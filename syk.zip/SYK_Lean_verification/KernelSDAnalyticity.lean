import KernelSDDifferentiation
import ConvolutionRegularity

/-!
# Analytic kernel orbits from the actual integrated SD equations

The convolution regularity hypotheses of the differentiation bridge are now
proved from the endpoint Lipschitz bound on the continuous remainder. This is
the concrete analytic step used for half-algebra generation.
-/

noncomputable section
namespace SYK

open Set

variable {A : Type*} [NormedRing A] [NormedAlgebra ℂ A] [NormOneClass A]
  [NormedSpace ℝ A] [IsScalarTower ℝ ℂ A] [CompleteSpace A]

/-- Actual two-sided integral SD identities and the Lipschitz remainder imply
real-analytic center-time motion, with no derivative or analyticity assumption. -/
theorem integratedSD_analytic_of_endpoint_lipschitz
    (β : ℝ) (hβ : 0 < β) (lam : ℂ) (R : KernelSpace A)
    (hSD : TwoSidedIntegratedKernelSD β hβ.le lam R)
    (hG : KernelAntiperiodic β (freeThermalKernel (A := A) β+R))
    (K : ℝ) (hK : 0 ≤ K)
    (hR : ∀ s t s' t', ‖R (s,t)-R (s',t')‖ ≤ K*(|s-s'|+|t-t'|)) :
    AnalyticOnNhd ℝ (fun u => translateKernel u R) Set.univ := by
  apply integratedSD_center_analytic β hβ lam R hSD hG K hK hR
    (ConvolutionRegularity.continuous_cube_G_convolution β hβ R K hK hR)
    (ConvolutionRegularity.continuous_G_cube_convolution β hβ R K hK hR)
    (‖(freeThermalKernel (A := A) β+R)^3‖*(1+β*K))
  exact ConvolutionRegularity.G_cube_convolution_left β hβ R K hR

/-- Every actual bilocal coordinate has an analytic simultaneous-translation
orbit, even though its dependence on either endpoint separately has jumps. -/
theorem integratedSD_coordinate_orbit_analytic
    (β : ℝ) (hβ : 0 < β) (lam : ℂ) (R : KernelSpace A)
    (hSD : TwoSidedIntegratedKernelSD β hβ.le lam R)
    (hG : KernelAntiperiodic β (freeThermalKernel (A := A) β+R))
    (K : ℝ) (hK : 0 ≤ K)
    (hR : ∀ s t s' t', ‖R (s,t)-R (s',t')‖ ≤ K*(|s-s'|+|t-t'|))
    (s t : ℝ) :
    AnalyticOnNhd ℝ (fun u => (freeThermalKernel (A := A) β+R) (s+u,t+u)) Set.univ := by
  have ha := integratedSD_analytic_of_endpoint_lipschitz β hβ lam R hSD hG K hK hR
  have he : (fun u => (freeThermalKernel (A := A) β+R) (s+u,t+u)) =
      (fun u => (kernelEvalCLM (A := A) (s,t)).restrictScalars ℝ (translateKernel u R) +
        freeThermalKernel (A := A) β (s,t)) := by
    funext u
    change freeThermalKernel (A := A) β (s+u,t+u)+R (s+u,t+u) =
      R (s+u,t+u)+freeThermalKernel (A := A) β (s,t)
    rw [freeThermalKernel_translation]
    exact add_comm _ _
  rw [he]
  intro u hu
  exact (((kernelEvalCLM (A := A) (s,t)).restrictScalars ℝ).analyticAt _ |>.comp (ha u hu)).add analyticAt_const

/-- Once a coordinate orbit meets a closed real linear subspace on a nonempty
open parameter interval, the proved SD analyticity puts its entire orbit there. -/
theorem integratedSD_coordinate_mem_of_open_seed
    (β : ℝ) (hβ : 0 < β) (lam : ℂ) (R : KernelSpace A)
    (hSD : TwoSidedIntegratedKernelSD β hβ.le lam R)
    (hG : KernelAntiperiodic β (freeThermalKernel (A := A) β+R))
    (K : ℝ) (hK : 0 ≤ K)
    (hR : ∀ s t s' t', ‖R (s,t)-R (s',t')‖ ≤ K*(|s-s'|+|t-t'|))
    (B : Submodule ℝ A) [IsClosed (B : Set A)] (s t : ℝ)
    (I : Set ℝ) (hI : IsOpen I) (hne : I.Nonempty)
    (hseed : ∀ u ∈ I, (freeThermalKernel (A := A) β+R) (s+u,t+u) ∈ B) :
    ∀ u, (freeThermalKernel (A := A) β+R) (s+u,t+u) ∈ B :=
  analytic_curve_mem_closed_submodule B _
    (integratedSD_coordinate_orbit_analytic β hβ lam R hSD hG K hK hR s t)
    I hI hne hseed

/-- The geometric half-circle seed and the actual SD equations place every
short-separation coordinate in the closed half-time subspace. -/
theorem integratedSD_short_pair_mem_half_subspace
    (β : ℝ) (hβ : 0 < β) (lam : ℂ) (R : KernelSpace A)
    (hSD : TwoSidedIntegratedKernelSD β hβ.le lam R)
    (hG : KernelAntiperiodic β (freeThermalKernel (A := A) β+R))
    (K : ℝ) (hK : 0 ≤ K)
    (hR : ∀ s t s' t', ‖R (s,t)-R (s',t')‖ ≤ K*(|s-s'|+|t-t'|))
    (B : Submodule ℝ A) [IsClosed (B : Set A)]
    (hhalf : ∀ s ∈ Ioo (0:ℝ) (β/2), ∀ t ∈ Ioo (0:ℝ) (β/2),
      (freeThermalKernel (A := A) β+R) (s,t) ∈ B)
    (s t : ℝ) (hsep : |s-t| < β/2) : (freeThermalKernel (A := A) β+R) (s,t) ∈ B := by
  obtain ⟨I,hI,hne,hfit⟩ := shifts_into_half_circle β s t hβ hsep
  have hm := integratedSD_coordinate_mem_of_open_seed β hβ lam R hSD hG K hK hR B s t
    I hI hne (fun u hu => hhalf (s+u) (hfit u hu).1 (t+u) (hfit u hu).2) 0
  simpa only [add_zero] using hm

/-- The continuous remainder inherits separate antiperiodicity because the
actual full kernel and free jump have the same signed period. -/
theorem remainder_antiperiodic
    (β : ℝ) (hβ : β ≠ 0) (R : KernelSpace A)
    (hG : KernelAntiperiodic β (freeThermalKernel (A := A) β+R)) : KernelAntiperiodic β R := by
  constructor <;> intro s t
  · have hg := hG.1 s t
    simp only [kernel_add_apply, freeThermalKernel_antiperiodic_left β hβ] at hg
    apply add_left_cancel (a := -(freeThermalKernel (A := A) β (s,t)))
    rw [hg, neg_add]
  · have hg := hG.2 s t
    simp only [kernel_add_apply, freeThermalKernel_antiperiodic_right β hβ] at hg
    apply add_left_cancel (a := -(freeThermalKernel (A := A) β (s,t)))
    rw [hg, neg_add]

/-- Every real separation has an antiperiodic lift at distance at most a
half-period, with equality covering the antipodal case. -/
theorem exists_half_period_lift (β : ℝ) (hβ : 0 < β) (s t : ℝ) :
    ∃ n : ℤ, |(s-n • β)-t| ≤ β/2 := by
  let n : ℤ := ⌊(s-t)/β+1/2⌋
  refine ⟨n, ?_⟩
  have hlo := mul_le_mul_of_nonneg_right (Int.floor_le ((s-t)/β+1/2)) hβ.le
  have hhi := mul_lt_mul_of_pos_right (Int.lt_floor_add_one ((s-t)/β+1/2)) hβ
  change (n:ℝ)*β ≤ ((s-t)/β+1/2)*β at hlo
  change ((s-t)/β+1/2)*β < ((n:ℝ)+1)*β at hhi
  rw [add_mul, div_mul_cancel₀ _ hβ.ne'] at hlo hhi
  rw [zsmul_eq_mul]
  apply abs_le.mpr
  constructor <;> nlinarith

/-- A closed unital half-time subalgebra contains every bilocal coordinate.
Antipodal pairs are handled by continuity of the remainder, and all other
lifts by literal antiperiodicity. No stationarity is used. -/
theorem integratedSD_all_coordinates_mem_half_algebra
    (β : ℝ) (hβ : 0 < β) (lam : ℂ) (R : KernelSpace A)
    (hSD : TwoSidedIntegratedKernelSD β hβ.le lam R)
    (hG : KernelAntiperiodic β (freeThermalKernel (A := A) β+R))
    (K : ℝ) (hK : 0 ≤ K)
    (hR : ∀ s t s' t', ‖R (s,t)-R (s',t')‖ ≤ K*(|s-s'|+|t-t'|))
    (B : Subalgebra ℂ A) [IsClosed (B : Set A)]
    (hhalf : ∀ s ∈ Ioo (0:ℝ) (β/2), ∀ t ∈ Ioo (0:ℝ) (β/2),
      (freeThermalKernel (A := A) β+R) (s,t) ∈ B) :
    ∀ s t, (freeThermalKernel (A := A) β+R) (s,t) ∈ B := by
  let Breal : Submodule ℝ A := B.toSubmodule.restrictScalars ℝ
  haveI : IsClosed (Breal : Set A) := (inferInstance : IsClosed (B : Set A))
  have hC : ∀ s t, freeThermalKernel (A := A) β (s,t) ∈ B := by
    intro s t
    exact B.smul_mem B.one_mem (Thermal.kernel β s t : ℂ)
  have hshort : ∀ s t, |s-t| < β/2 → R (s,t) ∈ B := by
    intro s t hst
    have hg := integratedSD_short_pair_mem_half_subspace β hβ lam R hSD hG K hK hR
      Breal hhalf s t hst
    have hh := B.sub_mem hg (hC s t)
    simpa only [kernel_add_apply, add_sub_cancel_left] using hh
  have hclosed : ∀ s t, |s-t| ≤ β/2 → R (s,t) ∈ B := by
    intro s t hst
    have hc : Continuous (fun x : ℝ => R (x,t)) := by
      apply (LipschitzWith.of_dist_le_mul (K := ⟨K,hK⟩) ?_).continuous
      intro x y
      simpa only [dist_eq_norm, Real.norm_eq_abs, sub_self, abs_zero, add_zero] using hR x t y t
    have hp : IsClosed {x : ℝ | R (x,t) ∈ B} := IsClosed.preimage hc inferInstance
    have hi : Ioo (t-β/2) (t+β/2) ⊆ {x : ℝ | R (x,t) ∈ B} := by
      intro x hx
      apply hshort x t
      rw [abs_lt]
      constructor <;> linarith [hx.1,hx.2]
    have hh := closure_minimal hi hp
    rw [closure_Ioo (by linarith : t-β/2 ≠ t+β/2)] at hh
    apply hh
    rcases abs_le.mp hst with ⟨hl,hr⟩
    constructor <;> linarith
  have hRa := remainder_antiperiodic β hβ.ne' R hG
  intro s t
  obtain ⟨n,hn⟩ := exists_half_period_lift β hβ s t
  have hm := hclosed (s-n • β) t hn
  have hanti : Function.Antiperiodic (fun x : ℝ => R (x,t)) β := fun x => hRa.1 x t
  have he := hanti.add_zsmul_eq n (x := s-n • β)
  simp only [sub_add_cancel] at he
  have hr : R (s,t) ∈ B := by
    rw [he]
    exact B.toSubmodule.toAddSubgroup.zsmul_mem hm _
  exact B.add_mem (hC s t) hr

end SYK
