import InsertedWickSeries
import MomentSymmetry

/-! # Exact external-field Weyl symmetries of the interacting Wick series -/
noncomputable section
open scoped BigOperators NNReal ComplexOrder
open MeasureTheory
namespace SYK.InsertedWickSymmetry
open ThermalWick Ward InsertedWickSeries

/-- Every interacting coefficient respects a genuine exterior-word scalar
identity. This statement includes the zero-word collision case. -/
theorem fieldCoefficient_of_word_smul (d : ℕ) {β : ℝ} (hβ : 0 < β)
    (L K : List (Label (2*d) β)) (c : ℂ)
    (h : FreeWick.word (fun p => field p.1 p.2) L =
      c • FreeWick.word (fun p => field p.1 p.2) K) (n : ℕ) :
    fieldCoefficient d hβ L n = c * fieldCoefficient d hβ K n := by
  unfold fieldCoefficient fieldIntegrand
  simp only [h, smul_mul_assoc, expectation, map_smul, smul_eq_mul]
  rw [integral_const_mul]
  simp only [Complex.real_smul]
  ring

/-- The complete convergent-series expression respects every exact external
exterior-word scalar identity, including arbitrary repeated labels. -/
theorem fieldNumerator_of_word_smul (d : ℕ) {β : ℝ} (hβ : 0 < β)
    (L K : List (Label (2*d) β)) (c : ℂ)
    (h : FreeWick.word (fun p => field p.1 p.2) L =
      c • FreeWick.word (fun p => field p.1 p.2) K) (lam : ℝ) :
    fieldNumerator d hβ L lam = c * fieldNumerator d hβ K lam := by
  unfold fieldNumerator ExponentialMomentSeries.value ExponentialMomentSeries.term
  simp_rw [fieldCoefficient_of_word_smul d hβ L K c h]
  simp only [Complex.real_smul]
  simp_rw [← mul_assoc, mul_comm _ c, mul_assoc]
  exact tsum_mul_left

/-- The list and alternating multilinear exterior words are identical. -/
theorem word_ofFn_eq_exteriorWord {N : ℕ} {β : ℝ} {m : ℕ} (L : Fin m → Label N β) :
    FreeWick.word (fun p => field p.1 p.2) (List.ofFn L) = FreeWeyl.exteriorWord L := by
  rw [FreeWick.word_ofFn]
  rfl

/-- Reordering external field labels contributes exactly its fermionic sign,
with no assumptions on their time coincidences. -/
theorem fieldNumerator_permutation (d : ℕ) {β : ℝ} (hβ : 0 < β) {m : ℕ}
    (L : Fin m → Label (2*d) β) (σ : Equiv.Perm (Fin m)) (lam : ℝ) :
    fieldNumerator d hβ (List.ofFn (L ∘ σ)) lam =
      Equiv.Perm.sign σ • fieldNumerator d hβ (List.ofFn L) lam := by
  have hp : FreeWeyl.exteriorWord (L ∘ σ) = Equiv.Perm.sign σ • FreeWeyl.exteriorWord L :=
    (ExteriorAlgebra.ιMulti ℂ m).map_perm (fun i => Finsupp.single (L i) 1) σ
  rcases Int.units_eq_one_or (Equiv.Perm.sign σ) with hs | hs
  · have hw : FreeWick.word (fun p => field p.1 p.2) (List.ofFn (L ∘ σ)) =
        (1 : ℂ) • FreeWick.word (fun p => field p.1 p.2) (List.ofFn L) := by
      simpa only [word_ofFn_eq_exteriorWord, hs, one_smul] using hp
    simpa only [hs, one_smul, one_mul] using fieldNumerator_of_word_smul d hβ _ _ 1 hw lam
  · have hw : FreeWick.word (fun p => field p.1 p.2) (List.ofFn (L ∘ σ)) =
        (-1 : ℂ) • FreeWick.word (fun p => field p.1 p.2) (List.ofFn L) := by
      simpa [word_ofFn_eq_exteriorWord, hs] using hp
    simpa [hs] using fieldNumerator_of_word_smul d hβ _ _ (-1) hw lam

/-- A repeated complete flavor-time label kills the whole interacting
external numerator by the exact exterior exclusion rule. -/
theorem fieldNumerator_zero_of_repeat (d : ℕ) {β : ℝ} (hβ : 0 < β) {m : ℕ}
    (L : Fin m → Label (2*d) β) (i j : Fin m) (hij : i ≠ j) (hL : L i = L j) (lam : ℝ) :
    fieldNumerator d hβ (List.ofFn L) lam = 0 := by
  have hw : FreeWeyl.exteriorWord L = 0 :=
    (ExteriorAlgebra.ιMulti ℂ m).map_eq_zero_of_eq
      (fun r => Finsupp.single (L r) (1 : ℂ)) (i := i) (j := j)
      (congrArg (fun p => Finsupp.single p (1 : ℂ)) hL) hij
  have h : FreeWick.word (fun p => field p.1 p.2) (List.ofFn L) =
      (0 : ℂ) • FreeWick.word (fun p : Label (2*d) β => field p.1 p.2) [] := by
    simpa only [word_ofFn_eq_exteriorWord, zero_smul] using hw
  simpa only [zero_mul] using fieldNumerator_of_word_smul d hβ _ [] 0 h lam

/-- Finite signed Weyl averaging commutes with an actual Bochner integral
when each genuine history is integrable. -/
theorem integral_signedAverage {X ι : Type*} [MeasurableSpace X]
    (μ : Measure X) (S : Finset ι) (ε : ι → ℤˣ) (F : ι → X → ℂ)
    (hF : ∀ i ∈ S, Integrable (F i) μ) :
    (∫ x, Interacting.signedAverage S ε (fun i => F i x) ∂μ) =
      Interacting.signedAverage S ε (fun i => ∫ x, F i x ∂μ) := by
  unfold Interacting.signedAverage
  rw [integral_const_mul, integral_finset_sum]
  · congr 1
    apply Finset.sum_congr rfl
    intro i hi
    rcases Int.units_eq_one_or (ε i) with h | h <;> simp [h, integral_neg]
  · intro i hi
    rcases Int.units_eq_one_or (ε i) with h | h
    · simpa [h] using hF i hi
    · have he (x : X) : ε i • F i x = -F i x := by simp [h]
      simp only [he]
      exact (hF i hi).neg

/-- The actual normalized annealed Weyl numerator equals its finite signed
average of actual normalized annealed ordered histories. -/
theorem annealedWeyl_eq_average (d : ℕ) (β : ℝ) (lam : ℝ≥0) {m : ℕ}
    (t : Fin m → ℝ) (A : Fin m → Matrix (Majorana.Basis d) (Majorana.Basis d) ℂ) :
    ((2 : ℂ)^d)⁻¹ * (∫ j, Interacting.weylNumerator (Majorana.hamiltonian d j) β t A
      ∂Microscopic.disorder d lam) =
      Interacting.signedAverage (Interacting.sortingPerms t) Equiv.Perm.sign
        (fun σ => ∫ j, Majorana.normalizedTrace d
          (Interacting.timeProduct (Majorana.hamiltonian d j) β (t ∘ σ) (A ∘ σ))
          ∂Microscopic.disorder d lam) := by
  unfold Interacting.weylNumerator
  rw [integral_signedAverage _ _ _ _ (fun σ _ => Interacting.timeProduct_integrable d β lam _ _)]
  rw [FreeWeyl.signedAverage_mul]
  congr 1
  funext σ
  rw [← integral_const_mul]
  congr 1
  funext j
  simp only [Majorana.normalizedTrace, div_eq_mul_inv]
  ring

end SYK.InsertedWickSymmetry
