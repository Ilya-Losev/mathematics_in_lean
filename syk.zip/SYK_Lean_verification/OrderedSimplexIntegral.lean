import Mathlib.MeasureTheory.Integral.Pi
import Mathlib.Analysis.SpecialFunctions.Integrals
import Mathlib.MeasureTheory.Measure.Lebesgue.EqHaar

/-!
# Genuine ordered time-simplex integrals

The ordered region is a subset of the actual Lebesgue product space, including
all boundaries. Its volume and constant Banach-valued integrals are computed
from Fubini, not supplied as combinatorial hypotheses.
-/

noncomputable section
open scoped BigOperators
open MeasureTheory MeasureTheory.Measure Set

namespace SYK.OrderedSimplexIntegral

/-- Descending interaction times between two fixed endpoints. -/
def orderedSimplex (n : ℕ) (a b : ℝ) : Set (Fin n → ℝ) :=
  {u | (∀ i, a ≤ u i) ∧ (∀ i, u i ≤ b) ∧ Antitone u}

@[simp] theorem orderedSimplex_zero (a b : ℝ) : orderedSimplex 0 a b = univ := by
  ext u
  simp [orderedSimplex, Antitone]

theorem orderedSimplex_closed (n : ℕ) (a b : ℝ) : IsClosed (orderedSimplex n a b) := by
  have h₁ := isClosed_iInter (fun i : Fin n => isClosed_le
    (f := fun _ : Fin n → ℝ => a) continuous_const (continuous_apply i))
  have h₂ := isClosed_iInter (fun i : Fin n => isClosed_le
    (g := fun _ : Fin n → ℝ => b) (continuous_apply i) continuous_const)
  have h₃ := isClosed_iInter (fun i : Fin n => isClosed_iInter (fun j : Fin n =>
    isClosed_iInter (fun _ : i ≤ j => isClosed_le
      (f := fun u : Fin n → ℝ => u j) (continuous_apply j) (continuous_apply i))))
  convert h₁.inter (h₂.inter h₃) using 1
  ext u
  simp [orderedSimplex, Antitone]

theorem orderedSimplex_measurable (n : ℕ) (a b : ℝ) : MeasurableSet (orderedSimplex n a b) :=
  (orderedSimplex_closed n a b).measurableSet

theorem orderedSimplex_compact (n : ℕ) (a b : ℝ) : IsCompact (orderedSimplex n a b) := by
  apply (isCompact_univ_pi (fun _ : Fin n => (isCompact_Icc : IsCompact (Icc a b)))).of_isClosed_subset
    (orderedSimplex_closed n a b)
  intro u hu
  exact fun i _ => ⟨hu.1 i, hu.2.1 i⟩

theorem orderedSimplex_volume_lt_top (n : ℕ) (a b : ℝ) :
    volume (orderedSimplex n a b) < ⊤ := (orderedSimplex_compact n a b).measure_lt_top

/-- Splitting off the latest time leaves the smaller simplex with that time
as its upper endpoint. -/
theorem cons_mem_orderedSimplex (n : ℕ) (a b t : ℝ) (u : Fin n → ℝ) :
    Fin.cons t u ∈ orderedSimplex (n+1) a b ↔
      t ∈ Icc a b ∧ u ∈ orderedSimplex n a t := by
  constructor
  · rintro ⟨hl, hr, hm⟩
    refine ⟨⟨by simpa using hl 0, by simpa using hr 0⟩, ?_, ?_, ?_⟩
    · intro i; simpa using hl i.succ
    · intro i; simpa using hm (Fin.zero_le i.succ)
    · intro i j hij; simpa using hm (Fin.succ_le_succ_iff.mpr hij)
  · rintro ⟨⟨ha, hb⟩, hl, hr, hm⟩
    refine ⟨?_, ?_, ?_⟩
    · intro i; refine Fin.cases ?_ (fun j => ?_) i
      · simpa using ha
      · simpa using hl j
    · intro i; refine Fin.cases ?_ (fun j => ?_) i
      · simpa using hb
      · simpa using (hr j).trans hb
    · intro i j
      refine Fin.cases ?_ (fun i' => ?_) i
      · refine Fin.cases ?_ (fun j' => ?_) j
        · simp
        · intro _; simpa using hr j'
      · refine Fin.cases ?_ (fun j' => ?_) j
        · simp
        · intro hij; simpa using hm (Fin.succ_le_succ_iff.mp hij)

/-- Fubini recurrence for the actual finite product Lebesgue volume. -/
theorem orderedSimplex_volume_succ (n : ℕ) (a b : ℝ) (hab : a ≤ b) :
    volume.real (orderedSimplex (n+1) a b) =
      ∫ t in a..b, volume.real (orderedSimplex n a t) := by
  let e := (MeasurableEquiv.piFinSuccAbove (fun _ : Fin (n+1) => ℝ) 0).symm
  let S : Set (ℝ × (Fin n → ℝ)) := e ⁻¹' orderedSimplex (n+1) a b
  have he : MeasurePreserving e volume volume :=
    (volume_preserving_piFinSuccAbove (fun _ : Fin (n+1) => ℝ) 0).symm
  have hS : MeasurableSet S := (orderedSimplex_measurable (n+1) a b).preimage e.measurable
  have hslice (t : ℝ) : Prod.mk t ⁻¹' S =
      if t ∈ Icc a b then orderedSimplex n a t else ∅ := by
    ext u
    change e (t, u) ∈ orderedSimplex (n+1) a b ↔ _
    have heq : e (t,u) = Fin.cons t u := by
      simp [e, MeasurableEquiv.piFinSuccAbove_symm_apply, Fin.insertNthEquiv]
    rw [heq, cons_mem_orderedSimplex]
    by_cases ht : t ∈ Icc a b <;> simp [ht]
  have hvol : volume S = volume (orderedSimplex (n+1) a b) :=
    he.measure_preimage (orderedSimplex_measurable (n+1) a b).nullMeasurableSet
  rw [measureReal_def, ← hvol, volume_eq_prod, Measure.prod_apply hS]
  rw [← integral_toReal (measurable_measure_prodMk_left hS).aemeasurable]
  · rw [intervalIntegral.integral_of_le hab, ← integral_Icc_eq_integral_Ioc,
      ← integral_indicator measurableSet_Icc]
    apply integral_congr_ae
    exact Filter.Eventually.of_forall (fun t => by
      dsimp only
      rw [hslice]
      by_cases ht : t ∈ Icc a b <;> simp [ht, measureReal_def])
  · exact Filter.Eventually.of_forall (fun t => by
      rw [hslice]
      by_cases ht : t ∈ Icc a b
      · simpa [ht] using orderedSimplex_volume_lt_top n a t
      · simp [ht])

/-- The exact ordered-simplex volume, also valid when the gap has width zero. -/
theorem orderedSimplex_volume_real (n : ℕ) (a b : ℝ) (hab : a ≤ b) :
    volume.real (orderedSimplex n a b) = (b-a)^n / n.factorial := by
  induction n generalizing b with
  | zero => simp [measureReal_def, volume_pi]
  | succ n ih =>
      rw [orderedSimplex_volume_succ n a b hab]
      calc
        _ = ∫ t in a..b, (t-a)^n / n.factorial := by
          apply intervalIntegral.integral_congr
          intro t ht
          exact ih t (by simpa only [min_eq_left hab] using ht.1)
        _ = (b-a)^(n+1) / (n+1).factorial := by
          rw [intervalIntegral.integral_div,
            intervalIntegral.integral_comp_sub_right (fun x : ℝ => x^n) a, integral_pow]
          simp only [sub_self, zero_pow (by omega : n+1 ≠ 0), sub_zero,
            Nat.factorial_succ, Nat.cast_mul, Nat.cast_add, Nat.cast_one]
          rw [div_div]

/-- ENNReal-valued version of the genuine product-measure formula. -/
theorem orderedSimplex_volume (n : ℕ) (a b : ℝ) (hab : a ≤ b) :
    volume (orderedSimplex n a b) = ENNReal.ofReal ((b-a)^n / n.factorial) := by
  rw [← orderedSimplex_volume_real n a b hab]
  exact (ENNReal.ofReal_toReal (orderedSimplex_volume_lt_top n a b).ne).symm

/-- Constant vector or matrix histories integrate to the actual simplex
volume times the constant, in every real Banach space. -/
theorem integral_orderedSimplex_const {E : Type*} [NormedAddCommGroup E]
    [NormedSpace ℝ E] [CompleteSpace E] (n : ℕ) (a b : ℝ) (hab : a ≤ b) (v : E) :
    ∫ _u in orderedSimplex n a b, v = ((b-a)^n / n.factorial) • v := by
  rw [setIntegral_const, orderedSimplex_volume_real n a b hab]

/-- Each pairwise coincidence hyperplane is Lebesgue-null. -/
theorem coordinate_collision_null {n : ℕ} (i j : Fin n) (hij : i ≠ j) :
    volume {u : Fin n → ℝ | u i = u j} = 0 := by
  let L : (Fin n → ℝ) →ₗ[ℝ] ℝ := (LinearMap.proj i : (Fin n → ℝ) →ₗ[ℝ] ℝ) -
    (LinearMap.proj j : (Fin n → ℝ) →ₗ[ℝ] ℝ)
  have hL : L ≠ 0 := by
    intro h
    have hh := congrArg (fun f : (Fin n → ℝ) →ₗ[ℝ] ℝ => f (Pi.single i 1)) h
    simp [L, Pi.single_apply, hij, hij.symm] at hh
  have hk : LinearMap.ker L ≠ ⊤ := by rwa [Ne, LinearMap.ker_eq_top]
  have hs : {u : Fin n → ℝ | u i = u j} = (LinearMap.ker L : Set (Fin n → ℝ)) := by
    ext u
    simp [L, sub_eq_zero]
  rw [hs]
  exact Measure.addHaar_submodule volume (LinearMap.ker L) hk

/-- The interaction times are pairwise distinct almost everywhere in the
full product space, before restriction to any simplex or cube. -/
theorem ae_injective_times (n : ℕ) :
    ∀ᵐ u : Fin n → ℝ, Function.Injective u := by
  apply ae_all_iff.mpr
  intro i
  apply ae_all_iff.mpr
  intro j
  by_cases hij : i = j
  · exact Filter.Eventually.of_forall (fun _ _ => hij)
  · have hn : ∀ᵐ u : Fin n → ℝ, u i ≠ u j := by
      rw [ae_iff]
      simpa only [not_not] using coordinate_collision_null i j hij
    exact hn.mono (fun _ hu h => False.elim (hu h))

/-- Fixed external insertion times and interval endpoints are also avoided
by almost every interaction-time vector. -/
theorem ae_times_avoid (n : ℕ) (t : ℝ) :
    ∀ᵐ u : Fin n → ℝ, ∀ i, u i ≠ t := by
  rw [ae_all_iff]
  intro i
  simpa only [volume_pi] using Measure.ae_eval_ne (fun _ : Fin n => (volume : Measure ℝ)) i t

/-- The open simplex used for strict time ordering. -/
def strictOrderedSimplex (n : ℕ) (a b : ℝ) : Set (Fin n → ℝ) :=
  {u | (∀ i, a < u i) ∧ (∀ i, u i < b) ∧ StrictAnti u}

/-- All boundary conventions give the same integrals: endpoints and ties
form a null set, including in a zero-width gap. -/
theorem strictOrderedSimplex_ae_eq (n : ℕ) (a b : ℝ) :
    strictOrderedSimplex n a b =ᵐ[volume] orderedSimplex n a b := by
  filter_upwards [ae_injective_times n, ae_times_avoid n a, ae_times_avoid n b] with u hu ha hb
  apply propext
  constructor
  · rintro ⟨hl, hr, hm⟩
    exact ⟨fun i => (hl i).le, fun i => (hr i).le, hm.antitone⟩
  · rintro ⟨hl, hr, hm⟩
    exact ⟨fun i => lt_of_le_of_ne (hl i) (ha i).symm,
      fun i => lt_of_le_of_ne (hr i) (hb i), hm.strictAnti_of_injective hu⟩

theorem strictOrderedSimplex_volume (n : ℕ) (a b : ℝ) (hab : a ≤ b) :
    volume (strictOrderedSimplex n a b) = ENNReal.ofReal ((b-a)^n / n.factorial) := by
  rw [measure_congr (strictOrderedSimplex_ae_eq n a b), orderedSimplex_volume n a b hab]

theorem integral_strictOrderedSimplex_const {E : Type*} [NormedAddCommGroup E]
    [NormedSpace ℝ E] [CompleteSpace E] (n : ℕ) (a b : ℝ) (hab : a ≤ b) (v : E) :
    ∫ _u in strictOrderedSimplex n a b, v = ((b-a)^n / n.factorial) • v := by
  rw [setIntegral_congr_set (strictOrderedSimplex_ae_eq n a b),
    integral_orderedSimplex_const n a b hab]

/-- Repeated insertion of a constant interaction matrix has exactly the
factorial-normalized coefficient of its genuine propagator exponential. -/
theorem integral_constant_interaction {A : Type*} [NormedRing A]
    [NormedAlgebra ℂ A] [NormedSpace ℝ A] [IsScalarTower ℝ ℂ A] [CompleteSpace A]
    (n : ℕ) (a b : ℝ) (hab : a ≤ b) (H : A) :
    ∫ _u in orderedSimplex n a b, H^n =
      (n.factorial : ℂ)⁻¹ • (((b-a : ℝ) : ℂ) • H)^n := by
  rw [integral_orderedSimplex_const n a b hab, smul_pow, smul_smul,
    RCLike.real_smul_eq_coe_smul (K := ℂ)]
  congr 1
  change (((b-a)^n / n.factorial : ℝ) : ℂ) = _
  push_cast
  ring

end SYK.OrderedSimplexIntegral
