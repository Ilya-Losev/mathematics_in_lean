import WeylReflection
import MomentSymmetry

/-! # Reflection of actual flavor-averaged bilocal words -/
noncomputable section
open scoped BigOperators ComplexOrder NNReal
namespace SYK.BilocalReflection
open Interacting WeylBlocks WeylReflection

/-- Reflection reverses the two fields in each bilocal. -/
def reflectPair (β : ℝ) (p : ℝ × ℝ) : ℝ × ℝ := (β-p.2, β-p.1)

/-- Canonical transport of the flattened concatenated field indices. -/
def appendFields (m n : ℕ) : Fin (m*2+n*2) ≃ Fin ((m+n)*2) :=
  finCongr (Nat.add_mul m n 2).symm

@[simp] theorem appendFields_left_div (m n : ℕ) (i : Fin (m*2)) :
    (appendFields m n (Fin.castAdd (n*2) i)).divNat = Fin.castAdd n i.divNat := by
  apply Fin.ext
  rfl

@[simp] theorem appendFields_right_div (m n : ℕ) (i : Fin (n*2)) :
    (appendFields m n (Fin.natAdd (m*2) i)).divNat = Fin.natAdd m i.divNat := by
  apply Fin.ext
  simp only [Fin.coe_divNat, appendFields, finCongr_apply, Fin.coe_cast, Fin.coe_natAdd]
  omega

@[simp] theorem appendFields_left_mod (m n : ℕ) (i : Fin (m*2)) :
    (appendFields m n (Fin.castAdd (n*2) i)).modNat = i.modNat := by
  apply Fin.ext
  rfl

@[simp] theorem appendFields_right_mod (m n : ℕ) (i : Fin (n*2)) :
    (appendFields m n (Fin.natAdd (m*2) i)).modNat = i.modNat := by
  apply Fin.ext
  simp only [Fin.coe_modNat, appendFields, finCongr_apply, Fin.coe_cast, Fin.coe_natAdd]
  omega

/-- Flattening a concatenated tuple is concatenating the flattened words. -/
theorem pairTimes_append {m n : ℕ} (p : Fin m → ℝ × ℝ) (q : Fin n → ℝ × ℝ) :
    pairTimes (Fin.append p q) ∘ appendFields m n = Fin.append (pairTimes p) (pairTimes q) := by
  funext i
  refine Fin.addCases (fun r => ?_) (fun r => ?_) i <;>
    simp only [Function.comp_def, pairTimes, appendFields_left_div, appendFields_right_div,
      appendFields_left_mod, appendFields_right_mod, Fin.append_left, Fin.append_right]

/-- Flavor assignments concatenate with the same canonical field transport. -/
theorem pairFlavors_append {m n N : ℕ} (f : Fin m → Fin N) (g : Fin n → Fin N) :
    pairFlavors (Fin.append f g) ∘ appendFields m n = Fin.append (pairFlavors f) (pairFlavors g) := by
  funext i
  refine Fin.addCases (fun r => ?_) (fun r => ?_) i <;>
    simp only [Function.comp_def, pairFlavors, appendFields_left_div, appendFields_right_div,
      Fin.append_left, Fin.append_right]

/-- Reversing a flattened even word reverses the bilocal occurrence index. -/
theorem divNat_rev {m : ℕ} (i : Fin (m*2)) : i.rev.divNat = i.divNat.rev := by
  apply Fin.ext
  simp only [Fin.coe_divNat, Fin.val_rev]
  have hi := i.isLt
  omega

/-- Full reversal agrees exactly with reflecting and reversing the bilocals. -/
theorem pairTimes_reflected {m : ℕ} (β : ℝ) (p : Fin m → ℝ × ℝ) :
    pairTimes (fun r => reflectPair β (p r.rev)) = fun i => β-pairTimes p i.rev := by
  funext i
  simp only [pairTimes, reflectPair, divNat_rev, Fin.modNat_rev]
  have hh : ∀ j : Fin 2, j = 0 ∨ j = 1 := by decide
  have h := hh i.modNat
  rcases h with h | h <;> simp [h]

 theorem pairFlavors_reflected {m N : ℕ} (f : Fin m → Fin N) :
    pairFlavors (fun r => f r.rev) = fun i => pairFlavors f i.rev := by
  funext i
  simp only [pairFlavors, divNat_rev]

section Transfer
variable {ν : Type*} [Fintype ν] [DecidableEq ν]

/-- A canonical cast of a finite tuple does not change its Weyl transfer. -/
theorem weylTransfer_cast {k l : ℕ} (h : k=l) (H : Matrix ν ν ℂ) (β : ℝ)
    (t : Fin l → ℝ) (A : Fin l → Matrix ν ν ℂ) :
    weylTransfer H β (t ∘ finCongr h) (A ∘ finCongr h) = weylTransfer H β t A := by
  subst l
  rfl

end Transfer

/-- The actual finite flavor-averaged half-history amplitude. -/
def collectiveTransfer (d : ℕ) {m : ℕ}
    (H : Matrix (Majorana.Basis d) (Majorana.Basis d) ℂ) (a : ℝ)
    (p : Fin m → ℝ × ℝ) : Matrix (Majorana.Basis d) (Majorana.Basis d) ℂ :=
  (((2*d : ℕ):ℂ)^m)⁻¹ • ∑ f : Fin m → Fin (2*d),
    weylTransfer H a (pairTimes p) (fun i => Majorana.chiFin d (pairFlavors f i))

@[simp] theorem trace_collectiveTransfer (d : ℕ) {m : ℕ}
    (H : Matrix (Majorana.Basis d) (Majorana.Basis d) ℂ) (a : ℝ)
    (p : Fin m → ℝ × ℝ) :
    Matrix.trace (collectiveTransfer d H a p) = collectiveNumerator d H a p := by
  simp only [collectiveTransfer, collectiveNumerator, Matrix.trace_smul,
    Matrix.trace_sum, trace_weylTransfer, smul_eq_mul]

/-- The full finite flavor average factors across a strict time cut. -/
theorem collectiveTransfer_append (d : ℕ) {m n : ℕ}
    (H : Matrix (Majorana.Basis d) (Majorana.Basis d) ℂ) (a c : ℝ)
    (p : Fin m → ℝ × ℝ) (q : Fin n → ℝ × ℝ)
    (hsep : ∀ i j, pairTimes q j < pairTimes p i) :
    collectiveTransfer d H a (Fin.append p q) =
      collectiveTransfer d H (a-c) (fun i => ((p i).1-c,(p i).2-c)) *
      collectiveTransfer d H c q := by
  classical
  have hterm (f : Fin m → Fin (2*d)) (g : Fin n → Fin (2*d)) :
      weylTransfer H a (pairTimes (Fin.append p q))
        (fun i => Majorana.chiFin d (pairFlavors (Fin.append f g) i)) =
      weylTransfer H (a-c) (pairTimes (fun i => ((p i).1-c,(p i).2-c)))
        (fun i => Majorana.chiFin d (pairFlavors f i)) *
      weylTransfer H c (pairTimes q) (fun i => Majorana.chiFin d (pairFlavors g i)) := by
    rw [← weylTransfer_cast (Nat.add_mul m n 2).symm H a]
    change weylTransfer H a (pairTimes (Fin.append p q) ∘ appendFields m n)
      ((fun i => Majorana.chiFin d (pairFlavors (Fin.append f g) i)) ∘ appendFields m n) = _
    rw [pairTimes_append]
    have hf : ((fun i => Majorana.chiFin d (pairFlavors (Fin.append f g) i)) ∘ appendFields m n) =
        Fin.append (fun i => Majorana.chiFin d (pairFlavors f i))
          (fun i => Majorana.chiFin d (pairFlavors g i)) := by
      have hh := pairFlavors_append f g
      funext i
      have hh' := congrFun hh i
      simp only [Function.comp_def] at hh' ⊢
      rw [hh']
      refine Fin.addCases (fun _ => ?_) (fun _ => ?_) i <;> simp only [Fin.append_left, Fin.append_right]
    rw [hf, weylTransfer_append H a c _ _ hsep]
    have ht : (fun i => pairTimes p i-c) = pairTimes (fun i => ((p i).1-c,(p i).2-c)) := by
      funext i
      simp only [pairTimes]
      split_ifs <;> rfl
    rw [ht]
  unfold collectiveTransfer
  rw [← Equiv.sum_comp (Fin.appendEquiv (α := Fin (2*d)) m n)]
  change _ = _
  simp only [Fintype.sum_prod_type, Fin.appendEquiv, Equiv.coe_fn_mk] 
  simp only [hterm, pow_add, mul_inv_rev]
  simp only [← Finset.mul_sum, ← Finset.sum_mul]
  simp only [smul_mul_assoc, mul_smul_comm, smul_smul, mul_comm]

/-- Reflection of the complete flavor sum is its ordinary matrix adjoint. -/
theorem collectiveTransfer_reflected (d : ℕ) {m : ℕ}
    {H : Matrix (Majorana.Basis d) (Majorana.Basis d) ℂ} (hH : H.IsHermitian)
    (a : ℝ) (p : Fin m → ℝ × ℝ) :
    collectiveTransfer d H a (fun r => reflectPair a (p r.rev)) =
      star (collectiveTransfer d H a p) := by
  classical
  unfold collectiveTransfer
  rw [← Equiv.sum_comp (Equiv.arrowCongr Fin.revPerm (Equiv.refl (Fin (2*d))))]
  simp only [← Nat.cast_pow, star_inv_natCast_smul, star_sum]
  congr 1
  apply Finset.sum_congr rfl
  intro f _
  change weylTransfer H a (pairTimes (fun r => reflectPair a (p r.rev)))
    (fun i => Majorana.chiFin d (pairFlavors (fun r => f r.rev) i)) = _
  rw [pairTimes_reflected, pairFlavors_reflected]
  simpa only [Majorana.chiFin_star] using weylTransfer_reflected hH a (pairTimes p)
    (fun i => Majorana.chiFin d (pairFlavors f i))

/-- Actual collective reflected monomials equal a Hilbert--Schmidt inner
product, with both flavor sums and all coincident-time Weyl signs retained. -/
theorem collectiveNumerator_reflected_pair (d : ℕ) {m n : ℕ}
    {H : Matrix (Majorana.Basis d) (Majorana.Basis d) ℂ} (hH : H.IsHermitian)
    (a : ℝ) (p : Fin m → ℝ × ℝ) (q : Fin n → ℝ × ℝ)
    (hp : ∀ i, (p i).1 < a ∧ (p i).2 < a)
    (hq : ∀ i, (q i).1 < a ∧ (q i).2 < a) :
    collectiveNumerator d H (2*a) (Fin.append (fun r => reflectPair (2*a) (p r.rev)) q) =
      Matrix.trace (star (collectiveTransfer d H a p) * collectiveTransfer d H a q) := by
  rw [← trace_collectiveTransfer]
  have hsep (i : Fin (m*2)) (j : Fin (n*2)) :
      pairTimes q j < pairTimes (fun r => reflectPair (2*a) (p r.rev)) i := by
    rw [pairTimes_reflected]
    have hi : pairTimes p i.rev < a := by
      dsimp [pairTimes]
      split_ifs
      · exact (hp _).1
      · exact (hp _).2
    have hj : pairTimes q j < a := by
      dsimp [pairTimes]
      split_ifs
      · exact (hq _).1
      · exact (hq _).2
    dsimp only
    linarith
  rw [collectiveTransfer_append d H (2*a) a _ _ hsep]
  have hr : (fun i : Fin m => ((reflectPair (2*a) (p i.rev)).1-a,
      (reflectPair (2*a) (p i.rev)).2-a)) = (fun i => reflectPair a (p i.rev)) := by
    funext i
    simp only [reflectPair]
    congr 1 <;> ring
  rw [show 2*a-a=a by ring, hr, collectiveTransfer_reflected d hH]

/-- Actual half-history matrix amplitude of a finite collective polynomial. -/
def collectiveAmplitude {ι : Type*} [Fintype ι] (d : ℕ)
    (H : Matrix (Majorana.Basis d) (Majorana.Basis d) ℂ) (a : ℝ)
    (k : ι → ℕ) (c : ι → ℂ) (p : ∀ i, Fin (k i) → ℝ × ℝ) :
    Matrix (Majorana.Basis d) (Majorana.Basis d) ℂ :=
  ∑ i, c i • collectiveTransfer d H a (p i)

/-- Full collective polynomial reflection is an exact trace star-square. -/
theorem collectiveNumerator_reflected_sum {ι : Type*} [Fintype ι] (d : ℕ)
    {H : Matrix (Majorana.Basis d) (Majorana.Basis d) ℂ} (hH : H.IsHermitian)
    (a : ℝ) (k : ι → ℕ) (c : ι → ℂ) (p : ∀ i, Fin (k i) → ℝ × ℝ)
    (hp : ∀ i r, (p i r).1 < a ∧ (p i r).2 < a) :
    (∑ i, ∑ j, (star (c i) * c j) * collectiveNumerator d H (2*a)
      (Fin.append (fun r => reflectPair (2*a) (p i r.rev)) (p j))) =
      Matrix.trace (star (collectiveAmplitude d H a k c p) * collectiveAmplitude d H a k c p) := by
  simp only [collectiveNumerator_reflected_pair d hH a _ _ (hp _) (hp _)]
  have hs : (∑ i, ∑ j, (star (c i)*c j) •
      (star (collectiveTransfer d H a (p i))*collectiveTransfer d H a (p j))) =
      star (collectiveAmplitude d H a k c p)*collectiveAmplitude d H a k c p := by
    simp only [collectiveAmplitude, star_sum, star_smul, Finset.sum_mul,
      Finset.mul_sum, smul_mul_assoc, mul_smul_comm, smul_smul, Finset.smul_sum]
    rw [Finset.sum_comm]
    simp only [mul_comm]
  rw [← hs]
  simp only [Matrix.trace_sum, Matrix.trace_smul, smul_eq_mul]

end SYK.BilocalReflection
