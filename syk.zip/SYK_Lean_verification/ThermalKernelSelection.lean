import ThermalHalfGeneration
import KernelSelection

/-!
# Physical selection and factorization for the actual thermal double quotient

Half-time reflection positivity is extended using the proved half-algebra
generation theorem. Both SD and regularity are supplied by the actual quotient;
odd inserted positivity and the limiting state's symmetry data are the remaining
microscopic-to-limit inputs.
-/

noncomputable section
namespace SYK.ThermalKernelSelection

open Set
open SYK.WeightedKernelAlgebra SYK.KernelResidualAlgebra
open SYK.KernelCoordinateGeneration SYK.KernelQuotientAnalyticity
open SYK.KernelSelection SYK.GNS
open scoped NNReal BigOperators

variable (b K : ℝ) (hb : 0 < b) (hK : 0 < K)
  (β : ℝ) (hβ : 0 < β) (lam : ℝ≥0)
  [Nontrivial (RegularityAlgebra b K hb hK (thermalCovariance β) (symmetryRelations β))]
  [Nontrivial (ThermalSDAlgebra b K hb hK β hβ (lam:ℂ) (symmetryRelations β))]

/-- The algebra of actual finite positive-half-time coordinate polynomials. -/
def halfPolynomialAlgebra :
    Subalgebra ℂ (ThermalSDAlgebra b K hb hK β hβ (lam:ℂ) (symmetryRelations β)) :=
  Algebra.adjoin ℂ (Set.range (fun p : Ioo (0:ℝ) (β/2) × Ioo (0:ℝ) (β/2) =>
    thermalFinalKernel b K hb hK β hβ (lam:ℂ) (symmetryRelations β) (p.1,p.2)))

/-- The actual half-time polynomial family is dense, with no density axiom. -/
theorem halfPolynomialAlgebra_dense :
    Dense (halfPolynomialAlgebra b K hb hK β hβ lam :
      Set (ThermalSDAlgebra b K hb hK β hβ (lam:ℂ) (symmetryRelations β))) := by
  let B := halfPolynomialAlgebra b K hb hK β hβ lam
  haveI : IsClosed (B.topologicalClosure :
      Set (ThermalSDAlgebra b K hb hK β hβ (lam:ℂ) (symmetryRelations β))) :=
    B.isClosed_topologicalClosure
  have ht : B.topologicalClosure = ⊤ := by
    apply SYK.ThermalHalfGeneration.closed_half_algebra_eq_top b K hb hK β hβ (lam:ℂ)
    intro s hs t ht
    apply B.le_topologicalClosure
    exact Algebra.subset_adjoin ⟨(⟨s,hs⟩,⟨t,ht⟩),rfl⟩
  apply dense_iff_closure_eq.mpr
  change closure (B : Set (ThermalSDAlgebra b K hb hK β hβ (lam:ℂ) (symmetryRelations β))) = Set.univ
  rw [← Subalgebra.topologicalClosure_coe, ht]
  rfl

variable
  [StarRing (ThermalSDAlgebra b K hb hK β hβ (lam:ℂ) (symmetryRelations β))]
  [StarModule ℂ (ThermalSDAlgebra b K hb hK β hβ (lam:ℂ) (symmetryRelations β))]
  [NormedStarGroup (ThermalSDAlgebra b K hb hK β hβ (lam:ℂ) (symmetryRelations β))]

/-- Construct the fully positive state from the limiting functional's actual
half-time reflection-positivity inequalities. -/
def limitingPositiveState
    (L : ThermalSDAlgebra b K hb hK β hβ (lam:ℂ) (symmetryRelations β) →L[ℂ] ℂ)
    (hreal : ∀ q ∈ halfPolynomialAlgebra b K hb hK β hβ lam, (L (star q*q)).im = 0)
    (hpos : ∀ q ∈ halfPolynomialAlgebra b K hb hK β hβ lam, 0 ≤ (L (star q*q)).re) :
    PositiveFunctional (ThermalSDAlgebra b K hb hK β hβ (lam:ℂ) (symmetryRelations β)) :=
  positiveFunctionalOfDense L _ (halfPolynomialAlgebra_dense b K hb hK β hβ lam) hreal hpos

/-- Existence of the unique physical scalar kernel and factorization of all
bilocal moments of the actual quotient state. No scalar solution, spectral
measure, analytic orbit, Hankel positivity, or factorization is assumed. -/
theorem exists_physical_factorization
    (L : ThermalSDAlgebra b K hb hK β hβ (lam:ℂ) (symmetryRelations β) →L[ℂ] ℂ)
    (hunit : L 1 = 1)
    (hreal : ∀ q ∈ halfPolynomialAlgebra b K hb hK β hβ lam, (L (star q*q)).im = 0)
    (hpos : ∀ q ∈ halfPolynomialAlgebra b K hb hK β hβ lam, 0 ≤ (L (star q*q)).re)
    (D : KernelActionData (limitingPositiveState b K hb hK β hβ lam L hreal hpos) β
      (thermalFinalKernel b K hb hK β hβ (lam:ℂ) (symmetryRelations β)))
    (hodd : ∀ (k : ℕ) (x : Fin k → Ioo (0:ℝ) (β/2)) (c : Fin k → ℂ) q,
      q ∈ halfPolynomialAlgebra b K hb hK β hβ lam →
      0 ≤ (L (star q*q*hankelObservable β
        (thermalFinalKernel b K hb hK β hβ (lam:ℂ) (symmetryRelations β)) (fun i => x i) c)).re) :
    ∃ g : ℝ → ℝ, SYK.Continuum.PhysicalSolution β lam g ∧
      ∀ (k : ℕ) (p : Fin k → ℝ × ℝ),
        L (∏ i, thermalFinalKernel b K hb hK β hβ (lam:ℂ) (symmetryRelations β) (p i)) =
          ∏ i, (g ((p i).1-(p i).2) : ℂ) := by
  have ha := finalKernel_antiperiodic b K hb hK (thermalCovariance β) β hβ.le (lam:ℂ)
    (thermalCovariance_stronglyMeasurable β) (1/2) (norm_thermalCovariance_le β)
  have hs := finalKernel_skew b K hb hK (thermalCovariance β) β hβ.le (lam:ℂ)
    (thermalCovariance_stronglyMeasurable β) (1/2) (norm_thermalCovariance_le β)
  have hz := finalKernel_diagonal b K hb hK (thermalCovariance β) β hβ.le (lam:ℂ)
    (thermalCovariance_stronglyMeasurable β) (1/2) (norm_thermalCovariance_le β) 0
  have hsd := thermalFinal_integratedSD b K hb hK β hβ (lam:ℂ) (symmetryRelations β)
  dsimp only [TwoSidedIntegratedKernelSD] at hsd
  rw [free_add_thermalFinalRemainder] at hsd
  exact SYK.KernelSelection.exists_physical_factorization hβ lam _ D ha hs hz hsd.1 _
    (halfPolynomialAlgebra_dense b K hb hK β hβ lam) hodd hunit

end SYK.ThermalKernelSelection
