import ContinuumWickSeries

/-!
# Actual continuum Wick series with even external field words

The coefficients remain genuine scalar time integrals. This module is the
finite-flavor bridge from individual operator words to collective monomials.
-/
noncomputable section
open scoped BigOperators NNReal ComplexOrder
open MeasureTheory Filter
namespace SYK.InsertedWickSeries
open ThermalWick Ward WickVertexIntegrals ContinuumWickSeries

/-- Numeric interaction integrand with one specified external field word. -/
def fieldIntegrand (d : ℕ) {β : ℝ} (hβ : 0 < β)
    (L : List (Label (2*d) β)) {n : ℕ} (u : Fin n → ℝ×ℝ) : ℂ :=
  expectation (2*d) β (FreeWick.word (fun p => field p.1 p.2) L *
    collectiveMonomial (interactionPairs β hβ u))

/-- Genuine factorial-free continuum coefficient of an external word. -/
def fieldCoefficient (d : ℕ) {β : ℝ} (hβ : 0 < β)
    (L : List (Label (2*d) β)) (n : ℕ) : ℂ :=
  (((2*d : ℕ) : ℝ)/8)^n • ∫ u, fieldIntegrand d hβ L u ∂interactionMeasure β n

def fieldNumerator (d : ℕ) {β : ℝ} (hβ : 0 < β)
    (L : List (Label (2*d) β)) (lam : ℝ) : ℂ :=
  ExponentialMomentSeries.value (fieldCoefficient d hβ L) lam

/-- Measurability is proved on the numeric expectation only. -/
theorem fieldIntegrand_measurable (d : ℕ) {β : ℝ} (hβ : 0 < β)
    (L : List (Label (2*d) β)) (hL : Even L.length) (n : ℕ) :
    Measurable (fieldIntegrand d hβ L (n := n)) := by
  have h := measurable_word_collectives d hβ (interactionPairFunctions β hβ n)
    (interactionPairFunctions_measurable β hβ n)
    (L.map (fun p => (p.1, fun _ : Fin n → ℝ×ℝ => p.2)))
    (by simpa using hL) (by
      intro p hp
      obtain ⟨q,_,rfl⟩ := List.mem_map.mp hp
      change Measurable (fun _ : Fin n → ℝ×ℝ => q.2.val)
      exact measurable_const)
  have he (u : Fin n → ℝ×ℝ) :
      (L.map (fun p => (p.1, fun _ : Fin n → ℝ×ℝ => p.2))).map (fun p => (p.1,p.2 u)) = L := by
    simp only [List.map_map, Function.comp_def, Prod.mk.eta]
    exact List.map_id L
  simpa only [he, interactionPairFunctions_eval, fieldIntegrand] using h

/-- The sharp actual free-model estimate retains every external field factor. -/
theorem fieldIntegrand_bound (d : ℕ) (hd : 0 < d) {β : ℝ} (hβ : 0 < β)
    (L : List (Label (2*d) β)) (hL : Even L.length) {n : ℕ} (u : Fin n → ℝ×ℝ) :
    ‖fieldIntegrand d hβ L u‖ ≤ ((Real.sqrt 2)⁻¹)^L.length * (1/2 : ℝ)^(4*n) := by
  simpa only [fieldIntegrand, interactionPairs_length] using
    FreeWeyl.expectation_word_collective_bound d hd hβ (interactionPairs β hβ u) L hL

theorem fieldIntegrand_integrable (d : ℕ) (hd : 0 < d) {β : ℝ} (hβ : 0 < β)
    (L : List (Label (2*d) β)) (hL : Even L.length) (n : ℕ) :
    Integrable (fieldIntegrand d hβ L) (interactionMeasure β n) :=
  (integrable_const (((Real.sqrt 2)⁻¹)^L.length * (1/2 : ℝ)^(4*n))).mono'
    (fieldIntegrand_measurable d hβ L hL n).aestronglyMeasurable
    (Eventually.of_forall (fieldIntegrand_bound d hd hβ L hL))

/-- The factorial-free coefficients have the exact geometric majorant needed
for every-coupling convergence and all later integral exchanges. -/
theorem fieldCoefficient_bound (d : ℕ) (hd : 0 < d) {β : ℝ} (hβ : 0 < β)
    (L : List (Label (2*d) β)) (hL : Even L.length) (n : ℕ) :
    ‖fieldCoefficient d hβ L n‖ ≤
      ((Real.sqrt 2)⁻¹)^L.length * (((2*d : ℕ) : ℝ)*β^2/128)^n := by
  have h := norm_integral_le_of_norm_le_const (μ := interactionMeasure β n)
    (Eventually.of_forall (fieldIntegrand_bound d hd hβ L hL (n := n)))
  rw [interactionMeasure_real_univ β hβ.le] at h
  simp only [fieldCoefficient, norm_smul, Real.norm_eq_abs,
    abs_of_nonneg (show 0 ≤ (((2*d : ℕ) : ℝ)/8)^n by positivity)]
  apply (mul_le_mul_of_nonneg_left h (by positivity)).trans_eq
  rw [pow_mul]
  have hc : (((2*d : ℕ) : ℝ)/8)*((1/2 : ℝ)^4*β^2) = ((2*d : ℕ) : ℝ)*β^2/128 := by ring
  calc
    _ = ((Real.sqrt 2)⁻¹)^L.length * ((((2*d : ℕ) : ℝ)/8)*((1/2 : ℝ)^4*β^2))^n := by
      rw [mul_pow,mul_pow]
      ring
    _ = _ := by rw [hc]

theorem fieldNumerator_norm_summable (d : ℕ) (hd : 0 < d) {β : ℝ} (hβ : 0 < β)
    (L : List (Label (2*d) β)) (hL : Even L.length) (lam : ℝ) :
    Summable (fun n => ‖ExponentialMomentSeries.term (fieldCoefficient d hβ L) lam n‖) :=
  ExponentialMomentSeries.summable_norm_term _ (((Real.sqrt 2)⁻¹)^L.length)
    (((2*d : ℕ) : ℝ)*β^2/128) (by positivity) (by positivity)
    (fieldCoefficient_bound d hd hβ L hL) lam

@[simp] theorem fieldCoefficient_empty (d : ℕ) {β : ℝ} (hβ : 0 < β) (n : ℕ) :
    fieldCoefficient d hβ [] n = ContinuumWickSeries.coefficient d β hβ [] n := by
  simp [fieldCoefficient, ContinuumWickSeries.coefficient, fieldIntegrand,
    coefficientIntegrand]

@[simp] theorem fieldNumerator_empty (d : ℕ) {β : ℝ} (hβ : 0 < β) (lam : ℝ) :
    fieldNumerator d hβ [] lam = ContinuumWickSeries.numerator d β hβ [] lam := by
  simp [fieldNumerator, numerator, ExponentialMomentSeries.value, ExponentialMomentSeries.term]

end SYK.InsertedWickSeries
