import FermionicFourier
import Mathlib.MeasureTheory.Integral.Prod

/-! Rectangular Hankel tests with actual bounded measurable integrands. -/
noncomputable section
open MeasureTheory Set
open scoped Topology
namespace SYK.Continuum

/-- Shearing a rectangle into its exact diagonal fibers, with Fubini justified
by bounded measurability on a finite rectangle. -/
theorem rectangle_shear (a : ℝ) (ha : 0 ≤ a) (F : ℝ × ℝ → ℂ)
    (hF : Measurable F) (B : ℝ) (hB : ∀ p, ‖F p‖ ≤ B) :
    (∫ t in (0 : ℝ)..a, ∫ s in (0 : ℝ)..a, F (t, s + t)) =
      ∫ r in (0 : ℝ)..(2 * a),
        ∫ t in max 0 (r - a)..min a r, F (t, r) := by
  let K : ℝ × ℝ → ℂ := {p | p.1 ≤ p.2 ∧ p.2 ≤ p.1 + a}.indicator F
  have hK : Measurable K := hF.indicator
    ((measurableSet_le measurable_fst measurable_snd).inter
      (measurableSet_le measurable_snd (measurable_fst.add_const a)))
  have hB0 : 0 ≤ B := (norm_nonneg (F (0,0))).trans (hB (0,0))
  have hKi : Integrable K ((volume.restrict (Icc 0 a)).prod
      (volume.restrict (Icc 0 (2*a)))) := by
    apply (integrable_const B).mono' hK.aestronglyMeasurable
    filter_upwards [] with p
    by_cases hp : p.1 ≤ p.2 ∧ p.2 ≤ p.1 + a
    · simpa [K, hp] using hB p
    · simpa [K, hp] using hB0
  have inner (t : ℝ) (ht : t ∈ Icc 0 a) :
      (∫ s in (0 : ℝ)..a, F (t, s + t)) =
        ∫ r in Icc 0 (2*a), K (t,r) := by
    rw [intervalIntegral.integral_comp_add_right (fun r => F (t,r)) t]
    simp only [zero_add]
    rw [intervalIntegral.integral_of_le (by linarith : t ≤ a+t),
      ← integral_Icc_eq_integral_Ioc]
    have hk : (fun r => K (t,r)) = (Icc t (a+t)).indicator (fun r => F (t,r)) := by
      ext r
      simp [K, Set.indicator, add_comm a t]
    rw [hk, setIntegral_indicator measurableSet_Icc]
    have hi : Icc 0 (2*a) ∩ Icc t (a+t) = Icc t (a+t) :=
      inter_eq_right.mpr (by intro r hr; constructor <;> linarith [ht.1, ht.2, hr.1, hr.2])
    rw [hi]
  rw [intervalIntegral.integral_of_le ha, ← integral_Icc_eq_integral_Ioc]
  calc
    _ = ∫ t in Icc 0 a, ∫ r in Icc 0 (2*a), K (t,r) := by
      apply setIntegral_congr_fun measurableSet_Icc
      exact inner
    _ = ∫ r in Icc 0 (2*a), ∫ t in Icc 0 a, K (t,r) :=
      integral_integral_swap hKi
    _ = _ := by
      rw [intervalIntegral.integral_of_le (by positivity : 0 ≤ 2*a),
        ← integral_Icc_eq_integral_Ioc]
      apply setIntegral_congr_fun measurableSet_Icc
      intro r hr
      dsimp only
      have hlow : max 0 (r-a) ≤ min a r := by
        exact max_le (le_min ha hr.1) (le_min (by linarith [hr.2]) (by linarith))
      rw [intervalIntegral.integral_of_le hlow, ← integral_Icc_eq_integral_Ioc]
      have hk : (fun t => K (t,r)) = (Icc (r-a) r).indicator (fun t => F (t,r)) := by
        ext t
        dsimp [K]
        by_cases hp : t ≤ r ∧ r ≤ t+a
        · have hq : t ∈ Icc (r-a) r := by constructor <;> linarith [hp.1,hp.2]
          simp [hp, hq]
        · have hq : t ∉ Icc (r-a) r := by
            intro hq; apply hp; constructor <;> linarith [hq.1,hq.2]
          simp [hp, hq]
      rw [hk, setIntegral_indicator measurableSet_Icc, Icc_inter_Icc]

/-- Exact diagonal primitive for a complex exponential. -/
theorem diagonal_exponential_integral (ω r l u : ℝ) (hω : ω ≠ 0) :
    (∫ t in l..u, Complex.exp (Complex.I * (ω : ℂ) * (2 * t - r))) =
      (Complex.exp (Complex.I * (ω : ℂ) * (2 * u - r)) -
       Complex.exp (Complex.I * (ω : ℂ) * (2 * l - r))) /
        (2 * Complex.I * (ω : ℂ)) := by
  have hc : (2 * Complex.I * (ω : ℂ)) ≠ 0 := by
    exact mul_ne_zero (mul_ne_zero (by norm_num) Complex.I_ne_zero)
      (Complex.ofReal_ne_zero.mpr hω)
  have he (t : ℝ) : Complex.exp (Complex.I * (ω : ℂ) * (2 * t - r)) =
      Complex.exp (-Complex.I * (ω : ℂ) * r) *
        Complex.exp ((2 * Complex.I * (ω : ℂ)) * t) := by
    rw [← Complex.exp_add]
    congr 1
    ring
  simp_rw [he]
  rw [intervalIntegral.integral_const_mul, integral_exp_mul_complex hc]
  ring

/-- The difference of conjugate phases is exactly the sine term. -/
theorem phase_difference (ω r : ℝ) (hω : ω ≠ 0) :
    (Complex.exp (Complex.I * (ω : ℂ) * r) -
      Complex.exp (-Complex.I * (ω : ℂ) * r)) /
        (2 * Complex.I * (ω : ℂ)) = (Real.sin (ω*r) / ω : ℝ) := by
  have hw : (ω : ℂ) ≠ 0 := Complex.ofReal_ne_zero.mpr hω
  have hplus : Complex.I * (ω : ℂ) * r = ((ω*r : ℝ) : ℂ) * Complex.I := by
    push_cast; ring
  have hminus : -Complex.I * (ω : ℂ) * r = -((ω*r : ℝ) : ℂ) * Complex.I := by
    push_cast; ring
  rw [hplus, hminus, Complex.exp_mul_I, Complex.exp_mul_I,
    Complex.cos_neg, Complex.sin_neg]
  push_cast
  field_simp
  <;> ring

/-- Odd-frequency phases make the two triangular fibers agree exactly. -/
theorem diagonal_fiber_integral (a ω r : ℝ) (ha : 0 ≤ a) (hω : ω ≠ 0)
    (hp : Complex.exp (Complex.I * (ω : ℂ) * (2 * a)) = -1)
    (hr : r ∈ Icc 0 (2*a)) :
    (∫ t in max 0 (r-a)..min a r,
      Complex.exp (Complex.I * (ω : ℂ) * (2 * t - r))) =
        (Real.sin (ω*r) / ω : ℝ) := by
  rw [diagonal_exponential_integral ω r _ _ hω]
  by_cases hra : r ≤ a
  · rw [max_eq_left (by linarith : r-a ≤ 0), min_eq_right hra]
    simp only [Complex.ofReal_zero]
    convert phase_difference ω r hω using 1 <;> congr 2 <;> ring
  · have har : a ≤ r := le_of_not_ge hra
    rw [max_eq_right (by linarith : 0 ≤ r-a), min_eq_left har]
    have he₁ : Complex.exp (Complex.I * (ω : ℂ) * (2 * a - r)) =
        -Complex.exp (-Complex.I * (ω : ℂ) * r) := by
      calc
        _ = Complex.exp (Complex.I * (ω : ℂ) * (2 * a)) *
            Complex.exp (-Complex.I * (ω : ℂ) * r) := by
          rw [← Complex.exp_add]; congr 1; ring
        _ = _ := by rw [hp]; ring
    have he₂ : Complex.exp (Complex.I * (ω : ℂ) * (2 * ((r-a : ℝ) : ℂ) - r)) =
        -Complex.exp (Complex.I * (ω : ℂ) * r) := by
      calc
        _ = Complex.exp (-(Complex.I * (ω : ℂ) * (2 * a))) *
            Complex.exp (Complex.I * (ω : ℂ) * r) := by
          rw [← Complex.exp_add]; congr 1; push_cast; ring
        _ = _ := by rw [Complex.exp_neg, hp]; simp
    rw [he₁, he₂]
    convert phase_difference ω r hω using 1 <;> ring

/-- The exact Hankel/Fourier test, with all changes of variables and Fubini
proved from bounded measurability. Reflection symmetry is not needed here. -/
theorem hankel_fourier_test_general (a ω : ℝ) (ha : 0 ≤ a) (hω : ω ≠ 0)
    (hp : Complex.exp (Complex.I * (ω : ℂ) * (2 * a)) = -1)
    (g : ℝ → ℝ) (hg : Measurable g) (B : ℝ) (hB : ∀ r, |g r| ≤ B) :
    (∫ t in (0 : ℝ)..a, ∫ s in (0 : ℝ)..a,
      Complex.exp (Complex.I * (ω : ℂ) * (t-s)) * (g (s+t) : ℂ)) =
      ((1 / ω * ∫ r in (0 : ℝ)..(2*a), Real.sin (ω*r) * g r : ℝ) : ℂ) := by
  let F : ℝ × ℝ → ℂ := fun p =>
    Complex.exp (Complex.I * (ω : ℂ) * (2*p.1-p.2)) * (g p.2 : ℂ)
  have hF : Measurable F := by dsimp [F]; fun_prop
  have hbound (p : ℝ × ℝ) : ‖F p‖ ≤ B := by
    simpa [F, norm_mul, Complex.norm_exp] using hB p.2
  have hs := rectangle_shear a ha F hF B hbound
  have he (t s : ℝ) : F (t,s+t) =
      Complex.exp (Complex.I * (ω : ℂ) * (t-s)) * (g (s+t) : ℂ) := by
    dsimp [F]; push_cast; congr 2; ring
  simp_rw [he] at hs
  rw [hs]
  have hi : (∫ r in (0 : ℝ)..(2*a), ∫ t in max 0 (r-a)..min a r, F (t,r)) =
      ∫ r in (0 : ℝ)..(2*a), ((1/ω * (Real.sin (ω*r) * g r) : ℝ) : ℂ) := by
    apply intervalIntegral.integral_congr
    intro r hr
    dsimp [F]
    rw [intervalIntegral.integral_mul_const,
      diagonal_fiber_integral a ω r ha hω hp (by simpa [uIcc_of_le (by positivity : 0 ≤ 2*a)] using hr)]
    push_cast; ring
  rw [hi]
  simp only [intervalIntegral, integral_complex_ofReal, ← Complex.ofReal_sub]
  congr 1
  rw [integral_const_mul, integral_const_mul]
  ring

/-- Manuscript's Eq. Fouriertest at each positive fermionic frequency. -/
theorem hankel_fourier_test (β : ℝ) (hβ : 0 < β) (n : ℕ)
    (g : ℝ → ℝ) (hg : Measurable g) (B : ℝ) (hB : ∀ r, |g r| ≤ B) :
    (∫ t in (0 : ℝ)..(β/2), ∫ s in (0 : ℝ)..(β/2),
      Complex.exp (Complex.I * (frequency β n : ℂ) * (t-s)) * (g (s+t) : ℂ)) =
      ((1 / frequency β n * ∫ r in (0 : ℝ)..β,
        Real.sin (frequency β n*r) * g r : ℝ) : ℂ) := by
  have hp : Complex.exp (Complex.I * (frequency β n : ℂ) * (2 * (β/2 : ℝ))) = -1 := by
    convert frequency_phase β hβ n using 1 <;> push_cast <;> congr 2 <;> ring
  have h := hankel_fourier_test_general (β/2) (frequency β n) (by positivity)
    (frequency_pos β hβ n).ne' hp g hg B hB
  convert h using 1 <;> congr 2 <;> ring

end SYK.Continuum
