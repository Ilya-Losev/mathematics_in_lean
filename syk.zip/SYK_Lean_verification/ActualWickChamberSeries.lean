import ActualWickChamber
import GapHistoryIntegrationAE
import FieldDisorderSeries

/-!
# Actual inserted operator series from genuine Wick time integrals

This is the sorted, tie-compatible external-word bridge. All interaction-time
partitioning, null collisions, flavor expansions and exponential coefficients
are proved from the concrete definitions.
-/
set_option maxHeartbeats 800000
noncomputable section
open scoped BigOperators
open Set MeasureTheory
namespace SYK.ActualWickChamberSeries
open DuhamelHistory DuhamelVertex WickVertexIntegrals ThermalWick
open GapAssignmentPartition GapChamberCoordinates ActualWickChamber
open OrderedSimplexIntegral OrderedCubePartition PartitionWick FieldDisorderSeries

/-- The literal external-time boundaries, with both thermal endpoints. -/
def boundaries {m : ℕ} (a : ℝ) (t : Fin m → ℝ) : Fin (m+2) → ℝ :=
  Fin.cons a (Fin.snoc t 0)

@[simp] theorem boundaries_zero {m : ℕ} (a : ℝ) (t : Fin m → ℝ) : boundaries a t 0 = a := by
  simp [boundaries]

@[simp] theorem boundaries_last {m : ℕ} (a : ℝ) (t : Fin m → ℝ) :
    boundaries a t (Fin.last (m+1)) = 0 := by
  change Fin.cons (α := fun _ => ℝ) a (Fin.snoc t 0) (Fin.last m).succ = 0
  simp only [Fin.cons_succ, Fin.snoc_last]

/-- Consecutive boundary differences are the actual recursively defined
thermal durations, including zero-width external gaps. -/
theorem boundaries_gap {m : ℕ} (a : ℝ) (t : Fin m → ℝ) (j : Fin (m+1)) :
    boundaries a t j.castSucc - boundaries a t j.succ = Interacting.gaps m a t j := by
  induction m generalizing a with
  | zero => fin_cases j; simp [boundaries, Interacting.gaps, Fin.snoc]
  | succ m ih =>
    have hsnoc : Fin.snoc t 0 = Fin.cons (α := fun _ => ℝ) (t 0) (Fin.snoc (fun i => t i.succ) 0) := by
      rw [Fin.cons_snoc_eq_snoc_cons]
      exact congrArg (fun f : Fin (m+1) → ℝ => Fin.snoc (α := fun _ => ℝ) f 0) (Fin.cons_self_tail t).symm
    refine Fin.cases ?_ (fun j => ?_) j
    · simp [boundaries, hsnoc, Interacting.gaps]
    · simpa only [boundaries, hsnoc, Fin.succ_castSucc, Fin.cons_succ, Interacting.gaps]
        using ih (t 0) (fun i => t i.succ) j

/-- Sorted actual external times yield descending genuine gap boundaries. -/
theorem boundaries_antitone {m : ℕ} {a : ℝ} (ha : 0 ≤ a) (t : Fin m → ℝ)
    (ht : Antitone t) (hb : ∀ i, 0 ≤ t i ∧ t i ≤ a) : Antitone (boundaries a t) := by
  apply Fin.antitone_iff_succ_le.mpr
  intro j
  exact sub_nonneg.mp (by rw [boundaries_gap]; exact Interacting.gaps_nonneg m ha t ht hb j)

/-- Each actual external field is placed after its gap; the final gap has
no external field. -/
def externalBlocks {α : Type*} {m : ℕ} (L : Fin m → α) : Fin (m+1) → List α :=
  Fin.snoc (fun i => [L i]) []

@[simp] theorem externalBlocks_flatten {α : Type*} {m : ℕ} (L : Fin m → α) :
    (List.ofFn (externalBlocks L)).flatten = List.ofFn L := by
  rw [List.ofFn_succ']
  simp only [externalBlocks, Fin.snoc_castSucc, Fin.snoc_last, List.concat_eq_append,
    List.flatten_append, List.flatten_cons, List.flatten_nil, List.append_nil]
  have hm := List.map_ofFn (f := L) (g := fun p => [p])
  simp only [Function.comp_def] at hm
  rw [← hm]
  exact List.flatMap_singleton' _

/-- The fixed labels occur at their exact lower gap endpoints. -/
theorem externalBlocks_time (d : ℕ) {β : ℝ} {m : ℕ}
    (L : Fin m → Label (2*d) β) (a : ℝ) (j : Fin (m+1))
    (p : Label (2*d) β) (hp : p ∈ externalBlocks L j) :
    p.2.val = boundaries a (fun i => (L i).2.val) j.succ := by
  revert hp
  refine Fin.lastCases ?_ (fun i => ?_) j
  · simp [externalBlocks]
  · simp only [externalBlocks, Fin.snoc_castSucc, List.mem_singleton]
    intro h
    subst p
    simp [boundaries]

/-- The operator word of each external block is precisely the original
external matrix, or the identity after the last gap. -/
theorem externalBlocks_word {α A : Type*} [Ring A] {m : ℕ} (L : Fin m → α) (x : α → A) :
    (fun j => FreeWick.word x (externalBlocks L j)) = Fin.snoc (fun i => x (L i)) 1 := by
  funext j
  refine Fin.lastCases ?_ (fun i => ?_) j <;> simp [externalBlocks]

/-- The requested literal chamber value for any sorted even external tuple,
with every tied external flavor block kept in its original order. -/
theorem weightedVertexIntegrand_sorted_chamber (d : ℕ) {β : ℝ} (hβ : 0 < β) {m n : ℕ}
    (L : Fin m → Label (2*d) β) (heven : Even m)
    (horder : Antitone (fun i => (L i).2.val))
    (htie : (List.ofFn L).Pairwise (fun p q => q.2.val < p.2.val ∨ p.1 ≠ q.1))
    (g : Fin n → Fin (m+1)) (j : Majorana.FourSet d → ℝ) (u : Fin n → ℝ)
    (hu : u ∈ orderedAssignmentRegion (boundaries β (fun i => (L i).2.val)) g)
    (hi : Function.Injective u) :
    weightedVertexIntegrand d hβ (List.ofFn L) j n u =
      Majorana.normalizedTrace d (orderedProduct (fun a => (-Majorana.hamiltonian d j)^(gapCount g a) *
        Fin.snoc (α := fun _ => Matrix (Majorana.Basis d) (Majorana.Basis d) ℂ)
          (fun i => Majorana.chiFin d (L i).1) 1 a)) := by
  have ht := boundaries_antitone hβ.le (fun i => (L i).2.val) horder
    (fun i => ⟨(L i).2.property.1, (L i).2.property.2.le⟩)
  have hh := weightedVertexIntegrand_chamber d hβ (boundaries β (fun i => (L i).2.val)) ht
    (boundaries_zero _ _) (boundaries_last _ _) (externalBlocks L)
    (externalBlocks_time d L β) (by simpa only [externalBlocks_flatten] using htie)
    (by simpa only [externalBlocks_flatten, List.length_ofFn] using heven) g j u hu hi
  have hw (a : Fin (m+1)) := congrFun (externalBlocks_word L
    (fun p : Label (2*d) β => Majorana.chiFin d p.1)) a
  simpa only [externalBlocks_flatten, hw] using hh

/-- Cube symmetrization supplies exactly the factorial in each genuine
inserted exterior coefficient, with all collision conventions preserved. -/
theorem disorderCoefficient_eq_ordered_integral (d : ℕ) {β : ℝ} (hβ : 0 < β)
    (L : List (Label (2*d) β)) (heven : Even L.length)
    (j : Majorana.FourSet d → ℝ) (n : ℕ) :
    disorderCoefficient d hβ L j n =
      ∫ u in orderedSimplex n 0 β, weightedVertexIntegrand d hβ L j n u := by
  rw [disorderCoefficient, functional_power_eq_integral d hβ L heven j n,
    integral_cube_eq_factorial_smul_ordered 0 β _
      (weightedVertexIntegrand_integrable d hβ L heven j n)
      (weightedVertexIntegrand_symmetric d hβ L j n), nsmul_eq_mul,
    ← mul_assoc, inv_mul_cancel₀ (by exact_mod_cast n.factorial_ne_zero), one_mul]

/-- The real simplex-volume coefficient is literally the actual matrix
exponential gap coefficient after applying the normalized trace. -/
theorem weighted_trace_eq_gapCoefficient (d : ℕ) {k : ℕ}
    (t : Fin (k+1) → ℝ) (ht : Antitone t)
    (H : Matrix (Majorana.Basis d) (Majorana.Basis d) ℂ)
    (U : Fin k → Matrix (Majorana.Basis d) (Majorana.Basis d) ℂ) (r : Fin k → ℕ) :
    (∏ a, (t a.castSucc-t a.succ)^(r a)/(r a).factorial) •
        Majorana.normalizedTrace d (orderedProduct (fun a => (-H)^(r a) * U a)) =
      gapCoefficient d H (fun a => t a.castSucc-t a.succ) U r := by
  have hab (a : Fin k) : t a.succ ≤ t a.castSucc := ht (by simp [Fin.le_iff_val_le_val])
  rw [gapCoefficient_eq_integral d H r (fun a => t a.succ) (fun a => t a.castSucc) hab U]
  exact (GapSimplexIntegral.integral_gapSimplex_const r (fun a => t a.succ)
    (fun a => t a.castSucc) hab _).symm

/-- The actual sorted interacting transfer product is the sum of the actual
inserted exterior time-integral coefficients. No Duhamel or Ward identity is
assumed. The fixed external tuple may contain distinct-flavor equal times. -/
theorem hasSum_sorted_disorderCoefficient (d : ℕ) {β : ℝ} (hβ : 0 < β) {m : ℕ}
    (L : Fin m → Label (2*d) β) (heven : Even m)
    (horder : Antitone (fun i => (L i).2.val))
    (htie : (List.ofFn L).Pairwise (fun p q => q.2.val < p.2.val ∨ p.1 ≠ q.1))
    (j : Majorana.FourSet d → ℝ) :
    HasSum (disorderCoefficient d hβ (List.ofFn L) j)
      (Majorana.normalizedTrace d (Interacting.timeProduct (Majorana.hamiltonian d j) β
        (fun i => (L i).2.val) (fun i => Majorana.chiFin d (L i).1))) := by
  let t := boundaries β (fun i => (L i).2.val)
  let U : Fin (m+1) → Matrix (Majorana.Basis d) (Majorana.Basis d) ℂ :=
    Fin.snoc (fun i => Majorana.chiFin d (L i).1) 1
  have ht : Antitone t := boundaries_antitone hβ.le (fun i => (L i).2.val) horder
    (fun i => ⟨(L i).2.property.1, (L i).2.property.2.le⟩)
  have hseries := hasSum_gapCoefficient d (Majorana.hamiltonian d j)
    (fun a => t a.castSucc-t a.succ) U
  have hseries' : HasSum (fun r : Fin (m+1) → ℕ =>
      (∏ a, (t a.castSucc-t a.succ)^(r a)/(r a).factorial) •
        Majorana.normalizedTrace d (orderedProduct (fun a => (-Majorana.hamiltonian d j)^(r a)*U a)))
      (Majorana.normalizedTrace d (Interacting.timeProduct (Majorana.hamiltonian d j) β
        (fun i => (L i).2.val) (fun i => Majorana.chiFin d (L i).1))) := by
    have hh := hseries.congr_fun (fun r => weighted_trace_eq_gapCoefficient d t ht _ U r)
    simpa only [t, boundaries_gap, Interacting.timeProduct_eq_gaps, U] using hh
  have hh := GapHistoryIntegrationAE.hasSum_ordered_integrals_of_gap_series t ht
    (fun n => weightedVertexIntegrand d hβ (List.ofFn L) j n)
    (fun r => Majorana.normalizedTrace d
      (orderedProduct (fun a => (-Majorana.hamiltonian d j)^(r a)*U a))) _
    (fun n g _ u hu hi => weightedVertexIntegrand_sorted_chamber d hβ L heven horder htie g j u hu hi)
    hseries'
  apply hh.congr_fun
  intro n
  simpa only [t, boundaries_last, boundaries_zero] using
    disorderCoefficient_eq_ordered_integral d hβ (List.ofFn L)
      (by simpa only [List.length_ofFn] using heven) j n

end SYK.ActualWickChamberSeries
