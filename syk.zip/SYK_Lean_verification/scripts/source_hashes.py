#!/usr/bin/env python3
"""Record checksums of deliverable sources, configuration and checking tools."""
import hashlib
import json
from pathlib import Path
root = Path(__file__).resolve().parents[1]
paths = sorted(list(root.glob('*.lean')) + list(root.glob('*.md')) +
               [root/'lean-toolchain', root/'lakefile.toml', root/'lake-manifest.json'] +
               list((root/'reference').glob('*')) + list((root/'scripts').glob('*.py')) + list((root/'scripts').glob('*.sh')))
result = {str(p.relative_to(root)): hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
(root/'source-hashes.json').write_text(json.dumps(result, indent=2) + '\n')
for p, digest in result.items():
    print(digest, p)
