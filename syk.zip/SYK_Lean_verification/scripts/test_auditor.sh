#!/usr/bin/env bash
# Fast positive and negative controls for the exact all-declarations auditor.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
python3 - "$ROOT/AuditAll.lean" "$TMP" <<'PY'
from pathlib import Path
import re, sys
source = Path(sys.argv[1]).read_text()
source = source.replace('import SYKLean', 'import AuditFixture')
source, n = re.subn(r'let projectModules : Array Name := #\[.*?\]',
                    'let projectModules : Array Name := #[`AuditFixture]',
                    source, count=1, flags=re.S)
if n != 1:
    raise SystemExit('Cannot locate audit module list for control fixture')
root = Path(sys.argv[2])
(root/'AuditControl.lean').write_text(source)
(root/'AuditFixture.lean').write_text('namespace AuditFixture\ntheorem valid : True := True.intro\nend AuditFixture\n')
(root/'MissingModuleControl.lean').write_text(source.replace(
    '#[`AuditFixture]', '#[`AuditFixture, `IntentionallyMissingModule]'))
PY
cd "$TMP"
lean -o AuditFixture.olean AuditFixture.lean
LEAN_PATH="$TMP" lean --trust=0 AuditControl.lean > positive.log
if ! grep -q 'AUDIT PASSED' positive.log; then cat positive.log; exit 1; fi
if LEAN_PATH="$TMP" lean --trust=0 MissingModuleControl.lean > missing.log 2>&1; then
  echo 'ERROR: audit accepted a missing expected module'; exit 1
fi
grep -q 'Missing project module IntentionallyMissingModule' missing.log
printf '\naxiom AuditFixture.injected : False\n' >> AuditFixture.lean
lean -o AuditFixture.olean AuditFixture.lean
if LEAN_PATH="$TMP" lean --trust=0 AuditControl.lean > negative.log 2>&1; then
  echo 'ERROR: audit accepted an injected axiom'; exit 1
fi
grep -q 'Forbidden axiom AuditFixture.injected' negative.log
echo 'AUDITOR CONTROLS PASSED: genuine proof accepted; injected axiom and missing module rejected.'
