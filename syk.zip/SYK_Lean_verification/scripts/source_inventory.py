#!/usr/bin/env python3
"""Check aggregate coverage, source placeholders, and manifest revisions."""
from pathlib import Path
import json
import hashlib
import re
import subprocess

root = Path(__file__).resolve().parents[1]


def without_comments_and_strings(text):
    out = []
    i = depth = 0
    in_string = False
    while i < len(text):
        if depth:
            if text.startswith('/-', i):
                depth += 1; i += 2
            elif text.startswith('-/', i):
                depth -= 1; i += 2
            else:
                if text[i] == '\n': out.append('\n')
                i += 1
        elif in_string:
            if text[i] == '\\': i += 2
            elif text[i] == '"': in_string = False; i += 1; out.append(' ')
            else: i += 1
        elif text.startswith('/-', i): depth = 1; i += 2; out.append(' ')
        elif text.startswith('--', i):
            e = text.find('\n', i)
            i = len(text) if e < 0 else e
        elif text[i] == '"': in_string = True; i += 1; out.append(' ')
        else: out.append(text[i]); i += 1
    if depth or in_string:
        raise SystemExit('Unterminated source comment/string')
    return ''.join(out)

excluded = {'AxiomAudit', 'AuditAll', 'TheoremStatements'}
sources = {p.stem: p for p in root.glob('*.lean') if p.stem not in excluded}
source_text = {m: without_comments_and_strings(p.read_text()) for m, p in sources.items()}
visited = set()
def visit(module):
    if module in visited: return
    visited.add(module)
    for dep in re.findall(r'^import\s+(\S+)', source_text[module], re.M):
        if dep in sources: visit(dep)
visit('SYKLean')
uncovered = set(sources) - visited
if uncovered:
    raise SystemExit('Project sources missing from SYKLean aggregate: ' + ', '.join(sorted(uncovered)))
audit = (root / 'AuditAll.lean').read_text()
listed = re.search(r'let projectModules.*?:= #\[(.*?)\]', audit, re.S)
if listed is None:
    raise SystemExit('Cannot find projectModules audit allowlist')
audited_modules = set(re.findall(r'`(\w+)', listed.group(1)))
if set(sources) - audited_modules:
    raise SystemExit('Source modules missing from axiom audit: ' + ', '.join(sorted(set(sources) - audited_modules)))
for module, text in source_text.items():
    if re.search(r'\b(?:sorry|admit|axiom|native_decide|unsafe|partial)\b', text):
        raise SystemExit(f'Forbidden proof placeholder/postulate/native_decide in {module}')
    print(f"SOURCE {module}: aggregate coverage and placeholder scan passed")

expected_manifest = "9353e45847b035ecf41d0084c7847e2a35f623ed91b10e7556eece76486131b6"
manifest_path = root / 'lake-manifest.json'
if hashlib.sha256(manifest_path.read_bytes()).hexdigest() != expected_manifest:
    raise SystemExit('Pinned dependency manifest hash mismatch')
manifest = json.loads(manifest_path.read_text())
for package in manifest['packages']:
    path = root / manifest['packagesDir'] / package['name']
    actual = subprocess.check_output(['git', '-C', str(path), 'rev-parse', 'HEAD'], text=True).strip()
    if actual != package['rev']:
        raise SystemExit(f'Dependency revision mismatch: {package["name"]}: {actual}')
    changes = subprocess.check_output(['git', '-C', str(path), 'diff', 'HEAD', '--name-only'], text=True).strip()
    if changes:
        raise SystemExit(f'Modified dependency sources: {package["name"]}: {changes}')
    untracked = subprocess.check_output(['git', '-C', str(path), 'ls-files',
        '--others', '--exclude-standard', '--', '*.lean'], text=True).strip()
    if untracked:
        raise SystemExit(f'Untracked dependency proof sources: {package["name"]}: {untracked}')
    print(f'DEPENDENCY {package["name"]}: {actual}')
print('SOURCE INVENTORY PASSED')

expected_manuscript = "c214e369a8d2ae97dc1fcbd4bc4b759119ced8ee92ae5598b4c5fb7135449562"
actual_manuscript = hashlib.sha256((root / "reference/SYK_continuum_free_energy.tex").read_bytes()).hexdigest()
if actual_manuscript != expected_manuscript:
    raise SystemExit("Input manuscript hash mismatch")
print("MANUSCRIPT HASH PASSED:", actual_manuscript)
