#!/usr/bin/env bash
# Run from any directory after installing the pinned official Lean toolchain.
# Does not alter Lean, mathlib, the kernel, or trust configuration.
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p logs
LOG="logs/verification-$(date -u +%Y%m%dT%H%M%SZ).txt"
# Keep the logger alive until every final status line is durably written.
exec 3>&1 4>&2
exec > >(tee "$LOG") 2>&1
LOGGER_PID=$!
finish() {
  status=$?
  trap - EXIT
  printf '\nCHECK EXIT CODE: %s\n' "$status"
  exec 1>&3 2>&4
  wait "$LOGGER_PID" || true
  exit "$status"
}
trap finish EXIT
printf 'Verification started: '; date -u '+%Y-%m-%dT%H:%M:%SZ'
printf '\nCOMMAND: lean --version\n'
LEAN_VERSION="$(lean --version)"
printf '%s\n' "$LEAN_VERSION"
case "$LEAN_VERSION" in
  "Lean (version 4.19.0,"*) ;;
  *) echo 'ERROR: this verification requires official Lean 4.19.0'; exit 1 ;;
esac
printf '\nPinned toolchain:\n'; cat lean-toolchain
printf '\nCOMMAND: ./scripts/test_auditor.sh\n'; ./scripts/test_auditor.sh
printf "\nCOMMAND: python3 scripts/source_inventory.py\n"; python3 scripts/source_inventory.py
printf '\nCOMMAND: lake clean syk_free_energy_check\n'; lake clean syk_free_energy_check
printf '\nCOMMAND: lake build\n'; lake build
printf '\nCOMMAND: lake env lean --trust=0 AxiomAudit.lean\n'
lake env lean --trust=0 AxiomAudit.lean
printf '\nCOMMAND: lake env lean --trust=0 AuditAll.lean\n'
lake env lean --trust=0 AuditAll.lean
printf '\nCOMMAND: lake env lean TheoremStatements.lean\n'
lake env lean TheoremStatements.lean
printf '\nSOURCE HASHES\n'
python3 scripts/source_hashes.py
printf '\nAll checks exited successfully.\n'
printf 'This checks the statements actually present, including their hypotheses.\n'
printf 'See the printed unconditional theorem type and manuscript scope audit for the exact result.\n'
