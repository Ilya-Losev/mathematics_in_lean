import WeylBlockFactorization

/-!
# Adjoint reflection of the full thermal Weyl average

The time reflection and reversal of the operator order are explicit. The
result does not require parity-dependent phases and retains internal Weyl ties.
-/

noncomputable section
open scoped BigOperators ComplexOrder
open Set
namespace SYK.WeylReflection
open Interacting WeylBlocks

/-- Reflect a thermal insertion word in a segment of length a, reversing
its order and taking the adjoint of every insertion. -/
def reflectedWord {ν : Type*} (a : ℝ) (L : List (ℝ × Matrix ν ν ℂ)) :
    List (ℝ × Matrix ν ν ℂ) := L.reverse.map (fun p => (a-p.1, star p.2))

section Transfer
variable {ν : Type*} [Fintype ν] [DecidableEq ν]

/-- Exact adjoint reflection of an arbitrary thermal transfer product. -/
theorem transfer_reflected {H : Matrix ν ν ℂ} (hH : H.IsHermitian)
    (a : ℝ) (L : List (ℝ × Matrix ν ν ℂ)) :
    ThermalRP.evaluate H (ThermalRP.halfFactors a (reflectedWord a L)) =
      star (ThermalRP.evaluate H (ThermalRP.halfFactors a L)) := by
  induction L generalizing a with
  | nil => simpa only [reflectedWord, List.reverse_nil, List.map_nil,
      ThermalRP.evaluate_halfFactors_nil] using (ThermalRP.heat_star hH a).symm
  | cons v L ih =>
    rcases v with ⟨t,A⟩
    simp only [reflectedWord, List.reverse_cons, List.map_append, List.map_cons, List.map_nil]
    rw [transfer_append H a (a-t)]
    have hm : (List.map (fun p : ℝ × Matrix ν ν ℂ => (p.1-(a-t),p.2))
        (L.reverse.map (fun p => (a-p.1,star p.2)))) = reflectedWord t L := by
      simp only [List.map_map, reflectedWord, Function.comp_def]
      congr 1
      funext p
      congr 1
      ring
    rw [hm, sub_sub_cancel, ih]
    simp only [ThermalRP.evaluate_halfFactors_cons, ThermalRP.evaluate_halfFactors_nil,
      sub_self, show Gibbs.weight 0 H = 1 by simp [Gibbs.weight], one_mul]
    rw [star_mul, star_mul, ThermalRP.heat_star hH]
    simp only [mul_assoc]

/-- Reversing a finite tuple reverses its list of entries. -/
theorem ofFn_rev {α : Type*} {k : ℕ} (f : Fin k → α) :
    List.ofFn (fun i => f i.rev) = (List.ofFn f).reverse := by
  apply List.ext_getElem (by simp)
  intro i hi hj
  simp only [List.getElem_ofFn, List.getElem_reverse, List.length_ofFn]
  congr 1
  apply Fin.ext
  simp [Fin.rev, Nat.sub_sub, Nat.add_comm]

/-- Tuple form of exact adjoint time reflection. -/
theorem timeProduct_reflected {H : Matrix ν ν ℂ} (hH : H.IsHermitian)
    (a : ℝ) {k : ℕ} (t : Fin k → ℝ) (A : Fin k → Matrix ν ν ℂ) :
    timeProduct H a (fun i => a-t i.rev) (fun i => star (A i.rev)) =
      star (timeProduct H a t A) := by
  unfold timeProduct
  have hp : List.ofFn (fun i => (a-t i.rev,star (A i.rev))) =
      reflectedWord a (List.ofFn (fun i => (t i,A i))) := by
    calc
      _ = (List.ofFn (fun i : Fin k => (t i.rev,A i.rev))).map
          (fun p : ℝ × Matrix ν ν ℂ => (a-p.1,star p.2)) := by
            rw [List.map_ofFn]
            rfl
      _ = _ := by
        change (List.ofFn ((fun i : Fin k => (t i,A i)) ∘ Fin.rev)).map _ = _
        rw [show List.ofFn ((fun i : Fin k => (t i,A i)) ∘ Fin.rev) =
          (List.ofFn (fun i => (t i,A i))).reverse from ofFn_rev (fun i : Fin k => (t i,A i))]
        rfl
  rw [hp]
  exact transfer_reflected hH a _

end Transfer

/-- Conjugating an occurrence permutation by the order reversal. -/
def reversedPerm {k : ℕ} (σ : Equiv.Perm (Fin k)) : Equiv.Perm (Fin k) :=
  Fin.revPerm.permCongr σ

@[simp] theorem reversedPerm_apply {k : ℕ} (σ : Equiv.Perm (Fin k)) (i : Fin k) :
    reversedPerm σ i = (σ i.rev).rev := by
  simp [reversedPerm, Equiv.permCongr_apply, Equiv.Perm.inv_def]

@[simp] theorem reversedPerm_reversedPerm {k : ℕ} (σ : Equiv.Perm (Fin k)) :
    reversedPerm (reversedPerm σ) = σ := by
  apply Equiv.ext
  intro i
  simp

@[simp] theorem reversedPerm_sign {k : ℕ} (σ : Equiv.Perm (Fin k)) :
    Equiv.Perm.sign (reversedPerm σ) = Equiv.Perm.sign σ := by
  exact Equiv.Perm.sign_permCongr Fin.revPerm σ

theorem reversedPerm_injective {k : ℕ} : Function.Injective (@reversedPerm k) := by
  intro σ τ h
  simpa only [reversedPerm_reversedPerm] using congrArg reversedPerm h

/-- Time reflection reverses the ordering inequality a second time, so the
admitted sorting permutations are related by conjugation with reversal. -/
theorem reversedPerm_sorting_iff {k : ℕ} (t : Fin k → ℝ) (a : ℝ)
    (σ : Equiv.Perm (Fin k)) :
    Antitone ((fun i => a-t i.rev) ∘ reversedPerm σ) ↔ Antitone (t ∘ σ) := by
  simp only [Function.comp_def, reversedPerm_apply, Fin.rev_rev]
  constructor
  · intro h i j hij
    have hh := h (Fin.rev_le_rev.mpr hij)
    simpa only [Fin.rev_rev, sub_le_sub_iff_left] using hh
  · intro h i j hij
    exact sub_le_sub_left (h (Fin.rev_le_rev.mpr hij)) a

/-- Exact reflected sorting set, including every internal tie permutation. -/
theorem sortingPerms_reflected {k : ℕ} (t : Fin k → ℝ) (a : ℝ) :
    sortingPerms (fun i => a-t i.rev) = (sortingPerms t).image reversedPerm := by
  classical
  ext σ
  constructor
  · intro hσ
    refine Finset.mem_image.mpr ⟨reversedPerm σ, ?_, by simp⟩
    apply (mem_sortingPerms _ _).mpr
    apply (reversedPerm_sorting_iff t a (reversedPerm σ)).mp
    simpa only [reversedPerm_reversedPerm] using (mem_sortingPerms _ _).mp hσ
  · rintro hσ
    obtain ⟨τ, hτ, rfl⟩ := Finset.mem_image.mp hσ
    apply (mem_sortingPerms _ _).mpr
    exact (reversedPerm_sorting_iff t a τ).mpr ((mem_sortingPerms _ _).mp hτ)

section Weyl
variable {ν : Type*} [Fintype ν] [DecidableEq ν]

/-- The complete matrix-valued Weyl average is taken to its actual matrix
adjoint by reflected times and reversed adjoint insertions, in every parity. -/
theorem weylTransfer_reflected {H : Matrix ν ν ℂ} (hH : H.IsHermitian)
    (a : ℝ) {k : ℕ} (t : Fin k → ℝ) (A : Fin k → Matrix ν ν ℂ) :
    weylTransfer H a (fun i => a-t i.rev) (fun i => star (A i.rev)) =
      star (weylTransfer H a t A) := by
  classical
  have hcard : (sortingPerms (fun i => a-t i.rev)).card = (sortingPerms t).card := by
    rw [sortingPerms_reflected, Finset.card_image_of_injective _ reversedPerm_injective]
  unfold weylTransfer
  rw [hcard, sortingPerms_reflected,
    Finset.sum_image (fun _ _ _ _ h => reversedPerm_injective h), star_inv_natCast_smul, star_sum]
  congr 1
  apply Finset.sum_congr rfl
  intro σ hσ
  rw [reversedPerm_sign]
  have ht : ((fun i => a-t i.rev) ∘ reversedPerm σ) =
      (fun i => a-(t ∘ σ) i.rev) := by funext i; simp
  have hA : ((fun i => star (A i.rev)) ∘ reversedPerm σ) =
      (fun i => star ((A ∘ σ) i.rev)) := by funext i; simp
  rw [ht, hA, timeProduct_reflected hH]
  rcases Int.units_eq_one_or (Equiv.Perm.sign σ) with hs | hs <;> simp [hs]

/-- Reflected upper-half and ordinary lower-half Weyl blocks give the exact
star-product, with internal coincidences already antisymmetrized. -/
theorem weylTransfer_reflected_pair {H : Matrix ν ν ℂ} (hH : H.IsHermitian)
    (a : ℝ) {k l : ℕ} (t : Fin k → ℝ) (u : Fin l → ℝ)
    (ht : ∀ i, t i < a) (hu : ∀ j, u j < a)
    (A : Fin k → Matrix ν ν ℂ) (B : Fin l → Matrix ν ν ℂ) :
    weylTransfer H (2*a) (Fin.append (fun i => 2*a-t i.rev) u)
      (Fin.append (fun i => star (A i.rev)) B) =
      star (weylTransfer H a t A) * weylTransfer H a u B := by
  have hsep (i : Fin k) (j : Fin l) : u j < 2*a-t i.rev := by
    have ht' := ht i.rev
    have hu' := hu j
    linarith
  rw [weylTransfer_append H (2*a) a _ _ hsep]
  have ht_eq : (fun i : Fin k => 2*a-t i.rev-a) = (fun i => a-t i.rev) := by
    funext i
    ring
  rw [show 2*a-a = a by ring, ht_eq, weylTransfer_reflected hH]

/-- A finite polynomial in Weyl words is represented by a concrete matrix
amplitude, allowing different word lengths in different terms. -/
def weylAmplitude {ι : Type*} [Fintype ι] (H : Matrix ν ν ℂ) (a : ℝ)
    (k : ι → ℕ) (c : ι → ℂ) (t : ∀ i, Fin (k i) → ℝ)
    (A : ∀ i, Fin (k i) → Matrix ν ν ℂ) : Matrix ν ν ℂ :=
  ∑ i, c i • weylTransfer H a (t i) (A i)

/-- The original signed, tie-averaged thermal double sum is exactly one
Hilbert--Schmidt square. All word lengths, including odd lengths, are allowed. -/
theorem weyl_sum_reflected_eq_star_mul {ι : Type*} [Fintype ι]
    {H : Matrix ν ν ℂ} (hH : H.IsHermitian) (a : ℝ)
    (k : ι → ℕ) (c : ι → ℂ) (t : ∀ i, Fin (k i) → ℝ)
    (ht : ∀ i j, t i j < a) (A : ∀ i, Fin (k i) → Matrix ν ν ℂ) :
    (∑ i, ∑ j, (star (c i) * c j) •
      weylTransfer H (2*a) (Fin.append (fun r => 2*a-t i r.rev) (t j))
        (Fin.append (fun r => star (A i r.rev)) (A j))) =
      star (weylAmplitude H a k c t A) * weylAmplitude H a k c t A := by
  simp only [weylTransfer_reflected_pair hH a _ _ (ht _) (ht _), weylAmplitude,
    star_sum, star_smul, Finset.sum_mul, Finset.mul_sum, smul_mul_assoc,
    mul_smul_comm, smul_smul, Finset.smul_sum]
  rw [Finset.sum_comm]
  simp only [mul_comm]

/-- Scalar version directly in terms of the already constructed microscopic
Weyl numerator, rather than an assumed reflection-positive functional. -/
theorem weyl_numerator_reflected_eq_trace {ι : Type*} [Fintype ι]
    {H : Matrix ν ν ℂ} (hH : H.IsHermitian) (a : ℝ)
    (k : ι → ℕ) (c : ι → ℂ) (t : ∀ i, Fin (k i) → ℝ)
    (ht : ∀ i j, t i j < a) (A : ∀ i, Fin (k i) → Matrix ν ν ℂ) :
    (∑ i, ∑ j, (star (c i) * c j) *
      weylNumerator H (2*a) (Fin.append (fun r => 2*a-t i r.rev) (t j))
        (Fin.append (fun r => star (A i r.rev)) (A j))) =
      Matrix.trace (star (weylAmplitude H a k c t A) * weylAmplitude H a k c t A) := by
  rw [← weyl_sum_reflected_eq_star_mul hH a k c t ht A]
  simp only [Matrix.trace_sum, Matrix.trace_smul, trace_weylTransfer, smul_eq_mul]

/-- The actual finite Weyl reflection form is nonnegative. -/
theorem weyl_numerator_reflected_nonnegative {ι : Type*} [Fintype ι]
    {H : Matrix ν ν ℂ} (hH : H.IsHermitian) (a : ℝ)
    (k : ι → ℕ) (c : ι → ℂ) (t : ∀ i, Fin (k i) → ℝ)
    (ht : ∀ i j, t i j < a) (A : ∀ i, Fin (k i) → Matrix ν ν ℂ) :
    0 ≤ (∑ i, ∑ j, (star (c i) * c j) *
      weylNumerator H (2*a) (Fin.append (fun r => 2*a-t i r.rev) (t j))
        (Fin.append (fun r => star (A i r.rev)) (A j))).re := by
  rw [weyl_numerator_reflected_eq_trace hH a k c t ht A]
  exact AntiCommuting.trace_re_nonneg (Matrix.posSemidef_conjTranspose_mul_self _)

/-- The actual finite Weyl reflection form is real. -/
theorem weyl_numerator_reflected_im_zero {ι : Type*} [Fintype ι]
    {H : Matrix ν ν ℂ} (hH : H.IsHermitian) (a : ℝ)
    (k : ι → ℕ) (c : ι → ℂ) (t : ∀ i, Fin (k i) → ℝ)
    (ht : ∀ i j, t i j < a) (A : ∀ i, Fin (k i) → Matrix ν ν ℂ) :
    (∑ i, ∑ j, (star (c i) * c j) *
      weylNumerator H (2*a) (Fin.append (fun r => 2*a-t i r.rev) (t j))
        (Fin.append (fun r => star (A i r.rev)) (A j))).im = 0 := by
  rw [weyl_numerator_reflected_eq_trace hH a k c t ht A]
  exact Gibbs.trace_im_eq_zero (Matrix.posSemidef_conjTranspose_mul_self _).isHermitian

end Weyl
end SYK.WeylReflection
