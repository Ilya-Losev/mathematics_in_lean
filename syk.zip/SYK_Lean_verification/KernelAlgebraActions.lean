import WeightedKernelAlgebra
import Mathlib.Algebra.MvPolynomial.Rename
import Mathlib.Algebra.MvPolynomial.Equiv
import Mathlib.Topology.Algebra.UniformRing
import Mathlib.RingTheory.Ideal.Quotient.Operations

/-!
# Isometric endpoint symmetries of the weighted kernel algebra

Translations act linearly. Reflection conjugates coefficients and reverses
the endpoints; it reverses translation time rather than commuting with it.
-/

noncomputable section

namespace SYK.KernelAlgebraActions
open SYK.WeightedKernelAlgebra UniformSpace
open scoped BigOperators

/-- Simultaneous real endpoint translation, retaining every real index. -/
def translateEndpoint (u : ℝ) : Endpoint ≃ Endpoint where
  toFun p := (p.1 + u, p.2 + u)
  invFun p := (p.1 - u, p.2 - u)
  left_inv p := by ext <;> dsimp <;> ring
  right_inv p := by ext <;> dsimp <;> ring

/-- The reflection dictated by reversal of the two odd fields. -/
def reflectEndpoint (β : ℝ) : Endpoint ≃ Endpoint where
  toFun p := (β - p.2, β - p.1)
  invFun p := (β - p.2, β - p.1)
  left_inv p := by ext <;> dsimp <;> ring
  right_inv p := by ext <;> dsimp <;> ring

@[simp] theorem endpointDistance_translate (u : ℝ) (p q : Endpoint) :
    endpointDistance (translateEndpoint u p) (translateEndpoint u q) = endpointDistance p q := by
  simp [endpointDistance, translateEndpoint]

@[simp] theorem endpointDistance_reflect (β : ℝ) (p q : Endpoint) :
    endpointDistance (reflectEndpoint β p) (reflectEndpoint β q) = endpointDistance p q := by
  change |(β-p.2)-(β-q.2)| + |(β-p.1)-(β-q.1)| = _
  rw [show (β-p.2)-(β-q.2) = -(p.2-q.2) by ring,
    show (β-p.1)-(β-q.1) = -(p.1-q.1) by ring, abs_neg, abs_neg]
  exact add_comm _ _

@[simp] theorem reflect_translate_endpoint (β u : ℝ) (p : Endpoint) :
    reflectEndpoint β (translateEndpoint u p) =
      translateEndpoint (-u) (reflectEndpoint β p) := by ext <;> dsimp [reflectEndpoint, translateEndpoint] <;> ring

/-- Every endpoint bijection transports distinct-endpoint increment indices. -/
def incrementEquiv (e : Endpoint ≃ Endpoint) : IncrementIndex ≃ IncrementIndex where
  toFun pq := ⟨(e pq.val.1, e pq.val.2), e.injective.ne pq.property⟩
  invFun pq := ⟨(e.symm pq.val.1, e.symm pq.val.2), e.symm.injective.ne pq.property⟩
  left_inv pq := by apply Subtype.ext; ext <;> simp
  right_inv pq := by apply Subtype.ext; ext <;> simp

/-- The induced permutation of both sorts of formal generators. -/
def kernelIndexEquiv (e : Endpoint ≃ Endpoint) : KernelIndex ≃ KernelIndex :=
  Equiv.sumCongr e (incrementEquiv e)

theorem kernelWeights_preserved (b K : ℝ) (hb : 0 < b) (hK : 0 < K)
    (e : Endpoint ≃ Endpoint)
    (he : ∀ p q, endpointDistance (e p) (e q) = endpointDistance p q) (i : KernelIndex) :
    (kernelWeights b K hb hK).value (kernelIndexEquiv e i) = (kernelWeights b K hb hK).value i := by
  cases i with
  | inl p => rfl
  | inr pq => exact congrArg (K * ·) (he pq.val.1 pq.val.2)

section WeightedPermutations
variable {ι : Type*} (w : Weights ι) (e : ι ≃ ι) (he : ∀ i, w.value (e i) = w.value i)
include he

theorem monomialWeight_mapDomain (d : ι →₀ ℕ) :
    monomialWeight w.value (Finsupp.mapDomain e d) = monomialWeight w.value d := by
  unfold monomialWeight
  rw [Finsupp.prod_mapDomain_index (fun _ => pow_zero _) (fun _ _ _ => pow_add _ _ _)]
  simp only [he]

/-- Weight-preserving permutations contract the actual coefficient norm. -/
theorem coefficientNorm_rename_le (p : MvPolynomial ι ℂ) :
    coefficientNorm w.value (MvPolynomial.rename e p) ≤ coefficientNorm w.value p := by
  classical
  letI : NormedAddCommGroup (MvPolynomial ι ℂ) :=
    (coefficientAddNorm w.value w.positive).toNormedAddCommGroup
  change ‖MvPolynomial.rename e p‖ ≤ coefficientNorm w.value p
  conv_lhs => rw [p.as_sum]
  rw [map_sum]
  calc
    _ ≤ ∑ d ∈ p.support, ‖MvPolynomial.rename e (MvPolynomial.monomial d (MvPolynomial.coeff d p))‖ := norm_sum_le _ _
    _ = coefficientNorm w.value p := by
      apply Finset.sum_congr rfl
      intro d hd
      change coefficientNorm w.value _ = _
      rw [MvPolynomial.rename_monomial, coefficientNorm_monomial, monomialWeight_mapDomain w e he]
      rfl

/-- Applying the inverse gives exact norm preservation. -/
theorem coefficientNorm_rename (p : MvPolynomial ι ℂ) :
    coefficientNorm w.value (MvPolynomial.rename e p) = coefficientNorm w.value p := by
  apply le_antisymm (coefficientNorm_rename_le w e he p)
  have hinv : ∀ i, w.value (e.symm i) = w.value i := by
    intro i
    simpa using (he (e.symm i)).symm
  have hh := coefficientNorm_rename_le w e.symm hinv (MvPolynomial.rename e p)
  simpa only [MvPolynomial.rename_rename, e.symm_comp_self, MvPolynomial.rename_id_apply] using hh

/-- The polynomial algebra permutation on the already constructed normed type. -/
def weightedRename : WeightedPolynomial w ≃ₐ[ℂ] WeightedPolynomial w :=
  MvPolynomial.renameEquiv ℂ e

theorem weightedRename_isometry : Isometry (weightedRename w e) :=
  AddMonoidHomClass.isometry_of_norm (weightedRename w e)
    (coefficientNorm_rename w e he)

end WeightedPermutations

section CoefficientConjugation
variable {ι : Type*} (w : Weights ι)

/-- Conjugation of coefficients, separate from the endpoint reversal. -/
def weightedConjugate : WeightedPolynomial w ≃+* WeightedPolynomial w :=
  MvPolynomial.mapEquiv ι Complex.conjAe.toRingEquiv

theorem coefficientNorm_conjugate (p : MvPolynomial ι ℂ) :
    coefficientNorm w.value (MvPolynomial.map Complex.conjAe.toRingHom p) = coefficientNorm w.value p := by
  classical
  change (∑ d ∈ (MvPolynomial.map Complex.conjAe.toRingHom p).support,
    ‖MvPolynomial.coeff d (MvPolynomial.map Complex.conjAe.toRingHom p)‖ * monomialWeight w.value d) =
    ∑ d ∈ p.support, ‖MvPolynomial.coeff d p‖ * monomialWeight w.value d
  rw [MvPolynomial.support_map_of_injective p (f := Complex.conjAe.toRingHom) Complex.conjAe.injective]
  apply Finset.sum_congr rfl
  intro d hd
  change ‖MvPolynomial.coeff d (MvPolynomial.map Complex.conjAe.toRingHom p)‖ *
    monomialWeight w.value d = ‖MvPolynomial.coeff d p‖ * monomialWeight w.value d
  rw [MvPolynomial.coeff_map]
  change ‖star (MvPolynomial.coeff d p)‖ * _ = _
  rw [norm_star]

theorem weightedConjugate_isometry : Isometry (weightedConjugate w) :=
  AddMonoidHomClass.isometry_of_norm (weightedConjugate w) (coefficientNorm_conjugate w)

end CoefficientConjugation

section CompleteEquivalence
variable {P : Type*} [NormedCommRing P] (e : P ≃+* P) (he : Isometry e)
include he

private theorem inverse_isometry : Isometry e.symm := by
  intro x y
  simpa using (he (e.symm x) (e.symm y)).symm

/-- Extend an isometric ring equivalence to the actual metric completion. -/
def completeRingEquiv : Completion P ≃+* Completion P :=
  { Completion.mapRingHom e.toRingHom he.continuous with
    invFun := Completion.map e.symm
    left_inv := by
      intro x
      change Completion.map e.symm (Completion.map e x) = x
      change (Completion.map e.symm ∘ Completion.map e) x = x
      rw [Completion.map_comp (inverse_isometry e he).uniformContinuous he.uniformContinuous]
      have hh : (e.symm ∘ e) = (id : P → P) := funext e.symm_apply_apply
      rw [hh, Completion.map_id]
      rfl
    right_inv := by
      intro x
      change Completion.map e (Completion.map e.symm x) = x
      change (Completion.map e ∘ Completion.map e.symm) x = x
      rw [Completion.map_comp he.uniformContinuous (inverse_isometry e he).uniformContinuous]
      have hh : (e ∘ e.symm) = (id : P → P) := funext e.apply_symm_apply
      rw [hh, Completion.map_id]
      rfl }

@[simp] theorem completeRingEquiv_coe (x : P) :
    completeRingEquiv e he (x : Completion P) = (e x : Completion P) :=
  Completion.map_coe he.uniformContinuous x

theorem completeRingEquiv_isometry : Isometry (completeRingEquiv e he) :=
  he.completion_map

end CompleteEquivalence

section CompletedActions
variable {ι : Type*} (w : Weights ι) (e : ι ≃ ι) (he : ∀ i, w.value (e i) = w.value i)

/-- The actual isometric permutation action on the completed weighted algebra. -/
def completedRename : WeightedAlgebra w ≃ₐ[ℂ] WeightedAlgebra w :=
  { completeRingEquiv (weightedRename w e).toRingEquiv (weightedRename_isometry w e he) with
    commutes' c := by
      change completeRingEquiv _ _ ((algebraMap ℂ (WeightedPolynomial w) c) :
        Completion (WeightedPolynomial w)) = _
      rw [completeRingEquiv_coe]
      exact congrArg (fun p : WeightedPolynomial w => (p : Completion (WeightedPolynomial w)))
        ((weightedRename w e).commutes c) }

@[simp] theorem completedRename_ofPolynomial (p : MvPolynomial ι ℂ) :
    completedRename w e he (WeightedAlgebra.ofPolynomial w p) =
      WeightedAlgebra.ofPolynomial w (MvPolynomial.rename e p) :=
  completeRingEquiv_coe (weightedRename w e).toRingEquiv (weightedRename_isometry w e he) _

theorem completedRename_isometry : Isometry (completedRename w e he) :=
  completeRingEquiv_isometry (weightedRename w e).toRingEquiv (weightedRename_isometry w e he)

/-- Coefficient conjugation extends isometrically before quotienting. -/
def completedConjugate : WeightedAlgebra w ≃+* WeightedAlgebra w :=
  completeRingEquiv (weightedConjugate w) (weightedConjugate_isometry w)

@[simp] theorem completedConjugate_ofPolynomial (p : MvPolynomial ι ℂ) :
    completedConjugate w (WeightedAlgebra.ofPolynomial w p) =
      WeightedAlgebra.ofPolynomial w (MvPolynomial.map Complex.conjAe.toRingHom p) :=
  completeRingEquiv_coe _ _ _

theorem completedConjugate_isometry : Isometry (completedConjugate w) :=
  completeRingEquiv_isometry _ _

end CompletedActions

section ClosedIdealActions
variable {A J : Type*} [NormedCommRing A]

/-- Preservation of the generating relations extends first algebraically and
then topologically to the entire closed ideal. -/
theorem maps_closedGeneratedIdeal (f : A →+* A) (hf : Continuous f) (r : J → A)
    (hr : ∀ j, f (r j) ∈ (Ideal.span (Set.range r)).closure) :
    ∀ a ∈ (Ideal.span (Set.range r)).closure,
      f a ∈ (Ideal.span (Set.range r)).closure := by
  have hspan : Ideal.span (Set.range r) ≤
      Ideal.comap f (Ideal.span (Set.range r)).closure := by
    apply Ideal.span_le.mpr
    rintro _ ⟨j, rfl⟩
    exact hr j
  intro a ha
  exact closure_minimal (show (Ideal.span (Set.range r) : Set A) ⊆
      f ⁻¹' ((Ideal.span (Set.range r)).closure : Set A) from hspan)
    (isClosed_closure.preimage hf) ha

variable (I : Ideal A) [IsClosed (I : Set A)] (e : A ≃+* A) (he : Isometry e)
  (hI : ∀ a, a ∈ I ↔ e a ∈ I)
include hI

private theorem ideal_eq_map : I = I.map e.toRingHom := by
  ext a
  rw [Ideal.mem_map_iff_of_surjective e.toRingHom e.surjective]
  constructor
  · intro ha
    exact ⟨e.symm a, (hI (e.symm a)).mpr (by simpa using ha), e.apply_symm_apply a⟩
  · rintro ⟨x, hx, rfl⟩
    exact (hI x).mp hx

/-- Actual descent to the closed ideal quotient, with an explicit inverse. -/
def quotientRingEquiv : A ⧸ I ≃+* A ⧸ I :=
  Ideal.quotientEquiv I I e (ideal_eq_map I e hI)

@[simp] theorem quotientRingEquiv_mk (a : A) :
    quotientRingEquiv I e hI (Ideal.Quotient.mk I a) = Ideal.Quotient.mk I (e a) :=
  Ideal.quotientEquiv_mk I I e (ideal_eq_map I e hI) a

include he

/-- No quotient norm estimate is assumed: isometry follows from arbitrarily
close representatives and the isometric action before quotienting. -/
theorem quotientRingEquiv_isometry : Isometry (quotientRingEquiv I e hI) := by
  have hn : ∀ a, ‖e a‖ = ‖a‖ := (AddMonoidHomClass.isometry_iff_norm e).mp he
  have hni : ∀ a, ‖e.symm a‖ = ‖a‖ := by
    intro a
    simpa using (hn (e.symm a)).symm
  have hforward : ∀ x : A ⧸ I, ‖quotientRingEquiv I e hI x‖ ≤ ‖x‖ := by
    intro x
    apply le_of_forall_pos_le_add
    intro ε hε
    obtain ⟨a, ha, hanorm⟩ := Ideal.Quotient.norm_mk_lt (I := I) x hε
    rw [← ha, quotientRingEquiv_mk]
    exact (Ideal.Quotient.norm_mk_le I (e a)).trans ((hn a).trans_le (by simpa [ha] using hanorm.le))
  have hbackward : ∀ x : A ⧸ I, ‖(quotientRingEquiv I e hI).symm x‖ ≤ ‖x‖ := by
    intro x
    apply le_of_forall_pos_le_add
    intro ε hε
    obtain ⟨a, ha, hanorm⟩ := Ideal.Quotient.norm_mk_lt (I := I) x hε
    rw [← ha]
    change ‖(Ideal.quotientEquiv I I e (ideal_eq_map I e hI)).symm (Ideal.Quotient.mk I a)‖ ≤ _
    rw [Ideal.quotientEquiv_symm_mk]
    exact (Ideal.Quotient.norm_mk_le I (e.symm a)).trans ((hni a).trans_le (by simpa [ha] using hanorm.le))
  apply AddMonoidHomClass.isometry_of_norm
  intro x
  apply le_antisymm (hforward x)
  simpa using hbackward (quotientRingEquiv I e hI x)

end ClosedIdealActions

section CompletedExtensionality
variable {ι : Type*} (w : Weights ι)

/-- Continuity and the dense polynomial embedding reduce equality of completed
ring maps to constants and generators. -/
theorem completedRingHom_ext (f g : WeightedAlgebra w →+* WeightedAlgebra w)
    (hf : Continuous f) (hg : Continuous g)
    (hC : ∀ c, f (algebraMap ℂ _ c) = g (algebraMap ℂ _ c))
    (hX : ∀ i, f (WeightedAlgebra.generator w i) = g (WeightedAlgebra.generator w i)) : f = g := by
  have hp : f.comp (WeightedAlgebra.ofPolynomialAlgHom w).toRingHom =
      g.comp (WeightedAlgebra.ofPolynomialAlgHom w).toRingHom := by
    apply MvPolynomial.ringHom_ext
    · intro c
      simpa only [RingHom.comp_apply, AlgHom.toRingHom_eq_coe, ← MvPolynomial.algebraMap_eq,
        AlgHom.commutes] using hC c
    · exact hX
  apply RingHom.ext
  intro a
  refine (WeightedAlgebra.denseRange_ofPolynomial w).induction_on a
    (isClosed_eq hf hg) ?_
  intro p
  exact RingHom.congr_fun hp p

@[simp] theorem completedConjugate_constant (c : ℂ) :
    completedConjugate w (algebraMap ℂ _ c) = algebraMap ℂ _ (star c) := by
  change completedConjugate w (WeightedAlgebra.ofPolynomial w (MvPolynomial.C c)) = _
  rw [completedConjugate_ofPolynomial, MvPolynomial.map_C]
  rfl

@[simp] theorem completedConjugate_generator (i : ι) :
    completedConjugate w (WeightedAlgebra.generator w i) = WeightedAlgebra.generator w i := by
  rw [WeightedAlgebra.generator, completedConjugate_ofPolynomial, MvPolynomial.map_X]

@[simp] theorem completedRename_generator (e : ι ≃ ι) (he : ∀ i, w.value (e i) = w.value i) (i : ι) :
    completedRename w e he (WeightedAlgebra.generator w i) = WeightedAlgebra.generator w (e i) := by
  rw [WeightedAlgebra.generator, completedRename_ofPolynomial, MvPolynomial.rename_X]
  rfl

end CompletedExtensionality

section ActualCompletedActions
variable (b K : ℝ) (hb : 0 < b) (hK : 0 < K)

/-- Simultaneous real time translations on the actual weighted completion. -/
def translation (u : ℝ) : WeightedAlgebra (kernelWeights b K hb hK) ≃ₐ[ℂ]
    WeightedAlgebra (kernelWeights b K hb hK) :=
  completedRename _ (kernelIndexEquiv (translateEndpoint u))
    (kernelWeights_preserved b K hb hK _ (endpointDistance_translate u))

/-- Thermal reflection is an antilinear, isometric ring equivalence. -/
def reflection (β : ℝ) : WeightedAlgebra (kernelWeights b K hb hK) ≃+*
    WeightedAlgebra (kernelWeights b K hb hK) :=
  (completedConjugate _).trans
    (completedRename _ (kernelIndexEquiv (reflectEndpoint β))
      (kernelWeights_preserved b K hb hK _ (endpointDistance_reflect β))).toRingEquiv

theorem translation_isometry (u : ℝ) : Isometry (translation b K hb hK u) :=
  completedRename_isometry _ _ _

theorem reflection_isometry (β : ℝ) : Isometry (reflection b K hb hK β) :=
  (completedRename_isometry _ _
    (kernelWeights_preserved b K hb hK _ (endpointDistance_reflect β))).comp
      (completedConjugate_isometry _)

@[simp] theorem translation_generator (u : ℝ) (i : KernelIndex) :
    translation b K hb hK u (WeightedAlgebra.generator (kernelWeights b K hb hK) i) =
      WeightedAlgebra.generator (kernelWeights b K hb hK) (kernelIndexEquiv (translateEndpoint u) i) :=
  completedRename_generator _ _ _ _

@[simp] theorem reflection_generator (β : ℝ) (i : KernelIndex) :
    reflection b K hb hK β (WeightedAlgebra.generator (kernelWeights b K hb hK) i) =
      WeightedAlgebra.generator (kernelWeights b K hb hK) (kernelIndexEquiv (reflectEndpoint β) i) := by
  change completedRename _ _ (kernelWeights_preserved b K hb hK _ (endpointDistance_reflect β))
    (completedConjugate _ _) = _
  rw [completedConjugate_generator, completedRename_generator]

@[simp] theorem reflection_constant (β : ℝ) (c : ℂ) :
    reflection b K hb hK β (algebraMap ℂ _ c) = algebraMap ℂ _ (star c) := by
  change completedRename _ _ (kernelWeights_preserved b K hb hK _ (endpointDistance_reflect β))
    (completedConjugate _ _) = _
  rw [completedConjugate_constant, AlgEquiv.commutes]

/-- Reflection is conjugate-linear, not complex-linear. -/
theorem reflection_smul (β : ℝ) (c : ℂ) (a : WeightedAlgebra (kernelWeights b K hb hK)) :
    reflection b K hb hK β (c • a) = star c • reflection b K hb hK β a := by
  simp only [Algebra.smul_def, map_mul, reflection_constant]

/-- The simultaneous translations form the additive real action. -/
theorem translation_add (u v : ℝ) (a : WeightedAlgebra (kernelWeights b K hb hK)) :
    translation b K hb hK u (translation b K hb hK v a) = translation b K hb hK (u+v) a := by
  have hh : (translation b K hb hK u).toRingHom.comp (translation b K hb hK v).toRingHom =
      (translation b K hb hK (u+v)).toRingHom := by
    apply completedRingHom_ext (kernelWeights b K hb hK)
      _ _ ((translation_isometry b K hb hK u).continuous.comp
        (translation_isometry b K hb hK v).continuous) (translation_isometry b K hb hK (u+v)).continuous
    · intro c
      change translation b K hb hK u (translation b K hb hK v (algebraMap ℂ _ c)) =
        translation b K hb hK (u+v) (algebraMap ℂ _ c)
      rw [AlgEquiv.commutes, AlgEquiv.commutes, AlgEquiv.commutes]
    · intro i
      change translation b K hb hK u (translation b K hb hK v (WeightedAlgebra.generator _ i)) =
        translation b K hb hK (u+v) (WeightedAlgebra.generator _ i)
      rw [translation_generator, translation_generator, translation_generator]
      congr 1
      cases i with
      | inl p => apply congrArg Sum.inl; ext <;> dsimp [kernelIndexEquiv, translateEndpoint] <;> ring
      | inr pq =>
          apply congrArg Sum.inr
          apply Subtype.ext
          ext <;> dsimp [kernelIndexEquiv, incrementEquiv, translateEndpoint] <;> ring
  exact RingHom.congr_fun hh a

@[simp] theorem translation_zero (a : WeightedAlgebra (kernelWeights b K hb hK)) :
    translation b K hb hK 0 a = a := by
  have hh : (translation b K hb hK 0).toRingHom = RingHom.id _ := by
    apply completedRingHom_ext (kernelWeights b K hb hK) _ _
      (translation_isometry b K hb hK 0).continuous continuous_id
    · intro c
      exact (translation b K hb hK 0).commutes c
    · intro i
      change translation b K hb hK 0 (WeightedAlgebra.generator _ i) = WeightedAlgebra.generator _ i
      rw [translation_generator]
      change WeightedAlgebra.generator _ _ = WeightedAlgebra.generator _ _
      congr 1
      cases i with
      | inl p => apply congrArg Sum.inl; ext <;> dsimp [kernelIndexEquiv, translateEndpoint] <;> simp
      | inr pq =>
          apply congrArg Sum.inr
          apply Subtype.ext
          ext <;> dsimp [kernelIndexEquiv, incrementEquiv, translateEndpoint] <;> simp
  exact RingHom.congr_fun hh a

@[simp] theorem reflection_involutive (β : ℝ) (a : WeightedAlgebra (kernelWeights b K hb hK)) :
    reflection b K hb hK β (reflection b K hb hK β a) = a := by
  have hh : (reflection b K hb hK β).toRingHom.comp (reflection b K hb hK β).toRingHom = RingHom.id _ := by
    apply completedRingHom_ext (kernelWeights b K hb hK) _ _
      ((reflection_isometry b K hb hK β).continuous.comp
        (reflection_isometry b K hb hK β).continuous) continuous_id
    · intro c
      change reflection b K hb hK β (reflection b K hb hK β (algebraMap ℂ _ c)) = algebraMap ℂ _ c
      rw [reflection_constant, reflection_constant, star_star]
    · intro i
      change reflection b K hb hK β (reflection b K hb hK β (WeightedAlgebra.generator _ i)) =
        WeightedAlgebra.generator _ i
      rw [reflection_generator, reflection_generator]
      congr 1
      cases i with
      | inl p => apply congrArg Sum.inl; ext <;> dsimp [kernelIndexEquiv, reflectEndpoint] <;> ring
      | inr pq =>
          apply congrArg Sum.inr
          apply Subtype.ext
          ext <;> dsimp [kernelIndexEquiv, incrementEquiv, reflectEndpoint] <;> ring
  exact RingHom.congr_fun hh a

/-- The crucial covariance reverses time; translations need not preserve the
reflection involution as star-algebra automorphisms. -/
theorem reflection_translation (β u : ℝ) (a : WeightedAlgebra (kernelWeights b K hb hK)) :
    reflection b K hb hK β (translation b K hb hK u a) =
      translation b K hb hK (-u) (reflection b K hb hK β a) := by
  have hh : (reflection b K hb hK β).toRingHom.comp (translation b K hb hK u).toRingHom =
      (translation b K hb hK (-u)).toRingHom.comp (reflection b K hb hK β).toRingHom := by
    apply completedRingHom_ext (kernelWeights b K hb hK) _ _
      ((reflection_isometry b K hb hK β).continuous.comp
        (translation_isometry b K hb hK u).continuous)
      ((translation_isometry b K hb hK (-u)).continuous.comp
        (reflection_isometry b K hb hK β).continuous)
    · intro c
      change reflection b K hb hK β (translation b K hb hK u (algebraMap ℂ _ c)) =
        translation b K hb hK (-u) (reflection b K hb hK β (algebraMap ℂ _ c))
      simp only [AlgEquiv.commutes, reflection_constant]
    · intro i
      change reflection b K hb hK β (translation b K hb hK u (WeightedAlgebra.generator _ i)) =
        translation b K hb hK (-u) (reflection b K hb hK β (WeightedAlgebra.generator _ i))
      rw [translation_generator, reflection_generator, reflection_generator, translation_generator]
      congr 1
      cases i with
      | inl p => apply congrArg Sum.inl; ext <;> dsimp [kernelIndexEquiv, reflectEndpoint, translateEndpoint] <;> ring
      | inr pq =>
          apply congrArg Sum.inr
          apply Subtype.ext
          ext <;> dsimp [kernelIndexEquiv, incrementEquiv, reflectEndpoint, translateEndpoint] <;> ring
  exact RingHom.congr_fun hh a

end ActualCompletedActions

section MomentInvariance
variable {ι : Type*} (w : Weights ι) (e : ι ≃ ι) (he : ∀ i, w.value (e i) = w.value i)
  (m : (ι →₀ ℕ) → ℂ) (hm : ∀ d, ‖m d‖ ≤ monomialWeight w.value d)

/-- Microscopic polynomial symmetry extends to the actual completed functional
by density; invariance on the completion is a conclusion. -/
theorem completedMoment_invariant
    (hsym : ∀ p : MvPolynomial ι ℂ,
      WeightedPolynomial.momentLinear w m (WeightedPolynomial.ofPolynomial w (MvPolynomial.rename e p)) =
        WeightedPolynomial.momentLinear w m (WeightedPolynomial.ofPolynomial w p))
    (a : WeightedAlgebra w) :
    WeightedAlgebra.momentFunctional w m hm (completedRename w e he a) =
      WeightedAlgebra.momentFunctional w m hm a := by
  refine (WeightedAlgebra.denseRange_ofPolynomial w).induction_on a ?_ ?_
  · exact isClosed_eq ((WeightedAlgebra.momentFunctional w m hm).continuous.comp
      (completedRename_isometry w e he).continuous) (WeightedAlgebra.momentFunctional w m hm).continuous
  · intro p
    rw [completedRename_ofPolynomial, WeightedAlgebra.momentFunctional_ofPolynomial,
      WeightedAlgebra.momentFunctional_ofPolynomial]
    exact hsym p

end MomentInvariance

end SYK.KernelAlgebraActions
