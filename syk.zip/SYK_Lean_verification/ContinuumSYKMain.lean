import ActualMomentLimit
import ActualFourthResponse
import PressureLimitAssembly
import PhysicalFredholm
import FinalModelConventions
import RepresentationIndependence

/-!
# Assembly of the continuum SYK theorem

This module assembles the actual microscopic moment and pressure limits, the
pointwise physical solution, its sharp regularity, and the ordinary intrinsic
Fredholm determinant. The auxiliary theorem names its two remaining finite
microscopic inputs explicitly; neither a limiting state nor a physical
solution nor a pressure response is assumed.

The final representation transfer permits every matrix realization of the CAR
of the manuscript's dimension, only for the relevant sizes N = 2d ≥ 4. All
limits hold for each fixed positive inverse temperature and every coupling.
-/
noncomputable section
open MeasureTheory Filter Set
open scoped Topology BigOperators NNReal
namespace SYK.ContinuumSYKMain
open Continuum ActualMomentLimit ActualFiniteWardControl
open FourierOperators PhysicalFredholm SpectralFredholm

/-- A literal inserted operator/series correspondence, before any limiting
argument. Half-open time representatives fix all thermal seam conventions. -/
def QuarticCorrespondence (β : ℝ) (hβ : 0 < β) : Prop :=
  ∀ d : ℕ, 0 < d → ∀ l : ℝ, 0 < l → ∀ p : ℝ × ℝ,
    ContinuumWickSeries.normalizedMoment d β hβ
      (ContinuumWickSeries.quarticPairs β hβ p) l =
    Interacting.collectiveMoment d β l.toNNReal (fun _ : Fin 4 =>
      ((WickVertexIntegrals.timeRepresentative β hβ p.1).val,
       (WickVertexIntegrals.timeRepresentative β hβ p.2).val))

/-- The physical equation and its proved sharp, pointwise regularity. -/
structure PhysicalConclusion (β : ℝ) (hβ : 0 < β) (lam : ℝ≥0) (g : ℝ → ℝ) : Prop where
  physical : PhysicalSolution β lam g
  unique : ∀ h : ℝ → ℝ, PhysicalSolution β lam h → h = g
  sharp_bound : ∀ t, |g t| ≤ 1/2
  midpoint : ∀ k : ℤ, g ((k : ℝ)*β) = 0
  right_endpoint : Tendsto g (𝓝[>] (0 : ℝ)) (𝓝 (1/2 : ℝ))
  left_endpoint : Tendsto g (𝓝[<] β) (𝓝 (1/2 : ℝ))
  centered_lipschitz : LipschitzWith ⟨(lam:ℝ)*β*(1/2:ℝ)^4, by positivity⟩
    (fun t => g t - Thermal.covariance β t)
  bilocal_lipschitz : ∀ p q : ℝ × ℝ,
    |(g (p.1-p.2)-Thermal.kernel β p.1 p.2)-
      (g (q.1-q.2)-Thermal.kernel β q.1 q.2)| ≤
      ((lam:ℝ)*β*(1/2:ℝ)^4) * (|p.1-q.1|+|p.2-q.2|)

variable (β : ℝ) [Fact (0 < β)]

/-- No regularity or endpoint normalization is imported as a hypothesis. -/
theorem physicalConclusion (lam : ℝ≥0) (g : ℝ → ℝ)
    (hg : PhysicalSolution β lam g) (hb : ∀ t, |g t| ≤ 1/2) :
    PhysicalConclusion β Fact.out lam g := by
  have hβ : 0 < β := Fact.out
  have hl := physical_centered_lipschitz β Fact.out lam g hg (1/2) hb
  refine ⟨hg, fun h hh => physical_unique β lam h g hh hg, hb,
    physical_integer_midpoint β lam g hg,
    physical_right_endpoint β Fact.out lam g hg,
    physical_left_endpoint β Fact.out lam g hg, hl, ?_⟩
  intro p q
  have ht := hl.dist_le_mul (p.1-p.2) (q.1-q.2)
  simp only [Real.dist_eq, NNReal.coe_mk] at ht
  change |(g (p.1-p.2)-Thermal.covariance β (p.1-p.2))-
    (g (q.1-q.2)-Thermal.covariance β (q.1-q.2))| ≤ _
  refine ht.trans (mul_le_mul_of_nonneg_left ?_ (by positivity))
  calc
    |p.1-p.2-(q.1-q.2)| = |(p.1-q.1)-(p.2-q.2)| := by congr 1 <;> ring
    _ ≤ |p.1-q.1| + |p.2-q.2| := abs_sub _ _

/-- A concrete trace-class certificate for the actual time-domain operator
−CΣ, with its ordinary intrinsic Fredholm determinant and strict positivity. -/
structure FredholmConclusion (lam : ℝ≥0) (g : ℝ → ℝ) : Prop where
  compact : IsCompactOperator (physicalPerturbation β lam g)
  selfAdjoint : IsSelfAdjoint (physicalPerturbation β lam g)
  rank_one_summable : Summable (fun n : ℤ =>
    ‖coefficientFunctional β n‖ * ‖modeVector β (sourceRatio β lam g) n‖)
  rank_one_sum : HasSum (fun n : ℤ => (coefficientFunctional β n).smulRight
    (modeVector β (sourceRatio β lam g) n)) (physicalPerturbation β lam g)
  spectral_absolute_sum : HasSum (fun r : ℝ =>
    (Module.finrank ℂ (Module.End.genEigenspace (physicalPerturbation β lam g).toLinearMap
      (r : ℂ) ⊤) : ℝ) * |r|) (∑' n : ℤ, |sourceRatio β lam g n|)
  determinant_positive : 0 < spectralDeterminant (physicalPerturbation β lam g)

/-- The operator certificates are proved from the physical SD equation. -/
theorem fredholmConclusion (lam : ℝ≥0) (g : ℝ → ℝ)
    (hg : PhysicalSolution β lam g) : FredholmConclusion β lam g := by
  have hn := physical_nuclear_expansion β lam g hg
  exact ⟨physical_compact β lam g hg, physical_selfAdjoint β lam g hg, hn.1, hn.2,
    physical_spectral_trace_class β lam g hg, ordinary_determinant_pos β lam g hg⟩

/-- All continuum and microscopic conclusions for one simultaneously chosen
physical family. The moments are actual operator moments, and the pressures
are the actual normalized Gaussian partition-function pressures. -/
structure MainConclusion (g : ℝ≥0 → ℝ → ℝ) : Prop where
  solution : ∀ lam, PhysicalConclusion β Fact.out lam (g lam)
  moments : ∀ lam, ActualMomentLimits β Fact.out lam (g lam)
  pressure : ∀ lam, PressureConvergence β lam (couplingPressure β g lam)
  fredholm : ∀ lam, FredholmConclusion β lam (g lam)
  ordinary_action : ∀ lam,
    couplingPressure β g lam = Real.log 2 / 2 +
      (1/2 : ℝ) * Real.log (spectralDeterminant (physicalPerturbation β lam (g lam))) -
      (3 * β / 8) * (lam : ℝ) * quarticIntegral β (g lam)

/-- Full theorem assembly with the exact two unresolved microscopic identities
visible in its type. In particular no compactness, reflection positivity,
translation symmetry, limiting Ward equation, existence, uniqueness, response,
pressure limit, determinant identification, or representation equivalence is
assumed here. -/
theorem exists_main_of_microscopic_identities
    (hWard : ∀ lam : ℝ≥0, ∀ d : ℕ, 0 < d → ExactLeftWard β Fact.out lam d)
    (hQuartic : QuarticCorrespondence β Fact.out) :
    ∃ g : ℝ≥0 → ℝ → ℝ, MainConclusion β g := by
  choose g hg hb hm using fun lam =>
    exists_physical_actual_moment_limit β Fact.out lam (hWard lam)
  have hresponse : ∀ d : ℕ, 0 < d → ∀ l : ℝ, 0 < l →
      HasDerivAt (fun s => Microscopic.annealedPressure d β s.toNNReal)
        (FourthMomentIntegral.fourthIntegral d β l.toNNReal) l := by
    intro d hd l hl
    exact ActualFourthResponse.hasDerivAt_annealedPressure d hd Fact.out l hl
      (hQuartic d hd l hl)
  exact ⟨g, ⟨fun lam => physicalConclusion β lam (g lam) (hg lam) (hb lam), hm,
    PressureLimitAssembly.pressure_convergence_from_quartic_response Fact.out g hg
      hresponse (fun lam => (hm lam).fourth),
    fun lam => fredholmConclusion β lam (g lam) (hg lam),
    couplingPressure_eq_ordinary_fredholm_action β g hg (1/2) hb⟩⟩

/-- The determinant's operator is literally minus the two nested convolution
integrals, on every bounded measurable real test function. This excludes a
mere formal mode product or a regularized determinant interpretation. -/
theorem MainConclusion.operator_integral_action {g : ℝ≥0 → ℝ → ℝ}
    (h : MainConclusion β g) (lam : ℝ≥0) (f : ℝ → ℝ) (hf : Measurable f)
    (D : ℝ) (hD : ∀ t, |f t| ≤ D) :
    physicalPerturbation β lam (g lam) (circleL2 β f hf D hD) =
      -circleL2 β (covarianceSource β lam (g lam) f)
        (covarianceSource_measurable β lam (g lam) f (h.solution lam).physical.1 hf)
        (β*((1/2)*(β*((lam:ℝ)*(1/2:ℝ)^3*D))))
        (covarianceSource_bound β lam (g lam) f (1/2) D
          (h.solution lam).sharp_bound hD) :=
  physicalPerturbation_integral_action β lam (g lam) f (h.solution lam).physical hf
    (1/2) D (h.solution lam).sharp_bound hD

/-- The manuscript's original real scale J, exact pressure integral, ordinary
Fredholm action, and free energy with sign and per-Majorana normalization. -/
theorem MainConclusion.at_real_coupling {g : ℝ≥0 → ℝ → ℝ}
    (h : MainConclusion β g) (J : ℝ) :
    PressureConvergence β (couplingOfJ J)
      (Real.log 2 / 2 + β/8 * ∫ l in (0:ℝ)..J^2,
        ∫ t in (0:ℝ)..β, (g l.toNNReal t)^4) ∧
    (couplingPressure β g (couplingOfJ J) = Real.log 2 / 2 +
      (1/2 : ℝ) * Real.log
        (spectralDeterminant (physicalPerturbation β (couplingOfJ J) (g (couplingOfJ J)))) -
      (3*J^2*β/8) * ∫ t in (0:ℝ)..β, (g (couplingOfJ J) t)^4) ∧
    Tendsto (fun d => Microscopic.annealedFreeEnergy d β (couplingOfJ J)) atTop
      (𝓝 (-(Real.log 2 / 2 + β/8 * ∫ l in (0:ℝ)..J^2,
        ∫ t in (0:ℝ)..β, (g l.toNNReal t)^4)/β)) ∧
    Tendsto (fun d => Microscopic.quenchedFreeEnergy d β (couplingOfJ J)) atTop
      (𝓝 (-(Real.log 2 / 2 + β/8 * ∫ l in (0:ℝ)..J^2,
        ∫ t in (0:ℝ)..β, (g l.toNNReal t)^4)/β)) := by
  refine ⟨h.pressure (couplingOfJ J), ?_, freeEnergy_convergence_J β g J (h.pressure _)⟩
  convert h.ordinary_action (couplingOfJ J) using 1 <;>
    simp only [couplingOfJ_coe, quarticIntegral] <;> ring

/-- Every actual CAR representation in dimension 2^d has the same two limits.
Only sizes N=2d≥4 need obey the CAR and dimension requirements. Thus this
covers the manuscript's arbitrary irreducible Majorana realization, without
assuming a chosen unitary equivalence or conditions at irrelevant small sizes. -/
theorem MainConclusion.arbitrary_representation {g : ℝ≥0 → ℝ → ℝ}
    (h : MainConclusion β g) {κ : ℕ → Type*}
    [∀ d, Fintype (κ d)] [∀ d, DecidableEq (κ d)]
    (x : ∀ d, Fin (2*d) → Matrix (κ d) (κ d) ℂ)
    (hx : ∀ d, 2 ≤ d → ∀ i j, x d i*x d j+x d j*x d i =
      FreeWick.flavorDelta i j • (1 : Matrix (κ d) (κ d) ℂ))
    (hcard : ∀ d, 2 ≤ d → Fintype.card (κ d) = 2^d) (J : ℝ) :
    Tendsto (fun d => RepresentationIndependence.annealedPressure d (x d) β (couplingOfJ J))
      atTop (𝓝 (couplingPressure β g (couplingOfJ J))) ∧
    Tendsto (fun d => RepresentationIndependence.quenchedPressure d (x d) β (couplingOfJ J))
      atTop (𝓝 (couplingPressure β g (couplingOfJ J))) := by
  have ha : (fun d => RepresentationIndependence.annealedPressure d (x d) β (couplingOfJ J))
      =ᶠ[atTop] (fun d => Microscopic.annealedPressure d β (couplingOfJ J)) := by
    filter_upwards [eventually_ge_atTop 2] with d hd
    exact RepresentationIndependence.annealedPressure_eq d (x d) (hx d hd) (hcard d hd) β _
  have hq : (fun d => RepresentationIndependence.quenchedPressure d (x d) β (couplingOfJ J))
      =ᶠ[atTop] (fun d => Microscopic.quenchedPressure d β (couplingOfJ J)) := by
    filter_upwards [eventually_ge_atTop 2] with d hd
    exact RepresentationIndependence.quenchedPressure_eq d (x d) (hx d hd) (hcard d hd) β _
  exact ⟨(h.pressure _).1.congr' ha.symm, (h.pressure _).2.congr' hq.symm⟩

end SYK.ContinuumSYKMain
