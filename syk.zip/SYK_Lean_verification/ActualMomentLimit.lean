import MicroscopicMomentConvergence
import ActualFiniteWardControl
import FourthMomentIntegral

/-!
# The actual full moment limit from the exact microscopic Ward identity

No state, compactness, symmetry or positivity premise is left. The sole named
microscopic premise below is the literal finite left Ward/contact identity.
-/

noncomputable section
namespace SYK.ActualMomentLimit
open SYK.WeightedKernelAlgebra SYK.ThermalEndpointLift SYK.ThermalMomentTransport
open SYK.MomentLimit SYK.ActualFiniteWardControl SYK.Continuum SYK.FourthMomentIntegral
open MeasureTheory Filter Set
open scoped BigOperators Topology NNReal

/-- Full actual moment convergence, with the two endpoint conventions kept
explicit: signed all-real labels, and the original primary Ico operator labels. -/
structure ActualMomentLimits (β : ℝ) (hβ : 0 < β) (lam : ℝ≥0) (g : ℝ → ℝ) : Prop where
  thermal : ∀ k, TendstoUniformly
    (fun d (p : Fin k → Endpoint) => actualThermalPolynomial β hβ d lam (∏ i, MvPolynomial.X (p i)))
    (fun p => ∏ i, (g ((p i).1-(p i).2) : ℂ)) atTop
  primary : ∀ k, TendstoUniformly
    (fun d (p : Fin k → Ico (0:ℝ) β × Ico (0:ℝ) β) =>
      Interacting.collectiveMoment d β lam (fun i => ((p i).1.val,(p i).2.val)))
    (fun p => ∏ i, (g ((p i).1.val-(p i).2.val) : ℂ)) atTop

/-- Exact finite inserted contacts imply physical existence and the full,
not merely subsequential, limit of every actual collective moment. -/
theorem exists_physical_actual_moment_limit (β : ℝ) (hβ : 0 < β) (lam : ℝ≥0)
    (hWard : ∀ d : ℕ, 0 < d → ExactLeftWard β hβ lam d) :
    ∃ g : ℝ → ℝ, PhysicalSolution β lam g ∧ (∀ s, |g s| ≤ 1/2) ∧
      ActualMomentLimits β hβ lam g := by
  obtain ⟨g,hg,hbound,hthermal,hprimary⟩ :=
    MicroscopicMomentConvergence.exists_physical_actual_moment_limit β hβ lam
      (finiteWardControl_of_exact_left β hβ lam (fun n => n+1) (fun n => Nat.succ_pos n)
        (fun n => hWard (n+1) (Nat.succ_pos n)))
  exact ⟨g,hg,hbound,⟨hthermal,hprimary⟩⟩

/-- The fixed-degree tuple limits imply convergence of every fixed actual
polynomial, with arbitrary real labels and all endpoint coincidences. -/
theorem ActualMomentLimits.polynomial {β : ℝ} {hβ : 0 < β} {lam : ℝ≥0} {g : ℝ → ℝ}
    (h : ActualMomentLimits β hβ lam g) (P : RealPolynomial) :
    Tendsto (fun d => actualThermalPolynomial β hβ d lam P) atTop
      (𝓝 (MvPolynomial.aeval (fun p : Endpoint => (g (p.1-p.2) : ℂ)) P)) := by
  induction P using MvPolynomial.induction_on' with
  | monomial e c =>
    have hc : MvPolynomial.monomial e c = c • MvPolynomial.monomial e (1 : ℂ) := by
      simp [MvPolynomial.smul_monomial]
    simp only [hc, monomial_eq_tuple_prod, map_smul, smul_eq_mul, map_prod, MvPolynomial.aeval_X]
    exact tendsto_const_nhds.mul ((h.thermal _).tendsto_at (monomialTuple e))
  | add P Q hP hQ => simpa only [map_add] using hP.add hQ

/-- Almost every thermal-square endpoint lies in the actual primary Ico
coordinate domain; the upper seam is a null set, not an asserted raw equality. -/
theorem ae_primary_timeSquare (β : ℝ) : ∀ᵐ p ∂timeMeasure β,
    p.1 ∈ Ico (0:ℝ) β ∧ p.2 ∈ Ico (0:ℝ) β := by
  unfold timeMeasure
  rw [← restrict_Ico_eq_restrict_Ioc]
  apply (Measure.ae_prod_iff_ae_ae (measurableSet_Ico.prod measurableSet_Ico)).mpr
  filter_upwards [ae_restrict_mem (measurableSet_Ico : MeasurableSet (Ico (0:ℝ) β))] with s hs
  filter_upwards [ae_restrict_mem (measurableSet_Ico : MeasurableSet (Ico (0:ℝ) β))] with t ht
  exact ⟨hs,ht⟩

/-- The literal microscopic fourth moment, used by the pressure derivative,
converges almost everywhere to the fourth power of the physical solution. -/
theorem ActualMomentLimits.fourth {β : ℝ} {hβ : 0 < β} {lam : ℝ≥0} {g : ℝ → ℝ}
    (h : ActualMomentLimits β hβ lam g) :
    ∀ᵐ p ∂timeMeasure β, Tendsto (fun d : ℕ => fourthMoment d β lam p) atTop
      (𝓝 ((g (p.1-p.2))^4)) := by
  filter_upwards [ae_primary_timeSquare β] with p hp
  have ht := (h.primary 4).tendsto_at (fun _ : Fin 4 => (⟨p.1,hp.1⟩,⟨p.2,hp.2⟩))
  have hre := Complex.continuous_re.tendsto _ |>.comp ht
  simpa only [Finset.prod_const, Finset.card_univ, Fintype.card_fin, ← Complex.ofReal_pow,
    Complex.ofReal_re, Function.comp_def, fourthMoment] using hre

end SYK.ActualMomentLimit
