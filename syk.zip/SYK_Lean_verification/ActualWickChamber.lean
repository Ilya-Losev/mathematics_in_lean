import PartitionWickSeries
import GapChamberCoordinates

/-!
# Actual free-Wick values on mixed external/interaction time chambers

Quartic vertices are kept as genuine four-letter blocks. Their centrality in
the exterior algebra permits moving the blocks past external letters without
introducing a sign; no analogous commutation of operator vertices is used.
-/
set_option maxHeartbeats 1200000
noncomputable section
open scoped BigOperators
open Set
namespace SYK.ActualWickChamber
open DuhamelHistory DuhamelVertex WickVertexIntegrals ThermalWick
open GapAssignmentPartition GapChamberCoordinates

/-- Interspersing central factors in an ordered word can move exactly those
factors to the right, while preserving the external word's order. -/
theorem orderedProduct_central {A : Type*} [Ring A] [Algebra ℂ A] {k : ℕ}
    (C : Fin k → Subalgebra.center ℂ A) (E : Fin k → A) :
    orderedProduct (fun j => (C j : A) * E j) =
      orderedProduct E * ((∏ j, C j : Subalgebra.center ℂ A) : A) := by
  induction k with
  | zero => simp
  | succ k ih =>
    simp only [orderedProduct_succ, Fin.prod_univ_succ, Subalgebra.coe_mul]
    rw [ih]
    have hc := Subalgebra.mem_center_iff.mp (C 0).property
      (E 0 * orderedProduct (fun i => E i.succ))
    calc
      _ = ((C 0 : A) * (E 0 * orderedProduct (fun i => E i.succ))) *
          ((∏ i : Fin k, C i.succ : Subalgebra.center ℂ A) : A) := by simp only [mul_assoc]
      _ = _ := by rw [← hc]; simp only [mul_assoc]

/-- Literal merged label list: each gap's interaction vertices, then that
gap's fixed external endpoint block. -/
def mergedLabels (d : ℕ) {β : ℝ} {k : ℕ} (r : Fin k → ℕ)
    (I : (j : Fin k) → Fin (r j) → Majorana.FourSet d)
    (u : (j : Fin k) → Fin (r j) → Time β)
    (E : Fin k → List (Label (2*d) β)) : List (Label (2*d) β) :=
  (List.ofFn (fun j => historyLabels d (I j) (u j) ++ E j)).flatten

/-- The merged actual matrix word preserves every noncommutative gap order. -/
theorem mergedLabels_operator_word (d : ℕ) {β : ℝ} {k : ℕ} (r : Fin k → ℕ)
    (I : (j : Fin k) → Fin (r j) → Majorana.FourSet d)
    (u : (j : Fin k) → Fin (r j) → Time β)
    (E : Fin k → List (Label (2*d) β)) :
    FreeWick.word (fun p : Label (2*d) β => Majorana.chiFin d p.1) (mergedLabels d r I u E) =
      orderedProduct (fun j => orderedProduct (fun a => Majorana.quartic d (I j a)) *
        FreeWick.word (fun p : Label (2*d) β => Majorana.chiFin d p.1) (E j)) := by
  simp only [mergedLabels, word_flatten, List.map_ofFn, Function.comp_def,
    FreeWick.word_append, historyLabels_operator_word, orderedProduct]

/-- The exterior merged word is exactly the fixed external word times the
true quartic product in the commutative even center. -/
theorem mergedLabels_exterior_word (d : ℕ) {β : ℝ} {k : ℕ} (r : Fin k → ℕ)
    (I : (j : Fin k) → Fin (r j) → Majorana.FourSet d)
    (u : (j : Fin k) → Fin (r j) → Time β)
    (E : Fin k → List (Label (2*d) β)) :
    FreeWick.word (fun p : Label (2*d) β => field p.1 p.2) (mergedLabels d r I u E) =
      FreeWick.word (fun p : Label (2*d) β => field p.1 p.2) (List.ofFn E).flatten *
        ((∏ j, ∏ a, centralVertex d (I j a) (u j a) :
          Subalgebra.center ℂ (FieldAlgebra (2*d) β)) : FieldAlgebra (2*d) β) := by
  simp only [mergedLabels, word_flatten, List.map_ofFn, Function.comp_def,
    FreeWick.word_append, historyLabels_exterior_word, vertex_product_center]
  exact orderedProduct_central _ _

/-- Adding genuine quartic histories preserves the parity of the external
word, including arbitrary fixed equal-time external blocks. -/
theorem mergedLabels_even (d : ℕ) {β : ℝ} {k : ℕ} (r : Fin k → ℕ)
    (I : (j : Fin k) → Fin (r j) → Majorana.FourSet d)
    (u : (j : Fin k) → Fin (r j) → Time β)
    (E : Fin k → List (Label (2*d) β)) (hE : Even (List.ofFn E).flatten.length) :
    Even (mergedLabels d r I u E).length := by
  have hh : Even (∑ j, r j * 4) := by
    rw [← Finset.sum_mul]
    exact Even.mul_left (by decide : Even 4) _
  simp only [List.length_flatten, List.map_ofFn, Function.comp_def, List.sum_ofFn] at hE
  simpa only [mergedLabels, List.length_flatten, List.map_ofFn, Function.comp_def,
    List.length_append, historyLabels_length, List.sum_ofFn, Finset.sum_add_distrib] using hh.add hE

/-- Every label in an interaction history belongs to one of its true
quartic vertices and consequently has that vertex's time. -/
theorem mem_historyLabels (d : ℕ) {β : ℝ} {n : ℕ}
    (I : Fin n → Majorana.FourSet d) (u : Fin n → Time β)
    {p : Label (2*d) β} (hp : p ∈ historyLabels d I u) :
    ∃ a : Fin n, p.2 = u a := by
  obtain ⟨l, hl, hp⟩ := List.mem_flatten.mp hp
  obtain ⟨a, rfl⟩ := List.mem_ofFn.mp hl
  obtain ⟨b, rfl⟩ := List.mem_ofFn.mp hp
  exact ⟨a, rfl⟩

/-- The real chamber inequalities give precisely the free-trace ordering
condition, retaining distinct-flavor external ties exactly. -/
theorem mergedLabels_pairwise (d : ℕ) {β : ℝ} {k : ℕ}
    (t : Fin (k+1) → ℝ) (ht : Antitone t) (r : Fin k → ℕ)
    (I : (j : Fin k) → Fin (r j) → Majorana.FourSet d)
    (u : (j : Fin k) → Fin (r j) → Time β)
    (E : Fin k → List (Label (2*d) β))
    (hu : ∀ j, StrictAnti (fun a => (u j a).val))
    (hb : ∀ j a, t j.succ < (u j a).val ∧ (u j a).val < t j.castSucc)
    (hEt : ∀ j, ∀ p ∈ E j, p.2.val = t j.succ)
    (hE : (List.ofFn E).flatten.Pairwise
      (fun p q => q.2.val < p.2.val ∨ p.1 ≠ q.1)) :
    (mergedLabels d r I u E).Pairwise
      (fun p q => q.2.val < p.2.val ∨ p.1 ≠ q.1) := by
  have he := List.pairwise_flatten.mp hE
  rw [mergedLabels, List.pairwise_flatten]
  constructor
  · intro l hl
    obtain ⟨j, rfl⟩ := List.mem_ofFn.mp hl
    rw [List.pairwise_append]
    refine ⟨historyLabels_pairwise d (I j) (u j) (hu j),
      he.1 _ (List.mem_ofFn.mpr ⟨j,rfl⟩), ?_⟩
    intro p hp q hq
    obtain ⟨a, ha⟩ := mem_historyLabels d (I j) (u j) hp
    exact Or.inl (by rw [hEt j q hq, ha]; exact (hb j a).1)
  · apply List.pairwise_ofFn.mpr
    intro i j hij p hp q hq
    have hij' : i.succ ≤ j.castSucc := by
      simpa only [Fin.le_iff_val_le_val, Fin.val_succ, Fin.coe_castSucc] using Nat.succ_le_of_lt hij
    rcases List.mem_append.mp hp with hp | hp <;> rcases List.mem_append.mp hq with hq | hq
    · obtain ⟨a, ha⟩ := mem_historyLabels d (I i) (u i) hp
      obtain ⟨b, hb'⟩ := mem_historyLabels d (I j) (u j) hq
      exact Or.inl (by rw [ha, hb']; exact (hb j b).2.trans_le (ht hij') |>.trans (hb i a).1)
    · obtain ⟨a, ha⟩ := mem_historyLabels d (I i) (u i) hp
      exact Or.inl (by rw [ha, hEt j q hq]; exact (ht (Fin.succ_le_succ_iff.mpr hij.le)).trans_lt (hb i a).1)
    · obtain ⟨b, hb'⟩ := mem_historyLabels d (I j) (u j) hq
      exact Or.inl (by rw [hEt i p hp, hb']; exact (hb j b).2.trans_le (ht hij'))
    · exact (List.pairwise_ofFn.mp he.2 hij) p hp q hq

/-- Genuine noncommutative mixed history equals its genuine exterior Wick
expectation at all strict within-gap interaction times. -/
theorem mixed_trace_eq_wick (d : ℕ) {β : ℝ} (hβ : 0 < β) {k : ℕ}
    (t : Fin (k+1) → ℝ) (ht : Antitone t) (r : Fin k → ℕ)
    (I : (j : Fin k) → Fin (r j) → Majorana.FourSet d)
    (u : (j : Fin k) → Fin (r j) → Time β)
    (E : Fin k → List (Label (2*d) β))
    (hu : ∀ j, StrictAnti (fun a => (u j a).val))
    (hb : ∀ j a, t j.succ < (u j a).val ∧ (u j a).val < t j.castSucc)
    (hEt : ∀ j, ∀ p ∈ E j, p.2.val = t j.succ)
    (hE : (List.ofFn E).flatten.Pairwise
      (fun p q => q.2.val < p.2.val ∨ p.1 ≠ q.1))
    (heven : Even (List.ofFn E).flatten.length) :
    Majorana.normalizedTrace d (orderedProduct (fun j =>
      orderedProduct (fun a => Majorana.quartic d (I j a)) *
        FreeWick.word (fun p : Label (2*d) β => Majorana.chiFin d p.1) (E j))) =
    expectation (2*d) β
      (FreeWick.word (fun p : Label (2*d) β => field p.1 p.2) (List.ofFn E).flatten *
        ((∏ j, ∏ a, centralVertex d (I j a) (u j a) :
          Subalgebra.center ℂ (FieldAlgebra (2*d) β)) : FieldAlgebra (2*d) β)) := by
  simpa only [mergedLabels_operator_word, mergedLabels_exterior_word] using
    FreeWick.thermal_trace_of_ordered_equal_flavors d β hβ (mergedLabels d r I u E)
      (mergedLabels_even d r I u E heven) (mergedLabels_pairwise d t ht r I u E hu hb hEt hE)

/-- Reindex actual interaction flavors into their canonical ordered gap
fibers. This is a genuine bijection, including empty gap fibers. -/
def vertexBlocksEquiv {n k : ℕ} (g : Fin n → Fin k) (α : Type*) :
    (Fin n → α) ≃ ((j : Fin k) → Fin (gapCount g j) → α) where
  toFun I j a := I (fiberIndexEquiv g ⟨j,a⟩)
  invFun J i := J ((fiberIndexEquiv g).symm i).1 ((fiberIndexEquiv g).symm i).2
  left_inv I := by funext i; simp
  right_inv J := by
    funext j a
    exact congrArg (fun z : Σ j : Fin k, Fin (gapCount g j) => J z.1 z.2)
      ((fiberIndexEquiv g).symm_apply_apply ⟨j,a⟩)

/-- The exact disorder monomial is unchanged by grouping vertices into gaps. -/
theorem prod_vertexBlocks {n k : ℕ} (g : Fin n → Fin k) {M : Type*} [CommMonoid M]
    (F : Fin n → M) :
    (∏ j, ∏ a, F (fiberIndexEquiv g ⟨j,a⟩)) = ∏ i, F i := by
  rw [← Fintype.prod_sigma (fun z : Σ j : Fin k, Fin (gapCount g j) => F (fiberIndexEquiv g z))]
  exact (fiberIndexEquiv g).prod_comp F

/-- Pointwise chamber constancy for a genuine fixed flavor history, away
from the null internal collisions. Fixed external blocks may have ties. -/
theorem vertexIntegrand_chamber (d : ℕ) {β : ℝ} (hβ : 0 < β) {n k : ℕ}
    (t : Fin (k+1) → ℝ) (ht : Antitone t) (htop : t 0 = β) (hbot : t (Fin.last k) = 0)
    (E : Fin k → List (Label (2*d) β))
    (hEt : ∀ j, ∀ p ∈ E j, p.2.val = t j.succ)
    (hE : (List.ofFn E).flatten.Pairwise
      (fun p q => q.2.val < p.2.val ∨ p.1 ≠ q.1))
    (heven : Even (List.ofFn E).flatten.length)
    (g : Fin n → Fin k) (I : Fin n → Majorana.FourSet d)
    (u : Fin n → ℝ) (hu : u ∈ orderedAssignmentRegion t g) (hi : Function.Injective u) :
    vertexIntegrand d hβ (List.ofFn E).flatten I u =
      Majorana.normalizedTrace d (orderedProduct (fun j =>
        orderedProduct (fun a => Majorana.quartic d (I (fiberIndexEquiv g ⟨j,a⟩))) *
          FreeWick.word (fun p : Label (2*d) β => Majorana.chiFin d p.1) (E j))) := by
  have hf (i : Fin n) : u i ∈ Ico 0 β := by
    have hh := hu.2 i (mem_univ _)
    exact ⟨by rw [← hbot]; exact (ht (Fin.le_last (g i).succ)).trans hh.1.le,
      by rw [← htop]; exact hh.2.trans_le (ht (Fin.zero_le (g i).castSucc))⟩
  have hr (i : Fin n) : (timeRepresentative β hβ (u i)).val = u i :=
    timeRepresentative_of_mem hβ (hf i)
  have hs := hu.1.2.2.strictAnti_of_injective hi
  have hh := mixed_trace_eq_wick d hβ t ht (gapCount g)
    (vertexBlocksEquiv g _ I)
    (fun j a => timeRepresentative β hβ (u (fiberIndexEquiv g ⟨j,a⟩))) E
    (by
      intro j a b hab
      simp only [hr]
      exact hs ((fiberOrder g j).strictMono hab))
    (by
      intro j a
      simpa only [hr, gapInterval, gap_fiberIndexEquiv] using
        hu.2 (fiberIndexEquiv g ⟨j,a⟩) (mem_univ _)) hEt hE heven
  have hp : (∏ j, ∏ a, centralVertex d (I (fiberIndexEquiv g ⟨j,a⟩))
      (timeRepresentative β hβ (u (fiberIndexEquiv g ⟨j,a⟩)))) =
      ∏ i, centralVertex d (I i) (timeRepresentative β hβ (u i)) :=
      prod_vertexBlocks g (fun i => centralVertex d (I i) (timeRepresentative β hβ (u i)))
  simp only [vertexBlocksEquiv, Equiv.coe_fn_mk] at hh
  rw [hp] at hh
  simpa only [vertexIntegrand, vertex_product_center, vertexBlocksEquiv, Equiv.coe_fn_mk] using hh.symm

/-- The complete actual flavor sum has the exact noncommutative Hamiltonian
power value on every off-collision ordered external-time chamber. -/
theorem weightedVertexIntegrand_chamber (d : ℕ) {β : ℝ} (hβ : 0 < β) {n k : ℕ}
    (t : Fin (k+1) → ℝ) (ht : Antitone t) (htop : t 0 = β) (hbot : t (Fin.last k) = 0)
    (E : Fin k → List (Label (2*d) β))
    (hEt : ∀ j, ∀ p ∈ E j, p.2.val = t j.succ)
    (hE : (List.ofFn E).flatten.Pairwise
      (fun p q => q.2.val < p.2.val ∨ p.1 ≠ q.1))
    (heven : Even (List.ofFn E).flatten.length)
    (g : Fin n → Fin k) (j : Majorana.FourSet d → ℝ)
    (u : Fin n → ℝ) (hu : u ∈ orderedAssignmentRegion t g) (hi : Function.Injective u) :
    PartitionWick.weightedVertexIntegrand d hβ (List.ofFn E).flatten j n u =
      Majorana.normalizedTrace d (orderedProduct (fun a => (-Majorana.hamiltonian d j)^(gapCount g a) *
        FreeWick.word (fun p : Label (2*d) β => Majorana.chiFin d p.1) (E a))) := by
  classical
  rw [hamiltonian_history_expansion]
  simp_rw [← FreeWick.normalizedTraceMap_apply]
  rw [map_sum]
  simp only [map_smul, smul_eq_mul, FreeWick.normalizedTraceMap_apply]
  unfold PartitionWick.weightedVertexIntegrand
  apply Fintype.sum_equiv (vertexBlocksEquiv g (Majorana.FourSet d))
  intro I
  have hp : (∏ a, ∏ b, (j (vertexBlocksEquiv g (Majorana.FourSet d) I a b) : ℂ)) =
      ∏ i, (j (I i) : ℂ) := prod_vertexBlocks g (fun i => (j (I i) : ℂ))
  rw [hp, vertexIntegrand_chamber d hβ t ht htop hbot E hEt hE heven g I u hu hi]
  rfl

end SYK.ActualWickChamber
