import GapAssignmentPartition
import Mathlib.Data.Fintype.Sort

/-!
# Measure-preserving block coordinates for actual external-time chambers
-/
noncomputable section
open scoped BigOperators
open MeasureTheory MeasureTheory.Measure Set
open SYK.OrderedSimplexIntegral SYK.GapSimplexIntegral SYK.GapAssignmentPartition

namespace SYK.GapChamberCoordinates

/-- Group time coordinates into finite dependent blocks using an explicit
bijection of their labels. -/
def blockCoordinates {n k : ℕ} {r : Fin k → ℕ}
    (e : (Σ j : Fin k, Fin (r j)) ≃ Fin n) :
    (Fin n → ℝ) ≃ᵐ ((j : Fin k) → Fin (r j) → ℝ) where
  toFun u j l := u (e ⟨j,l⟩)
  invFun v i := v (e.symm i).1 (e.symm i).2
  left_inv u := by funext i; simp
  right_inv v := by
    funext j l
    exact congrArg (fun z : Σ j : Fin k, Fin (r j) => v z.1 z.2) (e.symm_apply_apply ⟨j,l⟩)
  measurable_toFun := measurable_pi_lambda _ (fun j =>
    measurable_pi_lambda _ (fun l => measurable_pi_apply (e ⟨j,l⟩)))
  measurable_invFun := measurable_pi_lambda _ (fun i =>
    (measurable_pi_apply (e.symm i).2).comp (measurable_pi_apply (e.symm i).1))

@[simp] theorem blockCoordinates_apply {n k : ℕ} {r : Fin k → ℕ}
    (e : (Σ j : Fin k, Fin (r j)) ≃ Fin n) (u : Fin n → ℝ) (j : Fin k) (l : Fin (r j)) :
    blockCoordinates e u j l = u (e ⟨j,l⟩) := rfl

@[simp] theorem blockCoordinates_symm_apply {n k : ℕ} {r : Fin k → ℕ}
    (e : (Σ j : Fin k, Fin (r j)) ≃ Fin n) (v : (j : Fin k) → Fin (r j) → ℝ) (i : Fin n) :
    (blockCoordinates e).symm v i = v (e.symm i).1 (e.symm i).2 := rfl

/-- Grouping the genuine product Lebesgue coordinates preserves their
measure exactly. This is proved on rectangles, including zero-dimensional blocks. -/
theorem blockCoordinates_measurePreserving {n k : ℕ} {r : Fin k → ℕ}
    (e : (Σ j : Fin k, Fin (r j)) ≃ Fin n) :
    MeasurePreserving (blockCoordinates e) volume volume := by
  have h : MeasurePreserving (blockCoordinates e).symm volume volume := by
    refine ⟨(blockCoordinates e).symm.measurable, ?_⟩
    rw [volume_pi (α := fun _ : Fin n => ℝ)]
    refine (Measure.pi_eq (fun s hs => ?_)).symm
    rw [Measure.map_apply (blockCoordinates e).symm.measurable (MeasurableSet.univ_pi hs)]
    have hp : (blockCoordinates e).symm ⁻¹' (univ.pi s) =
        univ.pi (fun j => univ.pi (fun l : Fin (r j) => s (e ⟨j,l⟩))) := by
      ext v
      simp only [mem_preimage, mem_pi, mem_univ, forall_const, blockCoordinates_symm_apply]
      constructor
      · intro hv j l
        have hx := hv (e ⟨j,l⟩)
        have he := congrArg (fun z : Σ j : Fin k, Fin (r j) => v z.1 z.2) (e.symm_apply_apply ⟨j,l⟩)
        change v (e.symm (e ⟨j,l⟩)).1 (e.symm (e ⟨j,l⟩)).2 = v j l at he
        rw [he] at hx
        exact hx
      · intro hv i
        simpa using hv (e.symm i).1 (e.symm i).2
    rw [hp, volume_pi_pi]
    simp_rw [volume_pi_pi]
    rw [← Fintype.prod_sigma (fun p : Σ j : Fin k, Fin (r j) => volume (s (e p)))]
    exact e.prod_comp (fun i => volume (s i))
  exact h.symm

/-- Exact number of interaction vertices assigned to each external gap. -/
def gapCount {n k : ℕ} (g : Fin n → Fin k) (j : Fin k) : ℕ :=
  Fintype.card {i : Fin n // g i = j}

/-- Enumerate each gap's original labels in their original increasing order. -/
def fiberOrder {n k : ℕ} (g : Fin n → Fin k) (j : Fin k) :
    Fin (gapCount g j) ≃o {i : Fin n // g i = j} :=
  Fintype.orderIsoFinOfCardEq _ rfl

/-- The canonical coordinate-label bijection determined by gap assignment. -/
def fiberIndexEquiv {n k : ℕ} (g : Fin n → Fin k) :
    (Σ j : Fin k, Fin (gapCount g j)) ≃ Fin n :=
  (Equiv.sigmaCongrRight (fun j => (fiberOrder g j).toEquiv)).trans (Equiv.sigmaFiberEquiv g)

@[simp] theorem fiberIndexEquiv_apply {n k : ℕ} (g : Fin n → Fin k)
    (j : Fin k) (l : Fin (gapCount g j)) :
    fiberIndexEquiv g ⟨j,l⟩ = (fiberOrder g j l).val := rfl

@[simp] theorem gap_fiberIndexEquiv {n k : ℕ} (g : Fin n → Fin k)
    (j : Fin k) (l : Fin (gapCount g j)) :
    g (fiberIndexEquiv g ⟨j,l⟩) = j := (fiberOrder g j l).property

/-- Every original coordinate has a unique place in its ordered gap block. -/
theorem exists_fiberIndex {n k : ℕ} (g : Fin n → Fin k) (i : Fin n) :
    ∃ l : Fin (gapCount g (g i)), fiberIndexEquiv g ⟨g i,l⟩ = i := by
  refine ⟨(fiberOrder g (g i)).symm ⟨i,rfl⟩, ?_⟩
  simp

/-- Gap counts sum to the actual total number of labelled vertices. -/
theorem sum_gapCount {n k : ℕ} (g : Fin n → Fin k) : ∑ j, gapCount g j = n := by
  have h := Fintype.card_congr (fiberIndexEquiv g)
  simpa only [Fintype.card_sigma, Fintype.card_fin] using h

/-- Away from the fixed insertion times, the chamber is exactly a product
of ordered simplexes in its canonical coordinate blocks. -/
theorem mem_orderedAssignmentRegion_iff_blocks {n k : ℕ}
    (t : Fin (k+1) → ℝ) (ht : Antitone t) (g : Fin n → Fin k) (hg : Monotone g)
    (u : Fin n → ℝ) (ha : ∀ j i, u i ≠ t j) :
    u ∈ orderedAssignmentRegion t g ↔
      blockCoordinates (fiberIndexEquiv g) u ∈
        gapSimplex (gapCount g) (fun j => t j.succ) (fun j => t j.castSucc) := by
  constructor
  · intro hu j _
    refine ⟨?_, ?_, ?_⟩
    · intro l
      have h := hu.2 (fiberIndexEquiv g ⟨j,l⟩) (mem_univ _)
      simpa only [gapInterval, gap_fiberIndexEquiv, mem_Ioo, blockCoordinates_apply] using h.1.le
    · intro l
      have h := hu.2 (fiberIndexEquiv g ⟨j,l⟩) (mem_univ _)
      simpa only [gapInterval, gap_fiberIndexEquiv, mem_Ioo, blockCoordinates_apply] using h.2.le
    · intro l m hlm
      exact hu.1.2.2 ((fiberOrder g j).monotone hlm)
  · intro hv
    have hb (i : Fin n) : t (g i).succ ≤ u i ∧ u i ≤ t (g i).castSucc := by
      obtain ⟨l, hl⟩ := exists_fiberIndex g i
      have hh := hv (g i) (mem_univ _)
      exact ⟨by simpa only [blockCoordinates_apply, hl] using hh.1 l,
        by simpa only [blockCoordinates_apply, hl] using hh.2.1 l⟩
    have ha' : u ∈ assignmentRegion t g := by
      intro i _
      exact ⟨lt_of_le_of_ne (hb i).1 (ha _ i).symm,
        lt_of_le_of_ne (hb i).2 (ha _ i)⟩
    refine ⟨⟨?_, ?_, ?_⟩, ha'⟩
    · intro i
      exact (gapInterval_subset_bounds t ht (g i) (ha' i (mem_univ _))).1
    · intro i
      exact (gapInterval_subset_bounds t ht (g i) (ha' i (mem_univ _))).2
    · intro i j hij
      rcases eq_or_lt_of_le (hg hij) with heq | hlt
      · have hlocal := (hv (g i) (mem_univ _)).2.2
          ((fiberOrder g (g i)).symm.monotone
            (show (⟨i,rfl⟩ : {l : Fin n // g l = g i}) ≤ ⟨j,heq.symm⟩ from hij))
        simpa only [blockCoordinates_apply, fiberIndexEquiv_apply, OrderIso.apply_symm_apply] using hlocal
      · have he : (g i).succ ≤ (g j).castSucc := by
          simpa only [Fin.le_iff_val_le_val, Fin.val_succ, Fin.coe_castSucc]
            using Nat.succ_le_of_lt hlt
        exact (hb j).2.trans ((ht he).trans (hb i).1)

theorem orderedAssignmentRegion_ae_blocks {n k : ℕ}
    (t : Fin (k+1) → ℝ) (ht : Antitone t) (g : Fin n → Fin k) (hg : Monotone g) :
    orderedAssignmentRegion t g =ᵐ[volume]
      blockCoordinates (fiberIndexEquiv g) ⁻¹'
        gapSimplex (gapCount g) (fun j => t j.succ) (fun j => t j.castSucc) := by
  filter_upwards [ae_avoid_boundaries n t] with u hu
  exact propext (mem_orderedAssignmentRegion_iff_blocks t ht g hg u hu)

/-- Actual chamber volume equals the product of the factorial-normalized
gap volumes determined by its own vertex counts. -/
theorem orderedAssignmentRegion_volume_real {n k : ℕ}
    (t : Fin (k+1) → ℝ) (ht : Antitone t) (g : Fin n → Fin k) (hg : Monotone g) :
    volume.real (orderedAssignmentRegion t g) =
      ∏ j, (t j.castSucc-t j.succ)^(gapCount g j) / (gapCount g j).factorial := by
  rw [measureReal_def, measure_congr (orderedAssignmentRegion_ae_blocks t ht g hg),
    (blockCoordinates_measurePreserving (fiberIndexEquiv g)).measure_preimage
      (gapSimplex_measurable _ _ _).nullMeasurableSet]
  exact gapSimplex_volume_real _ _ _ (fun j => ht (by simp [Fin.le_iff_val_le_val]))

/-- Exact change of variables from a genuine global ordered chamber to its
dependent product of gap simplexes, for every Banach-valued history. -/
theorem integral_orderedAssignmentRegion_eq_blocks {E : Type*}
    [NormedAddCommGroup E] [NormedSpace ℝ E] {n k : ℕ}
    (t : Fin (k+1) → ℝ) (ht : Antitone t) (g : Fin n → Fin k) (hg : Monotone g)
    (f : (Fin n → ℝ) → E) :
    ∫ u in orderedAssignmentRegion t g, f u =
      ∫ v in gapSimplex (gapCount g) (fun j => t j.succ) (fun j => t j.castSucc),
        f ((blockCoordinates (fiberIndexEquiv g)).symm v) := by
  rw [setIntegral_congr_set (orderedAssignmentRegion_ae_blocks t ht g hg)]
  have h := (blockCoordinates_measurePreserving (fiberIndexEquiv g)).setIntegral_preimage_emb
    (blockCoordinates (fiberIndexEquiv g)).measurableEmbedding
    (fun v => f ((blockCoordinates (fiberIndexEquiv g)).symm v))
    (gapSimplex (gapCount g) (fun j => t j.succ) (fun j => t j.castSucc))
  simpa only [MeasurableEquiv.symm_apply_apply] using h

end SYK.GapChamberCoordinates
