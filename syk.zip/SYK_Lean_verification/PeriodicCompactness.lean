import MomentCompactness
import Mathlib.Algebra.Order.ToIntervalMod
import Mathlib.Algebra.Ring.Periodic

noncomputable section
open Set Filter Function
open scoped Topology
namespace SYK.Continuum

def periodRepresentative (P : ℝ) (hP : 0 < P) (t : ℝ) : Icc (0 : ℝ) P :=
  ⟨toIcoMod hP 0 t, (toIcoMod_mem_Ico' hP t).1, (toIcoMod_mem_Ico' hP t).2.le⟩

theorem periodic_eq_representative (P : ℝ) (hP : 0 < P) (f : ℝ → ℝ)
    (hf : Periodic f P) (t : ℝ) : f (periodRepresentative P hP t) = f t := by
  change f (t - toIcoDiv hP 0 t • P) = f t
  exact hf.sub_zsmul_eq _

/-- Periodicity upgrades compact-interval extraction to uniform convergence
on the entire real line. -/
theorem periodic_uniform_subsequence (P : ℝ) (hP : 0 < P)
    (f : ℕ → ℝ → ℝ) (B K : ℝ) (hK : 0 ≤ K)
    (hper : ∀ n, Periodic (f n) P) (hb : ∀ n t, |f n t| ≤ B)
    (hlip : ∀ n, LipschitzWith ⟨K, hK⟩ (f n)) :
    ∃ (φ : ℕ → ℕ) (g : ℝ → ℝ), StrictMono φ ∧
      TendstoUniformly (fun n => f (φ n)) g atTop ∧
      LipschitzWith ⟨K, hK⟩ g ∧ (∀ t, |g t| ≤ B) := by
  letI : Nonempty (Icc (0 : ℝ) P) := ⟨⟨0, le_rfl, hP.le⟩⟩
  obtain ⟨φ, q, hφ, hq, _, hqb⟩ := MomentCompactness.uniform_subsequence
    (fun n (t : Icc (0 : ℝ) P) => f n t) 0 B K hK (fun _ => 0) tendsto_const_nhds
    (fun n t => by simpa only [Real.dist_eq, sub_zero] using hb n t)
    (fun n s t => by simpa only [add_zero, Subtype.dist_eq] using (hlip n).dist_le_mul s.val t.val)
  let g := q ∘ periodRepresentative P hP
  have hu : TendstoUniformly (fun n => f (φ n)) g atTop := by
    have he := hq.comp (periodRepresentative P hP)
    convert he using 1
    ext n t
    exact (periodic_eq_representative P hP (f (φ n)) (hper (φ n)) t).symm
  refine ⟨φ, g, hφ, hu, ?_, ?_⟩
  · apply LipschitzWith.of_dist_le_mul
    intro s t
    exact le_of_tendsto ((hu.tendsto_at s).dist (hu.tendsto_at t))
      (Eventually.of_forall (fun n => (hlip (φ n)).dist_le_mul s t))
  · intro t
    simpa only [Real.dist_eq, sub_zero] using hqb (periodRepresentative P hP t)

end SYK.Continuum
