import FourierOperators

/-!
# Literal physical integral action on arbitrary bounded complex tests

Real and imaginary parts extend the previously checked real-test action to
all bounded measurable complex kernels. The resulting L² representative is
proved to be the actual half-frequency twist, and the output is the literal
nested Lebesgue integral defining minus CΣ.
-/
noncomputable section
open MeasureTheory Filter Set
open scoped Topology NNReal
namespace SYK.ComplexFourierOperatorAction
open Continuum FourierOperators

variable (β : ℝ) [Fact (0 < β)]

theorem re_bound (h : ℝ → ℂ) (D : ℝ) (hd : ∀ t, ‖h t‖ ≤ D) (t : ℝ) :
    |(h t).re| ≤ D := (Complex.abs_re_le_norm _).trans (hd t)

theorem im_bound (h : ℝ → ℂ) (D : ℝ) (hd : ∀ t, ‖h t‖ ≤ D) (t : ℝ) :
    |(h t).im| ≤ D := (Complex.abs_im_le_norm _).trans (hd t)

/-- The actual complex test in the twisted time-domain Hilbert space. -/
def complexCircleL2 (h : ℝ → ℂ) (hm : Measurable h) (D : ℝ)
    (hd : ∀ t, ‖h t‖ ≤ D) : TimeHilbert β :=
  circleL2 β (fun t => (h t).re) (Complex.measurable_re.comp hm) D (re_bound h D hd) +
    Complex.I • circleL2 β (fun t => (h t).im) (Complex.measurable_im.comp hm) D (im_bound h D hd)

def complexCircleLift (h : ℝ → ℂ) : AddCircle β → ℂ :=
  AddCircle.liftIoc β 0 (fun t =>
    Complex.exp (Complex.I * ((Real.pi*t/β : ℝ) : ℂ)) * h t)

theorem complexCircleL2_coe (h : ℝ → ℂ) (hm : Measurable h) (D : ℝ)
    (hd : ∀ t, ‖h t‖ ≤ D) :
    (complexCircleL2 β h hm D hd : AddCircle β → ℂ) =ᵐ[AddCircle.haarAddCircle]
      complexCircleLift β h := by
  unfold complexCircleL2
  filter_upwards [Lp.coeFn_add
      (circleL2 β (fun t => (h t).re) (Complex.measurable_re.comp hm) D (re_bound h D hd))
      (Complex.I • circleL2 β (fun t => (h t).im) (Complex.measurable_im.comp hm) D (im_bound h D hd)),
    Lp.coeFn_smul Complex.I (circleL2 β (fun t => (h t).im) (Complex.measurable_im.comp hm) D (im_bound h D hd)),
    (circleLift_memLp β (fun t => (h t).re) (Complex.measurable_re.comp hm) D (re_bound h D hd)).coeFn_toLp,
    (circleLift_memLp β (fun t => (h t).im) (Complex.measurable_im.comp hm) D (im_bound h D hd)).coeFn_toLp]
    with t ha hi hr hj
  simp only [Pi.add_apply, Pi.smul_apply, smul_eq_mul] at ha hi
  rw [ha, hi]
  change (circleL2 β (fun t => (h t).re) (Complex.measurable_re.comp hm) D (re_bound h D hd) : AddCircle β → ℂ) t = _ at hr
  change (circleL2 β (fun t => (h t).im) (Complex.measurable_im.comp hm) D (im_bound h D hd) : AddCircle β → ℂ) t = _ at hj
  rw [hr, hj]
  change _ * ((h _).re : ℂ) + Complex.I * (_ * ((h _).im : ℂ)) = _ * h _
  conv_rhs => rw [← Complex.re_add_im (h _)]
  ring

/-- Ordinary Lebesgue convolution with a real scalar kernel. -/
def complexConvolution (k : ℝ → ℝ) (h : ℝ → ℂ) (t : ℝ) : ℂ :=
  ∫ u in (0:ℝ)..β, (k (t-u) : ℂ) * h u

theorem real_product_integrable (k r : ℝ → ℝ) (hk : Measurable k) (hr : Measurable r)
    (B D : ℝ) (hb : ∀ t, |k t| ≤ B) (hd : ∀ t, |r t| ≤ D) (t : ℝ) :
    IntervalIntegrable (fun u => (k (t-u) : ℂ) * (r u : ℂ)) volume 0 β := by
  apply (intervalIntegrable_const (c := B*D)).mono_fun'
  · exact ((hk.comp (measurable_const.sub measurable_id)).complex_ofReal.mul
      hr.complex_ofReal).aestronglyMeasurable
  · filter_upwards [] with u
    simp only [norm_mul, Complex.norm_real, Real.norm_eq_abs]
    exact mul_le_mul (hb _) (hd _) (abs_nonneg _) ((abs_nonneg (k 0)).trans (hb 0))

theorem complexConvolution_split (k : ℝ → ℝ) (h : ℝ → ℂ)
    (hk : Measurable k) (hm : Measurable h) (B D : ℝ)
    (hb : ∀ t, |k t| ≤ B) (hd : ∀ t, ‖h t‖ ≤ D) (t : ℝ) :
    complexConvolution β k h t =
      (scalarConvolution β k (fun u => (h u).re) t : ℂ) +
        Complex.I * (scalarConvolution β k (fun u => (h u).im) t : ℂ) := by
  have hr := real_product_integrable β k (fun u => (h u).re) hk (Complex.measurable_re.comp hm) B D hb (re_bound h D hd) t
  have hi := real_product_integrable β k (fun u => (h u).im) hk (Complex.measurable_im.comp hm) B D hb (im_bound h D hd) t
  unfold complexConvolution
  calc
    _ = ∫ u in (0:ℝ)..β, (k (t-u):ℂ)*(h u).re +
        Complex.I*((k (t-u):ℂ)*(h u).im) := by
      apply intervalIntegral.integral_congr
      intro u _
      dsimp only
      conv_lhs => rw [← Complex.re_add_im (h u)]
      ring
    _ = _ := by
      rw [intervalIntegral.integral_add hr (hi.const_mul Complex.I),
        intervalIntegral.integral_const_mul, ← ofReal_scalarConvolution,
        ← ofReal_scalarConvolution]

/-- The literal nested complex CΣ integral. -/
def complexCovarianceSource (lam : ℝ≥0) (g : ℝ → ℝ) (h : ℝ → ℂ) : ℝ → ℂ :=
  complexConvolution β (Thermal.covariance β) (complexConvolution β (source lam g) h)

theorem complexConvolution_measurable (k : ℝ → ℝ) (h : ℝ → ℂ)
    (hk : Measurable k) (hm : Measurable h) :
    Measurable (complexConvolution β k h) := by
  have hp : Measurable (fun p : ℝ×ℝ => (k (p.1-p.2):ℂ)*h p.2) :=
    ((hk.comp (measurable_fst.sub measurable_snd)).complex_ofReal).mul (hm.comp measurable_snd)
  have hi := hp.stronglyMeasurable.integral_prod_right'
    (ν := volume.restrict (Ioc (0:ℝ) β))
  change Measurable (fun t => ∫ u in (0:ℝ)..β, (k (t-u):ℂ)*h u)
  simpa only [intervalIntegral.integral_of_le (Fact.out : 0<β).le] using hi.measurable

theorem complexConvolution_bound (k : ℝ → ℝ) (h : ℝ → ℂ) (B D : ℝ)
    (hb : ∀ t, |k t| ≤ B) (hd : ∀ t, ‖h t‖ ≤ D) (t : ℝ) :
    ‖complexConvolution β k h t‖ ≤ β*(B*D) := by
  have he := intervalIntegral.norm_integral_le_of_norm_le_const
    (a := (0:ℝ)) (b := β) (C := B*D)
    (f := fun u => (k (t-u):ℂ)*h u) (fun u _ => by
      simp only [norm_mul,Complex.norm_real,Real.norm_eq_abs]
      exact mul_le_mul (hb _) (hd _) (norm_nonneg _) ((abs_nonneg (k 0)).trans (hb 0)))
  simpa only [complexConvolution,sub_zero,abs_of_pos (Fact.out : 0<β),mul_comm] using he

theorem complexCovarianceSource_split (lam : ℝ≥0) (g : ℝ → ℝ) (h : ℝ → ℂ)
    (hg : Measurable g) (hm : Measurable h) (B D : ℝ)
    (hb : ∀ t, |g t| ≤ B) (hd : ∀ t, ‖h t‖ ≤ D) (t : ℝ) :
    complexCovarianceSource β lam g h t =
      (covarianceSource β lam g (fun u => (h u).re) t : ℂ) +
        Complex.I*(covarianceSource β lam g (fun u => (h u).im) t : ℂ) := by
  have hs := source_measurable lam g hg
  have hsb := source_bound lam g B hb
  have hr : (fun u => (complexConvolution β (source lam g) h u).re) =
      scalarConvolution β (source lam g) (fun u => (h u).re) := by
    funext u
    rw [complexConvolution_split β _ h hs hm _ D hsb hd u]
    simp
  have hi : (fun u => (complexConvolution β (source lam g) h u).im) =
      scalarConvolution β (source lam g) (fun u => (h u).im) := by
    funext u
    rw [complexConvolution_split β _ h hs hm _ D hsb hd u]
    simp
  rw [complexCovarianceSource, complexConvolution_split β _ _ (Thermal.covariance_measurable β)
    (complexConvolution_measurable β _ h hs hm) (1/2) _ (Thermal.abs_covariance_le β)
    (complexConvolution_bound β _ h _ D hsb hd) t, hr, hi]
  rfl

/-- On every bounded measurable complex test, the actual Hilbert operator is
minus the literal double Lebesgue convolution CΣ, almost everywhere on the
thermal circle after its specified half-frequency twist. -/
theorem physicalPerturbation_complex_integral_action (lam : ℝ≥0) (g : ℝ → ℝ)
    (h : ℝ → ℂ) (hg : PhysicalSolution β lam g) (hm : Measurable h)
    (B D : ℝ) (hb : ∀ t, |g t| ≤ B) (hd : ∀ t, ‖h t‖ ≤ D) :
    (physicalPerturbation β lam g (complexCircleL2 β h hm D hd) : AddCircle β → ℂ)
      =ᵐ[AddCircle.haarAddCircle] -complexCircleLift β (complexCovarianceSource β lam g h) := by
  let r := fun t => (h t).re
  let i := fun t => (h t).im
  let E := β*((1/2)*(β*((lam:ℝ)*B^3*D)))
  let cr := circleL2 β (covarianceSource β lam g r)
    (covarianceSource_measurable β lam g r hg.1 (Complex.measurable_re.comp hm)) E
    (covarianceSource_bound β lam g r B D hb (re_bound h D hd))
  let ci := circleL2 β (covarianceSource β lam g i)
    (covarianceSource_measurable β lam g i hg.1 (Complex.measurable_im.comp hm)) E
    (covarianceSource_bound β lam g i B D hb (im_bound h D hd))
  have he : physicalPerturbation β lam g (complexCircleL2 β h hm D hd) = -(cr+Complex.I • ci) := by
    unfold complexCircleL2
    rw [map_add,map_smul,
      physicalPerturbation_integral_action β lam g r hg (Complex.measurable_re.comp hm)
        B D hb (re_bound h D hd),
      physicalPerturbation_integral_action β lam g i hg (Complex.measurable_im.comp hm)
        B D hb (im_bound h D hd)]
    change -cr + Complex.I • (-ci) = -(cr+Complex.I • ci)
    module
  rw [he]
  have hcr : (cr : AddCircle β → ℂ) =ᵐ[AddCircle.haarAddCircle]
      circleLift β (covarianceSource β lam g r) :=
    (circleLift_memLp β (covarianceSource β lam g r)
      (covarianceSource_measurable β lam g r hg.1 (Complex.measurable_re.comp hm)) E
      (covarianceSource_bound β lam g r B D hb (re_bound h D hd))).coeFn_toLp
  have hci : (ci : AddCircle β → ℂ) =ᵐ[AddCircle.haarAddCircle]
      circleLift β (covarianceSource β lam g i) :=
    (circleLift_memLp β (covarianceSource β lam g i)
      (covarianceSource_measurable β lam g i hg.1 (Complex.measurable_im.comp hm)) E
      (covarianceSource_bound β lam g i B D hb (im_bound h D hd))).coeFn_toLp
  filter_upwards [Lp.coeFn_neg (cr+Complex.I • ci), Lp.coeFn_add cr (Complex.I • ci),
    Lp.coeFn_smul Complex.I ci,hcr,hci] with t hn ha hs hr hi
  simp only [Pi.neg_apply,Pi.add_apply,Pi.smul_apply,smul_eq_mul] at hn ha hs ⊢
  rw [hn,ha,hs,hr,hi]
  change -(_ * (covarianceSource β lam g r _ : ℂ) +
    Complex.I*(_ * (covarianceSource β lam g i _ : ℂ))) =
    -(_ * complexCovarianceSource β lam g h _)
  rw [complexCovarianceSource_split β lam g h hg.1 hm B D hb hd]
  ring

end SYK.ComplexFourierOperatorAction
