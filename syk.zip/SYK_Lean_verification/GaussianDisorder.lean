import Mathlib.Probability.Distributions.Gaussian
import Mathlib.MeasureTheory.Constructions.Pi
import Mathlib.MeasureTheory.Integral.Bochner.Basic
import Mathlib.MeasureTheory.Integral.Pi

/-!
# The finite product Gaussian disorder law

The index type will be instantiated with the increasing four-subsets of the
Majorana flavors. The variance is exactly 6 lam / N^3. These definitions use
actual probability measures, not an abstract expectation functional.
This file alone does not prove the interacting pressure limit.
-/

noncomputable section
open MeasureTheory ProbabilityTheory
open scoped BigOperators NNReal

namespace SYK.GaussianDisorder

variable (ι : Type*) [Fintype ι]

def variance (N : ℕ) (lam : ℝ≥0) : ℝ≥0 := 6 * lam / (N : ℝ≥0)^3

def law (N : ℕ) (lam : ℝ≥0) : Measure (ι → ℝ) :=
  Measure.pi (fun _ : ι => gaussianReal 0 (variance N lam))

instance law_isProbabilityMeasure (N : ℕ) (lam : ℝ≥0) :
    IsProbabilityMeasure (law ι N lam) := by
  unfold law
  infer_instance

@[simp] theorem variance_zero (N : ℕ) : variance N 0 = 0 := by
  simp [variance]

theorem pi_dirac_real (x : ι → ℝ) :
    Measure.pi (fun i => Measure.dirac (x i)) = Measure.dirac x := by
  classical
  apply Measure.pi_eq
  intro s hs
  simp only [Measure.dirac_apply, Set.indicator_apply, Pi.one_apply]
  simp [Fintype.prod_ite_zero, Set.mem_pi]

@[simp] theorem law_zero (N : ℕ) :
    law ι N 0 = Measure.dirac (0 : ι → ℝ) := by
  simp only [law, variance_zero, gaussianReal_zero_var]
  exact pi_dirac_real ι 0

/-- Every real exponential moment of one coupling exists. -/
theorem integrable_exp_linear (v : ℝ≥0) (c : ℝ) :
    Integrable (fun x : ℝ => Real.exp (c * x)) (gaussianReal 0 v) := by
  have h := mgf_gaussianReal (X := id) (p := gaussianReal 0 v) (μ := 0) (v := v)
    (by simp) c
  simp only [mgf, id_eq, zero_mul, zero_add] at h
  by_contra hn
  rw [integral_undef hn] at h
  exact (Real.exp_ne_zero _ h.symm)

/-- The absolute-value exponential majorant used in the Duhamel expansion. -/
theorem integrable_exp_abs (v : ℝ≥0) (c : ℝ) :
    Integrable (fun x : ℝ => Real.exp (c * |x|)) (gaussianReal 0 v) := by
  apply ((integrable_exp_linear v c).add (integrable_exp_linear v (-c))).mono'
  · exact (Real.continuous_exp.comp (continuous_const.mul continuous_abs)).aestronglyMeasurable
  · filter_upwards [] with x
    rw [Real.norm_eq_abs, abs_of_pos (Real.exp_pos _)]
    by_cases hx : 0 ≤ x
    · rw [abs_of_nonneg hx]
      exact le_add_of_nonneg_right (le_of_lt (Real.exp_pos _))
    · rw [abs_of_neg (lt_of_not_ge hx), mul_neg, ← neg_mul]
      exact le_add_of_nonneg_left (le_of_lt (Real.exp_pos _))

/-- Finite-dimensional Gaussian disorder makes the full Duhamel majorant integrable. -/
theorem integrable_exp_sum_abs (N : ℕ) (lam : ℝ≥0) (c : ℝ) :
    Integrable (fun j : ι → ℝ => Real.exp (c * ∑ i, |j i|)) (law ι N lam) := by
  classical
  letI : MeasureSpace ℝ := ⟨gaussianReal 0 (variance N lam)⟩
  haveI : IsProbabilityMeasure (volume : Measure ℝ) :=
    inferInstanceAs (IsProbabilityMeasure (gaussianReal 0 (variance N lam)))
  have h : Integrable (fun j : ι → ℝ => ∏ i, Real.exp (c * |j i|)) :=
    Integrable.fintype_prod (fun _ : ι => integrable_exp_abs (variance N lam) c)
  simpa only [Finset.mul_sum, Real.exp_sum, MeasureTheory.volume_pi, law] using h

/-- Both pressures use the ordinary, unnormalized partition function. -/
def annealedPressure (N : ℕ) (lam : ℝ≥0) (Z : (ι → ℝ) → ℝ) : ℝ :=
  Real.log (∫ j, Z j ∂law ι N lam) / N

def quenchedPressure (N : ℕ) (lam : ℝ≥0) (Z : (ι → ℝ) → ℝ) : ℝ :=
  (∫ j, Real.log (Z j) ∂law ι N lam) / N

@[simp] theorem annealedPressure_zero (N : ℕ) (Z : (ι → ℝ) → ℝ) :
    annealedPressure ι N 0 Z = Real.log (Z 0) / N := by
  simp [annealedPressure]

@[simp] theorem quenchedPressure_zero (N : ℕ) (Z : (ι → ℝ) → ℝ) :
    quenchedPressure ι N 0 Z = Real.log (Z 0) / N := by
  simp [quenchedPressure]

end SYK.GaussianDisorder
