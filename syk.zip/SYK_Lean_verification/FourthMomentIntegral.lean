import MomentMeasurability
import AnnealedDifferentiation
import OnShellAction
import Mathlib.MeasureTheory.Integral.IntervalIntegral.Periodic

/-! # Actual integrated fourth collective moments

These are integrals of the genuine annealed, Weyl-ordered microscopic moment.
Measurability and the sharp universal bound come from the concrete operator
construction; the time-integrated limiting formula uses actual periodicity.
-/
set_option maxHeartbeats 1000000
noncomputable section
open MeasureTheory Set Filter
open scoped NNReal Topology
namespace SYK.FourthMomentIntegral

/-- The actual thermal-time square with Lebesgue measure. -/
def timeMeasure (β : ℝ) : Measure (ℝ × ℝ) :=
  (volume.restrict (Ioc (0 : ℝ) β)).prod (volume.restrict (Ioc (0 : ℝ) β))

theorem timeMeasure_eq_closed (β : ℝ) : timeMeasure β =
    (volume.restrict (Icc (0 : ℝ) β)).prod (volume.restrict (Icc (0 : ℝ) β)) := by
  simp only [timeMeasure, restrict_Ioc_eq_restrict_Icc]

instance timeMeasure_finite (β : ℝ) : IsFiniteMeasure (timeMeasure β) := by
  unfold timeMeasure
  infer_instance

/-- Four copies of one bilocal insertion in the true microscopic moment. -/
def fourthMoment (d : ℕ) (β : ℝ) (lam : ℝ≥0) (p : ℝ × ℝ) : ℝ :=
  (Interacting.collectiveMoment d β lam (fun _ : Fin 4 => p)).re

/-- The exact derivative observable, normalized per Majorana as in the paper. -/
def fourthIntegral (d : ℕ) (β : ℝ) (lam : ℝ≥0) : ℝ :=
  (1/8 : ℝ) * ∫ p, fourthMoment d β lam p ∂timeMeasure β

theorem measurable_fourthMoment (d : ℕ) (β : ℝ) (lam : ℝ≥0) :
    Measurable (fourthMoment d β lam) := by
  exact Complex.measurable_re.comp ((MomentMeasurability.measurable_collectiveMoment d β lam 4).comp
    (measurable_pi_lambda _ fun _ => measurable_id))

theorem ae_timeSquare (β : ℝ) : ∀ᵐ p ∂timeMeasure β,
    p.1 ∈ Icc (0 : ℝ) β ∧ p.2 ∈ Icc (0 : ℝ) β := by
  apply (Measure.ae_prod_iff_ae_ae (measurableSet_Icc.prod measurableSet_Icc)).mpr
  filter_upwards [ae_restrict_mem (measurableSet_Ioc : MeasurableSet (Ioc (0 : ℝ) β))] with s hs
  filter_upwards [ae_restrict_mem (measurableSet_Ioc : MeasurableSet (Ioc (0 : ℝ) β))] with t ht
  exact ⟨⟨hs.1.le,hs.2⟩,⟨ht.1.le,ht.2⟩⟩


theorem timeMeasure_real_univ (β : ℝ) (hβ : 0 ≤ β) : (timeMeasure β).real univ = β^2 := by
  simp [timeMeasure, measureReal_def, Measure.prod_apply, Real.volume_Ioc, ENNReal.toReal_mul,
    ENNReal.toReal_ofReal hβ, pow_two]

/-- The sharp actual microscopic bound gives the fourth bilocal bound 1/16. -/
theorem fourthMoment_bound (d : ℕ) (hd : 0 < d) {β : ℝ} (hβ : 0 < β) (lam : ℝ≥0) :
    ∀ᵐ p ∂timeMeasure β, |fourthMoment d β lam p| ≤ 1/16 := by
  filter_upwards [ae_timeSquare β] with p hp
  apply (Complex.abs_re_le_norm _).trans
  have h := Interacting.collectiveMoment_bound d hd hβ lam (fun _ : Fin 4 => p)
    (fun _ => hp)
  norm_num at h ⊢
  exact h

theorem fourthMoment_integrable (d : ℕ) (hd : 0 < d) {β : ℝ} (hβ : 0 < β) (lam : ℝ≥0) :
    Integrable (fourthMoment d β lam) (timeMeasure β) :=
  (integrable_const (1/16 : ℝ)).mono' (measurable_fourthMoment d β lam).aestronglyMeasurable
    (by simpa only [Real.norm_eq_abs] using fourthMoment_bound d hd hβ lam)

/-- The derivative observable has the manuscript's exact N-independent bound. -/
theorem fourthIntegral_bound (d : ℕ) (hd : 0 < d) {β : ℝ} (hβ : 0 < β) (lam : ℝ≥0) :
    |fourthIntegral d β lam| ≤ β^2/128 := by
  have h := norm_integral_le_of_norm_le_const (μ := timeMeasure β)
    (f := fourthMoment d β lam) (C := (1/16 : ℝ))
    (by simpa only [Real.norm_eq_abs] using fourthMoment_bound d hd hβ lam)
  rw [timeMeasure_real_univ β hβ.le] at h
  unfold fourthIntegral
  rw [abs_mul, abs_of_pos (by norm_num : (0 : ℝ) < 1/8)]
  simpa only [Real.norm_eq_abs] using (mul_le_mul_of_nonneg_left h (by norm_num : (0 : ℝ) ≤ 1/8)).trans_eq (by ring)


/-- Physical antiperiodicity makes the fourth power genuinely periodic. -/
theorem physical_quartic_periodic (β : ℝ) (lam : ℝ≥0) (g : ℝ → ℝ)
    (hg : Continuum.PhysicalSolution β lam g) : Function.Periodic (fun t => (g t)^4) β := by
  intro t
  dsimp only
  rw [hg.2.2.1]
  ring

theorem stationaryQuartic_integrable (β : ℝ) (lam : ℝ≥0) (g : ℝ → ℝ)
    (hg : Continuum.PhysicalSolution β lam g) :
    Integrable (fun p : ℝ × ℝ => (g (p.1-p.2))^4) (timeMeasure β) := by
  obtain ⟨B,hB⟩ := hg.2.1
  apply (integrable_const (B^4)).mono'
  · exact ((hg.1.comp (measurable_fst.sub measurable_snd)).pow_const 4).aestronglyMeasurable
  · exact ae_of_all _ (fun p => by
      rw [Real.norm_eq_abs, abs_pow]
      exact pow_le_pow_left₀ (abs_nonneg _) (hB _) 4)

/-- Translation invariance reduces the genuine double-time integral to the
single-time quartic integral with exactly one factor β. -/
theorem stationaryQuartic_integral (β : ℝ) (hβ : 0 ≤ β) (lam : ℝ≥0) (g : ℝ → ℝ)
    (hg : Continuum.PhysicalSolution β lam g) :
    (∫ p, (g (p.1-p.2))^4 ∂timeMeasure β) = β * Continuum.quarticIntegral β g := by
  rw [show timeMeasure β = (volume.restrict (Ioc (0 : ℝ) β)).prod
    (volume.restrict (Ioc (0 : ℝ) β)) from rfl,
    integral_prod _ (stationaryQuartic_integrable β lam g hg)]
  have hinner (s : ℝ) : (∫ t in Ioc (0 : ℝ) β, (g (s-t))^4) = Continuum.quarticIntegral β g := by
    rw [← intervalIntegral.integral_of_le hβ,
      intervalIntegral.integral_comp_sub_left (fun t => (g t)^4) s]
    have h := (physical_quartic_periodic β lam g hg).intervalIntegral_add_eq (s-β) 0
    simpa [Continuum.quarticIntegral] using h
  simp only [hinner, integral_const, smul_eq_mul, measureReal_def, Measure.restrict_apply_univ,
    Real.volume_Ioc, sub_zero, ENNReal.toReal_ofReal hβ]

/-- Bounded convergence of the actual fourth moment gives the integrated
limiting derivative. No exchange-of-limits hypothesis is introduced. -/
theorem fourthIntegral_tendsto {β : ℝ} (hβ : 0 < β) (lam : ℝ≥0)
    (d : ℕ → ℕ) (hd : ∀ n, 0 < d n) (g : ℝ → ℝ)
    (hg : Continuum.PhysicalSolution β lam g)
    (hlim : ∀ᵐ p ∂timeMeasure β,
      Tendsto (fun n => fourthMoment (d n) β lam p) atTop (𝓝 ((g (p.1-p.2))^4))) :
    Tendsto (fun n => fourthIntegral (d n) β lam) atTop
      (𝓝 (β/8 * Continuum.quarticIntegral β g)) := by
  have h := tendsto_integral_filter_of_norm_le_const
    (μ := timeMeasure β) (l := atTop)
    (Eventually.of_forall fun n => (measurable_fourthMoment (d n) β lam).aestronglyMeasurable)
    ⟨(1/16 : ℝ), Eventually.of_forall fun n => by
      simpa only [Real.norm_eq_abs] using fourthMoment_bound (d n) (hd n) hβ lam⟩ hlim
  rw [stationaryQuartic_integral β hβ.le lam g hg] at h
  have hh := (tendsto_const_nhds (x := (1/8 : ℝ))).mul h
  convert hh using 1
  ring


/-- Scaling the actual Gaussian law provides a fixed-measure representation
of each unnormalized collective numerator at every coupling. -/
theorem numerator_scaled_eq (d : ℕ) (β : ℝ) (lam : ℝ≥0) {k : ℕ} (p : Fin k → ℝ × ℝ) :
    (∫ j, Interacting.collectiveNumerator d
      (Majorana.hamiltonian d (fun I => Real.sqrt (lam : ℝ) * j I)) β p ∂Microscopic.disorder d 1) =
    ∫ j, Interacting.collectiveNumerator d (Majorana.hamiltonian d j) β p ∂Microscopic.disorder d lam := by
  rw [← Microscopic.disorder_scale d lam]
  symm
  apply integral_map
  · exact (measurable_pi_lambda _ fun I => measurable_const.mul (measurable_pi_apply I)).aemeasurable
  · exact ((MomentMeasurability.measurable_collectiveNumerator d β k).comp
      (measurable_const.prodMk measurable_id)).aestronglyMeasurable

/-- Joint coupling/time measurability of the actual annealed moment, derived
by Gaussian scaling and parameter integration, not assumed from the series. -/
theorem measurable_collectiveMoment_coupling (d : ℕ) (β : ℝ) (k : ℕ) :
    Measurable (fun x : ℝ≥0 × (Fin k → ℝ × ℝ) =>
      Interacting.collectiveMoment d β x.1 x.2) := by
  let X := (ℝ≥0 × (Fin k → ℝ × ℝ)) × (Majorana.FourSet d → ℝ)
  have hs : Measurable (fun x : X => Real.sqrt (x.1.1 : ℝ)) :=
    Real.continuous_sqrt.measurable.comp
      (NNReal.continuous_coe.measurable.comp (measurable_fst.comp measurable_fst))
  have hj : Measurable (fun x : X => (fun I => Real.sqrt (x.1.1 : ℝ) * x.2 I)) :=
    measurable_pi_lambda _ (fun I => hs.mul ((measurable_pi_apply I).comp measurable_snd))
  have hp : Measurable (fun x : X => x.1.2) := measurable_snd.comp measurable_fst
  have hnum := (MomentMeasurability.measurable_collectiveNumerator d β k).comp (hp.prodMk hj)
  have hi := hnum.stronglyMeasurable.integral_prod_right'
    (ν := Microscopic.disorder d 1)
  have hZ : Continuous (fun lam : ℝ≥0 =>
      AnnealedDifferentiation.averagedPartition d β 1 (Real.sqrt (lam : ℝ))) :=
    (continuous_iff_continuousAt.mpr fun a =>
      (AnnealedDifferentiation.hasDerivAt_averagedPartition d β 1 a).continuousAt).comp
        (Real.continuous_sqrt.comp NNReal.continuous_coe)
  have hden := (Complex.continuous_ofReal.comp hZ).measurable.comp
    (measurable_fst : Measurable (Prod.fst : (ℝ≥0 × (Fin k → ℝ × ℝ)) → ℝ≥0))
  have h := hden.inv.mul hi.measurable
  simpa only [Function.comp_apply, numerator_scaled_eq, AnnealedDifferentiation.averagedPartition_sqrt_eq,
    Interacting.collectiveMoment] using h

/-- Joint measurability needed for both time and coupling dominated convergence. -/
theorem measurable_fourthMoment_coupling (d : ℕ) (β : ℝ) :
    Measurable (fun x : ℝ≥0 × (ℝ × ℝ) => fourthMoment d β x.1 x.2) := by
  have hp : Measurable (fun x : ℝ≥0 × (ℝ × ℝ) => (x.1, fun _ : Fin 4 => x.2)) :=
    measurable_fst.prodMk (measurable_pi_lambda _ fun _ => measurable_snd)
  have hm := (measurable_collectiveMoment_coupling d β 4).comp hp
  exact Complex.measurable_re.comp hm

theorem measurable_fourthIntegral (d : ℕ) (β : ℝ) : Measurable (fourthIntegral d β) := by
  have h := (measurable_fourthMoment_coupling d β).stronglyMeasurable.integral_prod_right'
    (ν := timeMeasure β)
  exact h.measurable.const_mul _

end SYK.FourthMomentIntegral
