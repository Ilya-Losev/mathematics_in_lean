import Majorana
import WickContraction
import WickThermal

/-!
# Free Clifford trace Wick recursion

The contraction recursion below is derived from the concrete CAR and cyclicity
of the ordinary matrix trace. No Gaussian or Wick identity is assumed.
Raw Clifford words contract with the symmetric flavor delta. This file proves
their identification with the actual thermal exterior functional for ordered
words and for one complete equal-time Weyl block with strictly separated
ordered insertions. Arbitrary products of several Weyl blocks and integrated
interacting Duhamel expansions remain separate obligations.
-/

noncomputable section
open scoped BigOperators

namespace SYK.FreeWick

section Algebra
variable {ι A : Type*} [Ring A] [Algebra ℂ A]

/-- An ordered operator word, including the empty word. -/
def word (x : ι → A) : List ι → A
  | [] => 1
  | a :: L => x a * word x L

omit [Algebra ℂ A] in
@[simp] theorem word_nil (x : ι → A) : word x [] = 1 := rfl
omit [Algebra ℂ A] in
@[simp] theorem word_cons (x : ι → A) (a : ι) (L : List ι) :
    word x (a :: L) = x a * word x L := rfl

omit [Algebra ℂ A] in
@[simp] theorem word_append (x : ι → A) (L K : List ι) :
    word x (L ++ K) = word x L * word x K := by
  induction L with
  | nil => simp
  | cons a L ih => simp [ih, mul_assoc]

/-- Signed contraction, recursively deleting one letter of a word. -/
def contractWord (x : ι → A) (c : ι → ι → ℂ) (a : ι) : List ι → A
  | [] => 0
  | b :: L => c a b • word x L - x b * contractWord x c a L

/-- CAR moves a distinguished generator through an arbitrary finite word. -/
theorem move_through_word (x : ι → A) (c : ι → ι → ℂ)
    (hCAR : ∀ a b, x a * x b + x b * x a = c a b • (1 : A))
    (a : ι) (L : List ι) :
    x a * word x L = contractWord x c a L +
      (-1 : ℂ) ^ L.length • (word x L * x a) := by
  induction L with
  | nil => simp [contractWord]
  | cons b L ih =>
    have hab : x a * x b = c a b • (1 : A) - x b * x a := by
      rw [← hCAR a b]; noncomm_ring
    simp only [word_cons, contractWord, List.length_cons, pow_succ]
    rw [← mul_assoc (x a), hab, sub_mul, smul_mul_assoc, one_mul,
      mul_assoc (x b) (x a), ih]
    simp only [mul_add, mul_smul_comm, smul_mul_assoc, smul_smul, mul_neg,
      mul_one, neg_smul, mul_assoc]
    abel

/-- The explicit signed list of contractions. A head contraction has positive
coefficient; every passage across a preceding letter reverses the sign. -/
def contractionTerms (c : ι → ι → ℂ) (a : ι) : List ι → List (ℂ × List ι)
  | [] => []
  | b :: L => (c a b, L) ::
      (contractionTerms c a L).map (fun t => (-t.1, b :: t.2))

/-- Every contraction removes exactly one letter. -/
theorem contractionTerms_length (c : ι → ι → ℂ) (a : ι) (L : List ι)
    (t : ℂ × List ι) (ht : t ∈ contractionTerms c a L) :
    t.2.length + 1 = L.length := by
  induction L generalizing t with
  | nil => simp [contractionTerms] at ht
  | cons b L ih =>
    simp only [contractionTerms, List.mem_cons, List.mem_map] at ht
    rcases ht with rfl | ⟨u, hu, rfl⟩
    · rfl
    · simp only [List.length_cons]
      exact congrArg Nat.succ (ih u hu)

/-- The contraction recursion is an actual finite signed sum of shorter words. -/
theorem contractWord_eq_sum (x : ι → A) (c : ι → ι → ℂ) (a : ι) (L : List ι) :
    contractWord x c a L =
      ((contractionTerms c a L).map (fun t => t.1 • word x t.2)).sum := by
  induction L with
  | nil => simp [contractWord, contractionTerms]
  | cons b L ih =>
    simp only [contractWord, contractionTerms, List.map_cons, List.sum_cons,
      List.map_map, Function.comp_def, word_cons, neg_smul]
    rw [ih, ← List.sum_map_mul_left]
    simp only [mul_smul_comm]
    rw [sub_eq_add_neg, List.sum_neg, List.map_map]
    rfl

/-- Cyclicity and CAR imply Wick's recursion for every even-length word.
The hypothesis says precisely that the tail has odd length. -/
theorem cyclic_wick_recursion (x : ι → A) (c : ι → ι → ℂ)
    (hCAR : ∀ a b, x a * x b + x b * x a = c a b • (1 : A))
    (τ : A →ₗ[ℂ] ℂ) (hcyclic : ∀ u v, τ (u * v) = τ (v * u))
    (a : ι) (L : List ι) (hodd : Odd L.length) :
    τ (word x (a :: L)) = (1 / 2 : ℂ) *
      ((contractionTerms c a L).map (fun t => t.1 * τ (word x t.2))).sum := by
  have hm := congrArg τ (move_through_word x c hCAR a L)
  rw [map_add, map_smul, hodd.neg_one_pow, neg_one_smul,
    hcyclic (word x L) (x a)] at hm
  rw [contractWord_eq_sum, map_list_sum, List.map_map] at hm
  simp only [Function.comp_def, map_smul, smul_eq_mul] at hm
  simp only [word_cons]
  linear_combination (1 / 2 : ℂ) * hm

end Algebra

/-- The normalized ordinary trace as a genuine linear functional. -/
def normalizedTraceMap (n : ℕ) :
    Matrix (Majorana.Basis n) (Majorana.Basis n) ℂ →ₗ[ℂ] ℂ :=
  ((2 : ℂ) ^ n)⁻¹ • Matrix.traceLinearMap _ _ _

@[simp] theorem normalizedTraceMap_apply (n : ℕ)
    (A : Matrix (Majorana.Basis n) (Majorana.Basis n) ℂ) :
    normalizedTraceMap n A = Majorana.normalizedTrace n A := by
  simp [normalizedTraceMap, Majorana.normalizedTrace, div_eq_mul_inv, mul_comm]

@[simp] theorem normalizedTraceMap_one (n : ℕ) : normalizedTraceMap n 1 = 1 := by
  simp

theorem normalizedTraceMap_cyclic (n : ℕ)
    (A B : Matrix (Majorana.Basis n) (Majorana.Basis n) ℂ) :
    normalizedTraceMap n (A * B) = normalizedTraceMap n (B * A) := by
  simp only [normalizedTraceMap_apply, Majorana.normalizedTrace, Matrix.trace_mul_comm A B]

/-- The scalar delta appearing in the normalized Majorana CAR. -/
def flavorDelta {n : ℕ} (a b : Fin (2 * n)) : ℂ := if a = b then 1 else 0

/-- The concrete free finite-dimensional Clifford trace obeys Wick recursion
at all even word lengths, without a Wick postulate. -/
theorem majorana_wick_recursion (n : ℕ) (a : Fin (2 * n))
    (L : List (Fin (2 * n))) (hodd : Odd L.length) :
    Majorana.normalizedTrace n (word (Majorana.chiFin n) (a :: L)) =
      (1 / 2 : ℂ) * ((contractionTerms flavorDelta a L).map
        (fun t => t.1 * Majorana.normalizedTrace n (word (Majorana.chiFin n) t.2))).sum := by
  have hCAR : ∀ i j : Fin (2 * n),
      Majorana.chiFin n i * Majorana.chiFin n j +
        Majorana.chiFin n j * Majorana.chiFin n i =
          flavorDelta i j • (1 : Matrix (Majorana.Basis n) (Majorana.Basis n) ℂ) := by
    intro i j
    rw [Majorana.chiFin_car]
    by_cases h : i = j <;> simp [flavorDelta, h]
  simpa only [normalizedTraceMap_apply] using
    cyclic_wick_recursion (Majorana.chiFin n) flavorDelta hCAR
      (normalizedTraceMap n) (normalizedTraceMap_cyclic n) a L hodd

/-- A contraction never reorders the remaining letters. -/
theorem contractionTerms_sublist {ι : Type*} (c : ι → ι → ℂ) (a : ι) (L : List ι)
    (t : ℂ × List ι) (ht : t ∈ contractionTerms c a L) : t.2.Sublist L := by
  induction L generalizing t with
  | nil => simp [contractionTerms] at ht
  | cons b L ih =>
    simp only [contractionTerms, List.mem_cons, List.mem_map] at ht
    rcases ht with rfl | ⟨u, hu, rfl⟩
    · exact List.Sublist.cons _ (List.Sublist.refl _)
    · exact List.Sublist.cons₂ _ (ih u hu)

section ExteriorComparison
variable {ι A M : Type*} [Ring A] [Algebra ℂ A]
  [AddCommGroup M] [Module ℂ M]

/-- Exterior contraction uses the same deletion algorithm, with half the CAR
coefficient whenever the distinguished letter precedes the other letters. -/
theorem exterior_contraction_eq (C : Wick.Covariance ℂ M) (v : ι → M)
    (c : ι → ι → ℂ) (a : ι) (L : List ι)
    (hmatch : ∀ b ∈ L, C.form (v a) (v b) = (1 / 2 : ℂ) * c a b) :
    C.contraction (v a) (word (fun i => ExteriorAlgebra.ι ℂ (v i)) L) =
      (1 / 2 : ℂ) • contractWord (fun i => ExteriorAlgebra.ι ℂ (v i)) c a L := by
  induction L with
  | nil => simp [contractWord]
  | cons b L ih =>
    rw [word_cons, C.contraction_ι_mul, hmatch b (by simp),
      ih (fun k hk => hmatch k (by simp [hk]))]
    simp only [contractWord, smul_sub, smul_smul, mul_smul_comm]

/-- The exterior functional has the same finite contraction expansion when
its covariance matches the ordered CAR pairings. -/
theorem exterior_wick_recursion (C : Wick.Covariance ℂ M) (v : ι → M)
    (c : ι → ι → ℂ) (a : ι) (L : List ι)
    (hmatch : ∀ b ∈ L, C.form (v a) (v b) = (1 / 2 : ℂ) * c a b) :
    C.expectation (word (fun i => ExteriorAlgebra.ι ℂ (v i)) (a :: L)) =
      (1 / 2 : ℂ) * ((contractionTerms c a L).map
        (fun t => t.1 * C.expectation (word (fun i => ExteriorAlgebra.ι ℂ (v i)) t.2))).sum := by
  rw [word_cons, C.expectation_ι_mul, exterior_contraction_eq C v c a L hmatch,
    map_smul, contractWord_eq_sum, map_list_sum, List.map_map]
  simp only [Function.comp_def, map_smul, smul_eq_mul]

/-- Equality with the constructed exterior Wick functional for every even word
whose ordered pair covariances are half the CAR coefficients. The Wick rule on
the operator side is proved above, not an assumption of this theorem. -/
theorem cyclic_trace_eq_exterior (x : ι → A) (c : ι → ι → ℂ)
    (hCAR : ∀ a b, x a * x b + x b * x a = c a b • (1 : A))
    (τ : A →ₗ[ℂ] ℂ) (hcyclic : ∀ u v, τ (u * v) = τ (v * u))
    (hone : τ 1 = 1) (C : Wick.Covariance ℂ M) (v : ι → M)
    (L : List ι) (heven : Even L.length)
    (hordered : L.Pairwise (fun a b => C.form (v a) (v b) = (1 / 2 : ℂ) * c a b)) :
    τ (word x L) = C.expectation (word (fun i => ExteriorAlgebra.ι ℂ (v i)) L) := by
  have main : ∀ k : ℕ, ∀ L : List ι, L.length = k → Even L.length →
      L.Pairwise (fun a b => C.form (v a) (v b) = (1 / 2 : ℂ) * c a b) →
      τ (word x L) = C.expectation (word (fun i => ExteriorAlgebra.ι ℂ (v i)) L) := by
    intro k
    induction k using Nat.strong_induction_on with
    | h k ih =>
      intro L hlen heven hordered
      cases L with
      | nil => simp [hone]
      | cons a L =>
        have hodd : Odd L.length := by
          simpa only [List.length_cons, Nat.even_add_one, Nat.not_even_iff_odd] using heven
        obtain ⟨hhead, htail⟩ := List.pairwise_cons.mp hordered
        rw [cyclic_wick_recursion x c hCAR τ hcyclic a L hodd,
          exterior_wick_recursion C v c a L hhead]
        congr 1
        apply congrArg List.sum
        apply List.map_congr_left
        intro t ht
        congr 1
        have hshort := contractionTerms_length c a L t ht
        have hsub := contractionTerms_sublist c a L t ht
        apply ih t.2.length (by simp only [List.length_cons] at hlen; omega) t.2 rfl
        · rw [Nat.even_iff]
          have hp := Nat.odd_iff.mp hodd
          omega
        · exact htail.sublist hsub
  exact main L.length L rfl heven hordered

end ExteriorComparison

/-- When every pair of equal-flavor letters has decreasing continuous times, every even free
Majorana word equals the actual thermal exterior Wick expectation. -/
theorem thermal_trace_of_ordered_equal_flavors (n : ℕ) (β : ℝ) (hβ : 0 < β)
    (L : List (ThermalWick.Label (2 * n) β)) (heven : Even L.length)
    (hordered : L.Pairwise (fun p q => q.2.val < p.2.val ∨ p.1 ≠ q.1)) :
    Majorana.normalizedTrace n (word (fun p => Majorana.chiFin n p.1) L) =
      ThermalWick.expectation (2 * n) β
        (word (fun p => ThermalWick.field p.1 p.2) L) := by
  let x : ThermalWick.Label (2 * n) β → Matrix (Majorana.Basis n) (Majorana.Basis n) ℂ :=
    fun p => Majorana.chiFin n p.1
  let c : ThermalWick.Label (2 * n) β → ThermalWick.Label (2 * n) β → ℂ :=
    fun p q => flavorDelta p.1 q.1
  have hCAR : ∀ p q, x p * x q + x q * x p = c p q • (1 : Matrix (Majorana.Basis n) (Majorana.Basis n) ℂ) := by
    intro p q
    dsimp [x, c]
    rw [Majorana.chiFin_car]
    by_cases h : p.1 = q.1 <;> simp [flavorDelta, h]
  have hmatch : L.Pairwise (fun p q =>
      (ThermalWick.covariance (2 * n) β).form (Finsupp.single p 1) (Finsupp.single q 1) =
        (1 / 2 : ℂ) * c p q) := by
    apply hordered.imp
    intro p q hpq
    rcases p with ⟨i, s⟩
    rcases q with ⟨j, t⟩
    rw [ThermalWick.covariance_single]
    by_cases hij : i = j
    · have ht : t.val < s.val := hpq.resolve_right (not_not_intro hij)
      have hk : Thermal.kernel β s.val t.val = (1 / 2 : ℝ) := by
        rw [Thermal.kernel_on_fundamental β hβ _ _ s.property t.property]
        simp [Thermal.halfSign, sub_pos.mpr ht]
      simp [hk, c, flavorDelta, hij]
    · simp [c, flavorDelta, hij]
  simpa only [normalizedTraceMap_apply, ThermalWick.expectation, ThermalWick.field, x] using
    cyclic_trace_eq_exterior x c hCAR (normalizedTraceMap n) (normalizedTraceMap_cyclic n)
      (normalizedTraceMap_one n) (ThermalWick.covariance (2 * n) β)
      (fun p => Finsupp.single p 1) L heven hmatch

/-- The free trace/Wick correspondence at strictly ordered distinct times. -/
theorem ordered_thermal_trace (n : ℕ) (β : ℝ) (hβ : 0 < β)
    (L : List (ThermalWick.Label (2 * n) β)) (heven : Even L.length)
    (hordered : L.Pairwise (fun p q => q.2.val < p.2.val)) :
    Majorana.normalizedTrace n (word (fun p => Majorana.chiFin n p.1) L) =
      ThermalWick.expectation (2 * n) β
        (word (fun p => ThermalWick.field p.1 p.2) L) := by
  exact thermal_trace_of_ordered_equal_flavors n β hβ L heven
    (hordered.imp (fun h => Or.inl h))

/-- Equal-time blocks with distinct flavors also satisfy the trace/Wick
correspondence. This covers the four distinct flavors in each SYK vertex. -/
theorem weakly_ordered_thermal_trace (n : ℕ) (β : ℝ) (hβ : 0 < β)
    (L : List (ThermalWick.Label (2 * n) β)) (heven : Even L.length)
    (hordered : L.Pairwise (fun p q => q.2.val ≤ p.2.val ∧
      (q.2.val = p.2.val → p.1 ≠ q.1))) :
    Majorana.normalizedTrace n (word (fun p => Majorana.chiFin n p.1) L) =
      ThermalWick.expectation (2 * n) β
        (word (fun p => ThermalWick.field p.1 p.2) L) := by
  apply thermal_trace_of_ordered_equal_flavors n β hβ L heven
  apply hordered.imp
  intro p q h
  rcases lt_or_eq_of_le h.1 with hlt | heq
  · exact Or.inl hlt
  · exact Or.inr (h.2 heq)

/-- The genuine factorial-normalized Weyl antisymmetrization of an equal-time
block, defined by the sum over every permutation of its operators. -/
def weylBlock (n k : ℕ) (v : Fin k → Fin (2 * n)) :
    Matrix (Majorana.Basis n) (Majorana.Basis n) ℂ :=
  (k.factorial : ℂ)⁻¹ •
    (MultilinearMap.mkPiAlgebraFin ℂ k
      (Matrix (Majorana.Basis n) (Majorana.Basis n) ℂ)).alternatization
        (fun i => Majorana.chiFin n (v i))

/-- Repeating a flavor in a Weyl block is exactly zero, at arbitrary degree. -/
theorem weylBlock_eq_zero_of_repeat (n k : ℕ) (v : Fin k → Fin (2 * n))
    (i j : Fin k) (hij : i ≠ j) (hv : v i = v j) : weylBlock n k v = 0 := by
  unfold weylBlock
  have hzero := (MultilinearMap.mkPiAlgebraFin ℂ k
      (Matrix (Majorana.Basis n) (Majorana.Basis n) ℂ)).alternatization.map_eq_zero_of_eq
      (fun r => Majorana.chiFin n (v r)) (i := i) (j := j)
      (congrArg (Majorana.chiFin n) hv) hij
  rw [hzero, smul_zero]

/-- Weyl equal-time exclusion persists with arbitrary surrounding operators. -/
theorem weylBlock_inserted_eq_zero_of_repeat (n k : ℕ) (v : Fin k → Fin (2 * n))
    (i j : Fin k) (hij : i ≠ j) (hv : v i = v j)
    (A B : Matrix (Majorana.Basis n) (Majorana.Basis n) ℂ) :
    A * weylBlock n k v * B = 0 := by
  rw [weylBlock_eq_zero_of_repeat n k v i j hij hv, mul_zero, zero_mul]

/-- Exact two-field Weyl contact subtraction, valid inside arbitrary insertions. -/
theorem weyl_pair_contact (n : ℕ) (i j : Fin (2 * n)) :
    (1 / 2 : ℂ) • (Majorana.chiFin n i * Majorana.chiFin n j -
      Majorana.chiFin n j * Majorana.chiFin n i) =
      Majorana.chiFin n i * Majorana.chiFin n j -
        ((1 / 2 : ℂ) * flavorDelta i j) •
          (1 : Matrix (Majorana.Basis n) (Majorana.Basis n) ℂ) := by
  have hCAR : Majorana.chiFin n i * Majorana.chiFin n j +
      Majorana.chiFin n j * Majorana.chiFin n i =
        flavorDelta i j • (1 : Matrix (Majorana.Basis n) (Majorana.Basis n) ℂ) := by
    rw [Majorana.chiFin_car]
    by_cases h : i = j <;> simp [flavorDelta, h]
  rw [← smul_smul, ← hCAR, smul_sub, smul_add]
  module

/-- The Weyl definition is the full signed permutation average. -/
theorem weylBlock_sum (n k : ℕ) (v : Fin k → Fin (2 * n)) :
    weylBlock n k v = (k.factorial : ℂ)⁻¹ •
      ∑ σ : Equiv.Perm (Fin k), Equiv.Perm.sign σ •
        (List.ofFn (fun i => Majorana.chiFin n (v (σ i)))).prod := by
  simp only [weylBlock, MultilinearMap.alternatization_apply,
    MultilinearMap.domDomCongr_apply, MultilinearMap.mkPiAlgebraFin_apply]

/-- No matching contraction means the whole contraction operator vanishes. -/
theorem contractWord_eq_zero_of_no_pair {ι A : Type*} [Ring A] [Algebra ℂ A]
    (x : ι → A) (c : ι → ι → ℂ) (a : ι) (L : List ι)
    (h : ∀ b ∈ L, c a b = 0) : contractWord x c a L = 0 := by
  induction L with
  | nil => rfl
  | cons b L ih => simp [contractWord, h b (by simp), ih (fun b hb => h b (by simp [hb]))]

/-- Every nonempty even word of distinct Majoranas has zero ordinary trace. -/
theorem majorana_trace_nodup_zero (n : ℕ) (L : List (Fin (2 * n)))
    (hne : L ≠ []) (heven : Even L.length) (hnd : L.Nodup) :
    Majorana.normalizedTrace n (word (Majorana.chiFin n) L) = 0 := by
  cases L with
  | nil => exact (hne rfl).elim
  | cons a L =>
    have hodd : Odd L.length := by
      simpa only [List.length_cons, Nat.even_add_one, Nat.not_even_iff_odd] using heven
    have hc : ∀ i j : Fin (2 * n),
        Majorana.chiFin n i * Majorana.chiFin n j +
          Majorana.chiFin n j * Majorana.chiFin n i =
            flavorDelta i j • (1 : Matrix (Majorana.Basis n) (Majorana.Basis n) ℂ) := by
      intro i j
      rw [Majorana.chiFin_car]
      by_cases h : i = j <;> simp [flavorDelta, h]
    have hcontract : contractWord (Majorana.chiFin n) flavorDelta a L = 0 := by
      apply contractWord_eq_zero_of_no_pair
      intro b hb
      have hab : a ≠ b := by intro h; subst b; exact (List.nodup_cons.mp hnd).1 hb
      simp [flavorDelta, hab]
    have hm := congrArg (normalizedTraceMap n)
      (move_through_word (Majorana.chiFin n) flavorDelta hc a L)
    rw [hcontract, zero_add, map_smul, hodd.neg_one_pow, neg_one_smul,
      normalizedTraceMap_cyclic] at hm
    have hz := CharZero.eq_neg_self_iff.mp hm
    rw [normalizedTraceMap_cyclic] at hz
    simpa only [normalizedTraceMap_apply, word_cons] using hz

/-- Weyl blocks have zero normalized trace in every nonzero even degree. -/
theorem normalizedTrace_weylBlock_even (n k : ℕ) (hk : 0 < k) (heven : Even k)
    (v : Fin k → Fin (2 * n)) : Majorana.normalizedTrace n (weylBlock n k v) = 0 := by
  by_cases hinj : Function.Injective v
  · rw [weylBlock_sum]
    rw [← normalizedTraceMap_apply]
    rw [map_smul, map_sum]
    suffices hs : (∑ σ : Equiv.Perm (Fin k),
        normalizedTraceMap n (Equiv.Perm.sign σ •
          (List.ofFn (fun i => Majorana.chiFin n (v (σ i)))).prod)) = 0 by
      rw [hs, smul_zero]
    apply Finset.sum_eq_zero
    intro σ _
    rw [Units.smul_def, map_zsmul]
    suffices ht : normalizedTraceMap n
        ((List.ofFn (fun i => Majorana.chiFin n (v (σ i)))).prod) = 0 by
      rw [ht, smul_zero]
    have hw : word (Majorana.chiFin n) (List.ofFn (fun i => v (σ i))) =
        (List.ofFn (fun i => Majorana.chiFin n (v (σ i)))).prod := by
      have hword : ∀ K : List (Fin (2 * n)), word (Majorana.chiFin n) K = (K.map (Majorana.chiFin n)).prod := by
        intro K; induction K with
        | nil => rfl
        | cons a K ih => simp [ih]
      rw [hword, List.map_ofFn]
      rfl
    rw [← hw, normalizedTraceMap_apply]
    apply majorana_trace_nodup_zero
    · intro hz
      have hlen := congrArg List.length hz
      simp only [List.length_ofFn, List.length_nil] at hlen
      omega
    · simpa using heven
    · exact List.nodup_ofFn.mpr (hinj.comp σ.injective)
  · have hrep : ∃ i j, i ≠ j ∧ v i = v j := by
      simp only [Function.Injective, not_forall, _root_.not_imp] at hinj
      obtain ⟨i, j, hv, hij⟩ := hinj
      exact ⟨i, j, hij, hv⟩
    obtain ⟨i, j, hij, hv⟩ := hrep
    rw [weylBlock_eq_zero_of_repeat n k v i j hij hv]
    simp [Majorana.normalizedTrace]

/-- Ordered words agree with the usual product of their mapped letters. -/
theorem word_eq_prod_map {ι A : Type*} [Ring A] (x : ι → A) (L : List ι) :
    word x L = (L.map x).prod := by
  induction L with
  | nil => rfl
  | cons a L ih => simp [ih]

/-- A useful form for blocks indexed by `Fin`. -/
theorem word_ofFn {ι A : Type*} [Ring A] {k : ℕ} (x : ι → A) (v : Fin k → ι) :
    word x (List.ofFn v) = (List.ofFn (fun i => x (v i))).prod := by
  rw [word_eq_prod_map, List.map_ofFn]
  rfl

/-- A complete equal-time Weyl block, with arbitrary strictly separated ordered
words on both sides, agrees with the actual thermal exterior expectation.
Repeated flavors are allowed and vanish by antisymmetrization on both sides. -/
theorem weyl_block_thermal_trace (n k : ℕ) (β : ℝ) (hβ : 0 < β)
    (s : ThermalWick.Time β) (v : Fin k → Fin (2 * n))
    (P Q : List (ThermalWick.Label (2 * n) β))
    (heven : Even (P.length + k + Q.length))
    (hP : P.Pairwise (fun p q => q.2.val < p.2.val ∨ p.1 ≠ q.1))
    (hQ : Q.Pairwise (fun p q => q.2.val < p.2.val ∨ p.1 ≠ q.1))
    (hPs : ∀ p ∈ P, s.val < p.2.val) (hsQ : ∀ q ∈ Q, q.2.val < s.val) :
    Majorana.normalizedTrace n
      (word (fun p => Majorana.chiFin n p.1) P * weylBlock n k v *
        word (fun p => Majorana.chiFin n p.1) Q) =
      ThermalWick.expectation (2 * n) β
        (word (fun p => ThermalWick.field p.1 p.2) P *
          ExteriorAlgebra.ιMulti ℂ k (fun i => Finsupp.single (v i, s) (1 : ℂ)) *
            word (fun p => ThermalWick.field p.1 p.2) Q) := by
  classical
  rw [← normalizedTraceMap_apply]
  by_cases hinj : Function.Injective v
  · let A := word (fun p => Majorana.chiFin n p.1) P
    let B := word (fun p => Majorana.chiFin n p.1) Q
    let F := word (fun p => ThermalWick.field p.1 p.2) P
    let G := word (fun p => ThermalWick.field p.1 p.2) Q
    let W := ExteriorAlgebra.ιMulti ℂ k (fun i => Finsupp.single (v i, s) (1 : ℂ))
    let E := ThermalWick.expectation (2 * n) β
    have hterm (σ : Equiv.Perm (Fin k)) :
        normalizedTraceMap n
          (A * (Equiv.Perm.sign σ •
            (List.ofFn (fun i => Majorana.chiFin n (v (σ i)))).prod) * B) = E (F * W * G) := by
      let K : List (ThermalWick.Label (2 * n) β) :=
        List.ofFn (fun i => (v (σ i), s))
      have hK : K.Pairwise (fun p q => q.2.val < p.2.val ∨ p.1 ≠ q.1) := by
        apply List.pairwise_ofFn.mpr
        intro i j hij
        exact Or.inr (fun h => (ne_of_lt hij) (σ.injective (hinj h)))
      have hKtime (p : ThermalWick.Label (2 * n) β) (hp : p ∈ K) : p.2 = s := by
        obtain ⟨i, rfl⟩ := List.mem_ofFn.mp hp
        rfl
      have hord : (P ++ K ++ Q).Pairwise (fun p q => q.2.val < p.2.val ∨ p.1 ≠ q.1) := by
        rw [List.pairwise_append, List.pairwise_append]
        refine ⟨⟨hP, hK, ?_⟩, hQ, ?_⟩
        · intro p hp q hq
          exact Or.inl (by rw [hKtime q hq]; exact hPs p hp)
        · intro p hp q hq
          rcases List.mem_append.mp hp with hp | hp
          · exact Or.inl (lt_trans (hsQ q hq) (hPs p hp))
          · exact Or.inl (by rw [hKtime p hp]; exact hsQ q hq)
      have hE : Even (P ++ K ++ Q).length := by simpa [K, Nat.add_assoc] using heven
      have htrace := thermal_trace_of_ordered_equal_flavors n β hβ (P ++ K ++ Q) hE hord
      have htrace' : normalizedTraceMap n
          (A * (List.ofFn (fun i => Majorana.chiFin n (v (σ i)))).prod * B) =
          E (F * ExteriorAlgebra.ιMulti ℂ k (fun i => Finsupp.single (v (σ i), s) (1 : ℂ)) * G) := by
        simpa only [normalizedTraceMap_apply, word_append, K, word_ofFn,
          ExteriorAlgebra.ιMulti_apply, ThermalWick.field, A, B, F, G, E] using htrace
      have hperm : ExteriorAlgebra.ιMulti ℂ k (fun i => Finsupp.single (v (σ i), s) (1 : ℂ)) =
          Equiv.Perm.sign σ • W := by
        exact (ExteriorAlgebra.ιMulti ℂ k).map_perm (fun i => Finsupp.single (v i, s) (1 : ℂ)) σ
      rcases Int.units_eq_one_or (Equiv.Perm.sign σ) with hsign | hsign
      · simpa [hsign, hperm] using htrace'
      · simpa [hsign, hperm, mul_neg, neg_mul, Majorana.normalizedTrace, neg_div] using congrArg Neg.neg htrace'
    change normalizedTraceMap n (A * weylBlock n k v * B) = E (F * W * G)
    rw [weylBlock_sum, mul_smul_comm, smul_mul_assoc, map_smul,
      Finset.mul_sum, Finset.sum_mul, map_sum]
    simp only [hterm, Finset.sum_const, Finset.card_univ, Fintype.card_perm,
      Fintype.card_fin, nsmul_eq_mul, smul_eq_mul]
    rw [inv_mul_cancel_left₀]
    exact_mod_cast Nat.factorial_ne_zero k
  · simp only [Function.Injective, not_forall, _root_.not_imp] at hinj
    obtain ⟨i, j, hv, hij⟩ := hinj
    rw [weylBlock_eq_zero_of_repeat n k v i j hij hv, mul_zero, zero_mul, map_zero]
    have heq : Finsupp.single (v i, s) (1 : ℂ) = Finsupp.single (v j, s) (1 : ℂ) := by rw [hv]
    rw [(ExteriorAlgebra.ιMulti ℂ k).map_eq_zero_of_eq
      (fun r => Finsupp.single (v r, s) (1 : ℂ)) (i := i) (j := j) heq hij,
      mul_zero, zero_mul, map_zero]

end SYK.FreeWick
