import PartitionWickSeries
import ThermalPairCubeMeasure
import ContinuumWickSeries
import InsertedWickSeries

/-! # Exact Gaussian-vertex to collective-quartic continuum regrouping -/
set_option maxHeartbeats 600000
noncomputable section
open scoped BigOperators NNReal ComplexOrder
open MeasureTheory
namespace SYK.WickGaussianRegrouping
open DuhamelHistory DuhamelVertex ThermalWick WickVertexIntegrals PartitionWick

/-- Adjacent repetition of each quartic disorder label. -/
def doubledLabels {ι : Type*} {k : ℕ} (I : Fin k → ι) (r : Fin (k*2)) : ι := I r.divNat

@[simp] theorem doubledLabels_finProd {ι : Type*} {k : ℕ} (I : Fin k → ι)
    (i : Fin k) (a : Fin 2) : doubledLabels I (finProdFinEquiv (i,a)) = I i := by
  have h := congrArg Prod.fst (finProdFinEquiv.symm_apply_apply (i,a))
  exact congrArg I h

/-- Grouping adjacent factors preserves the true noncommutative order. -/
theorem orderedProduct_blocks {A : Type*} [Monoid A] {k n : ℕ} (F : Fin (k*n) → A) :
    orderedProduct F = orderedProduct (fun i : Fin k =>
      orderedProduct (fun a : Fin n => F (finProdFinEquiv (i,a)))) := by
  unfold orderedProduct
  rw [List.ofFn_mul, List.prod_flatten, List.map_ofFn]
  apply congrArg List.prod
  apply congrArg List.ofFn
  funext i
  apply congrArg List.prod
  apply congrArg List.ofFn
  funext a
  apply congrArg F
  apply Fin.ext
  simp [finProdFinEquiv, Nat.mul_comm, Nat.add_comm]

/-- Squared commuting variables correspond exactly to doubled vertex labels. -/
theorem prod_square_eq_doubled {ι : Type*} {k : ℕ} (I : Fin k → ι) :
    (∏ i, (MvPolynomial.X (I i) : MvPolynomial ι ℂ)^2) =
      ∏ r : Fin (k*2), MvPolynomial.X (doubledLabels I r) := by
  rw [← List.prod_ofFn, ← List.prod_ofFn]
  change orderedProduct (fun i => (MvPolynomial.X (I i) : MvPolynomial ι ℂ)^2) =
    orderedProduct (fun r => (MvPolynomial.X (doubledLabels I r) : MvPolynomial ι ℂ))
  rw [orderedProduct_blocks (fun r : Fin (k*2) => (MvPolynomial.X (doubledLabels I r) : MvPolynomial ι ℂ))]
  simp only [doubledLabels_finProd, orderedProduct, List.ofFn_succ, List.ofFn_zero,
    List.prod_cons, List.prod_nil, mul_one, pow_two]

/-- After flattening endpoint pairs, the exterior doubled-vertex word is
exactly the product of paired quartic vertices, with positive crossing sign. -/
theorem doubled_vertex_product (d : ℕ) {β : ℝ} (hβ : 0 < β) {k : ℕ}
    (I : Fin k → Majorana.FourSet d) (p : Fin k → ℝ×ℝ) :
    orderedProduct (fun r => quarticField d (doubledLabels I r)
      (timeRepresentative β hβ (Interacting.pairTimes p r))) =
    orderedProduct (fun i => quarticField d (I i) (timeRepresentative β hβ (p i).1) *
      quarticField d (I i) (timeRepresentative β hβ (p i).2)) := by
  rw [orderedProduct_blocks]
  simp only [doubledLabels_finProd, MomentSymmetry.pairTimes_finProd,
    orderedProduct, List.ofFn_succ, List.ofFn_zero, List.prod_cons, List.prod_nil, mul_one]
  norm_num

/-- The integrated doubled history is exactly its genuine paired-cube
integral, through the proved measure-preserving adjacent coordinate map. -/
theorem vertexMoment_doubled (d : ℕ) {β : ℝ} (hβ : 0 < β)
    (L : List (Label (2*d) β)) {k : ℕ} (I : Fin k → Majorana.FourSet d) :
    vertexMoment d hβ L (doubledLabels I) =
      ∫ p, expectation (2*d) β (FreeWick.word (fun q => field q.1 q.2) L *
        orderedProduct (fun i => quarticField d (I i) (timeRepresentative β hβ (p i).1) *
          quarticField d (I i) (timeRepresentative β hβ (p i).2)))
        ∂ThermalPairCube.pairedMeasure β k := by
  rw [vertexMoment, ← ThermalPairCube.integral_pairTimes β k]
  simp only [vertexIntegrand, doubled_vertex_product]

/-- Exact finite-label expansion of the Gaussian quadratic symbol under
our concrete integrated exterior functional. -/
theorem functional_quadratic_eq_sum (d : ℕ) {β : ℝ} (hβ : 0 < β)
    (L : List (Label (2*d) β)) (c : ℂ) (k : ℕ) :
    vertexFunctional d hβ L ((c • ∑ I, (MvPolynomial.X I)^2)^k) =
      c^k * ∑ I : Fin k → Majorana.FourSet d, vertexMoment d hβ L (doubledLabels I) := by
  rw [smul_pow, map_smul, smul_eq_mul]
  rw [sum_pow_ordered (fun I : Majorana.FourSet d =>
    (MvPolynomial.X I : MvPolynomial (Majorana.FourSet d) ℂ)^2) k, map_sum]
  congr 1
  apply Finset.sum_congr rfl
  intro I _
  simp only [orderedProduct, List.prod_ofFn]
  rw [prod_square_eq_doubled, vertexFunctional_product]

/-- Paired quartic integrands are integrable by the already proved
single-coordinate Wick bound and the exact measure-preserving regrouping. -/
theorem paired_vertex_integrable (d : ℕ) {β : ℝ} (hβ : 0 < β)
    (L : List (Label (2*d) β)) (hL : Even L.length) {k : ℕ}
    (I : Fin k → Majorana.FourSet d) :
    Integrable (fun p => expectation (2*d) β (FreeWick.word (fun q => field q.1 q.2) L *
      orderedProduct (fun i => quarticField d (I i) (timeRepresentative β hβ (p i).1) *
        quarticField d (I i) (timeRepresentative β hβ (p i).2))))
      (ThermalPairCube.pairedMeasure β k) := by
  have hp := (ThermalPairCube.pairCoordinates_measurePreserving k).restrict_preimage_emb
    (ThermalPairCube.pairCoordinates k).measurableEmbedding (ThermalPairCube.pairedCube β k)
  rw [ThermalPairCube.pairedCube_preimage, ← ThermalPairCube.pairedMeasure_eq_restrict] at hp
  have hp' := MeasurePreserving.symm (ThermalPairCube.pairCoordinates k) hp
  have hi := (hp'.integrable_comp_emb
    (ThermalPairCube.pairCoordinates k).symm.measurableEmbedding).mpr
      (vertexIntegrand_integrable d hβ L hL (doubledLabels I))
  simpa only [Function.comp_def, ThermalPairCube.pairCoordinates_symm_eq_pairTimes,
    vertexIntegrand, doubled_vertex_product] using hi

/-- Exact finite flavor summation of all paired interaction vertices inside
the actual scalar time integral. -/
theorem sum_vertexMoment_doubled (d : ℕ) {β : ℝ} (hβ : 0 < β)
    (L : List (Label (2*d) β)) (hL : Even L.length) (k : ℕ) :
    (∑ I : Fin k → Majorana.FourSet d, vertexMoment d hβ L (doubledLabels I)) =
      ∫ p, expectation (2*d) β (FreeWick.word (fun q => field q.1 q.2) L *
        orderedProduct (fun i => ∑ I : Majorana.FourSet d,
          quarticField d I (timeRepresentative β hβ (p i).1) *
            quarticField d I (timeRepresentative β hβ (p i).2)))
        ∂ThermalPairCube.pairedMeasure β k := by
  simp_rw [vertexMoment_doubled]
  rw [← integral_finset_sum Finset.univ (fun I _ => paired_vertex_integrable d hβ L hL I)]
  congr 1
  funext p
  rw [orderedProduct_sum, Finset.mul_sum]
  simp only [expectation, map_sum]

/-- Extracting a common central interaction coefficient from its actual
scalar integral requires no topology on the exterior algebra. -/
theorem integral_scaled_vertex_product (d : ℕ) {β : ℝ}
    (L : List (Label (2*d) β)) (k : ℕ) (μ : Measure (Fin k → ℝ×ℝ)) (c : ℂ)
    (V : (Fin k → ℝ×ℝ) → Fin k → FieldAlgebra (2*d) β) :
    (∫ p, expectation (2*d) β (FreeWick.word (fun q => field q.1 q.2) L *
      orderedProduct (fun i => c • V p i)) ∂μ) =
    c^k * ∫ p, expectation (2*d) β (FreeWick.word (fun q => field q.1 q.2) L *
      orderedProduct (V p)) ∂μ := by
  simp_rw [orderedProduct_smul, Finset.prod_const, Finset.card_univ,
    Fintype.card_fin, mul_smul_comm, expectation, map_smul, smul_eq_mul]
  exact integral_const_mul _ _

/-- The exact Gaussian variance coefficient and the actual finite exterior
quartic regrouping produce the continuum N lambda / 8 collective vertex. -/
theorem functional_gaussian_quadratic (d : ℕ) (hd : 0 < d) {β : ℝ} (hβ : 0 < β)
    (L : List (Label (2*d) β)) (hL : Even L.length) (lam : ℝ≥0) (k : ℕ) :
    vertexFunctional d hβ L ((quadraticPolynomial d lam)^k) =
      ((((2*d : ℕ) : ℂ) * (lam : ℂ) / 8)^k) *
        ∫ p, expectation (2*d) β (FreeWick.word (fun q => field q.1 q.2) L *
          orderedProduct (fun i => collective (2*d) β
            (timeRepresentative β hβ (p i).1) (timeRepresentative β hβ (p i).2) ^ 4))
          ∂ThermalPairCube.pairedMeasure β k := by
  have hq : quadraticPolynomial d lam =
      ((3 * (lam : ℝ) / ((2*d : ℕ) : ℝ)^3 : ℝ) : ℂ) •
        ∑ I : Majorana.FourSet d, (MvPolynomial.X I : MvPolynomial (Majorana.FourSet d) ℂ)^2 := by
    unfold quadraticPolynomial
    rw [RCLike.real_smul_eq_coe_smul (K := ℂ)]
    rfl
  rw [hq, functional_quadratic_eq_sum,
    sum_vertexMoment_doubled d hβ L hL k, ← integral_scaled_vertex_product]
  have hc : ((3 * (lam : ℝ) / ((2*d : ℕ) : ℝ)^3 : ℝ) : ℂ) =
      (6*(lam:ℂ)/(((2*d : ℕ):ℂ)^3))/2 := by
    push_cast
    ring
  have hs (s t : Time β) : ((3 * (lam : ℝ) / ((2*d : ℕ) : ℝ)^3 : ℝ) : ℂ) •
      (∑ I, quarticField d I s * quarticField d I t) =
      ((((2*d : ℕ) : ℂ) * (lam : ℂ) / 8)) • collective (2*d) β s t ^ 4 := by
    rw [hc]
    exact gaussian_quartic_coefficient d hd (lam : ℂ) s t
  simp_rw [hs]
  exact integral_scaled_vertex_product d L k _ _ _

/-- The replicated bilocal list is exactly the product of actual fourth
collective powers used in the regrouped Gaussian vertex. -/
theorem interactionPairs_product (d : ℕ) {β : ℝ} (hβ : 0 < β) {k : ℕ}
    (p : Fin k → ℝ×ℝ) :
    Ward.collectiveMonomial (N := 2*d) (ContinuumWickSeries.interactionPairs β hβ p) =
      orderedProduct (fun i => collective (2*d) β
        (timeRepresentative β hβ (p i).1) (timeRepresentative β hβ (p i).2)^4) := by
  simp only [ContinuumWickSeries.interactionPairs, Ward.collectiveMonomial,
    List.map_flatten, List.prod_flatten, List.map_ofFn, Function.comp_def,
    List.map_replicate, List.prod_replicate, orderedProduct]

/-- Every Gaussian Wick coefficient is exactly the corresponding coefficient
of the genuine collective continuum series, with all numerical factors fixed. -/
theorem averagedWickCoefficient_eq_continuum_term (d : ℕ) (hd : 0 < d)
    {β : ℝ} (hβ : 0 < β) (lam : ℝ≥0) (k : ℕ) :
    averagedWickCoefficient d hβ lam k = ExponentialMomentSeries.term
      (ContinuumWickSeries.coefficient d β hβ []) (lam : ℝ) k := by
  rw [averagedWickCoefficient, functional_gaussian_quadratic d hd hβ [] (by simp)]
  simp only [FreeWick.word_nil, one_mul]
  unfold ExponentialMomentSeries.term ContinuumWickSeries.coefficient
  simp only [ContinuumWickSeries.coefficientIntegrand, List.nil_append]
  simp_rw [interactionPairs_product]
  change (k.factorial : ℂ)⁻¹ * ((((2*d : ℕ):ℂ)*(lam:ℂ)/8)^k * _) = _
  rw [show ThermalPairCube.pairedMeasure β k = ContinuumWickSeries.interactionMeasure β k from rfl]
  simp only [Complex.real_smul]
  push_cast
  simp only [div_pow, mul_pow]
  ring

/-- The manuscript's concrete collective continuum Wick denominator is the
normalized ordinary annealed partition function of the actual SYK model. -/
theorem numerator_empty_eq_partition (d : ℕ) (hd : 0 < d) {β : ℝ}
    (hβ : 0 < β) (lam : ℝ≥0) :
    ContinuumWickSeries.numerator d β hβ [] (lam : ℝ) =
      ((∫ j, (Majorana.partitionFunction d β j).re ∂Microscopic.disorder d lam : ℝ) : ℂ) /
        (2 : ℂ)^d := by
  rw [← averagedWick_sum_eq_partition d hβ lam]
  unfold ContinuumWickSeries.numerator ExponentialMomentSeries.value
  apply tsum_congr
  intro k
  exact (averagedWickCoefficient_eq_continuum_term d hd hβ lam k).symm

/-- Strict positivity of the exact continuum Wick denominator follows from
the genuine Gibbs partition and its actual Gaussian average. -/
theorem numerator_empty_re_pos (d : ℕ) (hd : 0 < d) {β : ℝ}
    (hβ : 0 < β) (lam : ℝ≥0) :
    0 < (ContinuumWickSeries.numerator d β hβ [] (lam : ℝ)).re := by
  rw [numerator_empty_eq_partition d hd hβ lam, ← averagedWick_sum_eq_partition d hβ lam]
  exact averagedWick_sum_re_pos d hβ lam

/-- The same coefficient correspondence retains an arbitrary even external
field word, with no external endpoint distinctness assumption. -/
theorem gaussian_fieldCoefficient_identity (d : ℕ) (hd : 0 < d) {β : ℝ} (hβ : 0 < β)
    (L : List (Label (2*d) β)) (hL : Even L.length) (lam : ℝ≥0) (k : ℕ) :
    (k.factorial : ℂ)⁻¹ * vertexFunctional d hβ L ((quadraticPolynomial d lam)^k) =
      ExponentialMomentSeries.term (InsertedWickSeries.fieldCoefficient d hβ L) (lam : ℝ) k := by
  rw [functional_gaussian_quadratic d hd hβ L hL]
  unfold ExponentialMomentSeries.term InsertedWickSeries.fieldCoefficient
  simp only [InsertedWickSeries.fieldIntegrand]
  simp_rw [interactionPairs_product]
  rw [show ThermalPairCube.pairedMeasure β k = ContinuumWickSeries.interactionMeasure β k from rfl]
  simp only [Complex.real_smul]
  push_cast
  simp only [div_pow, mul_pow]
  ring

end SYK.WickGaussianRegrouping
