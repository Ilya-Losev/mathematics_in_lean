import FiniteWardSymmetry
import RealWardContacts

/-!
# Exact microscopic left Ward contacts supply all finite control

The only input is the literal all-real left residual/contact identity. The
sharp coefficient moment bound, centered contact estimate, and skewed right
residual identity discharge every bound in the compactness interface.
-/

noncomputable section
namespace SYK.ActualFiniteWardControl
open SYK.WeightedKernelAlgebra SYK.ThermalEndpointLift SYK.ThermalMomentTransport
open SYK.ThermalWardLimit SYK.MixedIncrement SYK.RealWardContacts SYK.FiniteWardSymmetry
open MeasureTheory Filter Set
open scoped BigOperators Topology NNReal

/-- The exact finite-size left inserted Ward identity, expressed using the
actual thermal microscopic functional and the explicit contact derivation. -/
def ExactLeftWard (β : ℝ) (hβ : 0 < β) (lam : ℝ≥0) (d : ℕ) : Prop :=
  ∀ (Q : RealPolynomial) (s t : ℝ),
    ThermalWardLimit.leftResidual β hβ lam d Q s t =
      ((2*d : ℕ) : ℂ)⁻¹ * actualThermalPolynomial β hβ d lam (contact β s t Q)

variable (β : ℝ) (hβ : 0 < β) (lam : ℝ≥0)

/-- Every fixed polynomial insertion has an explicit, dimension-independent
inverse-N majorant for its literal contact term. -/
theorem actual_contact_bound (d : ℕ) (hd : 0 < d) (Q : RealPolynomial) (s t : ℝ) :
    ‖((2*d : ℕ) : ℂ)⁻¹ * actualThermalPolynomial β hβ d lam (contact β s t Q)‖ ≤
      (coefficientNorm (fun _ : Endpoint => (1/2:ℝ)) (contact β s t Q) / 2) / (d : ℝ) := by
  rw [norm_mul, norm_inv, Complex.norm_natCast]
  have h := mul_le_mul_of_nonneg_left
    (actualThermalPolynomial_bound β hβ d hd lam (contact β s t Q))
    (inv_nonneg.mpr (Nat.cast_nonneg (2*d) : (0:ℝ) ≤ (2*d:ℕ)))
  apply h.trans_eq
  have hdR : (d:ℝ) ≠ 0 := by exact_mod_cast hd.ne'
  push_cast
  field_simp [hdR]

/-- The exact microscopic identity automatically supplies the sharp centered
contact bound required by the endpoint compactness theorem. -/
theorem exact_left_centered_bound (d : ℕ) (hd : 0 < d)
    (hWard : ExactLeftWard β hβ lam d) (ps : List Endpoint) (s t : ℝ) :
    ‖ThermalWardLimit.leftResidual β hβ lam d (remainderProduct β ps) s t‖ ≤
      (ps.length : ℝ)/(4*d) := by
  rw [hWard]
  exact centered_contact_bound β s t d hd (actualThermalPolynomial β hβ d lam)
    (actualThermalPolynomial_bound β hβ d hd lam) ps

/-- The exact all-real microscopic left Ward identity is sufficient for the
entire finite control package. No contact estimate, right identity, moment
bound, regularity or compactness assertion is assumed here. -/
theorem finiteWardControl_of_exact_left (d : ℕ → ℕ) (hd : ∀ n, 0 < d n)
    (hWard : ∀ n, ExactLeftWard β hβ lam (d n)) : FiniteWardControl β hβ lam d := by
  apply finiteWardControl_of_left β hβ lam d hd
  · intro Q s t
    refine ⟨coefficientNorm (fun _ : Endpoint => (1/2:ℝ)) (contact β s t Q) / 2, fun n => ?_⟩
    rw [hWard n]
    exact actual_contact_bound β hβ lam (d n) (hd n) Q s t
  · intro n ps s t
    exact exact_left_centered_bound β hβ lam (d n) (hd n) (hWard n) ps s t

end SYK.ActualFiniteWardControl
