import WickSeriesDerivative
import MomentSeriesIntegrability
import FourthMomentIntegral

/-! # The normalized pressure derivative of the genuine scalar Wick series -/
noncomputable section
open MeasureTheory Set Filter
open scoped NNReal Topology
namespace SYK.ContinuumWickSeries
open ThermalWick

/-- Normalize an actual scalar inserted series by its scalar partition series. -/
def normalizedMoment (d : ℕ) (β : ℝ) (hβ : 0 < β)
    (ps : List (Time β × Time β)) (lam : ℝ) : ℂ :=
  numerator d β hβ ps lam / numerator d β hβ [] lam

/-- Pressure per Majorana, with the finite-dimensional free trace factor. -/
def seriesPressure (d : ℕ) (β : ℝ) (hβ : 0 < β) (lam : ℝ) : ℝ :=
  Real.log 2/2 + Real.log (numerator d β hβ [] lam).re / (2*d : ℝ)

/-- The full inserted series is integrable in its two true time variables. -/
theorem inserted_numerator_integrable (d : ℕ) (hd : 0 < d) (β : ℝ) (hβ : 0 < β)
    (ps : List (Time β × Time β)) (lam : ℝ) :
    Integrable (fun p => numerator d β hβ (ps ++ quarticPairs β hβ p) lam) (pairMeasure β) := by
  apply ExponentialMomentSeries.integrable_value (pairMeasure β)
    (fun p => coefficient d β hβ (ps ++ quarticPairs β hβ p))
    ((1/2:ℝ)^(ps.length+4)) (((2*d:ℕ):ℝ)*β^2/128) (by positivity) (by positivity)
    (fun n => (inserted_coefficient_measurable d β hβ ps n).aestronglyMeasurable)
  intro p n
  simpa only [List.length_append, quarticPairs_length] using
    coefficient_bound d hd β hβ (ps ++ quarticPairs β hβ p) n

/-- The exact 1/8 normalized quartic insertion derivative. Reality and
positivity of the partition value are the only local scalar conditions. -/
theorem hasDerivAt_seriesPressure (d : ℕ) (hd : 0 < d) (β : ℝ) (hβ : 0 < β)
    (lam : ℝ) (hz : 0 < (numerator d β hβ [] lam).re)
    (him : (numerator d β hβ [] lam).im = 0) :
    HasDerivAt (seriesPressure d β hβ)
      ((1/8 : ℝ) * ∫ p, (normalizedMoment d β hβ (quarticPairs β hβ p) lam).re
        ∂pairMeasure β) lam := by
  have hi : Integrable (fun p => numerator d β hβ (quarticPairs β hβ p) lam) (pairMeasure β) := by
    simpa using inserted_numerator_integrable d hd β hβ [] lam
  have h := Complex.reCLM.hasFDerivAt.comp_hasDerivAt lam
    (hasDerivAt_numerator_insertion d hd β hβ [] lam)
  simp only [List.nil_append, Function.comp_apply, Complex.reCLM_apply, Complex.smul_re,
    smul_eq_mul, Nat.cast_mul, Nat.cast_ofNat] at h
  have hp := ((h.log hz.ne').div_const (2*d : ℝ)).const_add (Real.log 2/2)
  have he : numerator d β hβ [] lam = ((numerator d β hβ [] lam).re : ℂ) := by
    apply Complex.ext
    · rfl
    · simpa using him
  have hI : (∫ p, (normalizedMoment d β hβ (quarticPairs β hβ p) lam).re ∂pairMeasure β) =
      (∫ p, numerator d β hβ (quarticPairs β hβ p) lam ∂pairMeasure β).re /
        (numerator d β hβ [] lam).re := by
    simp only [normalizedMoment]
    rw [he]
    simp only [Complex.div_ofReal_re, Complex.ofReal_re]
    rw [integral_div]
    have hr := Complex.reCLM.integral_comp_comm hi
    simpa only [Complex.reCLM_apply] using congrArg
      (fun x : ℝ => x / (numerator d β hβ [] lam).re) hr
  rw [hI]
  convert hp using 1
  have hd' : (d : ℝ) ≠ 0 := by exact_mod_cast hd.ne'
  dsimp only [Function.comp_apply, Complex.reCLM_apply]
  field_simp [hd']
  ring

end SYK.ContinuumWickSeries
