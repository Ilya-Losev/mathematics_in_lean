import FourierParseval
import Mathlib.MeasureTheory.Integral.Prod

noncomputable section
open MeasureTheory Set Function
open scoped Topology ComplexConjugate
namespace SYK.Continuum

def wave (ω t : ℝ) : ℂ := Complex.exp (Complex.I * ((ω : ℂ) * (t : ℂ)))

theorem wave_add (ω s t : ℝ) : wave ω (s + t) = wave ω s * wave ω t := by
  unfold wave
  rw [Complex.ofReal_add]
  have he : Complex.I * ((ω : ℂ) * ((s : ℂ) + (t : ℂ))) =
      Complex.I * ((ω : ℂ) * (s : ℂ)) + Complex.I * ((ω : ℂ) * (t : ℂ)) := by ring
  rw [he, Complex.exp_add]

theorem norm_wave (ω t : ℝ) : ‖wave ω t‖ = 1 := by simp [wave, Complex.norm_exp]

theorem modulated_periodic (β ω : ℝ) (g : ℝ → ℝ)
    (ha : ∀ t, g (t + β) = -g t) (hp : wave ω β = -1) :
    Periodic (fun t => wave ω t * (g t : ℂ)) β := by
  intro t
  dsimp only
  rw [wave_add, ha, hp]
  push_cast
  ring

/-- A shift of an antiperiodic kernel contributes its fermionic phase. -/
theorem fourier_shift (β ω u : ℝ) (g : ℝ → ℝ)
    (ha : ∀ t, g (t + β) = -g t) (hp : wave ω β = -1) :
    (∫ t in (0 : ℝ)..β, wave ω t * (g (t - u) : ℂ)) =
      wave ω u * fourier β g ω := by
  have hw (t : ℝ) : wave ω t = wave ω u * wave ω (t - u) := by
    simpa using (wave_add ω u (t - u))
  calc
    _ = ∫ t in (0 : ℝ)..β, wave ω u * (wave ω (t - u) * (g (t - u) : ℂ)) := by
      apply intervalIntegral.integral_congr
      intro t _
      dsimp only
      rw [hw t]
      ring
    _ = wave ω u * ∫ t in (0 : ℝ)..β, wave ω (t - u) * (g (t - u) : ℂ) :=
      intervalIntegral.integral_const_mul _ _
    _ = wave ω u * ∫ t in -u..(β - u), wave ω t * (g t : ℂ) := by
      rw [intervalIntegral.integral_comp_sub_right (fun t => wave ω t * (g t : ℂ)) u]
      simp
    _ = wave ω u * ∫ t in (0 : ℝ)..β, wave ω t * (g t : ℂ) := by
      congr 1
      have he := (modulated_periodic β ω g ha hp).intervalIntegral_add_eq (-u) 0
      simpa [sub_eq_add_neg, add_comm] using he
    _ = _ := rfl

def scalarConvolution (β : ℝ) (g h : ℝ → ℝ) (t : ℝ) : ℝ :=
  ∫ u in (0 : ℝ)..β, g (t - u) * h u

theorem ofReal_scalarConvolution (β : ℝ) (g h : ℝ → ℝ) (t : ℝ) :
    (scalarConvolution β g h t : ℂ) =
      ∫ u in (0 : ℝ)..β, (g (t - u) : ℂ) * (h u : ℂ) := by
  simp only [scalarConvolution, intervalIntegral, ← Complex.ofReal_mul,
    integral_complex_ofReal, Complex.ofReal_sub]

/-- The actual antiperiodic convolution diagonalizes at a fermionic frequency. -/
theorem fourier_scalarConvolution (β : ℝ) (hβ : 0 < β) (ω : ℝ)
    (g h : ℝ → ℝ) (hg : Measurable g) (hh : Measurable h)
    (B D : ℝ) (hb : ∀ t, |g t| ≤ B) (hd : ∀ t, |h t| ≤ D)
    (ha : ∀ t, g (t + β) = -g t) (hp : wave ω β = -1) :
    fourier β (scalarConvolution β g h) ω = fourier β g ω * fourier β h ω := by
  let μ := volume.restrict (Ioc (0 : ℝ) β)
  have hint : Integrable (fun p : ℝ × ℝ =>
      wave ω p.1 * (g (p.1 - p.2) : ℂ) * (h p.2 : ℂ)) (μ.prod μ) := by
    apply (integrable_const (B * D)).mono'
    · have hm : Measurable (fun p : ℝ × ℝ =>
          wave ω p.1 * (g (p.1 - p.2) : ℂ) * (h p.2 : ℂ)) := by
        unfold wave
        fun_prop
      exact hm.aestronglyMeasurable
    · filter_upwards [] with p
      simp only [norm_mul, norm_wave, one_mul, Complex.norm_real, Real.norm_eq_abs]
      exact mul_le_mul (hb _) (hd _) (abs_nonneg _) ((abs_nonneg (g 0)).trans (hb 0))
  have hswap : (∫ t in (0 : ℝ)..β, ∫ u in (0 : ℝ)..β,
      wave ω t * (g (t - u) : ℂ) * (h u : ℂ)) =
      ∫ u in (0 : ℝ)..β, ∫ t in (0 : ℝ)..β,
        wave ω t * (g (t - u) : ℂ) * (h u : ℂ) := by
    simp only [intervalIntegral.integral_of_le hβ.le]
    exact integral_integral_swap hint
  change (∫ t in (0 : ℝ)..β, wave ω t * (scalarConvolution β g h t : ℂ)) = _
  calc
    _ = ∫ t in (0 : ℝ)..β, ∫ u in (0 : ℝ)..β,
        wave ω t * (g (t - u) : ℂ) * (h u : ℂ) := by
      apply intervalIntegral.integral_congr
      intro t _
      dsimp only
      rw [ofReal_scalarConvolution, ← intervalIntegral.integral_const_mul]
      congr 1
      funext u
      ring
    _ = ∫ u in (0 : ℝ)..β, ∫ t in (0 : ℝ)..β,
        wave ω t * (g (t - u) : ℂ) * (h u : ℂ) := hswap
    _ = ∫ u in (0 : ℝ)..β, (wave ω u * fourier β g ω) * (h u : ℂ) := by
      apply intervalIntegral.integral_congr
      intro u _
      dsimp only
      rw [intervalIntegral.integral_mul_const, fourier_shift β ω u g ha hp]
    _ = fourier β g ω * ∫ u in (0 : ℝ)..β, wave ω u * (h u : ℂ) := by
      rw [← intervalIntegral.integral_const_mul]
      apply intervalIntegral.integral_congr
      intro u _
      dsimp only
      ring
    _ = _ := rfl

theorem scalarConvolution_measurable (β : ℝ) (hβ : 0 ≤ β)
    (g h : ℝ → ℝ) (hg : Measurable g) (hh : Measurable h) :
    Measurable (scalarConvolution β g h) := by
  have hm : Measurable (fun p : ℝ × ℝ => g (p.1 - p.2) * h p.2) :=
    (hg.comp (measurable_fst.sub measurable_snd)).mul (hh.comp measurable_snd)
  have hi := hm.stronglyMeasurable.integral_prod_right'
    (ν := volume.restrict (Ioc (0 : ℝ) β))
  change Measurable (fun t => ∫ u in (0 : ℝ)..β, g (t - u) * h u)
  simpa only [intervalIntegral.integral_of_le hβ] using hi.measurable

theorem scalarConvolution_bound (β : ℝ) (hβ : 0 ≤ β) (g h : ℝ → ℝ)
    (B D : ℝ) (hb : ∀ t, |g t| ≤ B) (hd : ∀ t, |h t| ≤ D) (t : ℝ) :
    |scalarConvolution β g h t| ≤ β * (B * D) := by
  have he := intervalIntegral.norm_integral_le_of_norm_le_const
    (a := (0 : ℝ)) (b := β) (C := B * D)
    (f := fun u => g (t - u) * h u) (fun u _ => by
      simp only [Real.norm_eq_abs, abs_mul]
      exact mul_le_mul (hb _) (hd _) (abs_nonneg _) ((abs_nonneg (g 0)).trans (hb 0)))
  simpa only [scalarConvolution, Real.norm_eq_abs, sub_zero, abs_of_nonneg hβ, mul_comm] using he

theorem scalarConvolution_antiperiodic (β : ℝ) (g h : ℝ → ℝ)
    (ha : ∀ t, g (t + β) = -g t) (t : ℝ) :
    scalarConvolution β g h (t + β) = -scalarConvolution β g h t := by
  unfold scalarConvolution
  simp_rw [show ∀ u : ℝ, t + β - u = (t - u) + β by intro u; ring, ha, neg_mul]
  exact intervalIntegral.integral_neg

/-- Stationary antiperiodic kernel composition is the scalar circle convolution. -/
theorem stationary_convolution (β : ℝ) (g h : ℝ → ℝ)
    (ha : ∀ t, g (t + β) = -g t) (hb : ∀ t, h (t + β) = -h t)
    (s t : ℝ) :
    convolution β (stationaryKernel g) (stationaryKernel h) s t =
      scalarConvolution β g h (s - t) := by
  let F := fun u : ℝ => g ((s - t) - u) * h u
  have hp : Periodic F β := by
    intro u
    dsimp [F]
    rw [hb]
    have hx := ha ((s - t) - u - β)
    have he : g ((s - t) - (u + β)) = -g ((s - t) - u) := by
      have heq : (s - t) - u - β + β = (s - t) - u := by ring
      rw [heq] at hx
      have heq' : (s - t) - (u + β) = (s - t) - u - β := by ring
      rw [heq']
      linarith
    rw [he]
    ring
  have heq (u : ℝ) : g (s - u) * h (u - t) = F (u - t) := by
    dsimp [F]
    congr 2
    ring
  unfold convolution stationaryKernel
  simp_rw [heq]
  rw [intervalIntegral.integral_comp_sub_right F t]
  have hper := hp.intervalIntegral_add_eq (-t) 0
  simpa [scalarConvolution, F, sub_eq_add_neg, add_comm] using hper

end SYK.Continuum
