import AbstractRepresentationTransport
import MomentRepresentationIndependence

/-!
# Thermal moments on arbitrary finite-dimensional complex spaces

The numerator below is defined using the actual continuous operators and their
ordinary linear trace. Basis transport preserves each exponential, time product,
complete tied-time Weyl average and flavor average. CAR then identifies the
actual Gaussian-normalized moments with the canonical microscopic model.
-/
noncomputable section
open MeasureTheory Filter
open scoped BigOperators NNReal Topology ComplexOrder
namespace SYK.AbstractRepresentation
open FreeWick

variable {E : Type*} [NormedAddCommGroup E] [NormedSpace ℂ E] [FiniteDimensional ℂ E]
variable {κ : Type*} [Fintype κ] [DecidableEq κ]

def timeProduct {k : ℕ} (H : E →L[ℂ] E) (β : ℝ) (t : Fin k → ℝ)
    (A : Fin k → E →L[ℂ] E) : E →L[ℂ] E :=
  (List.ofFn (fun i : Fin (k+1) => NormedSpace.exp ℂ ((-Interacting.gaps k β t i) • H) *
    Fin.snoc (α := fun _ => E →L[ℂ] E) A 1 i)).prod

theorem coordinates_timeProduct (b : Basis κ ℂ E) {k : ℕ} (H : E →L[ℂ] E)
    (β : ℝ) (t : Fin k → ℝ) (A : Fin k → E →L[ℂ] E) :
    coordinates b (timeProduct H β t A) =
      Interacting.timeProduct (coordinates b H) β t (fun i => coordinates b (A i)) := by
  rw [timeProduct,Interacting.timeProduct_eq_gaps,map_list_prod]
  rw [List.map_ofFn]
  congr 1
  apply congrArg List.ofFn
  funext i
  dsimp only [Function.comp_def]
  rw [map_mul,coordinates_exp]
  have hs (r : ℝ) : coordinates b (r • H) = r • coordinates b H := by
    rw [← Complex.coe_smul r,map_smul,Complex.coe_smul]
  rw [hs]
  congr 1
  refine Fin.lastCases ?_ (fun i => ?_) i <;> simp

theorem timeProduct_trace_eq (b : Basis κ ℂ E) {k : ℕ} (H : E →L[ℂ] E)
    (β : ℝ) (t : Fin k → ℝ) (A : Fin k → E →L[ℂ] E) :
    LinearMap.trace ℂ E (timeProduct H β t A).toLinearMap =
      Matrix.trace (Interacting.timeProduct (coordinates b H) β t (fun i => coordinates b (A i))) := by
  rw [← coordinates_trace b,coordinates_timeProduct]

def weylNumerator {k : ℕ} (H : E →L[ℂ] E) (β : ℝ) (t : Fin k → ℝ)
    (A : Fin k → E →L[ℂ] E) : ℂ :=
  Interacting.signedAverage (Interacting.sortingPerms t) Equiv.Perm.sign
    (fun σ => LinearMap.trace ℂ E (timeProduct H β (t ∘ σ) (A ∘ σ)).toLinearMap)

theorem weylNumerator_coordinates (b : Basis κ ℂ E) {k : ℕ} (H : E →L[ℂ] E)
    (β : ℝ) (t : Fin k → ℝ) (A : Fin k → E →L[ℂ] E) :
    weylNumerator H β t A =
      Interacting.weylNumerator (coordinates b H) β t (fun i => coordinates b (A i)) := by
  unfold weylNumerator Interacting.weylNumerator Interacting.signedAverage
  congr 1
  apply Finset.sum_congr rfl
  intro σ _
  congr 1
  exact timeProduct_trace_eq b H β (t ∘ σ) (A ∘ σ)

def collectiveNumerator (d : ℕ) (x : Fin (2*d) → E →L[ℂ] E)
    (β : ℝ) (j : Majorana.FourSet d → ℝ) {k : ℕ} (p : Fin k → ℝ×ℝ) : ℂ :=
  (((2*d:ℕ):ℂ)^k)⁻¹ * ∑ f : Fin k → Fin (2*d),
    weylNumerator (hamiltonian d x j) β (Interacting.pairTimes p)
      (fun i => x (Interacting.pairFlavors f i))

theorem collectiveNumerator_coordinates (b : Basis κ ℂ E) (d : ℕ)
    (x : Fin (2*d) → E →L[ℂ] E) (β : ℝ) (j : Majorana.FourSet d → ℝ)
    {k : ℕ} (p : Fin k → ℝ×ℝ) :
    collectiveNumerator d x β j p = MomentRepresentationIndependence.collectiveNumerator d
      (fun i => coordinates b (x i)) β j p := by
  unfold collectiveNumerator MomentRepresentationIndependence.collectiveNumerator
  congr 1
  apply Finset.sum_congr rfl
  intro f _
  rw [weylNumerator_coordinates b,coordinates_hamiltonian]

theorem collectiveNumerator_eq (d : ℕ) (x : Fin (2*d) → E →L[ℂ] E)
    (hx : ∀ i j, x i*x j+x j*x i = flavorDelta i j • (1:E →L[ℂ] E))
    (hdim : Module.finrank ℂ E = 2^d) (β : ℝ) (j : Majorana.FourSet d → ℝ)
    {k : ℕ} (p : Fin k → ℝ×ℝ) :
    collectiveNumerator d x β j p =
      Interacting.collectiveNumerator d (Majorana.hamiltonian d j) β p := by
  rw [collectiveNumerator_coordinates (Module.finBasis ℂ E)]
  exact MomentRepresentationIndependence.collectiveNumerator_eq d _
    (coordinates_car (Module.finBasis ℂ E) d x hx) (by simpa using hdim) β j p

/-- Actual Gaussian moment of the supplied abstract-space operators, with
its own ordinary partition denominator and every coincident Weyl block. -/
def collectiveMoment (d : ℕ) (x : Fin (2*d) → E →L[ℂ] E)
    (β : ℝ) (lam : ℝ≥0) {k : ℕ} (p : Fin k → ℝ×ℝ) : ℂ :=
  ((∫ j, (partitionFunction d x β j).re ∂Microscopic.disorder d lam : ℝ):ℂ)⁻¹ *
    ∫ j, collectiveNumerator d x β j p ∂Microscopic.disorder d lam

theorem collectiveMoment_eq (d : ℕ) (x : Fin (2*d) → E →L[ℂ] E)
    (hx : ∀ i j, x i*x j+x j*x i = flavorDelta i j • (1:E →L[ℂ] E))
    (hdim : Module.finrank ℂ E = 2^d) (β : ℝ) (lam : ℝ≥0)
    {k : ℕ} (p : Fin k → ℝ×ℝ) :
    collectiveMoment d x β lam p = Interacting.collectiveMoment d β lam p := by
  unfold collectiveMoment Interacting.collectiveMoment
  simp only [partitionFunction_eq_of_finrank d x hx hdim,collectiveNumerator_eq d x hx hdim]

theorem collectiveNumerator_integrable (d : ℕ) (x : Fin (2*d) → E →L[ℂ] E)
    (hx : ∀ i j, x i*x j+x j*x i = flavorDelta i j • (1:E →L[ℂ] E))
    (hdim : Module.finrank ℂ E = 2^d) (β : ℝ) (lam : ℝ≥0)
    {k : ℕ} (p : Fin k → ℝ×ℝ) :
    Integrable (fun j => collectiveNumerator d x β j p) (Microscopic.disorder d lam) := by
  simp only [collectiveNumerator_eq d x hx hdim]
  exact Interacting.collectiveNumerator_integrable d β lam p

end SYK.AbstractRepresentation
