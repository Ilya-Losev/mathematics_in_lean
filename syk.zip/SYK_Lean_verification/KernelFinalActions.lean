import KernelQuotientActions
import Mathlib.Topology.Instances.RealVectorSpace
import Mathlib.Analysis.CStarAlgebra.Basic

/-!
# Isometric actions on the final SD algebra

The two actual Bochner residual families are permuted by reflection and time
translation, so both actions descend through the second closed ideal.
-/

noncomputable section
namespace SYK.KernelFinalActions
open SYK.WeightedKernelAlgebra SYK.KernelResidualAlgebra
open SYK.KernelCoordinateGeneration SYK.KernelAlgebraActions SYK.KernelQuotientActions
open MeasureTheory

section CoefficientMaps
variable {A : Type*} [NormedCommRing A] [NormedAlgebra ℂ A] [NormOneClass A]
  (e : A ≃+* A) (he : Isometry e)

/-- A continuous coefficient ring map acts on actual pointwise kernels. -/
def mapCoefficients : KernelSpace A →+* KernelSpace A where
  toFun f := kernelOfFunction (fun p => e (f p))
    (he.continuous.comp_stronglyMeasurable (KernelSpace.stronglyMeasurable f))
    ‖f‖ (fun p => by
      rw [(AddMonoidHomClass.isometry_iff_norm e).mp he]
      exact kernel_norm_apply_le f p)
  map_zero' := by ext p; exact map_zero e
  map_one' := by ext p; exact map_one e
  map_add' f g := by ext p; exact map_add e (f p) (g p)
  map_mul' f g := by ext p; exact map_mul e (f p) (g p)

@[simp] theorem mapCoefficients_apply (f : KernelSpace A) (p : Endpoint) :
    mapCoefficients e he f p = e (f p) := rfl

theorem mapCoefficients_smul (σ : ℂ → ℂ) (hσ : ∀ c, e (algebraMap ℂ A c) = algebraMap ℂ A (σ c))
    (c : ℂ) (f : KernelSpace A) :
    mapCoefficients e he (c • f) = σ c • mapCoefficients e he f := by
  ext p
  change e (c • f p) = σ c • e (f p)
  simp only [Algebra.smul_def, map_mul, hσ]

variable [NormedSpace ℝ A] [IsScalarTower ℝ ℂ A] [CompleteSpace A]

/-- Real linearity suffices to move the antilinear reflection through Bochner
integrals. It is never incorrectly treated as a complex-linear map. -/
theorem mapCoefficients_convolution (β : ℝ) (hβ : 0 ≤ β) (f g : KernelSpace A) :
    mapCoefficients e he (kernelConvolution β hβ f g) =
      kernelConvolution β hβ (mapCoefficients e he f) (mapCoefficients e he g) := by
  ext p
  change e (∫ u in (0 : ℝ)..β, f (p.1,u) * g (u,p.2)) =
    ∫ u in (0 : ℝ)..β, e (f (p.1,u)) * e (g (u,p.2))
  have hi := (e.toAddMonoidHom.toRealLinearMap he.continuous).intervalIntegral_comp_comm
    (kernelProduct_intervalIntegrable β f g p)
  change (∫ u in (0 : ℝ)..β, e (f (p.1,u) * g (u,p.2))) =
    e (∫ u in (0 : ℝ)..β, f (p.1,u) * g (u,p.2)) at hi
  simpa only [map_mul] using hi.symm

end CoefficientMaps

section FirstKernels
variable (b K : ℝ) (hb : 0 < b) (hK : 0 < K) (β : ℝ)

abbrev FirstAlgebra := RegularityAlgebra b K hb hK (thermalCovariance β) (symmetryRelations β)

variable [Nontrivial (FirstAlgebra b K hb hK β)]

def G : KernelSpace (FirstAlgebra b K hb hK β) :=
  coordinateKernel b K hb hK (thermalCovariance β) (symmetryRelations β)
    (thermalCovariance_stronglyMeasurable β)

def C : KernelSpace (FirstAlgebra b K hb hK β) :=
  scalarKernel b K hb hK (thermalCovariance β) (symmetryRelations β)
    (thermalCovariance_stronglyMeasurable β) (1/2) (norm_thermalCovariance_le β)

@[simp] theorem C_eq_free : C b K hb hK β = freeThermalKernel β := by
  ext p
  rw [C, scalarKernel_apply]
  exact (Algebra.algebraMap_eq_smul_one _).trans rfl

abbrev T (u : ℝ) := firstTranslation b K hb hK β (thermalCovariance β) (thermal_translation β) u
abbrev R := firstReflection b K hb hK β (thermalCovariance β) (thermal_reflection β)

theorem T_isometry (u : ℝ) : Isometry (T b K hb hK β u) :=
  firstTranslation_isometry b K hb hK β (thermalCovariance β) (thermal_translation β) u
theorem R_isometry : Isometry (R b K hb hK β) :=
  firstReflection_isometry b K hb hK β (thermalCovariance β) (thermal_reflection β)

@[simp] theorem mapT_G (u : ℝ) :
    mapCoefficients (T b K hb hK β u).toRingEquiv (T_isometry b K hb hK β u) (G b K hb hK β) =
      translateKernel u (G b K hb hK β) := by
  ext p
  exact firstTranslation_coordinate b K hb hK β (thermalCovariance β) (thermal_translation β) u p

@[simp] theorem mapT_C (u : ℝ) :
    mapCoefficients (T b K hb hK β u).toRingEquiv (T_isometry b K hb hK β u) (C b K hb hK β) =
      translateKernel u (C b K hb hK β) := by
  ext p
  change T b K hb hK β u (C b K hb hK β p) = C b K hb hK β (p.1+u,p.2+u)
  simp only [C, scalarKernel_apply, AlgEquiv.commutes]
  rw [show (p.1+u,p.2+u) = translateEndpoint u p by rfl, thermal_translation]

@[simp] theorem mapR_G :
    mapCoefficients (R b K hb hK β) (R_isometry b K hb hK β) (G b K hb hK β) =
      reflectKernel β (G b K hb hK β) := by
  ext p
  exact firstReflection_coordinate b K hb hK β (thermalCovariance β) (thermal_reflection β) p

@[simp] theorem mapR_C :
    mapCoefficients (R b K hb hK β) (R_isometry b K hb hK β) (C b K hb hK β) =
      reflectKernel β (C b K hb hK β) := by
  ext p
  change R b K hb hK β (C b K hb hK β p) = C b K hb hK β (β-p.2,β-p.1)
  simp only [C, scalarKernel_apply, firstReflection_constant]
  rw [show (β-p.2,β-p.1) = reflectEndpoint β p by rfl, thermal_reflection]

/-- Antiperiodicity is an exact consequence of the first ideal, not an added
assumption on the Bochner kernels. -/
theorem G_antiperiodic : KernelAntiperiodic β (G b K hb hK β) := by
  exact ⟨coordinate_antiperiodic_left b K hb hK (thermalCovariance β) β,
    coordinate_antiperiodic_right b K hb hK (thermalCovariance β) β⟩

theorem C_antiperiodic (hβ : β ≠ 0) : KernelAntiperiodic β (C b K hb hK β) := by
  rw [C_eq_free]
  exact ⟨freeThermalKernel_antiperiodic_left β hβ, freeThermalKernel_antiperiodic_right β hβ⟩

/-- The left residual kernel is defined before taking the final quotient. -/
def leftResidual (hβ : 0 ≤ β) (lam : ℝ) : KernelSpace (FirstAlgebra b K hb hK β) :=
  G b K hb hK β - C b K hb hK β - (lam : ℂ) •
    kernelConvolution β hβ (kernelConvolution β hβ (C b K hb hK β) ((G b K hb hK β)^3)) (G b K hb hK β)

/-- The right residual is a second, independent kernel equation. -/
def rightResidual (hβ : 0 ≤ β) (lam : ℝ) : KernelSpace (FirstAlgebra b K hb hK β) :=
  G b K hb hK β - C b K hb hK β - (lam : ℂ) •
    kernelConvolution β hβ (kernelConvolution β hβ (G b K hb hK β) ((G b K hb hK β)^3)) (C b K hb hK β)

/-- Both residual families at all real endpoint pairs, exactly as used by the
already constructed second quotient. -/
abbrev residuals (hβ : 0 ≤ β) (lam : ℝ) :=
  sdResiduals b K hb hK (thermalCovariance β) (symmetryRelations β) β hβ (lam : ℂ)
    (thermalCovariance_stronglyMeasurable β) (1/2) (norm_thermalCovariance_le β)

@[simp] theorem residuals_true (hβ : 0 ≤ β) (lam : ℝ) (p : Endpoint) :
    residuals b K hb hK β hβ lam (true,p) = leftResidual b K hb hK β hβ lam p := rfl

@[simp] theorem residuals_false (hβ : 0 ≤ β) (lam : ℝ) (p : Endpoint) :
    residuals b K hb hK β hβ lam (false,p) = rightResidual b K hb hK β hβ lam p := rfl

private theorem translate_sub {A : Type*} [NormedCommRing A] [NormedAlgebra ℂ A] [NormOneClass A]
    (u : ℝ) (f g : KernelSpace A) : translateKernel u (f-g) = translateKernel u f - translateKernel u g := by
  ext p; rfl

private theorem translate_smul {A : Type*} [NormedCommRing A] [NormedAlgebra ℂ A] [NormOneClass A]
    (u : ℝ) (c : ℂ) (f : KernelSpace A) : translateKernel u (c • f) = c • translateKernel u f := by
  ext p; rfl

private theorem translate_pow {A : Type*} [NormedCommRing A] [NormedAlgebra ℂ A] [NormOneClass A]
    (u : ℝ) (f : KernelSpace A) (n : ℕ) : translateKernel u (f^n) = (translateKernel u f)^n := by
  ext p; rfl

/-- Actual Bochner left residuals transform covariantly under simultaneous
translations; interval shifts use antiperiodicity of both kernels. -/
theorem mapT_leftResidual (hβ : 0 < β) (lam u : ℝ) :
    mapCoefficients (T b K hb hK β u).toRingEquiv (T_isometry b K hb hK β u)
      (leftResidual b K hb hK β hβ.le lam) =
        translateKernel u (leftResidual b K hb hK β hβ.le lam) := by
  unfold leftResidual
  rw [map_sub, map_sub, mapCoefficients_smul (T b K hb hK β u).toRingEquiv (T_isometry b K hb hK β u)
      id (fun c => (T b K hb hK β u).commutes c),
    mapCoefficients_convolution, mapCoefficients_convolution, map_pow,
    mapT_G, mapT_C]
  simp only [id_eq, translate_sub, translate_smul]
  rw [translateKernel_convolution β hβ.le _ _
      ((C_antiperiodic b K hb hK β hβ.ne').convolution hβ.le (G_antiperiodic b K hb hK β).cube)
      (G_antiperiodic b K hb hK β),
    translateKernel_convolution β hβ.le _ _ (C_antiperiodic b K hb hK β hβ.ne')
      (G_antiperiodic b K hb hK β).cube, translate_pow]

/-- The independent right residual has the same translation covariance. -/
theorem mapT_rightResidual (hβ : 0 < β) (lam u : ℝ) :
    mapCoefficients (T b K hb hK β u).toRingEquiv (T_isometry b K hb hK β u)
      (rightResidual b K hb hK β hβ.le lam) =
        translateKernel u (rightResidual b K hb hK β hβ.le lam) := by
  unfold rightResidual
  rw [map_sub, map_sub, mapCoefficients_smul (T b K hb hK β u).toRingEquiv (T_isometry b K hb hK β u)
      id (fun c => (T b K hb hK β u).commutes c),
    mapCoefficients_convolution, mapCoefficients_convolution, map_pow,
    mapT_G, mapT_C]
  simp only [id_eq, translate_sub, translate_smul]
  rw [translateKernel_convolution β hβ.le _ _
      ((G_antiperiodic b K hb hK β).convolution hβ.le (G_antiperiodic b K hb hK β).cube)
      (C_antiperiodic b K hb hK β hβ.ne'),
    translateKernel_convolution β hβ.le _ _ (G_antiperiodic b K hb hK β)
      (G_antiperiodic b K hb hK β).cube, translate_pow]

/-- Antilinear coefficient reflection interchanges the left and right residuals.
Associativity is the previously proved Fubini theorem for actual integrals. -/
theorem mapR_leftResidual (hβ : 0 ≤ β) (lam : ℝ) :
    mapCoefficients (R b K hb hK β) (R_isometry b K hb hK β)
      (leftResidual b K hb hK β hβ lam) =
        reflectKernel β (rightResidual b K hb hK β hβ lam) := by
  unfold leftResidual rightResidual
  rw [map_sub, map_sub, mapCoefficients_smul _ _ star
      (firstReflection_constant b K hb hK β (thermalCovariance β) (thermal_reflection β)),
    mapCoefficients_convolution, mapCoefficients_convolution, map_pow, mapR_G, mapR_C]
  simp only [Complex.star_def, Complex.conj_ofReal, reflectKernel_sub, reflectKernel_smul,
    reflectKernel_convolution, reflectKernel_pow]
  rw [kernelConvolution_assoc]

/-- Reflection also maps the right residual back to the left residual. -/
theorem mapR_rightResidual (hβ : 0 ≤ β) (lam : ℝ) :
    mapCoefficients (R b K hb hK β) (R_isometry b K hb hK β)
      (rightResidual b K hb hK β hβ lam) =
        reflectKernel β (leftResidual b K hb hK β hβ lam) := by
  unfold leftResidual rightResidual
  rw [map_sub, map_sub, mapCoefficients_smul _ _ star
      (firstReflection_constant b K hb hK β (thermalCovariance β) (thermal_reflection β)),
    mapCoefficients_convolution, mapCoefficients_convolution, map_pow, mapR_G, mapR_C]
  simp only [Complex.star_def, Complex.conj_ofReal, reflectKernel_sub, reflectKernel_smul,
    reflectKernel_convolution, reflectKernel_pow]
  rw [kernelConvolution_assoc]

/-- Translation sends each residual value to the same family at translated endpoints. -/
theorem translation_residual (hβ : 0 < β) (lam u : ℝ) (i : Bool × Endpoint) :
    T b K hb hK β u (residuals b K hb hK β hβ.le lam i) =
      residuals b K hb hK β hβ.le lam (i.1, translateEndpoint u i.2) := by
  rcases i with ⟨i,p⟩
  cases i with
  | false =>
      exact congrArg (fun f : KernelSpace (FirstAlgebra b K hb hK β) => f p)
        (mapT_rightResidual b K hb hK β hβ lam u)
  | true =>
      exact congrArg (fun f : KernelSpace (FirstAlgebra b K hb hK β) => f p)
        (mapT_leftResidual b K hb hK β hβ lam u)

/-- Reflection exchanges the residual families and reverses the endpoints. -/
theorem reflection_residual (hβ : 0 ≤ β) (lam : ℝ) (i : Bool × Endpoint) :
    R b K hb hK β (residuals b K hb hK β hβ lam i) =
      residuals b K hb hK β hβ lam (!i.1, reflectEndpoint β i.2) := by
  rcases i with ⟨i,p⟩
  cases i with
  | false =>
      exact congrArg (fun f : KernelSpace (FirstAlgebra b K hb hK β) => f p)
        (mapR_rightResidual b K hb hK β hβ lam)
  | true =>
      exact congrArg (fun f : KernelSpace (FirstAlgebra b K hb hK β) => f p)
        (mapR_leftResidual b K hb hK β hβ lam)

/-- Translation preserves the whole closed residual ideal because it permutes
its actual integral generators. -/
theorem translation_preserves_secondIdeal (hβ : 0 < β) (lam u : ℝ) :
    ∀ a ∈ residualIdeal (residuals b K hb hK β hβ.le lam),
      T b K hb hK β u a ∈ residualIdeal (residuals b K hb hK β hβ.le lam) := by
  apply maps_closedGeneratedIdeal (T b K hb hK β u).toRingHom (T_isometry b K hb hK β u).continuous
  intro i
  change T b K hb hK β u (residuals b K hb hK β hβ.le lam i) ∈ _
  rw [translation_residual b K hb hK β hβ lam u i]
  exact subset_closure (Ideal.subset_span (Set.mem_range_self _))

/-- Reflection preserves the whole closed residual ideal by exchanging its two
families, not by assuming each family is individually reflection invariant. -/
theorem reflection_preserves_secondIdeal (hβ : 0 ≤ β) (lam : ℝ) :
    ∀ a ∈ residualIdeal (residuals b K hb hK β hβ lam),
      R b K hb hK β a ∈ residualIdeal (residuals b K hb hK β hβ lam) := by
  apply maps_closedGeneratedIdeal (R b K hb hK β).toRingHom (R_isometry b K hb hK β).continuous
  intro i
  change R b K hb hK β (residuals b K hb hK β hβ lam i) ∈ _
  rw [reflection_residual]
  exact subset_closure (Ideal.subset_span (Set.mem_range_self _))

theorem translation_secondIdeal_iff (hβ : 0 < β) (lam u : ℝ) (a : FirstAlgebra b K hb hK β) :
    a ∈ residualIdeal (residuals b K hb hK β hβ.le lam) ↔
      T b K hb hK β u a ∈ residualIdeal (residuals b K hb hK β hβ.le lam) := by
  constructor
  · exact translation_preserves_secondIdeal b K hb hK β hβ lam u a
  · intro ha
    have hh := translation_preserves_secondIdeal b K hb hK β hβ lam (-u) _ ha
    simpa only [T, firstTranslation_add, neg_add_cancel, firstTranslation_zero] using hh

theorem reflection_secondIdeal_iff (hβ : 0 ≤ β) (lam : ℝ) (a : FirstAlgebra b K hb hK β) :
    a ∈ residualIdeal (residuals b K hb hK β hβ lam) ↔
      R b K hb hK β a ∈ residualIdeal (residuals b K hb hK β hβ lam) := by
  constructor
  · exact reflection_preserves_secondIdeal b K hb hK β hβ lam a
  · intro ha
    have hh := reflection_preserves_secondIdeal b K hb hK β hβ lam _ ha
    simpa only [R, firstReflection_involutive] using hh

/-- The final algebra is the already constructed second quotient, with no extra
relations silently added to make the actions work. -/
abbrev FinalAlgebra (hβ : 0 < β) (lam : ℝ) := ResidualQuotient (residuals b K hb hK β hβ.le lam)

/-- Actual complex-linear real-time translations on the final SD quotient. -/
def finalTranslation (hβ : 0 < β) (lam u : ℝ) :
    FinalAlgebra b K hb hK β hβ lam ≃ₐ[ℂ] FinalAlgebra b K hb hK β hβ lam :=
  { quotientRingEquiv _ (T b K hb hK β u).toRingEquiv
      (translation_secondIdeal_iff b K hb hK β hβ lam u) with
    commutes' c := by
      change quotientRingEquiv _ _ _ (Ideal.Quotient.mk _ (algebraMap ℂ _ c)) = _
      rw [quotientRingEquiv_mk]
      exact congrArg (Ideal.Quotient.mk _) ((T b K hb hK β u).commutes c) }

/-- Actual antilinear reflection on the final SD quotient. -/
def finalReflection (hβ : 0 < β) (lam : ℝ) :
    FinalAlgebra b K hb hK β hβ lam ≃+* FinalAlgebra b K hb hK β hβ lam :=
  quotientRingEquiv _ (R b K hb hK β) (reflection_secondIdeal_iff b K hb hK β hβ.le lam)

theorem finalTranslation_isometry (hβ : 0 < β) (lam u : ℝ) :
    Isometry (finalTranslation b K hb hK β hβ lam u) :=
  quotientRingEquiv_isometry _ _ (T_isometry b K hb hK β u)
    (translation_secondIdeal_iff b K hb hK β hβ lam u)

theorem finalReflection_isometry (hβ : 0 < β) (lam : ℝ) :
    Isometry (finalReflection b K hb hK β hβ lam) :=
  quotientRingEquiv_isometry _ _ (R_isometry b K hb hK β)
    (reflection_secondIdeal_iff b K hb hK β hβ.le lam)

@[simp] theorem finalTranslation_mk (hβ : 0 < β) (lam u : ℝ) (a : FirstAlgebra b K hb hK β) :
    finalTranslation b K hb hK β hβ lam u (ResidualQuotient.mk _ a) =
      ResidualQuotient.mk _ (T b K hb hK β u a) :=
  quotientRingEquiv_mk _ _ (translation_secondIdeal_iff b K hb hK β hβ lam u) a

@[simp] theorem finalReflection_mk (hβ : 0 < β) (lam : ℝ) (a : FirstAlgebra b K hb hK β) :
    finalReflection b K hb hK β hβ lam (ResidualQuotient.mk _ a) =
      ResidualQuotient.mk _ (R b K hb hK β a) :=
  quotientRingEquiv_mk _ _ (reflection_secondIdeal_iff b K hb hK β hβ.le lam) a

@[simp] theorem finalTranslation_zero (hβ : 0 < β) (lam : ℝ) (a : FinalAlgebra b K hb hK β hβ lam) :
    finalTranslation b K hb hK β hβ lam 0 a = a := by
  obtain ⟨a, rfl⟩ := Ideal.Quotient.mk_surjective a
  change finalTranslation _ _ _ _ _ _ _ _ (ResidualQuotient.mk _ a) = _
  rw [finalTranslation_mk, T, firstTranslation_zero]
  rfl

theorem finalTranslation_add (hβ : 0 < β) (lam u v : ℝ) (a : FinalAlgebra b K hb hK β hβ lam) :
    finalTranslation b K hb hK β hβ lam u (finalTranslation b K hb hK β hβ lam v a) =
      finalTranslation b K hb hK β hβ lam (u+v) a := by
  obtain ⟨a, rfl⟩ := Ideal.Quotient.mk_surjective a
  change finalTranslation _ _ _ _ _ _ _ _ (finalTranslation _ _ _ _ _ _ _ _ (ResidualQuotient.mk _ a)) =
    finalTranslation _ _ _ _ _ _ _ _ (ResidualQuotient.mk _ a)
  rw [finalTranslation_mk, finalTranslation_mk, finalTranslation_mk, T, firstTranslation_add]

@[simp] theorem finalReflection_involutive (hβ : 0 < β) (lam : ℝ) (a : FinalAlgebra b K hb hK β hβ lam) :
    finalReflection b K hb hK β hβ lam (finalReflection b K hb hK β hβ lam a) = a := by
  obtain ⟨a, rfl⟩ := Ideal.Quotient.mk_surjective a
  change finalReflection _ _ _ _ _ _ _ (finalReflection _ _ _ _ _ _ _ (ResidualQuotient.mk _ a)) = _
  rw [finalReflection_mk, finalReflection_mk, R, firstReflection_involutive]
  rfl

/-- The final algebra has the covariance needed by the bounded-orbit GNS proof. -/
theorem finalReflection_translation (hβ : 0 < β) (lam u : ℝ)
    (a : FinalAlgebra b K hb hK β hβ lam) :
    finalReflection b K hb hK β hβ lam (finalTranslation b K hb hK β hβ lam u a) =
      finalTranslation b K hb hK β hβ lam (-u) (finalReflection b K hb hK β hβ lam a) := by
  obtain ⟨a, rfl⟩ := Ideal.Quotient.mk_surjective a
  change finalReflection _ _ _ _ _ _ _ (finalTranslation _ _ _ _ _ _ _ _ (ResidualQuotient.mk _ a)) =
    finalTranslation _ _ _ _ _ _ _ _ (finalReflection _ _ _ _ _ _ _ (ResidualQuotient.mk _ a))
  rw [finalTranslation_mk, finalReflection_mk, finalReflection_mk, finalTranslation_mk,
    R, T, firstReflection_translation]

@[simp] theorem finalReflection_constant (hβ : 0 < β) (lam : ℝ) (c : ℂ) :
    finalReflection b K hb hK β hβ lam (algebraMap ℂ _ c) = algebraMap ℂ _ (star c) := by
  change finalReflection _ _ _ _ _ _ _ (ResidualQuotient.mk _ (algebraMap ℂ _ c)) = _
  rw [finalReflection_mk, R, firstReflection_constant, AlgHom.commutes]

theorem finalReflection_smul (hβ : 0 < β) (lam : ℝ) (c : ℂ) (a : FinalAlgebra b K hb hK β hβ lam) :
    finalReflection b K hb hK β hβ lam (c • a) = star c • finalReflection b K hb hK β hβ lam a := by
  simp only [Algebra.smul_def, map_mul, finalReflection_constant]

@[simp] theorem finalTranslation_coordinate (hβ : 0 < β) (lam u : ℝ) (p : Endpoint) :
    finalTranslation b K hb hK β hβ lam u
      (ResidualQuotient.mk _ (coordinate b K hb hK (thermalCovariance β) (symmetryRelations β) p)) =
      ResidualQuotient.mk _ (coordinate b K hb hK (thermalCovariance β) (symmetryRelations β)
        (translateEndpoint u p)) := by
  rw [finalTranslation_mk, T, firstTranslation_coordinate]

@[simp] theorem finalReflection_coordinate (hβ : 0 < β) (lam : ℝ) (p : Endpoint) :
    finalReflection b K hb hK β hβ lam
      (ResidualQuotient.mk _ (coordinate b K hb hK (thermalCovariance β) (symmetryRelations β) p)) =
      ResidualQuotient.mk _ (coordinate b K hb hK (thermalCovariance β) (symmetryRelations β)
        (reflectEndpoint β p)) := by
  rw [finalReflection_mk, R, firstReflection_coordinate]

/-- Finite-polynomial translation symmetry is sufficient for invariance of the
continuous functional on the first quotient. -/
theorem firstFunctional_invariant_of_polynomial
    (L : FirstAlgebra b K hb hK β →L[ℂ] ℂ)
    (hsym : ∀ u p, L (translatedPolynomial b K hb hK β (thermalCovariance β) u p) =
      L (polynomialMap b K hb hK (thermalCovariance β) (symmetryRelations β) p))
    (u : ℝ) (a : FirstAlgebra b K hb hK β) : L (T b K hb hK β u a) = L a := by
  refine (firstQuotient_polynomials_dense (kernelWeights b K hb hK)
    (kernelRelations (thermalCovariance β) (symmetryRelations β))).induction_on a ?_ ?_
  · exact isClosed_eq (L.continuous.comp (T_isometry b K hb hK β u).continuous) L.continuous
  · intro p
    change L (firstTranslation _ _ _ _ _ _ _ _ (RelationQuotient.mk _ _
      (WeightedAlgebra.ofPolynomial _ p))) = _
    rw [firstTranslation_mk]
    exact hsym u p

/-- The final descended state inherits translation invariance from finite
polynomial symmetry tests; no invariance hypothesis on the final algebra is used. -/
theorem finalFunctional_invariant_of_polynomial (hβ : 0 < β) (lam : ℝ)
    (L : FirstAlgebra b K hb hK β →L[ℂ] ℂ)
    (hF : ∀ a i, L (a * residuals b K hb hK β hβ.le lam i) = 0)
    (hL : ∀ a, ‖L a‖ ≤ ‖a‖)
    (hsym : ∀ u p, L (translatedPolynomial b K hb hK β (thermalCovariance β) u p) =
      L (polynomialMap b K hb hK (thermalCovariance β) (symmetryRelations β) p))
    (u : ℝ) (a : FinalAlgebra b K hb hK β hβ lam) :
    ResidualQuotient.descendFunctional _ L hF hL (finalTranslation b K hb hK β hβ lam u a) =
      ResidualQuotient.descendFunctional _ L hF hL a := by
  obtain ⟨a, rfl⟩ := Ideal.Quotient.mk_surjective a
  change ResidualQuotient.descendFunctional _ L hF hL
    (finalTranslation _ _ _ _ _ _ _ _ (ResidualQuotient.mk _ a)) = _
  rw [finalTranslation_mk, ResidualQuotient.descendFunctional_mk]
  exact firstFunctional_invariant_of_polynomial b K hb hK β L hsym u a

/-- The star-ring structure is constructed from the descended reflection. This
explicit structure can be installed locally without ambiguity about β. -/
def finalStarRing (hβ : 0 < β) (lam : ℝ) : StarRing (FinalAlgebra b K hb hK β hβ lam) where
  star := finalReflection b K hb hK β hβ lam
  star_involutive := finalReflection_involutive b K hb hK β hβ lam
  star_mul a c := (map_mul (finalReflection b K hb hK β hβ lam) a c).trans (mul_comm _ _)
  star_add := map_add (finalReflection b K hb hK β hβ lam)

/-- Compatibility with complex conjugation is proved, not built into the
translation maps. -/
def finalStarModule (hβ : 0 < β) (lam : ℝ) :
    letI := finalStarRing b K hb hK β hβ lam
    StarModule ℂ (FinalAlgebra b K hb hK β hβ lam) := by
  letI := finalStarRing b K hb hK β hβ lam
  exact ⟨finalReflection_smul b K hb hK β hβ lam⟩

/-- The normed-star structure follows from the independently proved quotient
isometry, so it adds no C*-norm assumption. -/
def finalNormedStarGroup (hβ : 0 < β) (lam : ℝ) :
    letI := finalStarRing b K hb hK β hβ lam
    NormedStarGroup (FinalAlgebra b K hb hK β hβ lam) := by
  letI := finalStarRing b K hb hK β hβ lam
  refine ⟨fun a => ?_⟩
  exact ((AddMonoidHomClass.isometry_iff_norm _).mp
    (finalReflection_isometry b K hb hK β hβ lam) a).le

end FirstKernels
end SYK.KernelFinalActions
