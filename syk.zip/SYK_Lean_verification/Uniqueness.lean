import Mathlib.MeasureTheory.Integral.Bochner.Basic
import Mathlib.Topology.Algebra.InfiniteSum.Order
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Ring

/-!
# Checked algebraic and summation core of Section 9

This file proves the two-sign comparison underlying uniqueness in the physical
Fourier class. It does not assert a Fourier/Parseval theorem for the manuscript's
kernels. That analytic identity and convergence are explicit hypotheses in the
last results. No physical solution or partition function is postulated here.
-/

namespace SYK

open scoped BigOperators
open MeasureTheory

/-- The real cubic is monotone, expressed in the pairing used in Section 9. -/
theorem cubic_pairing_nonnegative (a b : ℝ) :
    0 ≤ (a - b) * (a ^ 3 - b ^ 3) := by
  have hfactor : (a - b) * (a ^ 3 - b ^ 3) =
      (a - b) ^ 2 * (a ^ 2 + a * b + b ^ 2) := by ring
  rw [hfactor]
  apply mul_nonneg (sq_nonneg (a - b))
  nlinarith [sq_nonneg (a + b), sq_nonneg (a - b)]

/-- Including the nonnegative coupling does not change monotonicity. -/
theorem coupled_cubic_pairing_nonnegative (a b coupling : ℝ)
    (hcoupling : 0 ≤ coupling) :
    0 ≤ (a - b) * (coupling * a ^ 3 - coupling * b ^ 3) := by
  have hfactor : (a - b) * (coupling * a ^ 3 - coupling * b ^ 3) =
      coupling * ((a - b) * (a ^ 3 - b ^ 3)) := by ring
  rw [hfactor]
  exact mul_nonneg hcoupling (cubic_pairing_nonnegative a b)

/-- The time-domain pairing is nonnegative. Integrability is assumed explicitly
to match the intended analytic use, although nonnegativity itself needs less. -/
theorem integral_cubic_pairing_nonnegative {Ω : Type*} [MeasurableSpace Ω]
    (μ : Measure Ω) (g₁ g₂ : Ω → ℝ) (coupling : ℝ)
    (hcoupling : 0 ≤ coupling)
    (_hintegrable : Integrable
      (fun t => (g₁ t - g₂ t) * (coupling * g₁ t ^ 3 - coupling * g₂ t ^ 3)) μ) :
    0 ≤ ∫ t, (g₁ t - g₂ t) * (coupling * g₁ t ^ 3 - coupling * g₂ t ^ 3) ∂μ := by
  apply integral_nonneg
  intro t
  exact coupled_cubic_pairing_nonnegative (g₁ t) (g₂ t) coupling hcoupling

/-- The Dyson reciprocal difference has a negative square pairing. -/
theorem reciprocal_pairing_identity (x₁ x₂ : ℝ)
    (hx₁ : 0 < x₁) (hx₂ : 0 < x₂) :
    (x₁ - x₂) * (1 / x₁ - 1 / x₂) =
      -((x₁ - x₂) ^ 2 / (x₁ * x₂)) := by
  field_simp [ne_of_gt hx₁, ne_of_gt hx₂]
  ring

/-- Solving the scalar Fourier SD relation for its self-energy coefficient. -/
theorem dyson_self_energy (frequency x y : ℝ) (hx : 0 < x)
    (hdyson : x * (frequency + y) = 1) :
    y = 1 / x - frequency := by
  field_simp [ne_of_gt hx]
  nlinarith [hdyson]

/-- Once the Hankel test gives a nonnegative Fourier coefficient, the scalar
Dyson equation upgrades it to strict positivity. -/
theorem positive_of_nonnegative_dyson (frequency x y : ℝ)
    (hx : 0 ≤ x) (hdyson : x * (frequency + y) = 1) :
    0 < x := by
  by_contra hnot
  have hzero : x = 0 := le_antisymm (le_of_not_gt hnot) hx
  rw [hzero] at hdyson
  norm_num at hdyson

/-- The common frequency cancels when two Fourier SD relations are compared. -/
theorem dyson_pairing_identity (frequency x₁ x₂ y₁ y₂ : ℝ)
    (hx₁ : 0 < x₁) (hx₂ : 0 < x₂)
    (hdyson₁ : x₁ * (frequency + y₁) = 1)
    (hdyson₂ : x₂ * (frequency + y₂) = 1) :
    (x₁ - x₂) * (y₁ - y₂) =
      -((x₁ - x₂) ^ 2 / (x₁ * x₂)) := by
  rw [dyson_self_energy frequency x₁ y₁ hx₁ hdyson₁,
    dyson_self_energy frequency x₂ y₂ hx₂ hdyson₂]
  convert reciprocal_pairing_identity x₁ x₂ hx₁ hx₂ using 1
  ring

/-- This negative pairing can be nonnegative only when the coefficients agree. -/
theorem eq_of_reciprocal_pairing_nonnegative (x₁ x₂ : ℝ)
    (hx₁ : 0 < x₁) (hx₂ : 0 < x₂)
    (hpairing : 0 ≤ (x₁ - x₂) * (1 / x₁ - 1 / x₂)) :
    x₁ = x₂ := by
  rw [reciprocal_pairing_identity x₁ x₂ hx₁ hx₂] at hpairing
  have hdenom : 0 < x₁ * x₂ := mul_pos hx₁ hx₂
  have hnonneg : 0 ≤ (x₁ - x₂) ^ 2 / (x₁ * x₂) :=
    div_nonneg (sq_nonneg (x₁ - x₂)) (le_of_lt hdenom)
  have hzero : (x₁ - x₂) ^ 2 / (x₁ * x₂) = 0 := by linarith
  have hsquare : (x₁ - x₂) ^ 2 = 0 :=
    (div_eq_zero_iff.mp hzero).resolve_right (ne_of_gt hdenom)
  exact sub_eq_zero.mp (sq_eq_zero_iff.mp hsquare)

/-- The weighted energy occurring in the Fourier comparison. -/
noncomputable def fourierEnergy {ι : Type*} (weight x₁ x₂ : ι → ℝ) (i : ι) : ℝ :=
  weight i * (x₁ i - x₂ i) ^ 2 / (x₁ i * x₂ i)

theorem fourierEnergy_nonnegative {ι : Type*} (weight x₁ x₂ : ι → ℝ)
    (hweight : ∀ i, 0 < weight i)
    (hx₁ : ∀ i, 0 < x₁ i) (hx₂ : ∀ i, 0 < x₂ i) (i : ι) :
    0 ≤ fourierEnergy weight x₁ x₂ i := by
  unfold fourierEnergy
  exact div_nonneg
    (mul_nonneg (le_of_lt (hweight i)) (sq_nonneg (x₁ i - x₂ i)))
    (le_of_lt (mul_pos (hx₁ i) (hx₂ i)))

/-- A nonnegative time pairing equal to minus a convergent sum of nonnegative
Fourier energies forces equality of every Fourier coefficient.

`hcomparison` is the analytic Parseval/Dyson comparison that must be established
for the actual kernels. `hsummable` prevents an invalid use of Lean's default
value for an unconditionally divergent `tsum`.
-/
theorem coefficients_equal_of_two_signs {ι : Type*}
    (weight x₁ x₂ : ι → ℝ)
    (hweight : ∀ i, 0 < weight i)
    (hx₁ : ∀ i, 0 < x₁ i) (hx₂ : ∀ i, 0 < x₂ i)
    (hsummable : Summable (fourierEnergy weight x₁ x₂))
    (pairing : ℝ) (hpairing : 0 ≤ pairing)
    (hcomparison : pairing = -∑' i, fourierEnergy weight x₁ x₂ i) :
    x₁ = x₂ := by
  have hterm : ∀ i, 0 ≤ fourierEnergy weight x₁ x₂ i :=
    fourierEnergy_nonnegative weight x₁ x₂ hweight hx₁ hx₂
  have hsumle : (∑' i, fourierEnergy weight x₁ x₂ i) ≤ 0 := by
    rw [hcomparison] at hpairing
    linarith
  funext i
  have htermle : fourierEnergy weight x₁ x₂ i ≤ 0 :=
    le_trans (hsummable.le_tsum i (fun j _ => hterm j)) hsumle
  have hzero : fourierEnergy weight x₁ x₂ i = 0 :=
    le_antisymm htermle (hterm i)
  have hdenom : x₁ i * x₂ i ≠ 0 := ne_of_gt (mul_pos (hx₁ i) (hx₂ i))
  have hproduct : weight i * (x₁ i - x₂ i) ^ 2 = 0 :=
    (div_eq_zero_iff.mp hzero).resolve_right hdenom
  have hsquare : (x₁ i - x₂ i) ^ 2 = 0 :=
    (mul_eq_zero.mp hproduct).resolve_left (ne_of_gt (hweight i))
  exact sub_eq_zero.mp (sq_eq_zero_iff.mp hsquare)

/-- This version takes the Parseval pairing before the reciprocal substitution.
The signed pairing's summability is the analytic Cauchy--Schwarz input, and the
Fourier SD relations are explicit hypotheses. The negative-square identity and
the resulting energy summability are derived inside Lean.
-/
theorem coefficients_equal_of_parseval_and_dyson {ι : Type*}
    (weight frequency x₁ x₂ y₁ y₂ : ι → ℝ)
    (hweight : ∀ i, 0 < weight i)
    (hx₁ : ∀ i, 0 < x₁ i) (hx₂ : ∀ i, 0 < x₂ i)
    (hdyson₁ : ∀ i, x₁ i * (frequency i + y₁ i) = 1)
    (hdyson₂ : ∀ i, x₂ i * (frequency i + y₂ i) = 1)
    (hsummable : Summable
      (fun i => weight i * ((x₁ i - x₂ i) * (y₁ i - y₂ i))))
    (pairing : ℝ) (hpairing : 0 ≤ pairing)
    (hparseval : pairing =
      ∑' i, weight i * ((x₁ i - x₂ i) * (y₁ i - y₂ i))) :
    x₁ = x₂ := by
  have hterm (i : ι) :
      weight i * ((x₁ i - x₂ i) * (y₁ i - y₂ i)) =
      -fourierEnergy weight x₁ x₂ i := by
    rw [dyson_pairing_identity (frequency i) (x₁ i) (x₂ i) (y₁ i) (y₂ i)
      (hx₁ i) (hx₂ i) (hdyson₁ i) (hdyson₂ i)]
    unfold fourierEnergy
    ring
  have henergySummable : Summable (fourierEnergy weight x₁ x₂) := by
    apply hsummable.neg.congr
    intro i
    rw [hterm i, neg_neg]
  have hcomparison : pairing = -∑' i, fourierEnergy weight x₁ x₂ i := by
    rw [hparseval]
    calc
      (∑' i, weight i * ((x₁ i - x₂ i) * (y₁ i - y₂ i))) =
          ∑' i, -fourierEnergy weight x₁ x₂ i := tsum_congr hterm
      _ = -∑' i, fourierEnergy weight x₁ x₂ i := tsum_neg
  exact coefficients_equal_of_two_signs weight x₁ x₂ hweight hx₁ hx₂
    henergySummable pairing hpairing hcomparison

/-- Version with an explicit integral pairing and explicit Parseval comparison.
Neither Fourier transformation nor its injectivity is silently assumed. -/
theorem coefficients_equal_of_cubic_integral_comparison
    {Ω ι : Type*} [MeasurableSpace Ω]
    (μ : Measure Ω) (g₁ g₂ : Ω → ℝ) (coupling : ℝ)
    (hcoupling : 0 ≤ coupling)
    (hintegrable : Integrable
      (fun t => (g₁ t - g₂ t) * (coupling * g₁ t ^ 3 - coupling * g₂ t ^ 3)) μ)
    (weight x₁ x₂ : ι → ℝ)
    (hweight : ∀ i, 0 < weight i)
    (hx₁ : ∀ i, 0 < x₁ i) (hx₂ : ∀ i, 0 < x₂ i)
    (hsummable : Summable (fourierEnergy weight x₁ x₂))
    (hcomparison :
      (∫ t, (g₁ t - g₂ t) * (coupling * g₁ t ^ 3 - coupling * g₂ t ^ 3) ∂μ) =
      -∑' i, fourierEnergy weight x₁ x₂ i) :
    x₁ = x₂ := by
  exact coefficients_equal_of_two_signs weight x₁ x₂ hweight hx₁ hx₂ hsummable _
    (integral_cubic_pairing_nonnegative μ g₁ g₂ coupling hcoupling hintegrable)
    hcomparison

end SYK
