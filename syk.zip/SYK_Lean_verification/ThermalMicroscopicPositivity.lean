import ThermalRPTransport
import PolynomialReflectionPositivity

/-!
# Actual microscopic reflection positivity for arbitrary half polynomials

The full finite polynomial is expanded into its finite monomial support and
identified with the actual Weyl star-square theorem. Interior representatives
are unchanged by thermal correction, including the reflected endpoints.
-/

noncomputable section
namespace SYK.ThermalMicroscopicPositivity
open SYK.WeightedKernelAlgebra SYK.ThermalEndpointLift SYK.ThermalMomentTransport
open SYK.MomentLimit SYK.MomentCompactness SYK.ThermalRPTransport
open SYK.PolynomialRP
open MeasureTheory Filter Set
open scoped BigOperators Topology NNReal

variable (β : ℝ) (hβ : 0 < β)

/-- Positive-half endpoints regarded as points of the closed compact cube. -/
def compactHalfPair (p : HalfPair β) : EndpointPair β :=
  (⟨p.1.val, p.1.property.1.le, by linarith [p.1.property.2]⟩,
   ⟨p.2.val, p.2.property.1.le, by linarith [p.2.property.2]⟩)

def compactReflection : CoordinatePolynomial β →+* CoordinatePolynomial β :=
  (MvPolynomial.rename (SYK.PolynomialRP.reflectEndpoint β)).toRingHom.comp
    (MvPolynomial.map (starRingEnd ℂ))

/-- Signed real-label reduction preserves every finite interior polynomial. -/
theorem polynomialReduction_interior {ι : Type*} (e : ι → EndpointPair β)
    (he : ∀ i, (e i).1.val < β ∧ (e i).2.val < β) (P : MvPolynomial ι ℂ) :
    polynomialReduction β hβ (MvPolynomial.rename (fun i => ((e i).1.val,(e i).2.val)) P) =
      MvPolynomial.rename e P := by
  have h : (polynomialReduction β hβ).comp
      (MvPolynomial.rename (fun i => ((e i).1.val,(e i).2.val))) = MvPolynomial.rename e := by
    ext i : 1
    simp only [AlgHom.comp_apply, MvPolynomial.rename_X, polynomialReduction_X]
    exact liftedVariable_of_mem β hβ (e i) (he i)
  exact AlgHom.congr_fun h P

@[simp] theorem polynomialReduction_half (P : MvPolynomial (HalfPair β) ℂ) :
    polynomialReduction β hβ (halfPolynomial β P) = MvPolynomial.rename (compactHalfPair β hβ) P := by
  apply polynomialReduction_interior β hβ (compactHalfPair β hβ)
  intro p
  constructor <;> dsimp [compactHalfPair] <;> linarith [p.1.property.2, p.2.property.2]

@[simp] theorem polynomialReduction_reflected_half (P : MvPolynomial (HalfPair β) ℂ) :
    polynomialReduction β hβ (reflectPolynomial β (halfPolynomial β P)) =
      compactReflection β (MvPolynomial.rename (compactHalfPair β hβ) P) := by
  change polynomialReduction β hβ
    (MvPolynomial.rename (SYK.KernelAlgebraActions.reflectEndpoint β)
      (MvPolynomial.map (starRingEnd ℂ) (MvPolynomial.rename halfEndpoint P))) =
    MvPolynomial.rename (SYK.PolynomialRP.reflectEndpoint β)
      (MvPolynomial.map (starRingEnd ℂ) (MvPolynomial.rename (compactHalfPair β hβ) P))
  rw [MvPolynomial.map_rename, MvPolynomial.map_rename,
    MvPolynomial.rename_rename, MvPolynomial.rename_rename]
  have he : ∀ p : HalfPair β,
      ((SYK.PolynomialRP.reflectEndpoint β ∘ compactHalfPair β hβ) p).1.val < β ∧
      ((SYK.PolynomialRP.reflectEndpoint β ∘ compactHalfPair β hβ) p).2.val < β := by
    intro p
    constructor <;> dsimp [SYK.PolynomialRP.reflectEndpoint, compactHalfPair] <;>
      linarith [p.1.property.1, p.2.property.1]
  exact polynomialReduction_interior β hβ
    (SYK.PolynomialRP.reflectEndpoint β ∘ compactHalfPair β hβ) he
    (MvPolynomial.map (starRingEnd ℂ) P)

/-- The actual signed thermal test agrees exactly with the raw interior
operator test, before any limit and with all internal coincidences retained. -/
theorem actualThermal_reflection_test_eq (d : ℕ) (lam : ℝ≥0)
    (P : MvPolynomial (HalfPair β) ℂ) :
    actualThermalPolynomial β hβ d lam
      (reflectPolynomial β (halfPolynomial β P) * halfPolynomial β P) =
      actualPolynomial d β lam (compactReflection β (MvPolynomial.rename (compactHalfPair β hβ) P) *
        MvPolynomial.rename (compactHalfPair β hβ) P) := by
  change actualPolynomial d β lam (polynomialReduction β hβ _) = _
  rw [map_mul, polynomialReduction_half, polynomialReduction_reflected_half]

/-- Every polynomial is a finite linear combination of actual coordinate
tuples, with no common degree required and including the empty tuple. -/
theorem polynomial_tuple_expansion {ι : Type*} (P : MvPolynomial ι ℂ) :
    P = ∑ e : P.support, MvPolynomial.coeff e.val P •
      ∏ r, MvPolynomial.X (monomialTuple e.val r) := by
  classical
  rw [Finset.sum_coe_sort P.support (fun e => MvPolynomial.coeff e P •
    ∏ r, MvPolynomial.X (monomialTuple e r))]
  conv_lhs => rw [P.as_sum]
  apply Finset.sum_congr rfl
  intro e _
  rw [← monomial_eq_tuple_prod, MvPolynomial.smul_monomial]
  simp only [smul_eq_mul, mul_one]

/-- Reflection of the complete tuple sum is exactly conjugation of all
coefficients and reversed endpoint reflection of every occurrence. -/
theorem compactReflection_tuple {ι : Type*} [Fintype ι] (k : ι → ℕ) (c : ι → ℂ)
    (p : ∀ i, EndpointCube β (k i)) :
    compactReflection β (tuplePolynomial β k c p) = reflectedTuplePolynomial β k c p := by
  simp [compactReflection, tuplePolynomial, reflectedTuplePolynomial, Algebra.smul_def,
    MvPolynomial.algebraMap_eq, map_prod]

/-- Actual finite-size even reflection positivity for every half polynomial. -/
theorem actualThermal_half_nonnegative (d : ℕ) (lam : ℝ≥0)
    (P : MvPolynomial (HalfPair β) ℂ) :
    0 ≤ (actualThermalPolynomial β hβ d lam
      (reflectPolynomial β (halfPolynomial β P) * halfPolynomial β P)).re := by
  classical
  let k : P.support → ℕ := fun e => (monomialList e.val).length
  let c : P.support → ℂ := fun e => MvPolynomial.coeff e.val P
  let p : ∀ e : P.support, EndpointCube β (k e) :=
    fun e r => compactHalfPair β hβ (monomialTuple e.val r)
  have hp : ∀ e r, (p e r).1.val < β/2 ∧ (p e r).2.val < β/2 := by
    intro e r
    exact ⟨(monomialTuple e.val r).1.property.2, (monomialTuple e.val r).2.property.2⟩
  have he : MvPolynomial.rename (compactHalfPair β hβ) P = tuplePolynomial β k c p := by
    conv_lhs => rw [polynomial_tuple_expansion P]
    simp only [map_sum, map_smul, map_prod, MvPolynomial.rename_X, tuplePolynomial, k, c, p]
  rw [actualThermal_reflection_test_eq, he, compactReflection_tuple]
  exact actualPolynomial_reflection_nonnegative d β lam k c p hp

/-- Actual finite-size reality of the complete half-polynomial reflection form. -/
theorem actualThermal_half_real (d : ℕ) (lam : ℝ≥0)
    (P : MvPolynomial (HalfPair β) ℂ) :
    (actualThermalPolynomial β hβ d lam
      (reflectPolynomial β (halfPolynomial β P) * halfPolynomial β P)).im = 0 := by
  classical
  let k : P.support → ℕ := fun e => (monomialList e.val).length
  let c : P.support → ℂ := fun e => MvPolynomial.coeff e.val P
  let p : ∀ e : P.support, EndpointCube β (k e) :=
    fun e r => compactHalfPair β hβ (monomialTuple e.val r)
  have hp : ∀ e r, (p e r).1.val < β/2 ∧ (p e r).2.val < β/2 := by
    intro e r
    exact ⟨(monomialTuple e.val r).1.property.2, (monomialTuple e.val r).2.property.2⟩
  have he : MvPolynomial.rename (compactHalfPair β hβ) P = tuplePolynomial β k c p := by
    conv_lhs => rw [polynomial_tuple_expansion P]
    simp only [map_sum, map_smul, map_prod, MvPolynomial.rename_X, tuplePolynomial, k, c, p]
  rw [actualThermal_reflection_test_eq, he, compactReflection_tuple]
  exact actualPolynomial_reflection_im_zero d β lam k c p hp


/-- The cross-half bilocal of the odd reflection test, with both values in
the strict interior of the compact thermal interval. -/
def compactCrossPair (x y : Ioo (0:ℝ) (β/2)) : EndpointPair β :=
  (⟨β-x.val, by constructor <;> linarith [x.property.1, x.property.2]⟩,
   ⟨y.val, y.property.1.le, by linarith [y.property.2]⟩)

def compactHankelPolynomial {k : ℕ} (x : Fin k → Ioo (0:ℝ) (β/2))
    (c : Fin k → ℂ) : CoordinatePolynomial β :=
  ∑ i, ∑ j, (star (c i)*c j) • MvPolynomial.X (compactCrossPair β hβ (x i) (x j))

@[simp] theorem polynomialReduction_hankel {k : ℕ}
    (x : Fin k → Ioo (0:ℝ) (β/2)) (c : Fin k → ℂ) :
    polynomialReduction β hβ (hankelPolynomial β (fun i => x i) c) = compactHankelPolynomial β hβ x c := by
  have hv (i j : Fin k) : liftedVariable β hβ (β-(x i).val,(x j).val) =
      MvPolynomial.X (compactCrossPair β hβ (x i) (x j)) := by
    apply liftedVariable_of_mem β hβ (compactCrossPair β hβ (x i) (x j))
    constructor <;> dsimp [compactCrossPair] <;> linarith [(x i).property.1, (x j).property.2]
  simp only [hankelPolynomial, compactHankelPolynomial, map_sum, map_smul, polynomialReduction_X, hv]

/-- Odd inserted tests also retain their exact raw interior microscopic
values; no antiperiodic sign or seam term is silently discarded. -/
theorem actualThermal_odd_test_eq (d : ℕ) (lam : ℝ≥0)
    (P : MvPolynomial (HalfPair β) ℂ) {k : ℕ}
    (x : Fin k → Ioo (0:ℝ) (β/2)) (c : Fin k → ℂ) :
    actualThermalPolynomial β hβ d lam
      (reflectPolynomial β (halfPolynomial β P) * halfPolynomial β P *
        hankelPolynomial β (fun i => x i) c) =
      actualPolynomial d β lam
        (compactReflection β (MvPolynomial.rename (compactHalfPair β hβ) P) *
          MvPolynomial.rename (compactHalfPair β hβ) P * compactHankelPolynomial β hβ x c) := by
  change actualPolynomial d β lam (polynomialReduction β hβ _) = _
  simp only [map_mul, polynomialReduction_half, polynomialReduction_reflected_half,
    polynomialReduction_hankel]

end SYK.ThermalMicroscopicPositivity
