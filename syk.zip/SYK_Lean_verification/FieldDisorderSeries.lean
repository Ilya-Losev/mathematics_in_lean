import WickGaussianRegrouping

/-!
# Absolutely convergent disorder series with external field insertions

The integrated exterior coefficients have a proved Gaussian-integrable
majorant. This discharges averaging and summation independently of the later
operator chamber identification.
-/
set_option maxHeartbeats 500000
noncomputable section
open scoped BigOperators NNReal ComplexOrder
open MeasureTheory
namespace SYK.FieldDisorderSeries
open ThermalWick DuhamelHistory DuhamelVertex WickVertexIntegrals PartitionWick
open InsertedWickSeries WickGaussianRegrouping

/-- Actual factorial-normalized integrated exterior coefficient before
Gaussian averaging, retaining its specified external word. -/
def disorderCoefficient (d : ℕ) {β : ℝ} (hβ : 0 < β)
    (L : List (Label (2*d) β)) (j : Majorana.FourSet d → ℝ) (n : ℕ) : ℂ :=
  (n.factorial : ℂ)⁻¹ * vertexFunctional d hβ L ((disorderPolynomial d j)^n)

/-- The absolute flavor sum has the exact scalar multinomial value. -/
theorem sum_product_abs (d : ℕ) (j : Majorana.FourSet d → ℝ) (n : ℕ) :
    (∑ I : Fin n → Majorana.FourSet d, ∏ i, |j (I i)|) = (∑ I, |j I|)^n := by
  simpa only [orderedProduct, List.prod_ofFn] using
    (sum_pow_ordered (fun I : Majorana.FourSet d => |j I|) n).symm

/-- The finite integrated Wick polynomial has the genuine normalized
Duhamel majorant, with no hidden dependence on the Hilbert-space dimension. -/
theorem functional_power_bound (d : ℕ) {β : ℝ} (hβ : 0 < β)
    (L : List (Label (2*d) β)) (hL : Even L.length)
    (j : Majorana.FourSet d → ℝ) (n : ℕ) :
    ‖vertexFunctional d hβ L ((disorderPolynomial d j)^n)‖ ≤
      ((Real.sqrt 2)⁻¹)^L.length * (β/4 * ∑ I, |j I|)^n := by
  rw [functional_power_eq_sum]
  calc
    _ ≤ ∑ I : Fin n → Majorana.FourSet d,
        ‖(∏ i, (j (I i) : ℂ)) * vertexMoment d hβ L I‖ := norm_sum_le _ _
    _ ≤ ∑ I : Fin n → Majorana.FourSet d,
        (∏ i, |j (I i)|) * (((Real.sqrt 2)⁻¹)^L.length * (β/4)^n) := by
      apply Finset.sum_le_sum
      intro I _
      rw [norm_mul, norm_prod]
      simp only [Complex.norm_real, Real.norm_eq_abs]
      exact mul_le_mul_of_nonneg_left (vertexMoment_bound d hβ L hL I)
        (Finset.prod_nonneg (fun _ _ => abs_nonneg _))
    _ = _ := by
      rw [← Finset.sum_mul, sum_product_abs, mul_pow]
      ring

/-- The exact factorial coefficient is bounded termwise by a scalar
exponential coefficient. -/
theorem disorderCoefficient_bound (d : ℕ) {β : ℝ} (hβ : 0 < β)
    (L : List (Label (2*d) β)) (hL : Even L.length)
    (j : Majorana.FourSet d → ℝ) (n : ℕ) :
    ‖disorderCoefficient d hβ L j n‖ ≤
      ((Real.sqrt 2)⁻¹)^L.length * scalarCoefficient (β/4 * ∑ I, |j I|) n := by
  rw [disorderCoefficient, norm_mul, norm_inv, Complex.norm_natCast]
  apply (mul_le_mul_of_nonneg_left (functional_power_bound d hβ L hL j n) (by positivity)).trans_eq
  unfold scalarCoefficient
  ring

theorem summable_norm_disorderCoefficient (d : ℕ) {β : ℝ} (hβ : 0 < β)
    (L : List (Label (2*d) β)) (hL : Even L.length) (j : Majorana.FourSet d → ℝ) :
    Summable (fun n => ‖disorderCoefficient d hβ L j n‖) :=
  Summable.of_nonneg_of_le (fun _ => norm_nonneg _) (disorderCoefficient_bound d hβ L hL j)
    ((hasSum_scalarCoefficient (β/4 * ∑ I, |j I|)).summable.mul_left _)

theorem tsum_norm_disorderCoefficient_le (d : ℕ) {β : ℝ} (hβ : 0 < β)
    (L : List (Label (2*d) β)) (hL : Even L.length) (j : Majorana.FourSet d → ℝ) :
    (∑' n, ‖disorderCoefficient d hβ L j n‖) ≤
      ((Real.sqrt 2)⁻¹)^L.length * Real.exp (β/4 * ∑ I, |j I|) := by
  have hs := (hasSum_scalarCoefficient (β/4 * ∑ I, |j I|)).mul_left (((Real.sqrt 2)⁻¹)^L.length)
  exact ((summable_norm_disorderCoefficient d hβ L hL j).tsum_le_tsum
    (disorderCoefficient_bound d hβ L hL j) hs.summable).trans_eq hs.tsum_eq

/-- Every disorder coefficient is a genuine continuous scalar polynomial. -/
theorem disorderCoefficient_continuous (d : ℕ) {β : ℝ} (hβ : 0 < β)
    (L : List (Label (2*d) β)) (n : ℕ) :
    Continuous (fun j => disorderCoefficient d hβ L j n) := by
  simp only [disorderCoefficient, functional_power_eq_sum]
  apply continuous_const.mul
  apply continuous_finset_sum
  intro I _
  apply Continuous.mul _ continuous_const
  apply continuous_finset_prod
  intro i _
  exact Complex.continuous_ofReal.comp (continuous_apply (I i))

/-- Each coefficient is Gaussian integrable under the actual exponential
majorant, with no polynomial-functional continuity assumption. -/
theorem disorderCoefficient_integrable (d : ℕ) {β : ℝ} (hβ : 0 < β)
    (L : List (Label (2*d) β)) (hL : Even L.length) (lam : ℝ≥0) (n : ℕ) :
    Integrable (fun j => disorderCoefficient d hβ L j n) (Microscopic.disorder d lam) := by
  apply ((GaussianDisorder.integrable_exp_sum_abs (Majorana.FourSet d) (2*d) lam (β/4)).const_mul
    (((Real.sqrt 2)⁻¹)^L.length)).mono'
  · exact (disorderCoefficient_continuous d hβ L n).aestronglyMeasurable
  · filter_upwards [] with j
    exact (Summable.le_tsum (summable_norm_disorderCoefficient d hβ L hL j) n
      (fun _ _ => norm_nonneg _)).trans (tsum_norm_disorderCoefficient_le d hβ L hL j)

/-- Full summability of Gaussian absolute coefficient integrals, proved from
the genuine disorder majorant rather than assumed for an interacting series. -/
theorem summable_integral_norm_disorderCoefficient (d : ℕ) {β : ℝ} (hβ : 0 < β)
    (L : List (Label (2*d) β)) (hL : Even L.length) (lam : ℝ≥0) :
    Summable (fun n => ∫ j, ‖disorderCoefficient d hβ L j n‖ ∂Microscopic.disorder d lam) := by
  classical
  let g := fun j : Majorana.FourSet d → ℝ =>
    ((Real.sqrt 2)⁻¹)^L.length * Real.exp (β/4 * ∑ I, |j I|)
  have hg : Integrable g (Microscopic.disorder d lam) :=
    (GaussianDisorder.integrable_exp_sum_abs (Majorana.FourSet d) (2*d) lam (β/4)).const_mul _
  apply summable_of_sum_le (fun _ => integral_nonneg (fun _ => norm_nonneg _))
    (c := ∫ j, g j ∂Microscopic.disorder d lam)
  intro s
  rw [← integral_finset_sum s (fun n _ => (disorderCoefficient_integrable d hβ L hL lam n).norm)]
  apply integral_mono (integrable_finset_sum s
    (fun n _ => (disorderCoefficient_integrable d hβ L hL lam n).norm)) hg
  intro j
  exact (Summable.sum_le_tsum s (fun _ _ => norm_nonneg _)
    (summable_norm_disorderCoefficient d hβ L hL j)).trans
      (tsum_norm_disorderCoefficient_le d hβ L hL j)

/-- Disorder averaging commutes with the whole inserted exterior series;
the full absolute Fubini hypothesis has been proved above. -/
theorem hasSum_integral_disorderCoefficient (d : ℕ) {β : ℝ} (hβ : 0 < β)
    (L : List (Label (2*d) β)) (hL : Even L.length) (lam : ℝ≥0) :
    HasSum (fun n => ∫ j, disorderCoefficient d hβ L j n ∂Microscopic.disorder d lam)
      (∫ j, ∑' n, disorderCoefficient d hβ L j n ∂Microscopic.disorder d lam) :=
  hasSum_integral_of_summable_integral_norm
    (fun n => disorderCoefficient_integrable d hβ L hL lam n)
    (summable_integral_norm_disorderCoefficient d hβ L hL lam)

/-- Genuine Gaussian symmetry eliminates every odd inserted coefficient. -/
theorem integral_disorderCoefficient_odd (d : ℕ) {β : ℝ} (hβ : 0 < β)
    (L : List (Label (2*d) β)) (lam : ℝ≥0) (k : ℕ) :
    (∫ j, disorderCoefficient d hβ L j (2*k+1) ∂Microscopic.disorder d lam) = 0 := by
  classical
  unfold disorderCoefficient
  rw [integral_const_mul]
  have h := GaussianCoefficient.integral_linearSymbol_odd
    (MvPolynomial (Majorana.FourSet d) ℂ) (GaussianDisorder.variance (2*d) lam)
    MvPolynomial.X ((vertexFunctional d hβ L).restrictScalars ℝ) k
  change (∫ j, vertexFunctional d hβ L
    ((∑ I, j I • (MvPolynomial.X I : MvPolynomial (Majorana.FourSet d) ℂ))^(2*k+1))
    ∂Microscopic.disorder d lam) = 0 at h
  simp_rw [disorderPolynomial_real]
  rw [h, mul_zero]

/-- Actual Gaussian averaging and finite exterior regrouping identify every
even inserted coefficient with its precise collective-interaction term. -/
theorem integral_disorderCoefficient_even (d : ℕ) (hd : 0 < d) {β : ℝ} (hβ : 0 < β)
    (L : List (Label (2*d) β)) (hL : Even L.length) (lam : ℝ≥0) (k : ℕ) :
    (∫ j, disorderCoefficient d hβ L j (2*k) ∂Microscopic.disorder d lam) =
      ExponentialMomentSeries.term (fieldCoefficient d hβ L) (lam : ℝ) k := by
  classical
  rw [← gaussian_fieldCoefficient_identity d hd hβ L hL lam k]
  unfold disorderCoefficient
  rw [integral_const_mul, factorial_mul_eq_real_smul, factorial_mul_eq_real_smul]
  simp_rw [disorderPolynomial_real]
  exact GaussianCoefficient.disorder_polynomial_coefficient (2*d) lam (vertexFunctional d hβ L) k

/-- Exact analytic Gaussian Wick representation with all external fields
retained. The only remaining microscopic bridge is identification of the
unaveraged disorder-series sum with the actual operator thermal history. -/
theorem fieldNumerator_eq_integral_disorderSeries (d : ℕ) (hd : 0 < d) {β : ℝ} (hβ : 0 < β)
    (L : List (Label (2*d) β)) (hL : Even L.length) (lam : ℝ≥0) :
    fieldNumerator d hβ L (lam : ℝ) =
      ∫ j, ∑' n, disorderCoefficient d hβ L j n ∂Microscopic.disorder d lam := by
  let f := fun n => ∫ j, disorderCoefficient d hβ L j n ∂Microscopic.disorder d lam
  have hf : HasSum f _ := hasSum_integral_disorderCoefficient d hβ L hL lam
  have hinj : Function.Injective (fun k : ℕ => 2*k) := by intro a b h; dsimp at h; omega
  have he := hf.summable.comp_injective hinj
  have ho : HasSum (fun k => f (2*k+1)) 0 := by
    simpa only [f, integral_disorderCoefficient_odd] using
      (hasSum_zero : HasSum (fun _ : ℕ => (0 : ℂ)) 0)
  have heq := (he.hasSum.even_add_odd ho).unique hf
  simp only [add_zero] at heq
  simpa only [f, Function.comp_def, integral_disorderCoefficient_even d hd hβ L hL lam,
    fieldNumerator, ExponentialMomentSeries.value] using heq

end SYK.FieldDisorderSeries
