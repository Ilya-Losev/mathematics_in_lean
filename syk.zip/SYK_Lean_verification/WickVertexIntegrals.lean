import DuhamelVertexExpansion
import OrderedCubePartition
import SymmetricMomentFunctional
import Mathlib.Algebra.Order.ToIntervalMod
import Mathlib.MeasureTheory.Function.Floor

/-!
# Genuine scalar time integrals of exterior quartic vertices

Only the numerical Wick expectation is integrated. No topology or completion
on the infinite flavor-time exterior algebra is postulated.
-/
noncomputable section
open scoped BigOperators ComplexOrder
open MeasureTheory Set
namespace SYK.WickVertexIntegrals
open DuhamelHistory DuhamelVertex ThermalWick

local instance (β : ℝ) : MeasurableSpace (Time β) :=
  inferInstanceAs (MeasurableSpace {t : ℝ // t ∈ Ico 0 β})

/-- The canonical half-open thermal representative, used only to give scalar
vertex integrands a total definition on ordinary real Lebesgue spaces. -/
def timeRepresentative (β : ℝ) (hβ : 0 < β) (t : ℝ) : Time β :=
  ⟨toIcoMod hβ 0 t, toIcoMod_mem_Ico' hβ t⟩

@[simp] theorem timeRepresentative_of_mem {β : ℝ} (hβ : 0 < β)
    {t : ℝ} (ht : t ∈ Ico 0 β) : (timeRepresentative β hβ t).val = t :=
  (toIcoMod_eq_self hβ).mpr (by simpa using ht)

theorem timeRepresentative_measurable (β : ℝ) (hβ : 0 < β) :
    Measurable (timeRepresentative β hβ) := by
  apply Measurable.subtype_mk
  change Measurable (fun t => toIcoMod hβ 0 t)
  simp only [toIcoMod_eq_fract_mul]
  exact (measurable_fract.comp (measurable_id.div_const β)).mul_const β

/-- An even quartic vertex belongs to the genuine commutative exterior center. -/
def centralVertex (d : ℕ) {β : ℝ} (I : Majorana.FourSet d) (u : Time β) :
    Subalgebra.center ℂ (FieldAlgebra (2*d) β) :=
  ⟨quarticField d I u, Subalgebra.mem_center_iff.mpr (fun a =>
    (Ward.even_commutes _ a (by simp [quarticField, field])).symm)⟩

@[simp] theorem centralVertex_coe (d : ℕ) {β : ℝ} (I : Majorana.FourSet d) (u : Time β) :
    (centralVertex d I u : FieldAlgebra (2*d) β) = quarticField d I u := rfl

/-- Ordered quartic products can be evaluated through the commutative center,
without discarding any fermionic signs. -/
theorem vertex_product_center (d : ℕ) {β : ℝ} {k : ℕ}
    (I : Fin k → Majorana.FourSet d) (u : Fin k → Time β) :
    orderedProduct (fun i => quarticField d (I i) (u i)) =
      ((∏ i, centralVertex d (I i) (u i) : Subalgebra.center ℂ (FieldAlgebra (2*d) β)) :
        FieldAlgebra (2*d) β) := by
  change _ = (Subalgebra.val (Subalgebra.center ℂ (FieldAlgebra (2*d) β))) _
  rw [← List.prod_ofFn, map_list_prod, List.map_ofFn]
  rfl

/-- A simultaneous permutation of quartic labels and times has no sign. -/
theorem vertex_product_permutation (d : ℕ) {β : ℝ} {k : ℕ}
    (I : Fin k → Majorana.FourSet d) (u : Fin k → Time β) (σ : Equiv.Perm (Fin k)) :
    orderedProduct (fun i => quarticField d (I (σ i)) (u (σ i))) =
      orderedProduct (fun i => quarticField d (I i) (u i)) := by
  rw [vertex_product_center, vertex_product_center]
  congr 1
  exact Equiv.prod_comp σ (fun i => centralVertex d (I i) (u i))

local instance (d : ℕ) : SecondCountableTopology (Matrix (Majorana.Basis d) (Majorana.Basis d) ℂ) :=
  inferInstanceAs (SecondCountableTopology (Majorana.Basis d → Majorana.Basis d → ℂ))
local instance (d : ℕ) : MeasurableSpace (Matrix (Majorana.Basis d) (Majorana.Basis d) ℂ) := borel _
local instance (d : ℕ) : BorelSpace (Matrix (Majorana.Basis d) (Majorana.Basis d) ℂ) := ⟨rfl⟩

/-- Numerical Wick expectations of even words are measurable in arbitrary
measurable endpoint families. No exterior-valued measurability is required. -/
theorem measurable_expectation_word {X : Type*} [MeasurableSpace X]
    (d : ℕ) {β : ℝ} (hβ : 0 < β) {k : ℕ} (hk : Even k)
    (f : Fin k → Fin (2*d)) (s : X → Fin k → Time β)
    (hs : ∀ i, Measurable (fun x => (s x i).val)) :
    Measurable (fun x => expectation (2*d) β
      (FreeWeyl.exteriorWord (fun i => (f i, s x i)))) := by
  have he (x : X) := FreeWeyl.free_weyl_eq_expectation d hβ hk (fun i => (f i, s x i))
  simp_rw [← he]
  apply Measurable.const_mul
  exact MomentMeasurability.measurable_weylNumerator d (fun _ => 0) (fun _ => β)
    (fun x i => (s x i).val) (fun _ i => Majorana.chiFin d (f i))
    measurable_const measurable_const hs (fun _ => measurable_const)

/-- List form, with a fixed finite list of measurable endpoint functions. -/
theorem measurable_expectation_list {X : Type*} [MeasurableSpace X]
    (d : ℕ) {β : ℝ} (hβ : 0 < β)
    (L : List (Fin (2*d) × (X → Time β))) (hL : Even L.length)
    (hs : ∀ p ∈ L, Measurable (fun x => (p.2 x).val)) :
    Measurable (fun x => expectation (2*d) β
      (FreeWick.word (fun p : Label (2*d) β => field p.1 p.2)
        (L.map (fun p => (p.1, p.2 x))))) := by
  have h := measurable_expectation_word d hβ hL (fun i => (L.get i).1)
    (fun x i => (L.get i).2 x) (fun i => hs (L.get i) (List.get_mem _ _))
  have he (x : X) : FreeWeyl.exteriorWord (fun i => ((L.get i).1, (L.get i).2 x)) =
      FreeWick.word (fun p : Label (2*d) β => field p.1 p.2)
        (L.map (fun p => (p.1, p.2 x))) := by
    have hm : L.map (fun p => (p.1, p.2 x)) =
        List.ofFn (fun i => ((L.get i).1, (L.get i).2 x)) := by
      simpa only [Function.comp_def, List.ofFn_get] using
        (List.map_ofFn (f := L.get) (g := fun p => (p.1, p.2 x)))
    rw [hm, FreeWick.word_ofFn]
    rfl
  simpa only [he] using h

/-- The numerical integrand for genuine quartic vertices and a fixed even
external field word. The half-open representative fixes null cube boundaries. -/
def vertexIntegrand (d : ℕ) {β : ℝ} (hβ : 0 < β)
    (L : List (Label (2*d) β)) {k : ℕ} (I : Fin k → Majorana.FourSet d)
    (u : Fin k → ℝ) : ℂ :=
  expectation (2*d) β (FreeWick.word (fun p => field p.1 p.2) L *
    orderedProduct (fun i => quarticField d (I i) (timeRepresentative β hβ (u i))))

/-- The inserted scalar Wick vertex integrand is genuinely Borel measurable. -/
theorem vertexIntegrand_measurable (d : ℕ) {β : ℝ} (hβ : 0 < β)
    (L : List (Label (2*d) β)) (hL : Even L.length) {k : ℕ}
    (I : Fin k → Majorana.FourSet d) : Measurable (vertexIntegrand d hβ L I) := by
  let T : List (Fin (2*d) × ((Fin k → ℝ) → Time β)) :=
    (L.map (fun p => (p.1, fun _ => p.2))) ++
      (List.ofFn (fun i => List.ofFn (fun a : Fin 4 =>
        (Majorana.fourIndex d (I i) a, fun u => timeRepresentative β hβ (u i))))).flatten
  have hT : Even T.length := by
    have ht : T.length = L.length+k*4 := by
      simp [T, List.length_flatten, List.map_ofFn, Function.comp_def, List.sum_ofFn]
    rw [ht]
    exact hL.add (Even.mul_left (by decide : Even 4) k)
  have hm : ∀ p ∈ T, Measurable (fun x => (p.2 x).val) := by
    intro p hp
    rcases List.mem_append.mp hp with hp | hp
    · obtain ⟨q, hq, rfl⟩ := List.mem_map.mp hp
      change Measurable (fun _ : Fin k → ℝ => q.2.val)
      exact measurable_const
    · obtain ⟨B, hB, hp⟩ := List.mem_flatten.mp hp
      obtain ⟨i, rfl⟩ := List.mem_ofFn.mp hB
      obtain ⟨a, rfl⟩ := List.mem_ofFn.mp hp
      exact measurable_subtype_coe.comp ((timeRepresentative_measurable β hβ).comp (measurable_pi_apply i))
  have h := measurable_expectation_list d hβ T hT hm
  have he (x : Fin k → ℝ) :
      FreeWick.word (fun p : Label (2*d) β => field p.1 p.2)
        (T.map (fun p => (p.1, p.2 x))) =
      FreeWick.word (fun p : Label (2*d) β => field p.1 p.2) L *
        orderedProduct (fun i => quarticField d (I i) (timeRepresentative β hβ (x i))) := by
    simp only [T, List.map_append, FreeWick.word_append]
    congr 1
    · simp only [List.map_map, Function.comp_def, Prod.mk.eta]
      congr 1
      exact List.map_id L
    · rw [List.map_flatten]
      simp only [List.map_ofFn, Function.comp_def]
      exact historyLabels_exterior_word d I (fun i => timeRepresentative β hβ (x i))
  simpa only [he, vertexIntegrand] using h

/-- Sharp uniform scalar integrand estimate, including all collisions. -/
theorem vertexIntegrand_bound (d : ℕ) {β : ℝ} (hβ : 0 < β)
    (L : List (Label (2*d) β)) (hL : Even L.length) {k : ℕ}
    (I : Fin k → Majorana.FourSet d) (u : Fin k → ℝ) :
    ‖vertexIntegrand d hβ L I u‖ ≤ ((Real.sqrt 2)⁻¹)^L.length * (1/4 : ℝ)^k :=
  wick_inserted_vertex_history_bound d hβ L hL I (fun i => timeRepresentative β hβ (u i))

/-- The actual closed time cube has finite Lebesgue volume. -/
theorem timeCube_compact (k : ℕ) (β : ℝ) :
    IsCompact (OrderedCubePartition.timeCube k 0 β) :=
  isCompact_univ_pi (fun _ => isCompact_Icc)

/-- Its volume is exactly beta to the number of interaction vertices. -/
theorem timeCube_volume_real (k : ℕ) {β : ℝ} (hβ : 0 < β) :
    volume.real (OrderedCubePartition.timeCube k 0 β) = β^k := by
  rw [MeasureTheory.measureReal_def, OrderedCubePartition.timeCube, volume_pi_pi,
    ENNReal.toReal_prod]
  simp [Real.volume_Icc, ENNReal.toReal_ofReal hβ.le]

/-- Integrability of each actual inserted quartic Wick history follows from
measurability, the proved uniform Wick bound, and finite time volume. -/
theorem vertexIntegrand_integrable (d : ℕ) {β : ℝ} (hβ : 0 < β)
    (L : List (Label (2*d) β)) (hL : Even L.length) {k : ℕ}
    (I : Fin k → Majorana.FourSet d) :
    IntegrableOn (vertexIntegrand d hβ L I) (OrderedCubePartition.timeCube k 0 β) := by
  have hfin := (timeCube_compact k β).measure_lt_top (μ := volume)
  haveI : IsFiniteMeasure (volume.restrict (OrderedCubePartition.timeCube k 0 β)) :=
    ⟨by simpa only [Measure.restrict_apply_univ] using hfin⟩
  apply (integrable_const (((Real.sqrt 2)⁻¹)^L.length * (1/4 : ℝ)^k)).mono'
  · exact (vertexIntegrand_measurable d hβ L hL I).aestronglyMeasurable
  · exact Filter.Eventually.of_forall (vertexIntegrand_bound d hβ L hL I)

/-- Actual scalar integrated vertex moment, before the exponential factorial
and Gaussian coupling averages. -/
def vertexMoment (d : ℕ) {β : ℝ} (hβ : 0 < β)
    (L : List (Label (2*d) β)) {k : ℕ} (I : Fin k → Majorana.FourSet d) : ℂ :=
  ∫ u in OrderedCubePartition.timeCube k 0 β, vertexIntegrand d hβ L I u

/-- Exact factorial-free integrated majorant, with every external insertion
and the actual thermal volume accounted for. -/
theorem vertexMoment_bound (d : ℕ) {β : ℝ} (hβ : 0 < β)
    (L : List (Label (2*d) β)) (hL : Even L.length) {k : ℕ}
    (I : Fin k → Majorana.FourSet d) :
    ‖vertexMoment d hβ L I‖ ≤ ((Real.sqrt 2)⁻¹)^L.length * (β/4)^k := by
  have h := norm_setIntegral_le_of_norm_le_const_ae
    ((timeCube_compact k β).measure_lt_top (μ := volume))
    (Filter.Eventually.of_forall (vertexIntegrand_bound d hβ L hL I))
  rw [timeCube_volume_real k hβ] at h
  convert h using 1 <;> simp only [div_pow, one_div_pow] <;> ring

/-- Relabeling a history amounts to the inverse change of time coordinates;
even quartic vertices contribute no fermionic sign. -/
theorem vertexIntegrand_permutation (d : ℕ) {β : ℝ} (hβ : 0 < β)
    (L : List (Label (2*d) β)) {k : ℕ} (I : Fin k → Majorana.FourSet d)
    (σ : Equiv.Perm (Fin k)) (u : Fin k → ℝ) :
    vertexIntegrand d hβ L (I ∘ σ) u =
      vertexIntegrand d hβ L I (u ∘ σ.symm) := by
  unfold vertexIntegrand
  congr 2
  simpa only [Function.comp_def, Equiv.symm_apply_apply] using
    vertex_product_permutation d I (fun i => timeRepresentative β hβ (u (σ.symm i))) σ

/-- The time cube is invariant under actual coordinate permutations. -/
theorem timeCube_preimage {k : ℕ} (β : ℝ) (σ : Equiv.Perm (Fin k)) :
    OrderedCubePartition.timePermutation σ ⁻¹' OrderedCubePartition.timeCube k 0 β =
      OrderedCubePartition.timeCube k 0 β := by
  ext u
  simp only [Set.mem_preimage, OrderedCubePartition.timePermutation_apply,
    OrderedCubePartition.timeCube, Set.mem_univ_pi, Function.comp_def]
  constructor
  · intro h i; simpa using h (σ.symm i)
  · intro h i; exact h (σ i)

/-- Integrated quartic moments are genuinely symmetric in their finite
vertex labels, derived from measure-preserving time relabeling. -/
theorem vertexMoment_permutation (d : ℕ) {β : ℝ} (hβ : 0 < β)
    (L : List (Label (2*d) β)) {k : ℕ} (I : Fin k → Majorana.FourSet d)
    (σ : Equiv.Perm (Fin k)) :
    vertexMoment d hβ L (I ∘ σ) = vertexMoment d hβ L I := by
  unfold vertexMoment
  simp_rw [vertexIntegrand_permutation]
  have h := (OrderedCubePartition.timePermutation_measurePreserving σ.symm).setIntegral_preimage_emb
    (OrderedCubePartition.timePermutation σ.symm).measurableEmbedding
    (vertexIntegrand d hβ L I) (OrderedCubePartition.timeCube k 0 β)
  rw [timeCube_preimage] at h
  simpa only [OrderedCubePartition.timePermutation_apply] using h

/-- The concrete degreewise integrated exterior-vertex functional on the
ordinary polynomial ring of disorder labels. Its coefficients are genuine
scalar Lebesgue integrals, not formal expectation symbols. -/
def vertexFunctional (d : ℕ) {β : ℝ} (hβ : 0 < β) (L : List (Label (2*d) β)) :
    MvPolynomial (Majorana.FourSet d) ℂ →ₗ[ℂ] ℂ :=
  SymmetricMomentFunctional.functional (fun _ => vertexMoment d hβ L)

/-- The coefficientwise functional agrees with every integrated vertex
history, including repeated quartic labels and the empty history. -/
theorem vertexFunctional_product (d : ℕ) {β : ℝ} (hβ : 0 < β)
    (L : List (Label (2*d) β)) {k : ℕ} (I : Fin k → Majorana.FourSet d) :
    vertexFunctional d hβ L (∏ i, MvPolynomial.X (I i)) = vertexMoment d hβ L I :=
  SymmetricMomentFunctional.functional_tuple_prod (fun _ => vertexMoment d hβ L)
    (fun _ I σ => vertexMoment_permutation d hβ L I σ) I

end SYK.WickVertexIntegrals
