import SYKMainTheorem
import SYKRepresentationCorollaries
import AbstractMomentTransport

/-!
# The complete theorem for abstract finite-dimensional realizations

All moment numerators below are built from actual continuous-operator thermal
histories and the basis-free ordinary trace. Their normalized Gaussian moments
are proved representation independent. The final theorem packages the physical
family with both abstract-space pressure and free-energy limits and the whole
moment addendum, with no selected basis or equivalence in its hypotheses.
-/
noncomputable section
open MeasureTheory Filter Set
open scoped Topology BigOperators NNReal
namespace SYK.ContinuumSYKMain
open Continuum ThermalEndpointLift ThermalMomentTransport WeightedKernelAlgebra
variable (β : ℝ) [Fact (0 < β)]

/-- Signed all-real thermal extension of the actual basis-free collective
moment. The representative reduction precedes the operator Weyl convention. -/
def abstractThermalCollectiveMoment {E : Type*} [NormedAddCommGroup E]
    [NormedSpace ℂ E] [FiniteDimensional ℂ E]
    (d : ℕ) (x : Fin (2*d) → E →L[ℂ] E) (lam : ℝ≥0)
    {k : ℕ} (p : Fin k → Endpoint) : ℂ :=
  (∏ i, pairSign β Fact.out (p i)) *
    AbstractRepresentation.collectiveMoment d x β lam
      (fun i => ((representative β Fact.out (p i).1).val,
        (representative β Fact.out (p i).2).val))

variable {E : ℕ → Type*} [∀ d, NormedAddCommGroup (E d)] [∀ d, NormedSpace ℂ (E d)]
  [∀ d, FiniteDimensional ℂ (E d)]
  (x : ∀ d, Fin (2*d) → E d →L[ℂ] E d)
  (hx : ∀ d, 2 ≤ d → ∀ i j, x d i*x d j+x d j*x d i =
    FreeWick.flavorDelta i j • (1 : E d →L[ℂ] E d))
  (hdim : ∀ d, 2 ≤ d → Module.finrank ℂ (E d) = 2^d)
include hx hdim

/-- Full uniform primary-domain moment convergence in every abstract
realization, including all endpoint coincidences and finite polynomial degrees. -/
theorem MainConclusion.abstract_primary_moments {g : ℝ≥0 → ℝ → ℝ}
    (h : MainConclusion β g) (lam : ℝ≥0) (k : ℕ) :
    TendstoUniformly
      (fun d (p : Fin k → Ico (0:ℝ) β × Ico (0:ℝ) β) =>
        AbstractRepresentation.collectiveMoment d (x d) β lam
          (fun i => ((p i).1.val,(p i).2.val)))
      (fun p => ∏ i, (g lam ((p i).1.val-(p i).2.val) : ℂ)) atTop := by
  have he : (fun d (p : Fin k → Ico (0:ℝ) β × Ico (0:ℝ) β) =>
      AbstractRepresentation.collectiveMoment d (x d) β lam
        (fun i => ((p i).1.val,(p i).2.val))) =ᶠ[atTop]
      (fun d p => Interacting.collectiveMoment d β lam
        (fun i => ((p i).1.val,(p i).2.val))) := by
    filter_upwards [eventually_ge_atTop 2] with d hd
    funext p
    exact AbstractRepresentation.collectiveMoment_eq d (x d) (hx d hd) (hdim d hd) β lam _
  exact (tendstoUniformly_congr he).mpr ((h.moments lam).primary k)

/-- Full uniform all-real convergence with the exact signed thermal endpoint
convention, for genuine abstract-space operator moments. -/
theorem MainConclusion.abstract_thermal_moments {g : ℝ≥0 → ℝ → ℝ}
    (h : MainConclusion β g) (lam : ℝ≥0) (k : ℕ) :
    TendstoUniformly
      (fun d (p : Fin k → Endpoint) => abstractThermalCollectiveMoment β d (x d) lam p)
      (fun p => ∏ i, (g lam ((p i).1-(p i).2) : ℂ)) atTop := by
  have he : (fun d (p : Fin k → Endpoint) => abstractThermalCollectiveMoment β d (x d) lam p)
      =ᶠ[atTop] (fun d p => actualThermalPolynomial β Fact.out d lam
        (∏ i, MvPolynomial.X (p i))) := by
    filter_upwards [eventually_ge_atTop 2] with d hd
    funext p
    rw [actualThermalPolynomial_tuple]
    unfold abstractThermalCollectiveMoment
    rw [AbstractRepresentation.collectiveMoment_eq d (x d) (hx d hd) (hdim d hd)]
  exact (tendstoUniformly_congr he).mpr ((h.moments lam).thermal k)

omit hx hdim in
/-- Actual conclusions for the supplied abstract operator family. This records
results, not assumed microscopic identities or representation equivalences. -/
structure AbstractRealizationConclusion (g : ℝ≥0 → ℝ → ℝ) : Prop where
  pressure : ∀ J : ℝ,
    Tendsto (fun d => AbstractRepresentation.annealedPressure d (x d) β (couplingOfJ J))
      atTop (𝓝 (couplingPressure β g (couplingOfJ J))) ∧
    Tendsto (fun d => AbstractRepresentation.quenchedPressure d (x d) β (couplingOfJ J))
      atTop (𝓝 (couplingPressure β g (couplingOfJ J)))
  free_energy : ∀ J : ℝ,
    Tendsto (fun d => -AbstractRepresentation.annealedPressure d (x d) β (couplingOfJ J)/β)
      atTop (𝓝 (couplingFreeEnergy β g J)) ∧
    Tendsto (fun d => -AbstractRepresentation.quenchedPressure d (x d) β (couplingOfJ J)/β)
      atTop (𝓝 (couplingFreeEnergy β g J))
  primary_moments : ∀ (lam : ℝ≥0) (k : ℕ), TendstoUniformly
    (fun d (p : Fin k → Ico (0:ℝ) β × Ico (0:ℝ) β) =>
      AbstractRepresentation.collectiveMoment d (x d) β lam
        (fun i => ((p i).1.val,(p i).2.val)))
    (fun p => ∏ i, (g lam ((p i).1.val-(p i).2.val) : ℂ)) atTop
  thermal_moments : ∀ (lam : ℝ≥0) (k : ℕ), TendstoUniformly
    (fun d (p : Fin k → Endpoint) => abstractThermalCollectiveMoment β d (x d) lam p)
    (fun p => ∏ i, (g lam ((p i).1-(p i).2) : ℂ)) atTop

/-- The complete actual realization conclusion follows from CAR and the
manuscript's dimension alone, and only at the sizes N=2d≥4 that it assumes. -/
theorem MainConclusion.abstract_realization {g : ℝ≥0 → ℝ → ℝ}
    (h : MainConclusion β g) : AbstractRealizationConclusion β x g :=
  ⟨h.abstract_pressures β x hx hdim, h.abstract_freeEnergy β x hx hdim,
    h.abstract_primary_moments β x hx hdim, h.abstract_thermal_moments β x hx hdim⟩

end SYK.ContinuumSYKMain

namespace SYK.SYKMainTheorem
open ContinuumSYKMain

/-- Complete continuum SYK theorem for an arbitrary sequence of abstract
finite-dimensional complex realizations, hence for every Hilbert-space
Majorana family in the manuscript. Physical existence, the positive ordinary
Fredholm action, both pressure/free-energy limits, and all collective moments
are simultaneous consequences. No basis, state, Ward identity, positivity,
response, limiting solution, or convergence theorem is assumed. -/
theorem continuum_free_energy_abstract (β : ℝ) (hβ : 0 < β)
    {E : ℕ → Type*} [∀ d, NormedAddCommGroup (E d)] [∀ d, NormedSpace ℂ (E d)]
    [∀ d, FiniteDimensional ℂ (E d)]
    (x : ∀ d, Fin (2*d) → E d →L[ℂ] E d)
    (hx : ∀ d, 2 ≤ d → ∀ i j, x d i*x d j+x d j*x d i =
      FreeWick.flavorDelta i j • (1 : E d →L[ℂ] E d))
    (hdim : ∀ d, 2 ≤ d → Module.finrank ℂ (E d) = 2^d) :
    ∃ g : ℝ≥0 → ℝ → ℝ, @MainConclusion β ⟨hβ⟩ g ∧
      @AbstractRealizationConclusion β ⟨hβ⟩ E _ _ _ x g := by
  letI : Fact (0 < β) := ⟨hβ⟩
  obtain ⟨g,hg⟩ := continuum_free_energy β hβ
  exact ⟨g,hg,hg.abstract_realization β x hx hdim⟩

end SYK.SYKMainTheorem
