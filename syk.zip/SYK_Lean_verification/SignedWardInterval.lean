import SignedWardIdentity

/-! # Literal interval-integral form of the actual signed microscopic Ward identity -/
noncomputable section
open scoped BigOperators NNReal
open MeasureTheory Set
namespace SYK.SignedWardReduction
open ThermalWick ThermalEndpointLift ThermalMomentTransport WeightedKernelAlgebra MvPolynomial
open ContinuumWickSeries

variable (β : ℝ) (hβ : 0<β)

/-- The all-real actual inserted interaction density is Borel measurable,
including external and internal seams and all coincidence surfaces. -/
theorem actual_interaction_measurable (d : ℕ) (lam : ℝ≥0)
    (Q : RealPolynomial) (s t : ℝ) :
    Measurable (fun p : ℝ×ℝ => actualThermalPolynomial β hβ d lam (Q*realInteraction β s t p)) := by
  have hm := actualThermal_inserted_measurable β hβ d lam Q
    (fun p : ℝ×ℝ => ![(p.1,p.2),(p.1,p.2),(p.1,p.2),(p.2,t)])
    (by intro i; fin_cases i <;> dsimp <;> fun_prop)
  have hC : Measurable (fun p : ℝ×ℝ => (Thermal.kernel β s p.1:ℂ)) :=
    Complex.measurable_ofReal.comp ((Thermal.covariance_measurable β).comp
    (measurable_const.sub measurable_fst))
  simpa only [realInteraction,mul_smul_comm,map_smul,smul_eq_mul,
    MixedIncrement.coordinateProduct,List.map_cons,List.map_nil,List.prod_cons,List.prod_nil,
    Fin.prod_univ_succ,Fin.prod_univ_zero,Matrix.cons_val_zero,Matrix.cons_val_succ,mul_one]
    using hC.mul hm

/-- Uniform actual four-point bound discharges all integrability needed for
conversion of the physical pair measure to iterated thermal intervals. -/
theorem actual_interaction_bound (d : ℕ) (hd : 0<d) (lam : ℝ≥0)
    (Q : RealPolynomial) (s t : ℝ) (p : ℝ×ℝ) :
    ‖actualThermalPolynomial β hβ d lam (Q*realInteraction β s t p)‖ ≤
      coefficientNorm (fun _ : Endpoint => (1/2:ℝ)) Q /32 := by
  simp only [realInteraction,mul_smul_comm,map_smul,smul_eq_mul,norm_mul]
  have hc : ‖(Thermal.kernel β s p.1:ℂ)‖ ≤ 1/2 := by
    simpa only [Complex.norm_real,Real.norm_eq_abs] using Thermal.abs_covariance_le β (s-p.1)
  have hm := MixedIncrement.inserted_four_bound (actualThermalPolynomial β hβ d lam)
    (actualThermalPolynomial_bound β hβ d hd lam) Q
    [(p.1,p.2),(p.1,p.2),(p.1,p.2),(p.2,t)] rfl
  exact (mul_le_mul hc hm (norm_nonneg _) (by norm_num : (0:ℝ) ≤ 1/2)).trans_eq (by ring)

 theorem actual_interaction_integrable (d : ℕ) (hd : 0<d) (lam : ℝ≥0)
    (Q : RealPolynomial) (s t : ℝ) :
    Integrable (fun p : ℝ×ℝ => actualThermalPolynomial β hβ d lam (Q*realInteraction β s t p))
      (pairMeasure β) :=
  (integrable_const (coefficientNorm (fun _ : Endpoint => (1/2:ℝ)) Q /32)).mono'
    (actual_interaction_measurable β hβ d lam Q s t).aestronglyMeasurable
    (Filter.Eventually.of_forall (actual_interaction_bound β hβ d hd lam Q s t))

include hβ in
/-- Fubini and the null boundary faces identify the exact closed-square
measure used in the Wick series with the literal thermal interval integrals. -/
theorem pairIntegral_eq_interval (F : ℝ×ℝ → ℂ) (hF : Integrable F (pairMeasure β)) :
    (∫ p, F p ∂pairMeasure β) = ∫ u in (0:ℝ)..β, ∫ v in (0:ℝ)..β, F (u,v) := by
  rw [pairMeasure,integral_prod _ hF]
  simp only [integral_Icc_eq_integral_Ioc,intervalIntegral.integral_of_le hβ.le]

/-- Final actual finite left Ward identity at every real external endpoint,
with the exact contact derivation and the original interval convolution. -/
theorem actualWard_interval_of_fundamental (d : ℕ) (hd : 0<d) (lam : ℝ≥0)
    (hward : ∀ (P : TimePolynomial β) (s t : Time β),
      actualFundamental β d lam (P*FundamentalWardBridge.remainder s t) =
        (lam:ℂ)*(∫ p, actualFundamental β d lam
          (P*FundamentalWardBridge.interactionPolynomial β hβ s t p) ∂pairMeasure β) +
          (((2*d:ℕ):ℂ)⁻¹)*actualFundamental β d lam (FundamentalWardContacts.contact s t P))
    (Q : RealPolynomial) (s t : ℝ) :
    actualThermalPolynomial β hβ d lam (Q*MixedIncrement.remainder β (s,t)) =
      (lam:ℂ)*(∫ u in (0:ℝ)..β, ∫ v in (0:ℝ)..β, (Thermal.kernel β s u:ℂ)*
        actualThermalPolynomial β hβ d lam
          (Q*MixedIncrement.coordinateProduct [(u,v),(u,v),(u,v),(v,t)])) +
        (((2*d:ℕ):ℂ)⁻¹)*actualThermalPolynomial β hβ d lam (RealWardContacts.contact β s t Q) := by
  have h := actualWard_of_fundamental β hβ (pairMeasure β) d lam hward Q s t
  have hi := pairIntegral_eq_interval β hβ
    (fun p => actualThermalPolynomial β hβ d lam (Q*realInteraction β s t p))
    (actual_interaction_integrable β hβ d hd lam Q s t)
  simp only [realInteraction,mul_smul_comm,map_smul,smul_eq_mul] at hi
  rw [hi] at h
  exact h

end SYK.SignedWardReduction
