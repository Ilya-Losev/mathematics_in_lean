import ThermalResidualState
import FiniteWardRegularity

/-!
# Actual finite Ward residuals vanish in the constructed thermal limit

The scalar two-sided inserted Ward equations are derived from literal
finite-size residual estimates and dominated convergence on the actual
thermal square. They are not assumed of the limiting state.
-/

noncomputable section
open scoped BigOperators Topology NNReal
open MeasureTheory Filter Set
open SYK.WeightedKernelAlgebra SYK.MomentCompactness SYK.MomentLimit
open SYK.ThermalEndpointLift SYK.ThermalMomentTransport SYK.ThermalWeightedState
open SYK.ThermalResidualState SYK.MixedIncrement

namespace SYK.ThermalWardLimit

/-- Actual left finite-size inserted Ward residual. -/
def leftResidual (β : ℝ) (hβ : 0 < β) (lam : ℝ≥0) (d : ℕ)
    (Q : RealPolynomial) (s t : ℝ) : ℂ :=
  actualThermalPolynomial β hβ d lam (Q*MixedIncrement.remainder β (s,t)) -
    (lam:ℂ)*(∫ u in (0:ℝ)..β, ∫ v in (0:ℝ)..β,
      (Thermal.kernel β s u:ℂ)*actualThermalPolynomial β hβ d lam
        (Q*coordinateProduct [(u,v),(u,v),(u,v),(v,t)]))

/-- Actual right finite-size inserted Ward residual. -/
def rightResidual (β : ℝ) (hβ : 0 < β) (lam : ℝ≥0) (d : ℕ)
    (Q : RealPolynomial) (s t : ℝ) : ℂ :=
  actualThermalPolynomial β hβ d lam (Q*MixedIncrement.remainder β (s,t)) -
    (lam:ℂ)*(∫ u in (0:ℝ)..β, ∫ v in (0:ℝ)..β,
      (Thermal.kernel β v t:ℂ)*actualThermalPolynomial β hβ d lam
        (Q*coordinateProduct [(s,u),(u,v),(u,v),(u,v)]))

/-- Concrete microscopic premises: inverse-dimension contacts for arbitrary
inserted polynomials, and the sharper centered contact needed for compactness. -/
structure FiniteWardControl (β : ℝ) (hβ : 0 < β) (lam : ℝ≥0) (d : ℕ → ℕ) : Prop where
  left : ∀ Q s t, ∃ A : ℝ, ∀ n, ‖leftResidual β hβ lam (d n) Q s t‖ ≤ A / (d n : ℝ)
  right : ∀ Q s t, ∃ A : ℝ, ∀ n, ‖rightResidual β hβ lam (d n) Q s t‖ ≤ A / (d n : ℝ)
  centered : ∀ n (l : List Endpoint) s t,
    ‖leftResidual β hβ lam (d n) (remainderProduct β l) s t‖ ≤ (l.length : ℝ)/(4*d n)

theorem FiniteWardControl.comp {β : ℝ} {hβ : 0 < β} {lam : ℝ≥0} {d : ℕ → ℕ}
    (h : FiniteWardControl β hβ lam d) (φ : ℕ → ℕ) : FiniteWardControl β hβ lam (d ∘ φ) := by
  refine ⟨?_, ?_, fun n => h.centered (φ n)⟩
  · intro Q s t; obtain ⟨A, hA⟩ := h.left Q s t; exact ⟨A, fun n => hA (φ n)⟩
  · intro Q s t; obtain ⟨A, hA⟩ := h.right Q s t; exact ⟨A, fun n => hA (φ n)⟩

/-- Dominated convergence on the literal iterated thermal interval. -/
theorem double_integral_tendsto (β : ℝ) (hβ : 0 ≤ β) (F : ℕ → ℝ×ℝ → ℂ)
    (G : ℝ×ℝ → ℂ) (B : ℝ) (hm : ∀ n, Measurable (F n))
    (hb : ∀ n p, ‖F n p‖ ≤ B) (hlim : ∀ p, Tendsto (fun n => F n p) atTop (𝓝 (G p))) :
    Tendsto (fun n => ∫ u in (0:ℝ)..β, ∫ v in (0:ℝ)..β, F n (u,v)) atTop
      (𝓝 (∫ u in (0:ℝ)..β, ∫ v in (0:ℝ)..β, G (u,v))) := by
  let μ := volume.restrict (Ioc (0:ℝ) β)
  have hGm : Measurable G := measurable_of_tendsto_metrizable hm (tendsto_pi_nhds.mpr hlim)
  have hGb (p) : ‖G p‖ ≤ B := le_of_tendsto (hlim p |>.norm) (Eventually.of_forall (fun n => hb n p))
  have hi (n) : Integrable (F n) (μ.prod μ) :=
    (integrable_const B).mono' (hm n).aestronglyMeasurable (Eventually.of_forall (hb n))
  have hGi : Integrable G (μ.prod μ) :=
    (integrable_const B).mono' hGm.aestronglyMeasurable (Eventually.of_forall hGb)
  have h := tendsto_integral_of_dominated_convergence (μ := μ.prod μ) (fun _ => B)
    (fun n => (hm n).aestronglyMeasurable) (integrable_const B)
    (fun n => Eventually.of_forall (hb n)) (Eventually.of_forall hlim)
  simp only [intervalIntegral.integral_of_le hβ]
  change Tendsto (fun n => ∫ u, ∫ v, F n (u,v) ∂μ ∂μ) atTop
    (𝓝 (∫ u, ∫ v, G (u,v) ∂μ ∂μ))
  simpa only [integral_prod _ (hi _), integral_prod _ hGi] using h

variable (β : ℝ) (hβ : 0 < β) (lam : ℝ≥0) (d : ℕ → ℕ) (hd : ∀ n, 0 < d n)
    (G : ∀ k, EndpointCube β k → ℂ)
    (hG : ∀ k, TendstoUniformly
      (fun n => functionalCenteredMoment (actualCorrectedPolynomial β hβ (d n) lam)) (G k) atTop)

include hd hG in
/-- Every bounded-covariance inserted four-point integral converges; finite
measurability and bounds are discharged using the actual moment formulas. -/
theorem inserted_four_integral_tendsto (Q : RealPolynomial)
    (p : ℝ×ℝ → Fin 4 → Endpoint) (hp : ∀ i, Measurable (fun x => p x i))
    (c : ℝ×ℝ → ℂ) (hc : Measurable c) (hcb : ∀ x, ‖c x‖ ≤ 1/2) :
    Tendsto (fun n => ∫ u in (0:ℝ)..β, ∫ v in (0:ℝ)..β,
      c (u,v)*actualThermalPolynomial β hβ (d n) lam (Q*∏ i, MvPolynomial.X (p (u,v) i))) atTop
      (𝓝 (∫ u in (0:ℝ)..β, ∫ v in (0:ℝ)..β,
        c (u,v)*polynomialState β hβ G (Q*∏ i, MvPolynomial.X (p (u,v) i)))) := by
  apply double_integral_tendsto β hβ.le
    (fun n x => c x * actualThermalPolynomial β hβ (d n) lam (Q*∏ i, MvPolynomial.X (p x i)))
    (fun x => c x * polynomialState β hβ G (Q*∏ i, MvPolynomial.X (p x i)))
    (coefficientNorm (fun _ => (1/2:ℝ)) Q / 32)
  · intro n
    exact hc.mul (actualThermal_inserted_measurable β hβ (d n) lam Q p hp)
  · intro n x
    have hm := inserted_four_bound (actualThermalPolynomial β hβ (d n) lam)
      (actualThermalPolynomial_bound β hβ (d n) (hd n) lam) Q (List.ofFn (p x)) (by simp)
    simp only [coordinateProduct, List.map_ofFn, List.prod_ofFn] at hm
    rw [norm_mul]
    have hh := mul_le_mul (hcb x) hm (norm_nonneg _) (by norm_num : (0:ℝ) ≤ 1/2)
    exact hh.trans_eq (by ring)
  · intro x
    exact tendsto_const_nhds.mul (actualThermal_polynomial_tendsto β hβ lam d G hG _)

include hd hG in
/-- Literal finite left contact bounds imply the exact limiting inserted SD identity. -/
theorem leftWard_of_finite (hdtop : Tendsto d atTop atTop)
    (hward : FiniteWardControl β hβ lam d) : LeftWard β (lam : ℝ) (polynomialState β hβ G) := by
  intro Q s t
  have hi := inserted_four_integral_tendsto β hβ lam d hd G hG Q
    (fun p : ℝ×ℝ => ![(p.1,p.2),(p.1,p.2),(p.1,p.2),(p.2,t)])
    (by intro i; fin_cases i <;> dsimp <;> fun_prop)
    (fun p => (Thermal.kernel β s p.1 : ℂ))
    (Complex.measurable_ofReal.comp ((Thermal.covariance_measurable β).comp
      (measurable_const.sub measurable_fst)))
    (fun p => by simpa only [Complex.norm_real, Real.norm_eq_abs] using Thermal.abs_covariance_le β (s-p.1))
  simp only [Fin.prod_univ_succ, Fin.prod_univ_zero, Matrix.cons_val_zero, Matrix.cons_val_succ,
    mul_one] at hi
  obtain ⟨A, hA⟩ := hward.left Q s t
  have hz := contact_error_tendsto d hdtop A (fun n => leftResidual β hβ lam (d n) Q s t) hA
  have hh := (actualThermal_polynomial_tendsto β hβ lam d G hG
    (Q*MixedIncrement.remainder β (s,t))).sub ((tendsto_const_nhds (x := (lam:ℂ))).mul hi)
  simp only [leftResidual, rightResidual, coordinateProduct, List.map_cons, List.map_nil,
    List.prod_cons, List.prod_nil, mul_one] at hz
  have he := tendsto_nhds_unique hh hz
  simpa only [leftResidual, coordinateProduct, List.map_cons, List.map_nil,
    List.prod_cons, List.prod_nil, mul_one, sub_eq_zero] using he

include hd hG in
/-- Literal finite right contact bounds imply the independent limiting right identity. -/
theorem rightWard_of_finite (hdtop : Tendsto d atTop atTop)
    (hward : FiniteWardControl β hβ lam d) : RightWard β (lam : ℝ) (polynomialState β hβ G) := by
  intro Q s t
  have hi := inserted_four_integral_tendsto β hβ lam d hd G hG Q
    (fun p : ℝ×ℝ => ![(s,p.1),(p.1,p.2),(p.1,p.2),(p.1,p.2)])
    (by intro i; fin_cases i <;> dsimp <;> fun_prop)
    (fun p => (Thermal.kernel β p.2 t : ℂ))
    (Complex.measurable_ofReal.comp ((Thermal.covariance_measurable β).comp
      (measurable_snd.sub measurable_const)))
    (fun p => by simpa only [Complex.norm_real, Real.norm_eq_abs] using Thermal.abs_covariance_le β (p.2-t))
  simp only [Fin.prod_univ_succ, Fin.prod_univ_zero, Matrix.cons_val_zero, Matrix.cons_val_succ,
    mul_one] at hi
  obtain ⟨A, hA⟩ := hward.right Q s t
  have hz := contact_error_tendsto d hdtop A (fun n => rightResidual β hβ lam (d n) Q s t) hA
  have hh := (actualThermal_polynomial_tendsto β hβ lam d G hG
    (Q*MixedIncrement.remainder β (s,t))).sub ((tendsto_const_nhds (x := (lam:ℂ))).mul hi)
  simp only [leftResidual, rightResidual, coordinateProduct, List.map_cons, List.map_nil,
    List.prod_cons, List.prod_nil, mul_one] at hz
  have he := tendsto_nhds_unique hh hz
  simpa only [rightResidual, coordinateProduct, List.map_cons, List.map_nil,
    List.prod_cons, List.prod_nil, mul_one, sub_eq_zero] using he

/-- The actual all-real centered insertion inherits microscopic skewness. -/
theorem actual_remainder_skew (d₀ : ℕ) (Q : RealPolynomial) (s t : ℝ) :
    actualThermalPolynomial β hβ d₀ lam (Q*MixedIncrement.remainder β (s,t)) =
      -actualThermalPolynomial β hβ d₀ lam (Q*MixedIncrement.remainder β (t,s)) := by
  simp only [MixedIncrement.remainder, mul_sub, map_sub]
  rw [actualThermal_inserted_skew β hβ d₀ lam Q t s,
    Thermal.kernel_skew β s t, Complex.ofReal_neg, MvPolynomial.C_neg, mul_neg, map_neg]
  ring

/-- Seam correction and centering agree with evaluation of the literal
all-real remainder polynomial, including both compact-cube boundary faces. -/
theorem compact_centered_eq_real (d₀ : ℕ) {k : ℕ} (p : EndpointCube β k) :
    functionalCenteredMoment (actualCorrectedPolynomial β hβ d₀ lam) p =
      actualThermalPolynomial β hβ d₀ lam (∏ i, MixedIncrement.remainder β (endpointValues p i)) := by
  change actualPolynomial d₀ β lam (cubeReduction β hβ (∏ i, remainderCoordinate β (p i))) =
    actualPolynomial d₀ β lam (polynomialReduction β hβ (∏ i, MixedIncrement.remainder β (endpointValues p i)))
  congr 1
  simp only [map_prod]
  apply Finset.prod_congr rfl
  intro i _
  simp only [remainderCoordinate, MixedIncrement.remainder, cubeReduction,
    polynomialReduction, map_sub, MvPolynomial.aeval_X, MvPolynomial.aeval_C,
    freeCoordinate, endpointValues]

include hd in
/-- No compactness modulus is assumed: the actual centered finite moments
satisfy the precise kλβ/8 Lipschitz coefficient and k(k−1)/d contact defect. -/
theorem actual_centered_modulus (hward : FiniteWardControl β hβ lam d)
    (k n : ℕ) (p q : EndpointCube β k) :
    ‖functionalCenteredMoment (actualCorrectedPolynomial β hβ (d n) lam) p -
      functionalCenteredMoment (actualCorrectedPolynomial β hβ (d n) lam) q‖ ≤
      ((k:ℝ)*(lam:ℝ)*β/8)*dist p q + ((k:ℝ)*((k-1:ℕ):ℝ))/(d n:ℝ) := by
  rw [compact_centered_eq_real, compact_centered_eq_real]
  apply (finite_centered_tuple_modulus β (lam:ℝ) hβ lam.coe_nonneg (d n)
    (actualThermalPolynomial β hβ (d n) lam)
    (actualThermalPolynomial_bound β hβ (d n) (hd n) lam)
    (fun l s t => leftResidual β hβ lam (d n) (remainderProduct β l) s t)
    (hward.centered n) ?_ ?_ ?_ k (endpointValues p) (endpointValues q)).trans_eq
      (by rw [endpointValues_dist])
  · intro l t
    have hm := actualThermal_inserted_measurable β hβ (d n) lam (remainderProduct β l)
      (fun p : ℝ×ℝ => ![(p.1,p.2),(p.1,p.2),(p.1,p.2),(p.2,t)])
      (by intro i; fin_cases i <;> dsimp <;> fun_prop)
    simpa only [Fin.prod_univ_succ, Fin.prod_univ_zero, Matrix.cons_val_zero, Matrix.cons_val_succ,
      coordinateProduct, List.map_cons, List.map_nil, List.prod_cons, List.prod_nil, mul_one] using hm
  · intro l s t
    simp only [leftResidual, add_sub_cancel]
  · intro l s t
    exact actual_remainder_skew β hβ lam (d n) (remainderProduct β l) s t

end SYK.ThermalWardLimit
