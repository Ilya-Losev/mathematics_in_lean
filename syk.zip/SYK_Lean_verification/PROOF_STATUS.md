# Proof assembly and verification status

## Main theorem

`SYK.SYKMainTheorem.continuum_free_energy` is unconditional and has passed direct
`lean --trust=0` compilation and explicit axiom auditing. Its only input is
β > 0. Its output is one physical family for all nonnegative couplings together
with every field of `ContinuumSYKMain.MainConclusion`.

The exact type and all conclusion structure fields were printed and reviewed.
The main theorem depends only on `propext`, `Classical.choice` and `Quot.sound`.
Final artifact verification is the complete clean source-snapshot run recorded
in `VERIFICATION.md`; do not confuse earlier checkpoints with that final run.

## Concrete dependency chain

| Stage | Checked concrete-model endpoint |
|---|---|
| Finite model | `Majorana`, `GaussianDisorder`, `GibbsState`, `MicroscopicPressure`: explicit CAR matrices, ordinary exponential trace, actual Gaussian law, positivity and integrability |
| Thermal moments | `ThermalMomentBound`, `InteractingMoments`: actual time-ordered Weyl/flavor moments, all tied blocks and sharp dimension-free bounds |
| Interacting Wick correspondence | `ActualWickChamberSeries`, `FieldDisorderSeries`, `WickGaussianRegrouping`, `CollectiveFieldExpansion`, `CollectiveWeylAverage`, `ActualWickCorrespondence`: convergent ordered-time histories and exact normalized list correspondence |
| Finite Ward | `IntegratedWickWard.numerator_ward`, `ActualWickWard`, `ActualMicroscopicIdentities.exact_left_ward`: exact inserted identities with all finite contacts |
| Symmetry and positivity | `WeylTranslation`, polynomial even/odd reflection modules and microscopic adapters: actual translation invariance and both reflection tests |
| Compactness and limiting algebra | `ThermalWardLimit`, `ThermalMomentTransport`, `ThermalWeightedState`, `ThermalResidualState`: corrected seam family, actual modulus and simultaneous limits, normalized nontrivial quotients |
| Analyticity and selection | Kernel SD/analyticity/actions, half generation, GNS, spectral representation, Hankel positivity and Fourier uniqueness produce a physical scalar kernel and factorization |
| Full convergence | `MicroscopicMomentConvergence`, `ActualMomentLimit`: every subsequence has the same physical limit, giving full uniform moment convergence and the exact fourth-moment integral limit |
| Actual pressure response | `WickSeriesDerivative`, `ActualWickPressure`, `ActualFourthResponse`, `ActualCorrespondenceConsequences`: actual annealed derivative equals the microscopic fourth-moment integral |
| Pressure limit | `PressureLimitAssembly`: actual domination, normalization and derivative limits; `PressureGap` supplies the independently proved vanishing quenched gap |
| Ordinary determinant | `PhysicalFredholm`: actual compact selfadjoint complex operator, summable nuclear expansion, full nonzero spectrum and algebraic multiplicities, intrinsic positive Fredholm determinant and exact action |
| Final assembly | `SYKMainTheorem.continuum_free_energy` supplies every formerly conditional microscopic premise from the checked model |

## Scope and extensions

- `FinalModelConventions` proves every integer midpoint, λ = J² and actual
  free-energy limit conversion with −1/β.
- `RepresentationIndependence` proves identical ordinary partition functions
  and pressures for all finite matrix CAR families of dimension 2^d.
- `ComplexFourierOperatorAction` and `ComplexPhysicalUniqueness` prove the
  literal action on every bounded complex test and its whole-space uniqueness.
- `AbstractRepresentationTransport`, `AbstractMomentTransport`,
  `SYKRepresentationCorollaries` and `SYKAbstractMomentCorollaries` prove actual
  basis-free pressure, free-energy and coincident-moment convergence for every
  finite-dimensional complex realization. The combined public endpoint is
  `SYK.SYKMainTheorem.continuum_free_energy_abstract`.

## Exact scope boundaries

The formalization establishes the main free-energy theorem and collective
moment convergence, not every auxiliary statement in the manuscript. Its
Gaussian concentration constant is nonsharp but gives the required O(1/N)
pressure gap. The separate convergence-in-probability/almost-sure remarks and all-L²
maximization assertion are not asserted. The Fredholm construction uses the ordinary spectral definition
for the actual compact selfadjoint target, rather than a general-purpose API
for arbitrary nonnormal trace-class operators. See `PROOF_GUIDE.md` for the
mathematical adaptations, including exact endpoint seam handling.
