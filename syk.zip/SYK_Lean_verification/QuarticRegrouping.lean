import NilpotentSymmetricSum
import WardMoments
import Majorana
import Mathlib.Algebra.Algebra.Subalgebra.Basic
import Mathlib.Data.Finset.Sort

noncomputable section
open Finset
namespace SYK.ThermalWick

abbrev FieldAlgebra (N : ℕ) (β : ℝ) := ExteriorAlgebra ℂ (FieldSpace N β)

/-- A bilocal lies in the genuine commutative center of the exterior algebra. -/
def centralBilocal {N : ℕ} {β : ℝ} (i : Fin N) (s t : Time β) :
    Subalgebra.center ℂ (FieldAlgebra N β) :=
  ⟨field i s * field i t, Subalgebra.mem_center_iff.mpr (fun a =>
    (Ward.even_commutes _ a (by simp [field])).symm)⟩

@[simp] theorem centralBilocal_coe {N : ℕ} {β : ℝ} (i : Fin N) (s t : Time β) :
    (centralBilocal i s t : FieldAlgebra N β) = field i s * field i t := rfl

theorem field_swap {N : ℕ} {β : ℝ} (i j : Fin N) (s t : Time β) :
    field i s * field j t = -(field j t * field i s) :=
  eq_neg_of_add_eq_zero_left (ExteriorAlgebra.ι_add_mul_swap _ _)

@[simp] theorem centralBilocal_sq {N : ℕ} {β : ℝ} (i : Fin N) (s t : Time β) :
    (centralBilocal i s t)^2 = 0 := by
  apply Subtype.ext
  simp only [Subalgebra.coe_pow, Subalgebra.coe_mul, Subalgebra.coe_zero, centralBilocal_coe, pow_two]
  calc
    _ = field i s * (field i t * field i s) * field i t := by simp only [mul_assoc]
    _ = -(field i s * field i s) * (field i t * field i t) := by
      rw [field_swap i i t s]
      noncomm_ring
    _ = 0 := by simp [field, ExteriorAlgebra.ι_sq_zero]

/-- Increasing quartic exterior vertex, with the same indexing as the
microscopic independent disorder coordinates. -/
def quarticField (d : ℕ) {β : ℝ} (I : Majorana.FourSet d) (u : Time β) :
    FieldAlgebra (2*d) β :=
  field (Majorana.fourIndex d I 0) u * field (Majorana.fourIndex d I 1) u *
  field (Majorana.fourIndex d I 2) u * field (Majorana.fourIndex d I 3) u

/-- Regrouping four bilocals crosses six fermionic pairs and has positive sign. -/
theorem four_bilocal_regroup {N : ℕ} {β : ℝ} (a b c d : Fin N) (u v : Time β) :
    (field a u*field a v)*(field b u*field b v)*
      (field c u*field c v)*(field d u*field d v) =
    (field a u*field b u*field c u*field d u)*
      (field a v*field b v*field c v*field d v) := by
  have hs (x y z : FieldAlgebra N β) (h : x*y=-(y*x)) :
      x*(y*z)=-(y*(x*z)) := by rw [← mul_assoc,h]; noncomm_ring
  simp only [mul_assoc]
  rw [hs _ _ _ (field_swap a b v u)]
  rw [hs _ _ _ (field_swap b c v u)]
  simp only [mul_neg, neg_mul, neg_neg]
  rw [hs _ _ _ (field_swap a c v u)]
  rw [hs _ _ _ (field_swap c d v u)]
  simp only [mul_neg, neg_mul, neg_neg]
  rw [hs _ _ _ (field_swap b d v u)]
  simp only [mul_neg, neg_mul, neg_neg]
  rw [hs _ _ _ (field_swap a d v u)]
  simp only [mul_neg, neg_mul, neg_neg]

theorem central_product_fourSet (d : ℕ) {β : ℝ} (I : Majorana.FourSet d)
    (u v : Time β) :
    ((∏ i ∈ I.val, centralBilocal i u v : Subalgebra.center ℂ (FieldAlgebra (2*d) β)) : FieldAlgebra (2*d) β) =
      quarticField d I u * quarticField d I v := by
  have he : ∏ i ∈ I.val, centralBilocal i u v =
      ∏ k : Fin 4, centralBilocal (Majorana.fourIndex d I k) u v := by
    rw [← I.val.map_orderEmbOfFin_univ I.property, Finset.prod_map]
    rfl
  rw [he]
  simp only [Fin.prod_univ_succ, Fin.sum_univ_zero, Fin.prod_univ_zero,
    Subalgebra.coe_mul, centralBilocal_coe, mul_one]
  simpa only [quarticField, mul_assoc] using
    four_bilocal_regroup (Majorana.fourIndex d I 0) (Majorana.fourIndex d I 1)
      (Majorana.fourIndex d I 2) (Majorana.fourIndex d I 3) u v

theorem central_powerset_sum (d : ℕ) {β : ℝ} (u v : Time β) :
    (∑ T ∈ (Finset.univ : Finset (Fin (2*d))).powersetCard 4,
      ∏ i ∈ T, centralBilocal i u v) =
    ∑ I : Majorana.FourSet d, ∏ i ∈ I.val, centralBilocal i u v := by
  classical
  exact Finset.sum_subtype _ (fun _ => Finset.mem_powersetCard_univ) _

/-- Exact regrouping before the collective 1/N normalization. -/
theorem sum_bilocal_fourth (d : ℕ) {β : ℝ} (u v : Time β) :
    (∑ i : Fin (2*d), field i u*field i v)^4 =
      (24:ℂ) • ∑ I : Majorana.FourSet d, quarticField d I u*quarticField d I v := by
  classical
  have h := NilpotentSymmetricSum.sum_fourth_eq_twentyfour_mul_subsets
    (fun i : Fin (2*d) => centralBilocal i u v) (fun i => centralBilocal_sq i u v)
  rw [central_powerset_sum d u v] at h
  have he := congrArg (Subalgebra.val (Subalgebra.center ℂ (FieldAlgebra (2*d) β))) h
  simp only [map_pow, map_mul, map_sum, map_ofNat] at he
  change (∑ i : Fin (2*d), field i u*field i v)^4 =
    (24:FieldAlgebra (2*d) β)*(∑ I : Majorana.FourSet d,
      ((∏ i ∈ I.val, centralBilocal i u v : Subalgebra.center ℂ (FieldAlgebra (2*d) β)) : FieldAlgebra (2*d) β)) at he
  simp_rw [central_product_fourSet] at he
  simpa only [Algebra.smul_def, map_ofNat] using he

/-- The precise coefficient converting independent increasing quartics into
the fourth collective power. -/
theorem quartic_regrouping (d : ℕ) (hd : 0 < d) {β : ℝ} (u v : Time β) :
    (∑ I : Majorana.FourSet d, quarticField d I u*quarticField d I v) =
      (((2*d:ℕ):ℂ)^4/24) • (collective (2*d) β u v)^4 := by
  rw [collective, smul_pow, sum_bilocal_fourth, smul_smul, smul_smul]
  have hc : (((2*d:ℕ):ℂ)^4/24)*((((2*d:ℕ):ℂ)⁻¹)^4)*(24:ℂ) = 1 := by
    have hdC : (d:ℂ) ≠ 0 := by exact_mod_cast hd.ne'
    field_simp [hdC]
    ring
  rw [hc, one_smul]

/-- Gaussian variance 6λ/N³ and the exponential factor 1/2 give exactly
Nλ/8, with no asymptotic replacement of four-set counts. -/
theorem gaussian_quartic_coefficient (d : ℕ) (hd : 0 < d) {β : ℝ}
    (lam : ℂ) (u v : Time β) :
    ((6*lam/(((2*d:ℕ):ℂ)^3))/2) •
      (∑ I : Majorana.FourSet d, quarticField d I u*quarticField d I v) =
    (((2*d:ℕ):ℂ)*lam/8) • (collective (2*d) β u v)^4 := by
  rw [quartic_regrouping d hd, smul_smul]
  congr 1
  have hdC : (d:ℂ) ≠ 0 := by exact_mod_cast hd.ne'
  field_simp [hdC]
  ring

end SYK.ThermalWick
