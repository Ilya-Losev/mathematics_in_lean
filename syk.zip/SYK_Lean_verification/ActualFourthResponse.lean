import ActualWickPressure
import FourthMomentIntegral

noncomputable section
open MeasureTheory Filter Set
open scoped Topology NNReal
namespace SYK.ActualFourthResponse
open ContinuumWickSeries WickVertexIntegrals

/-- The half-open representative agrees with the actual time variable almost
everywhere on the true thermal square; seam values are never silently equated. -/
theorem ae_pair_representative (β : ℝ) (hβ : 0<β) : ∀ᵐ p ∂pairMeasure β,
    (timeRepresentative β hβ p.1).val=p.1 ∧ (timeRepresentative β hβ p.2).val=p.2 := by
  have hm : pairMeasure β = (volume.restrict (Ico (0:ℝ) β)).prod (volume.restrict (Ico (0:ℝ) β)) := by
    simp only [pairMeasure,restrict_Ico_eq_restrict_Icc]
  rw [hm]
  have hi : ∀ᵐ p ∂(volume.restrict (Ico (0:ℝ) β)).prod (volume.restrict (Ico (0:ℝ) β)),
      p ∈ (Ico (0:ℝ) β) ×ˢ (Ico (0:ℝ) β) := by
    apply (Measure.ae_prod_iff_ae_ae (measurableSet_Ico.prod measurableSet_Ico)).mpr
    filter_upwards [ae_restrict_mem (measurableSet_Ico : MeasurableSet (Ico (0:ℝ) β))] with s hs
    filter_upwards [ae_restrict_mem (measurableSet_Ico : MeasurableSet (Ico (0:ℝ) β))] with t ht
    exact ⟨hs,ht⟩
  filter_upwards [hi] with p hp
  exact ⟨timeRepresentative_of_mem hβ hp.1,timeRepresentative_of_mem hβ hp.2⟩

/-- A literal inserted Wick/operator equality identifies the pressure's
series derivative with the exact microscopic fourth-moment observable. -/
theorem fourthIntegral_eq_series (d : ℕ) {β : ℝ} (hβ : 0<β) (lam : ℝ≥0)
    (hfour : ∀ p : ℝ×ℝ,
      normalizedMoment d β hβ (quarticPairs β hβ p) (lam:ℝ) =
        Interacting.collectiveMoment d β lam (fun _ : Fin 4=>
          ((timeRepresentative β hβ p.1).val,(timeRepresentative β hβ p.2).val))) :
    FourthMomentIntegral.fourthIntegral d β lam =
      (1/8:ℝ)*(∫ p, (normalizedMoment d β hβ (quarticPairs β hβ p) (lam:ℝ)).re ∂pairMeasure β) := by
  rw [FourthMomentIntegral.fourthIntegral,FourthMomentIntegral.timeMeasure_eq_closed]
  congr 1
  apply integral_congr_ae
  filter_upwards [ae_pair_representative β hβ] with p hp
  rw [hfour,hp.1,hp.2]
  rfl

/-- Exact microscopic quartic response at every positive real coupling. -/
theorem hasDerivAt_annealedPressure (d : ℕ) (hd : 0<d) {β : ℝ} (hβ : 0<β)
    (lam : ℝ) (hlam : 0<lam)
    (hfour : ∀ p : ℝ×ℝ,
      normalizedMoment d β hβ (quarticPairs β hβ p) lam =
        Interacting.collectiveMoment d β lam.toNNReal (fun _ : Fin 4=>
          ((timeRepresentative β hβ p.1).val,(timeRepresentative β hβ p.2).val))) :
    HasDerivAt (fun l=>Microscopic.annealedPressure d β l.toNNReal)
      (FourthMomentIntegral.fourthIntegral d β lam.toNNReal) lam := by
  have hf := fourthIntegral_eq_series d hβ lam.toNNReal (by
    simpa only [Real.coe_toNNReal _ hlam.le] using hfour)
  simp only [Real.coe_toNNReal _ hlam.le] at hf
  rw [hf]
  exact ActualWickPressure.hasDerivAt_annealedPressure_series d hd hβ lam hlam

end SYK.ActualFourthResponse
