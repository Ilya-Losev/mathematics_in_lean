import LogPartitionDifferential
import Mathlib.Analysis.Convex.Integral
import Mathlib.Analysis.Convex.SpecificFunctions.Basic
import Mathlib.Analysis.SpecialFunctions.Trigonometric.Deriv
import Mathlib.MeasureTheory.Integral.IntervalIntegral.FundThmCalculus

/-!
# The deterministic rotation/Jensen step of Gaussian concentration

A rotation joins two actual SYK coupling vectors. The true Frechet derivative
identifies its response, and the fundamental theorem plus Jensen bounds the
exponential log-partition difference by an average of exponentiated responses.
-/

set_option maxHeartbeats 600000
noncomputable section
open MeasureTheory Set
open scoped BigOperators Topology ComplexOrder
namespace SYK.PisierPath
open Majorana GlobalGradient LogPartitionDifferential

/-- Lebesgue measure on a unit interval is a probability measure. -/
def unitInterval : Measure ℝ := volume.restrict (Ioc 0 1)

instance unitInterval_isProbabilityMeasure : IsProbabilityMeasure unitInterval := by
  constructor
  simp [unitInterval]

/-- The deterministic Jensen/FTC inequality on a unit interval. -/
theorem exp_sub_le_integral_exp_derivative (f d : ℝ → ℝ)
    (hd : Continuous d) (hderiv : ∀ t, HasDerivAt f (d t) t) :
    Real.exp (f 1 - f 0) ≤ ∫ t, Real.exp (d t) ∂unitInterval := by
  have hi : Integrable d unitInterval :=
    (intervalIntegrable_iff_integrableOn_Ioc_of_le (by norm_num : (0 : ℝ) ≤ 1)).mp
      (hd.intervalIntegrable 0 1)
  have hei : Integrable (Real.exp ∘ d) unitInterval :=
    (intervalIntegrable_iff_integrableOn_Ioc_of_le (by norm_num : (0 : ℝ) ≤ 1)).mp
      ((Real.continuous_exp.comp hd).intervalIntegrable 0 1)
  have hJ := convexOn_exp.map_integral_le Real.continuous_exp.continuousOn
    isClosed_univ (ae_of_all unitInterval (fun _ => mem_univ _)) hi hei
  have hFTC := intervalIntegral.integral_eq_sub_of_hasDerivAt (fun t _ => hderiv t)
    (hd.intervalIntegrable 0 1)
  rw [intervalIntegral.integral_of_le (by norm_num : (0 : ℝ) ≤ 1)] at hFTC
  change (∫ t, d t ∂unitInterval) = f 1 - f 0 at hFTC
  simpa only [hFTC] using hJ

def rotateX {ι : Type*} (θ : ℝ) (x y : ι → ℝ) : ι → ℝ :=
  fun i => Real.cos θ * x i + Real.sin θ * y i

def rotateY {ι : Type*} (θ : ℝ) (x y : ι → ℝ) : ι → ℝ :=
  fun i => -Real.sin θ * x i + Real.cos θ * y i

/-- The derivative of the rotated first vector is the second vector. -/
theorem hasDerivAt_rotateX {ι : Type*} [Fintype ι] (x y : ι → ℝ) (t : ℝ) :
    HasDerivAt (fun s => rotateX (Real.pi / 2 * s) x y)
      ((Real.pi / 2) • rotateY (Real.pi / 2 * t) x y) t := by
  apply hasDerivAt_pi.mpr
  intro i
  have hθ : HasDerivAt (fun s : ℝ => Real.pi / 2 * s) (Real.pi / 2) t :=
    by simpa using (hasDerivAt_id t).const_mul (Real.pi / 2)
  have h := ((hθ.cos).mul_const (x i)).add ((hθ.sin).mul_const (y i))
  convert h using 1
  simp only [Pi.smul_apply, smul_eq_mul, rotateY]
  ring

/-- The actual rotation response, parametrized on [0,1]. -/
def rotationResponse (m : ℕ) (β : ℝ) (x y : FourSet m → ℝ) (t : ℝ) : ℝ :=
  (Real.pi / 2) * ∑ I,
    logGradient m β (rotateX (Real.pi / 2 * t) x y) I *
      rotateY (Real.pi / 2 * t) x y I

theorem hasDerivAt_logPartition_rotation (m : ℕ) (β : ℝ)
    (x y : FourSet m → ℝ) (t : ℝ) :
    HasDerivAt (fun s => logPartition m β (rotateX (Real.pi / 2 * s) x y))
      (rotationResponse m β x y t) t := by
  have h := hasDerivAt_logPartition_curve m β t _ _ (hasDerivAt_rotateX x y t)
  convert h using 1
  simp only [rotationResponse, Pi.smul_apply, smul_eq_mul, Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro I _
  ring

theorem continuous_rotationResponse (m : ℕ) (β : ℝ) (x y : FourSet m → ℝ) :
    Continuous (rotationResponse m β x y) := by
  have hX : Continuous (fun t : ℝ => rotateX (Real.pi / 2 * t) x y) := by
    unfold rotateX
    fun_prop
  have hG := (continuous_logGradient m β).comp hX
  unfold rotationResponse
  apply continuous_const.mul
  apply continuous_finset_sum
  intro I _
  have hGi := (continuous_apply I).comp hG
  exact hGi.mul (by unfold rotateY; fun_prop)

/-- The deterministic core of Pisier concentration, already instantiated to
the actual SYK log partition function and its concrete Gibbs gradient. -/
theorem exp_logPartition_sub_le (m : ℕ) (β : ℝ) (x y : FourSet m → ℝ) :
    Real.exp (logPartition m β y - logPartition m β x) ≤
      ∫ t, Real.exp (rotationResponse m β x y t) ∂unitInterval := by
  have h := exp_sub_le_integral_exp_derivative
    (fun t => logPartition m β (rotateX (Real.pi / 2 * t) x y))
    (rotationResponse m β x y) (continuous_rotationResponse m β x y)
    (hasDerivAt_logPartition_rotation m β x y)
  have h0 : rotateX (Real.pi / 2 * 0) x y = x := by
    ext I
    simp [rotateX]
  have h1 : rotateX (Real.pi / 2 * 1) x y = y := by
    ext I
    simp [rotateX]
  simpa only [h0, h1] using h

end SYK.PisierPath
