import ConvolutionRegularity
import WeightedKernelAlgebra

noncomputable section
open MeasureTheory Set Filter
open scoped Topology
namespace SYK.MixedIncrement
open WeightedKernelAlgebra

abbrev Polynomial := MvPolynomial Endpoint ℂ

def coordinateProduct (p : List Endpoint) : Polynomial := (p.map MvPolynomial.X).prod

def remainder (β : ℝ) (p : Endpoint) : Polynomial :=
  MvPolynomial.X p - MvPolynomial.C (Thermal.kernel β p.1 p.2 : ℂ)

def increment (β : ℝ) (pq : Endpoint × Endpoint) : Polynomial :=
  remainder β pq.1 - remainder β pq.2

def incrementProduct (β : ℝ) (p : List (Endpoint × Endpoint)) : Polynomial :=
  (p.map (increment β)).prod

@[simp] theorem coordinateProduct_nil : coordinateProduct [] = 1 := rfl
@[simp] theorem coordinateProduct_cons (p : Endpoint) (l : List Endpoint) :
    coordinateProduct (p::l) = MvPolynomial.X p * coordinateProduct l := rfl
@[simp] theorem coordinateProduct_append (p q : List Endpoint) :
    coordinateProduct (p++q) = coordinateProduct p * coordinateProduct q := by
  simp [coordinateProduct]
@[simp] theorem incrementProduct_nil (β : ℝ) : incrementProduct β [] = 1 := rfl
@[simp] theorem incrementProduct_cons (β : ℝ) (p : Endpoint × Endpoint) (l) :
    incrementProduct β (p::l) = increment β p * incrementProduct β l := rfl

/-- The exact L¹ mass of the first-endpoint covariance difference controls
any bounded inserted four-coordinate moment. No pointwise regularity is used. -/
theorem double_left_bound (β : ℝ) (hβ : 0 < β) (s s' : ℝ)
    (F : ℝ → ℝ → ℂ) (A : ℝ) (hA : 0 ≤ A) (hF : ∀ u v, ‖F u v‖ ≤ A) :
    ‖∫ u in (0:ℝ)..β, ∫ v in (0:ℝ)..β,
      ((Thermal.kernel β s u-Thermal.kernel β s' u):ℂ)*F u v‖ ≤
      β*A*|s-s'| := by
  have hin (u) : ‖∫ v in (0:ℝ)..β,
      ((Thermal.kernel β s u-Thermal.kernel β s' u):ℂ)*F u v‖ ≤
        (β*A)*|Thermal.kernel β s u-Thermal.kernel β s' u| := by
    have h := intervalIntegral.norm_integral_le_of_norm_le_const
      (a := (0:ℝ)) (b := β) (C := |Thermal.kernel β s u-Thermal.kernel β s' u| *A)
      (f := fun v => ((Thermal.kernel β s u-Thermal.kernel β s' u):ℂ)*F u v)
      (fun v _ => by
        dsimp only
        rw [norm_mul, ← Complex.ofReal_sub, Complex.norm_real, Real.norm_eq_abs]
        exact mul_le_mul_of_nonneg_left (hF u v) (abs_nonneg _))
    simp only [sub_zero, abs_of_nonneg hβ.le] at h
    nlinarith [h]
  have h := intervalIntegral.norm_integral_le_of_norm_le
    (Eventually.of_forall hin) ((Thermal.kernel_difference_intervalIntegrable β s s').const_mul (β*A))
  rw [intervalIntegral.integral_const_mul, abs_of_nonneg
    (mul_nonneg (mul_nonneg hβ.le hA) (intervalIntegral.integral_nonneg_of_forall hβ.le
      (fun _ => abs_nonneg _)))] at h
  exact h.trans (mul_le_mul_of_nonneg_left
    (Thermal.integral_kernel_difference_le β hβ s s') (mul_nonneg hβ.le hA))

/-- The second-endpoint kernel has the same integrated mass bound. -/
theorem double_right_bound (β : ℝ) (hβ : 0 < β) (t t' : ℝ)
    (F : ℝ → ℝ → ℂ) (A : ℝ) (hA : 0 ≤ A) (hF : ∀ u v, ‖F u v‖ ≤ A) :
    ‖∫ u in (0:ℝ)..β, ∫ v in (0:ℝ)..β,
      ((Thermal.kernel β v t-Thermal.kernel β v t'):ℂ)*F u v‖ ≤
      β*A*|t-t'| := by
  have hin (u) : ‖∫ v in (0:ℝ)..β,
      ((Thermal.kernel β v t-Thermal.kernel β v t'):ℂ)*F u v‖ ≤ A*|t-t'| := by
    have hi : IntervalIntegrable (fun v => A*|Thermal.kernel β v t-Thermal.kernel β v t'|)
        volume 0 β := by
      have he : (fun v => |Thermal.kernel β v t-Thermal.kernel β v t'|) =
          (fun v => |Thermal.kernel β t v-Thermal.kernel β t' v|) := by
        funext v
        rw [Thermal.kernel_skew β v t, Thermal.kernel_skew β v t']
        simpa only [neg_sub_neg, abs_sub_comm]
      convert (Thermal.kernel_difference_intervalIntegrable β t t').const_mul A using 1
      funext v
      exact congrArg (fun x => A*x) (congrFun he v)
    have h := intervalIntegral.norm_integral_le_of_norm_le
      (Eventually.of_forall (fun v => show
        ‖((Thermal.kernel β v t-Thermal.kernel β v t'):ℂ)*F u v‖ ≤
        A*|Thermal.kernel β v t-Thermal.kernel β v t'| from by
          rw [norm_mul, ← Complex.ofReal_sub, Complex.norm_real, Real.norm_eq_abs]
          exact (mul_le_mul_of_nonneg_left (hF u v) (abs_nonneg _)).trans_eq (mul_comm _ _))) hi
    rw [intervalIntegral.integral_const_mul, abs_of_nonneg
      (mul_nonneg hA (intervalIntegral.integral_nonneg_of_forall hβ.le (fun _ => abs_nonneg _)))] at h
    exact h.trans (mul_le_mul_of_nonneg_left
      (Thermal.integral_kernel_difference_right_le β hβ t t') hA)
  have h := intervalIntegral.norm_integral_le_of_norm_le_const
    (a := (0:ℝ)) (b := β) (C := A*|t-t'|) (fun u _ => hin u)
  simp only [sub_zero, abs_of_nonneg hβ.le] at h
  nlinarith [h]

def leftCoordinates (pq : Endpoint × Endpoint) (u v : ℝ) : List Endpoint :=
  [(u,v),(u,v),(u,v),(v,pq.1.2)]

def rightCoordinates (pq : Endpoint × Endpoint) (u v : ℝ) : List Endpoint :=
  [(pq.2.1,u),(u,v),(u,v),(u,v)]

/-- The two exact limiting inserted SD replacement formulas combined along
an axis-aligned path between endpoint pairs. These are explicit polynomial
identities to be supplied by the microscopic limiting Ward theorem. -/
def ReplacementIdentity (β lam : ℝ) (L : Polynomial →ₗ[ℂ] ℂ) : Prop :=
  ∀ (Q : Polynomial) (pq : Endpoint × Endpoint),
    L (Q*increment β pq) = (lam:ℂ)*
      (∫ u in (0:ℝ)..β, ∫ v in (0:ℝ)..β,
        ((Thermal.kernel β pq.1.1 u-Thermal.kernel β pq.2.1 u):ℂ)*
          L (Q*coordinateProduct (leftCoordinates pq u v))) +
      (lam:ℂ)*(∫ u in (0:ℝ)..β, ∫ v in (0:ℝ)..β,
        ((Thermal.kernel β v pq.1.2-Thermal.kernel β v pq.2.2):ℂ)*
          L (Q*coordinateProduct (rightCoordinates pq u v)))

theorem replacement_bound (β lam : ℝ) (hβ : 0 < β) (hlam : 0 ≤ lam)
    (L : Polynomial →ₗ[ℂ] ℂ) (hrep : ReplacementIdentity β lam L)
    (Q : Polynomial) (pq : Endpoint × Endpoint) (A : ℝ) (hA : 0 ≤ A)
    (hleft : ∀ u v, ‖L (Q*coordinateProduct (leftCoordinates pq u v))‖ ≤ A)
    (hright : ∀ u v, ‖L (Q*coordinateProduct (rightCoordinates pq u v))‖ ≤ A) :
    ‖L (Q*increment β pq)‖ ≤ lam*β*endpointDistance pq.1 pq.2*A := by
  rw [hrep Q pq]
  have h₁ := double_left_bound β hβ pq.1.1 pq.2.1 _ A hA hleft
  have h₂ := double_right_bound β hβ pq.1.2 pq.2.2 _ A hA hright
  calc
    _ ≤ ‖(lam:ℂ)*(∫ u in (0:ℝ)..β, ∫ v in (0:ℝ)..β,
        ((Thermal.kernel β pq.1.1 u-Thermal.kernel β pq.2.1 u):ℂ)*
          L (Q*coordinateProduct (leftCoordinates pq u v)))‖ +
      ‖(lam:ℂ)*(∫ u in (0:ℝ)..β, ∫ v in (0:ℝ)..β,
        ((Thermal.kernel β v pq.1.2-Thermal.kernel β v pq.2.2):ℂ)*
          L (Q*coordinateProduct (rightCoordinates pq u v)))‖ := norm_add_le _ _
    _ ≤ lam*(β*A*|pq.1.1-pq.2.1|)+lam*(β*A*|pq.1.2-pq.2.2|) := by
      simp only [norm_mul, Complex.norm_real, Real.norm_eq_abs, abs_of_nonneg hlam]
      exact add_le_add (mul_le_mul_of_nonneg_left h₁ hlam) (mul_le_mul_of_nonneg_left h₂ hlam)
    _ = _ := by unfold endpointDistance; ring

/-- Each increment retains its own small displacement factor inside arbitrary
products. Every use of SD adds four genuine coordinate factors. -/
theorem mixed_product_bound (β lam b : ℝ) (hβ : 0 < β) (hlam : 0 ≤ lam) (hb : 0 ≤ b)
    (L : Polynomial →ₗ[ℂ] ℂ) (hrep : ReplacementIdentity β lam L)
    (hplain : ∀ p : List Endpoint, ‖L (coordinateProduct p)‖ ≤ b^p.length)
    (p : List Endpoint) (q : List (Endpoint × Endpoint)) :
    ‖L (coordinateProduct p*incrementProduct β q)‖ ≤
      b^p.length * (q.map (fun pq => (lam*β*b^4)*endpointDistance pq.1 pq.2)).prod := by
  induction q generalizing p with
  | nil => simpa using hplain p
  | cons pq q ih =>
      let W := (q.map (fun pq => (lam*β*b^4)*endpointDistance pq.1 pq.2)).prod
      have hW : 0 ≤ W := by
        have aux (l : List ℝ) (h : ∀ x ∈ l, 0 ≤ x) : 0 ≤ l.prod := by
          induction l with
          | nil => simp
          | cons a l ih =>
            exact mul_nonneg (h a (by simp)) (ih (fun x hx => h x (by simp [hx])))
        apply aux
        intro x hx
        obtain ⟨r,_,rfl⟩ := List.mem_map.mp hx
        exact mul_nonneg (by positivity) (add_nonneg (abs_nonneg _) (abs_nonneg _))
      let Q := coordinateProduct p*incrementProduct β q
      have hh (r : List Endpoint) (hr : r.length=4) :
          ‖L (Q*coordinateProduct r)‖ ≤ b^(p.length+4)*W := by
        have h := ih (p++r)
        rw [coordinateProduct_append, List.length_append, hr] at h
        convert h using 1
        congr 2
        dsimp [Q]
        ring
      have h := replacement_bound β lam hβ hlam L hrep Q pq
        (b^(p.length+4)*W) (mul_nonneg (pow_nonneg hb _) hW)
        (fun u v => hh (leftCoordinates pq u v) rfl)
        (fun u v => hh (rightCoordinates pq u v) rfl)
      have he : coordinateProduct p*incrementProduct β (pq::q) = Q*increment β pq := by
        simp only [incrementProduct_cons]
        dsimp [Q]
        ring
      rw [he]
      refine h.trans_eq ?_
      simp only [List.map_cons, List.prod_cons, pow_add]
      dsimp [W]
      ring

end SYK.MixedIncrement
