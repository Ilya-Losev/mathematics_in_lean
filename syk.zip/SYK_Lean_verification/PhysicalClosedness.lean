import PhysicalSelection
import Mathlib.MeasureTheory.Integral.DominatedConvergence
import Mathlib.MeasureTheory.Constructions.BorelSpace.Metrizable

noncomputable section
open MeasureTheory Set Filter
open scoped Topology NNReal
namespace SYK.Continuum

theorem fourier_tendsto_bounded (β : ℝ) (ω : ℝ) (f : ℕ → ℝ → ℝ) (g : ℝ → ℝ)
    (hm : ∀ n, Measurable (f n)) (B : ℝ) (hb : ∀ n t, |f n t| ≤ B)
    (ht : ∀ t, Tendsto (fun n => f n t) atTop (𝓝 (g t))) :
    Tendsto (fun n => fourier β (f n) ω) atTop (𝓝 (fourier β g ω)) := by
  apply intervalIntegral.tendsto_integral_filter_of_dominated_convergence (fun _ => B)
  · filter_upwards [] with n
    have hmeas : Measurable (fun t : ℝ => Complex.exp (Complex.I * (ω * t)) * (f n t : ℂ)) := by
      fun_prop
    exact hmeas.aestronglyMeasurable
  · filter_upwards [] with n
    filter_upwards [] with t _
    simpa [norm_mul, Complex.norm_exp] using hb n t
  · exact intervalIntegrable_const
  · filter_upwards [] with t _
    exact tendsto_const_nhds.mul (Complex.continuous_ofReal.continuousAt.tendsto.comp (ht t))

theorem scalarConvolution_tendsto_bounded (β : ℝ) (f h : ℕ → ℝ → ℝ) (g k : ℝ → ℝ)
    (hfm : ∀ n, Measurable (f n)) (hhm : ∀ n, Measurable (h n))
    (B D : ℝ) (hfb : ∀ n t, |f n t| ≤ B) (hhb : ∀ n t, |h n t| ≤ D)
    (hft : ∀ t, Tendsto (fun n => f n t) atTop (𝓝 (g t)))
    (hht : ∀ t, Tendsto (fun n => h n t) atTop (𝓝 (k t))) (s : ℝ) :
    Tendsto (fun n => scalarConvolution β (f n) (h n) s) atTop (𝓝 (scalarConvolution β g k s)) := by
  apply intervalIntegral.tendsto_integral_filter_of_dominated_convergence (fun _ => B*D)
  · filter_upwards [] with n
    exact (((hfm n).comp (measurable_const.sub measurable_id)).mul (hhm n)).aestronglyMeasurable
  · filter_upwards [] with n
    filter_upwards [] with t _
    simp only [Real.norm_eq_abs, abs_mul]
    exact mul_le_mul (hfb n _) (hhb n _) (abs_nonneg _) ((abs_nonneg (f n 0)).trans (hfb n 0))
  · exact intervalIntegrable_const
  · filter_upwards [] with t _
    exact (hft (s-t)).mul (hht t)

/-- The scalar equation reconstructs the manuscript's full two-endpoint equation. -/
theorem sd_of_scalar_equation (β : ℝ) (hβ : 0 < β) (lam : ℝ≥0) (g : ℝ → ℝ)
    (ha : ∀ t, g (t+β) = -g t)
    (he : ∀ t, g t = Thermal.covariance β t + (lam : ℝ) *
      scalarConvolution β (scalarConvolution β (Thermal.covariance β) (fun u => (g u)^3)) g t) :
    SDEquation β lam g := by
  have hcube (u : ℝ) : (g (u+β))^3 = -(g u)^3 := by rw [ha]; ring
  have hi : convolution β (Thermal.kernel β) (cube (stationaryKernel g)) =
      stationaryKernel (scalarConvolution β (Thermal.covariance β) (fun u => (g u)^3)) := by
    funext s t
    exact stationary_convolution β (Thermal.covariance β) (fun u => (g u)^3)
      (Thermal.covariance_antiperiodic β hβ.ne') hcube s t
  intro s t
  unfold SDEquation at *
  rw [hi, stationary_convolution β _ g
    (scalarConvolution_antiperiodic β _ _ (Thermal.covariance_antiperiodic β hβ.ne')) ha]
  exact he (s-t)

/-- Physical continuum solutions are closed under bounded pointwise limits,
including changes of coupling. Strict Fourier signs follow from the limiting SD equation. -/
theorem physical_closed_bounded_pointwise (β : ℝ) (hβ : 0 < β)
    (lam : ℕ → ℝ≥0) (l : ℝ≥0) (f : ℕ → ℝ → ℝ) (g : ℝ → ℝ)
    (hp : ∀ n, PhysicalSolution β (lam n) (f n))
    (hl : Tendsto (fun n => (lam n : ℝ)) atTop (𝓝 (l : ℝ)))
    (B : ℝ) (hb : ∀ n t, |f n t| ≤ B)
    (ht : ∀ t, Tendsto (fun n => f n t) atTop (𝓝 (g t))) :
    PhysicalSolution β l g := by
  have hm (n) : Measurable (f n) := (hp n).1
  have hg : Measurable g := measurable_of_tendsto_metrizable hm (tendsto_pi_nhds.mpr ht)
  have hgb (t) : |g t| ≤ B := le_of_tendsto (ht t).abs (Eventually.of_forall (fun n => hb n t))
  have haN (n t) : f n (t+β) = -f n t := (hp n).2.2.1 t
  have ha (t) : g (t+β) = -g t := by
    have he := ht (t+β)
    simp_rw [haN] at he
    exact tendsto_nhds_unique he (ht t).neg
  have hzN (n) : f n 0 = 0 := (hp n).2.2.2.1
  have hz : g 0 = 0 := by
    have he := ht 0
    simp_rw [hzN] at he
    exact tendsto_nhds_unique he tendsto_const_nhds
  have hsN (n t) : f n (β-t) = f n t := (hp n).2.2.2.2.1 t
  have hsym (t) : g (β-t) = g t := by
    have he := ht (β-t)
    simp_rw [hsN] at he
    exact tendsto_nhds_unique he (ht t)
  let c := Thermal.covariance β
  let q := fun n t => (f n t)^3
  let k := fun n => scalarConvolution β c (q n)
  let kg := scalarConvolution β c (fun t => (g t)^3)
  have hqm (n) : Measurable (q n) := (hm n).pow_const 3
  have hqb (n t) : |q n t| ≤ B^3 := by
    dsimp [q]
    rw [abs_pow]
    exact pow_le_pow_left₀ (abs_nonneg _) (hb n t) 3
  have hqt (t) : Tendsto (fun n => q n t) atTop (𝓝 ((g t)^3)) := (ht t).pow 3
  have hkm (n) : Measurable (k n) := scalarConvolution_measurable β hβ.le c (q n)
    (Thermal.covariance_measurable β) (hqm n)
  have hkb (n t) : |k n t| ≤ β*((1/2:ℝ)*B^3) :=
    scalarConvolution_bound β hβ.le c (q n) _ _ (Thermal.abs_covariance_le β) (hqb n) t
  have hkt (t) : Tendsto (fun n => k n t) atTop (𝓝 (kg t)) :=
    scalarConvolution_tendsto_bounded β (fun _ => c) q c (fun t => (g t)^3)
      (fun _ => Thermal.covariance_measurable β) hqm _ _
      (fun _ => Thermal.abs_covariance_le β) hqb (fun _ => tendsto_const_nhds) hqt t
  have houter (t) : Tendsto (fun n => scalarConvolution β (k n) (f n) t) atTop
      (𝓝 (scalarConvolution β kg g t)) :=
    scalarConvolution_tendsto_bounded β k f kg g hkm hm _ _ hkb hb hkt ht t
  have heq (t) : g t = c t + (l : ℝ) * scalarConvolution β kg g t := by
    have hn (n) : f n t = c t + (lam n : ℝ) * scalarConvolution β (k n) (f n) t :=
      sd_scalar_equation β hβ (lam n) (f n) (hp n).2.2.1 (hp n).2.2.2.2.2.2 t
    have he := ht t
    simp_rw [hn] at he
    exact tendsto_nhds_unique he (tendsto_const_nhds.add (hl.mul (houter t)))
  have hSD : SDEquation β l g := sd_of_scalar_equation β hβ l g ha heq
  refine ⟨hg, ⟨B, hgb⟩, ha, hz, hsym, ?_, hSD⟩
  intro j
  have hFt := fourier_tendsto_bounded β (frequency β j) f g hm B hb ht
  have hI := Complex.continuous_im.continuousAt.tendsto.comp hFt
  have hn : 0 ≤ (fourier β g (frequency β j)).im := by
    apply ge_of_tendsto' hI
    intro n
    rcases (hp n).2.2.2.2.2.1 j with ⟨x, hx, he⟩
    dsimp only [Function.comp_apply]
    rw [he]
    simpa using hx.le
  have hr := fourier_re_zero β hβ g hsym j
  have he : fourier β g (frequency β j) = Complex.I * (fourier β g (frequency β j)).im := by
    apply Complex.ext <;> simp [hr]
  have hd := scalar_dyson β hβ l g hg B hgb ha hsym hSD j _ he
  exact ⟨_, SYK.positive_of_nonnegative_dyson _ _ _ hn hd, he⟩

end SYK.Continuum
