import SYKLean
import Lean.Util.CollectAxioms
import Lean.Elab.Command

/-!
Machine-enforced axiom audit of every logical declaration originating in a
project proof module, including generated and private safe declarations.
Unsafe executable compiler artifacts are counted separately; Lean does not
permit them in logical proof dependencies. Source code also forbids unsafe. Only Lean's three
standard foundations are accepted. A theorem's ordinary hypotheses are still
mathematical obligations, not axioms; this check does not discharge them.
-/

open Lean Elab Command

elab "#audit_project_axioms" : command => do
  let projectModules : Array Name := #[`SYKAbstractMomentCorollaries, `AbstractMomentTransport, `SYKRepresentationCorollaries, `AbstractRepresentationTransport, `MomentRepresentationIndependence, `ActualMicroscopicIdentities, `SYKMainTheorem, `ActualWickCorrespondence, `IntegratedWickWard, `ContinuumSYKCorollaries, `CollectiveWeylAverage, `ActualWickChamberSeries, `ContinuumSYKMain, `ComplexPhysicalUniqueness, `ActualCorrespondenceConsequences, `ComplexFourierOperatorAction, `InsertedWickSymmetry, `ActualWickWard, `ActualWickChamber, `ActualFourthResponse, `ActualWickPressure, `FundamentalMomentIntegrability, `RepresentationIndependence, `SignedWardInterval, `CollectiveFieldExpansion, `WardMarkedIntegration, `SignedWardIdentity, `FundamentalWardBridge, `WickWardNormalization, `FieldDisorderSeries, `ActualMomentLimit, `MicroscopicResponseBridge, `WickCoefficientParameters, `SignedWardReduction, `GapHistoryIntegrationAE, `WardInteractionSwap, `FundamentalWardContacts, `PolynomialWardExtension, `WickGaussianRegrouping, `MicroscopicMomentConvergence, `ActualFiniteWardControl, `ContactWickEvaluation, `RealWardContacts, `FiniteWardSymmetry, `InsertedWickSeries, `WardInteractionAlgebra, `ContinuumWickWard, `WickSeriesPressure, `CollectiveMomentConvergence, `ThermalMicroscopicOddPositivity, `ThermalWardSymmetry, `FinalModelConventions, `OddPolynomialReflection, `WeylTranslation, `ThermalWardLimit, `MomentSeriesIntegrability, `SymmetricInteractionIntegral, `OddWeylReflection, `ThermalPairCubeMeasure, `PressureLimitAssembly, `WickSeriesDerivative, `ThermalMicroscopicPositivity, `PartitionWickSeries, `ContinuumWickSeries, `FourthMomentIntegral, `PolynomialReflectionPositivity, `ThermalRPTransport, `IntegralMomentSeries, `GapHistoryIntegration, `BilocalReflection, `FiniteWardRegularity, `CoordinateTelescoping, `WickVertexIntegrals, `GapCountCompositions, `ThermalResidualState, `WeylReflection, `PhysicalFredholm, `SpectralFredholm, `GapChamberCoordinates, `ExponentialMomentSeries, `SymmetricMomentFunctional, `ThermalWeightedState, `DuhamelVertexExpansion, `GapAssignmentPartition, `WeylBlockFactorization, `ThermalMomentTransport, `GaussianSymbolAverage, `MixedWeightedExtension, `GapSimplexIntegral, `DuhamelHistorySeries, `OrderedCubePartition, `InsertedWardReplacements, `GaussianCoefficientIdentity, `OrderedSimplexIntegral, `PhysicalOperatorAction, `MomentLimitHierarchy, `ThermalEndpointLift, `FourierOperators, `VariationalEnvelope, `MixedIncrementBounds, `QuarticRegrouping, `NilpotentSymmetricSum, `OnShellAction, `KernelConstructedSelection, `PhysicalEndpoints, `DiagonalFredholm, `MomentMeasurability, `ThermalKernelSelection, `KernelActionBridge, `CouplingContinuity, `PhysicalRegularity, `KernelFinalActions, `MomentSymmetry, `KernelSelection, `PeriodicCompactness, `PressureGap, `FreeWeylCorrespondence, `GaussianConcentration, `KernelQuotientActions, `PhysicalClosedness, `RelativeLogSeries, `PisierPath, `KernelAlgebraActions, `ThermalHalfGeneration, `MomentCompactness, `InteractingMoments, `ProductGaussianRotation, `ProductGaussianMGF, `LogPartitionDifferential, `PhysicalSelection, `KernelCoordinateGeneration, `KernelQuotientAnalyticity, `PhysicalUniqueness, `FermionicSigns, `HankelPositivity, `GlobalGradientBound, `KernelSDAnalyticity, `ConvolutionRegularity, `ThermalMomentBound, `KernelReflection, `FourierDyson, `KernelResidualAlgebra, `AnnealedDifferentiation, `KernelSDDifferentiation, `FourierConvolution, `HankelFourierTest, `GaussianIntegrationByParts, `WeightedKernelAlgebra, `ThermalReflectionPositivity, `GaussianScaling, `ClosedIdeal, `HalfGeneration, `Translation,
    `Uniqueness, `Pressure, `Majorana, `CovarianceRegularity, `MicroscopicPressure, `PressureJensen, `PressureWellDefined, `ContinuumDefinitions, `FreeContinuumCase, `FermionicFourier, `FourierParseval, `GibbsState, `DuhamelTrace, `GNSRepresentation, `SpectralRepresentation, `TranslationContraction, `GaussianDisorder, `ThermalCovariance, `AntiCommutingBound, `WickContraction, `KernelAnalyticity, `PolynomialODE, `KernelSpace, `WickThermal, `WardMoments, `FreeWickTrace, `SYKLean]
  let allowed : Array Name := #[`propext, `Classical.choice, `Quot.sound]
  let env ← getEnv
  for modName in projectModules do
    unless env.header.moduleNames.contains modName do
      throwError "Missing project module {modName} in imported environment; build the current aggregate first"
  let mut checked := 0
  let mut logicalRoots : Array Name := #[]
  let mut theoremCount := 0
  let mut unsafeArtifacts := 0
  for (name, info) in env.constants.toList do
    let some index := env.getModuleIdxFor? name | continue
    let modName := env.header.moduleNames[index.toNat]!
    unless projectModules.contains modName do continue
    if info.isUnsafe then
      unsafeArtifacts := unsafeArtifacts + 1
      logInfo m!"EXCLUDED UNSAFE EXECUTABLE ARTIFACT {name} (module {modName})"
      continue
    checked := checked + 1
    logicalRoots := logicalRoots.push name
    if info.isTheorem then
      theoremCount := theoremCount + 1
      logInfo m!"LOGICAL THEOREM ROOT {name}"
  if checked == 0 then
    throwError "No project declarations were audited"
  -- This is the same dependency walker used by Lean.collectAxioms, with a
  -- shared visited set across roots. Sharing changes no dependency edges;
  -- it avoids re-traversing the same mathlib proof graph hundreds of times.
  let walk : CollectAxioms.M Unit := do
    for name in logicalRoots do
      CollectAxioms.collect name
  let (_, state) := (walk.run env).run {}
  for ax in state.axioms do
    unless allowed.contains ax do
      -- A failure additionally reports a responsible project root.
      for name in logicalRoots do
        if (← collectAxioms name).contains ax then
          throwError "Forbidden axiom {ax} reachable from project declaration {name}"
      throwError "Forbidden axiom {ax} in project dependency graph"
  logInfo m!"COMPLETE LOGICAL DEPENDENCY AXIOMS: {state.axioms}"
  logInfo m!"AUDIT PASSED: {checked} safe project declarations, {theoremCount} theorem declarations; permitted foundations only. {unsafeArtifacts} unsafe executable compiler artifacts excluded from logical audit."

#audit_project_axioms
