import ClosedIdeal
import Mathlib.Algebra.MvPolynomial.CommRing
import Mathlib.Analysis.Complex.Basic
import Mathlib.Analysis.Normed.Unbundled.RingSeminorm
import Mathlib.Analysis.Normed.Module.Completion
import Mathlib.Analysis.Normed.Group.Quotient
import Mathlib.Analysis.NormedSpace.OperatorNorm.Completeness
import Mathlib.Data.Finsupp.Order
import Mathlib.LinearAlgebra.Finsupp.LinearCombination
import Mathlib.Topology.Algebra.Ring.Ideal

/-!
# The weighted coefficient Banach algebra of Section 6

The index type is arbitrary; no countability assumption is imposed on the
endpoint or increment generators. The coefficient norm is defined explicitly
on finite polynomials before completion.
-/

noncomputable section

namespace SYK.WeightedKernelAlgebra

open scoped BigOperators
open MvPolynomial
open UniformSpace

variable {ι : Type*}

/-- Product of the positive assigned generator weights in a monomial. -/
def monomialWeight (w : ι → ℝ) (d : ι →₀ ℕ) : ℝ := d.prod fun i n => w i ^ n

@[simp] theorem monomialWeight_zero (w : ι → ℝ) : monomialWeight w 0 = 1 := by
  simp [monomialWeight]

@[simp] theorem monomialWeight_add (w : ι → ℝ) (d e : ι →₀ ℕ) :
    monomialWeight w (d + e) = monomialWeight w d * monomialWeight w e := by
  exact Finsupp.prod_add_index' (fun i => pow_zero (w i)) (fun i m n => pow_add (w i) m n)

@[simp] theorem monomialWeight_single (w : ι → ℝ) (i : ι) (n : ℕ) :
    monomialWeight w (Finsupp.single i n) = w i ^ n := by
  exact Finsupp.prod_single_index (pow_zero (w i))

theorem monomialWeight_pos (w : ι → ℝ) (hw : ∀ i, 0 < w i) (d : ι →₀ ℕ) :
    0 < monomialWeight w d := by
  exact Finset.prod_pos (fun i _ => pow_pos (hw i) _)

/-- The weighted coefficient ℓ¹ norm, given by a finite sum on each polynomial. -/
def coefficientNorm (w : ι → ℝ) (p : MvPolynomial ι ℂ) : ℝ :=
  p.sum fun d c => ‖c‖ * monomialWeight w d

@[simp] theorem coefficientNorm_zero (w : ι → ℝ) : coefficientNorm w 0 = 0 := by
  simp [coefficientNorm]

@[simp] theorem coefficientNorm_monomial (w : ι → ℝ) (d : ι →₀ ℕ) (c : ℂ) :
    coefficientNorm w (monomial d c) = ‖c‖ * monomialWeight w d := by
  exact Finsupp.sum_single_index (by simp)

theorem coefficientNorm_nonneg (w : ι → ℝ) (hw : ∀ i, 0 < w i) (p : MvPolynomial ι ℂ) :
    0 ≤ coefficientNorm w p :=
  Finset.sum_nonneg fun d _ => mul_nonneg (norm_nonneg _) (monomialWeight_pos w hw d).le

theorem coefficientNorm_add_le (w : ι → ℝ) (hw : ∀ i, 0 < w i) (p q : MvPolynomial ι ℂ) :
    coefficientNorm w (p + q) ≤ coefficientNorm w p + coefficientNorm w q := by
  classical
  let f : (ι →₀ ℕ) → ℂ → ℝ := fun d c => ‖c‖ * monomialWeight w d
  have hzero : ∀ d ∈ p.support ∪ q.support, f d 0 = 0 := by intro d hd; simp [f]
  change (p + q).sum f ≤ p.sum f + q.sum f
  rw [Finsupp.sum_of_support_subset (p + q) Finsupp.support_add f hzero,
    Finsupp.sum_of_support_subset p Finset.subset_union_left f hzero,
    Finsupp.sum_of_support_subset q Finset.subset_union_right f hzero]
  calc
    _ ≤ ∑ d ∈ p.support ∪ q.support, (f d (coeff d p) + f d (coeff d q)) := by
      apply Finset.sum_le_sum
      intro d hd
      change ‖coeff d p + coeff d q‖ * monomialWeight w d ≤
        ‖coeff d p‖ * monomialWeight w d + ‖coeff d q‖ * monomialWeight w d
      simpa only [add_mul] using
        mul_le_mul_of_nonneg_right (norm_add_le (coeff d p) (coeff d q))
          (monomialWeight_pos w hw d).le
    _ = _ := by rw [Finset.sum_add_distrib]; rfl

@[simp] theorem coefficientNorm_neg (w : ι → ℝ) (p : MvPolynomial ι ℂ) :
    coefficientNorm w (-p) = coefficientNorm w p := by
  change (-p).sum (fun d c => ‖c‖ * monomialWeight w d) = _
  rw [Finsupp.sum_neg_index (by intro d; simp)]
  simp only [norm_neg]
  rfl

theorem coefficientNorm_eq_zero (w : ι → ℝ) (hw : ∀ i, 0 < w i)
    (p : MvPolynomial ι ℂ) (hp : coefficientNorm w p = 0) : p = 0 := by
  classical
  have hterms : ∀ d ∈ p.support, ‖coeff d p‖ * monomialWeight w d = 0 :=
    (Finset.sum_eq_zero_iff_of_nonneg
      (fun d _ => mul_nonneg (norm_nonneg _) (monomialWeight_pos w hw d).le)).mp hp
  apply Finsupp.ext
  intro d
  by_cases hd : d ∈ p.support
  · have h := (mul_eq_zero.mp (hterms d hd)).resolve_right (ne_of_gt (monomialWeight_pos w hw d))
    exact norm_eq_zero.mp h
  · exact Finsupp.not_mem_support_iff.mp hd

/-- The coefficient formula gives an actual additive norm. -/
def coefficientAddNorm (w : ι → ℝ) (hw : ∀ i, 0 < w i) : AddGroupNorm (MvPolynomial ι ℂ) where
  toFun := coefficientNorm w
  map_zero' := coefficientNorm_zero w
  add_le' := coefficientNorm_add_le w hw
  neg' := coefficientNorm_neg w
  eq_zero_of_map_eq_zero' := coefficientNorm_eq_zero w hw

/-- Convolution of polynomial coefficients is submultiplicative for the
weighted ℓ¹ norm. -/
theorem coefficientNorm_mul_le (w : ι → ℝ) (hw : ∀ i, 0 < w i) (p q : MvPolynomial ι ℂ) :
    coefficientNorm w (p * q) ≤ coefficientNorm w p * coefficientNorm w q := by
  classical
  letI : NormedAddCommGroup (MvPolynomial ι ℂ) := (coefficientAddNorm w hw).toNormedAddCommGroup
  have hmul : p * q = ∑ d ∈ p.support, ∑ e ∈ q.support,
      monomial (d + e) (coeff d p * coeff e q) := by
    calc
      p * q = (∑ d ∈ p.support, monomial d (coeff d p)) *
          (∑ e ∈ q.support, monomial e (coeff e q)) :=
        congrArg₂ (fun x y : MvPolynomial ι ℂ => x * y) p.as_sum q.as_sum
      _ = _ := by
        simp only [Finset.sum_mul, Finset.mul_sum, monomial_mul]
        exact Finset.sum_comm
  calc
    coefficientNorm w (p * q) = ‖∑ d ∈ p.support, ∑ e ∈ q.support,
        monomial (d + e) (coeff d p * coeff e q)‖ := congrArg (coefficientNorm w) hmul
    _ ≤ ∑ d ∈ p.support, ∑ e ∈ q.support,
        ‖monomial (d + e) (coeff d p * coeff e q)‖ :=
      (norm_sum_le _ _).trans (Finset.sum_le_sum fun d hd => norm_sum_le _ _)
    _ = coefficientNorm w p * coefficientNorm w q := by
      change (∑ d ∈ p.support, ∑ e ∈ q.support,
        coefficientNorm w (monomial (d + e) (coeff d p * coeff e q))) = _
      simp only [coefficientNorm_monomial, norm_mul, monomialWeight_add]
      change (∑ d ∈ p.support, ∑ e ∈ q.support,
        ‖coeff d p‖ * ‖coeff e q‖ * (monomialWeight w d * monomialWeight w e)) =
        (∑ d ∈ p.support, ‖coeff d p‖ * monomialWeight w d) *
        (∑ e ∈ q.support, ‖coeff e q‖ * monomialWeight w e)
      rw [Finset.sum_mul]
      apply Finset.sum_congr rfl
      intro d hd
      rw [Finset.mul_sum]
      apply Finset.sum_congr rfl
      intro e he
      ring

/-- The resulting ring norm is explicit, rather than an assumed algebra norm. -/
def coefficientRingNorm (w : ι → ℝ) (hw : ∀ i, 0 < w i) : RingNorm (MvPolynomial ι ℂ) where
  __ := coefficientAddNorm w hw
  mul_le' := coefficientNorm_mul_le w hw


@[simp] theorem coefficientNorm_smul (w : ι → ℝ) (r : ℂ) (p : MvPolynomial ι ℂ) :
    coefficientNorm w (r • p) = ‖r‖ * coefficientNorm w p := by
  change (r • p).sum (fun d c => ‖c‖ * monomialWeight w d) = _
  rw [Finsupp.sum_smul_index' (by intro d; simp)]
  simp only [norm_smul, mul_assoc]
  exact (Finset.mul_sum ..).symm

/-- Strictly positive generator weights. -/
structure Weights (ι : Type*) where
  value : ι → ℝ
  positive : ∀ i, 0 < value i

/-- Finite polynomials equipped with the explicitly constructed weighted norm. -/
def WeightedPolynomial (w : Weights ι) : Type _ := MvPolynomial ι ℂ

namespace WeightedPolynomial

variable (w : Weights ι)

instance : CommRing (WeightedPolynomial w) := inferInstanceAs (CommRing (MvPolynomial ι ℂ))
instance : Algebra ℂ (WeightedPolynomial w) := inferInstanceAs (Algebra ℂ (MvPolynomial ι ℂ))
instance : NormedCommRing (WeightedPolynomial w) where
  __ := (coefficientRingNorm w.value w.positive).toNormedRing
  mul_comm := mul_comm
instance : NormedAlgebra ℂ (WeightedPolynomial w) where
  norm_smul_le r p := (coefficientNorm_smul w.value r p).le

/-- Embed a finite polynomial into the normed type synonym. -/
def ofPolynomial (p : MvPolynomial ι ℂ) : WeightedPolynomial w := p

@[simp] theorem norm_ofPolynomial (p : MvPolynomial ι ℂ) :
    ‖ofPolynomial w p‖ = coefficientNorm w.value p := rfl

@[simp] theorem norm_monomial (d : ι →₀ ℕ) (c : ℂ) :
    ‖ofPolynomial w (monomial d c)‖ = ‖c‖ * monomialWeight w.value d :=
  coefficientNorm_monomial w.value d c

@[simp] theorem norm_X (i : ι) : ‖ofPolynomial w (MvPolynomial.X i)‖ = w.value i := by
  change coefficientNorm w.value (monomial (Finsupp.single i 1) 1) = _
  simp

@[simp] theorem norm_C (c : ℂ) : ‖ofPolynomial w (MvPolynomial.C c)‖ = ‖c‖ := by
  exact (coefficientNorm_monomial w.value 0 c).trans (by rw [monomialWeight_zero, mul_one])

instance : NormOneClass (WeightedPolynomial w) where
  norm_one := by exact norm_C w 1 |>.trans norm_one

/-- The coefficient-wise moment assignment extended linearly to polynomials. -/
def momentLinear (m : (ι →₀ ℕ) → ℂ) : WeightedPolynomial w →ₗ[ℂ] ℂ :=
  Finsupp.linearCombination ℂ m

/-- Mixed monomial bounds imply the norm-one bound for the entire polynomial
functional by the triangle inequality in the weighted coefficient norm. -/
theorem momentLinear_bound (m : (ι →₀ ℕ) → ℂ)
    (hm : ∀ d, ‖m d‖ ≤ monomialWeight w.value d) (p : WeightedPolynomial w) :
    ‖momentLinear w m p‖ ≤ ‖p‖ := by
  change ‖p.sum (fun d c => c • m d)‖ ≤ coefficientNorm w.value p
  calc
    _ ≤ ∑ d ∈ (show MvPolynomial ι ℂ from p).support, ‖coeff d p • m d‖ := norm_sum_le _ _
    _ ≤ coefficientNorm w.value p := by
      apply Finset.sum_le_sum
      intro d hd
      change ‖coeff d p • m d‖ ≤ ‖coeff d p‖ * monomialWeight w.value d
      rw [norm_smul]
      exact mul_le_mul_of_nonneg_left (hm d) (norm_nonneg _)

/-- Bounded polynomial moments as a continuous linear functional. -/
def momentCLM (m : (ι →₀ ℕ) → ℂ)
    (hm : ∀ d, ‖m d‖ ≤ monomialWeight w.value d) : WeightedPolynomial w →L[ℂ] ℂ :=
  (momentLinear w m).mkContinuous 1 (fun p => by simpa only [one_mul] using momentLinear_bound w m hm p)

@[simp] theorem momentCLM_monomial (m : (ι →₀ ℕ) → ℂ)
    (hm : ∀ d, ‖m d‖ ≤ monomialWeight w.value d) (d : ι →₀ ℕ) (c : ℂ) :
    momentCLM w m hm (ofPolynomial w (monomial d c)) = c * m d := by
  change (Finsupp.single d c).sum (fun e z => z • m e) = c * m d
  simp [smul_eq_mul]

end WeightedPolynomial

/-- The actual completed weighted coefficient algebra, over any index type. -/
def WeightedAlgebra (w : Weights ι) : Type _ := Completion (WeightedPolynomial w)

namespace WeightedAlgebra

variable (w : Weights ι)

instance : NormedCommRing (WeightedAlgebra w) := inferInstanceAs
  (NormedCommRing (Completion (WeightedPolynomial w)))
instance : NormedAlgebra ℂ (WeightedAlgebra w) := inferInstanceAs
  (NormedAlgebra ℂ (Completion (WeightedPolynomial w)))
instance : CompleteSpace (WeightedAlgebra w) := inferInstanceAs
  (CompleteSpace (Completion (WeightedPolynomial w)))

/-- The dense polynomial embedding, preserving the weighted norm exactly. -/
def ofPolynomial (p : MvPolynomial ι ℂ) : WeightedAlgebra w :=
  (WeightedPolynomial.ofPolynomial w p : Completion (WeightedPolynomial w))

@[simp] theorem norm_ofPolynomial (p : MvPolynomial ι ℂ) :
    ‖ofPolynomial w p‖ = coefficientNorm w.value p :=
  Completion.norm_coe (WeightedPolynomial.ofPolynomial w p)

theorem denseRange_ofPolynomial : DenseRange (ofPolynomial w) :=
  Completion.denseRange_coe (α := WeightedPolynomial w)

/-- The assigned generator in the completed algebra. -/
def generator (i : ι) : WeightedAlgebra w := ofPolynomial w (MvPolynomial.X i)

@[simp] theorem norm_generator (i : ι) : ‖generator w i‖ = w.value i := by
  rw [generator, norm_ofPolynomial]
  exact WeightedPolynomial.norm_X w i

/-- Extend the bounded moment functional continuously to the completion. -/
def momentFunctional (m : (ι →₀ ℕ) → ℂ)
    (hm : ∀ d, ‖m d‖ ≤ monomialWeight w.value d) : WeightedAlgebra w →L[ℂ] ℂ :=
  (WeightedPolynomial.momentCLM w m hm).extend
    (Completion.toComplL : WeightedPolynomial w →L[ℂ] Completion (WeightedPolynomial w))
    (Completion.denseRange_coe (α := WeightedPolynomial w))
    (Completion.isUniformInducing_coe (WeightedPolynomial w))

@[simp] theorem momentFunctional_ofPolynomial (m : (ι →₀ ℕ) → ℂ)
    (hm : ∀ d, ‖m d‖ ≤ monomialWeight w.value d) (p : MvPolynomial ι ℂ) :
    momentFunctional w m hm (ofPolynomial w p) =
      WeightedPolynomial.momentLinear w m (WeightedPolynomial.ofPolynomial w p) :=
  ContinuousLinearMap.extend_eq ..

theorem momentFunctional_bound (m : (ι →₀ ℕ) → ℂ)
    (hm : ∀ d, ‖m d‖ ≤ monomialWeight w.value d) (a : WeightedAlgebra w) :
    ‖momentFunctional w m hm a‖ ≤ ‖a‖ := by
  refine (denseRange_ofPolynomial w).induction_on a
    (isClosed_le (momentFunctional w m hm).continuous.norm continuous_norm) ?_
  intro p
  rw [momentFunctional_ofPolynomial, norm_ofPolynomial]
  exact WeightedPolynomial.momentLinear_bound w m hm (WeightedPolynomial.ofPolynomial w p)

/-- The completed moment functional has operator norm at most one. -/
theorem norm_momentFunctional_le_one (m : (ι →₀ ℕ) → ℂ)
    (hm : ∀ d, ‖m d‖ ≤ monomialWeight w.value d) : ‖momentFunctional w m hm‖ ≤ 1 :=
  ContinuousLinearMap.opNorm_le_bound _ zero_le_one
    (fun a => by simpa only [one_mul] using momentFunctional_bound w m hm a)


@[simp] theorem ofPolynomial_one : ofPolynomial w (1 : MvPolynomial ι ℂ) = 1 :=
  Completion.coe_one (WeightedPolynomial w)

@[simp] theorem ofPolynomial_mul (p q : MvPolynomial ι ℂ) :
    ofPolynomial w (p * q) = ofPolynomial w p * ofPolynomial w q :=
  Completion.coe_mul (WeightedPolynomial.ofPolynomial w p) (WeightedPolynomial.ofPolynomial w q)

@[simp] theorem momentFunctional_one (m : (ι →₀ ℕ) → ℂ)
    (hm : ∀ d, ‖m d‖ ≤ monomialWeight w.value d) : momentFunctional w m hm 1 = m 0 := by
  rw [← ofPolynomial_one w, momentFunctional_ofPolynomial]
  simpa only [one_mul] using WeightedPolynomial.momentCLM_monomial w m hm 0 1


/-- The polynomial embedding preserves the full complex algebra structure. -/
def ofPolynomialAlgHom : MvPolynomial ι ℂ →ₐ[ℂ] WeightedAlgebra w where
  toFun := ofPolynomial w
  map_zero' := Completion.coe_zero
  map_one' := ofPolynomial_one w
  map_add' p q := Completion.coe_add (WeightedPolynomial.ofPolynomial w p) (WeightedPolynomial.ofPolynomial w q)
  map_mul' := ofPolynomial_mul w
  commutes' r := by
    change ((algebraMap ℂ (WeightedPolynomial w) r) : Completion (WeightedPolynomial w)) =
      algebraMap ℂ (WeightedAlgebra w) r
    rfl

@[simp] theorem ofPolynomialAlgHom_apply (p : MvPolynomial ι ℂ) :
    ofPolynomialAlgHom w p = ofPolynomial w p := rfl

/-- Polynomial inserted identities extend to every completed-algebra insertion
by density and continuity of multiplication. -/
theorem inserted_polynomial_relations {J : Type*} (r : J → MvPolynomial ι ℂ)
    (m : (ι →₀ ℕ) → ℂ) (hm : ∀ d, ‖m d‖ ≤ monomialWeight w.value d)
    (hrelations : ∀ (p : MvPolynomial ι ℂ) j,
      WeightedPolynomial.momentLinear w m (WeightedPolynomial.ofPolynomial w (p * r j)) = 0)
    (a : WeightedAlgebra w) (j : J) :
    momentFunctional w m hm (a * ofPolynomial w (r j)) = 0 := by
  refine (denseRange_ofPolynomial w).induction_on a ?_ ?_
  · exact isClosed_eq ((momentFunctional w m hm).continuous.comp
      (continuous_id.mul continuous_const)) continuous_const
  · intro p
    rw [← ofPolynomial_mul, momentFunctional_ofPolynomial]
    exact hrelations p j

end WeightedAlgebra

section Relations

variable (w : Weights ι) {J : Type*} (r : J → MvPolynomial ι ℂ)

/-- The closed ideal generated by the prescribed exact polynomial relations. -/
def closedRelationIdeal : Ideal (WeightedAlgebra w) :=
  (Ideal.span (Set.range fun j => WeightedAlgebra.ofPolynomial w (r j))).closure

instance closedRelationIdeal_isClosed : IsClosed (closedRelationIdeal w r : Set (WeightedAlgebra w)) :=
  isClosed_closure

/-- The actual complete quotient algebra used to impose polynomial relations. -/
def RelationQuotient : Type _ := WeightedAlgebra w ⧸ closedRelationIdeal w r

namespace RelationQuotient

instance : NormedCommRing (RelationQuotient w r) := inferInstanceAs
  (NormedCommRing (WeightedAlgebra w ⧸ closedRelationIdeal w r))
instance : NormedAlgebra ℂ (RelationQuotient w r) := inferInstanceAs
  (NormedAlgebra ℂ (WeightedAlgebra w ⧸ closedRelationIdeal w r))
instance : CompleteSpace (RelationQuotient w r) := inferInstanceAs
  (CompleteSpace (WeightedAlgebra w ⧸ closedRelationIdeal w r))

/-- The canonical quotient algebra homomorphism. -/
def mk : WeightedAlgebra w →ₐ[ℂ] RelationQuotient w r :=
  Ideal.Quotient.mkₐ ℂ (closedRelationIdeal w r)

theorem norm_mk_le (a : WeightedAlgebra w) : ‖mk w r a‖ ≤ ‖a‖ :=
  Ideal.Quotient.norm_mk_le (closedRelationIdeal w r) a

/-- Every defining polynomial relation is zero in the quotient. -/
theorem relation_eq_zero (j : J) : mk w r (WeightedAlgebra.ofPolynomial w (r j)) = 0 := by
  apply Ideal.Quotient.eq_zero_iff_mem.mpr
  exact subset_closure (Ideal.subset_span (Set.mem_range_self j))

/-- Descend any continuous functional annihilating the closed ideal. -/
def descendLinear (L : WeightedAlgebra w →L[ℂ] ℂ)
    (hann : ∀ a ∈ closedRelationIdeal w r, L a = 0) : RelationQuotient w r →ₗ[ℂ] ℂ :=
  ((closedRelationIdeal w r).restrictScalars ℂ).liftQ L.toLinearMap (by
    intro a ha
    exact hann a ha)

@[simp] theorem descendLinear_mk (L : WeightedAlgebra w →L[ℂ] ℂ)
    (hann : ∀ a ∈ closedRelationIdeal w r, L a = 0) (a : WeightedAlgebra w) :
    descendLinear w r L hann (mk w r a) = L a := rfl

/-- The quotient functional retains a norm-one bound; this follows from the
quotient norm's arbitrarily close representatives, not a chosen section. -/
theorem descendLinear_bound (L : WeightedAlgebra w →L[ℂ] ℂ)
    (hann : ∀ a ∈ closedRelationIdeal w r, L a = 0)
    (hbound : ∀ a, ‖L a‖ ≤ ‖a‖) (x : RelationQuotient w r) :
    ‖descendLinear w r L hann x‖ ≤ ‖x‖ := by
  apply le_of_forall_pos_le_add
  intro ε hε
  obtain ⟨a, ha, hanorm⟩ := Ideal.Quotient.norm_mk_lt (I := closedRelationIdeal w r) x hε
  calc
    ‖descendLinear w r L hann x‖ = ‖L a‖ := by rw [← ha]; rfl
    _ ≤ ‖a‖ := hbound a
    _ ≤ ‖x‖ + ε := hanorm.le

/-- The continuous quotient functional with the proved bound. -/
def descendFunctional (L : WeightedAlgebra w →L[ℂ] ℂ)
    (hann : ∀ a ∈ closedRelationIdeal w r, L a = 0)
    (hbound : ∀ a, ‖L a‖ ≤ ‖a‖) : RelationQuotient w r →L[ℂ] ℂ :=
  (descendLinear w r L hann).mkContinuous 1
    (fun x => by simpa only [one_mul] using descendLinear_bound w r L hann hbound x)

/-- Inserted polynomial identities annihilate the entire closed relation ideal. -/
theorem moment_annihilates_closedIdeal
    (m : (ι →₀ ℕ) → ℂ) (hm : ∀ d, ‖m d‖ ≤ monomialWeight w.value d)
    (hrelations : ∀ (p : MvPolynomial ι ℂ) j,
      WeightedPolynomial.momentLinear w m (WeightedPolynomial.ofPolynomial w (p * r j)) = 0)
    (a : WeightedAlgebra w) (ha : a ∈ closedRelationIdeal w r) :
    WeightedAlgebra.momentFunctional w m hm a = 0 := by
  exact SYK.ClosedIdeal.inserted_residuals_annihilate_closed_ideal
    (WeightedAlgebra.momentFunctional w m hm) (fun j => WeightedAlgebra.ofPolynomial w (r j))
    (WeightedAlgebra.inserted_polynomial_relations w r m hm hrelations) ha

/-- The actual descended moment functional on the regularity quotient. -/
def quotientMomentFunctional
    (m : (ι →₀ ℕ) → ℂ) (hm : ∀ d, ‖m d‖ ≤ monomialWeight w.value d)
    (hrelations : ∀ (p : MvPolynomial ι ℂ) j,
      WeightedPolynomial.momentLinear w m (WeightedPolynomial.ofPolynomial w (p * r j)) = 0) :
    RelationQuotient w r →L[ℂ] ℂ :=
  descendFunctional w r (WeightedAlgebra.momentFunctional w m hm)
    (moment_annihilates_closedIdeal w r m hm hrelations)
    (WeightedAlgebra.momentFunctional_bound w m hm)

@[simp] theorem quotientMomentFunctional_mk
    (m : (ι →₀ ℕ) → ℂ) (hm : ∀ d, ‖m d‖ ≤ monomialWeight w.value d)
    (hrelations : ∀ (p : MvPolynomial ι ℂ) j,
      WeightedPolynomial.momentLinear w m (WeightedPolynomial.ofPolynomial w (p * r j)) = 0)
    (a : WeightedAlgebra w) :
    quotientMomentFunctional w r m hm hrelations (mk w r a) =
      WeightedAlgebra.momentFunctional w m hm a := rfl

/-- Normalization proves the quotient is nonzero, rather than assuming that
the imposed closed ideal is proper. -/
theorem nontrivial_of_normalized_moments
    (m : (ι →₀ ℕ) → ℂ) (hm : ∀ d, ‖m d‖ ≤ monomialWeight w.value d)
    (hrelations : ∀ (p : MvPolynomial ι ℂ) j,
      WeightedPolynomial.momentLinear w m (WeightedPolynomial.ofPolynomial w (p * r j)) = 0)
    (hunit : m 0 = 1) : Nontrivial (RelationQuotient w r) := by
  let L := quotientMomentFunctional w r m hm hrelations
  have hone : L 1 = 1 := by
    change L (mk w r 1) = 1
    rw [quotientMomentFunctional_mk, WeightedAlgebra.momentFunctional_one, hunit]
  refine ⟨⟨1, 0, ?_⟩⟩
  intro h
  have heq := congrArg L h
  rw [hone, map_zero] at heq
  exact one_ne_zero heq

end RelationQuotient
end Relations




section EndpointRegularity

/-- The manuscript's actual (uncountable) set of real endpoint pairs. -/
abbrev Endpoint := ℝ × ℝ

/-- The endpoint displacement used in the mixed-increment estimates. -/
def endpointDistance (p q : Endpoint) : ℝ := |p.1 - q.1| + |p.2 - q.2|

theorem endpointDistance_pos {p q : Endpoint} (hpq : p ≠ q) : 0 < endpointDistance p q := by
  by_contra h
  have hsum : |p.1 - q.1| + |p.2 - q.2| ≤ 0 := le_of_not_gt h
  have h1 : |p.1 - q.1| = 0 := by linarith [abs_nonneg (p.1 - q.1), abs_nonneg (p.2 - q.2)]
  have h2 : |p.2 - q.2| = 0 := by linarith [abs_nonneg (p.1 - q.1), abs_nonneg (p.2 - q.2)]
  apply hpq
  exact Prod.ext (sub_eq_zero.mp (abs_eq_zero.mp h1)) (sub_eq_zero.mp (abs_eq_zero.mp h2))

/-- Formal increments omit the zero-distance pairs so that all weights are positive. -/
abbrev IncrementIndex := {pq : Endpoint × Endpoint // pq.1 ≠ pq.2}

/-- Both coordinate generators and formal increment generators are retained. -/
abbrev KernelIndex := Endpoint ⊕ IncrementIndex

/-- Coordinate weights `b` and increment weights `K d(p,q)`. -/
def kernelWeights (b K : ℝ) (hb : 0 < b) (hK : 0 < K) : Weights KernelIndex where
  value := Sum.elim (fun _ => b) (fun pq => K * endpointDistance pq.val.1 pq.val.2)
  positive := by
    intro i
    cases i with
    | inl p => exact hb
    | inr pq => exact mul_pos hK (endpointDistance_pos pq.property)

/-- Exact increment-substitution relations, together with any prescribed
additional polynomial symmetry relations. The covariance is scalar data. -/
def kernelRelations {J : Type*} (C₀ : Endpoint → ℂ)
    (extra : J → MvPolynomial KernelIndex ℂ) : IncrementIndex ⊕ J → MvPolynomial KernelIndex ℂ
  | .inl pq => MvPolynomial.X (.inr pq) - MvPolynomial.X (.inl pq.val.1) +
      MvPolynomial.X (.inl pq.val.2) + MvPolynomial.C (C₀ pq.val.1) - MvPolynomial.C (C₀ pq.val.2)
  | .inr j => extra j

variable {J : Type*} (b K : ℝ) (hb : 0 < b) (hK : 0 < K)
  (C₀ : Endpoint → ℂ) (extra : J → MvPolynomial KernelIndex ℂ)

/-- The Section 6 regularity algebra, constructed as a closed ideal quotient
of the completed weighted polynomial algebra. -/
abbrev RegularityAlgebra := RelationQuotient (kernelWeights b K hb hK) (kernelRelations C₀ extra)

/-- The actual coordinate class in the regularity algebra. -/
def coordinate (p : Endpoint) : RegularityAlgebra b K hb hK C₀ extra :=
  RelationQuotient.mk _ _ (WeightedAlgebra.generator (kernelWeights b K hb hK) (.inl p))

/-- The formal increment class, equal below to a difference of remainders. -/
def increment (pq : IncrementIndex) : RegularityAlgebra b K hb hK C₀ extra :=
  RelationQuotient.mk _ _ (WeightedAlgebra.generator (kernelWeights b K hb hK) (.inr pq))

/-- Subtract the prescribed scalar fermionic jump. -/
def remainder (p : Endpoint) : RegularityAlgebra b K hb hK C₀ extra :=
  coordinate b K hb hK C₀ extra p - algebraMap ℂ _ (C₀ p)

/-- Coordinate classes satisfy the assigned bound in the actual quotient norm. -/
theorem norm_coordinate_le (p : Endpoint) : ‖coordinate b K hb hK C₀ extra p‖ ≤ b := by
  exact (RelationQuotient.norm_mk_le _ _ _).trans_eq
    (WeightedAlgebra.norm_generator (kernelWeights b K hb hK) (.inl p))

/-- Formal increments retain their assigned norm bound after quotienting. -/
theorem norm_increment_le (pq : IncrementIndex) :
    ‖increment b K hb hK C₀ extra pq‖ ≤ K * endpointDistance pq.val.1 pq.val.2 := by
  exact (RelationQuotient.norm_mk_le _ _ _).trans_eq
    (WeightedAlgebra.norm_generator (kernelWeights b K hb hK) (.inr pq))

/-- The imposed relation is an exact equality of quotient elements. -/
theorem increment_eq_remainder_sub (pq : IncrementIndex) :
    increment b K hb hK C₀ extra pq =
      remainder b K hb hK C₀ extra pq.val.1 - remainder b K hb hK C₀ extra pq.val.2 := by
  let w := kernelWeights b K hb hK
  let r := kernelRelations C₀ extra
  let F := (RelationQuotient.mk w r).comp (WeightedAlgebra.ofPolynomialAlgHom w)
  have h := RelationQuotient.relation_eq_zero w r (Sum.inl pq)
  change F (r (Sum.inl pq)) = 0 at h
  dsimp only [r, kernelRelations] at h
  simp only [map_sub, map_add, ← MvPolynomial.algebraMap_eq, AlgHom.commutes] at h
  apply sub_eq_zero.mp
  calc
    increment b K hb hK C₀ extra pq -
        (remainder b K hb hK C₀ extra pq.val.1 - remainder b K hb hK C₀ extra pq.val.2) =
        F (MvPolynomial.X (.inr pq)) - F (MvPolynomial.X (.inl pq.val.1)) +
          F (MvPolynomial.X (.inl pq.val.2)) + algebraMap ℂ _ (C₀ pq.val.1) -
          algebraMap ℂ _ (C₀ pq.val.2) := by
      change (F (MvPolynomial.X (.inr pq))) -
        ((F (MvPolynomial.X (.inl pq.val.1)) - algebraMap ℂ _ (C₀ pq.val.1)) -
         (F (MvPolynomial.X (.inl pq.val.2)) - algebraMap ℂ _ (C₀ pq.val.2))) = _
      ring
    _ = 0 := h

/-- The precise endpoint Lipschitz bound of Equation (6.2), including equal
endpoint pairs, is proved in the constructed regularity algebra. -/
theorem norm_remainder_sub_le (p q : Endpoint) :
    ‖remainder b K hb hK C₀ extra p - remainder b K hb hK C₀ extra q‖ ≤
      K * endpointDistance p q := by
  by_cases hpq : p = q
  · subst q
    simp [endpointDistance]
  · let pq : IncrementIndex := ⟨(p, q), hpq⟩
    rw [← increment_eq_remainder_sub b K hb hK C₀ extra pq]
    exact norm_increment_le b K hb hK C₀ extra pq

/-- Comparison with the usual product metric, which uses the maximum norm. -/
theorem endpointDistance_le_two_dist (p q : Endpoint) :
    endpointDistance p q ≤ 2 * dist p q := by
  rw [Prod.dist_eq, Real.dist_eq, Real.dist_eq]
  dsimp [endpointDistance]
  linarith [le_max_left |p.1 - q.1| |p.2 - q.2|,
    le_max_right |p.1 - q.1| |p.2 - q.2|]

/-- The remainder is globally Lipschitz for the ordinary product metric. -/
theorem remainder_lipschitz :
    LipschitzWith ⟨2 * K, by positivity⟩ (remainder b K hb hK C₀ extra) := by
  apply LipschitzWith.of_dist_le_mul
  intro p q
  rw [dist_eq_norm]
  calc
    _ ≤ K * endpointDistance p q := norm_remainder_sub_le b K hb hK C₀ extra p q
    _ ≤ K * (2 * dist p q) :=
      mul_le_mul_of_nonneg_left (endpointDistance_le_two_dist p q) hK.le
    _ = _ := by dsimp; ring

/-- The scalar jump has been removed in the algebra norm: no continuity of
`C₀` is needed for the continuous remainder. -/
theorem remainder_continuous : Continuous (remainder b K hb hK C₀ extra) :=
  (remainder_lipschitz b K hb hK C₀ extra).continuous

/-- This is the positive regularity constant used in the manuscript. -/
theorem manuscript_regularity_constant_pos (lam β b : ℝ) (hlam : 0 ≤ lam) (hβ : 0 ≤ β) :
    0 < 1 + lam * β * b ^ 4 := by positivity

/-- Any additional polynomial symmetry relation is also imposed exactly. -/
theorem extra_relation_eq_zero (j : J) :
    RelationQuotient.mk (kernelWeights b K hb hK) (kernelRelations C₀ extra)
      (WeightedAlgebra.ofPolynomial (kernelWeights b K hb hK) (extra j)) = 0 :=
  RelationQuotient.relation_eq_zero _ _ (Sum.inr j)

end EndpointRegularity

end SYK.WeightedKernelAlgebra
