import GaussianDisorder
import Mathlib.MeasureTheory.Measure.CharacteristicFunction
import Mathlib.MeasureTheory.Integral.Pi

/-! Exact rotational invariance of the actual finite product Gaussian law. -/
noncomputable section
open MeasureTheory ProbabilityTheory
open scoped NNReal ComplexConjugate
namespace SYK.GaussianRotation

/-- The rotation orientation whose first-coordinate derivative is the second. -/
def rotate (θ : ℝ) (p : ℝ × ℝ) : ℝ × ℝ :=
  (Real.cos θ * p.1 + Real.sin θ * p.2,
    -Real.sin θ * p.1 + Real.cos θ * p.2)

@[fun_prop] theorem measurable_rotate (θ : ℝ) : Measurable (rotate θ) := by
  unfold rotate; fun_prop

/-- A bilinear separating pairing on the usual product topology. -/
def dotPairing : (ℝ × ℝ) →ₗ[ℝ] (ℝ × ℝ) →ₗ[ℝ] ℝ where
  toFun p :=
    { toFun := fun q => p.1*q.1+p.2*q.2
      map_add' := by intros; simp; ring
      map_smul' := by intros; simp; ring }
  map_add' := by
    intro x y
    apply LinearMap.ext
    intro q
    change (x.1+y.1)*q.1+(x.2+y.2)*q.2 = (x.1*q.1+x.2*q.2)+(y.1*q.1+y.2*q.2)
    ring
  map_smul' := by
    intro r x
    apply LinearMap.ext
    intro q
    change (r*x.1)*q.1+(r*x.2)*q.2 = r*(x.1*q.1+x.2*q.2)
    ring

@[simp] theorem dotPairing_apply (p q : ℝ × ℝ) :
    dotPairing p q = p.1*q.1+p.2*q.2 := rfl

theorem dotPairing_separates (p : ℝ × ℝ) (hp : p ≠ 0) : dotPairing p ≠ 0 := by
  intro h
  apply hp
  apply Prod.ext
  · have hx := congrArg (fun f : (ℝ × ℝ) →ₗ[ℝ] ℝ => f (1,0)) h
    simpa using hx
  · have hy := congrArg (fun f : (ℝ × ℝ) →ₗ[ℝ] ℝ => f (0,1)) h
    simpa using hy

/-- Product characteristic function, valid also at zero variance. -/
theorem pair_characteristic (v : ℝ≥0) (a b : ℝ) :
    (∫ p : ℝ × ℝ, Complex.exp (((a*p.1+b*p.2 : ℝ) : ℂ) * Complex.I)
      ∂(gaussianReal 0 v).prod (gaussianReal 0 v)) =
      Complex.exp (-(v : ℂ) * ((a : ℂ)^2+(b : ℂ)^2) / 2) := by
  have he (p : ℝ × ℝ) : Complex.exp (((a*p.1+b*p.2 : ℝ) : ℂ)*Complex.I) =
      Complex.exp (((a*p.1 : ℝ) : ℂ)*Complex.I) *
        Complex.exp (((b*p.2 : ℝ) : ℂ)*Complex.I) := by
    rw [← Complex.exp_add]; congr 1; push_cast; ring
  simp_rw [he]
  rw [integral_prod_mul (fun x : ℝ => Complex.exp (((a*x : ℝ) : ℂ)*Complex.I))
    (fun y : ℝ => Complex.exp (((b*y : ℝ) : ℂ)*Complex.I))]
  simp only [Complex.ofReal_mul]
  rw [← charFun_apply_real, ← charFun_apply_real]
  rw [charFun_gaussianReal, charFun_gaussianReal, ← Complex.exp_add]
  congr 1
  simp only [Complex.ofReal_zero, mul_zero, zero_mul, zero_sub]
  ring

/-- The two-dimensional Gaussian characteristic function is unchanged by rotation. -/
theorem rotated_characteristic (v : ℝ≥0) (θ : ℝ) (w : ℝ × ℝ) :
    (∫ p : ℝ × ℝ, Complex.exp ((dotPairing (rotate θ p) w : ℝ) * Complex.I)
      ∂(gaussianReal 0 v).prod (gaussianReal 0 v)) =
    (∫ p : ℝ × ℝ, Complex.exp ((dotPairing p w : ℝ) * Complex.I)
      ∂(gaussianReal 0 v).prod (gaussianReal 0 v)) := by
  have he (p : ℝ × ℝ) : dotPairing (rotate θ p) w =
      (Real.cos θ*w.1-Real.sin θ*w.2)*p.1 +
        (Real.sin θ*w.1+Real.cos θ*w.2)*p.2 := by
    simp only [dotPairing_apply, rotate]; ring
  simp_rw [he]
  have he' (p : ℝ × ℝ) : dotPairing p w = w.1*p.1+w.2*p.2 := by
    simp only [dotPairing_apply]; ring
  simp_rw [he']
  rw [pair_characteristic, pair_characteristic]
  have hs : (Real.cos θ*w.1-Real.sin θ*w.2)^2 +
      (Real.sin θ*w.1+Real.cos θ*w.2)^2 = w.1^2+w.2^2 := by
    calc
      _ = (Real.cos θ^2+Real.sin θ^2)*(w.1^2+w.2^2) := by ring
      _ = _ := by rw [Real.cos_sq_add_sin_sq]; ring
  have hsc : (((Real.cos θ*w.1-Real.sin θ*w.2 : ℝ) : ℂ))^2 +
      (((Real.sin θ*w.1+Real.cos θ*w.2 : ℝ) : ℂ))^2 =
      (w.1 : ℂ)^2+(w.2 : ℂ)^2 := by exact_mod_cast hs
  rw [hsc]

/-- Exact invariance of a Gaussian pair, including the degenerate variance-zero law. -/
theorem pair_measurePreserving (v : ℝ≥0) (θ : ℝ) :
    MeasurePreserving (rotate θ) ((gaussianReal 0 v).prod (gaussianReal 0 v))
      ((gaussianReal 0 v).prod (gaussianReal 0 v)) := by
  refine ⟨measurable_rotate θ, ?_⟩
  let μ := (gaussianReal 0 v).prod (gaussianReal 0 v)
  haveI : IsProbabilityMeasure (μ.map (rotate θ)) :=
    isProbabilityMeasure_map (measurable_rotate θ).aemeasurable
  have hLc : Continuous (fun p : (ℝ × ℝ) × (ℝ × ℝ) => dotPairing p.1 p.2) := by
    simp only [dotPairing_apply]; fun_prop
  apply ext_of_integral_char_eq Real.continuous_probChar Real.probChar_ne_one
    dotPairing_separates hLc
  intro w
  rw [integral_map (measurable_rotate θ).aemeasurable]
  · simp only [BoundedContinuousFunction.char_apply, Real.probChar_apply]
    exact rotated_characteristic v θ w
  · exact (BoundedContinuousFunction.char Real.continuous_probChar hLc w).continuous.measurable.aestronglyMeasurable

variable {ι : Type*} [Fintype ι]

/-- The actual centered Gaussian finite-array law. -/
abbrev arrayLaw (v : ℝ≥0) : Measure (ι → ℝ) := Measure.pi (fun _ => gaussianReal 0 v)

/-- Simultaneous rotation of two independent arrays. -/
def rotateArray (θ : ℝ) (p : (ι → ℝ) × (ι → ℝ)) : (ι → ℝ) × (ι → ℝ) :=
  ((fun i => Real.cos θ * p.1 i + Real.sin θ * p.2 i),
    (fun i => -Real.sin θ * p.1 i + Real.cos θ * p.2 i))

@[fun_prop] theorem measurable_rotateArray (θ : ℝ) :
    Measurable (rotateArray (ι := ι) θ) := by unfold rotateArray; fun_prop

/-- Exact finite-product rotational invariance, with no restriction on variance.
In particular this theorem includes the zero-variance Dirac law. -/
theorem array_measurePreserving (v : ℝ≥0) (θ : ℝ) :
    MeasurePreserving (rotateArray (ι := ι) θ)
      ((arrayLaw v).prod (arrayLaw v)) ((arrayLaw v).prod (arrayLaw v)) := by
  let e := MeasurableEquiv.arrowProdEquivProdArrow ℝ ℝ ι
  have he := measurePreserving_arrowProdEquivProdArrow ℝ ℝ ι
    (fun _ => gaussianReal 0 v) (fun _ => gaussianReal 0 v)
  have hp := measurePreserving_pi
    (fun _ : ι => (gaussianReal 0 v).prod (gaussianReal 0 v))
    (fun _ : ι => (gaussianReal 0 v).prod (gaussianReal 0 v))
    (fun _ => pair_measurePreserving v θ)
  convert he.comp (hp.comp (he.symm e)) using 1

@[simp] theorem rotateArray_zero (p : (ι → ℝ) × (ι → ℝ)) : rotateArray 0 p = p := by
  apply Prod.ext <;> funext i <;> simp [rotateArray]

@[simp] theorem rotateArray_pi_div_two (p : (ι → ℝ) × (ι → ℝ)) :
    rotateArray (Real.pi/2) p = (p.2,-p.1) := by
  apply Prod.ext <;> funext i <;> simp [rotateArray]

/-- The derivative of the first rotated array is exactly the second. -/
theorem hasDerivAt_rotateArray_first (p : (ι → ℝ) × (ι → ℝ)) (θ : ℝ) :
    HasDerivAt (fun t => (rotateArray t p).1) (rotateArray θ p).2 θ := by
  apply hasDerivAt_pi.mpr
  intro i
  convert ((Real.hasDerivAt_cos θ).mul_const (p.1 i)).add
    ((Real.hasDerivAt_sin θ).mul_const (p.2 i)) using 1

end SYK.GaussianRotation
