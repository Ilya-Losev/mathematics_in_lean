import DuhamelTrace
import Mathlib.Analysis.SpecificLimits.Normed

/-!
# Differentiating factorially bounded interacting moment series

This is the analytic series step. Its coefficients remain explicit scalar
inputs; the microscopic operator/coefficient correspondence is supplied by the
separate interacting Wick construction, not assumed by the final model theorem.
-/

noncomputable section
open Filter Set
open scoped Topology
namespace SYK.ExponentialMomentSeries

/-- Factorial-normalized coefficient at real coupling. -/
def term (a : ℕ → ℂ) (l : ℝ) (n : ℕ) : ℂ := (l^n / (n.factorial : ℝ)) • a n

def value (a : ℕ → ℂ) (l : ℝ) : ℂ := ∑' n, term a l n

/-- A geometric coefficient bound gives absolute convergence at every coupling. -/
theorem summable_norm_term (a : ℕ → ℂ) (K R : ℝ) (_hK : 0 ≤ K) (_hR : 0 ≤ R)
    (ha : ∀ n, ‖a n‖ ≤ K * R^n) (l : ℝ) : Summable (fun n => ‖term a l n‖) := by
  apply Summable.of_nonneg_of_le (fun n => norm_nonneg _) _
    ((Real.summable_pow_div_factorial (|l| * R)).mul_left K)
  intro n
  simp only [term, norm_smul, Real.norm_eq_abs, abs_div, abs_pow, Nat.abs_cast]
  calc
    _ ≤ (|l|^n / (n.factorial : ℝ)) * (K*R^n) := by gcongr; exact ha n
    _ = K * ((|l| * R)^n / (n.factorial : ℝ)) := by rw [mul_pow]; ring

theorem summable_term (a : ℕ → ℂ) (K R : ℝ) (hK : 0 ≤ K) (hR : 0 ≤ R)
    (ha : ∀ n, ‖a n‖ ≤ K * R^n) (l : ℝ) : Summable (term a l) :=
  (summable_norm_term a K R hK hR ha l).of_norm

/-- Exact derivative of each factorial-normalized positive-degree term. -/
theorem hasDerivAt_term_succ (a : ℕ → ℂ) (n : ℕ) (l : ℝ) :
    HasDerivAt (fun s => term a s (n+1)) (term (fun k => a (k+1)) l n) l := by
  have h := ((hasDerivAt_pow (n+1) l).div_const ((n+1).factorial : ℝ)).smul_const (a (n+1))
  have he : ((n+1 : ℕ) : ℝ) * l^n / ((n+1).factorial : ℝ) = l^n / (n.factorial : ℝ) := by
    rw [Nat.factorial_succ, Nat.cast_mul]
    field_simp
    ring
  simpa only [term, Nat.add_sub_cancel, he] using h

/-- A summable uniform bound for the derivative series on any bounded interval. -/
theorem derivative_term_le (a : ℕ → ℂ) (K R T : ℝ) (_hK : 0 ≤ K) (_hR : 0 ≤ R)
    (hT : 0 ≤ T) (ha : ∀ n, ‖a n‖ ≤ K * R^n) (l : ℝ) (hl : |l| ≤ T) (n : ℕ) :
    ‖term (fun k => a (k+1)) l n‖ ≤ (K*R) * ((T*R)^n / (n.factorial : ℝ)) := by
  simp only [term, norm_smul, Real.norm_eq_abs, abs_div, abs_pow, Nat.abs_cast]
  calc
    _ ≤ (T^n / (n.factorial : ℝ)) * (K*R^(n+1)) := by
      gcongr
      exact ha (n+1)
    _ = _ := by rw [pow_succ, mul_pow]; ring

/-- The entire factorially bounded series is differentiable, with the shifted
coefficient sequence as derivative. This proves rather than assumes termwise
differentiation. -/
theorem hasDerivAt_value (a : ℕ → ℂ) (K R : ℝ) (hK : 0 ≤ K) (hR : 0 ≤ R)
    (ha : ∀ n, ‖a n‖ ≤ K * R^n) (l : ℝ) :
    HasDerivAt (value a) (value (fun n => a (n+1)) l) l := by
  let T : ℝ := |l|+1
  have hT : 0 < T := by dsimp [T]; positivity
  have hu := (Real.summable_pow_div_factorial (T*R)).mul_left (K*R)
  have hd := hasDerivAt_tsum_of_isPreconnected hu isOpen_Ioo (convex_Ioo (-T) T).isPreconnected
    (fun n y _ => hasDerivAt_term_succ a n y)
    (fun n y hy => derivative_term_le a K R T hK hR hT.le ha y
      (abs_le.mpr ⟨hy.1.le,hy.2.le⟩) n)
    (show (0 : ℝ) ∈ Ioo (-T) T by constructor <;> linarith)
    (show Summable (fun n => term a 0 (n+1)) by
      simpa [term] using (summable_zero : Summable (fun _ : ℕ => (0 : ℂ))))
    (show l ∈ Ioo (-T) T by
      constructor <;> dsimp [T] <;> linarith [le_abs_self l, neg_abs_le l])
  have hv (s : ℝ) : value a s = a 0 + ∑' n, term a s (n+1) := by
    rw [value, (summable_term a K R hK hR ha s).tsum_eq_zero_add]
    simp [term]
  have hh := hd.const_add (a 0)
  simpa only [← hv, value] using hh

/-- A coefficient insertion recurrence becomes the true derivative of the
summed interacting series. -/
theorem hasDerivAt_value_insertion (a b : ℕ → ℂ) (K R c : ℝ)
    (hK : 0 ≤ K) (hR : 0 ≤ R) (ha : ∀ n, ‖a n‖ ≤ K * R^n)
    (hinsert : ∀ n, a (n+1) = c • b n) (l : ℝ) :
    HasDerivAt (value a) (c • value b l) l := by
  have h := hasDerivAt_value a K R hK hR ha l
  have he : value (fun n => a (n+1)) l = c • value b l := by
    unfold value term
    simp only [hinsert, smul_comm _ c]
    exact tsum_const_smul'' c
  rwa [he] at h

/-- The logarithm of the real partition series has its normalized insertion
as derivative, whenever that actual partition value is positive. -/
theorem hasDerivAt_log_real_value (a b : ℕ → ℂ) (K R c N : ℝ)
    (hK : 0 ≤ K) (hR : 0 ≤ R) (ha : ∀ n, ‖a n‖ ≤ K * R^n)
    (hinsert : ∀ n, a (n+1) = c • b n) (l : ℝ) (hz : 0 < (value a l).re) :
    HasDerivAt (fun s => Real.log (value a s).re / N)
      ((c * (value b l).re / (value a l).re) / N) l := by
  have h := Complex.reCLM.hasFDerivAt.comp_hasDerivAt l
    (hasDerivAt_value_insertion a b K R c hK hR ha hinsert l)
  simpa only [Function.comp_apply, Complex.reCLM_apply, Complex.smul_re, smul_eq_mul] using (h.log hz.ne').div_const N

end SYK.ExponentialMomentSeries
