import MicroscopicPressure
import GibbsState

/-!
# Well-defined actual microscopic pressures

These statements connect the concrete matrix partition function with its actual
Gaussian disorder law. They prove positivity of its annealed average and
integrability of its logarithm, rather than relying on Lean's default value for
an undefined Bochner integral. No large-N limit is assumed or asserted here.
-/

set_option maxHeartbeats 1200000

noncomputable section
open MeasureTheory
open scoped NNReal
namespace SYK.Microscopic

/-- The ordinary trace has strictly positive disorder average. -/
theorem annealed_partition_pos (m : ℕ) (β : ℝ) (lam : ℝ≥0) :
    0 < ∫ j, (Majorana.partitionFunction m β j).re ∂disorder m lam := by
  rw [integral_pos_iff_support_of_nonneg
    (fun j => (Gibbs.syk_partition_re_pos m β j).le)
    (real_partitionFunction_integrable m β lam)]
  have hs : Function.support (fun j => (Majorana.partitionFunction m β j).re) =
      Set.univ := by
    ext j
    simp only [Function.mem_support, Set.mem_univ, iff_true]
    exact (Gibbs.syk_partition_re_pos m β j).ne'
  simp [hs]

/-- The total absolute coupling size is genuinely integrable under disorder. -/
theorem coupling_size_integrable (m : ℕ) (lam : ℝ≥0) :
    Integrable (fun j : Majorana.FourSet m → ℝ => ∑ I, |j I|) (disorder m lam) := by
  have hg := GaussianDisorder.integrable_exp_sum_abs (Majorana.FourSet m)
    (2 * m) lam 1
  apply hg.mono'
  · exact (continuous_finset_sum _ (fun I _ =>
      (continuous_apply I).abs)).aestronglyMeasurable
  · filter_upwards [] with j
    rw [Real.norm_eq_abs, abs_of_nonneg (Finset.sum_nonneg (fun I _ => abs_nonneg _)),
      one_mul]
    have h := Real.add_one_le_exp (∑ I, |j I|)
    linarith

/-- The quenched pressure is an integral of an integrable real logarithm. -/
theorem log_partitionFunction_integrable (m : ℕ) (β : ℝ) (lam : ℝ≥0) :
    Integrable (fun j => Real.log (Majorana.partitionFunction m β j).re)
      (disorder m lam) := by
  have hg : Integrable (fun j : Majorana.FourSet m → ℝ =>
      (m : ℝ) * Real.log 2 + |β| * (∑ I, |j I|) / 4) (disorder m lam) :=
    (integrable_const ((m : ℝ) * Real.log 2)).add
      (((coupling_size_integrable m lam).const_mul |β|).div_const 4)
  apply hg.mono'
  · exact (Real.measurable_log.comp_aemeasurable
      (real_partitionFunction_integrable m β lam).aemeasurable).aestronglyMeasurable
  · filter_upwards [] with j
    exact Gibbs.abs_log_syk_partition_le m β j

end SYK.Microscopic
