import SignedWardReduction
import FundamentalWardBridge

noncomputable section
open MeasureTheory Set Filter
open scoped BigOperators NNReal
namespace SYK.FundamentalMomentIntegrability
open ThermalWick SignedWardReduction FundamentalWardContacts WickVertexIntegrals
local instance (β : ℝ) : MeasurableSpace (Time β) :=
  inferInstanceAs (MeasurableSpace {t : ℝ // t ∈ Ico 0 β})

/-- Polynomial insertions into true fundamental-domain moments are integrable
against every bounded measurable scalar weight on a finite measure space. -/
theorem actualFundamental_inserted_integrable {Ω : Type*} [MeasurableSpace Ω]
    (μ : Measure Ω) [IsFiniteMeasure μ] (β : ℝ) (hβ : 0<β) (d : ℕ) (hd : 0<d)
    (lam : ℝ≥0) (c : Ω→ℂ) (hc : Measurable c) (B : ℝ) (hb : ∀ x, ‖c x‖≤B)
    (Q : TimePolynomial β) {k : ℕ} (p : Ω→Fin k→TimePair β)
    (hp : ∀ i, Measurable (fun x=>p x i)) :
    Integrable (fun x=>c x*actualFundamental β d lam (Q*∏ i, MvPolynomial.X (p x i))) μ := by
  induction Q using MvPolynomial.induction_on generalizing k with
  | C z =>
    have hm : Measurable (fun x=>Interacting.collectiveMoment d β lam
        (fun i=>((p x i).1.val,(p x i).2.val))) := by
      apply (MomentMeasurability.measurable_collectiveMoment d β lam k).comp
      apply measurable_pi_lambda
      intro i
      exact (measurable_subtype_coe.comp (hp i).fst).prodMk
        (measurable_subtype_coe.comp (hp i).snd)
    have hi : Integrable (fun x=>c x*Interacting.collectiveMoment d β lam
        (fun i=>((p x i).1.val,(p x i).2.val))) μ := by
      apply (integrable_const (B*(1/2:ℝ)^k)).mono' (hc.mul hm).aestronglyMeasurable
      exact Eventually.of_forall (fun x=> by
        rw [norm_mul]
        exact mul_le_mul (hb x) (Interacting.collectiveMoment_bound d hd hβ lam _
          (fun i=>⟨⟨(p x i).1.property.1,(p x i).1.property.2.le⟩,
                    ⟨(p x i).2.property.1,(p x i).2.property.2.le⟩⟩))
          (norm_nonneg _) ((norm_nonneg (c x)).trans (hb x)))
    simp only [MvPolynomial.C_mul',map_smul,smul_eq_mul,actualFundamental_tuple]
    simpa only [mul_left_comm (c _) z] using hi.const_mul z
  | add P Q hP hQ =>
    simpa only [add_mul,map_add,mul_add] using (hP p hp).add (hQ p hp)
  | mul_X P a hP =>
    have h := hP (fun x=>Fin.cons a (p x)) (by
      intro i
      refine Fin.cases ?_ (fun i=>?_) i
      · exact measurable_const
      · exact hp i)
    simpa only [Fin.prod_univ_succ,Fin.cons_zero,Fin.cons_succ,mul_assoc] using h

/-- The literal fundamental Ward interaction is integrable for every actual
polynomial insertion, with all endpoint measurability proved microscopically. -/
theorem actualFundamental_ward_integrable (β : ℝ) (hβ : 0<β) (d : ℕ) (hd : 0<d)
    (lam : ℝ≥0) (s t : Time β) (Q : TimePolynomial β) :
    Integrable (fun x=>actualFundamental β d lam
      (Q*FundamentalWardBridge.interactionPolynomial β hβ s t x)) (ContinuumWickSeries.pairMeasure β) := by
  let r := timeRepresentative β hβ
  have hr : Measurable r := timeRepresentative_measurable β hβ
  have hp : ∀ i : Fin 4, Measurable (fun x : ℝ×ℝ=>
      (![ (r x.1,r x.2),(r x.1,r x.2),(r x.1,r x.2),(r x.2,t)] : Fin 4→TimePair β) i) := by
    intro i; fin_cases i <;> dsimp <;> fun_prop
  have hc : Measurable (fun x : ℝ×ℝ=>(Thermal.kernel β s.val (r x.1).val:ℂ)) := by
    exact Complex.measurable_ofReal.comp ((Thermal.covariance_measurable β).comp
      (measurable_const.sub (measurable_subtype_coe.comp (hr.comp measurable_fst))))
  have h := actualFundamental_inserted_integrable (ContinuumWickSeries.pairMeasure β)
    β hβ d hd lam _ hc (1/2) (fun x=>by
      simpa only [Complex.norm_real,Real.norm_eq_abs] using Thermal.abs_covariance_le β (s.val-(r x.1).val))
    Q _ hp
  simpa only [FundamentalWardBridge.interactionPolynomial,FundamentalWardBridge.interactionPairs,
    coordinateProduct,List.replicate_succ,List.replicate_zero,List.cons_append,List.nil_append,
    List.map_cons,List.map_nil,List.prod_cons,List.prod_nil,mul_one,
    Fin.prod_univ_succ,Fin.prod_univ_zero,Fin.cons_zero,Fin.cons_succ,mul_smul_comm,map_smul,smul_eq_mul] using h

end SYK.FundamentalMomentIntegrability
