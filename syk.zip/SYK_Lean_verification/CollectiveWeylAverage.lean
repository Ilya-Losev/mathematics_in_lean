import CollectiveFieldExpansion
import InteractingMoments

/-!
# Exact flavor averaging of physical annealed Weyl numerators

The finite flavor average and the actual Gaussian integral commute by proved
integrability. Normalized Clifford traces and the normalized annealed partition
have the same dimension factor, which cancels exactly in the physical moment.
No exterior/operator correspondence is assumed in this module.
-/
noncomputable section
open scoped BigOperators NNReal
open MeasureTheory
namespace SYK.CollectiveWeylAverage
open ThermalWick CollectiveFieldExpansion Interacting

/-- Real endpoints of a list of fundamental-domain bilocals. -/
def endpointTuple {β : ℝ} (ps : List (Time β × Time β)) : Fin ps.length → ℝ × ℝ :=
  fun i => ((ps.get i).1.val, (ps.get i).2.val)

@[simp] theorem pairLabels_times {N : ℕ} {β : ℝ}
    (ps : List (Time β × Time β)) (f : Fin ps.length → Fin N) :
    (fun i => (pairLabels ps f i).2.val) = pairTimes (endpointTuple ps) := by
  funext i
  simp only [pairLabels, pairTimes, endpointTuple]
  split_ifs <;> rfl

@[simp] theorem pairLabels_fields (d : ℕ) {β : ℝ}
    (ps : List (Time β × Time β)) (f : Fin ps.length → Fin (2*d)) :
    (fun i => Majorana.chiFin d (pairLabels ps f i).1) =
      (fun i => Majorana.chiFin d (pairFlavors f i)) := rfl

/-- Actual normalized annealed Weyl numerators, averaged over all N^m flavor
assignments, give exactly the normalized actual collective numerator. -/
theorem normalized_flavor_average (d : ℕ) {β : ℝ} (lam : ℝ≥0)
    (ps : List (Time β × Time β)) :
    (((2*d : ℕ) : ℂ)^ps.length)⁻¹ *
      (∑ f : Fin ps.length → Fin (2*d), ((2 : ℂ)^d)⁻¹ *
        (∫ j, weylNumerator (Majorana.hamiltonian d j) β
          (fun i => (pairLabels ps f i).2.val)
          (fun i => Majorana.chiFin d (pairLabels ps f i).1)
          ∂Microscopic.disorder d lam)) =
      ((2 : ℂ)^d)⁻¹ * (∫ j, collectiveNumerator d (Majorana.hamiltonian d j) β
        (endpointTuple ps) ∂Microscopic.disorder d lam) := by
  simp only [pairLabels_times, pairLabels_fields, collectiveNumerator]
  rw [integral_const_mul, integral_finset_sum]
  · rw [← Finset.mul_sum]
    ring
  · intro f _
    exact weylNumerator_integrable d β lam _ _

/-- Dividing the normalized flavor average by the normalized annealed
partition gives the manuscript's actual annealed collective moment. This
includes every internal or external time coincidence. -/
theorem normalized_flavor_average_ratio (d : ℕ) {β : ℝ} (lam : ℝ≥0)
    (ps : List (Time β × Time β)) :
    ((((2*d : ℕ) : ℂ)^ps.length)⁻¹ *
      (∑ f : Fin ps.length → Fin (2*d), ((2 : ℂ)^d)⁻¹ *
        (∫ j, weylNumerator (Majorana.hamiltonian d j) β
          (fun i => (pairLabels ps f i).2.val)
          (fun i => Majorana.chiFin d (pairLabels ps f i).1)
          ∂Microscopic.disorder d lam))) /
      (((∫ j, (Majorana.partitionFunction d β j).re
        ∂Microscopic.disorder d lam : ℝ) : ℂ) / (2 : ℂ)^d) =
      collectiveMoment d β lam (endpointTuple ps) := by
  rw [normalized_flavor_average, collectiveMoment]
  have hdim : (2 : ℂ)^d ≠ 0 := pow_ne_zero _ (by norm_num)
  have hZ : ((∫ j, (Majorana.partitionFunction d β j).re
      ∂Microscopic.disorder d lam : ℝ) : ℂ) ≠ 0 := by
    exact_mod_cast (ne_of_gt (ThermalRP.annealed_partition_positive d β lam))
  field_simp

end SYK.CollectiveWeylAverage
