import KernelFinalActions
import KernelSelection
import KernelQuotientAnalyticity

/-!
# The actual quotient actions supply the spectral-selection action data

The star structures and actions are constructed. The only symmetry input is
finite-polynomial invariance of the limiting functional, which density extends.
-/

noncomputable section
namespace SYK.KernelActionBridge
open SYK.WeightedKernelAlgebra SYK.KernelResidualAlgebra
open SYK.KernelCoordinateGeneration SYK.KernelAlgebraActions SYK.KernelQuotientActions
open SYK.KernelFinalActions SYK.KernelSelection SYK.KernelQuotientAnalyticity SYK.GNS

variable (b K : ℝ) (hb : 0 < b) (hK : 0 < K) (β : ℝ) (hβ : 0 < β) (lam : ℝ)
  [Nontrivial (FirstAlgebra b K hb hK β)]
  [Nontrivial (FinalAlgebra b K hb hK β hβ lam)]

local instance actualStarRing : StarRing (FinalAlgebra b K hb hK β hβ lam) :=
  finalStarRing b K hb hK β hβ lam
local instance actualStarModule : StarModule ℂ (FinalAlgebra b K hb hK β hβ lam) :=
  finalStarModule b K hb hK β hβ lam
local instance actualNormedStarGroup : NormedStarGroup (FinalAlgebra b K hb hK β hβ lam) :=
  finalNormedStarGroup b K hb hK β hβ lam

/-- Polynomial symmetry descends and extends to the final positive state. -/
theorem invariant_of_polynomial (φ : PositiveFunctional (FinalAlgebra b K hb hK β hβ lam))
    (hsym : ∀ u p, φ.map (ResidualQuotient.mk _
      (translatedPolynomial b K hb hK β (thermalCovariance β) u p)) =
      φ.map (ResidualQuotient.mk _
        (polynomialMap b K hb hK (thermalCovariance β) (symmetryRelations β) p)))
    (u : ℝ) (a : FinalAlgebra b K hb hK β hβ lam) :
    φ.map (finalTranslation b K hb hK β hβ lam u a) = φ.map a := by
  let L := φ.map.comp (ResidualQuotient.mkCLM (residuals b K hb hK β hβ.le lam))
  obtain ⟨a, rfl⟩ := Ideal.Quotient.mk_surjective a
  change φ.map (finalTranslation _ _ _ _ _ _ _ _ (ResidualQuotient.mk _ a)) = _
  rw [finalTranslation_mk]
  exact firstFunctional_invariant_of_polynomial b K hb hK β L hsym u a

/-- Every action-data field used by the spectral theorem is now supplied by
the constructed quotient, rather than a model structure assumed as input. -/
def actionData (φ : PositiveFunctional (FinalAlgebra b K hb hK β hβ lam))
    (hsym : ∀ u p, φ.map (ResidualQuotient.mk _
      (translatedPolynomial b K hb hK β (thermalCovariance β) u p)) =
      φ.map (ResidualQuotient.mk _
        (polynomialMap b K hb hK (thermalCovariance β) (symmetryRelations β) p))) :
    KernelActionData φ β
      (thermalFinalKernel b K hb hK β hβ (lam : ℂ) (symmetryRelations β)) where
  translation := finalTranslation b K hb hK β hβ lam
  zero := finalTranslation_zero b K hb hK β hβ lam
  add u v a := (finalTranslation_add b K hb hK β hβ lam u v a).symm
  invariant := invariant_of_polynomial b K hb hK β hβ lam φ hsym
  reversal := finalReflection_translation b K hb hK β hβ lam
  isometric u a := (AddMonoidHomClass.isometry_iff_norm _).mp
    (finalTranslation_isometry b K hb hK β hβ lam u) a
  coordinate u s t := finalTranslation_coordinate b K hb hK β hβ lam u (s,t)
  reflected s t := finalReflection_coordinate b K hb hK β hβ lam (s,t)

end SYK.KernelActionBridge
