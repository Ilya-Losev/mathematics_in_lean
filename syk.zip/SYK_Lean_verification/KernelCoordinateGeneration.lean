import KernelResidualAlgebra
import KernelSDDifferentiation

/-!
# Exact coordinate symmetries and coordinate generation of the quotient

The formal increment generators are eliminated using their imposed relations.
Closed subalgebras containing the bilocals therefore contain the whole algebra.
-/

noncomputable section
namespace SYK.KernelCoordinateGeneration
open SYK.WeightedKernelAlgebra SYK.KernelResidualAlgebra
open MeasureTheory

/-- All the additional first-quotient relations in Section 6. -/
inductive SymmetryIndex
  | skew (p : Endpoint)
  | antiperiodicLeft (p : Endpoint)
  | antiperiodicRight (p : Endpoint)
  | diagonal (t : ℝ)

/-- The canonical skew, antiperiodic and zero-diagonal polynomials. -/
def symmetryRelations (β : ℝ) : SymmetryIndex → MvPolynomial KernelIndex ℂ
  | .skew p => MvPolynomial.X (.inl (p.2,p.1)) + MvPolynomial.X (.inl p)
  | .antiperiodicLeft p => MvPolynomial.X (.inl (p.1+β,p.2)) + MvPolynomial.X (.inl p)
  | .antiperiodicRight p => MvPolynomial.X (.inl (p.1,p.2+β)) + MvPolynomial.X (.inl p)
  | .diagonal t => MvPolynomial.X (.inl (t,t))

section FirstQuotient
variable {J : Type*} (b K : ℝ) (hb : 0 < b) (hK : 0 < K)
  (C₀ : Endpoint → ℂ) (extra : J → MvPolynomial KernelIndex ℂ)

def polynomialMap : MvPolynomial KernelIndex ℂ →ₐ[ℂ] RegularityAlgebra b K hb hK C₀ extra :=
  (RelationQuotient.mk _ _).comp (WeightedAlgebra.ofPolynomialAlgHom _)

@[simp] theorem polynomialMap_coordinate (p : Endpoint) :
    polynomialMap b K hb hK C₀ extra (MvPolynomial.X (.inl p)) =
      coordinate b K hb hK C₀ extra p := rfl

@[simp] theorem polynomialMap_increment (pq : IncrementIndex) :
    polynomialMap b K hb hK C₀ extra (MvPolynomial.X (.inr pq)) =
      increment b K hb hK C₀ extra pq := rfl

/-- All increment generators belong to every subalgebra containing the bilocals. -/
theorem increments_mem_of_coordinates (S : Subalgebra ℂ (RegularityAlgebra b K hb hK C₀ extra))
    (hS : ∀ p, coordinate b K hb hK C₀ extra p ∈ S) (pq : IncrementIndex) :
    increment b K hb hK C₀ extra pq ∈ S := by
  rw [increment_eq_remainder_sub]
  exact S.sub_mem (S.sub_mem (hS _) (S.algebraMap_mem _))
    (S.sub_mem (hS _) (S.algebraMap_mem _))

/-- Exact generation by coordinate polynomials after the increment relations. -/
theorem polynomials_mem_of_coordinates (S : Subalgebra ℂ (RegularityAlgebra b K hb hK C₀ extra))
    (hS : ∀ p, coordinate b K hb hK C₀ extra p ∈ S) (p : MvPolynomial KernelIndex ℂ) :
    polynomialMap b K hb hK C₀ extra p ∈ S := by
  induction p using MvPolynomial.induction_on with
  | C c => simpa only [← MvPolynomial.algebraMap_eq, AlgHom.commutes] using S.algebraMap_mem c
  | add p q hp hq => simpa only [map_add] using S.add_mem hp hq
  | mul_X p i hp =>
      rw [map_mul]
      apply S.mul_mem hp
      cases i with
      | inl q => exact hS q
      | inr pq => exact increments_mem_of_coordinates b K hb hK C₀ extra S hS pq

/-- Coordinate polynomials are dense in the actual first quotient. -/
theorem closed_subalgebra_eq_top_of_coordinates
    (S : Subalgebra ℂ (RegularityAlgebra b K hb hK C₀ extra)) (hclosed : IsClosed (S : Set (RegularityAlgebra b K hb hK C₀ extra)))
    (hS : ∀ p, coordinate b K hb hK C₀ extra p ∈ S) : S = ⊤ := by
  apply top_unique
  intro a ha
  exact (firstQuotient_polynomials_dense (kernelWeights b K hb hK) (kernelRelations C₀ extra)).induction_on a
    hclosed (polynomials_mem_of_coordinates b K hb hK C₀ extra S hS)

end FirstQuotient

section CanonicalSymmetries
variable (b K : ℝ) (hb : 0 < b) (hK : 0 < K) (C₀ : Endpoint → ℂ) (β : ℝ)

theorem coordinate_skew (s t : ℝ) :
    coordinate b K hb hK C₀ (symmetryRelations β) (t,s) =
      -coordinate b K hb hK C₀ (symmetryRelations β) (s,t) := by
  have hh := extra_relation_eq_zero b K hb hK C₀ (symmetryRelations β) (.skew (s,t))
  change polynomialMap b K hb hK C₀ (symmetryRelations β)
    (MvPolynomial.X (.inl (t,s)) + MvPolynomial.X (.inl (s,t))) = 0 at hh
  simpa only [map_add, polynomialMap_coordinate, eq_neg_iff_add_eq_zero] using hh

theorem coordinate_antiperiodic_left (s t : ℝ) :
    coordinate b K hb hK C₀ (symmetryRelations β) (s+β,t) =
      -coordinate b K hb hK C₀ (symmetryRelations β) (s,t) := by
  have hh := extra_relation_eq_zero b K hb hK C₀ (symmetryRelations β) (.antiperiodicLeft (s,t))
  change polynomialMap b K hb hK C₀ (symmetryRelations β)
    (MvPolynomial.X (.inl (s+β,t)) + MvPolynomial.X (.inl (s,t))) = 0 at hh
  simpa only [map_add, polynomialMap_coordinate, eq_neg_iff_add_eq_zero] using hh

theorem coordinate_antiperiodic_right (s t : ℝ) :
    coordinate b K hb hK C₀ (symmetryRelations β) (s,t+β) =
      -coordinate b K hb hK C₀ (symmetryRelations β) (s,t) := by
  have hh := extra_relation_eq_zero b K hb hK C₀ (symmetryRelations β) (.antiperiodicRight (s,t))
  change polynomialMap b K hb hK C₀ (symmetryRelations β)
    (MvPolynomial.X (.inl (s,t+β)) + MvPolynomial.X (.inl (s,t))) = 0 at hh
  simpa only [map_add, polynomialMap_coordinate, eq_neg_iff_add_eq_zero] using hh

theorem coordinate_diagonal (t : ℝ) :
    coordinate b K hb hK C₀ (symmetryRelations β) (t,t) = 0 :=
  extra_relation_eq_zero b K hb hK C₀ (symmetryRelations β) (.diagonal t)

end CanonicalSymmetries

section FinalQuotient
variable {J I : Type*} (b K : ℝ) (hb : 0 < b) (hK : 0 < K)
  (C₀ : Endpoint → ℂ) (extra : J → MvPolynomial KernelIndex ℂ)
  (F : I → RegularityAlgebra b K hb hK C₀ extra)

/-- Passing to a second quotient preserves dense generation by bilocals. -/
theorem final_closed_subalgebra_eq_top
    (S : Subalgebra ℂ (ResidualQuotient F)) (hclosed : IsClosed (S : Set (ResidualQuotient F)))
    (hS : ∀ p, ResidualQuotient.mk F (coordinate b K hb hK C₀ extra p) ∈ S) : S = ⊤ := by
  have hpre : S.comap (ResidualQuotient.mk F) = ⊤ :=
    closed_subalgebra_eq_top_of_coordinates b K hb hK C₀ extra _
      (hclosed.preimage (ResidualQuotient.mkCLM F).continuous) hS
  apply top_unique
  intro a ha
  obtain ⟨x, rfl⟩ := Ideal.Quotient.mk_surjective (I := residualIdeal F) a
  have hx : x ∈ S.comap (ResidualQuotient.mk F) := by rw [hpre]; trivial
  exact hx

end FinalQuotient

section FinalSymmetries
variable (b K : ℝ) (hb : 0 < b) (hK : 0 < K) (C₀ : Endpoint → ℂ) (β : ℝ)
  [Nontrivial (RegularityAlgebra b K hb hK C₀ (symmetryRelations β))]
  (hβ : 0 ≤ β) (lam : ℂ) (hC : StronglyMeasurable C₀) (B : ℝ) (hB : ∀ p, ‖C₀ p‖ ≤ B)
  [Nontrivial (SchwingerDysonAlgebra b K hb hK C₀ (symmetryRelations β) β hβ lam hC B hB)]

theorem finalKernel_antiperiodic : KernelAntiperiodic β
    (finalKernel b K hb hK C₀ (symmetryRelations β) β hβ lam hC B hB) := by
  constructor
  · intro s t
    change ResidualQuotient.mk _ (coordinate _ _ _ _ _ _ (s+β,t)) = -_
    rw [coordinate_antiperiodic_left, map_neg]
    rfl
  · intro s t
    change ResidualQuotient.mk _ (coordinate _ _ _ _ _ _ (s,t+β)) = -_
    rw [coordinate_antiperiodic_right, map_neg]
    rfl

theorem finalKernel_skew (s t : ℝ) :
    finalKernel b K hb hK C₀ (symmetryRelations β) β hβ lam hC B hB (t,s) =
      -finalKernel b K hb hK C₀ (symmetryRelations β) β hβ lam hC B hB (s,t) := by
  change ResidualQuotient.mk _ (coordinate _ _ _ _ _ _ (t,s)) = -_
  rw [coordinate_skew, map_neg]
  rfl

theorem finalKernel_diagonal (t : ℝ) :
    finalKernel b K hb hK C₀ (symmetryRelations β) β hβ lam hC B hB (t,t) = 0 := by
  change ResidualQuotient.mk _ (coordinate _ _ _ _ _ _ (t,t)) = 0
  rw [coordinate_diagonal, map_zero]

end FinalSymmetries
end SYK.KernelCoordinateGeneration
