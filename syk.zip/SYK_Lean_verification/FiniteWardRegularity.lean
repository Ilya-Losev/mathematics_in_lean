import InsertedWardReplacements
import CoordinateTelescoping

set_option maxHeartbeats 1200000

noncomputable section
open MeasureTheory Set Filter
open scoped Topology
namespace SYK.MixedIncrement
open WeightedKernelAlgebra MvPolynomial

def remainderProduct (β : ℝ) (p : List Endpoint) : Polynomial :=
  (p.map (remainder β)).prod

@[simp] theorem remainderProduct_nil (β : ℝ) : remainderProduct β []=1 := rfl
@[simp] theorem remainderProduct_cons (β : ℝ) (p : Endpoint) (l) :
    remainderProduct β (p::l)=remainder β p*remainderProduct β l := rfl

theorem coefficientNorm_remainder_le (β : ℝ) (p : Endpoint) :
    coefficientNorm (fun _ => (1/2:ℝ)) (remainder β p) ≤ 1 := by
  have h := coefficientNorm_add_le (fun _ : Endpoint => (1/2:ℝ)) (fun _ => by norm_num)
    (X p) (-C (Thermal.kernel β p.1 p.2:ℂ))
  unfold remainder
  rw [sub_eq_add_neg]
  apply h.trans
  rw [coefficientNorm_neg]
  have hx : coefficientNorm (fun _ : Endpoint => (1/2:ℝ)) (X p) = 1/2 := by
    change coefficientNorm (fun _ : Endpoint => (1/2:ℝ)) (monomial (Finsupp.single p 1) (1:ℂ)) = 1/2
    rw [coefficientNorm_monomial,monomialWeight_single]
    norm_num
  have hc : coefficientNorm (fun _ : Endpoint => (1/2:ℝ)) (C (Thermal.kernel β p.1 p.2:ℂ)) ≤ 1/2 := by
    change coefficientNorm (fun _ : Endpoint => (1/2:ℝ)) (monomial 0 (Thermal.kernel β p.1 p.2:ℂ)) ≤ 1/2
    rw [coefficientNorm_monomial,monomialWeight_zero,mul_one,Complex.norm_real,Real.norm_eq_abs]
    exact Thermal.abs_covariance_le β _
  linarith

theorem coefficientNorm_remainderProduct_le (β : ℝ) (p : List Endpoint) :
    coefficientNorm (fun _ => (1/2:ℝ)) (remainderProduct β p) ≤ 1 := by
  induction p with
  | nil =>
    change coefficientNorm (fun _ : Endpoint => (1/2:ℝ)) (monomial 0 (1:ℂ)) ≤ 1
    rw [coefficientNorm_monomial,monomialWeight_zero]
    norm_num
  | cons a p ih =>
    rw [remainderProduct_cons]
    apply (coefficientNorm_mul_le (fun _ => (1/2:ℝ)) (fun _ => by norm_num) _ _).trans
    have hn := coefficientNorm_nonneg (fun _ : Endpoint => (1/2:ℝ)) (fun _ => by norm_num)
      (remainderProduct β p)
    exact (mul_le_mul (coefficientNorm_remainder_le β a) ih hn (by norm_num)).trans_eq (one_mul 1)

/-- Subtracting the genuine finite inserted Ward equation gives its explicit
endpoint modulus, including the finite-size contact defect. -/
theorem finite_ward_left_modulus (β lam : ℝ) (hβ : 0 < β) (hlam : 0 ≤ lam)
    (L : Polynomial →ₗ[ℂ] ℂ)
    (hbound : ∀ P, ‖L P‖ ≤ coefficientNorm (fun _ => (1/2:ℝ)) P)
    (Q : Polynomial) (hQ : coefficientNorm (fun _ => (1/2:ℝ)) Q ≤ 1)
    (E : ℝ → ℝ → ℂ) (ε : ℝ) (hE : ∀ s t, ‖E s t‖ ≤ ε)
    (hm : ∀ t, Measurable (fun p : ℝ×ℝ =>
      L (Q*coordinateProduct [(p.1,p.2),(p.1,p.2),(p.1,p.2),(p.2,t)])))
    (hWard : ∀ s t, L (Q*remainder β (s,t)) =
      (lam:ℂ)*(∫ u in (0:ℝ)..β, ∫ v in (0:ℝ)..β,
        (Thermal.kernel β s u:ℂ)*L (Q*coordinateProduct [(u,v),(u,v),(u,v),(v,t)])) + E s t)
    (s s' t : ℝ) :
    ‖L (Q*(remainder β (s,t)-remainder β (s',t)))‖ ≤
      (lam*β/16)*|s-s'|+2*ε := by
  have hb (u v) : ‖L (Q*coordinateProduct [(u,v),(u,v),(u,v),(v,t)])‖ ≤ (1/16:ℝ) :=
    (inserted_four_bound L hbound Q _ rfl).trans (by linarith)
  have he := covariance_double_difference_left β hβ.le s s'
    (fun u v => L (Q*coordinateProduct [(u,v),(u,v),(u,v),(v,t)])) (hm t) (1/16) hb
  rw [mul_sub,map_sub,hWard,hWard]
  have hsplit (a b e f : ℂ) : (lam:ℂ)*a+e-((lam:ℂ)*b+f)=(lam:ℂ)*(a-b)+(e-f) := by ring
  rw [hsplit,he]
  have hi := double_left_bound β hβ s s'
    (fun u v => L (Q*coordinateProduct [(u,v),(u,v),(u,v),(v,t)])) (1/16) (by norm_num) hb
  have hc : ‖E s t-E s' t‖ ≤ 2*ε := (norm_sub_le _ _).trans (by linarith [hE s t,hE s' t])
  calc
    _ ≤ ‖(lam:ℂ)*(∫ u in (0:ℝ)..β, ∫ v in (0:ℝ)..β,
      ((Thermal.kernel β s u-Thermal.kernel β s' u):ℂ)*
        L (Q*coordinateProduct [(u,v),(u,v),(u,v),(v,t)]))‖ + ‖E s t-E s' t‖ := norm_add_le _ _
    _ ≤ lam*(β*(1/16)*|s-s'|)+2*ε := by
      rw [norm_mul,Complex.norm_real,Real.norm_eq_abs,abs_of_nonneg hlam]
      exact add_le_add (mul_le_mul_of_nonneg_left hi hlam) hc
    _ = _ := by ring

/-- Skewness converts the proved first-endpoint modulus to the other endpoint
and then controls arbitrary pairs by their ℓ¹ displacement. -/
theorem endpoint_modulus_of_left (β : ℝ) (L : Polynomial →ₗ[ℂ] ℂ) (Q : Polynomial)
    (K ε : ℝ)
    (hskew : ∀ s t, L (Q*remainder β (s,t)) = -L (Q*remainder β (t,s)))
    (hleft : ∀ s s' t, ‖L (Q*(remainder β (s,t)-remainder β (s',t)))‖ ≤ K*|s-s'|+ε)
    (p q : Endpoint) :
    ‖L (Q*(remainder β p-remainder β q))‖ ≤ K*endpointDistance p q+2*ε := by
  have hright (s t t') :
      ‖L (Q*(remainder β (s,t)-remainder β (s,t')))‖ ≤ K*|t-t'|+ε := by
    have he : L (Q*(remainder β (s,t)-remainder β (s,t'))) =
        -L (Q*(remainder β (t,s)-remainder β (t',s))) := by
      simp only [mul_sub,map_sub,hskew s t,hskew s t']
      ring
    rw [he,norm_neg]
    exact hleft t t' s
  have he : Q*(remainder β p-remainder β q) =
      Q*(remainder β (p.1,p.2)-remainder β (q.1,p.2)) +
      Q*(remainder β (q.1,p.2)-remainder β (q.1,q.2)) := by
    simp only [Prod.eta]
    ring
  rw [he,map_add]
  apply (norm_add_le _ _).trans
  have h := add_le_add (hleft p.1 q.1 p.2) (hright q.1 p.2 q.2)
  exact h.trans_eq (by unfold endpointDistance; ring)

theorem endpointDistance_le_two_dist (p q : Endpoint) :
    endpointDistance p q ≤ 2*dist p q := by
  change |p.1-q.1|+|p.2-q.2| ≤ 2*max (dist p.1 q.1) (dist p.2 q.2)
  rw [Real.dist_eq,Real.dist_eq]
  linarith [le_max_left |p.1-q.1| |p.2-q.2|,le_max_right |p.1-q.1| |p.2-q.2|]

theorem remainderProduct_ofFn {k : ℕ} (β : ℝ) (p : Fin k → Endpoint) :
    remainderProduct β (List.ofFn p) = ∏ i, remainder β (p i) := by
  simp [remainderProduct,List.map_ofFn,List.prod_ofFn]

/-- The exact tuple modulus needed for asymptotic compactness follows by
changing one bilocal at a time. The coefficient scales with degree, not with N. -/
theorem remainder_tuple_modulus (β : ℝ) (L : Polynomial →ₗ[ℂ] ℂ)
    (k : ℕ) (K ε : ℝ) (hK : 0 ≤ K)
    (hpair : ∀ (l : List Endpoint), l.length+1=k → ∀ p q,
      ‖L (remainderProduct β l*(remainder β p-remainder β q))‖ ≤
        K*endpointDistance p q+ε)
    (p q : Fin k → Endpoint) :
    ‖L (∏ i, remainder β (p i))-L (∏ i, remainder β (q i))‖ ≤
      (k:ℝ)*(2*K)*dist p q+(k:ℝ)*ε := by
  apply coordinate_defect_max_bound k (fun p => L (∏ i, remainder β (p i))) (2*K) ε (by positivity)
  intro p q i hpq
  cases k with
  | zero => exact Fin.elim0 i
  | succ n =>
    let l := List.ofFn (fun j : Fin n => p (i.succAbove j))
    have hl : l.length+1=n+1 := by simp [l]
    have hprod : (∏ j : Fin n, remainder β (p (i.succAbove j))) =
        ∏ j : Fin n, remainder β (q (i.succAbove j)) := by
      apply Finset.prod_congr rfl
      intro j _
      rw [hpq (i.succAbove j) (Fin.succAbove_ne i j)]
    have hco : remainderProduct β l = ∏ j : Fin n, remainder β (p (i.succAbove j)) :=
      remainderProduct_ofFn β _
    have he : L (∏ j, remainder β (p j))-L (∏ j, remainder β (q j)) =
        L (remainderProduct β l*(remainder β (p i)-remainder β (q i))) := by
      rw [Fin.prod_univ_succAbove (fun j => remainder β (p j)) i,
        Fin.prod_univ_succAbove (fun j => remainder β (q j)) i, ← hprod, ← hco, ← map_sub]
      congr 1
      ring
    rw [he]
    apply (hpair l hl (p i) (q i)).trans
    have hd := mul_le_mul_of_nonneg_left (endpointDistance_le_two_dist (p i) (q i)) hK
    linarith

/-- With the actual inverse-dimension contact bound, the full centered
k-point family has a vanishing-defect modulus. This is the precise numerical
estimate required by simultaneous compactness at fixed coupling. -/
theorem finite_centered_tuple_modulus (β lam : ℝ) (hβ : 0 < β) (hlam : 0 ≤ lam)
    (d : ℕ) (L : Polynomial →ₗ[ℂ] ℂ)
    (hbound : ∀ P, ‖L P‖ ≤ coefficientNorm (fun _ => (1/2:ℝ)) P)
    (E : List Endpoint → ℝ → ℝ → ℂ)
    (hE : ∀ l s t, ‖E l s t‖ ≤ (l.length:ℝ)/(4*d))
    (hm : ∀ l t, Measurable (fun p : ℝ×ℝ =>
      L (remainderProduct β l*coordinateProduct [(p.1,p.2),(p.1,p.2),(p.1,p.2),(p.2,t)])))
    (hWard : ∀ l s t, L (remainderProduct β l*remainder β (s,t)) =
      (lam:ℂ)*(∫ u in (0:ℝ)..β, ∫ v in (0:ℝ)..β,
        (Thermal.kernel β s u:ℂ)*L (remainderProduct β l*
          coordinateProduct [(u,v),(u,v),(u,v),(v,t)])) + E l s t)
    (hskew : ∀ l s t, L (remainderProduct β l*remainder β (s,t)) =
      -L (remainderProduct β l*remainder β (t,s)))
    (k : ℕ) (p q : Fin k → Endpoint) :
    ‖L (∏ i, remainder β (p i))-L (∏ i, remainder β (q i))‖ ≤
      ((k:ℝ)*lam*β/8)*dist p q+((k:ℝ)*((k-1:ℕ):ℝ))/(d:ℝ) := by
  have hpairs : ∀ (l : List Endpoint), l.length+1=k → ∀ p q,
      ‖L (remainderProduct β l*(remainder β p-remainder β q))‖ ≤
        (lam*β/16)*endpointDistance p q+((k-1:ℕ):ℝ)/(d:ℝ) := by
    intro l hl p q
    have hleft := finite_ward_left_modulus β lam hβ hlam L hbound (remainderProduct β l)
      (coefficientNorm_remainderProduct_le β l) (E l) ((l.length:ℝ)/(4*d))
      (hE l) (hm l) (hWard l)
    have h := endpoint_modulus_of_left β L (remainderProduct β l) (lam*β/16)
      (2*((l.length:ℝ)/(4*d))) (hskew l) hleft p q
    have hlen : l.length=k-1 := by omega
    rw [hlen] at h
    convert h using 1
    ring
  have h := remainder_tuple_modulus β L k (lam*β/16) (((k-1:ℕ):ℝ)/(d:ℝ))
    (by positivity) hpairs p q
  convert h using 1
  ring

end SYK.MixedIncrement
