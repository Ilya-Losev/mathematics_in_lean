import Mathlib.Data.Matrix.Kronecker
import Mathlib.Analysis.CStarAlgebra.CStarMatrix
import Mathlib.Data.Finset.Sort
import Mathlib.Analysis.Normed.Algebra.Exponential
import Mathlib.Analysis.SpecialFunctions.Exponential
import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Tactic

/-!
# Concrete finite-dimensional Majorana matrices

This file constructs the matrices in Section 2 of the supplied SYK draft from
Pauli matrices. The anticommutation relations are proved from the entries;
they are not assumptions on an unspecified model. The construction has 2m
flavors and matrix dimension 2^m. This file does not formalize the continuum
limit or the irreducibility claim.
-/

noncomputable section
open scoped BigOperators Kronecker Matrix ComplexOrder
namespace SYK.Majorana

/-- A recursive basis for m qubits. -/
def Basis : ℕ → Type
  | 0 => Unit
  | n + 1 => Fin 2 × Basis n

/-- Two new flavors are added at every recursion step. -/
def Flavor : ℕ → Type
  | 0 => Empty
  | n + 1 => Bool ⊕ Flavor n

instance basisFintype (n : ℕ) : Fintype (Basis n) := by
  induction n with
  | zero => exact inferInstanceAs (Fintype Unit)
  | succ n ih =>
    letI := ih
    exact inferInstanceAs (Fintype (Fin 2 × Basis n))

instance flavorFintype (n : ℕ) : Fintype (Flavor n) := by
  induction n with
  | zero => exact inferInstanceAs (Fintype Empty)
  | succ n ih =>
    letI := ih
    exact inferInstanceAs (Fintype (Bool ⊕ Flavor n))

instance basisDecidableEq : (n : ℕ) → DecidableEq (Basis n)
  | 0 => inferInstanceAs (DecidableEq Unit)
  | n + 1 => by
    letI := basisDecidableEq n
    exact inferInstanceAs (DecidableEq (Fin 2 × Basis n))
instance flavorDecidableEq (n : ℕ) : DecidableEq (Flavor n) := Classical.decEq _

instance basisNonempty (n : ℕ) : Nonempty (Basis n) := by
  induction n with
  | zero => exact ⟨()⟩
  | succ n ih =>
    rcases ih with ⟨x⟩
    exact ⟨(0, x)⟩

@[simp] theorem card_basis (n : ℕ) : Fintype.card (Basis n) = 2 ^ n := by
  induction n with
  | zero => rfl
  | succ n ih =>
    change Fintype.card (Fin 2 × Basis n) = _
    simp [ih, pow_succ, Nat.mul_comm]

@[simp] theorem card_flavor (n : ℕ) : Fintype.card (Flavor n) = 2 * n := by
  induction n with
  | zero => rfl
  | succ n ih =>
    change Fintype.card (Bool ⊕ Flavor n) = _
    simp [ih, Nat.mul_add, Nat.add_comm]

def pauliX : Matrix (Fin 2) (Fin 2) ℂ := !![0, 1; 1, 0]
def pauliY : Matrix (Fin 2) (Fin 2) ℂ := !![0, -Complex.I; Complex.I, 0]
def pauliZ : Matrix (Fin 2) (Fin 2) ℂ := !![1, 0; 0, -1]
def pauli : Bool → Matrix (Fin 2) (Fin 2) ℂ
  | false => pauliX
  | true => pauliY

@[simp] theorem pauli_square (b : Bool) : pauli b * pauli b = 1 := by
  cases b <;> ext i j <;> fin_cases i <;> fin_cases j <;>
    simp [pauli, pauliX, pauliY, Matrix.mul_apply, Fin.sum_univ_two, Complex.I_mul_I]

@[simp] theorem pauliZ_square : pauliZ * pauliZ = 1 := by
  ext i j; fin_cases i <;> fin_cases j <;>
    simp [pauliZ, Matrix.mul_apply, Fin.sum_univ_two]

@[simp] theorem pauli_star (b : Bool) : star (pauli b) = pauli b := by
  cases b <;> ext i j <;> fin_cases i <;> fin_cases j <;>
    simp [pauli, pauliX, pauliY, Matrix.star_apply]

@[simp] theorem pauliZ_star : star pauliZ = pauliZ := by
  ext i j; fin_cases i <;> fin_cases j <;> simp [pauliZ, Matrix.star_apply]

theorem pauli_anticommute (a b : Bool) (h : a ≠ b) :
    pauli a * pauli b = -(pauli b * pauli a) := by
  cases a <;> cases b <;> try contradiction
  all_goals
    ext i j; fin_cases i <;> fin_cases j <;>
      simp [pauli, pauliX, pauliY, Matrix.mul_apply, Fin.sum_univ_two]

theorem pauli_Z_anticommute (b : Bool) :
    pauli b * pauliZ = -(pauliZ * pauli b) := by
  cases b <;> ext i j <;> fin_cases i <;> fin_cases j <;>
    simp [pauli, pauliX, pauliY, pauliZ, Matrix.mul_apply, Fin.sum_univ_two]

private theorem neg_kron {m n : Type*}
    (A : Matrix m m ℂ) (B : Matrix n n ℂ) : (-A) ⊗ₖ B = -(A ⊗ₖ B) := by
  ext i j
  exact neg_mul _ _

private theorem kron_neg {m n : Type*}
    (A : Matrix m m ℂ) (B : Matrix n n ℂ) : A ⊗ₖ (-B) = -(A ⊗ₖ B) := by
  ext i j
  exact mul_neg _ _

private theorem star_kron {m n : Type*}
    (A : Matrix m m ℂ) (B : Matrix n n ℂ) :
    star (A ⊗ₖ B) = (star A) ⊗ₖ (star B) := by
  ext i j
  simp [Matrix.star_apply, Matrix.kroneckerMap_apply, star_mul, mul_comm]

/-- Unnormalized Clifford generators, of square one, constructed explicitly. -/
def gamma : (n : ℕ) → Flavor n → Matrix (Basis n) (Basis n) ℂ
  | 0, i => Empty.elim i
  | n + 1, Sum.inl b => pauli b ⊗ₖ (1 : Matrix (Basis n) (Basis n) ℂ)
  | n + 1, Sum.inr i => pauliZ ⊗ₖ gamma n i

@[simp] theorem gamma_square (n : ℕ) (i : Flavor n) : gamma n i * gamma n i = 1 := by
  induction n with
  | zero => exact Empty.elim i
  | succ n ih =>
    cases i with
    | inl b =>
      change (pauli b ⊗ₖ (1 : Matrix (Basis n) (Basis n) ℂ)) * (pauli b ⊗ₖ 1) = 1
      rw [← Matrix.mul_kronecker_mul]
      simp [Matrix.one_kronecker_one]
    | inr i =>
      change (pauliZ ⊗ₖ gamma n i) * (pauliZ ⊗ₖ gamma n i) = 1
      rw [← Matrix.mul_kronecker_mul]
      simp [ih, Matrix.one_kronecker_one]

@[simp] theorem gamma_star (n : ℕ) (i : Flavor n) : star (gamma n i) = gamma n i := by
  induction n with
  | zero => exact Empty.elim i
  | succ n ih =>
    cases i with
    | inl b =>
      change star (pauli b ⊗ₖ (1 : Matrix (Basis n) (Basis n) ℂ)) = _
      rw [star_kron]
      simp [gamma]
    | inr i =>
      change star (pauliZ ⊗ₖ gamma n i) = _
      rw [star_kron]
      simp [gamma, ih]

theorem gamma_anticommute (n : ℕ) (i j : Flavor n) (h : i ≠ j) :
    gamma n i * gamma n j = -(gamma n j * gamma n i) := by
  induction n with
  | zero => exact Empty.elim i
  | succ n ih =>
    cases i with
    | inl a =>
      cases j with
      | inl b =>
        have hab : a ≠ b := fun e => h (congrArg Sum.inl e)
        change (pauli a ⊗ₖ (1 : Matrix (Basis n) (Basis n) ℂ)) * (pauli b ⊗ₖ 1) =
          -((pauli b ⊗ₖ 1) * (pauli a ⊗ₖ 1))
        rw [← Matrix.mul_kronecker_mul, ← Matrix.mul_kronecker_mul, pauli_anticommute a b hab, neg_kron]
      | inr j =>
        change (pauli a ⊗ₖ (1 : Matrix (Basis n) (Basis n) ℂ)) * (pauliZ ⊗ₖ gamma n j) =
          -((pauliZ ⊗ₖ gamma n j) * (pauli a ⊗ₖ 1))
        simp [← Matrix.mul_kronecker_mul, pauli_Z_anticommute, neg_kron]
    | inr i =>
      cases j with
      | inl b =>
        have hp := pauli_Z_anticommute b
        have hp' : pauliZ * pauli b = -(pauli b * pauliZ) := by rw [hp, neg_neg]
        change (pauliZ ⊗ₖ gamma n i) * (pauli b ⊗ₖ (1 : Matrix (Basis n) (Basis n) ℂ)) =
          -((pauli b ⊗ₖ 1) * (pauliZ ⊗ₖ gamma n i))
        simp [← Matrix.mul_kronecker_mul, hp', neg_kron]
      | inr j =>
        have hij : i ≠ j := fun e => h (congrArg Sum.inr e)
        change (pauliZ ⊗ₖ gamma n i) * (pauliZ ⊗ₖ gamma n j) =
          -((pauliZ ⊗ₖ gamma n j) * (pauliZ ⊗ₖ gamma n i))
        simp [← Matrix.mul_kronecker_mul, ih i j hij, kron_neg]

/-- The factor converting Clifford generators to the paper's CAR convention. -/
def normalization : ℝ := (Real.sqrt 2)⁻¹

@[simp] theorem normalization_square : normalization * normalization = (1 / 2 : ℝ) := by
  have hs := Real.sq_sqrt (show (0 : ℝ) ≤ 2 by norm_num)
  dsimp [normalization]
  rw [← mul_inv_rev, ← pow_two, hs]
  norm_num

/-- The concrete normalized Majorana matrices. -/
def chi (n : ℕ) (i : Flavor n) : Matrix (Basis n) (Basis n) ℂ :=
  normalization • gamma n i

@[simp] theorem chi_star (n : ℕ) (i : Flavor n) : star (chi n i) = chi n i := by
  simp [chi, star_smul]

@[simp] theorem chi_square (n : ℕ) (i : Flavor n) :
    chi n i * chi n i = (1 / 2 : ℝ) • (1 : Matrix (Basis n) (Basis n) ℂ) := by
  simp [chi, smul_mul_assoc, mul_smul_comm, smul_smul]

theorem chi_anticommute (n : ℕ) (i j : Flavor n) (h : i ≠ j) :
    chi n i * chi n j = -(chi n j * chi n i) := by
  simp [chi, smul_mul_assoc, mul_smul_comm, gamma_anticommute n i j h]

/-- The exact CAR normalization used by the finite-N SYK model. -/
theorem chi_car (n : ℕ) (i j : Flavor n) :
    chi n i * chi n j + chi n j * chi n i =
      if i = j then 1 else 0 := by
  split_ifs with h
  · subst j
    rw [chi_square, ← add_smul]
    norm_num
  · rw [chi_anticommute n i j h, neg_add_cancel]

@[simp] theorem trace_gamma (n : ℕ) (i : Flavor n) : Matrix.trace (gamma n i) = 0 := by
  cases n with
  | zero => exact Empty.elim i
  | succ n =>
    cases i with
    | inl b =>
      change Matrix.trace (pauli b ⊗ₖ (1 : Matrix (Basis n) (Basis n) ℂ)) = 0
      rw [Matrix.trace_kronecker]
      cases b <;> simp [pauli, pauliX, pauliY,
        Matrix.trace, Matrix.diag, Fin.sum_univ_two]
    | inr i =>
      change Matrix.trace (pauliZ ⊗ₖ gamma n i) = 0
      rw [Matrix.trace_kronecker]
      simp [pauliZ, Matrix.trace, Matrix.diag,
        Fin.sum_univ_two]

@[simp] theorem trace_chi (n : ℕ) (i : Flavor n) : Matrix.trace (chi n i) = 0 := by
  simp [chi, Matrix.trace_smul]

/-- The ordinary two-point Clifford trace, derived from the constructed CAR. -/
theorem trace_chi_mul (n : ℕ) (i j : Flavor n) :
    Matrix.trace (chi n i * chi n j) = if i = j then (2 : ℂ) ^ n / 2 else 0 := by
  split_ifs with h
  · subst j
    rw [chi_square, Matrix.trace_smul, Matrix.trace_one, card_basis]
    simp [smul_eq_mul]
    ring
  · have ht := congrArg Matrix.trace (chi_anticommute n i j h)
    rw [Matrix.trace_neg, Matrix.trace_mul_comm (chi n j)] at ht
    exact CharZero.eq_neg_self_iff.mp ht

/-- The normalized Clifford trace used for free correlations. -/
def normalizedTrace (n : ℕ) (A : Matrix (Basis n) (Basis n) ℂ) : ℂ :=
  Matrix.trace A / (2 : ℂ) ^ n

@[simp] theorem normalizedTrace_one (n : ℕ) :
    normalizedTrace n (1 : Matrix (Basis n) (Basis n) ℂ) = 1 := by
  simp [normalizedTrace, Matrix.trace_one]

theorem normalizedTrace_chi_mul (n : ℕ) (i j : Flavor n) :
    normalizedTrace n (chi n i * chi n j) = if i = j then (1 / 2 : ℂ) else 0 := by
  rw [normalizedTrace, trace_chi_mul]
  split_ifs <;> field_simp <;> ring

/-- Convert the recursively presented flavors to the usual finite index set. -/
def flavorEquivFin (n : ℕ) : Flavor n ≃ Fin (2 * n) :=
  Fintype.equivFinOfCardEq (card_flavor n)

def chiFin (n : ℕ) (i : Fin (2 * n)) : Matrix (Basis n) (Basis n) ℂ :=
  chi n ((flavorEquivFin n).symm i)

@[simp] theorem chiFin_star (n : ℕ) (i : Fin (2 * n)) :
    star (chiFin n i) = chiFin n i := chi_star _ _

@[simp] theorem chiFin_square (n : ℕ) (i : Fin (2 * n)) :
    chiFin n i * chiFin n i = (1 / 2 : ℝ) • (1 : Matrix (Basis n) (Basis n) ℂ) :=
  chi_square _ _

theorem chiFin_anticommute (n : ℕ) (i j : Fin (2 * n)) (h : i ≠ j) :
    chiFin n i * chiFin n j = -(chiFin n j * chiFin n i) :=
  chi_anticommute _ _ _ (fun e => h ((flavorEquivFin n).symm.injective e))

theorem chiFin_car (n : ℕ) (i j : Fin (2 * n)) :
    chiFin n i * chiFin n j + chiFin n j * chiFin n i =
      if i = j then 1 else 0 := by
  simpa [chiFin] using chi_car n ((flavorEquivFin n).symm i) ((flavorEquivFin n).symm j)

/-- The increasing four-sets used for independent SYK couplings. -/
def FourSet (n : ℕ) := { I : Finset (Fin (2 * n)) // I.card = 4 }

instance fourSetFintype (n : ℕ) : Fintype (FourSet n) := by
  unfold FourSet
  exact Fintype.ofFinite _

/-- Increasing enumeration of a four-set. -/
def fourIndex (n : ℕ) (I : FourSet n) : Fin 4 ↪o Fin (2 * n) :=
  I.val.orderEmbOfFin I.property

/-- The ordered quartic Majorana operator. -/
def quartic (n : ℕ) (I : FourSet n) : Matrix (Basis n) (Basis n) ℂ :=
  chiFin n (fourIndex n I 0) * chiFin n (fourIndex n I 1) *
  chiFin n (fourIndex n I 2) * chiFin n (fourIndex n I 3)

private theorem reverse_four {R : Type*} [Ring R] (a b c d : R)
    (hba : b * a = -(a * b)) (hca : c * a = -(a * c))
    (hda : d * a = -(a * d)) (hcb : c * b = -(b * c))
    (hdb : d * b = -(b * d)) (hdc : d * c = -(c * d)) :
    d * (c * (b * a)) = a * b * c * d := by
  have swap (x y z : R) (h : x * y = -(y * x)) :
      x * (y * z) = -(y * (x * z)) := by
    rw [← mul_assoc, h]
    noncomm_ring
  calc
    d * (c * (b * a)) = -(c * (d * (b * a))) := swap d c _ hdc
    _ = c * (b * (d * a)) := by rw [swap d b a hdb]; noncomm_ring
    _ = -(c * (b * (a * d))) := by rw [hda]; noncomm_ring
    _ = b * (c * (a * d)) := by rw [swap c b (a * d) hcb]; simp
    _ = -(b * (a * (c * d))) := by rw [swap c a d hca]; noncomm_ring
    _ = a * b * c * d := by rw [swap b a (c * d) hba]; noncomm_ring

@[simp] theorem quartic_star (n : ℕ) (I : FourSet n) :
    star (quartic n I) = quartic n I := by
  let a := fun k => chiFin n (fourIndex n I k)
  have ha (r s : Fin 4) (h : r ≠ s) : a r * a s = -(a s * a r) :=
    chiFin_anticommute n _ _ (fun e => h ((fourIndex n I).injective e))
  simp only [quartic, star_mul, chiFin_star]
  exact reverse_four (a 0) (a 1) (a 2) (a 3)
    (ha 1 0 (by decide)) (ha 2 0 (by decide)) (ha 3 0 (by decide))
    (ha 2 1 (by decide)) (ha 3 1 (by decide)) (ha 3 2 (by decide))

instance matrixNormedSpaceReal (n : ℕ) :
    NormedSpace ℝ (CStarMatrix (Basis n) (Basis n) ℂ) :=
  NormedSpace.restrictScalars ℝ ℂ _

/-- Each unnormalized concrete generator is unitary for the genuine operator norm. -/
theorem gamma_mem_unitary (n : ℕ) (i : Flavor n) :
    CStarMatrix.ofMatrix (gamma n i) ∈
      unitary (CStarMatrix (Basis n) (Basis n) ℂ) := by
  rw [unitary.mem_iff]
  constructor
  · change star (gamma n i) * gamma n i = 1
    simp
  · change gamma n i * star (gamma n i) = 1
    simp

@[simp] theorem norm_gamma (n : ℕ) (i : Flavor n) :
    ‖CStarMatrix.ofMatrix (gamma n i)‖ = 1 :=
  CStarRing.norm_of_mem_unitary (gamma_mem_unitary n i)

/-- The Majorana operator norm, with the paper's normalization. -/
theorem norm_chi (n : ℕ) (i : Flavor n) :
    ‖CStarMatrix.ofMatrix (chi n i)‖ = (Real.sqrt 2)⁻¹ := by
  change ‖normalization • CStarMatrix.ofMatrix (gamma n i)‖ = _
  rw [norm_smul normalization (CStarMatrix.ofMatrix (gamma n i)), norm_gamma, mul_one, Real.norm_eq_abs]
  exact abs_of_nonneg (by dsimp [normalization]; positivity)

def gammaQuartic (n : ℕ) (I : FourSet n) : Matrix (Basis n) (Basis n) ℂ :=
  gamma n ((flavorEquivFin n).symm (fourIndex n I 0)) *
  gamma n ((flavorEquivFin n).symm (fourIndex n I 1)) *
  gamma n ((flavorEquivFin n).symm (fourIndex n I 2)) *
  gamma n ((flavorEquivFin n).symm (fourIndex n I 3))

theorem quartic_eq (n : ℕ) (I : FourSet n) :
    quartic n I = (1 / 4 : ℝ) • gammaQuartic n I := by
  have hn : normalization * normalization * normalization * normalization = (1 / 4 : ℝ) := by
    calc
      _ = (normalization * normalization) * (normalization * normalization) := by ring
      _ = _ := by rw [normalization_square]; norm_num
  simp only [quartic, chiFin, chi, gammaQuartic, smul_mul_assoc, mul_smul_comm, smul_smul]
  rw [← mul_assoc, ← mul_assoc, hn]

/-- Every quartic operator has operator norm exactly one quarter. -/
theorem norm_quartic (n : ℕ) (I : FourSet n) :
    ‖CStarMatrix.ofMatrix (quartic n I)‖ = (1 / 4 : ℝ) := by
  have hu : CStarMatrix.ofMatrix (gammaQuartic n I) ∈
      unitary (CStarMatrix (Basis n) (Basis n) ℂ) := by
    exact (unitary _).mul_mem
      ((unitary _).mul_mem
        ((unitary _).mul_mem (gamma_mem_unitary n _) (gamma_mem_unitary n _))
        (gamma_mem_unitary n _)) (gamma_mem_unitary n _)
  rw [quartic_eq]
  change ‖(1 / 4 : ℝ) • CStarMatrix.ofMatrix (gammaQuartic n I)‖ = _
  rw [norm_smul (1 / 4 : ℝ) (CStarMatrix.ofMatrix (gammaQuartic n I)), CStarRing.norm_of_mem_unitary hu]
  norm_num

/-- The finite-dimensional SYK Hamiltonian for actual real couplings. -/
def hamiltonian (n : ℕ) (j : FourSet n → ℝ) : Matrix (Basis n) (Basis n) ℂ :=
  -∑ I, j I • quartic n I

@[simp] theorem hamiltonian_star (n : ℕ) (j : FourSet n → ℝ) :
    star (hamiltonian n j) = hamiltonian n j := by
  simp [hamiltonian, star_sum, star_smul]

@[simp] theorem hamiltonian_zero (n : ℕ) : hamiltonian n (fun _ => 0) = 0 := by
  simp [hamiltonian]

/-- A deterministic operator bound on the actual finite Hamiltonian. -/
theorem norm_hamiltonian_le (n : ℕ) (j : FourSet n → ℝ) :
    ‖CStarMatrix.ofMatrix (hamiltonian n j)‖ ≤ (∑ I, |j I|) / 4 := by
  change ‖-∑ I, j I • CStarMatrix.ofMatrix (quartic n I)‖ ≤ _
  rw [norm_neg]
  calc
    _ ≤ ∑ I, ‖j I • CStarMatrix.ofMatrix (quartic n I)‖ := norm_sum_le _ _
    _ = ∑ I, |j I| * (1 / 4 : ℝ) := by
      apply Finset.sum_congr rfl
      intro I hI
      rw [norm_smul (j I) (CStarMatrix.ofMatrix (quartic n I)), norm_quartic, Real.norm_eq_abs]
    _ = (∑ I, |j I|) / 4 := by rw [← Finset.sum_mul]; ring

/-- The ordinary trace is bounded by dimension times the operator norm. -/
theorem norm_trace_le (n : ℕ) (A : Matrix (Basis n) (Basis n) ℂ) :
    ‖Matrix.trace A‖ ≤ (2 : ℝ) ^ n * ‖CStarMatrix.ofMatrix A‖ := by
  calc
    _ ≤ ∑ i, ‖A i i‖ := norm_sum_le _ _
    _ ≤ ∑ _i : Basis n, ‖CStarMatrix.ofMatrix A‖ := by
      exact Finset.sum_le_sum (fun _ _ => CStarMatrix.norm_entry_le_norm)
    _ = _ := by simp [nsmul_eq_mul]

/-- Ordinary, unnormalized trace of the matrix exponential. -/
def partitionFunction (n : ℕ) (β : ℝ) (j : FourSet n → ℝ) : ℂ :=
  Matrix.trace (NormedSpace.exp ℂ ((-β) • hamiltonian n j))

@[simp] theorem partitionFunction_zero (n : ℕ) (β : ℝ) :
    partitionFunction n β (fun _ => 0) = (2 : ℂ) ^ n := by
  simp [partitionFunction, Matrix.trace_one]

/-- The deterministic pressure, using the real part of the ordinary trace. -/
def pressure (n : ℕ) (β : ℝ) (j : FourSet n → ℝ) : ℝ :=
  Real.log (partitionFunction n β j).re / (2 * n)

/-- The exact free anchor for every positive even number N=2n of Majoranas. -/
theorem pressure_zero (n : ℕ) (hn : 0 < n) (β : ℝ) :
    pressure n β (fun _ => 0) = Real.log 2 / 2 := by
  have hn' : (n : ℝ) ≠ 0 := by exact_mod_cast Nat.ne_of_gt hn
  simp only [pressure, partitionFunction_zero, ← Complex.ofReal_ofNat,
    ← Complex.ofReal_pow, Complex.ofReal_re]
  rw [Real.log_pow]
  field_simp [hn']
  <;> ring

/-- Changing the normed matrix type does not change the topological exponential. -/
theorem ofMatrix_exp (n : ℕ) (A : Matrix (Basis n) (Basis n) ℂ) :
    CStarMatrix.ofMatrix (NormedSpace.exp ℂ A) =
      NormedSpace.exp ℂ (CStarMatrix.ofMatrix A) := by
  rfl

/-- Power-series estimate in the genuine matrix operator norm. -/
theorem norm_exp_le (n : ℕ) (A : CStarMatrix (Basis n) (Basis n) ℂ) :
    ‖NormedSpace.exp ℂ A‖ ≤ Real.exp ‖A‖ := by
  have hs : HasSum (fun k : ℕ => (k.factorial : ℝ)⁻¹ * ‖A‖ ^ k) (Real.exp ‖A‖) := by
    simpa only [Real.exp_eq_exp_ℝ, smul_eq_mul] using
      (NormedSpace.exp_series_hasSum_exp' (𝕂 := ℝ) ‖A‖)
  apply (NormedSpace.exp_series_hasSum_exp' (𝕂 := ℂ) A).norm_le_of_bounded hs
  intro k
  rw [norm_smul ((k.factorial : ℂ)⁻¹) (A ^ k), norm_inv, Complex.norm_natCast]
  exact mul_le_mul_of_nonneg_left (norm_pow_le A k) (by positivity)

/-- A finite-volume exponential bound with the exact Hilbert-space dimension. -/
theorem norm_partitionFunction_le (n : ℕ) (β : ℝ) (j : FourSet n → ℝ) :
    ‖partitionFunction n β j‖ ≤
      (2 : ℝ) ^ n * Real.exp (|β| * (∑ I, |j I|) / 4) := by
  calc
    _ ≤ (2 : ℝ) ^ n *
        ‖CStarMatrix.ofMatrix (NormedSpace.exp ℂ ((-β) • hamiltonian n j))‖ :=
      norm_trace_le n _
    _ = (2 : ℝ) ^ n *
        ‖NormedSpace.exp ℂ ((-β) • CStarMatrix.ofMatrix (hamiltonian n j))‖ := by
      rw [ofMatrix_exp]
      rfl
    _ ≤ (2 : ℝ) ^ n * Real.exp ‖(-β) • CStarMatrix.ofMatrix (hamiltonian n j)‖ :=
      mul_le_mul_of_nonneg_left (norm_exp_le n _) (by positivity)
    _ ≤ _ := by
      apply mul_le_mul_of_nonneg_left _ (by positivity)
      apply Real.exp_le_exp.mpr
      rw [norm_smul (-β) (CStarMatrix.ofMatrix (hamiltonian n j)), Real.norm_eq_abs, abs_neg]
      calc
        _ ≤ |β| * ((∑ I, |j I|) / 4) :=
          mul_le_mul_of_nonneg_left (norm_hamiltonian_le n j) (abs_nonneg _)
        _ = _ := by ring

/-- The finite Hamiltonian is continuous in its finitely many real couplings. -/
theorem continuous_hamiltonian (n : ℕ) : Continuous (hamiltonian n) := by
  unfold hamiltonian
  fun_prop

/-- The ordinary partition function is jointly continuous in β and the couplings. -/
theorem continuous_partitionFunction (n : ℕ) :
    Continuous (fun p : ℝ × (FourSet n → ℝ) => partitionFunction n p.1 p.2) := by
  have hexp : Continuous (fun A : Matrix (Basis n) (Basis n) ℂ => NormedSpace.exp ℂ A) := by
    change Continuous (fun A : Matrix (Basis n) (Basis n) ℂ =>
      CStarMatrix.ofMatrixL.symm (NormedSpace.exp ℂ (CStarMatrix.ofMatrixL A)))
    exact CStarMatrix.ofMatrixL.symm.continuous.comp
      (NormedSpace.exp_continuous.comp CStarMatrix.ofMatrixL.continuous)
  unfold partitionFunction
  apply Continuous.matrix_trace
  apply hexp.comp
  exact continuous_fst.neg.smul ((continuous_hamiltonian n).comp continuous_snd)

end SYK.Majorana
