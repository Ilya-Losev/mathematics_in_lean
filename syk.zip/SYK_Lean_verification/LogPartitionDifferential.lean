import GlobalGradientBound
import GaussianIntegrationByParts

/-!
# The actual SYK Frechet differential

Analyticity of the finite matrix exponential gives Frechet differentiability.
The previously proved noncommutative directional trace formula then identifies
the differential with the concrete Gibbs gradient. This permits arbitrary
smooth coupling curves, rather than only straight-line perturbations.
-/

set_option maxHeartbeats 600000
noncomputable section
open scoped BigOperators ComplexOrder
namespace SYK.LogPartitionDifferential
open Majorana GlobalGradient

/-- The concrete Hamiltonian as a continuous real-linear map. -/
def hamiltonianCLM (m : ℕ) : (FourSet m → ℝ) →L[ℝ]
    CStarMatrix (Basis m) (Basis m) ℂ :=
  -∑ I, (ContinuousLinearMap.proj I).smulRight (CStarMatrix.ofMatrix (quartic m I))

@[simp] theorem hamiltonianCLM_apply (m : ℕ) (j : FourSet m → ℝ) :
    hamiltonianCLM m j = CStarMatrix.ofMatrix (hamiltonian m j) := by
  simp only [hamiltonianCLM, ContinuousLinearMap.neg_apply, ContinuousLinearMap.sum_apply,
    ContinuousLinearMap.smulRight_apply, ContinuousLinearMap.proj_apply]
  rfl

def logPartition (m : ℕ) (β : ℝ) (j : FourSet m → ℝ) : ℝ :=
  Real.log (partitionFunction m β j).re

/-- Frechet differentiability is derived from the actual matrix exponential,
not inferred from existence of unrelated directional derivatives. -/
theorem differentiableAt_logPartition (m : ℕ) (β : ℝ) (j : FourSet m → ℝ) :
    DifferentiableAt ℝ (logPartition m β) j := by
  let h := (-β) • hamiltonianCLM m
  have he := ((NormedSpace.exp_analytic (𝕂 := ℂ) (h j)).differentiableAt).restrictScalars ℝ
  have hh := he.comp j h.differentiableAt
  have ht := ((DuhamelTrace.matrixTrace m).restrictScalars ℝ).differentiableAt.comp j hh
  have hr := Complex.reCLM.differentiableAt.comp j ht
  have heq : (fun x => Complex.reCLM
      (((DuhamelTrace.matrixTrace m).restrictScalars ℝ) (NormedSpace.exp ℂ (h x)))) =
      (fun x => (partitionFunction m β x).re) := by
    funext x
    simp only [h, ContinuousLinearMap.smul_apply, hamiltonianCLM_apply]
    rfl
  simp only [Function.comp_def] at hr
  rw [heq] at hr
  exact hr.log (Gibbs.syk_partition_re_pos m β j).ne'

/-- The explicit Gibbs gradient assembled into a continuous linear functional. -/
def gradientCLM (m : ℕ) (β : ℝ) (j : FourSet m → ℝ) : (FourSet m → ℝ) →L[ℝ] ℝ :=
  ∑ I, (logGradient m β j I) • ContinuousLinearMap.proj I

@[simp] theorem gradientCLM_apply (m : ℕ) (β : ℝ) (j w : FourSet m → ℝ) :
    gradientCLM m β j w = ∑ I, logGradient m β j I * w I := by
  simp only [gradientCLM, ContinuousLinearMap.sum_apply, ContinuousLinearMap.smul_apply,
    ContinuousLinearMap.proj_apply, smul_eq_mul]

/-- Identification of the true Frechet derivative with the actual Gibbs gradient. -/
theorem hasFDerivAt_logPartition (m : ℕ) (β : ℝ) (j : FourSet m → ℝ) :
    HasFDerivAt (logPartition m β) (gradientCLM m β j) j := by
  have hf := (differentiableAt_logPartition m β j).hasFDerivAt
  have he : fderiv ℝ (logPartition m β) j = gradientCLM m β j := by
    ext w
    have hl : HasDerivAt (fun t : ℝ => j + t • w) w 0 := by
      simpa using ((hasDerivAt_id (0 : ℝ)).smul_const w).const_add j
    have hf' : HasFDerivAt (logPartition m β) (fderiv ℝ (logPartition m β) j) (j + (0 : ℝ) • w) := by
      simpa using hf
    have hcomp := hf'.comp_hasDerivAt (0 : ℝ) hl
    have hreal := hasDerivAt_logPartition_line m β j w 0
    have h := hcomp.unique hreal
    simpa only [gradientCLM_apply, zero_mul, add_zero] using h
  rw [he] at hf
  exact hf

/-- The concrete response along any differentiable disorder curve. -/
theorem hasDerivAt_logPartition_curve (m : ℕ) (β t : ℝ)
    (c : ℝ → FourSet m → ℝ) (v : FourSet m → ℝ) (hc : HasDerivAt c v t) :
    HasDerivAt (fun s => logPartition m β (c s))
      (∑ I, logGradient m β (c t) I * v I) t := by
  simpa only [gradientCLM_apply] using (hasFDerivAt_logPartition m β (c t)).comp_hasDerivAt t hc

/-- The gradient is continuous, since every Gibbs insertion and the strictly
positive partition normalization are continuous. -/
theorem continuous_logGradient (m : ℕ) (β : ℝ) : Continuous (logGradient m β) := by
  apply continuous_pi
  intro I
  have hc : Continuous (fun j : FourSet m → ℝ => (partitionFunction m β j).re) := by
    have hp : Continuous (fun j : FourSet m → ℝ => (β, j)) := continuous_const.prodMk continuous_id
    have hZ := (continuous_partitionFunction m).comp hp
    have hR := Complex.continuous_re.comp hZ
    exact hR
  have hInv := hc.inv₀ (fun j => (Gibbs.syk_partition_re_pos m β j).ne')
  have hT := GaussianIBP.continuous_thermalInsertion m β (quartic m I)
  have h := (show Continuous (fun _ : FourSet m → ℝ => β) from continuous_const).mul (hInv.mul hT)
  have heq : (fun j : FourSet m → ℝ => β *
      ((partitionFunction m β j).re⁻¹ * GaussianIBP.thermalInsertion m β j (quartic m I))) =
      (fun j => logGradient m β j I) := by
    funext j
    simp only [logGradient, quarticExpectation, Gibbs.sykDensity, Gibbs.density,
      mul_smul_comm, smul_mul_assoc, Matrix.trace_smul, Complex.real_smul,
      Complex.mul_re, Complex.ofReal_re, Complex.ofReal_im, zero_mul, sub_zero]
    rfl
  rw [heq] at h
  exact h

end SYK.LogPartitionDifferential
