# Continuum SYK free energy: Lean verification

The unconditional main theorem is:

```lean
SYK.SYKMainTheorem.continuum_free_energy
  (β : ℝ) (hβ : 0 < β) :
  ∃ g : ℝ≥0 → ℝ → ℝ,
    @SYK.ContinuumSYKMain.MainConclusion β ⟨hβ⟩ g
```

It proves the unique physical continuum solution, its sharp bound and endpoint
regularity, actual collective-moment convergence including coincidences, both
actual pressure limits, and the positive ordinary Fredholm determinant formula.
The only hypothesis is positive inverse temperature. The family includes every
nonnegative coupling; the original parameter is λ = J². Free energy is −p/β.

This verifies the manuscript's main free-energy theorem and its stated moment
convergence addendum. It does **not** claim that every auxiliary bound or remark
in the paper has been formalized. In particular, the concentration proof uses a
nonsharp bound sufficient for the pressure limit; the separate probability and
almost-sure remarks and the separate all-L² maximization assertion are outside
this result. See the proof adaptations in
[PROOF_GUIDE.md](PROOF_GUIDE.md).

## Read and inspect

- [PROOF_GUIDE.md](PROOF_GUIDE.md): readable mathematical proof and theorem map.
- [MANUSCRIPT_THEOREM_AUDIT.md](MANUSCRIPT_THEOREM_AUDIT.md): each target conclusion
  and the exact concrete-model dependencies that discharge it.
- [PROOF_STATUS.md](PROOF_STATUS.md): proof assembly and current audit status.
- [DIAGONAL_OPERATOR_SCOPE.md](DIAGONAL_OPERATOR_SCOPE.md): actual complex L²
  operator, trace-class certificate and basis-independent Fredholm meaning.
- [VERIFICATION.md](VERIFICATION.md): exact reproduced snapshot and logs.
- `SYKMainTheorem.lean`: unconditional entry point.
- `ContinuumSYKMain.lean`: explicit physical, moment, pressure and Fredholm
  conclusion structures. Intermediate conditional assembly is kept visible.
- `ContinuumSYKCorollaries.lean`: complex operator uniqueness, family uniqueness,
  original coupling/free-energy and arbitrary matrix representation corollaries.
- `ActualMicroscopicIdentities.lean`: unconditional finite Ward and response facts.

The finite model is constructed from Pauli matrices, with N = 2d and dimension
2^d. The disorder is the actual finite product Gaussian with variance 6λ/N³.
The partition function is the ordinary matrix-exponential trace. Generic
representation independence follows from CAR, cyclic trace and convergent
exponential series, without assuming unitary equivalence.
`SYK.SYKMainTheorem.continuum_free_energy_abstract` additionally states actual
pressure, free-energy and all coincident-moment convergence on arbitrary
finite-dimensional complex spaces using their basis-free ordinary trace.

## Reproduce on macOS or Linux

Install the official Lean toolchain using
[Lean's installation instructions](https://lean-lang.org/install/).
The `lean-toolchain` file pins Lean 4.19.0; `lakefile.toml` and
`lake-manifest.json` pin mathlib and all transitive dependencies. Python 3 and
Git are also needed. From this directory:

```sh
lake exe cache get
./scripts/check.sh
```

Do not run `lake update` unless intentionally changing dependencies. A first
cache download can be large. The source archive omits toolchains and dependency
caches; Lake retrieves the exact pinned dependencies. No platform compatibility
adapter is needed. The retained `local-environment/self_path_compat.c` is unused
historical provenance from the starter and is never loaded by the checking script.

The script checks auditor controls and source inventory, cleans and rebuilds
only this project, prints named theorem axioms, audits every safe project
logical declaration, prints exact theorem types, and writes source checksums.
The audit invocations use `--trust=0`. The only accepted foundations are
`propext`, `Classical.choice` and `Quot.sound`. Additional axioms, proof
placeholders, authored unsafe definitions or native proof shortcuts are rejected.
The exhaustive audit includes private/generated safe declarations. Unsafe
compiler execution artifacts are individually reported and cannot be logical
proof dependencies.

A successful axiom audit does not discharge ordinary hypotheses by itself.
The unconditional public theorem instantiates every intermediate model,
positivity, Ward, compactness, pressure and determinant premise with the actual
constructed model. Its printed type is the definitive completion check.

## Inputs and provenance

The supplied manuscript is preserved at
`reference/SYK_continuum_free_energy.tex`, SHA-256:

`c214e369a8d2ae97dc1fcbd4bc4b759119ced8ee92ae5598b4c5fb7135449562`

The starter's reports are retained under `historical/`. Older partial-checkpoint
logs describe the state at their respective dates; they do not override the
latest verification record. The official Lean kernel and dependency sources
are unmodified. No remote publication is required to reproduce the proof.
