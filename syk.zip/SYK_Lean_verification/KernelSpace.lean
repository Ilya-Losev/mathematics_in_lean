import PolynomialODE
import ThermalCovariance
import Mathlib.Analysis.Normed.Lp.lpSpace
import Mathlib.MeasureTheory.Integral.Prod
import Mathlib.MeasureTheory.Integral.IntervalIntegral.Basic
import Mathlib.Topology.Sequences
import Mathlib.Tactic

/-!
# Pointwise bounded, strongly measurable kernels

The ambient space is a closed subalgebra of the discrete-index ℓ∞ space over
all pairs of real endpoints. These are actual functions, with actual endpoint
values, not equivalence classes modulo null sets. Joint strong measurability
is imposed explicitly and is preserved by uniform limits. In particular no
separability assumption is made about the coefficient Banach algebra.
-/

noncomputable section

namespace SYK

open MeasureTheory Filter Set
open scoped ENNReal Topology

variable (A : Type*) [NormedRing A] [NormedAlgebra ℂ A] [NormOneClass A]

abbrev RawKernel := lp (fun _ : ℝ × ℝ => A) ∞

/-- The subalgebra of globally bounded, jointly strongly measurable kernels. -/
def strongKernelAlgebra : Subalgebra ℂ (RawKernel A) where
  carrier := {f | StronglyMeasurable (fun p : ℝ × ℝ => f p)}
  algebraMap_mem' := fun c => stronglyMeasurable_const
  add_mem' := fun hf hg => hf.add hg
  mul_mem' := fun hf hg => hf.mul hg

/-- A sup-norm kernel space with pointwise evaluation. -/
abbrev KernelSpace := ↥(strongKernelAlgebra A)

instance kernelNormedSpace : NormedSpace ℂ (KernelSpace A) :=
  NormedAlgebra.toNormedSpace (KernelSpace A)

instance kernelRealNormedSpace [NormedSpace ℝ A] [IsScalarTower ℝ ℂ A] :
    NormedSpace ℝ (KernelSpace A) :=
  Submodule.normedSpace (𝕜 := ℝ) (strongKernelAlgebra A).toSubmodule

instance : CoeFun (KernelSpace A) (fun _ => ℝ × ℝ → A) :=
  ⟨fun f => (f.val : ℝ × ℝ → A)⟩

variable {A}

@[ext] theorem KernelSpace.ext {f g : KernelSpace A} (h : ∀ p, f p = g p) : f = g :=
  Subtype.ext (lp.ext (funext h))

@[simp] theorem kernel_zero_apply (p : ℝ × ℝ) : (0 : KernelSpace A) p = 0 := rfl
@[simp] theorem kernel_one_apply (p : ℝ × ℝ) : (1 : KernelSpace A) p = 1 := rfl
@[simp] theorem kernel_add_apply (f g : KernelSpace A) (p : ℝ × ℝ) :
    (f + g) p = f p + g p := rfl
@[simp] theorem kernel_sub_apply (f g : KernelSpace A) (p : ℝ × ℝ) :
    (f - g) p = f p - g p := rfl
@[simp] theorem kernel_mul_apply (f g : KernelSpace A) (p : ℝ × ℝ) :
    (f * g) p = f p * g p := rfl
@[simp] theorem kernel_smul_apply (c : ℂ) (f : KernelSpace A) (p : ℝ × ℝ) :
    (c • f) p = c • f p := rfl

/-- Joint strong measurability holds everywhere, not only almost everywhere. -/
theorem KernelSpace.stronglyMeasurable (f : KernelSpace A) : StronglyMeasurable f := f.property

theorem kernel_norm_apply_le (f : KernelSpace A) (p : ℝ × ℝ) : ‖f p‖ ≤ ‖f‖ :=
  lp.norm_apply_le_norm ENNReal.top_ne_zero f.val p

/-- The strong-measurability condition is uniformly closed in the genuine
pointwise sup-norm space, even for a nonseparable coefficient algebra. -/
theorem isClosed_strongKernelAlgebra :
    IsClosed (strongKernelAlgebra A : Set (RawKernel A)) := by
  apply isSeqClosed_iff_isClosed.mp
  intro f g hf hfg
  exact stronglyMeasurable_of_tendsto atTop hf
    (lp.uniformContinuous_coe.continuous.continuousAt.tendsto.comp hfg)

instance [CompleteSpace A] : CompleteSpace (KernelSpace A) :=
  isClosed_strongKernelAlgebra.completeSpace_coe

/-- Bounded pointwise evaluation; this would be unavailable on an a.e. quotient. -/
def kernelEvalCLM (p : ℝ × ℝ) : KernelSpace A →L[ℂ] A :=
  LinearMap.mkContinuous
    { toFun := fun f => f p
      map_add' := fun _ _ => rfl
      map_smul' := fun _ _ => rfl }
    1 (fun f => by simpa only [one_mul] using kernel_norm_apply_le f p)

@[simp] theorem kernelEvalCLM_apply (p : ℝ × ℝ) (f : KernelSpace A) :
    kernelEvalCLM (A := A) p f = f p := rfl

/-- Build an actual pointwise kernel from strong measurability and a uniform
bound; no choice of an almost-everywhere representative is involved. -/
def kernelOfFunction (f : ℝ × ℝ → A) (hf : StronglyMeasurable f)
    (B : ℝ) (hB : ∀ p, ‖f p‖ ≤ B) : KernelSpace A :=
  ⟨⟨f, memℓp_infty ⟨B, by rintro _ ⟨p, rfl⟩; exact hB p⟩⟩, hf⟩

@[simp] theorem kernelOfFunction_apply (f : ℝ × ℝ → A) (hf : StronglyMeasurable f)
    (B : ℝ) (hB : ∀ p, ‖f p‖ ≤ B) (p : ℝ × ℝ) :
    kernelOfFunction f hf B hB p = f p := rfl

/-- Continuous bounded remainders belong to the measurable kernel algebra even
if their coefficient algebra is nonseparable. -/
def kernelOfContinuous (f : ℝ × ℝ → A) (hf : Continuous f)
    (B : ℝ) (hB : ∀ p, ‖f p‖ ≤ B) : KernelSpace A :=
  kernelOfFunction f hf.stronglyMeasurable B hB

/-- The exact midpoint-prescribed thermal covariance embedded as scalar multiples
of the coefficient algebra's unit. -/
def freeThermalKernel (β : ℝ) : KernelSpace A :=
  kernelOfFunction
    (fun p => (Thermal.kernel β p.1 p.2 : ℂ) • (1 : A))
    ((Complex.continuous_ofReal.comp_stronglyMeasurable
      (Thermal.kernel_measurable β).stronglyMeasurable).smul_const (1 : A))
    (1 / 2) (by
      intro p
      simpa only [norm_smul, norm_one, mul_one, Complex.norm_real, Real.norm_eq_abs]
        using Thermal.abs_covariance_le β (p.1 - p.2))

@[simp] theorem freeThermalKernel_apply (β : ℝ) (p : ℝ × ℝ) :
    freeThermalKernel (A := A) β p = (Thermal.kernel β p.1 p.2 : ℂ) • (1 : A) := rfl

theorem freeThermalKernel_norm_le (β : ℝ) : ‖freeThermalKernel (A := A) β‖ ≤ 1 / 2 := by
  apply lp.norm_le_of_forall_le (by norm_num)
  intro p
  change ‖(Thermal.kernel β p.1 p.2 : ℂ) • (1 : A)‖ ≤ 1 / 2
  simpa only [norm_smul, norm_one, mul_one, Complex.norm_real, Real.norm_eq_abs]
    using Thermal.abs_covariance_le β (p.1 - p.2)

@[simp] theorem freeThermalKernel_diagonal (β s : ℝ) :
    freeThermalKernel (A := A) β (s, s) = 0 := by simp

theorem freeThermalKernel_skew (β s t : ℝ) :
    freeThermalKernel (A := A) β (t, s) = -freeThermalKernel β (s, t) := by
  change (Thermal.kernel β t s : ℂ) • (1 : A) =
    -((Thermal.kernel β s t : ℂ) • (1 : A))
  rw [Thermal.kernel_skew β s t]
  simp only [Complex.ofReal_neg, neg_smul]

theorem freeThermalKernel_translation (β s t u : ℝ) :
    freeThermalKernel (A := A) β (s + u, t + u) = freeThermalKernel β (s, t) := by
  simp only [freeThermalKernel_apply, Thermal.kernel_translation]

theorem freeThermalKernel_antiperiodic_left (β : ℝ) (hβ : β ≠ 0) (s t : ℝ) :
    freeThermalKernel (A := A) β (s + β, t) = -freeThermalKernel β (s, t) := by
  change (Thermal.covariance β ((s + β) - t) : ℂ) • (1 : A) =
    -((Thermal.covariance β (s - t) : ℂ) • (1 : A))
  rw [show (s + β) - t = (s - t) + β by ring,
    Thermal.covariance_antiperiodic β hβ (s - t)]
  simp only [Complex.ofReal_neg, neg_smul]

theorem freeThermalKernel_antiperiodic_right (β : ℝ) (hβ : β ≠ 0) (s t : ℝ) :
    freeThermalKernel (A := A) β (s, t + β) = -freeThermalKernel (A := A) β (s, t) := by
  calc
    _ = -freeThermalKernel (A := A) β (t + β, s) := freeThermalKernel_skew (A := A) β (t + β) s
    _ = -(-freeThermalKernel (A := A) β (t, s)) := by rw [freeThermalKernel_antiperiodic_left (A := A) β hβ]
    _ = -freeThermalKernel (A := A) β (s, t) := by rw [neg_neg, freeThermalKernel_skew (A := A) β s t]

/-- Simultaneous translation, preserving every individual endpoint value. -/
def translateKernel (u : ℝ) (f : KernelSpace A) : KernelSpace A :=
  kernelOfFunction (fun p => f (p.1 + u, p.2 + u))
    ((KernelSpace.stronglyMeasurable f).comp_measurable
      ((measurable_fst.add_const u).prodMk (measurable_snd.add_const u)))
    ‖f‖ (fun p => kernel_norm_apply_le f _)

@[simp] theorem translateKernel_apply (u : ℝ) (f : KernelSpace A) (s t : ℝ) :
    translateKernel u f (s, t) = f (s + u, t + u) := rfl

theorem translateKernel_norm_le (u : ℝ) (f : KernelSpace A) :
    ‖translateKernel u f‖ ≤ ‖f‖ :=
  lp.norm_le_of_forall_le (norm_nonneg _) (fun p => kernel_norm_apply_le f _)

@[simp] theorem translateKernel_neg (u : ℝ) (f : KernelSpace A) :
    translateKernel (-u) (translateKernel u f) = f := by
  ext p
  rcases p with ⟨s, t⟩
  change f ((s + -u) + u, (t + -u) + u) = f (s, t)
  simp

/-- Translations are isometries of the full actual-value sup-norm algebra. -/
theorem translateKernel_norm (u : ℝ) (f : KernelSpace A) :
    ‖translateKernel u f‖ = ‖f‖ := by
  apply le_antisymm (translateKernel_norm_le u f)
  simpa only [translateKernel_neg] using translateKernel_norm_le (-u) (translateKernel u f)

@[simp] theorem translateKernel_freeThermalKernel (β u : ℝ) :
    translateKernel u (freeThermalKernel (A := A) β) = freeThermalKernel β := by
  ext p
  exact freeThermalKernel_translation β p.1 p.2 u

/-- The endpoint Lipschitz estimate gives actual sup-norm continuity of the
center-translation orbit; pointwise continuity alone would not suffice. -/
theorem translateKernel_lipschitz (f : KernelSpace A) (K : ℝ) (hK : 0 ≤ K)
    (hf : ∀ s t s' t', ‖f (s, t) - f (s', t')‖ ≤ K * (|s - s'| + |t - t'|)) :
    LipschitzWith ⟨2 * K, by positivity⟩ (fun u : ℝ => translateKernel u f) := by
  apply LipschitzWith.of_dist_le_mul
  intro u v
  rw [dist_eq_norm, Real.dist_eq]
  apply lp.norm_le_of_forall_le (by positivity)
  intro p
  rcases p with ⟨s, t⟩
  change ‖f (s + u, t + u) - f (s + v, t + v)‖ ≤ 2 * K * |u - v|
  calc
    _ ≤ K * (|(s + u) - (s + v)| + |(t + u) - (t + v)|) := hf _ _ _ _
    _ = 2 * K * |u - v| := by
      rw [show (s + u) - (s + v) = u - v by ring,
        show (t + u) - (t + v) = u - v by ring]
      ring

section Convolution

variable [NormedSpace ℝ A] [IsScalarTower ℝ ℂ A] [CompleteSpace A]

/-- The actual continuous-time composition integral on `[0, β]`. -/
def kernelConvolutionValue (β : ℝ) (f g : KernelSpace A) (p : ℝ × ℝ) : A :=
  ∫ u in (0 : ℝ)..β, f (p.1, u) * g (u, p.2)

theorem kernelProduct_stronglyMeasurable (f g : KernelSpace A) (p : ℝ × ℝ) :
    StronglyMeasurable (fun u : ℝ => f (p.1, u) * g (u, p.2)) :=
  ((KernelSpace.stronglyMeasurable f).comp_measurable (measurable_const.prodMk measurable_id)).mul
    ((KernelSpace.stronglyMeasurable g).comp_measurable (measurable_id.prodMk measurable_const))

theorem kernelProduct_norm_le (f g : KernelSpace A) (p : ℝ × ℝ) (u : ℝ) :
    ‖f (p.1, u) * g (u, p.2)‖ ≤ ‖f‖ * ‖g‖ := by
  calc
    _ ≤ ‖f (p.1, u)‖ * ‖g (u, p.2)‖ := norm_mul_le _ _
    _ ≤ ‖f‖ * ‖g‖ := by
      gcongr
      · exact kernel_norm_apply_le _ _
      · exact kernel_norm_apply_le _ _

theorem kernelProduct_intervalIntegrable (β : ℝ) (f g : KernelSpace A) (p : ℝ × ℝ) :
    IntervalIntegrable (fun u : ℝ => f (p.1, u) * g (u, p.2)) volume 0 β :=
  (intervalIntegrable_const (c := ‖f‖ * ‖g‖)).mono_fun'
    (kernelProduct_stronglyMeasurable f g p).aestronglyMeasurable
    (Eventually.of_forall fun u => kernelProduct_norm_le f g p u)

theorem kernelConvolutionValue_norm_le (β : ℝ) (hβ : 0 ≤ β)
    (f g : KernelSpace A) (p : ℝ × ℝ) :
    ‖kernelConvolutionValue β f g p‖ ≤ β * ‖f‖ * ‖g‖ := by
  calc
    _ ≤ (‖f‖ * ‖g‖) * |β - 0| :=
      intervalIntegral.norm_integral_le_of_norm_le_const
        (fun u _ => kernelProduct_norm_le f g p u)
    _ = β * ‖f‖ * ‖g‖ := by rw [sub_zero, abs_of_nonneg hβ]; ring

/-- Integrating the strongly measurable joint three-time kernel preserves
joint strong measurability in both external endpoints. -/
theorem kernelConvolutionValue_stronglyMeasurable (β : ℝ) (hβ : 0 ≤ β)
    (f g : KernelSpace A) : StronglyMeasurable (kernelConvolutionValue β f g) := by
  have h : StronglyMeasurable (fun z : (ℝ × ℝ) × ℝ =>
      f (z.1.1, z.2) * g (z.2, z.1.2)) :=
    ((KernelSpace.stronglyMeasurable f).comp_measurable
      (measurable_fst.fst.prodMk measurable_snd)).mul
    ((KernelSpace.stronglyMeasurable g).comp_measurable
      (measurable_snd.prodMk measurable_fst.snd))
  have hi := h.integral_prod_right' (ν := volume.restrict (Ioc 0 β))
  change StronglyMeasurable (fun p : ℝ × ℝ => ∫ u in (0 : ℝ)..β, f (p.1, u) * g (u, p.2))
  simp_rw [intervalIntegral.integral_of_le hβ]
  exact hi

/-- Actual convolution as an element of the pointwise kernel Banach algebra. -/
def kernelConvolution (β : ℝ) (hβ : 0 ≤ β) (f g : KernelSpace A) : KernelSpace A :=
  ⟨⟨kernelConvolutionValue β f g,
    memℓp_infty ⟨β * ‖f‖ * ‖g‖, by
      rintro _ ⟨p, rfl⟩
      exact kernelConvolutionValue_norm_le β hβ f g p⟩⟩,
    kernelConvolutionValue_stronglyMeasurable β hβ f g⟩

@[simp] theorem kernelConvolution_apply (β : ℝ) (hβ : 0 ≤ β)
    (f g : KernelSpace A) (p : ℝ × ℝ) :
    kernelConvolution β hβ f g p = ∫ u in (0 : ℝ)..β, f (p.1, u) * g (u, p.2) := rfl

theorem kernelConvolution_norm_le (β : ℝ) (hβ : 0 ≤ β) (f g : KernelSpace A) :
    ‖kernelConvolution β hβ f g‖ ≤ β * ‖f‖ * ‖g‖ := by
  apply lp.norm_le_of_forall_le (by positivity)
  exact fun p => kernelConvolutionValue_norm_le β hβ f g p


/-- Continuous-time kernel composition is a bounded complex-bilinear operation
on the actual pointwise Banach algebra. -/
def kernelConvolutionCLM (β : ℝ) (hβ : 0 ≤ β) :
    KernelSpace A →L[ℂ] KernelSpace A →L[ℂ] KernelSpace A :=
  (LinearMap.mk₂ ℂ (kernelConvolution β hβ)
    (by
      intro f g h
      ext p
      simp only [kernelConvolution_apply, kernel_add_apply, add_mul]
      exact intervalIntegral.integral_add (kernelProduct_intervalIntegrable β f h p)
        (kernelProduct_intervalIntegrable β g h p))
    (by
      intro c f g
      ext p
      simp only [kernelConvolution_apply, kernel_smul_apply, smul_mul_assoc]
      exact intervalIntegral.integral_smul c _)
    (by
      intro f g h
      ext p
      simp only [kernelConvolution_apply, kernel_add_apply, mul_add]
      exact intervalIntegral.integral_add (kernelProduct_intervalIntegrable β f g p)
        (kernelProduct_intervalIntegrable β f h p))
    (by
      intro c f g
      ext p
      simp only [kernelConvolution_apply, kernel_smul_apply, mul_smul_comm]
      exact intervalIntegral.integral_smul c _)).mkContinuous₂ β
    (kernelConvolution_norm_le β hβ)

@[simp] theorem kernelConvolutionCLM_apply_kernel (β : ℝ) (hβ : 0 ≤ β)
    (f g : KernelSpace A) :
    kernelConvolutionCLM (A := A) β hβ f g = kernelConvolution β hβ f g := rfl

@[simp] theorem kernelConvolutionCLM_apply (β : ℝ) (hβ : 0 ≤ β)
    (f g : KernelSpace A) (p : ℝ × ℝ) :
    kernelConvolutionCLM (A := A) β hβ f g p =
      ∫ u in (0 : ℝ)..β, f (p.1, u) * g (u, p.2) := rfl

theorem kernelConvolutionCLM_norm_le (β : ℝ) (hβ : 0 ≤ β) :
    ‖kernelConvolutionCLM (A := A) β hβ‖ ≤ β :=
  (kernelConvolutionCLM (A := A) β hβ).opNorm_le_bound₂ hβ (by
    intro f g
    rw [kernelConvolutionCLM_apply_kernel]
    exact kernelConvolution_norm_le β hβ f g)

/-- The concrete integral-kernel field inherits the checked real-analytic ODE
regularity theorem. The derivative identity is still required in sup norm. -/
theorem concreteKernel_ode_analytic
    (β : ℝ) (hβ : 0 ≤ β) (C : KernelSpace A) (lam : ℂ)
    (r : ℝ → KernelSpace A)
    (hr : ∀ t, HasDerivAt r
      (kernelCenterField (A := KernelSpace A) (kernelConvolutionCLM (A := A) β hβ) C lam (r t)) t) :
    AnalyticOnNhd ℝ r Set.univ :=
  kernelCenterField_ode_analytic (A := KernelSpace A)
    (kernelConvolutionCLM (A := A) β hβ) C lam r hr

end Convolution

end SYK
