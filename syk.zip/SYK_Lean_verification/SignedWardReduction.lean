import FundamentalWardContacts
import ThermalMomentTransport
import WickVertexIntegrals

/-! # Signed thermal reduction of exact polynomial Ward identities

The fundamental algebra uses the actual half-open time type. Covariance,
centered coordinates and contact derivations are transported algebraically,
including every thermal seam. No raw 0/beta identification is assumed.
-/
noncomputable section
open scoped BigOperators NNReal
namespace SYK.SignedWardReduction
open ThermalWick WickVertexIntegrals ThermalEndpointLift
open WeightedKernelAlgebra MvPolynomial

abbrev TimePair (β : ℝ) := Time β × Time β
abbrev TimePolynomial (β : ℝ) := MvPolynomial (TimePair β) ℂ

variable (β : ℝ) (hβ : 0<β)

def timePair (p : Endpoint) : TimePair β :=
  (timeRepresentative β hβ p.1,timeRepresentative β hβ p.2)

/-- Signed reduction into the genuine Ico field-label polynomial algebra. -/
def reduction : RealPolynomial →ₐ[ℂ] TimePolynomial β :=
  MvPolynomial.aeval (fun p => pairSign β hβ p • X (timePair β hβ p))

@[simp] theorem reduction_X (p : Endpoint) :
    reduction β hβ (X p) = pairSign β hβ p • X (timePair β hβ p) := MvPolynomial.aeval_X _ _

@[simp] theorem reduction_C (z : ℂ) : reduction β hβ (C z)=C z := MvPolynomial.aeval_C _ _

/-- The half-open labels embed into the compact coordinate cube. -/
def compactPair (p : TimePair β) : FundamentalPair β :=
  (⟨p.1.val,p.1.property.1,p.1.property.2.le⟩,
   ⟨p.2.val,p.2.property.1,p.2.property.2.le⟩)

def compactEmbedding : TimePolynomial β →ₐ[ℂ] FundamentalPolynomial β :=
  MvPolynomial.rename (compactPair β)

@[simp] theorem compactPair_timePair (p : Endpoint) :
    compactPair β (timePair β hβ p) = representativePair β hβ p := rfl

/-- The new half-open reduction is exactly the already constructed actual
thermal reduction after compact embedding. -/
theorem compactEmbedding_reduction (P : RealPolynomial) :
    compactEmbedding β (reduction β hβ P) = polynomialReduction β hβ P := by
  have hh : (compactEmbedding β).comp (reduction β hβ) = polynomialReduction β hβ := by
    apply MvPolynomial.algHom_ext
    intro p
    simp only [AlgHom.comp_apply,reduction_X,map_smul,compactEmbedding,MvPolynomial.rename_X,
      compactPair_timePair,polynomialReduction_X,liftedVariable]
  exact congrArg (fun f : RealPolynomial →ₐ[ℂ] FundamentalPolynomial β => f P) hh

/-- Exact fundamental-domain actual microscopic functional. -/
def actualFundamental (d : ℕ) (lam : ℝ≥0) : TimePolynomial β →ₗ[ℂ] ℂ :=
  (MomentLimit.actualPolynomial d β lam).comp (compactEmbedding β).toLinearMap

/-- The all-real actual functional is the signed reduction of the original
microscopic Ico functional, as an equality rather than an invariance premise. -/
theorem actualThermal_eq_reduction (d : ℕ) (lam : ℝ≥0) (P : RealPolynomial) :
    ThermalMomentTransport.actualThermalPolynomial β hβ d lam P =
      actualFundamental β d lam (reduction β hβ P) := by
  change MomentLimit.actualPolynomial d β lam (polynomialReduction β hβ P) =
    MomentLimit.actualPolynomial d β lam (compactEmbedding β (reduction β hβ P))
  rw [compactEmbedding_reduction]

/-- The fundamental functional evaluates literal microscopic tuple moments. -/
theorem actualFundamental_tuple (d : ℕ) (lam : ℝ≥0) {k : ℕ} (p : Fin k → TimePair β) :
    actualFundamental β d lam (∏ i, X (p i)) =
      Interacting.collectiveMoment d β lam (fun i => ((p i).1.val,(p i).2.val)) := by
  change MomentLimit.actualPolynomial d β lam (compactEmbedding β (∏ i, X (p i))) = _
  simp only [map_prod,compactEmbedding,MvPolynomial.rename_X]
  exact MomentLimit.actualPolynomial_tuple_prod d β lam (fun i => compactPair β (p i))

/-- List formulation matching the integrated continuum Ward coefficients. -/
theorem actualFundamental_list (d : ℕ) (lam : ℝ≥0) (ps : List (TimePair β)) :
    actualFundamental β d lam (FundamentalWardContacts.coordinateProduct ps) =
      Interacting.collectiveMoment d β lam (fun i => ((ps.get i).1.val,(ps.get i).2.val)) := by
  have hp : FundamentalWardContacts.coordinateProduct ps = ∏ i, X (ps.get i) := by
    rw [← List.prod_ofFn,show List.ofFn (fun i => X (ps.get i)) = ps.map X by
      simpa only [Function.comp_def,List.ofFn_get] using (List.map_ofFn ps.get (X : TimePair β → TimePolynomial β)).symm]
    rfl
  rw [hp,actualFundamental_tuple]

/-- Exact signed covariance reduction to half-open representatives. -/
theorem covariance_reduce (s t : ℝ) :
    (Thermal.kernel β s t:ℂ) = pairSign β hβ (s,t) *
      (Thermal.kernel β (timeRepresentative β hβ s).val (timeRepresentative β hβ t).val:ℂ) :=
  freeCovariance_reduce β hβ (s,t)

/-- Contact generators carry precisely the two distinguished external signs. -/
theorem reduction_contactGenerator (s t : ℝ) (p : Endpoint) :
    reduction β hβ (RealWardContacts.contactGenerator β s t p) =
      pairSign β hβ (s,t) • FundamentalWardContacts.contact (timeRepresentative β hβ s) (timeRepresentative β hβ t)
        (reduction β hβ (X p)) := by
  simp only [RealWardContacts.contactGenerator,map_sub,map_smul,reduction_X,Derivation.map_smul,FundamentalWardContacts.contact_X,
    FundamentalWardContacts.contactGenerator,timePair,smul_sub,smul_smul]
  rw [covariance_reduce β hβ s p.1,covariance_reduce β hβ s p.2]
  simp only [pairSign]
  congr 1 <;> congr 1 <;> ring

/-- Signed reduction intertwines the complete polynomial contact derivation,
so every centered or uncentered insertion retains its exact contact terms. -/
theorem reduction_contact (s t : ℝ) (Q : RealPolynomial) :
    reduction β hβ (RealWardContacts.contact β s t Q) =
      pairSign β hβ (s,t) • FundamentalWardContacts.contact (timeRepresentative β hβ s) (timeRepresentative β hβ t)
        (reduction β hβ Q) := by
  induction Q using MvPolynomial.induction_on with
  | C z => simp
  | add P Q hP hQ => simp only [map_add,hP,hQ,smul_add]
  | mul_X P p hP =>
    simp only [Derivation.leibniz,smul_eq_mul,map_add,map_mul,RealWardContacts.contact_X,
      hP,reduction_contactGenerator]
    simp only [mul_smul_comm,smul_mul_assoc,smul_add]

/-- Centering commutes with the same half-open reduction, also at a seam. -/
theorem reduction_remainder (p : Endpoint) :
    reduction β hβ (MixedIncrement.remainder β p) =
      pairSign β hβ p • (X (timePair β hβ p) -
        C (Thermal.kernel β (timeRepresentative β hβ p.1).val (timeRepresentative β hβ p.2).val:ℂ)) := by
  simp only [MixedIncrement.remainder,map_sub,reduction_X,reduction_C,smul_sub]
  rw [covariance_reduce β hβ p.1 p.2]
  congr 1
  simp only [Algebra.smul_def,map_mul,← MvPolynomial.algebraMap_eq,AlgHom.commutes]

end SYK.SignedWardReduction
