# Reading the continuum SYK formalization

The final unconditional theorem below has passed Lean’s kernel check. The
verification report and clean-build log identify the exact audited source
snapshot. Read the proof adaptations near the end of this guide as well.

## Start with the theorem, not the file count

The public entry point is

```lean
SYK.SYKMainTheorem.continuum_free_energy
  (β : ℝ) (hβ : 0 < β) :
  ∃ g : ℝ≥0 → ℝ → ℝ,
    @SYK.ContinuumSYKMain.MainConclusion β ⟨hβ⟩ g
```

There is no additional microscopic identity, existence, uniqueness,
positivity, convergence, or determinant hypothesis in this entry point.
The family `g` is the actual continuum physical solution, indexed by
`lam : ℝ≥0`. The original parameter is recovered by `lam = J²`.

The conclusion is a structure so that the same family is used throughout:

- `solution`: the integrated continuum Schwinger–Dyson equation, the physical
  Fourier signs, uniqueness, the bound `|g| ≤ 1/2`, the canonical midpoint
  values, both one-sided endpoint limits, and Lipschitz regularity of `G−C`.
- `moments`: convergence of the actual microscopic collective moments,
  including repeated or coincident external labels.
- `pressure`: both `log(E Z)/N` and `E(log Z)/N` converge to the same coupling
  integral.
- `fredholm`: the actual Hilbert-space operator has a summable rank-one
  expansion and a positive ordinary Fredholm determinant.
- `ordinary_action`: the coupling integral equals the Fredholm action.

`MainConclusion.at_real_coupling` writes out the formulas with `J²` and gives
both free-energy limits, including the factor `−1/β`.
`MainConclusion.arbitrary_representation` transfers the pressures from the
explicit matrix construction to any finite matrix Majorana realization of the
prescribed dimension. In `SYKRepresentationCorollaries.lean`,
`arbitrary_primary_moments` and `arbitrary_thermal_moments` transfer the actual
moments as well; `abstract_pressures` and `abstract_freeEnergy` state the
pressure/free-energy results directly for operators on abstract finite-dimensional
complex spaces, including Hilbert spaces. A basis is constructed in the proof;
no chosen coordinates or unproved unitary equivalence is required.

For the whole statement directly on an abstract realization, import
`SYKAbstractMomentCorollaries.lean` and use
`SYK.SYKMainTheorem.continuum_free_energy_abstract`. It returns the same
`MainConclusion` together with `AbstractRealizationConclusion`, whose fields
are `pressure`, `free_energy`, `primary_moments`, and `thermal_moments`.
The only realization assumptions are CAR and dimension `2^d`, for `d ≥ 2`.

## What the mathematical objects actually are

The finite model is not an abstract sequence supplied with a proposed limit.
`Majorana.lean` constructs the matrices from Pauli matrices and proves CAR.
There are `N = 2*d` Majoranas and the matrix dimension is `2^d`.
`MicroscopicPressure.lean` uses the ordinary trace of the matrix exponential
and the actual finite product Gaussian disorder law, with variance
`6*lam/N³` for each increasing four-set.

`ContinuumDefinitions.lean` defines convolution using Lebesgue interval
integrals. Its Fourier transform has the manuscript's positive-exponential
convention. `PhysicalSolution` is a conjunction of actual measurability,
boundedness, symmetry, midpoint, Fourier-sign and integral-equation statements;
it does not abbreviate the desired free-energy conclusion.

The determinant is not a formal product substituted for an operator without
justification. The construction gives the time-domain operator, a trace-class
certificate, its spectrum with algebraic multiplicities, and the ordinary
spectral Fredholm determinant. The integral-action and operator-uniqueness
results identify this operator with `−CΣ` on the complex Hilbert space.
Thus the displayed determinant is `det(I−CΣ)`, not a regularized determinant.

## The proof in six steps

1. **Construct and bound the microscopic moments.** Actual Weyl ordering,
   flavor averages and Gaussian integration give the finite-N polynomial
   functional. Thermal trace bounds give the sharp bounds needed later.

2. **Prove the continuum Wick correspondence and Ward identity.** The
   matrix-exponential histories are expanded into genuinely convergent
   ordered-time series. The exterior Wick coefficients are identified with
   those histories. Gaussian averaging and quartic regrouping give the
   `N*lam/8` collective interaction. Differentiating this interaction gives
   the integrated inserted Ward identity, with every finite-N contact kept.

3. **Construct a limiting state.** The Ward contact estimates yield an
   endpoint modulus with a vanishing inverse-N defect. A common subsequence
   for all degrees gives a bounded polynomial functional. The weighted
   completions and quotients are constructed from it; their nontriviality
   is proved by its normalization.

4. **Select the physical solution and remove subsequences.** The actual
   finite-N reflection-positivity and time-translation identities pass to
   the limit. Analyticity and half-algebra generation supply the positive
   representation and stationarity needed for selection. Fourier positivity,
   the integral equation and a Parseval comparison prove physical uniqueness.
   That uniqueness upgrades the common subsequence to full convergence.

5. **Recover both pressures.** The microscopic derivative is the actual
   integrated fourth collective moment, with coefficient `1/8`. Moment
   convergence and domination allow coupling integration from the proved
   free anchor `log(2)/2`. An independently proved concentration estimate
   makes the annealed–quenched pressure gap vanish.

6. **Identify the ordinary determinant action.** The physical Fourier
   equation supplies the convergent operator expansion and determinant.
   The coupling integral and the on-shell determinant action are identified
   without assuming differentiability of an unspecified saddle point.

The project retains useful intermediate theorems with explicit hypotheses.
Their existence is normal. The important completeness test is that the final
public theorem discharges all model-specific hypotheses through proved
microscopic results.

## Coincidences and the thermal seam

There are two different issues, and the formalization treats them separately.

- External coincidences are part of the theorem. They use the actual Weyl
  prescription; they are not discarded as a null set.
- Collisions among integrated interaction times, or between an interaction
  time and a fixed external time, can be removed only after proving that
  their Lebesgue measure is zero.

For arbitrary real external times, the canonical thermal representative lies
in `[0,β)`, with its fermionic winding sign. Reduction is performed before the
midpoint/Weyl prescription. This matters: raw operator labels `0` and `β`
are different real-time labels. Simply treating their raw closed-interval
moments as an already midpoint-consistent periodic family would be wrong.

Accordingly, the theorem distinguishes literal raw microscopic moments on
`[0,β)` from their signed, midpoint-consistent thermal extension to all real
times. The partition function is unchanged by this correction of the moment
convention.

## Scope

The theorem holds for every fixed `β > 0` and every `lam ≥ 0`, hence for
arbitrarily large fixed `βJ`. No high-temperature smallness condition is
introduced. The limit is along the actual even flavor counts `N = 2*d`.
The original restriction `N ≥ 4` only removes finitely many terms.

This is a continuum proof. It does not require taking a time-mesh limit after
a discrete-time theorem. It does not assert uniformity for `β = β_N → ∞`,
a higher-order `1/N` expansion, or a dominating superbosonisation contour.
Those are not claims of the attached continuum main theorem.

## Changes from a literal line-by-line transcription

This proves the manuscript's main free-energy theorem. It is not a claim
that every auxiliary estimate or prose remark was translated
verbatim. The following proof-level adaptations matter:

1. The signed half-open reduction makes the thermal-seam convention explicit,
   as explained above.
2. The pressure comparison uses the proved nonsharp estimate
   `pᵃ−pᑫ ≤ 3π²β²lam/(128*d)`, with `N=2*d`. This still tends to zero and closes
   the main expected-quenched limit. It does not claim to verify the sharper
   numerical constant in the manuscript's finite-N concentration proposition.
3. The determinant action is identified through comparisons between actual
   physical sources. The broader auxiliary maximization lemma over all L²
   sources is not needed for, or asserted by, the final formal theorem.

The separate prose remark about random sample pressures converging in
probability or almost surely is not a field of the main conclusion. The
verified quenched quantity in that conclusion is the expectation `E(log Z)/N`.
These distinctions should be kept when citing what the Lean project proves.

## What a successful Lean check means

Use the pinned toolchain and dependency manifest, then run the commands in
`README.md`. The clean checking script rebuilds the project, checks named
results, and audits the dependencies of every safe project declaration.
The permitted foundational axioms are `propext`, `Classical.choice`, and
`Quot.sound`. No extra SYK axiom or unfinished proof placeholder is permitted.

Kernel checking verifies the formal statements. Matching those statements to
the manuscript is a separate mathematical obligation, documented in
`MANUSCRIPT_THEOREM_AUDIT.md`. In particular, a successful check of a
conditional intermediate theorem is not itself a proof that its hypotheses
hold. Read the final unconditional theorem and its concrete definitions.
