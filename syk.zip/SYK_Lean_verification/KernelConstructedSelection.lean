import KernelActionBridge
import ThermalKernelSelection

/-!
# Scalar physical selection for the fully constructed continuum algebra

No Banach algebra, star operation, translation action, representation, spectral
measure or factorization is assumed. The remaining inputs are normalized
limiting moments, their finite-polynomial translation symmetry, and even/odd
half-time reflection-positivity tests.
-/

noncomputable section
namespace SYK.KernelConstructedSelection
open SYK.WeightedKernelAlgebra SYK.KernelResidualAlgebra
open SYK.KernelCoordinateGeneration SYK.KernelQuotientActions
open SYK.KernelFinalActions SYK.KernelQuotientAnalyticity SYK.ThermalKernelSelection
open Set
open scoped NNReal BigOperators

variable (b K : ℝ) (hb : 0 < b) (hK : 0 < K) (β : ℝ) (hβ : 0 < β) (lam : ℝ≥0)
  [Nontrivial (FirstAlgebra b K hb hK β)]
  [Nontrivial (FinalAlgebra b K hb hK β hβ (lam : ℝ))]

/-- The constructed-algebra selection theorem: every actual endpoint value and
finite bilocal moment factorizes through the physical scalar solution. -/
theorem exists_physical_factorization
    (L : FinalAlgebra b K hb hK β hβ (lam : ℝ) →L[ℂ] ℂ)
    (hunit : L 1 = 1)
    (hreal : ∀ q ∈ halfPolynomialAlgebra b K hb hK β hβ lam,
      (L (finalReflection b K hb hK β hβ (lam : ℝ) q * q)).im = 0)
    (hpos : ∀ q ∈ halfPolynomialAlgebra b K hb hK β hβ lam,
      0 ≤ (L (finalReflection b K hb hK β hβ (lam : ℝ) q * q)).re)
    (hsym : ∀ u p, L (ResidualQuotient.mk _
      (translatedPolynomial b K hb hK β (thermalCovariance β) u p)) =
      L (ResidualQuotient.mk _
        (polynomialMap b K hb hK (thermalCovariance β) (symmetryRelations β) p)))
    (hodd : ∀ (k : ℕ) (x : Fin k → Ioo (0:ℝ) (β/2)) (c : Fin k → ℂ) q,
      q ∈ halfPolynomialAlgebra b K hb hK β hβ lam →
      0 ≤ (L (finalReflection b K hb hK β hβ (lam : ℝ) q * q *
        SYK.KernelSelection.hankelObservable β
          (thermalFinalKernel b K hb hK β hβ (lam : ℂ) (symmetryRelations β))
          (fun i => x i) c)).re) :
    ∃ g : ℝ → ℝ, SYK.Continuum.PhysicalSolution β lam g ∧
      ∀ (k : ℕ) (p : Fin k → ℝ × ℝ),
        L (∏ i, thermalFinalKernel b K hb hK β hβ (lam : ℂ) (symmetryRelations β) (p i)) =
          ∏ i, (g ((p i).1-(p i).2) : ℂ) := by
  letI : StarRing (ThermalSDAlgebra b K hb hK β hβ (lam : ℂ) (symmetryRelations β)) :=
    finalStarRing b K hb hK β hβ (lam : ℝ)
  letI : StarModule ℂ (ThermalSDAlgebra b K hb hK β hβ (lam : ℂ) (symmetryRelations β)) :=
    finalStarModule b K hb hK β hβ (lam : ℝ)
  letI : NormedStarGroup (ThermalSDAlgebra b K hb hK β hβ (lam : ℂ) (symmetryRelations β)) :=
    finalNormedStarGroup b K hb hK β hβ (lam : ℝ)
  let φ := limitingPositiveState b K hb hK β hβ lam L hreal hpos
  let D := SYK.KernelActionBridge.actionData b K hb hK β hβ (lam : ℝ) φ hsym
  exact SYK.ThermalKernelSelection.exists_physical_factorization
    b K hb hK β hβ lam L hunit hreal hpos D hodd

end SYK.KernelConstructedSelection
