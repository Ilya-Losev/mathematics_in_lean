import MicroscopicPressure

noncomputable section
open MeasureTheory ProbabilityTheory
open scoped NNReal
namespace SYK.GaussianDisorder

variable (ι : Type*) [Fintype ι]

/-- Scaling every actual Gaussian coupling changes exactly the variance parameter. -/
theorem law_scale (N : ℕ) (lam : ℝ≥0) :
    (law ι N 1).map (fun j i => Real.sqrt (lam : ℝ) * j i) = law ι N lam := by
  have hp : MeasurePreserving (fun x : ℝ => Real.sqrt (lam : ℝ) * x)
      (gaussianReal 0 (variance N 1)) (gaussianReal 0 (variance N lam)) := by
    refine ⟨measurable_const.mul measurable_id, ?_⟩
    rw [gaussianReal_map_const_mul, mul_zero]
    congr 1
    apply Subtype.ext
    change (Real.sqrt (lam : ℝ))^2 * (6 * 1 / (N : ℝ)^3) =
      6 * (lam : ℝ) / (N : ℝ)^3
    rw [Real.sq_sqrt lam.coe_nonneg]
    ring
  exact (measurePreserving_pi (fun _ : ι => gaussianReal 0 (variance N 1))
    (fun _ : ι => gaussianReal 0 (variance N lam)) (fun _ => hp)).map_eq

end SYK.GaussianDisorder

namespace SYK.Microscopic

theorem disorder_scale (m : ℕ) (lam : ℝ≥0) :
    (disorder m 1).map (fun j I => Real.sqrt (lam : ℝ) * j I) = disorder m lam :=
  GaussianDisorder.law_scale (Majorana.FourSet m) (2 * m) lam

end SYK.Microscopic
