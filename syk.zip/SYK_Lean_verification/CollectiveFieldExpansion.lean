import WickGaussianRegrouping

/-! # Exact finite-flavor expansion of collective continuum insertions -/
noncomputable section
open scoped BigOperators NNReal ComplexOrder
open MeasureTheory
namespace SYK.CollectiveFieldExpansion
open ThermalWick Ward DuhamelHistory DuhamelVertex WickGaussianRegrouping
open InsertedWickSeries

/-- Flattened flavor-time labels of a collective bilocal monomial. -/
def pairLabels {N : ℕ} {β : ℝ} (ps : List (Time β × Time β))
    (f : Fin ps.length → Fin N) (r : Fin (ps.length*2)) : Label N β :=
  (f r.divNat, if r.modNat = 0 then (ps.get r.divNat).1 else (ps.get r.divNat).2)

def pairLabelList {N : ℕ} {β : ℝ} (ps : List (Time β × Time β))
    (f : Fin ps.length → Fin N) : List (Label N β) := List.ofFn (pairLabels ps f)

@[simp] theorem pairLabelList_length {N : ℕ} {β : ℝ} (ps : List (Time β × Time β))
    (f : Fin ps.length → Fin N) : (pairLabelList ps f).length = ps.length*2 := by
  simp [pairLabelList]

theorem pairLabelList_even {N : ℕ} {β : ℝ} (ps : List (Time β × Time β))
    (f : Fin ps.length → Fin N) : Even (pairLabelList ps f).length := by
  rw [pairLabelList_length]
  exact Even.mul_left (by decide : Even 2) ps.length

@[simp] theorem pairLabels_finProd {N : ℕ} {β : ℝ} (ps : List (Time β × Time β))
    (f : Fin ps.length → Fin N) (i : Fin ps.length) (a : Fin 2) :
    pairLabels ps f (finProdFinEquiv (i,a)) =
      (f i, if a = 0 then (ps.get i).1 else (ps.get i).2) := by
  have he := finProdFinEquiv.symm_apply_apply (i,a)
  have hd := congrArg Prod.fst he
  have hm := congrArg Prod.snd he
  change (finProdFinEquiv (i,a)).divNat = i at hd
  change (finProdFinEquiv (i,a)).modNat = a at hm
  simp only [pairLabels, hd, hm]

/-- The exact exterior word of each finite flavor choice. -/
theorem pairLabelList_word {N : ℕ} {β : ℝ} (ps : List (Time β × Time β))
    (f : Fin ps.length → Fin N) :
    FreeWick.word (fun p : Label N β => field p.1 p.2) (pairLabelList ps f) =
      orderedProduct (fun i => field (f i) (ps.get i).1 * field (f i) (ps.get i).2) := by
  rw [pairLabelList, FreeWick.word_ofFn]
  change orderedProduct (fun r => field (pairLabels ps f r).1 (pairLabels ps f r).2) = _
  rw [orderedProduct_blocks]
  simp only [pairLabels_finProd, orderedProduct, List.ofFn_succ, List.ofFn_zero,
    List.prod_cons, List.prod_nil, mul_one]
  norm_num

/-- Exact finite-N flavor expansion of the genuine collective monomial,
including repeated endpoints and every equal-time collision. -/
theorem collectiveMonomial_expansion {N : ℕ} {β : ℝ} (ps : List (Time β × Time β)) :
    collectiveMonomial (N := N) ps = ((N : ℂ)^ps.length)⁻¹ •
      ∑ f : Fin ps.length → Fin N,
        FreeWick.word (fun p : Label N β => field p.1 p.2) (pairLabelList ps f) := by
  have hl : ps.map (fun p => collective N β p.1 p.2) =
      List.ofFn (fun i => collective N β (ps.get i).1 (ps.get i).2) := by
    simpa only [Function.comp_def, List.ofFn_get] using
      (List.map_ofFn (f := ps.get) (g := fun p => collective N β p.1 p.2))
  rw [collectiveMonomial, hl]
  change orderedProduct (fun i => collective N β (ps.get i).1 (ps.get i).2) = _
  simp only [collective]
  rw [orderedProduct_smul, Finset.prod_const, Finset.card_univ, Fintype.card_fin,
    inv_pow, orderedProduct_sum]
  congr 1
  apply Finset.sum_congr rfl
  intro f _
  exact (pairLabelList_word ps f).symm

/-- External collective coefficients are the exact finite flavor averages
of the already convergent external-field coefficients. -/
theorem coefficient_eq_field_sum (d : ℕ) (hd : 0 < d) {β : ℝ} (hβ : 0 < β)
    (ps : List (Time β × Time β)) (n : ℕ) :
    ContinuumWickSeries.coefficient d β hβ ps n =
      (((2*d : ℕ) : ℂ)^ps.length)⁻¹ •
        (∑ f : Fin ps.length → Fin (2*d), fieldCoefficient d hβ (pairLabelList ps f) n) := by
  have he (u : Fin n → ℝ×ℝ) : ContinuumWickSeries.coefficientIntegrand d β hβ ps u =
      (((2*d : ℕ) : ℂ)^ps.length)⁻¹ * ∑ f : Fin ps.length → Fin (2*d),
        fieldIntegrand d hβ (pairLabelList ps f) u := by
    simp only [ContinuumWickSeries.coefficientIntegrand, collectiveMonomial,
      List.map_append, List.prod_append]
    rw [← collectiveMonomial, collectiveMonomial_expansion]
    simp only [smul_mul_assoc, Finset.sum_mul, expectation, map_smul, map_sum, smul_eq_mul,
      fieldIntegrand, collectiveMonomial]
  unfold ContinuumWickSeries.coefficient
  simp_rw [he]
  rw [integral_const_mul, integral_finset_sum]
  · simp only [fieldCoefficient, Complex.real_smul, smul_eq_mul, Finset.mul_sum]
    apply Finset.sum_congr rfl
    intro f _
    ring
  · intro f _
    exact fieldIntegrand_integrable d hd hβ _ (pairLabelList_even ps f) n

/-- The exact flavor expansion respects every factorial-normalized
interaction coefficient. -/
theorem term_eq_field_sum (d : ℕ) (hd : 0 < d) {β : ℝ} (hβ : 0 < β)
    (ps : List (Time β × Time β)) (lam : ℝ) (n : ℕ) :
    ExponentialMomentSeries.term (ContinuumWickSeries.coefficient d β hβ ps) lam n =
      (((2*d : ℕ) : ℂ)^ps.length)⁻¹ * ∑ f : Fin ps.length → Fin (2*d),
        ExponentialMomentSeries.term (fieldCoefficient d hβ (pairLabelList ps f)) lam n := by
  unfold ExponentialMomentSeries.term
  rw [coefficient_eq_field_sum d hd hβ ps n]
  simp only [Complex.real_smul, smul_eq_mul, Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro f _
  ring

/-- The genuine collective Wick numerator is the exact finite flavor
average of the external-field numerators, with all convergence proved. -/
theorem numerator_eq_field_sum (d : ℕ) (hd : 0 < d) {β : ℝ} (hβ : 0 < β)
    (ps : List (Time β × Time β)) (lam : ℝ) :
    ContinuumWickSeries.numerator d β hβ ps lam =
      (((2*d : ℕ) : ℂ)^ps.length)⁻¹ * ∑ f : Fin ps.length → Fin (2*d),
        fieldNumerator d hβ (pairLabelList ps f) lam := by
  unfold ContinuumWickSeries.numerator fieldNumerator ExponentialMomentSeries.value
  simp_rw [term_eq_field_sum d hd hβ ps lam]
  rw [tsum_mul_left]
  congr 1
  exact Summable.tsum_finsetSum (fun f _ =>
    (fieldNumerator_norm_summable d hd hβ _ (pairLabelList_even ps f) lam).of_norm)

end SYK.CollectiveFieldExpansion
