# Current verification record

## Reproduced baseline

The original starter's complete aggregate build was reproduced successfully with
unmodified official Lean 4.19.0 and the pinned mathlib commit. Its explicit axiom
audit and the stronger all-declaration allowlist audit both passed with
`--trust=0`. See `logs/starter-reproduced-axioms.txt` and
`logs/starter-reproduced-all-axioms.txt`.

The baseline contains 30 source-level theorem declarations. Its old explicit
audit has 31 entries because it also audits one definition. The automatic audit
covers 52 declarations, including 32 kernel theorem declarations (two are
compiler-generated), and permits only `propext`, `Classical.choice`, `Quot.sound`.

## Unconditional theorem and final snapshot

The final unconditional entry point `SYK.SYKMainTheorem.continuum_free_energy`
has passed direct `lean --trust=0` compilation and explicit axiom printing.
Its only mathematical hypothesis is β > 0, and its dependency set is precisely
the permitted standard foundations. Conclusion structure fields were printed
and checked against the manuscript.

The final isolated source-snapshot clean check passed in
`logs/verification-20261013T203624Z.txt`. It began on 2026-10-13 at 20:36:24 UTC
and ends with `CHECK EXIT CODE: 0`. This run cleaned and rebuilt all 180 proof
modules, then ran the explicit and exhaustive audits under `--trust=0` and
printed the final theorem types and conclusion structures.

- 663 explicit `#print axioms` commands completed successfully.
- The exhaustive audit accepted 4,039 safe project declarations, including
  3,214 theorem declarations, with only the three standard foundations.
- 1,222 unsafe compiler execution artifacts were identified and listed
  separately; no unsafe artifact or additional axiom is accepted as a proof.
- The positive, injected-axiom negative, and missing-module controls passed.
- Source inventory, all dependency revisions and the exact manuscript hash passed.
- The full clean log contains 127 harmless linter/style/deprecation warnings
  and no compiler errors. Both final public main theorem files compile cleanly.

The final abstract entry point is
`SYK.SYKMainTheorem.continuum_free_energy_abstract`. It adds actual pressure,
free-energy and moment conclusions for arbitrary finite-dimensional complex
operator realizations satisfying CAR and the dimension condition, without a
basis or unitary-equivalence assumption.

After the full check, verification metadata was updated and the obsolete trailing
documentation block in `SYKLean.lean` was corrected. Every non-comment aggregate
byte was verified identical, and the corrected aggregate was recompiled under
`--trust=0`; see `logs/comment-only-aggregate-check.txt`. No mathematical proof,
configuration or check script changed. The final `source-hashes.json` covers
all delivered source and metadata files. Earlier partial checkpoints remain clearly historical
and are not a substitute for the final reproducibility run.

The original manuscript hash and all nine dependency revisions remain pinned.
No dependency source or official Lean runtime was modified.

## Trust boundary and negative control

`AuditAll.lean` enumerates every safe logical declaration from every listed project proof
module, including private and generated ones. It rejects every foundational axiom
except the three standard ones above. `scripts/source_inventory.py` separately
checks that no proof file is omitted from the aggregate or axiom-audit module
list, checks exact dependency revisions and unmodified dependency sources, and
rejects source-level placeholders/postulates/native evaluation shortcuts.

The audit was tested on a temporary copy containing a synthetic extra axiom and
correctly failed. The delivered proof modules never contained that test axiom.
The real core-only Translation module then passed again. The negative-control
and positive-control logs are in `logs/`.

The original C compatibility adapter is retained only for provenance and is not
compiled or loaded in this run. `logs/environment-provenance.txt` records official
archive/binary hashes and the cache source.

Lean generates unsafe executable specialization artifacts when compiling some
safe definitions. These cannot occur in kernel proof dependencies and are
counted separately from the logical declaration audit. The source inventory
rejects authored `unsafe`/`partial` declarations, and every logical declaration
retains the exact same three-axiom allowlist. The detected sample was
`RingHom.id._at.SYK.kernelCenterField._spec_1`, confirmed by Lean as
`unsafe=true, theorem=false`. No mathematical axiom was whitelisted for it.
