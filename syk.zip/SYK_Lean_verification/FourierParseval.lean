import FermionicFourier
import Mathlib.Analysis.Fourier.AddCircle

/-!
The physical Fourier transform is reduced to the ordinary Hilbert basis on a
circle by a half-frequency phase twist. Haar measure has mass one, so the
normalizing factor 1/β is kept explicit.
-/
noncomputable section
open MeasureTheory Set
open scoped ENNReal ComplexConjugate Topology
namespace SYK.Continuum

def twist (β : ℝ) (g : ℝ → ℝ) (t : ℝ) : ℂ :=
  Complex.exp (Complex.I * ((Real.pi * t / β : ℝ) : ℂ)) * (g t : ℂ)

theorem twist_measurable (β : ℝ) (g : ℝ → ℝ) (hg : Measurable g) :
    Measurable (twist β g) := by
  unfold twist
  fun_prop

theorem norm_twist (β : ℝ) (g : ℝ → ℝ) (t : ℝ) :
    ‖twist β g t‖ = |g t| := by
  simp [twist, norm_mul, Complex.norm_exp]

variable (β : ℝ) [Fact (0 < β)]

def circleLift (g : ℝ → ℝ) : AddCircle β → ℂ :=
  AddCircle.liftIoc β 0 (twist β g)

theorem circleLift_measurable (g : ℝ → ℝ) (hg : Measurable g) :
    Measurable (circleLift β g) := by
  exact (twist_measurable β g hg).comp
    (measurable_subtype_coe.comp (AddCircle.measurableEquivIoc β 0).measurable)

theorem circleLift_memLp (g : ℝ → ℝ) (hg : Measurable g)
    (B : ℝ) (hb : ∀ t, |g t| ≤ B) :
    MemLp (circleLift β g) 2 AddCircle.haarAddCircle := by
  apply MemLp.of_bound (circleLift_measurable β g hg).aestronglyMeasurable B
  filter_upwards [] with t
  exact (norm_twist β g _).le.trans (hb _)

def circleL2 (g : ℝ → ℝ) (hg : Measurable g)
    (B : ℝ) (hb : ∀ t, |g t| ≤ B) : Lp ℂ 2 (@AddCircle.haarAddCircle β _) :=
  (circleLift_memLp β g hg B hb).toLp (circleLift β g)

/-- Every integer label corresponds to an odd (possibly negative) frequency. -/
def integerFrequency (n : ℤ) : ℝ := (2 * (n : ℝ) + 1) * Real.pi / β

theorem circleLift_coefficient (g : ℝ → ℝ) (n : ℤ) :
    _root_.fourierCoeff (circleLift β g) n =
      (1 / β : ℝ) • fourier β g (integerFrequency β (-n)) := by
  rw [_root_.fourierCoeff_eq_intervalIntegral _ _ 0]
  simp only [zero_add]
  congr 1
  apply intervalIntegral.integral_congr_ae
  filter_upwards [] with t ht
  have hβ : 0 < β := Fact.out
  have hm : t ∈ Ioc (0 : ℝ) (0 + β) := by
    simpa only [zero_add, uIoc_of_le hβ.le] using ht
  rw [circleLift, AddCircle.liftIoc_coe_apply hm,
    _root_.fourier_coe_apply, twist]
  simp only [smul_eq_mul, ← mul_assoc, ← Complex.exp_add]
  congr 2
  unfold integerFrequency
  push_cast
  ring

theorem circleL2_coefficient (g : ℝ → ℝ) (hg : Measurable g)
    (B : ℝ) (hb : ∀ t, |g t| ≤ B) (n : ℤ) :
    _root_.fourierCoeff (circleL2 β g hg B hb) n =
      (1 / β : ℝ) • fourier β g (integerFrequency β (-n)) := by
  rw [← circleLift_coefficient β g n]
  apply integral_congr_ae
  filter_upwards [(circleLift_memLp β g hg B hb).coeFn_toLp] with t ht
  change (_root_.fourier (-n)) t • ((circleLift_memLp β g hg B hb).toLp (circleLift β g)) t = _
  rw [ht]

theorem twist_pairing (g h : ℝ → ℝ) (t : ℝ) :
    conj (twist β g t) * twist β h t = ((g t * h t : ℝ) : ℂ) := by
  unfold twist
  rw [map_mul, ← Complex.exp_conj, Complex.conj_ofReal]
  have he : conj (Complex.I * ((Real.pi * t / β : ℝ) : ℂ)) +
      Complex.I * ((Real.pi * t / β : ℝ) : ℂ) = 0 := by
    simp
  calc
    _ = (Complex.exp (conj (Complex.I * ((Real.pi * t / β : ℝ) : ℂ))) *
        Complex.exp (Complex.I * ((Real.pi * t / β : ℝ) : ℂ))) *
        ((g t : ℂ) * (h t : ℂ)) := by ring
    _ = _ := by rw [← Complex.exp_add, he, Complex.exp_zero, one_mul, Complex.ofReal_mul]

theorem circle_integral_formula (f : AddCircle β → ℂ) :
    (∫ t, f t ∂AddCircle.haarAddCircle) =
      (1 / β : ℝ) • ∫ t in (0 : ℝ)..β, f t := by
  simpa [_root_.fourierCoeff, _root_.fourier_zero] using
    _root_.fourierCoeff_eq_intervalIntegral f 0 0

/-- The half-frequency twist preserves the actual time-domain pairing. -/
theorem circleL2_inner (g h : ℝ → ℝ) (hg : Measurable g) (hh : Measurable h)
    (B D : ℝ) (hb : ∀ t, |g t| ≤ B) (hd : ∀ t, |h t| ≤ D) :
    @inner ℂ _ _ (circleL2 β g hg B hb) (circleL2 β h hh D hd) =
      (1 / β : ℝ) • ∫ t in (0 : ℝ)..β, ((g t * h t : ℝ) : ℂ) := by
  rw [MeasureTheory.L2.inner_def]
  have hrep : (∫ t, @inner ℂ _ _ ((circleL2 β g hg B hb) t)
      ((circleL2 β h hh D hd) t) ∂AddCircle.haarAddCircle) =
      ∫ t, conj (circleLift β g t) * circleLift β h t ∂AddCircle.haarAddCircle := by
    apply integral_congr_ae
    filter_upwards [(circleLift_memLp β g hg B hb).coeFn_toLp,
      (circleLift_memLp β h hh D hd).coeFn_toLp] with t ht hu
    change @inner ℂ ℂ _ ((circleLift_memLp β g hg B hb).toLp (circleLift β g) t)
      ((circleLift_memLp β h hh D hd).toLp (circleLift β h) t) = _
    rw [ht, hu]
    simp only [RCLike.inner_apply']
  rw [hrep, circle_integral_formula]
  congr 1
  apply intervalIntegral.integral_congr_ae
  filter_upwards [] with t ht
  have hβ : 0 < β := Fact.out
  have hm : t ∈ Ioc (0 : ℝ) (0 + β) := by
    simpa only [zero_add, uIoc_of_le hβ.le] using ht
  simp only [circleLift, AddCircle.liftIoc_coe_apply hm]
  exact twist_pairing β g h t

/-- Genuine Parseval, including summability, for the circle's actual Fourier basis. -/
theorem circle_parseval (f g : Lp ℂ 2 (@AddCircle.haarAddCircle β _)) :
    HasSum (fun n : ℤ => conj (_root_.fourierCoeff f n) *
      _root_.fourierCoeff g n) (@inner ℂ _ _ f g) := by
  convert (@_root_.fourierBasis β _).hasSum_inner_mul_inner f g using 1
  ext n
  rw [← _root_.fourierBasis_repr, ← _root_.fourierBasis_repr]
  rw [HilbertBasis.repr_apply_apply, HilbertBasis.repr_apply_apply]
  rw [inner_conj_symm]

/-- Parseval in exactly the manuscript's unnormalized fermionic convention.
The integer index enumerates every positive and negative odd frequency. -/
theorem fermionic_parseval (g h : ℝ → ℝ) (hg : Measurable g) (hh : Measurable h)
    (B D : ℝ) (hb : ∀ t, |g t| ≤ B) (hd : ∀ t, |h t| ≤ D) :
    HasSum (fun n : ℤ => conj (fourier β g (integerFrequency β (-n))) *
      fourier β h (integerFrequency β (-n)))
      ((β : ℂ) * ∫ t in (0 : ℝ)..β, ((g t * h t : ℝ) : ℂ)) := by
  have hβ : (β : ℂ) ≠ 0 := Complex.ofReal_ne_zero.mpr (Fact.out : 0 < β).ne'
  have hs := (circle_parseval β (circleL2 β g hg B hb)
    (circleL2 β h hh D hd)).mul_left ((β : ℂ)^2)
  convert hs using 1
  · ext n
    rw [circleL2_coefficient, circleL2_coefficient]
    simp only [Complex.real_smul, Complex.ofReal_div, Complex.ofReal_one,
      map_mul, map_div₀, map_one, Complex.conj_ofReal]
    field_simp
    <;> ring
  · rw [circleL2_inner]
    simp only [Complex.real_smul, Complex.ofReal_div, Complex.ofReal_one]
    field_simp
    <;> ring

/-- All Fourier coefficients determine the actual L² vector. -/
theorem circle_fourier_injective (f g : Lp ℂ 2 (@AddCircle.haarAddCircle β _))
    (h : ∀ n : ℤ, _root_.fourierCoeff f n = _root_.fourierCoeff g n) : f = g := by
  apply (@_root_.fourierBasis β _).repr.injective
  ext n
  simpa only [_root_.fourierBasis_repr] using h n

/-- Injectivity for bounded measurable kernels, first in the correct a.e. sense. -/
theorem fermionic_fourier_zero_ae (g : ℝ → ℝ) (hg : Measurable g)
    (B : ℝ) (hb : ∀ t, |g t| ≤ B)
    (hz : ∀ n : ℤ, fourier β g (integerFrequency β (-n)) = 0) :
    g =ᵐ[volume.restrict (Ioc (0 : ℝ) β)] 0 := by
  have hβ : 0 < β := Fact.out
  have hs := fermionic_parseval β g g hg hg B B hb hb
  simp only [hz, map_zero, zero_mul] at hs
  have he : (β : ℂ) * (∫ t in (0 : ℝ)..β, ((g t * g t : ℝ) : ℂ)) = 0 := by
    simpa only [tsum_zero] using hs.tsum_eq.symm
  have hc : (∫ t in (0 : ℝ)..β, ((g t * g t : ℝ) : ℂ)) = 0 :=
    (mul_eq_zero.mp he).resolve_left (Complex.ofReal_ne_zero.mpr hβ.ne')
  have hr : (∫ t in (0 : ℝ)..β, g t * g t) = 0 := by
    apply Complex.ofReal_injective
    simpa only [intervalIntegral, integral_complex_ofReal, Complex.ofReal_sub,
      Complex.ofReal_zero] using hc
  have hint : Integrable (fun t => g t * g t) (volume.restrict (Ioc (0 : ℝ) β)) := by
    apply (integrable_const (B * B)).mono' (hg.mul hg).aestronglyMeasurable
    filter_upwards [] with t
    simp only [Real.norm_eq_abs, abs_mul]
    exact mul_self_le_mul_self (abs_nonneg _) (hb t)
  rw [intervalIntegral.integral_of_le hβ.le] at hr
  have hae := (integral_eq_zero_iff_of_nonneg
    (fun t => mul_self_nonneg (g t)) hint).mp hr
  filter_upwards [hae] with t ht
  exact mul_self_eq_zero.mp ht

/-- Canonical continuous interior values are determined pointwise by all coefficients. -/
theorem fermionic_fourier_zero_on_interval (g : ℝ → ℝ) (hg : Measurable g)
    (B : ℝ) (hb : ∀ t, |g t| ≤ B)
    (hc : ContinuousOn g (Ioo (0 : ℝ) β))
    (hz : ∀ n : ℤ, fourier β g (integerFrequency β (-n)) = 0) :
    EqOn g 0 (Ioo (0 : ℝ) β) := by
  have hae := fermionic_fourier_zero_ae β g hg B hb hz
  exact Measure.eqOn_Ioo_of_ae_eq volume
    (ae_restrict_of_ae_restrict_of_subset Ioo_subset_Ioc_self hae)
    hc continuousOn_const

/-- Bounded measurable kernels have honest, integrable Fourier integrands. -/
theorem fourier_integrable (g : ℝ → ℝ) (hg : Measurable g)
    (B : ℝ) (hb : ∀ t, |g t| ≤ B) (ω : ℝ) :
    IntervalIntegrable (fun t : ℝ => Complex.exp (Complex.I * (ω * t)) * (g t : ℂ))
      volume 0 β := by
  apply (intervalIntegrable_const (c := B)).mono_fun'
  · have hm : Measurable (fun t : ℝ => Complex.exp (Complex.I * (ω * t)) * (g t : ℂ)) := by
      fun_prop
    exact hm.aestronglyMeasurable
  · filter_upwards [] with t
    simpa [norm_mul, Complex.norm_exp] using hb t

theorem fourier_sub (g h : ℝ → ℝ) (hg : Measurable g) (hh : Measurable h)
    (B D : ℝ) (hb : ∀ t, |g t| ≤ B) (hd : ∀ t, |h t| ≤ D) (ω : ℝ) :
    fourier β (fun t => g t - h t) ω = fourier β g ω - fourier β h ω := by
  unfold fourier
  simp only [Complex.ofReal_sub, mul_sub]
  exact intervalIntegral.integral_sub (fourier_integrable β g hg B hb ω)
    (fourier_integrable β h hh D hd ω)

/-- Pointwise interior uniqueness from equal actual fermionic Fourier coefficients. -/
theorem fermionic_fourier_injective_on_interval (g h : ℝ → ℝ)
    (hg : Measurable g) (hh : Measurable h) (B D : ℝ)
    (hb : ∀ t, |g t| ≤ B) (hd : ∀ t, |h t| ≤ D)
    (hc : ContinuousOn (fun t => g t - h t) (Ioo (0 : ℝ) β))
    (he : ∀ n : ℤ, fourier β g (integerFrequency β (-n)) =
      fourier β h (integerFrequency β (-n))) : EqOn g h (Ioo (0 : ℝ) β) := by
  have hbound (t : ℝ) : |g t - h t| ≤ B + D :=
    (abs_sub (g t) (h t)).trans (add_le_add (hb t) (hd t))
  have hz (n : ℤ) : fourier β (fun t => g t - h t) (integerFrequency β (-n)) = 0 := by
    rw [fourier_sub β g h hg hh B D hb hd, he n, sub_self]
  have hzero := fermionic_fourier_zero_on_interval β (fun t => g t - h t)
    (hg.sub hh) (B + D) hbound hc hz
  intro t ht
  exact sub_eq_zero.mp (hzero ht)

end SYK.Continuum
