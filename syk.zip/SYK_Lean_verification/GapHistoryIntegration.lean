import GapCountCompositions
import DuhamelHistorySeries

/-!
# Genuine global ordered-history integration and convergent Dyson expansion

Finite chamber constancy implies Bochner integrability automatically, even
when collision or external-time boundary values are assigned arbitrarily.
The exponential gap series is then converted into actual global ordered-time
integrals, without assuming a Duhamel identity.
-/

noncomputable section
open scoped BigOperators
open MeasureTheory Set
open SYK.OrderedSimplexIntegral SYK.GapSimplexIntegral SYK.GapAssignmentPartition
open SYK.GapChamberCoordinates SYK.GapCountCompositions SYK.DuhamelHistory

namespace SYK.GapHistoryIntegration

/-- A finite chamberwise-constant history is integrable on the full ordered
simplex; no measurability of its arbitrary null-boundary values is required. -/
theorem integrableOn_of_chamber_constant {E : Type*} [NormedAddCommGroup E]
    {n k : ℕ} (t : Fin (k+1) → ℝ) (ht : Antitone t)
    (f : (Fin n → ℝ) → E) (F : (Fin k → ℕ) → E)
    (hconst : ∀ (g : Fin n → Fin k), Monotone g →
      ∀ u ∈ orderedAssignmentRegion t g, f u = F (gapCount g)) :
    IntegrableOn f (orderedSimplex n (t (Fin.last k)) (t 0)) := by
  classical
  have hi (g : Fin n → Fin k) : IntegrableOn f (orderedAssignmentRegion t g) := by
    by_cases hg : Monotone g
    · have hc : IntegrableOn (fun _ : Fin n → ℝ => F (gapCount g)) (orderedAssignmentRegion t g) :=
        integrableOn_const.mpr (Or.inr ((measure_mono inter_subset_left).trans_lt
          (orderedSimplex_volume_lt_top n _ _)))
      exact hc.congr_fun (fun u hu => (hconst g hg u hu).symm) (orderedAssignmentRegion_measurable t g)
    · rw [orderedAssignmentRegion_eq_empty_of_not_monotone t ht g hg]
      exact integrableOn_empty
  have hall : IntegrableOn f (⋃ g : Fin n → Fin k, orderedAssignmentRegion t g) := by
    simpa only [Finset.mem_univ, iUnion_true] using
      (integrableOn_finset_iUnion.mpr (fun g (_ : g ∈ (Finset.univ : Finset (Fin n → Fin k))) => hi g))
  exact hall.congr_set_ae (orderedAssignmentRegion_union_ae_simplex n t ht).symm

/-- Integrating any chamberwise-constant history gives the exact weighted
composition sum with no separate integrability premise. -/
theorem integral_simplex_of_chamber_constant {E : Type*}
    [NormedAddCommGroup E] [NormedSpace ℝ E] [CompleteSpace E] {n k : ℕ}
    (t : Fin (k+1) → ℝ) (ht : Antitone t) (f : (Fin n → ℝ) → E)
    (F : (Fin k → ℕ) → E)
    (hconst : ∀ (g : Fin n → Fin k), Monotone g →
      ∀ u ∈ orderedAssignmentRegion t g, f u = F (gapCount g)) :
    ∫ u in orderedSimplex n (t (Fin.last k)) (t 0), f u =
      ∑ r : CountComposition n k,
        (∏ j, (t j.castSucc-t j.succ)^(r.val j) / (r.val j).factorial) • F r.val :=
  integral_simplex_eq_sum_counts_of_chamber_constant t ht f
    (integrableOn_of_chamber_constant t ht f F hconst) F hconst

/-- A genuinely convergent gap series is the sum of the genuine global
ordered-time integrals whenever their actual free histories have the stated
chamber values. -/
theorem hasSum_ordered_integrals_of_gap_series {E : Type*}
    [NormedAddCommGroup E] [NormedSpace ℝ E] [CompleteSpace E] {k : ℕ}
    (t : Fin (k+1) → ℝ) (ht : Antitone t)
    (f : (n : ℕ) → (Fin n → ℝ) → E) (F : (Fin k → ℕ) → E) (v : E)
    (hconst : ∀ n (g : Fin n → Fin k), Monotone g →
      ∀ u ∈ orderedAssignmentRegion t g, f n u = F (gapCount g))
    (hseries : HasSum (fun r : Fin k → ℕ =>
      (∏ j, (t j.castSucc-t j.succ)^(r j) / (r j).factorial) • F r) v) :
    HasSum (fun n => ∫ u in orderedSimplex n (t (Fin.last k)) (t 0), f n u) v := by
  apply (hasSum_group_by_total hseries).congr_fun
  intro n
  exact integral_simplex_of_chamber_constant t ht (f n) F (hconst n)

/-- The exact matrix-exponential/Dyson bridge. The only history-specific
input is pointwise constancy on the actual external-time chambers. -/
theorem hasSum_matrix_history_integrals {A : Type*} [NormedRing A] [NormedAlgebra ℂ A]
    [NormOneClass A] [NormedSpace ℝ A] [CompleteSpace A] {k : ℕ}
    (t : Fin (k+1) → ℝ) (ht : Antitone t) (H U : Fin k → A)
    (f : (n : ℕ) → (Fin n → ℝ) → A)
    (hconst : ∀ n (g : Fin n → Fin k), Monotone g →
      ∀ u ∈ orderedAssignmentRegion t g,
        f n u = orderedProduct (fun j => (H j)^(gapCount g j) * U j)) :
    HasSum (fun n => ∫ u in orderedSimplex n (t (Fin.last k)) (t 0), f n u)
      (orderedProduct (fun j => NormedSpace.exp ℂ (((t j.castSucc-t j.succ : ℝ) : ℂ) • H j) * U j)) := by
  apply hasSum_ordered_integrals_of_gap_series t ht f
    (fun r => orderedProduct (fun j => (H j)^(r j) * U j)) _ hconst
  apply (hasSum_exponential_history
    (fun j => ((t j.castSucc-t j.succ : ℝ) : ℂ) • H j) U).congr_fun
  intro r
  have h := (integral_gapSimplex_const r (fun j => t j.succ) (fun j => t j.castSucc)
    (fun j => ht (by simp [Fin.le_iff_val_le_val]))
    ((List.ofFn (fun j => (H j)^(r j) * U j)).prod)).symm.trans
      (integral_gap_history r (fun j => t j.succ) (fun j => t j.castSucc)
        (fun j => ht (by simp [Fin.le_iff_val_le_val])) H U)
  simpa only [orderedProduct, expCoefficient] using h

end SYK.GapHistoryIntegration
