import FundamentalWardContacts
import PolynomialWardExtension
import WickWardNormalization

noncomputable section
open MeasureTheory
namespace SYK.FundamentalWardBridge
open ThermalWick WickVertexIntegrals ContinuumWickSeries FundamentalWardContacts

def interactionPairs (β : ℝ) (hβ : 0<β) (t : Time β) (x : ℝ×ℝ) : List (Time β×Time β) :=
  List.replicate 3 (timeRepresentative β hβ x.1,timeRepresentative β hβ x.2) ++
    [(timeRepresentative β hβ x.2,t)]

def interactionPolynomial (β : ℝ) (hβ : 0<β) (s t : Time β) (x : ℝ×ℝ) : Polynomial β :=
  (Thermal.kernel β s.val (timeRepresentative β hβ x.1).val:ℂ) •
    coordinateProduct (interactionPairs β hβ t x)

def remainder {β : ℝ} (s t : Time β) : Polynomial β :=
  MvPolynomial.X (s,t) - MvPolynomial.C (Thermal.kernel β s.val t.val:ℂ)

/-- Exact normalized listed Wick identities imply the genuine polynomial Ward
identity, with the actual time measure and explicit contact derivation. -/
theorem polynomial_ward_of_numerator (β : ℝ) (hβ : 0<β)
    (L : Polynomial β →ₗ[ℂ] ℂ) (F : List (Time β×Time β)→ℂ)
    (hz : F []≠0) (hF : ∀ ps, L (coordinateProduct ps)=F ps/F [])
    (a b : ℂ) (s t : Time β)
    (hI : ∀ Q, Integrable (fun x => L (Q*interactionPolynomial β hβ s t x)) (pairMeasure β))
    (h : ∀ ps, F ((s,t)::ps)=(Thermal.kernel β s.val t.val:ℂ)*F ps+
      a*contactValue F s t ps []+b*(∫ x,
        (Thermal.kernel β s.val (timeRepresentative β hβ x.1).val:ℂ)*
          F (ps++interactionPairs β hβ t x) ∂pairMeasure β))
    (Q : Polynomial β) :
    L (Q*remainder s t) = b*(∫ x, L (Q*interactionPolynomial β hβ s t x) ∂pairMeasure β)+
      a*L (contact s t Q) := by
  apply PolynomialWardExtension.ward_of_list_products (pairMeasure β) L
    (interactionPolynomial β hβ s t) hI (remainder s t) (contact s t).toLinearMap b a
    (Q := Q)
  intro ps
  change L (coordinateProduct ps*remainder s t) =
    b*(∫ x, L (coordinateProduct ps*interactionPolynomial β hβ s t x) ∂pairMeasure β)+
      a*L (contact s t (coordinateProduct ps))
  have hn := normalized_ward_of_numerator (pairMeasure β) F s t ps
    (fun x => (Thermal.kernel β s.val (timeRepresentative β hβ x.1).val:ℂ))
    (fun x => ps++interactionPairs β hβ t x) a b hz (h ps)
  have hr : L (coordinateProduct ps*remainder s t) =
      F ((s,t)::ps)/F []-(Thermal.kernel β s.val t.val:ℂ)*(F ps/F []) := by
    simp only [remainder,mul_sub,map_sub]
    have hm : coordinateProduct ps*MvPolynomial.X (s,t)=coordinateProduct ((s,t)::ps) := by
      simp only [coordinateProduct,List.map_cons,List.prod_cons]; ring
    rw [hm,hF,mul_comm _ (MvPolynomial.C _),MvPolynomial.C_mul',map_smul,smul_eq_mul,hF]
  rw [hr,hn]
  have he (x : ℝ×ℝ) : L (coordinateProduct ps*interactionPolynomial β hβ s t x)=
      (Thermal.kernel β s.val (timeRepresentative β hβ x.1).val:ℂ)*
        (F (ps++interactionPairs β hβ t x)/F []) := by
    simp only [interactionPolynomial,mul_smul_comm,map_smul,smul_eq_mul]
    rw [show coordinateProduct ps*coordinateProduct (interactionPairs β hβ t x)=
      coordinateProduct (ps++interactionPairs β hβ t x) by
        simp only [coordinateProduct,List.map_append,List.prod_append],hF]
  simp_rw [he]
  rw [FundamentalWardContacts.eval_contact]
  congr 2
  congr 1
  funext l
  exact (hF l).symm

end SYK.FundamentalWardBridge
