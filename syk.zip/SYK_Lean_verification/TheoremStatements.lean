import SYKLean

/-! Human-readable hypotheses and conclusions for the strongest starter bridges.
These are ordinary theorem inputs, even when the foundational axiom audit passes.
-/
set_option pp.universes false
set_option format.width 110

#check @SYK.ClosedIdeal.inserted_residuals_annihilate_closed_ideal
#check @SYK.every_generator_mem_of_analytic_orbits
#check @SYK.Translation.halving_action_is_trivial
#check @SYK.coefficients_equal_of_parseval_and_dyson
#check @SYK.pressure_limit_of_dominated_derivatives
#check @SYK.kernelCenterField_analyticAt
#check @SYK.norm_kernelCenterField_sub_le

#check @SYK.GaussianDisorder.integrable_exp_sum_abs
#check @SYK.AntiCommuting.density_sum_sq_le_one

#check @SYK.TranslationContraction.reflection_translation_class_stationary

#check @SYK.Thermal.covariance_antiperiodic
#check @SYK.Thermal.covariance_on_interval

#check @SYK.AntiCommuting.density_normalized_common_triple_bound

#check @SYK.Wick.Covariance.expectation_ward_split
#check @SYK.Wick.Covariance.expectation_radical_inserted
#check @SYK.Wick.kernel_expectation_two

#check @SYK.Majorana.chi_car
#check @SYK.Majorana.norm_quartic
#check @SYK.Majorana.pressure_zero

#check @SYK.Gibbs.syk_partition_re_pos
#check @SYK.GNS.GNSHilbert.representationStarAlgHom
#check @SYK.GNS.GNSHilbert.represented_observables_stationary

#check @SYK.ThermalWick.expectation_collective_square
#check @SYK.kernelCenterField_ode_analytic

#check @SYK.kernelCenterField_eval_mem_of_open_seed

#check @SYK.Microscopic.partitionFunction_integrable
#check @SYK.Microscopic.annealedPressure_free
#check @SYK.Thermal.integral_halfSign_difference_le

#check @SYK.Gibbs.abs_log_syk_partition_le

#check SYK.Continuum.PhysicalSolution
#check SYK.Continuum.PressureConvergence
#check @SYK.Continuum.sd_zero_iff

#check @SYK.Microscopic.log_partitionFunction_integrable
#check @SYK.Microscopic.quenchedPressure_le_annealedPressure
#check @SYK.Spectral.gns_spectral_integral

#check @SYK.FreeWick.weyl_block_thermal_trace

#check @SYK.Continuum.free_continuum_case

#check @SYK.DuhamelTrace.hasDerivAt_syk_log_partition_direction_at
#check @SYK.Ward.exponential_ward_of_summable

#check @SYK.kernelConvolutionCLM_norm_le
#check @SYK.concreteKernel_ode_analytic

#check @SYK.Continuum.fermionic_parseval
#check @SYK.Continuum.fermionic_fourier_injective_on_interval

#check @SYK.Microscopic.disorder_scale

#check @SYK.WeightedKernelAlgebra.remainder_continuous

#check @SYK.ThermalRP.annealedValue_nonnegative

#check @SYK.GaussianIBP.syk_partition_stein_variance

#check @SYK.Continuum.hankel_fourier_test

#check @SYK.Continuum.stationary_convolution

#check @SYK.integratedSD_center_analytic

#check @SYK.AnnealedDifferentiation.tendsto_annealedPressure_zero

#check @SYK.KernelResidualAlgebra.finalCovariance_eq_free

#check @SYK.Continuum.physical_scalar_dyson

#check @SYK.reflectKernel_convolution

#check @SYK.ThermalBound.majorana_even_history_bound

#check @SYK.ConvolutionRegularity.G_cube_convolution_left

#check @SYK.integratedSD_all_coordinates_mem_half_algebra

#check @SYK.GlobalGradient.hasDerivAt_logPartition_line

#check @SYK.HankelPositivity.fermionic_sine_integral_nonnegative

#check @SYK.Continuum.physical_integer_dyson

#check @SYK.Continuum.physical_unique

#check @SYK.KernelQuotientAnalyticity.thermalFinal_all_coordinates_mem_half_algebra

#check @SYK.KernelCoordinateGeneration.finalKernel_diagonal

#check @SYK.Continuum.hankel_sd_unique

#check @SYK.LogPartitionDifferential.continuous_logGradient

#check @SYK.ProductGaussianMGF.integral_exp_dot_le

#check @SYK.GaussianRotation.hasDerivAt_rotateArray_first

#check @SYK.Interacting.timeProduct_bound

#check @SYK.MomentCompactness.endpoint_moment_subsequence

#check @SYK.ThermalHalfGeneration.closed_half_algebra_eq_top

#check @SYK.KernelAlgebraActions.completedMoment_invariant

#check @SYK.PisierPath.exp_sub_le_integral_exp_derivative

#check @SYK.Continuum.paired_product_log

#check @SYK.Continuum.physical_closed_bounded_pointwise

#check @SYK.KernelQuotientActions.firstReflection_translation

#check @SYK.GaussianConcentration.integral_exp_logPartition_difference_le

#check @SYK.FreeWeyl.expectation_collectiveMonomial_bound

#check @SYK.PressureGap.quenched_limit_of_annealed_limit

#check @SYK.Continuum.periodic_uniform_subsequence

#check @SYK.KernelSelection.exists_physical_factorization

#check @SYK.MomentSymmetry.collectiveMoment_list_perm

#check @SYK.KernelFinalActions.finalFunctional_invariant_of_polynomial

#check @SYK.Continuum.physical_centered_lipschitz

#check @SYK.Continuum.physical_quartic_integral_continuous

#check @SYK.KernelActionBridge.actionData

#check @SYK.ThermalKernelSelection.exists_physical_factorization

#check @SYK.MomentMeasurability.measurable_collectiveMoment

#check @SYK.DiagonalFredholm.compression_determinants_along_cofinal

#check @SYK.Continuum.physical_left_endpoint

#check @SYK.KernelConstructedSelection.exists_physical_factorization

#check @SYK.Continuum.onShellAction_bounds

#check @SYK.NilpotentSymmetricSum.sum_fourth_eq_twentyfour_mul_subsets

#check @SYK.ThermalWick.gaussian_quartic_coefficient

#check @SYK.MixedIncrement.mixed_product_bound

#check @SYK.Continuum.couplingPressure_eq_relative_log_action

#check @SYK.FourierOperators.physicalDeterminant_log

#check @SYK.ThermalEndpointLift.liftFunctional_seam_diagonal

#check @SYK.MomentLimit.functional_limit_inserted_relations

#check @SYK.FourierOperators.couplingPressure_eq_physical_operator_action

#check @SYK.OrderedSimplexIntegral.integral_constant_interaction

#check @SYK.GaussianCoefficient.integral_monomial_odd

#check @SYK.MixedIncrement.replacement_of_inserted_ward

#check @SYK.OrderedCubePartition.integral_cube_eq_factorial_smul_ordered

#check @SYK.DuhamelHistory.hasSum_integral_gapCoefficient

#check @SYK.GapSimplexIntegral.integral_gap_history_observable

#check @SYK.MixedIncrement.momentLinear_substitution

#check @SYK.GaussianCoefficient.disorder_polynomial_coefficient

#check @SYK.ThermalMomentTransport.thermalLimit_bound

#check @SYK.WeylBlocks.weylTransfer_append

#check @SYK.GapAssignmentPartition.integral_simplex_eq_sum_monotone_assignments

#check @SYK.DuhamelVertex.wick_inserted_vertex_history_bound

#check @SYK.ThermalWeightedState.actual_moments_to_regularityState

#check @SYK.SymmetricMomentFunctional.functional_tuple_prod

#check @SYK.ExponentialMomentSeries.hasDerivAt_log_real_value

#check @SYK.GapChamberCoordinates.integral_orderedAssignmentRegion_eq_blocks

#check @SYK.SpectralFredholm.spectralDeterminant_conjugate

#check @SYK.PhysicalFredholm.couplingPressure_eq_ordinary_fredholm_action

#check @SYK.WeylReflection.weyl_numerator_reflected_nonnegative

#check @SYK.ThermalResidualState.actual_moments_to_finalState

#check @SYK.GapCountCompositions.integral_simplex_eq_sum_counts_of_chamber_constant

#check @SYK.WickVertexIntegrals.vertexFunctional_product

#check @SYK.coordinate_defect_max_bound

#check @SYK.MixedIncrement.finite_centered_tuple_modulus

#check @SYK.BilocalReflection.collectiveNumerator_reflected_sum

#check @SYK.GapHistoryIntegration.hasSum_matrix_history_integrals

#check @SYK.ExponentialMomentSeries.hasDerivAt_value_integrated_insertion

#check @SYK.ThermalRPTransport.finalState_translation_tests

#check @SYK.PolynomialRP.actualPolynomial_reflection_im_zero

#check @SYK.FourthMomentIntegral.timeMeasure_eq_closed

#check @SYK.ContinuumWickSeries.numerator_norm_summable

#check @SYK.PartitionWick.averagedWick_sum_re_pos

#check @SYK.ThermalMicroscopicPositivity.actualThermal_odd_test_eq

#check @SYK.ContinuumWickSeries.hasDerivAt_numerator_insertion

#check @SYK.PressureLimitAssembly.pressure_convergence_from_quartic_response

#check @SYK.ThermalPairCube.integral_pairTimes

#check @SYK.OddWeylReflection.odd_numerator_reflected_sum

#check @SYK.ContinuumWickSeries.integral_pair_swap

#check @SYK.ExponentialMomentSeries.integrable_value

#check @SYK.ThermalWardLimit.actual_centered_modulus

#check @SYK.WeylTranslation.actualThermalPolynomial_translation

#check @SYK.OddPolynomialRP.actualPolynomial_odd_im_zero

#check @SYK.Continuum.freeEnergy_convergence_J

#check @SYK.ThermalWardSymmetry.rightWard_of_left

#check @SYK.ThermalMicroscopicOddPositivity.actualThermal_half_odd_nonnegative

#check @SYK.CollectiveMomentConvergence.exists_physical_actual_moment_limit

#check @SYK.ContinuumWickSeries.hasDerivAt_seriesPressure

#check @SYK.ContinuumWickSeries.normalizedPartner_product

#check @SYK.WardInteraction.markedIntegrand_eq

#check @SYK.InsertedWickSeries.fieldNumerator_norm_summable

#check @SYK.FiniteWardSymmetry.finiteWardControl_of_left

#check @SYK.RealWardContacts.centered_contact_bound

#check @SYK.ContinuumWickSeries.contactValue_hasSum

#check @SYK.ActualFiniteWardControl.finiteWardControl_of_exact_left

#check @SYK.MicroscopicMomentConvergence.exists_physical_actual_moment_limit_of_left

#check @SYK.WickGaussianRegrouping.numerator_empty_re_pos

#check @SYK.PolynomialWardExtension.ward_of_list_products

#check @SYK.FundamentalWardContacts.eval_contact

#check @SYK.WardInteraction.marked_kernel_swap

#check @SYK.GapHistoryIntegrationAE.hasSum_ordered_integrals_of_gap_series

#check @SYK.SignedWardReduction.actualFundamental_list

#check @SYK.ContinuumWickSeries.integral_interaction_marked

#check @SYK.MicroscopicResponseBridge.hasDerivAt_annealedPressure_fourth

#check @SYK.ActualMomentLimit.ActualMomentLimits.fourth

#check @SYK.FieldDisorderSeries.fieldNumerator_eq_integral_disorderSeries

#check @SYK.ContinuumWickSeries.normalized_ward_of_numerator

#check @SYK.FundamentalWardBridge.polynomial_ward_of_numerator

#check @SYK.SignedWardReduction.actualWard_of_fundamental

#check @SYK.ContinuumWickSeries.integral_markedIntegrand

#check @SYK.CollectiveFieldExpansion.numerator_eq_field_sum

#check @SYK.SignedWardReduction.pairIntegral_eq_interval

#check @SYK.RepresentationIndependence.pressure_convergence_transfer

#check @SYK.FundamentalMomentIntegrability.actualFundamental_ward_integrable

#check @SYK.ActualWickPressure.hasDerivAt_annealedPressure_series

#check @SYK.ActualFourthResponse.hasDerivAt_annealedPressure

#check @SYK.ActualWickChamber.weightedVertexIntegrand_chamber

#check @SYK.ActualWickWard.exact_left_of_wick_identities

#check @SYK.InsertedWickSymmetry.annealedWeyl_eq_average

#check @SYK.ComplexFourierOperatorAction.physicalPerturbation_complex_integral_action

#check @SYK.ActualCorrespondenceConsequences.pressure_response_of_list_correspondence

#check @SYK.ComplexFourierOperatorAction.physical_operator_unique

#check @SYK.ContinuumSYKMain.MainConclusion.arbitrary_representation

#check @SYK.ActualWickChamberSeries.hasSum_sorted_disorderCoefficient

#check @SYK.CollectiveWeylAverage.normalized_flavor_average_ratio

#check @SYK.ContinuumSYKMain.MainConclusion.arbitrary_representation_freeEnergy

#check @SYK.ContinuumWickSeries.numerator_ward

#check @SYK.ActualWickCorrespondence.normalizedMoment_eq_collectiveMoment

#check @SYK.SYKMainTheorem.existsUnique_physical_solution

#check @SYK.ActualMicroscopicIdentities.finite_ward_control

#check @SYK.MomentRepresentationIndependence.moment_convergence_transfer

-- Exact public conclusion structures, to audit semantic scope as well as axioms.
#check @SYK.SYKMainTheorem.continuum_free_energy
#print SYK.ContinuumSYKMain.MainConclusion
#print SYK.ContinuumSYKMain.PhysicalConclusion
#print SYK.ContinuumSYKMain.FredholmConclusion
#print SYK.ActualMomentLimit.ActualMomentLimits
#print SYK.Continuum.PhysicalSolution
#print SYK.Continuum.PressureConvergence

#check @SYK.AbstractRepresentation.quenchedPressure_eq

#check @SYK.ContinuumSYKMain.MainConclusion.abstract_freeEnergy

#check @SYK.AbstractRepresentation.collectiveNumerator_integrable

#check @SYK.SYKMainTheorem.continuum_free_energy_abstract

#check @SYK.SYKMainTheorem.continuum_free_energy_abstract
#print SYK.ContinuumSYKMain.AbstractRealizationConclusion
