import FourierConvolution

noncomputable section
open MeasureTheory Set
open scoped NNReal
namespace SYK.Continuum

/-- The kernel equation in the manuscript reduces to an actual scalar convolution equation. -/
theorem sd_scalar_equation (β : ℝ) (hβ : 0 < β) (lam : ℝ≥0) (g : ℝ → ℝ)
    (ha : ∀ t, g (t + β) = -g t) (hSD : SDEquation β lam g) (t : ℝ) :
    g t = Thermal.covariance β t + (lam : ℝ) *
      scalarConvolution β (scalarConvolution β (Thermal.covariance β) (fun u => (g u)^3)) g t := by
  have hcube (u : ℝ) : (g (u + β))^3 = -(g u)^3 := by rw [ha]; ring
  have hi (s v : ℝ) : convolution β (Thermal.kernel β) (cube (stationaryKernel g)) s v =
      scalarConvolution β (Thermal.covariance β) (fun u => (g u)^3) (s - v) :=
    stationary_convolution β (Thermal.covariance β) (fun u => (g u)^3)
      (Thermal.covariance_antiperiodic β hβ.ne') hcube s v
  have he := hSD t 0
  change g (t - 0) = Thermal.covariance β (t - 0) + (lam : ℝ) *
    (∫ v in (0 : ℝ)..β,
      convolution β (Thermal.kernel β) (cube (stationaryKernel g)) t v * g (v - 0)) at he
  simp_rw [hi, sub_zero] at he
  exact he

/-- Fourier linearity with an actual bounded measurable integrand. -/
theorem fourier_add_mul (β : ℝ) (hβ : 0 < β) (g h : ℝ → ℝ)
    (hg : Measurable g) (hh : Measurable h) (B D : ℝ)
    (hb : ∀ t, |g t| ≤ B) (hd : ∀ t, |h t| ≤ D) (c ω : ℝ) :
    fourier β (fun t => g t + c * h t) ω = fourier β g ω + (c : ℂ) * fourier β h ω := by
  letI : Fact (0 < β) := ⟨hβ⟩
  unfold fourier
  simp only [Complex.ofReal_add, Complex.ofReal_mul, mul_add]
  have hi := (fourier_integrable β h hh D hd ω).const_mul (c : ℂ)
  have he (t : ℝ) : Complex.exp (Complex.I * ((ω : ℂ) * (t : ℂ))) * ((c : ℂ) * (h t : ℂ)) =
      (c : ℂ) * (Complex.exp (Complex.I * ((ω : ℂ) * (t : ℂ))) * (h t : ℂ)) := by ring
  simp_rw [he]
  rw [intervalIntegral.integral_add (fourier_integrable β g hg B hb ω) hi,
    intervalIntegral.integral_const_mul]

/-- The Fourier SD identity is derived from the actual continuum equation. -/
theorem fourier_sd (β : ℝ) (hβ : 0 < β) (lam : ℝ≥0) (g : ℝ → ℝ)
    (hg : Measurable g) (B : ℝ) (hb : ∀ t, |g t| ≤ B)
    (ha : ∀ t, g (t + β) = -g t) (hSD : SDEquation β lam g) (n : ℕ) :
    fourier β g (frequency β n) = Complex.I / (frequency β n : ℂ) +
      (lam : ℝ) * ((Complex.I / (frequency β n : ℂ)) *
        fourier β (fun t => (g t)^3) (frequency β n) * fourier β g (frequency β n)) := by
  let c := Thermal.covariance β
  let q := fun t => (g t)^3
  let k := scalarConvolution β c q
  let l := scalarConvolution β k g
  let K := β * ((1 / 2 : ℝ) * B^3)
  have hc : Measurable c := Thermal.covariance_measurable β
  have hq : Measurable q := hg.pow_const 3
  have hcb : ∀ t, |c t| ≤ (1 / 2 : ℝ) := Thermal.abs_covariance_le β
  have hqb (t : ℝ) : |q t| ≤ B^3 := by
    dsimp [q]
    rw [abs_pow]
    exact pow_le_pow_left₀ (abs_nonneg _) (hb t) 3
  have hca : ∀ t, c (t + β) = -c t := Thermal.covariance_antiperiodic β hβ.ne'
  have hk : Measurable k := scalarConvolution_measurable β hβ.le c q hc hq
  have hkb : ∀ t, |k t| ≤ K := scalarConvolution_bound β hβ.le c q _ _ hcb hqb
  have hka : ∀ t, k (t + β) = -k t := scalarConvolution_antiperiodic β c q hca
  have hl : Measurable l := scalarConvolution_measurable β hβ.le k g hk hg
  have hlb : ∀ t, |l t| ≤ β * (K * B) := scalarConvolution_bound β hβ.le k g K B hkb hb
  have hp : wave (frequency β n) β = -1 := by
    simpa [wave, mul_assoc] using frequency_phase β hβ n
  have he : g = fun t => c t + (lam : ℝ) * l t := by
    funext t
    exact sd_scalar_equation β hβ lam g ha hSD t
  calc
    fourier β g (frequency β n) = fourier β c (frequency β n) +
        (lam : ℂ) * fourier β l (frequency β n) := by
      conv_lhs => rw [he]
      exact fourier_add_mul β hβ c l hc hl _ _ hcb hlb (lam : ℝ) _
    _ = fourier β c (frequency β n) + (lam : ℂ) *
        (fourier β k (frequency β n) * fourier β g (frequency β n)) := by
      rw [fourier_scalarConvolution β hβ _ k g hk hg K B hkb hb hka hp]
    _ = fourier β c (frequency β n) + (lam : ℂ) *
        (fourier β c (frequency β n) * fourier β q (frequency β n) *
          fourier β g (frequency β n)) := by
      rw [fourier_scalarConvolution β hβ _ c q hc hq _ _ hcb hqb hca hp]
    _ = _ := by rw [free_fourier β hβ n]

/-- The scalar Dyson relation, with the self-energy coefficient computed from g³. -/
theorem scalar_dyson (β : ℝ) (hβ : 0 < β) (lam : ℝ≥0) (g : ℝ → ℝ)
    (hg : Measurable g) (B : ℝ) (hb : ∀ t, |g t| ≤ B)
    (ha : ∀ t, g (t + β) = -g t) (hsym : ∀ t, g (β - t) = g t)
    (hSD : SDEquation β lam g) (n : ℕ) (x : ℝ)
    (hx : fourier β g (frequency β n) = Complex.I * x) :
    x * (frequency β n + (lam : ℝ) *
      (fourier β (fun t => (g t)^3) (frequency β n)).im) = 1 := by
  have hz := fourier_re_zero β hβ (fun t => (g t)^3)
    (fun t => by dsimp only; rw [hsym]) n
  have hq : fourier β (fun t => (g t)^3) (frequency β n) =
      Complex.I * (fourier β (fun t => (g t)^3) (frequency β n)).im := by
    apply Complex.ext <;> simp [hz]
  have he := fourier_sd β hβ lam g hg B hb ha hSD n
  rw [hx, hq] at he
  have hi := congrArg Complex.im he
  simp only [Complex.add_im, Complex.mul_im, Complex.mul_re, Complex.I_re,
    Complex.I_im, Complex.ofReal_re, Complex.ofReal_im, Complex.div_ofReal_re,
    Complex.div_ofReal_im, zero_mul, mul_zero, zero_div, one_mul, zero_add,
    add_zero, sub_zero, zero_sub] at hi
  have hw := (frequency_pos β hβ n).ne'
  field_simp [hw] at hi
  nlinarith

/-- Every physical solution supplies the exact scalar Dyson identities. -/
theorem physical_scalar_dyson (β : ℝ) (hβ : 0 < β) (lam : ℝ≥0)
    (g : ℝ → ℝ) (hphys : PhysicalSolution β lam g) (n : ℕ) :
    ∃ x : ℝ, 0 < x ∧ fourier β g (frequency β n) = Complex.I * x ∧
      x * (frequency β n + (lam : ℝ) *
        (fourier β (fun t => (g t)^3) (frequency β n)).im) = 1 := by
  rcases hphys with ⟨hg, ⟨B, hb⟩, ha, _, hsym, hsign, hSD⟩
  rcases hsign n with ⟨x, hx, he⟩
  exact ⟨x, hx, he, scalar_dyson β hβ lam g hg B hb ha hsym hSD n x he⟩

end SYK.Continuum
