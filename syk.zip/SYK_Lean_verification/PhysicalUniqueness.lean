import FermionicSigns
import Uniqueness

noncomputable section
open MeasureTheory Set
open scoped NNReal ComplexConjugate
namespace SYK.Continuum

/-- Same-sign nonzero coefficients suffice for the reciprocal Dyson comparison,
including the negative fermionic frequencies. -/
theorem signed_dyson_pairing (ω x z y w : ℝ) (hxz : 0 < x*z)
    (hx : x*(ω+y)=1) (hz : z*(ω+w)=1) :
    (x-z)*(y-w) = -((x-z)^2/(x*z)) := by
  have hn : x*z ≠ 0 := hxz.ne'
  have hxn : x ≠ 0 := (mul_ne_zero_iff.mp hn).1
  have hzn : z ≠ 0 := (mul_ne_zero_iff.mp hn).2
  have hy : y = 1 / x - ω := by
    apply (eq_sub_iff_add_eq).mpr
    apply (eq_div_iff hxn).mpr
    nlinarith [hx]
  have hw : w = 1 / z - ω := by
    apply (eq_sub_iff_add_eq).mpr
    apply (eq_div_iff hzn).mpr
    nlinarith [hz]
  rw [hy, hw]
  field_simp
  <;> ring

/-- A convergent nonpositive Fourier pairing with a nonnegative total vanishes termwise. -/
theorem pairing_terms_vanish {ι : Type*} (a : ι → ℝ) (s : ℝ)
    (hs : HasSum a s) (ha : ∀ i, a i ≤ 0) (hpos : 0 ≤ s) (i : ι) : a i = 0 := by
  have hn := hs.summable.neg
  have hsum : (∑' j, -a j) ≤ 0 := by
    rw [tsum_neg, hs.tsum_eq]
    linarith
  have hterm : -a i ≤ 0 := (hn.le_tsum i (fun j _ => neg_nonneg.mpr (ha j))).trans hsum
  linarith [ha i]

variable (β : ℝ) [Fact (0 < β)]

/-- The two-kernel pairing has a genuinely convergent Fourier representation. -/
theorem physical_pairing_parseval (lam : ℝ≥0) (g h : ℝ → ℝ)
    (hg : PhysicalSolution β lam g) (hh : PhysicalSolution β lam h) :
    HasSum (fun n : ℤ =>
      ((fourier β g (integerFrequency β (-n))).im -
        (fourier β h (integerFrequency β (-n))).im) *
      ((lam : ℝ) * (fourier β (fun t => (g t)^3) (integerFrequency β (-n))).im -
        (lam : ℝ) * (fourier β (fun t => (h t)^3) (integerFrequency β (-n))).im))
      ((lam : ℝ) * β * ∫ t in (0 : ℝ)..β, (g t - h t) * ((g t)^3 - (h t)^3)) := by
  rcases hg with ⟨hgm, ⟨B, hb⟩, _, _, hgsym, _, _⟩
  rcases hh with ⟨hhm, ⟨D, hd⟩, _, _, hhsym, _, _⟩
  have hgb (t : ℝ) : |(g t)^3| ≤ B^3 := by
    rw [abs_pow]
    exact pow_le_pow_left₀ (abs_nonneg _) (hb t) 3
  have hhb (t : ℝ) : |(h t)^3| ≤ D^3 := by
    rw [abs_pow]
    exact pow_le_pow_left₀ (abs_nonneg _) (hd t) 3
  have hdb (t : ℝ) : |g t-h t| ≤ B+D := (abs_sub _ _).trans (add_le_add (hb t) (hd t))
  have hqb (t : ℝ) : |(g t)^3-(h t)^3| ≤ B^3+D^3 :=
    (abs_sub _ _).trans (add_le_add (hgb t) (hhb t))
  have hgs : ∀ t, (g (β-t))^3 = (g t)^3 := fun t => by rw [hgsym]
  have hhs : ∀ t, (h (β-t))^3 = (h t)^3 := fun t => by rw [hhsym]
  have hs := fermionic_parseval β (fun t => g t-h t) (fun t => (g t)^3-(h t)^3)
    (hgm.sub hhm) ((hgm.pow_const 3).sub (hhm.pow_const 3))
    (B+D) (B^3+D^3) hdb hqb
  have hc (n : ℤ) : conj (fourier β (fun t => g t-h t) (integerFrequency β (-n))) *
      fourier β (fun t => (g t)^3-(h t)^3) (integerFrequency β (-n)) =
      (((fourier β g (integerFrequency β (-n))).im -
        (fourier β h (integerFrequency β (-n))).im) *
      ((fourier β (fun t => (g t)^3) (integerFrequency β (-n))).im -
        (fourier β (fun t => (h t)^3) (integerFrequency β (-n))).im) : ℝ) := by
    rw [fourier_sub β g h hgm hhm B D hb hd,
      fourier_sub β (fun t => (g t)^3) (fun t => (h t)^3)
        (hgm.pow_const 3) (hhm.pow_const 3) (B^3) (D^3) hgb hhb]
    rw [integer_fourier_imaginary β g hgsym (-n),
      integer_fourier_imaginary β h hhsym (-n),
      integer_fourier_imaginary β (fun t => (g t)^3) hgs (-n),
      integer_fourier_imaginary β (fun t => (h t)^3) hhs (-n)]
    apply Complex.ext <;> simp [Complex.mul_re, Complex.mul_im] <;> ring
  simp_rw [hc] at hs
  have he : (∫ t in (0 : ℝ)..β, (((g t-h t)*((g t)^3-(h t)^3) : ℝ) : ℂ)) =
      ((∫ t in (0 : ℝ)..β, (g t-h t)*((g t)^3-(h t)^3) : ℝ) : ℂ) := by
    simp only [intervalIntegral, integral_complex_ofReal, Complex.ofReal_sub]
  rw [he] at hs
  have hr := hs.mapL Complex.reCLM
  simp only [Complex.reCLM_apply, Complex.ofReal_re, Complex.mul_re,
    Complex.ofReal_im, mul_zero, sub_zero] at hr
  convert hr.mul_left (lam : ℝ) using 1
  · ext n
    ring
  · ring

/-- All coefficients of two actual physical SD solutions agree.
Parseval, summability, and the Dyson equations are proved inputs, not hypotheses. -/
theorem physical_fourier_coefficients_equal (lam : ℝ≥0) (g h : ℝ → ℝ)
    (hg : PhysicalSolution β lam g) (hh : PhysicalSolution β lam h) (n : ℤ) :
    fourier β g (integerFrequency β (-n)) = fourier β h (integerFrequency β (-n)) := by
  let x := fun k : ℤ => (fourier β g (integerFrequency β (-k))).im
  let z := fun k : ℤ => (fourier β h (integerFrequency β (-k))).im
  let y := fun k : ℤ => (lam : ℝ) * (fourier β (fun t => (g t)^3) (integerFrequency β (-k))).im
  let w := fun k : ℤ => (lam : ℝ) * (fourier β (fun t => (h t)^3) (integerFrequency β (-k))).im
  let a := fun k => (x k-z k)*(y k-w k)
  have hp (k : ℤ) : 0 < x k*z k := physical_integer_product_pos β lam g h hg hh (-k)
  have hid (k : ℤ) : a k = -((x k-z k)^2/(x k*z k)) :=
    signed_dyson_pairing _ _ _ _ _ (hp k)
      (physical_integer_dyson β lam g hg (-k)) (physical_integer_dyson β lam h hh (-k))
  have hn (k : ℤ) : a k ≤ 0 := by
    rw [hid]
    exact neg_nonpos.mpr (div_nonneg (sq_nonneg _) (hp k).le)
  have htotal : 0 ≤ (lam : ℝ) * β *
      ∫ t in (0 : ℝ)..β, (g t-h t)*((g t)^3-(h t)^3) := by
    apply mul_nonneg (mul_nonneg lam.coe_nonneg (Fact.out : 0 < β).le)
    apply intervalIntegral.integral_nonneg (Fact.out : 0 < β).le
    intro t _
    exact SYK.cubic_pairing_nonnegative _ _
  have hz := pairing_terms_vanish a _ (physical_pairing_parseval β lam g h hg hh) hn htotal n
  rw [hid] at hz
  have hsq : (x n-z n)^2 = 0 := by
    have hdiv : (x n-z n)^2/(x n*z n) = 0 := neg_eq_zero.mp hz
    exact (div_eq_zero_iff.mp hdiv).resolve_right (hp n).ne'
  have hxz : x n = z n := sub_eq_zero.mp (sq_eq_zero_iff.mp hsq)
  rw [integer_fourier_imaginary β g hg.2.2.2.2.1 (-n),
    integer_fourier_imaginary β h hh.2.2.2.2.1 (-n)]
  exact congrArg (fun r : ℝ => Complex.I * r) hxz

/-- Physical SD solutions are already unique almost everywhere on one thermal period. -/
theorem physical_unique_ae (lam : ℝ≥0) (g h : ℝ → ℝ)
    (hg : PhysicalSolution β lam g) (hh : PhysicalSolution β lam h) :
    g =ᵐ[volume.restrict (Ioc (0 : ℝ) β)] h := by
  obtain ⟨B, hb⟩ := hg.2.1
  obtain ⟨D, hd⟩ := hh.2.1
  have hbound (t : ℝ) : |g t-h t| ≤ B+D := (abs_sub _ _).trans (add_le_add (hb t) (hd t))
  have hz (n : ℤ) : fourier β (fun t => g t-h t) (integerFrequency β (-n)) = 0 := by
    rw [fourier_sub β g h hg.1 hh.1 B D hb hd,
      physical_fourier_coefficients_equal β lam g h hg hh n, sub_self]
  have he := fermionic_fourier_zero_ae β (fun t => g t-h t) (hg.1.sub hh.1) (B+D) hbound hz
  filter_upwards [he] with t ht
  exact sub_eq_zero.mp ht

/-- The canonical integral equation upgrades a.e. equality to equality at every endpoint. -/
theorem physical_unique (lam : ℝ≥0) (g h : ℝ → ℝ)
    (hg : PhysicalSolution β lam g) (hh : PhysicalSolution β lam h) : g = h := by
  have hβ : 0 < β := Fact.out
  have hae := physical_unique_ae β lam g h hg hh
  have hk : scalarConvolution β (Thermal.covariance β) (fun t => (g t)^3) =
      scalarConvolution β (Thermal.covariance β) (fun t => (h t)^3) := by
    funext s
    unfold scalarConvolution
    simp only [intervalIntegral.integral_of_le hβ.le]
    apply integral_congr_ae
    filter_upwards [hae] with t ht
    rw [ht]
  funext s
  rw [sd_scalar_equation β hβ lam g hg.2.2.1 hg.2.2.2.2.2.2,
    sd_scalar_equation β hβ lam h hh.2.2.1 hh.2.2.2.2.2.2, hk]
  congr 2
  unfold scalarConvolution
  simp only [intervalIntegral.integral_of_le hβ.le]
  apply integral_congr_ae
  filter_upwards [hae] with t ht
  rw [ht]

end SYK.Continuum
