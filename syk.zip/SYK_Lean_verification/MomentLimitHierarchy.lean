import MomentCompactness
import MomentSymmetry
import MomentMeasurability
import WeightedKernelAlgebra
import Mathlib.Data.Finsupp.Multiset
import Mathlib.MeasureTheory.Integral.DominatedConvergence

/-!
# Polynomial moments and their subsequential limits

The finite-size polynomial functional below is constructed from the actual
annealed, Weyl-ordered collective moments. Its coefficient bound and
normalization follow from the microscopic theorems. Centering always means
subtracting the prescribed free covariance, not the interacting mean.

Asymptotic endpoint estimates, inserted finite-size Ward equations and the
exterior identification of reflection positivity are distinct microscopic
obligations. No such assertion is built into a definition of a limiting state.

The raw Icc-indexed operator moments distinguish the two real times 0 and β.
They are therefore not automatically the midpoint-consistent thermal-circle
family at a seam. The raw compactness result below is conditional on its stated
modulus; its application at the seam requires the corrected signed-representative
functional. The generic functional theorem at the end is provided for precisely
that correction, without assuming a false raw endpoint identification.
-/

noncomputable section
open scoped BigOperators NNReal
open Filter Set Topology MvPolynomial MeasureTheory

namespace SYK.MomentLimit
open MomentCompactness WeightedKernelAlgebra

abbrev EndpointPair (β : ℝ) := (Icc (0 : ℝ) β) × (Icc (0 : ℝ) β)
abbrev CoordinatePolynomial (β : ℝ) := MvPolynomial (EndpointPair β) ℂ

/-- A fixed enumeration of a commutative monomial, including multiplicities. -/
def monomialList {ι : Type*} (e : ι →₀ ℕ) : List ι := e.toMultiset.toList

@[simp] theorem monomialList_zero {ι : Type*} : monomialList (0 : ι →₀ ℕ) = [] := by
  simp [monomialList]

@[simp] theorem monomialList_length {ι : Type*} (e : ι →₀ ℕ) :
    (monomialList e).length = e.sum (fun _ n => n) := by
  simp [monomialList, Finsupp.card_toMultiset, Function.id_def]

/-- The canonical ordered tuple representing a commutative monomial. -/
def monomialTuple {ι : Type*} (e : ι →₀ ℕ) : Fin (monomialList e).length → ι :=
  (monomialList e).get

/-- The product along the chosen enumeration is exactly the original
commutative monomial. No permutation invariance is assumed here. -/
theorem monomial_eq_tuple_prod {ι : Type*} (e : ι →₀ ℕ) :
    (MvPolynomial.monomial e (1 : ℂ)) =
      ∏ i, MvPolynomial.X (monomialTuple e i) := by
  classical
  have hprod : ∀ e : ι →₀ ℕ,
      (e.toMultiset.map (MvPolynomial.X : ι → MvPolynomial ι ℂ)).prod =
        e.prod (fun i n => (MvPolynomial.X i : MvPolynomial ι ℂ)^n) := by
    intro e
    refine e.induction ?_ ?_
    · simp
    · intro a n e _ _ ih
      rw [Finsupp.toMultiset_add, Multiset.map_add, Multiset.prod_add, ih,
        Finsupp.toMultiset_single, ← Multiset.coe_mapAddMonoidHom,
        (Multiset.mapAddMonoidHom _).map_nsmul, Multiset.prod_nsmul,
        Finsupp.prod_add_index' (fun _ => pow_zero _) (fun _ => pow_add _)]
      simp
  rw [MvPolynomial.monomial_eq, map_one, one_mul, ← hprod]
  rw [← List.prod_ofFn, show List.ofFn (fun i => MvPolynomial.X (monomialTuple e i)) =
      (monomialList e).map MvPolynomial.X by
        rw [← Function.comp_def, ← List.map_ofFn]
        simp only [monomialTuple, List.ofFn_get]]
  rw [← Multiset.prod_coe, ← Multiset.map_coe]
  simp only [monomialList, Multiset.coe_toList]

/-- Actual collective moment on a finite list of endpoint pairs. -/
def actualList (d : ℕ) (β : ℝ) (lam : ℝ≥0) (l : List (EndpointPair β)) : ℂ :=
  Interacting.collectiveMoment d β lam (endpointValues l.get)

/-- Actual finite-size monomial value, evaluated on its canonical tuple. -/
def actualMonomial (d : ℕ) (β : ℝ) (lam : ℝ≥0) (e : EndpointPair β →₀ ℕ) : ℂ :=
  actualList d β lam (monomialList e)

/-- The concrete linear functional obtained by extending actual monomial
moments coefficientwise. -/
def actualPolynomial (d : ℕ) (β : ℝ) (lam : ℝ≥0) : CoordinatePolynomial β →ₗ[ℂ] ℂ :=
  Finsupp.linearCombination ℂ (actualMonomial d β lam)

@[simp] theorem actualPolynomial_monomial (d : ℕ) (β : ℝ) (lam : ℝ≥0)
    (e : EndpointPair β →₀ ℕ) (c : ℂ) :
    actualPolynomial d β lam (MvPolynomial.monomial e c) = c * actualMonomial d β lam e := by
  exact Finsupp.linearCombination_single ..

@[simp] theorem actualMonomial_zero (d : ℕ) (β : ℝ) (lam : ℝ≥0) :
    actualMonomial d β lam 0 = 1 := by
  rw [actualMonomial, monomialList_zero]
  exact Interacting.collectiveMoment_empty d β lam _

@[simp] theorem actualPolynomial_one (d : ℕ) (β : ℝ) (lam : ℝ≥0) :
    actualPolynomial d β lam 1 = 1 := by
  change actualPolynomial d β lam (MvPolynomial.monomial 0 1) = 1
  rw [actualPolynomial_monomial, actualMonomial_zero, mul_one]

/-- The sharp microscopic bound gives every canonical monomial its weight. -/
theorem actualMonomial_bound (d : ℕ) (hd : 0 < d) {β : ℝ} (hβ : 0 < β)
    (lam : ℝ≥0) (e : EndpointPair β →₀ ℕ) :
    ‖actualMonomial d β lam e‖ ≤ (1 / 2 : ℝ)^(monomialList e).length := by
  apply Interacting.collectiveMoment_bound d hd hβ lam
  intro i
  exact endpointValues_mem (monomialTuple e) i

/-- Constant coordinate weight for the sharp `b = 1/2` moment estimate. -/
def coordinateWeights (β : ℝ) : Weights (EndpointPair β) :=
  ⟨fun _ => 1/2, fun _ => by norm_num⟩

theorem constant_monomialWeight {ι : Type*} (b : ℝ) (e : ι →₀ ℕ) :
    monomialWeight (fun _ : ι => b) e = b^(monomialList e).length := by
  classical
  simp only [monomialWeight, Finsupp.prod, monomialList_length, Finsupp.sum]
  rw [Finset.prod_pow_eq_pow_sum]

/-- A bound on every actual finite-size polynomial, with the explicit
weighted coefficient norm. -/
theorem actualPolynomial_bound (d : ℕ) (hd : 0 < d) {β : ℝ} (hβ : 0 < β)
    (lam : ℝ≥0) (P : CoordinatePolynomial β) :
    ‖actualPolynomial d β lam P‖ ≤ coefficientNorm (fun _ => 1/2) P := by
  exact WeightedPolynomial.momentLinear_bound (coordinateWeights β)
    (actualMonomial d β lam) (fun e => by
      rw [show monomialWeight (coordinateWeights β).value e =
        (1/2 : ℝ)^(monomialList e).length from constant_monomialWeight (1/2) e]
      exact actualMonomial_bound d hd hβ lam e)
    (WeightedPolynomial.ofPolynomial (coordinateWeights β) P)

/-- The prescribed scalar free covariance at an endpoint pair. -/
def freeCoordinate (β : ℝ) (p : EndpointPair β) : ℂ :=
  (Thermal.kernel β p.1.val p.2.val : ℝ)

theorem norm_freeCoordinate_le (β : ℝ) (p : EndpointPair β) :
    ‖freeCoordinate β p‖ ≤ (1/2 : ℝ) := by
  simpa only [freeCoordinate, Complex.norm_real, Real.norm_eq_abs, Thermal.kernel] using
    Thermal.abs_covariance_le β (p.1.val - p.2.val)

/-- The centered coordinate is literally `G - C 1`. -/
def remainderCoordinate (β : ℝ) (p : EndpointPair β) : CoordinatePolynomial β :=
  MvPolynomial.X p - MvPolynomial.C (freeCoordinate β p)

/-- Substitute `R = G-C` into a coordinate polynomial. -/
def subtractFree (β : ℝ) : CoordinatePolynomial β →ₐ[ℂ] CoordinatePolynomial β :=
  MvPolynomial.aeval (remainderCoordinate β)

/-- The inverse substitution `G = R+C`. -/
def addFree (β : ℝ) : CoordinatePolynomial β →ₐ[ℂ] CoordinatePolynomial β :=
  MvPolynomial.aeval (fun p => MvPolynomial.X p + MvPolynomial.C (freeCoordinate β p))

@[simp] theorem subtractFree_addFree (β : ℝ) (P : CoordinatePolynomial β) :
    subtractFree β (addFree β P) = P := by
  have h : (subtractFree β).comp (addFree β) = AlgHom.id ℂ (CoordinatePolynomial β) := by
    ext p
    simp [subtractFree, addFree, remainderCoordinate]
  exact congrArg (fun F : CoordinatePolynomial β →ₐ[ℂ] CoordinatePolynomial β => F P) h

@[simp] theorem addFree_subtractFree (β : ℝ) (P : CoordinatePolynomial β) :
    addFree β (subtractFree β P) = P := by
  have h : (addFree β).comp (subtractFree β) = AlgHom.id ℂ (CoordinatePolynomial β) := by
    ext p
    simp [subtractFree, addFree, remainderCoordinate]
  exact congrArg (fun F : CoordinatePolynomial β →ₐ[ℂ] CoordinatePolynomial β => F P) h

/-- The actual centered degree-k moment, formed by a finite polynomial
expansion, with all endpoint contact conventions inherited from the Weyl sum. -/
def centeredMoment (d : ℕ) (β : ℝ) (lam : ℝ≥0) {k : ℕ} (p : EndpointCube β k) : ℂ :=
  actualPolynomial d β lam (∏ i, remainderCoordinate β (p i))

theorem remainderCoordinate_coefficientNorm_le (β : ℝ) (p : EndpointPair β) :
    coefficientNorm (fun _ => 1/2) (remainderCoordinate β p) ≤ 1 := by
  let w := coordinateWeights β
  change ‖WeightedPolynomial.ofPolynomial w (remainderCoordinate β p)‖ ≤ 1
  have h := norm_sub_le (WeightedPolynomial.ofPolynomial w (MvPolynomial.X p))
    (WeightedPolynomial.ofPolynomial w (MvPolynomial.C (freeCoordinate β p)))
  rw [WeightedPolynomial.norm_X, WeightedPolynomial.norm_C] at h
  exact h.trans (by have hc := norm_freeCoordinate_le β p; dsimp [w, coordinateWeights]; linarith)

/-- Every centered monomial is uniformly bounded by one, proved from the
sharp microscopic G-moment bound and the actual subtraction of C. -/
theorem centeredMoment_bound (d : ℕ) (hd : 0 < d) {β : ℝ} (hβ : 0 < β)
    (lam : ℝ≥0) {k : ℕ} (p : EndpointCube β k) : ‖centeredMoment d β lam p‖ ≤ 1 := by
  apply (actualPolynomial_bound d hd hβ lam _).trans
  let w := coordinateWeights β
  change ‖∏ i, (WeightedPolynomial.ofPolynomial w (remainderCoordinate β (p i)))‖ ≤ 1
  calc
    _ ≤ ∏ i, ‖WeightedPolynomial.ofPolynomial w (remainderCoordinate β (p i))‖ := Finset.norm_prod_le _ _
    _ ≤ ∏ _i : Fin k, (1 : ℝ) := Finset.prod_le_prod (fun _ _ => norm_nonneg _) (fun i _ =>
      remainderCoordinate_coefficientNorm_le β (p i))
    _ = 1 := by simp

@[simp] theorem centeredMoment_empty (d : ℕ) (β : ℝ) (lam : ℝ≥0) (p : EndpointCube β 0) :
    centeredMoment d β lam p = 1 := by
  simp [centeredMoment]

/-- The actual polynomial functional in centered variables. -/
def actualCenteredPolynomial (d : ℕ) (β : ℝ) (lam : ℝ≥0) :
    CoordinatePolynomial β →ₗ[ℂ] ℂ :=
  (actualPolynomial d β lam).comp (subtractFree β).toLinearMap

@[simp] theorem actualCenteredPolynomial_addFree (d : ℕ) (β : ℝ) (lam : ℝ≥0)
    (P : CoordinatePolynomial β) :
    actualCenteredPolynomial d β lam (addFree β P) = actualPolynomial d β lam P := by
  simp [actualCenteredPolynomial]

@[simp] theorem actualCenteredPolynomial_monomial (d : ℕ) (β : ℝ) (lam : ℝ≥0)
    (e : EndpointPair β →₀ ℕ) (c : ℂ) :
    actualCenteredPolynomial d β lam (MvPolynomial.monomial e c) =
      c * centeredMoment d β lam (monomialTuple e) := by
  have hm : MvPolynomial.monomial e c = c • MvPolynomial.monomial e (1 : ℂ) := by
    simp only [MvPolynomial.smul_monomial, smul_eq_mul, mul_one]
  rw [hm, map_smul, smul_eq_mul]
  congr 1
  change actualPolynomial d β lam (subtractFree β (MvPolynomial.monomial e 1)) = _
  rw [monomial_eq_tuple_prod, map_prod]
  simp only [subtractFree, aeval_X]
  rfl

/-- The candidate centered polynomial functional obtained from all the
simultaneously extracted centered moment limits. -/
def limitCenteredPolynomial (β : ℝ) (g : ∀ k, EndpointCube β k → ℂ) :
    CoordinatePolynomial β →ₗ[ℂ] ℂ :=
  Finsupp.linearCombination ℂ (fun e => g (monomialList e).length (monomialTuple e))

@[simp] theorem limitCenteredPolynomial_monomial (β : ℝ)
    (g : ∀ k, EndpointCube β k → ℂ) (e : EndpointPair β →₀ ℕ) (c : ℂ) :
    limitCenteredPolynomial β g (MvPolynomial.monomial e c) =
      c * g (monomialList e).length (monomialTuple e) := Finsupp.linearCombination_single ..

/-- Restore `G = C+R` after forming the centered limit functional. -/
def limitPolynomial (β : ℝ) (g : ∀ k, EndpointCube β k → ℂ) :
    CoordinatePolynomial β →ₗ[ℂ] ℂ :=
  (limitCenteredPolynomial β g).comp (addFree β).toLinearMap

/-- Simultaneous convergence of centered moments implies convergence of the
actual centered polynomial functional for every finite coordinate polynomial. -/
theorem centered_polynomial_tendsto (β : ℝ) (lam : ℝ≥0) (d : ℕ → ℕ)
    (g : ∀ k, EndpointCube β k → ℂ)
    (hg : ∀ k, TendstoUniformly (fun n => centeredMoment (d n) β lam) (g k) atTop)
    (P : CoordinatePolynomial β) :
    Tendsto (fun n => actualCenteredPolynomial (d n) β lam P) atTop
      (𝓝 (limitCenteredPolynomial β g P)) := by
  induction P using MvPolynomial.induction_on' with
  | monomial e c =>
    simp only [actualCenteredPolynomial_monomial, limitCenteredPolynomial_monomial]
    exact tendsto_const_nhds.mul ((hg _).tendsto_at (monomialTuple e))
  | add P Q hP hQ => simpa only [map_add] using hP.add hQ

/-- Every uncentered actual polynomial converges along the same sequence;
no additional extraction is needed after the scalar covariance is restored. -/
theorem actual_polynomial_tendsto (β : ℝ) (lam : ℝ≥0) (d : ℕ → ℕ)
    (g : ∀ k, EndpointCube β k → ℂ)
    (hg : ∀ k, TendstoUniformly (fun n => centeredMoment (d n) β lam) (g k) atTop)
    (P : CoordinatePolynomial β) :
    Tendsto (fun n => actualPolynomial (d n) β lam P) atTop
      (𝓝 (limitPolynomial β g P)) := by
  simpa only [actualCenteredPolynomial_addFree] using
    centered_polynomial_tendsto β lam d g hg (addFree β P)

/-- The subsequential limit is normalized because the actual finite-size
functional is normalized, rather than by an assumption on the limit. -/
theorem limitPolynomial_one (β : ℝ) (lam : ℝ≥0) (d : ℕ → ℕ)
    (g : ∀ k, EndpointCube β k → ℂ)
    (hg : ∀ k, TendstoUniformly (fun n => centeredMoment (d n) β lam) (g k) atTop) :
    limitPolynomial β g 1 = 1 := by
  exact tendsto_nhds_unique (actual_polynomial_tendsto β lam d g hg 1)
    (by simpa only [actualPolynomial_one] using (tendsto_const_nhds :
      Tendsto (fun _ : ℕ => (1 : ℂ)) atTop (𝓝 1)))

/-- The sharp coefficient bound is retained by the limiting functional. -/
theorem limitPolynomial_bound {β : ℝ} (hβ : 0 < β) (lam : ℝ≥0)
    (d : ℕ → ℕ) (hd : ∀ n, 0 < d n) (g : ∀ k, EndpointCube β k → ℂ)
    (hg : ∀ k, TendstoUniformly (fun n => centeredMoment (d n) β lam) (g k) atTop)
    (P : CoordinatePolynomial β) :
    ‖limitPolynomial β g P‖ ≤ coefficientNorm (fun _ => 1/2) P := by
  exact le_of_tendsto (actual_polynomial_tendsto β lam d g hg P |>.norm)
    (Eventually.of_forall (fun n => actualPolynomial_bound (d n) (hd n) hβ lam P))

/-- A genuine common subsequential polynomial limit of the actual moments.
The endpoint-defect estimate is the explicit remaining microscopic premise;
uniform boundedness and polynomial normalization are already discharged. -/
theorem actual_centered_subsequence {β : ℝ} (hβ : 0 < β) (lam : ℝ≥0)
    (d : ℕ → ℕ) (hd : ∀ n, 0 < d n) (K : ℕ → ℝ) (hK : ∀ k, 0 ≤ K k)
    (ε : ℕ → ℕ → ℝ) (hε : ∀ k, Tendsto (ε k) atTop (𝓝 0))
    (hmod : ∀ k n (p q : EndpointCube β k),
      ‖centeredMoment (d n) β lam p - centeredMoment (d n) β lam q‖ ≤
        K k * dist p q + ε k n) :
    ∃ (φ : ℕ → ℕ) (g : ∀ k, EndpointCube β k → ℂ), StrictMono φ ∧
      (∀ k, TendstoUniformly (fun n => centeredMoment (d (φ n)) β lam) (g k) atTop) ∧
      (∀ k, LipschitzWith ⟨K k, hK k⟩ (g k)) ∧ (∀ k p, ‖g k p‖ ≤ 1) ∧
      (∀ P, Tendsto (fun n => actualPolynomial (d (φ n)) β lam P) atTop
        (𝓝 (limitPolynomial β g P))) ∧
      limitPolynomial β g 1 = 1 ∧
      (∀ P, ‖limitPolynomial β g P‖ ≤ coefficientNorm (fun _ => 1/2) P) := by
  letI : Nonempty (Icc (0 : ℝ) β) := ⟨⟨0, le_refl _, hβ.le⟩⟩
  obtain ⟨φ, g, hφ, hg, hLip, hbound⟩ := complex_diagonal_uniform_subsequence
    (EndpointCube β) (fun k n => centeredMoment (d n) β lam (k := k))
    (fun _ => 1) K hK ε hε (fun _ n p => centeredMoment_bound (d n) (hd n) hβ lam p) hmod
  exact ⟨φ, g, hφ, hg, hLip, hbound,
    actual_polynomial_tendsto β lam (d ∘ φ) g hg,
    limitPolynomial_one β lam (d ∘ φ) g hg,
    limitPolynomial_bound hβ lam (d ∘ φ) (fun n => hd (φ n)) g hg⟩

/-- The contact scale tends to zero along every sequence of dimensions
escaping to infinity. -/
theorem contact_scale_tendsto (d : ℕ → ℕ) (hd : Tendsto d atTop atTop) (A : ℝ) :
    Tendsto (fun n => A / (d n : ℝ)) atTop (𝓝 0) :=
  (tendsto_const_div_atTop_nhds_zero_nat A).comp hd

/-- Every contact remainder controlled by the actual inverse dimension
vanishes; no limiting contact equation is postulated. -/
theorem contact_error_tendsto (d : ℕ → ℕ) (hd : Tendsto d atTop atTop)
    (A : ℝ) (E : ℕ → ℂ) (hE : ∀ n, ‖E n‖ ≤ A / (d n : ℝ)) :
    Tendsto E atTop (𝓝 0) := by
  apply tendsto_zero_iff_norm_tendsto_zero.mpr
  exact squeeze_zero (fun _ => norm_nonneg _) hE (contact_scale_tendsto d hd A)

/-- Finite-size polynomial identities are inherited by the actual limiting
functional. This applies to each already-established symmetry or relation. -/
theorem limitPolynomial_eq_of_actual (β : ℝ) (lam : ℝ≥0) (d : ℕ → ℕ)
    (g : ∀ k, EndpointCube β k → ℂ)
    (hg : ∀ k, TendstoUniformly (fun n => centeredMoment (d n) β lam) (g k) atTop)
    (P Q : CoordinatePolynomial β)
    (hPQ : ∀ n, actualPolynomial (d n) β lam P = actualPolynomial (d n) β lam Q) :
    limitPolynomial β g P = limitPolynomial β g Q := by
  exact tendsto_nhds_unique (actual_polynomial_tendsto β lam d g hg P)
    ((actual_polynomial_tendsto β lam d g hg Q).congr (fun n => (hPQ n).symm))

/-- Positivity passes by closedness of the real half-line. Its microscopic
reflection-polynomial interpretation is a separate, explicit premise. -/
theorem limitPolynomial_re_nonnegative (β : ℝ) (lam : ℝ≥0) (d : ℕ → ℕ)
    (g : ∀ k, EndpointCube β k → ℂ)
    (hg : ∀ k, TendstoUniformly (fun n => centeredMoment (d n) β lam) (g k) atTop)
    (P : CoordinatePolynomial β) (hP : ∀ n, 0 ≤ (actualPolynomial (d n) β lam P).re) :
    0 ≤ (limitPolynomial β g P).re := by
  exact le_of_tendsto_of_tendsto tendsto_const_nhds
    (Complex.continuous_re.tendsto _ |>.comp (actual_polynomial_tendsto β lam d g hg P))
    (Eventually.of_forall hP)

theorem limitPolynomial_im_zero (β : ℝ) (lam : ℝ≥0) (d : ℕ → ℕ)
    (g : ∀ k, EndpointCube β k → ℂ)
    (hg : ∀ k, TendstoUniformly (fun n => centeredMoment (d n) β lam) (g k) atTop)
    (P : CoordinatePolynomial β) (hP : ∀ n, (actualPolynomial (d n) β lam P).im = 0) :
    (limitPolynomial β g P).im = 0 := by
  apply tendsto_nhds_unique
    (Complex.continuous_im.tendsto _ |>.comp (actual_polynomial_tendsto β lam d g hg P))
  simpa only [Function.comp_def, hP] using (tendsto_const_nhds : Tendsto (fun _ : ℕ => (0 : ℝ)) atTop (𝓝 0))

/-- Passage through an actual Bochner integral follows from the proved sharp
polynomial bound and dominated convergence. Finite-size continuity is not used. -/
theorem polynomial_integral_tendsto {Ω : Type*} [MeasurableSpace Ω] (μ : Measure Ω)
    {β : ℝ} (hβ : 0 < β) (lam : ℝ≥0) (d : ℕ → ℕ) (hd : ∀ n, 0 < d n)
    (g : ∀ k, EndpointCube β k → ℂ)
    (hg : ∀ k, TendstoUniformly (fun n => centeredMoment (d n) β lam) (g k) atTop)
    (P : Ω → CoordinatePolynomial β) (b : Ω → ℝ) (hb : Integrable b μ)
    (hbound : ∀ x, coefficientNorm (fun _ => 1/2) (P x) ≤ b x)
    (hMeas : ∀ n, AEStronglyMeasurable (fun x => actualPolynomial (d n) β lam (P x)) μ) :
    Tendsto (fun n => ∫ x, actualPolynomial (d n) β lam (P x) ∂μ) atTop
      (𝓝 (∫ x, limitPolynomial β g (P x) ∂μ)) := by
  apply tendsto_integral_of_dominated_convergence b hMeas hb
  · intro n
    exact Eventually.of_forall (fun x =>
      (actualPolynomial_bound (d n) (hd n) hβ lam (P x)).trans (hbound x))
  · exact Eventually.of_forall (fun x => actual_polynomial_tendsto β lam d g hg (P x))

/-- Generic inserted Ward passage: the finite-size identity is supplied,
but its contact error is eliminated here by its inverse-dimension estimate,
and the integral passes by the actual polynomial convergence. -/
theorem inserted_ward_limit {Ω : Type*} [MeasurableSpace Ω] (μ : Measure Ω)
    {β : ℝ} (hβ : 0 < β) (lam : ℝ≥0) (d : ℕ → ℕ) (hd : ∀ n, 0 < d n)
    (hd_top : Tendsto d atTop atTop) (g : ∀ k, EndpointCube β k → ℂ)
    (hg : ∀ k, TendstoUniformly (fun n => centeredMoment (d n) β lam) (g k) atTop)
    (P : CoordinatePolynomial β) (Q : Ω → CoordinatePolynomial β)
    (b : Ω → ℝ) (hb : Integrable b μ)
    (hbound : ∀ x, coefficientNorm (fun _ => 1/2) (Q x) ≤ b x)
    (hMeas : ∀ n, AEStronglyMeasurable (fun x => actualPolynomial (d n) β lam (Q x)) μ)
    (c : ℂ) (E : ℕ → ℂ) (A : ℝ) (hE : ∀ n, ‖E n‖ ≤ A / (d n : ℝ))
    (hWard : ∀ n, actualPolynomial (d n) β lam P =
      c * (∫ x, actualPolynomial (d n) β lam (Q x) ∂μ) + E n) :
    limitPolynomial β g P = c * ∫ x, limitPolynomial β g (Q x) ∂μ := by
  have hright := ((tendsto_const_nhds (x := c)).mul
    (polynomial_integral_tendsto μ hβ lam d hd g hg Q b hb hbound hMeas)).add
      (contact_error_tendsto d hd_top A E hE)
  simp only [add_zero] at hright
  exact tendsto_nhds_unique (actual_polynomial_tendsto β lam d g hg P)
    (hright.congr (fun n => (hWard n).symm))

/-- The canonical enumeration differs from any list of the same
commutative monomial only by an actual list permutation. -/
theorem monomialList_perm {ι : Type*} [DecidableEq ι] (l : List ι) :
    (monomialList (Multiset.toFinsupp (l : Multiset ι))).Perm l := by
  apply Multiset.coe_eq_coe.mp
  simp only [monomialList, Multiset.coe_toList, Multiset.toFinsupp_toMultiset]

/-- The actual collective moment is insensitive to enumeration of bilocal
factors. This uses the proved microscopic permutation theorem. -/
theorem actualList_perm (d : ℕ) (β : ℝ) (lam : ℝ≥0)
    {l r : List (EndpointPair β)} (h : l.Perm r) :
    actualList d β lam l = actualList d β lam r := by
  obtain ⟨e, he⟩ := MomentSymmetry.listPerm_get_equiv h
  apply MomentSymmetry.collectiveMoment_eq_of_equiv d β lam
    (endpointValues l.get) (endpointValues r.get) e
  intro i
  exact congrArg (fun p : EndpointPair β => (p.1.val, p.2.val)) (he i)

/-- The coefficientwise polynomial functional agrees with the actual
Weyl-ordered collective moment for every listed coordinate product. -/
theorem actualPolynomial_list_prod (d : ℕ) (β : ℝ) (lam : ℝ≥0)
    (l : List (EndpointPair β)) :
    actualPolynomial d β lam ((l.map MvPolynomial.X).prod) = actualList d β lam l := by
  classical
  let e := Multiset.toFinsupp (l : Multiset (EndpointPair β))
  have hp := monomialList_perm l
  have he : MvPolynomial.monomial e (1 : ℂ) = (l.map MvPolynomial.X).prod := by
    rw [monomial_eq_tuple_prod, ← List.prod_ofFn]
    have hlist : List.ofFn (fun i => MvPolynomial.X (monomialTuple e i)) =
        (monomialList e).map (MvPolynomial.X : EndpointPair β → CoordinatePolynomial β) := by
      rw [← Function.comp_def, ← List.map_ofFn]
      simp only [monomialTuple, List.ofFn_get]
    rw [hlist]
    exact (hp.map MvPolynomial.X).prod_eq
  rw [← he, actualPolynomial_monomial, one_mul]
  exact actualList_perm d β lam hp

/-- The polynomial functional recovers every actual tuple moment, including
coincident and repeated endpoint pairs. -/
theorem actualPolynomial_tuple_prod (d : ℕ) (β : ℝ) (lam : ℝ≥0) {k : ℕ}
    (p : EndpointCube β k) :
    actualPolynomial d β lam (∏ i, MvPolynomial.X (p i)) =
      Interacting.collectiveMoment d β lam (endpointValues p) := by
  have h := actualPolynomial_list_prod d β lam (List.ofFn p)
  rw [List.map_ofFn, List.prod_ofFn] at h
  simp only [Function.comp_def] at h
  rw [h]
  apply MomentSymmetry.collectiveMoment_eq_of_equiv d β lam
    (endpointValues (List.ofFn p).get) (endpointValues p) (finCongr (List.length_ofFn (f := p)))
  intro i
  simp [endpointValues, List.get_ofFn, finCongr, Fin.cast]

/-- The subsequential polynomial moments inherit the sharp degree bound,
with their actual finite-size interpretation already proved. -/
theorem limitPolynomial_tuple_bound {β : ℝ} (hβ : 0 < β) (lam : ℝ≥0)
    (d : ℕ → ℕ) (hd : ∀ n, 0 < d n) (g : ∀ k, EndpointCube β k → ℂ)
    (hg : ∀ k, TendstoUniformly (fun n => centeredMoment (d n) β lam) (g k) atTop)
    {k : ℕ} (p : EndpointCube β k) :
    ‖limitPolynomial β g (∏ i, MvPolynomial.X (p i))‖ ≤ (1/2 : ℝ)^k := by
  apply le_of_tendsto (actual_polynomial_tendsto β lam d g hg _ |>.norm)
  apply Eventually.of_forall
  intro n
  rw [actualPolynomial_tuple_prod]
  exact Interacting.collectiveMoment_bound (d n) (hd n) hβ lam (endpointValues p)
    (endpointValues_mem p)

/-- The limiting functional evaluates every centered coordinate product as
the simultaneously extracted centered moment, regardless of enumeration. -/
theorem limitPolynomial_centered_prod (β : ℝ) (lam : ℝ≥0) (d : ℕ → ℕ)
    (g : ∀ k, EndpointCube β k → ℂ)
    (hg : ∀ k, TendstoUniformly (fun n => centeredMoment (d n) β lam) (g k) atTop)
    {k : ℕ} (p : EndpointCube β k) :
    limitPolynomial β g (∏ i, remainderCoordinate β (p i)) = g k p := by
  exact tendsto_nhds_unique (actual_polynomial_tendsto β lam d g hg _)
    ((hg k).tendsto_at p)

/-- Multiplication by a fixed bounded scalar function preserves uniform
convergence. The multiplier may itself have contact jumps. -/
theorem uniform_bounded_mul {Z : Type*} (a : Z → ℂ) (B : ℝ) (hB : 0 ≤ B)
    (ha : ∀ z, ‖a z‖ ≤ B) {f : ℕ → Z → ℂ} {g : Z → ℂ}
    (h : TendstoUniformly f g atTop) :
    TendstoUniformly (fun n z => a z * f n z) (fun z => a z * g z) atTop := by
  apply Metric.tendstoUniformly_iff.mpr
  intro η hη
  have hden : 0 < B + 1 := by linarith
  filter_upwards [Metric.tendstoUniformly_iff.mp h (η / (B+1)) (div_pos hη hden)] with n hn
  intro z
  calc
    dist (a z * g z) (a z * f n z) = ‖a z‖ * dist (g z) (f n z) := by
      simp only [dist_eq_norm, ← mul_sub, norm_mul]
    _ ≤ (B + 1) * dist (g z) (f n z) :=
      mul_le_mul_of_nonneg_right ((ha z).trans (by linarith)) dist_nonneg
    _ < (B + 1) * (η / (B+1)) := mul_lt_mul_of_pos_left (hn z) hden
    _ = η := mul_div_cancel₀ η hden.ne'

/-- One algebraic step in restoring G from R: every finite-size and limiting
linear functional obeys this identity before taking any limit. -/
theorem mixed_product_succ {β : ℝ} (L : CoordinatePolynomial β →ₗ[ℂ] ℂ)
    {k l : ℕ} (p : EndpointCube β k) (q : EndpointCube β (l+1)) :
    L ((∏ i, remainderCoordinate β (p i)) * ∏ i, MvPolynomial.X (q i)) =
      L ((∏ i, remainderCoordinate β (Fin.snoc (α := fun _ => EndpointPair β) p (q 0) i)) *
        ∏ i : Fin l, MvPolynomial.X (q i.succ)) +
      freeCoordinate β (q 0) * L ((∏ i, remainderCoordinate β (p i)) *
        ∏ i : Fin l, MvPolynomial.X (q i.succ)) := by
  have hpoly : ((∏ i, remainderCoordinate β (p i)) * ∏ i, MvPolynomial.X (q i)) =
      ((∏ i, remainderCoordinate β (Fin.snoc (α := fun _ => EndpointPair β) p (q 0) i)) *
        ∏ i : Fin l, MvPolynomial.X (q i.succ)) +
      freeCoordinate β (q 0) • ((∏ i, remainderCoordinate β (p i)) *
        ∏ i : Fin l, MvPolynomial.X (q i.succ)) := by
    rw [Fin.prod_univ_succ (fun i => MvPolynomial.X (q i)),
      Fin.prod_univ_castSucc (fun i => remainderCoordinate β (Fin.snoc (α := fun _ => EndpointPair β) p (q 0) i))]
    simp only [Fin.snoc_castSucc, Fin.snoc_last, remainderCoordinate,
      ← MvPolynomial.C_mul']
    ring
  rw [hpoly, map_add, map_smul, smul_eq_mul]

/-- Uniform convergence survives restoring any fixed number of G factors,
with arbitrary endpoint substitutions. No continuity of C or of the finite-N
moments is assumed. -/
theorem uniform_mixed_products (β : ℝ) (lam : ℝ≥0) (d : ℕ → ℕ)
    (g : ∀ k, EndpointCube β k → ℂ)
    (hg : ∀ k, TendstoUniformly (fun n => centeredMoment (d n) β lam) (g k) atTop)
    {Z : Type*} (l k : ℕ) (p : Z → EndpointCube β k) (q : Z → EndpointCube β l) :
    TendstoUniformly
      (fun n z => actualPolynomial (d n) β lam
        ((∏ i, remainderCoordinate β (p z i)) * ∏ i, MvPolynomial.X (q z i)))
      (fun z => limitPolynomial β g
        ((∏ i, remainderCoordinate β (p z i)) * ∏ i, MvPolynomial.X (q z i))) atTop := by
  induction l generalizing k with
  | zero =>
    simpa only [Fin.prod_univ_zero, mul_one,
      limitPolynomial_centered_prod β lam d g hg] using (hg k).comp p
  | succ l ih =>
    have h₁ := ih (k+1) (fun z => Fin.snoc (α := fun _ => EndpointPair β) (p z) (q z 0)) (fun z i => q z i.succ)
    have h₂ := uniform_bounded_mul (fun z => freeCoordinate β (q z 0)) (1/2)
      (by norm_num) (fun z => norm_freeCoordinate_le β (q z 0))
      (ih k p (fun z i => q z i.succ))
    have hsum := h₁.add h₂
    convert hsum using 1
    · funext n z
      exact mixed_product_succ (actualPolynomial (d n) β lam) (p z) (q z)
    · funext z
      exact mixed_product_succ (limitPolynomial β g) (p z) (q z)

/-- All actual G moments converge uniformly on the compact endpoint cubes,
not just their centered R counterparts. -/
theorem actual_moments_tendstoUniformly (β : ℝ) (lam : ℝ≥0) (d : ℕ → ℕ)
    (g : ∀ k, EndpointCube β k → ℂ)
    (hg : ∀ k, TendstoUniformly (fun n => centeredMoment (d n) β lam) (g k) atTop)
    (k : ℕ) :
    TendstoUniformly (fun n p => Interacting.collectiveMoment (d n) β lam (endpointValues p))
      (fun p : EndpointCube β k => limitPolynomial β g (∏ i, MvPolynomial.X (p i))) atTop := by
  have h := uniform_mixed_products β lam d g hg k 0
    (fun _ : EndpointCube β k => Fin.elim0) (fun p => p)
  simpa only [Fin.prod_univ_zero, one_mul, actualPolynomial_tuple_prod] using h

/-- The centered coordinate product has coefficient norm at most one,
independently of the functional to which it will be applied. -/
theorem centered_product_coefficientNorm_le (β : ℝ) {k : ℕ} (p : EndpointCube β k) :
    coefficientNorm (fun _ => 1/2) (∏ i, remainderCoordinate β (p i)) ≤ 1 := by
  let w := coordinateWeights β
  change ‖∏ i, (WeightedPolynomial.ofPolynomial w (remainderCoordinate β (p i)))‖ ≤ 1
  calc
    _ ≤ ∏ i, ‖WeightedPolynomial.ofPolynomial w (remainderCoordinate β (p i))‖ :=
      Finset.norm_prod_le _ _
    _ ≤ ∏ _i : Fin k, (1 : ℝ) := Finset.prod_le_prod (fun _ _ => norm_nonneg _) (fun i _ =>
      remainderCoordinate_coefficientNorm_le β (p i))
    _ = 1 := by simp

/-- Centering a supplied finite-size polynomial functional is an explicit
algebraic operation, usable after the thermal seam has been corrected. -/
def functionalCenteredMoment {β : ℝ} (L : CoordinatePolynomial β →ₗ[ℂ] ℂ)
    {k : ℕ} (p : EndpointCube β k) : ℂ := L (∏ i, remainderCoordinate β (p i))

/-- Any sequence of linear functionals with uniformly convergent centered
moments has the same explicitly constructed polynomial limit. -/
theorem functional_polynomial_tendsto (β : ℝ)
    (L : ℕ → CoordinatePolynomial β →ₗ[ℂ] ℂ) (g : ∀ k, EndpointCube β k → ℂ)
    (hg : ∀ k, TendstoUniformly (fun n => functionalCenteredMoment (L n)) (g k) atTop)
    (P : CoordinatePolynomial β) :
    Tendsto (fun n => L n P) atTop (𝓝 (limitPolynomial β g P)) := by
  have hcenter (Q : CoordinatePolynomial β) :
      Tendsto (fun n => L n (subtractFree β Q)) atTop (𝓝 (limitCenteredPolynomial β g Q)) := by
    induction Q using MvPolynomial.induction_on' with
    | monomial e c =>
      have hm : MvPolynomial.monomial e c = c • MvPolynomial.monomial e (1 : ℂ) := by
        simp only [MvPolynomial.smul_monomial, smul_eq_mul, mul_one]
      rw [limitCenteredPolynomial_monomial]
      simp only [hm, map_smul, smul_eq_mul, monomial_eq_tuple_prod, map_prod,
        subtractFree, aeval_X]
      exact tendsto_const_nhds.mul ((hg _).tendsto_at (monomialTuple e))
    | add P Q hP hQ => simpa only [map_add] using hP.add hQ
  simpa only [subtractFree_addFree] using hcenter (addFree β P)

/-- Generic form for the seam-corrected actual family: normalization and the
sharp coefficient bounds are finite-size obligations; compactness and the
limiting polynomial functional are proved, not assumed. -/
theorem functional_centered_subsequence {β : ℝ} (hβ : 0 ≤ β)
    (L : ℕ → CoordinatePolynomial β →ₗ[ℂ] ℂ)
    (hunit : ∀ n, L n 1 = 1)
    (hbound : ∀ n P, ‖L n P‖ ≤ coefficientNorm (fun _ => 1/2) P)
    (K : ℕ → ℝ) (hK : ∀ k, 0 ≤ K k) (ε : ℕ → ℕ → ℝ)
    (hε : ∀ k, Tendsto (ε k) atTop (𝓝 0))
    (hmod : ∀ k n (p q : EndpointCube β k),
      ‖functionalCenteredMoment (L n) p - functionalCenteredMoment (L n) q‖ ≤
        K k * dist p q + ε k n) :
    ∃ (φ : ℕ → ℕ) (g : ∀ k, EndpointCube β k → ℂ), StrictMono φ ∧
      (∀ k, TendstoUniformly (fun n => functionalCenteredMoment (L (φ n))) (g k) atTop) ∧
      (∀ k, LipschitzWith ⟨K k, hK k⟩ (g k)) ∧ (∀ k p, ‖g k p‖ ≤ 1) ∧
      (∀ P, Tendsto (fun n => L (φ n) P) atTop (𝓝 (limitPolynomial β g P))) ∧
      limitPolynomial β g 1 = 1 ∧
      (∀ P, ‖limitPolynomial β g P‖ ≤ coefficientNorm (fun _ => 1/2) P) := by
  letI : Nonempty (Icc (0 : ℝ) β) := ⟨⟨0, le_refl _, hβ⟩⟩
  obtain ⟨φ, g, hφ, hg, hLip, hB⟩ := complex_diagonal_uniform_subsequence
    (EndpointCube β) (fun k n => functionalCenteredMoment (L n) (k := k))
    (fun _ => 1) K hK ε hε (fun _ n p => (hbound n _).trans
      (centered_product_coefficientNorm_le β p)) hmod
  have hL := functional_polynomial_tendsto β (L ∘ φ) g hg
  refine ⟨φ, g, hφ, hg, hLip, hB, hL, ?_, ?_⟩
  · exact tendsto_nhds_unique (hL 1)
      (by simpa only [Function.comp_def, hunit] using (tendsto_const_nhds :
        Tendsto (fun _ : ℕ => (1 : ℂ)) atTop (𝓝 1)))
  · intro P
    exact le_of_tendsto (hL P |>.norm) (Eventually.of_forall (fun n => hbound (φ n) P))

/-- The centered tuple values of the generic limiting functional agree with
the uniform limits extracted from the corrected finite-size family. -/
theorem functional_limit_centered_prod (β : ℝ)
    (L : ℕ → CoordinatePolynomial β →ₗ[ℂ] ℂ) (g : ∀ k, EndpointCube β k → ℂ)
    (hg : ∀ k, TendstoUniformly (fun n => functionalCenteredMoment (L n)) (g k) atTop)
    {k : ℕ} (p : EndpointCube β k) :
    limitPolynomial β g (∏ i, remainderCoordinate β (p i)) = g k p := by
  exact tendsto_nhds_unique (functional_polynomial_tendsto β L g hg _)
    ((hg k).tendsto_at p)

/-- Uniform restoration of G after an arbitrary corrected finite-size
functional has been used for centered compactness. -/
theorem functional_uniform_mixed_products (β : ℝ)
    (L : ℕ → CoordinatePolynomial β →ₗ[ℂ] ℂ) (g : ∀ k, EndpointCube β k → ℂ)
    (hg : ∀ k, TendstoUniformly (fun n => functionalCenteredMoment (L n)) (g k) atTop)
    {Z : Type*} (l k : ℕ) (p : Z → EndpointCube β k) (q : Z → EndpointCube β l) :
    TendstoUniformly
      (fun n z => L n ((∏ i, remainderCoordinate β (p z i)) * ∏ i, MvPolynomial.X (q z i)))
      (fun z => limitPolynomial β g
        ((∏ i, remainderCoordinate β (p z i)) * ∏ i, MvPolynomial.X (q z i))) atTop := by
  induction l generalizing k with
  | zero =>
    simpa only [Fin.prod_univ_zero, mul_one,
      functional_limit_centered_prod β L g hg] using (hg k).comp p
  | succ l ih =>
    have h₁ := ih (k+1) (fun z => Fin.snoc (α := fun _ => EndpointPair β) (p z) (q z 0))
      (fun z i => q z i.succ)
    have h₂ := uniform_bounded_mul (fun z => freeCoordinate β (q z 0)) (1/2)
      (by norm_num) (fun z => norm_freeCoordinate_le β (q z 0))
      (ih k p (fun z i => q z i.succ))
    have hsum := h₁.add h₂
    convert hsum using 1
    · funext n z
      exact mixed_product_succ (L n) (p z) (q z)
    · funext z
      exact mixed_product_succ (limitPolynomial β g) (p z) (q z)

/-- All uncentered moments of the corrected family converge uniformly. -/
theorem functional_moments_tendstoUniformly (β : ℝ)
    (L : ℕ → CoordinatePolynomial β →ₗ[ℂ] ℂ) (g : ∀ k, EndpointCube β k → ℂ)
    (hg : ∀ k, TendstoUniformly (fun n => functionalCenteredMoment (L n)) (g k) atTop)
    (k : ℕ) :
    TendstoUniformly (fun n p => L n (∏ i, MvPolynomial.X (p i)))
      (fun p : EndpointCube β k => limitPolynomial β g (∏ i, MvPolynomial.X (p i))) atTop := by
  have h := functional_uniform_mixed_products β L g hg k 0
    (fun _ : EndpointCube β k => Fin.elim0) (fun p => p)
  simpa only [Fin.prod_univ_zero, one_mul] using h

/-- Actual coordinate products are measurable for measurable endpoint maps.
This uses the microscopic sorting-indicator measurability theorem, so it also
covers all collision loci. -/
theorem measurable_actual_tuple {Ω : Type*} [MeasurableSpace Ω]
    (d : ℕ) (β : ℝ) (lam : ℝ≥0) {k : ℕ} (p : Ω → EndpointCube β k)
    (hp : ∀ i, Measurable (fun x => p x i)) :
    Measurable (fun x => actualPolynomial d β lam (∏ i, MvPolynomial.X (p x i))) := by
  simp only [actualPolynomial_tuple_prod]
  apply (MomentMeasurability.measurable_collectiveMoment d β lam k).comp
  apply measurable_pi_lambda
  intro i
  exact (measurable_subtype_coe.comp (hp i).fst).prodMk
    (measurable_subtype_coe.comp (hp i).snd)

/-- A fixed arbitrary polynomial insertion preserves endpoint measurability
of actual collective products. -/
theorem measurable_actual_inserted_product {Ω : Type*} [MeasurableSpace Ω]
    (d : ℕ) (β : ℝ) (lam : ℝ≥0) (P : CoordinatePolynomial β)
    {k : ℕ} (p : Ω → EndpointCube β k) (hp : ∀ i, Measurable (fun x => p x i)) :
    Measurable (fun x => actualPolynomial d β lam (P * ∏ i, MvPolynomial.X (p x i))) := by
  induction P using MvPolynomial.induction_on generalizing k with
  | C c =>
    simp only [MvPolynomial.C_mul', map_smul, smul_eq_mul]
    exact (measurable_actual_tuple d β lam p hp).const_mul c
  | add P Q hP hQ =>
    simpa only [add_mul, map_add] using (hP p hp).add (hQ p hp)
  | mul_X P a hP =>
    have h := hP (fun x => Fin.cons a (p x)) (by
      intro i
      refine Fin.cases ?_ (fun i => ?_) i
      · exact measurable_const
      · exact hp i)
    simpa only [Fin.prod_univ_succ, Fin.cons_zero, Fin.cons_succ, mul_assoc] using h

/-- The actual limiting uncentered moments are measurable: they are limits
of the genuine measurable finite-size Weyl moments, not presumed continuous. -/
theorem measurable_limit_tuple (β : ℝ) (lam : ℝ≥0) (d : ℕ → ℕ)
    (g : ∀ k, EndpointCube β k → ℂ)
    (hg : ∀ k, TendstoUniformly (fun n => centeredMoment (d n) β lam) (g k) atTop)
    (k : ℕ) :
    Measurable (fun p : EndpointCube β k => limitPolynomial β g (∏ i, MvPolynomial.X (p i))) := by
  apply measurable_of_tendsto_metrizable (fun n =>
    measurable_actual_tuple (d n) β lam (fun p : EndpointCube β k => p)
      (fun i => measurable_pi_apply i))
  apply tendsto_pi_nhds.mpr
  intro p
  exact actual_polynomial_tendsto β lam d g hg _

/-- Integral passage for an actual corrected functional sequence. Every
finite-N bound and measurability requirement remains visible for instantiation. -/
theorem functional_integral_tendsto {Ω : Type*} [MeasurableSpace Ω] (μ : Measure Ω)
    (β : ℝ) (L : ℕ → CoordinatePolynomial β →ₗ[ℂ] ℂ)
    (hbound : ∀ n P, ‖L n P‖ ≤ coefficientNorm (fun _ => 1/2) P)
    (g : ∀ k, EndpointCube β k → ℂ)
    (hg : ∀ k, TendstoUniformly (fun n => functionalCenteredMoment (L n)) (g k) atTop)
    (P : Ω → CoordinatePolynomial β) (b : Ω → ℝ) (hb : Integrable b μ)
    (hPb : ∀ x, coefficientNorm (fun _ => 1/2) (P x) ≤ b x)
    (hMeas : ∀ n, AEStronglyMeasurable (fun x => L n (P x)) μ) :
    Tendsto (fun n => ∫ x, L n (P x) ∂μ) atTop (𝓝 (∫ x, limitPolynomial β g (P x) ∂μ)) := by
  apply tendsto_integral_of_dominated_convergence b hMeas hb
  · intro n
    exact Eventually.of_forall (fun x => (hbound n (P x)).trans (hPb x))
  · exact Eventually.of_forall (fun x => functional_polynomial_tendsto β L g hg (P x))

/-- For the seam-corrected hierarchy, finite inserted equations plus explicit
inverse-dimension contacts imply the exact limiting inserted integral identity. -/
theorem functional_ward_limit {Ω : Type*} [MeasurableSpace Ω] (μ : Measure Ω)
    (β : ℝ) (L : ℕ → CoordinatePolynomial β →ₗ[ℂ] ℂ)
    (hbound : ∀ n P, ‖L n P‖ ≤ coefficientNorm (fun _ => 1/2) P)
    (d : ℕ → ℕ) (hd_top : Tendsto d atTop atTop) (g : ∀ k, EndpointCube β k → ℂ)
    (hg : ∀ k, TendstoUniformly (fun n => functionalCenteredMoment (L n)) (g k) atTop)
    (P : CoordinatePolynomial β) (Q : Ω → CoordinatePolynomial β)
    (b : Ω → ℝ) (hb : Integrable b μ)
    (hQb : ∀ x, coefficientNorm (fun _ => 1/2) (Q x) ≤ b x)
    (hMeas : ∀ n, AEStronglyMeasurable (fun x => L n (Q x)) μ)
    (c : ℂ) (E : ℕ → ℂ) (A : ℝ) (hE : ∀ n, ‖E n‖ ≤ A / (d n : ℝ))
    (hWard : ∀ n, L n P = c * (∫ x, L n (Q x) ∂μ) + E n) :
    limitPolynomial β g P = c * ∫ x, limitPolynomial β g (Q x) ∂μ := by
  have hright := ((tendsto_const_nhds (x := c)).mul
    (functional_integral_tendsto μ β L hbound g hg Q b hb hQb hMeas)).add
      (contact_error_tendsto d hd_top A E hE)
  simp only [add_zero] at hright
  exact tendsto_nhds_unique (functional_polynomial_tendsto β L g hg P)
    (hright.congr (fun n => (hWard n).symm))

/-- The coefficient bound for any partial product of centered coordinates,
including the product with a single insertion slot removed. -/
theorem remainder_finset_coefficientNorm_le {ι : Type*} (β : ℝ) (s : Finset ι)
    (p : ι → EndpointPair β) :
    coefficientNorm (fun _ => 1/2) (∏ i ∈ s, remainderCoordinate β (p i)) ≤ 1 := by
  let w := coordinateWeights β
  change ‖∏ i ∈ s, (WeightedPolynomial.ofPolynomial w (remainderCoordinate β (p i)))‖ ≤ 1
  calc
    _ ≤ ∏ i ∈ s, ‖WeightedPolynomial.ofPolynomial w (remainderCoordinate β (p i))‖ :=
      Finset.norm_prod_le _ _
    _ ≤ ∏ _i ∈ s, (1 : ℝ) := Finset.prod_le_prod (fun _ _ => norm_nonneg _) (fun i _ =>
      remainderCoordinate_coefficientNorm_le β (p i))
    _ = 1 := by simp

/-- The explicit polynomial numerator of the insertion contact remainder.
Every removed R slot contributes its two original Wick contractions. -/
def contactPolynomial (β : ℝ) {k : ℕ} (p : EndpointCube β k)
    (s t : Icc (0 : ℝ) β) : CoordinatePolynomial β :=
  ∑ r : Fin k,
    (freeCoordinate β (s, (p r).1) •
      ((∏ i ∈ Finset.univ.erase r, remainderCoordinate β (p i)) * MvPolynomial.X ((p r).2, t)) -
    freeCoordinate β (s, (p r).2) •
      ((∏ i ∈ Finset.univ.erase r, remainderCoordinate β (p i)) * MvPolynomial.X ((p r).1, t)))

/-- The explicit finite-size contact term with N=2d. -/
def contactRemainder {β : ℝ} (L : CoordinatePolynomial β →ₗ[ℂ] ℂ) (d : ℕ)
    {k : ℕ} (p : EndpointCube β k) (s t : Icc (0 : ℝ) β) : ℂ :=
  (((2*d : ℕ) : ℂ)⁻¹) * L (contactPolynomial β p s t)

/-- The polynomial contact numerator is exactly the finite sum of scalar
covariances times the two lower moments, with the original relative minus. -/
theorem contactRemainder_expansion {β : ℝ} (L : CoordinatePolynomial β →ₗ[ℂ] ℂ) (d : ℕ)
    {k : ℕ} (p : EndpointCube β k) (s t : Icc (0 : ℝ) β) :
    contactRemainder L d p s t = (((2*d : ℕ) : ℂ)⁻¹) *
      ∑ r : Fin k,
        (freeCoordinate β (s, (p r).1) *
          L ((∏ i ∈ Finset.univ.erase r, remainderCoordinate β (p i)) * MvPolynomial.X ((p r).2, t)) -
        freeCoordinate β (s, (p r).2) *
          L ((∏ i ∈ Finset.univ.erase r, remainderCoordinate β (p i)) * MvPolynomial.X ((p r).1, t))) := by
  simp only [contactRemainder, contactPolynomial, map_sum, map_sub, map_smul, smul_eq_mul]

/-- Sharp scalar bookkeeping for the actual contact polynomial. No contact
estimate is assumed: each R factor costs at most one and the remaining G costs b. -/
theorem contactPolynomial_coefficientNorm_le (β : ℝ) {k : ℕ} (p : EndpointCube β k)
    (s t : Icc (0 : ℝ) β) :
    coefficientNorm (fun _ => 1/2) (contactPolynomial β p s t) ≤ (k : ℝ)/2 := by
  let w := coordinateWeights β
  have hterm (r : Fin k) (a : EndpointPair β) :
      ‖WeightedPolynomial.ofPolynomial w
        ((∏ i ∈ Finset.univ.erase r, remainderCoordinate β (p i)) * MvPolynomial.X a)‖ ≤ 1/2 := by
    calc
      _ ≤ ‖WeightedPolynomial.ofPolynomial w (∏ i ∈ Finset.univ.erase r,
          remainderCoordinate β (p i))‖ * ‖WeightedPolynomial.ofPolynomial w (MvPolynomial.X a)‖ :=
        norm_mul_le _ _
      _ ≤ 1 * (1/2) := mul_le_mul
        (remainder_finset_coefficientNorm_le β (Finset.univ.erase r) p)
        (by rw [WeightedPolynomial.norm_X]; rfl) (norm_nonneg _) zero_le_one
      _ = _ := one_mul _
  have hsummand (r : Fin k) :
      ‖WeightedPolynomial.ofPolynomial w
        (freeCoordinate β (s, (p r).1) •
          ((∏ i ∈ Finset.univ.erase r, remainderCoordinate β (p i)) * MvPolynomial.X ((p r).2, t)) -
        freeCoordinate β (s, (p r).2) •
          ((∏ i ∈ Finset.univ.erase r, remainderCoordinate β (p i)) * MvPolynomial.X ((p r).1, t)))‖
        ≤ 1/2 := by
    apply (norm_sub_le _ _).trans
    change ‖freeCoordinate β (s, (p r).1) • (WeightedPolynomial.ofPolynomial w _)‖ +
      ‖freeCoordinate β (s, (p r).2) • (WeightedPolynomial.ofPolynomial w _)‖ ≤ 1/2
    rw [norm_smul, norm_smul]
    have h₁ := mul_le_mul (norm_freeCoordinate_le β (s, (p r).1))
      (hterm r ((p r).2, t)) (norm_nonneg _) (by norm_num : (0 : ℝ) ≤ 1/2)
    have h₂ := mul_le_mul (norm_freeCoordinate_le β (s, (p r).2))
      (hterm r ((p r).1, t)) (norm_nonneg _) (by norm_num : (0 : ℝ) ≤ 1/2)
    linarith
  change ‖WeightedPolynomial.ofPolynomial w (contactPolynomial β p s t)‖ ≤ _
  unfold contactPolynomial
  calc
    _ ≤ ∑ r : Fin k, ‖WeightedPolynomial.ofPolynomial w
      (freeCoordinate β (s, (p r).1) •
        ((∏ i ∈ Finset.univ.erase r, remainderCoordinate β (p i)) * MvPolynomial.X ((p r).2, t)) -
      freeCoordinate β (s, (p r).2) •
        ((∏ i ∈ Finset.univ.erase r, remainderCoordinate β (p i)) * MvPolynomial.X ((p r).1, t)))‖ :=
      norm_sum_le _ _
    _ ≤ ∑ _r : Fin k, (1/2 : ℝ) := Finset.sum_le_sum (fun r _ => hsummand r)
    _ = (k : ℝ)/2 := by simp; ring

/-- The contact term is genuinely O(1/N), uniformly over all insertion
endpoints, as a consequence of the microscopic coefficient bound. -/
theorem contactRemainder_bound {β : ℝ} (L : CoordinatePolynomial β →ₗ[ℂ] ℂ)
    (hL : ∀ P, ‖L P‖ ≤ coefficientNorm (fun _ => 1/2) P) (d : ℕ) (hd : 0 < d)
    {k : ℕ} (p : EndpointCube β k) (s t : Icc (0 : ℝ) β) :
    ‖contactRemainder L d p s t‖ ≤ ((k : ℝ)/4) / (d : ℝ) := by
  have hd' : (0 : ℝ) < d := by exact_mod_cast hd
  unfold contactRemainder
  rw [norm_mul, norm_inv, Complex.norm_natCast]
  calc
    _ ≤ (((2*d : ℕ) : ℝ)⁻¹) * ((k : ℝ)/2) :=
      mul_le_mul_of_nonneg_left ((hL _).trans (contactPolynomial_coefficientNorm_le β p s t))
        (inv_nonneg.mpr (Nat.cast_nonneg _))
    _ = _ := by
      push_cast
      field_simp [hd'.ne']
      left
      ring

/-- The exact, explicitly summed insertion contact remainder vanishes along
any dimensions tending to infinity, for every fixed inserted R monomial. -/
theorem contactRemainder_tendsto {β : ℝ}
    (L : ℕ → CoordinatePolynomial β →ₗ[ℂ] ℂ)
    (hL : ∀ n P, ‖L n P‖ ≤ coefficientNorm (fun _ => 1/2) P)
    (d : ℕ → ℕ) (hd : ∀ n, 0 < d n) (hd_top : Tendsto d atTop atTop)
    {k : ℕ} (p : EndpointCube β k) (s t : Icc (0 : ℝ) β) :
    Tendsto (fun n => contactRemainder (L n) (d n) p s t) atTop (𝓝 0) :=
  contact_error_tendsto d hd_top ((k : ℝ)/4) _
    (fun n => contactRemainder_bound (L n) (hL n) (d n) (hd n) p s t)

/-- Inserted polynomial relations, rather than just uninserted averages,
pass to the limiting functional and are suitable for quotient descent. -/
theorem functional_limit_inserted_relations {J : Type*} (β : ℝ)
    (L : ℕ → CoordinatePolynomial β →ₗ[ℂ] ℂ) (g : ∀ k, EndpointCube β k → ℂ)
    (hg : ∀ k, TendstoUniformly (fun n => functionalCenteredMoment (L n)) (g k) atTop)
    (r : J → CoordinatePolynomial β) (hr : ∀ n P j, L n (P * r j) = 0) :
    ∀ P j, limitPolynomial β g (P * r j) = 0 := by
  intro P j
  apply tendsto_nhds_unique (functional_polynomial_tendsto β L g hg (P * r j))
  simpa only [hr] using (tendsto_const_nhds : Tendsto (fun _ : ℕ => (0 : ℂ)) atTop (𝓝 0))

/-- Any finite polynomial positivity test established microscopically is
inherited by the corrected limiting functional. -/
theorem functional_limit_nonnegative (β : ℝ)
    (L : ℕ → CoordinatePolynomial β →ₗ[ℂ] ℂ) (g : ∀ k, EndpointCube β k → ℂ)
    (hg : ∀ k, TendstoUniformly (fun n => functionalCenteredMoment (L n)) (g k) atTop)
    (P : CoordinatePolynomial β) (hP : ∀ n, 0 ≤ (L n P).re) :
    0 ≤ (limitPolynomial β g P).re := by
  exact le_of_tendsto_of_tendsto tendsto_const_nhds
    (Complex.continuous_re.tendsto _ |>.comp (functional_polynomial_tendsto β L g hg P))
    (Eventually.of_forall hP)

/-- Swapping one endpoint pair commutes with forgetting interval proofs. -/
theorem endpointValues_update_swap {β : ℝ} {k : ℕ} (p : EndpointCube β k) (r : Fin k) :
    endpointValues (Function.update p r (p r).swap) =
      Function.update (endpointValues p) r (endpointValues p r).swap := by
  classical
  funext i
  by_cases h : i = r <;> simp [endpointValues, Function.update_apply, h]

/-- The actual polynomial tuple moments retain microscopic skewness in
each bilocal, including arbitrary other coincident endpoints. -/
theorem actualPolynomial_tuple_flip (d : ℕ) (β : ℝ) (lam : ℝ≥0) {k : ℕ}
    (p : EndpointCube β k) (r : Fin k) :
    actualPolynomial d β lam (∏ i, MvPolynomial.X (Function.update p r (p r).swap i)) =
      -actualPolynomial d β lam (∏ i, MvPolynomial.X (p i)) := by
  rw [actualPolynomial_tuple_prod, actualPolynomial_tuple_prod, endpointValues_update_swap]
  exact MomentSymmetry.collectiveMoment_flip d β lam (endpointValues p) r

/-- Bilocal skewness passes from the actual moments to their subsequential
polynomial functional, with no extra symmetry axiom on the limit. -/
theorem limitPolynomial_tuple_flip (β : ℝ) (lam : ℝ≥0) (d : ℕ → ℕ)
    (g : ∀ k, EndpointCube β k → ℂ)
    (hg : ∀ k, TendstoUniformly (fun n => centeredMoment (d n) β lam) (g k) atTop)
    {k : ℕ} (p : EndpointCube β k) (r : Fin k) :
    limitPolynomial β g (∏ i, MvPolynomial.X (Function.update p r (p r).swap i)) =
      -limitPolynomial β g (∏ i, MvPolynomial.X (p i)) := by
  exact tendsto_nhds_unique (actual_polynomial_tendsto β lam d g hg _)
    ((actual_polynomial_tendsto β lam d g hg _).neg.congr
      (fun n => (actualPolynomial_tuple_flip (d n) β lam p r).symm))

/-- Exactly coincident bilocals vanish in the limiting tuple moments. -/
theorem limitPolynomial_tuple_diagonal (β : ℝ) (lam : ℝ≥0) (d : ℕ → ℕ)
    (g : ∀ k, EndpointCube β k → ℂ)
    (hg : ∀ k, TendstoUniformly (fun n => centeredMoment (d n) β lam) (g k) atTop)
    {k : ℕ} (p : EndpointCube β k) (r : Fin k) (hr : (p r).1 = (p r).2) :
    limitPolynomial β g (∏ i, MvPolynomial.X (p i)) = 0 := by
  have hp : (p r).swap = p r := by ext <;> simp [hr]
  have h := limitPolynomial_tuple_flip β lam d g hg p r
  rw [hp, Function.update_eq_self] at h
  exact CharZero.eq_neg_self_iff.mp h

end SYK.MomentLimit
