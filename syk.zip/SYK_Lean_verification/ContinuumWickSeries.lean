import WickVertexIntegrals
import ExponentialMomentSeries
import Mathlib.MeasureTheory.Integral.Pi

/-!
# The actual continuum collective Wick series

Only scalar free expectations are integrated. The field algebra itself is not
given a fictitious norm or an infinite-dimensional integration operation.
The operator correspondence is a separate microscopic theorem.
-/
set_option maxHeartbeats 1200000
noncomputable section
open MeasureTheory Set Filter
open scoped Topology BigOperators
namespace SYK.ContinuumWickSeries
open ThermalWick Ward WickVertexIntegrals

local instance (β : ℝ) : MeasurableSpace (Time β) :=
  inferInstanceAs (MeasurableSpace {t : ℝ // t ∈ Ico 0 β})

/-- Ordinary two-time Lebesgue measure on the thermal square. -/
def pairMeasure (β : ℝ) : Measure (ℝ×ℝ) :=
  (volume.restrict (Icc (0:ℝ) β)).prod (volume.restrict (Icc (0:ℝ) β))

/-- The n independent time pairs in the degree-n interaction coefficient. -/
def interactionMeasure (β : ℝ) (n : ℕ) : Measure (Fin n → ℝ×ℝ) :=
  Measure.pi (fun _ : Fin n => pairMeasure β)

instance pairMeasure_finite (β : ℝ) : IsFiniteMeasure (pairMeasure β) := by
  unfold pairMeasure
  infer_instance
instance interactionMeasure_finite (β : ℝ) (n : ℕ) : IsFiniteMeasure (interactionMeasure β n) := by
  exact Measure.pi.instIsFiniteMeasure (fun _ : Fin n => pairMeasure β)

def interactionPairs (β : ℝ) (hβ : 0 < β) {n : ℕ} (u : Fin n → ℝ×ℝ) :
    List (Time β × Time β) :=
  (List.ofFn (fun i => List.replicate 4
    (timeRepresentative β hβ (u i).1,timeRepresentative β hβ (u i).2))).flatten

def coefficientIntegrand (d : ℕ) (β : ℝ) (hβ : 0 < β)
    (ps : List (Time β × Time β)) {n : ℕ} (u : Fin n → ℝ×ℝ) : ℂ :=
  expectation (2*d) β (collectiveMonomial (ps ++ interactionPairs β hβ u))

/-- Factorial-free coefficient. The exact Gaussian/exterior regrouping has
already fixed the factor N/8. -/
def coefficient (d : ℕ) (β : ℝ) (hβ : 0 < β)
    (ps : List (Time β × Time β)) (n : ℕ) : ℂ :=
  (((2*d:ℕ):ℝ)/8)^n • ∫ u, coefficientIntegrand d β hβ ps u ∂interactionMeasure β n

def numerator (d : ℕ) (β : ℝ) (hβ : 0 < β)
    (ps : List (Time β × Time β)) (lam : ℝ) : ℂ :=
  ExponentialMomentSeries.value (coefficient d β hβ ps) lam

/-- Free Wick expectations are measurable for finite lists of measurable
bilocals, including all diagonal/tie configurations. -/
theorem measurable_word_collectives {X : Type*} [MeasurableSpace X]
    (d : ℕ) {β : ℝ} (hβ : 0 < β)
    (ps : List ((X → Time β) × (X → Time β)))
    (hps : ∀ p ∈ ps, Measurable (fun x => (p.1 x).val) ∧ Measurable (fun x => (p.2 x).val)) :
    ∀ (L : List (Fin (2*d) × (X → Time β))), Even L.length →
      (∀ p ∈ L, Measurable (fun x => (p.2 x).val)) →
      Measurable (fun x => expectation (2*d) β
        (FreeWick.word (fun p => field p.1 p.2) (L.map (fun p => (p.1,p.2 x))) *
          collectiveMonomial (ps.map (fun p => (p.1 x,p.2 x))))) := by
  induction ps with
  | nil =>
    intro L hL hs
    simpa [collectiveMonomial] using measurable_expectation_list d hβ L hL hs
  | cons p ps ih =>
    intro L hL hs
    have hm (i : Fin (2*d)) := ih (fun q hq => hps q (by simp [hq]))
      (L++[(i,p.1),(i,p.2)])
      (by simpa using hL.add (by decide : Even 2))
      (by
        intro q hq
        rcases List.mem_append.mp hq with hq | hq
        · exact hs q hq
        · simp only [List.mem_cons,List.mem_nil_iff,or_false] at hq
          rcases hq with rfl | rfl
          · exact (hps p (by simp)).1
          · exact (hps p (by simp)).2)
    have hsum := Finset.measurable_sum Finset.univ (fun i _ => hm i)
    have he (x : X) : expectation (2*d) β
        (FreeWick.word (fun p => field p.1 p.2) (L.map (fun p => (p.1,p.2 x))) *
          collectiveMonomial ((p::ps).map (fun p => (p.1 x,p.2 x)))) =
        ((2*d:ℕ):ℂ)⁻¹ * ∑ i : Fin (2*d), expectation (2*d) β
          (FreeWick.word (fun p => field p.1 p.2)
            ((L++[(i,p.1),(i,p.2)]).map (fun p => (p.1,p.2 x))) *
              collectiveMonomial (ps.map (fun p => (p.1 x,p.2 x)))) := by
      simp only [List.map_cons,collectiveMonomial,List.prod_cons,collective,
        mul_smul_comm,smul_mul_assoc,Finset.sum_mul,Finset.mul_sum,map_smul,map_sum,
        smul_eq_mul,List.map_append,List.map_nil,FreeWick.word_append,FreeWick.word_cons,
        FreeWick.word_nil,mul_one,mul_assoc]
    simp_rw [he]
    exact hsum.const_mul _

def interactionPairFunctions (β : ℝ) (hβ : 0 < β) (n : ℕ) :
    List (((Fin n → ℝ×ℝ) → Time β) × ((Fin n → ℝ×ℝ) → Time β)) :=
  (List.ofFn (fun i => List.replicate 4
    ((fun u => timeRepresentative β hβ (u i).1),
     (fun u => timeRepresentative β hβ (u i).2)))).flatten

theorem interactionPairFunctions_eval (β : ℝ) (hβ : 0 < β) {n : ℕ}
    (u : Fin n → ℝ×ℝ) :
    (interactionPairFunctions β hβ n).map (fun p => (p.1 u,p.2 u)) = interactionPairs β hβ u := by
  simp [interactionPairFunctions,interactionPairs,List.map_flatten,List.map_ofFn,Function.comp_def]

theorem interactionPairFunctions_measurable (β : ℝ) (hβ : 0 < β) (n : ℕ)
    (p) (hp : p ∈ interactionPairFunctions β hβ n) :
    Measurable (fun u => (p.1 u).val) ∧ Measurable (fun u => (p.2 u).val) := by
  obtain ⟨l,hl,hp⟩ := List.mem_flatten.mp hp
  obtain ⟨i,rfl⟩ := List.mem_ofFn.mp hl
  obtain ⟨_,rfl⟩ := List.mem_replicate.mp hp
  have hm := measurable_subtype_coe.comp (timeRepresentative_measurable β hβ)
  exact ⟨hm.comp (measurable_pi_apply i).fst,hm.comp (measurable_pi_apply i).snd⟩

theorem coefficientIntegrand_measurable (d : ℕ) (β : ℝ) (hβ : 0 < β)
    (ps : List (Time β × Time β)) (n : ℕ) :
    Measurable (coefficientIntegrand d β hβ ps (n := n)) := by
  let xs := ps.map (fun p => ((fun _ : Fin n → ℝ×ℝ => p.1),(fun _ => p.2))) ++
    interactionPairFunctions β hβ n
  have hm := measurable_word_collectives d hβ xs (by
    intro p hp
    rcases List.mem_append.mp hp with hp | hp
    · obtain ⟨q,_,rfl⟩ := List.mem_map.mp hp
      change Measurable (fun _ : Fin n → ℝ×ℝ => q.1.val) ∧
        Measurable (fun _ : Fin n → ℝ×ℝ => q.2.val)
      exact ⟨measurable_const,measurable_const⟩
    · exact interactionPairFunctions_measurable β hβ n p hp) [] (by simp) (by simp)
  have he (u : Fin n → ℝ×ℝ) : xs.map (fun p => (p.1 u,p.2 u)) = ps++interactionPairs β hβ u := by
    simp [xs,List.map_append,List.map_map,interactionPairFunctions_eval,Function.comp_def]
  simpa only [List.map_nil,FreeWick.word_nil,one_mul,he,coefficientIntegrand] using hm

@[simp] theorem interactionPairs_length (β : ℝ) (hβ : 0 < β) {n : ℕ}
    (u : Fin n → ℝ×ℝ) : (interactionPairs β hβ u).length=4*n := by
  simp [interactionPairs,List.length_flatten,List.map_ofFn,List.sum_ofFn,Nat.mul_comm]

theorem coefficientIntegrand_bound (d : ℕ) (hd : 0 < d) (β : ℝ) (hβ : 0 < β)
    (ps : List (Time β × Time β)) {n : ℕ} (u : Fin n → ℝ×ℝ) :
    ‖coefficientIntegrand d β hβ ps u‖ ≤ (1/2:ℝ)^(ps.length+4*n) := by
  simpa only [coefficientIntegrand,List.length_append,interactionPairs_length] using
    FreeWeyl.expectation_collectiveMonomial_bound d hd hβ (ps++interactionPairs β hβ u)

theorem coefficientIntegrand_integrable (d : ℕ) (hd : 0 < d) (β : ℝ) (hβ : 0 < β)
    (ps : List (Time β × Time β)) (n : ℕ) :
    Integrable (coefficientIntegrand d β hβ ps) (interactionMeasure β n) :=
  (integrable_const ((1/2:ℝ)^(ps.length+4*n))).mono'
    (coefficientIntegrand_measurable d β hβ ps n).aestronglyMeasurable
    (Eventually.of_forall (coefficientIntegrand_bound d hd β hβ ps))

theorem pairMeasure_real_univ (β : ℝ) (hβ : 0 ≤ β) : (pairMeasure β).real univ=β^2 := by
  rw [measureReal_def,pairMeasure,← univ_prod_univ,Measure.prod_prod]
  simp [Measure.restrict_apply_univ,Real.volume_Icc,ENNReal.toReal_mul,hβ,pow_two]

theorem interactionMeasure_real_univ (β : ℝ) (hβ : 0 ≤ β) (n : ℕ) :
    (interactionMeasure β n).real univ=(β^2)^n := by
  rw [measureReal_def,interactionMeasure,Measure.pi_univ,ENNReal.toReal_prod]
  simp only [← measureReal_def,pairMeasure_real_univ β hβ,Finset.prod_const,
    Finset.card_univ,Fintype.card_fin]

/-- The exact finite-N coefficient majorant is valid at every degree and
for every external endpoint configuration, including coincident times. -/
theorem coefficient_bound (d : ℕ) (hd : 0 < d) (β : ℝ) (hβ : 0 < β)
    (ps : List (Time β × Time β)) (n : ℕ) :
    ‖coefficient d β hβ ps n‖ ≤
      (1/2:ℝ)^ps.length * (((2*d:ℕ):ℝ)*β^2/128)^n := by
  have h := norm_integral_le_of_norm_le_const
    (μ := interactionMeasure β n)
    (Eventually.of_forall (coefficientIntegrand_bound d hd β hβ ps (n := n)))
  rw [interactionMeasure_real_univ β hβ.le] at h
  simp only [coefficient,norm_smul,Real.norm_eq_abs,abs_of_nonneg
    (show 0 ≤ (((2*d:ℕ):ℝ)/8)^n by positivity)]
  apply (mul_le_mul_of_nonneg_left h (by positivity)).trans_eq
  rw [pow_add,pow_mul]
  have hconst : (((2*d:ℕ):ℝ)/8)*((1/2:ℝ)^4*β^2)=((2*d:ℕ):ℝ)*β^2/128 := by ring
  calc
    _ = (1/2:ℝ)^ps.length * ((((2*d:ℕ):ℝ)/8)*((1/2:ℝ)^4*β^2))^n := by
      rw [mul_pow,mul_pow]
      ring
    _ = _ := by rw [hconst]

theorem numerator_summable (d : ℕ) (hd : 0 < d) (β : ℝ) (hβ : 0 < β)
    (ps : List (Time β × Time β)) (lam : ℝ) :
    Summable (ExponentialMomentSeries.term (coefficient d β hβ ps) lam) :=
  ExponentialMomentSeries.summable_term _ ((1/2:ℝ)^ps.length)
    (((2*d:ℕ):ℝ)*β^2/128) (by positivity) (by positivity)
    (coefficient_bound d hd β hβ ps) lam

theorem numerator_norm_summable (d : ℕ) (hd : 0 < d) (β : ℝ) (hβ : 0 < β)
    (ps : List (Time β × Time β)) (lam : ℝ) :
    Summable (fun n => ‖ExponentialMomentSeries.term (coefficient d β hβ ps) lam n‖) :=
  ExponentialMomentSeries.summable_norm_term _ ((1/2:ℝ)^ps.length)
    (((2*d:ℕ):ℝ)*β^2/128) (by positivity) (by positivity)
    (coefficient_bound d hd β hβ ps) lam

@[simp] theorem coefficient_zero (d : ℕ) (β : ℝ) (hβ : 0 < β)
    (ps : List (Time β × Time β)) :
    coefficient d β hβ ps 0 = expectation (2*d) β (collectiveMonomial ps) := by
  simp only [coefficient,pow_zero,one_smul,coefficientIntegrand,interactionPairs,
    List.ofFn_zero,List.flatten_nil,List.append_nil,integral_const,
    interactionMeasure_real_univ β hβ.le,pow_zero,one_smul]

@[simp] theorem numerator_zero (d : ℕ) (β : ℝ) (hβ : 0 < β)
    (ps : List (Time β × Time β)) :
    numerator d β hβ ps 0 = expectation (2*d) β (collectiveMonomial ps) := by
  unfold numerator ExponentialMomentSeries.value
  rw [tsum_eq_single 0]
  · simp [ExponentialMomentSeries.term,coefficient_zero]
  · intro n hn
    simp [ExponentialMomentSeries.term,zero_pow hn]

end SYK.ContinuumWickSeries
