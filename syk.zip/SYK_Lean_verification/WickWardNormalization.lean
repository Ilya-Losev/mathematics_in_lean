import ContactWickEvaluation
import WickSeriesPressure

noncomputable section
open MeasureTheory
namespace SYK.ContinuumWickSeries
open ThermalWick

theorem contactValue_div {β : ℝ} (F : List (Time β × Time β) → ℂ) (z : ℂ)
    (s t : Time β) (ps qs : List (Time β × Time β)) :
    contactValue (fun l => F l/z) s t ps qs = contactValue F s t ps qs/z := by
  induction ps generalizing qs with
  | nil => simp [contactValue]
  | cons p ps ih => simp only [contactValue,ih]; ring

/-- Dividing a genuine inserted series identity by its nonzero partition
preserves every contact and the literal integrated interaction term. -/
theorem normalized_ward_of_numerator {β : ℝ} {Ω : Type*} [MeasurableSpace Ω]
    (μ : Measure Ω) (F : List (Time β × Time β) → ℂ)
    (s t : Time β) (ps : List (Time β × Time β))
    (c : Ω → ℂ) (w : Ω → List (Time β × Time β)) (a b : ℂ)
    (hz : F [] ≠ 0)
    (h : F ((s,t)::ps) = (Thermal.kernel β s.val t.val:ℂ)*F ps +
      a*contactValue F s t ps [] + b*(∫ x, c x*F (w x) ∂μ)) :
    F ((s,t)::ps)/F [] - (Thermal.kernel β s.val t.val:ℂ)*(F ps/F []) =
      b*(∫ x, c x*(F (w x)/F []) ∂μ) +
      a*contactValue (fun l => F l/F []) s t ps [] := by
  rw [contactValue_div]
  simp_rw [← mul_div_assoc]
  rw [integral_div,h]
  field_simp
  ring

end SYK.ContinuumWickSeries
