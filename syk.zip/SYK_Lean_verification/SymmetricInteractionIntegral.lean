import ContinuumWickSeries

/-! # Genuine time-measure symmetries and marked-interaction integration -/
noncomputable section
open MeasureTheory Set
open scoped BigOperators Topology
namespace SYK.ContinuumWickSeries

/-- Swapping the two actual thermal-time coordinates preserves their law. -/
theorem pairMeasure_swap (β : ℝ) :
    MeasurePreserving Prod.swap (pairMeasure β) (pairMeasure β) :=
  Measure.measurePreserving_swap

/-- Change variables u↔v in the actual two-time integral. -/
theorem integral_pair_swap (β : ℝ) (f : ℝ×ℝ → ℂ) :
    (∫ p, f p.swap ∂pairMeasure β) = ∫ p, f p ∂pairMeasure β :=
  (pairMeasure_swap β).integral_comp MeasurableEquiv.prodComm.measurableEmbedding f

/-- Any permutation of the independent interaction pairs preserves the
actual finite product Lebesgue measure. -/
theorem interactionMeasure_permutation (β : ℝ) (n : ℕ) (σ : Equiv.Perm (Fin n)) :
    MeasurePreserving (fun x : Fin n → ℝ×ℝ => x ∘ σ)
      (interactionMeasure β n) (interactionMeasure β n) := by
  have h := (measurePreserving_piCongrLeft (fun _ : Fin n => pairMeasure β) σ).symm
  simpa only [interactionMeasure, MeasurableEquiv.piCongrLeft, MeasurableEquiv.coe_mk,
    Equiv.piCongrLeft_symm_apply, Function.comp_def] using h

/-- Integral permutation invariance is proved by the measurable equivalence,
even before any special formula for an integrand is used. -/
theorem integral_interaction_permutation (β : ℝ) (n : ℕ) (σ : Equiv.Perm (Fin n))
    (f : (Fin n → ℝ×ℝ) → ℂ) :
    (∫ x, f (x ∘ σ) ∂interactionMeasure β n) = ∫ x, f x ∂interactionMeasure β n := by
  have h := ((measurePreserving_piCongrLeft (fun _ : Fin n => pairMeasure β) σ).symm).integral_comp' f
  simpa only [interactionMeasure, MeasurableEquiv.piCongrLeft, MeasurableEquiv.coe_mk,
    Equiv.piCongrLeft_symm_apply, Function.comp_def] using h

/-- Equivariant marked vertices all have exactly the same actual integral. -/
theorem marked_integral_eq (β : ℝ) (n : ℕ) (T : Fin n → (Fin n → ℝ×ℝ) → ℂ)
    (hsym : ∀ (σ : Equiv.Perm (Fin n)) i x, T i (x ∘ σ) = T (σ i) x)
    (i j : Fin n) :
    (∫ x, T i x ∂interactionMeasure β n) = ∫ x, T j x ∂interactionMeasure β n := by
  rw [← integral_interaction_permutation β n (Equiv.swap i j) (T i)]
  congr 1
  funext x
  rw [hsym, Equiv.swap_apply_left]

/-- Summing over marked vertices contributes precisely the number n, with
all finite-sum integration hypotheses explicitly retained. -/
theorem integral_marked_sum (β : ℝ) (n : ℕ) (T : Fin n → (Fin n → ℝ×ℝ) → ℂ)
    (hsym : ∀ (σ : Equiv.Perm (Fin n)) i x, T i (x ∘ σ) = T (σ i) x)
    (hT : ∀ i, Integrable (T i) (interactionMeasure β n)) (j : Fin n) :
    (∫ x, ∑ i, T i x ∂interactionMeasure β n) =
      (n : ℂ) * ∫ x, T j x ∂interactionMeasure β n := by
  rw [integral_finset_sum _ (fun i _ => hT i)]
  simp only [marked_integral_eq β n T hsym _ j, Finset.sum_const, Finset.card_univ,
    Fintype.card_fin, nsmul_eq_mul]

/-- A uniform scalar bound and measurable marked vertices discharge every
integrability hypothesis of the marked-sum identity on the true finite cube. -/
theorem integral_marked_sum_of_bound (β : ℝ) (n : ℕ) (T : Fin n → (Fin n → ℝ×ℝ) → ℂ)
    (hsym : ∀ (σ : Equiv.Perm (Fin n)) i x, T i (x ∘ σ) = T (σ i) x)
    (hmeas : ∀ i, AEStronglyMeasurable (T i) (interactionMeasure β n))
    (B : ℝ) (hB : ∀ i x, ‖T i x‖ ≤ B) (j : Fin n) :
    (∫ x, ∑ i, T i x ∂interactionMeasure β n) =
      (n : ℂ) * ∫ x, T j x ∂interactionMeasure β n := by
  apply integral_marked_sum β n T hsym
  intro i
  exact (integrable_const B).mono' (hmeas i) (ae_of_all _ (hB i))

end SYK.ContinuumWickSeries
