import GibbsState
import Mathlib.Analysis.CStarAlgebra.Exponential
import Mathlib.Analysis.Complex.Hadamard
import Mathlib.Analysis.Convex.Combination

/-!
# Uniform thermal insertion estimates

The operator norm is the genuine C-star matrix norm. The estimates below retain
the ordinary positive thermal trace; they do not replace it by a dimension times
an exponential norm bound. The full multi-gap estimate is derived from the positive-trace endpoint
estimate and Hadamard interpolation on the simplex of time gaps.
-/

noncomputable section
open scoped BigOperators ComplexOrder

namespace SYK.ThermalBound

variable {n : Type*} [Fintype n] [DecidableEq n]

/-- The genuine Hilbert-space operator norm of a matrix. -/
def opNorm (A : Matrix n n ℂ) : ℝ := ‖CStarMatrix.ofMatrix A‖

/-- Unitary conjugation preserves this operator norm exactly. -/
theorem opNorm_unitary_conj (U : unitary (Matrix n n ℂ)) (A : Matrix n n ℂ) :
    opNorm ((star (U : Matrix n n ℂ)) * A * (U : Matrix n n ℂ)) = opNorm A := by
  let e : Matrix n n ℂ ≃⋆ₐ[ℂ] CStarMatrix n n ℂ := CStarMatrix.ofMatrixStarAlgEquiv
  have hu : e (U : Matrix n n ℂ) ∈ unitary (CStarMatrix n n ℂ) := unitary.map_mem e U.prop
  change ‖star (e (U : Matrix n n ℂ)) * e A * e (U : Matrix n n ℂ)‖ = ‖e A‖
  rw [CStarRing.norm_mul_mem_unitary _ hu, CStarRing.norm_mem_unitary_mul _ (unitary.star_mem hu)]

/-- A positive diagonal weight gives a dimension-free normalized trace estimate. -/
theorem norm_trace_diagonal_mul_le (d : n → ℝ) (hd : ∀ i, 0 ≤ d i) (A : Matrix n n ℂ) :
    ‖Matrix.trace (Matrix.diagonal (fun i => (d i : ℂ)) * A)‖ ≤
      (∑ i, d i) * opNorm A := by
  rw [Matrix.trace, Finset.sum_mul]
  calc
    ‖∑ i, (Matrix.diagonal (fun j => (d j : ℂ)) * A).diag i‖ ≤
        ∑ i, ‖(Matrix.diagonal (fun j => (d j : ℂ)) * A).diag i‖ := norm_sum_le _ _
    _ ≤ ∑ i, d i * opNorm A := by
      apply Finset.sum_le_sum
      intro i _
      simp only [Matrix.diag_apply, Matrix.diagonal_mul, norm_mul,
        Complex.norm_real, Real.norm_eq_abs, abs_of_nonneg (hd i)]
      exact mul_le_mul_of_nonneg_left CStarMatrix.norm_entry_le_norm (hd i)

/-- The ordinary trace of a positive semidefinite matrix is the sum of its nonnegative eigenvalues. -/
theorem trace_re_eq_sum_eigenvalues {D : Matrix n n ℂ} (hD : D.PosSemidef) :
    (Matrix.trace D).re = ∑ i, hD.isHermitian.eigenvalues i := by
  let U : (Matrix n n ℂ)ˣ := unitary.toUnits hD.isHermitian.eigenvectorUnitary
  have hs : D = (U : Matrix n n ℂ) *
      Matrix.diagonal (fun i => (hD.isHermitian.eigenvalues i : ℂ)) *
        (↑U⁻¹ : Matrix n n ℂ) := hD.isHermitian.spectral_theorem
  conv_lhs => rw [hs, Matrix.trace_units_conj, Matrix.trace_diagonal]
  simp

/-- The sharp positive trace estimate, with the actual trace weight rather than a dimension bound. -/
theorem norm_trace_positive_mul_le {D : Matrix n n ℂ} (hD : D.PosSemidef)
    (A : Matrix n n ℂ) :
    ‖Matrix.trace (D * A)‖ ≤ (Matrix.trace D).re * opNorm A := by
  let U := hD.isHermitian.eigenvectorUnitary
  let V : (Matrix n n ℂ)ˣ := unitary.toUnits U
  let d : n → ℝ := hD.isHermitian.eigenvalues
  have hs : D = (V : Matrix n n ℂ) * Matrix.diagonal (fun i => (d i : ℂ)) *
      (↑V⁻¹ : Matrix n n ℂ) := hD.isHermitian.spectral_theorem
  have ht : Matrix.trace (D * A) =
      Matrix.trace (Matrix.diagonal (fun i => (d i : ℂ)) *
        (star (U : Matrix n n ℂ) * A * (U : Matrix n n ℂ))) := by
    calc
      Matrix.trace (D * A) = Matrix.trace ((V : Matrix n n ℂ) *
          (Matrix.diagonal (fun i => (d i : ℂ)) * ((↑V⁻¹ : Matrix n n ℂ) * A))) := by
        rw [hs]
        simp only [mul_assoc]
      _ = Matrix.trace ((Matrix.diagonal (fun i => (d i : ℂ)) *
          ((↑V⁻¹ : Matrix n n ℂ) * A)) * (V : Matrix n n ℂ)) := Matrix.trace_mul_comm _ _
      _ = _ := by simp only [mul_assoc]; rfl
  rw [ht, trace_re_eq_sum_eigenvalues hD]
  exact (norm_trace_diagonal_mul_le d hD.eigenvalues_nonneg _).trans_eq
    (by rw [opNorm_unitary_conj])

/-- A one-gap thermal history satisfies exactly the required normalized operator bound. -/
theorem one_gap_bound {H : Matrix n n ℂ} (hH : H.IsHermitian) (β : ℝ)
    (A : Matrix n n ℂ) :
    ‖Matrix.trace (Gibbs.weight β H * A)‖ ≤ Gibbs.partition β H * opNorm A :=
  norm_trace_positive_mul_le (Gibbs.weight_posDef hH β).posSemidef A



/-- Ordinary trace as a continuous linear functional on operator-norm matrices. -/
def ctrace : CStarMatrix n n ℂ →L[ℂ] ℂ :=
  (Matrix.traceLinearMap n ℂ ℂ).toContinuousLinearMap.comp
    CStarMatrix.ofMatrixL.symm.toContinuousLinearMap

omit [DecidableEq n] in
@[simp] theorem ctrace_ofMatrix (A : Matrix n n ℂ) :
    ctrace (CStarMatrix.ofMatrix A) = Matrix.trace A := rfl

/-- Complex-time heat evolution in the actual matrix C-star algebra. -/
def heat (H : CStarMatrix n n ℂ) (z : ℂ) : CStarMatrix n n ℂ :=
  NormedSpace.exp ℂ ((-z) • H)

@[simp] theorem heat_zero (H : CStarMatrix n n ℂ) : heat H 0 = 1 := by
  simp [heat]

@[simp] theorem heat_real (H : Matrix n n ℂ) (t : ℝ) :
    heat (CStarMatrix.ofMatrix H) (t : ℂ) = CStarMatrix.ofMatrix (Gibbs.weight t H) := by
  change NormedSpace.exp ℂ ((-(t : ℂ)) • CStarMatrix.ofMatrix H) =
    NormedSpace.exp ℂ (CStarMatrix.ofMatrix ((-t) • H))
  congr 1
  ext i j
  simp [Complex.real_smul]

/-- The heat semigroup law is valid for complex time. -/
theorem heat_add (H : CStarMatrix n n ℂ) (z w : ℂ) :
    heat H (z + w) = heat H z * heat H w := by
  simp only [heat, neg_add, add_smul]
  exact NormedSpace.exp_add_of_commute (((Commute.refl H).smul_left (-z)).smul_right (-w))

/-- Pure imaginary heat evolution is unitary for a Hermitian Hamiltonian. -/
theorem heat_imag_unitary {H : CStarMatrix n n ℂ} (hH : IsSelfAdjoint H) (t : ℝ) :
    heat H ((t : ℂ) * Complex.I) ∈ unitary (CStarMatrix n n ℂ) := by
  apply NormedSpace.exp_mem_unitary_of_mem_skewAdjoint
  rw [skewAdjoint.mem_iff]
  simp [star_smul, hH.star_eq, star_mul, Complex.conj_ofReal, Complex.conj_I,
    neg_smul, smul_neg, mul_comm]

/-- Imaginary-time translations preserve the norm of each insertion. -/
theorem heat_norm_eq_real {H : CStarMatrix n n ℂ} (hH : IsSelfAdjoint H) (z : ℂ) :
    ‖heat H z‖ = ‖heat H (z.re : ℂ)‖ := by
  conv_lhs => rw [← Complex.re_add_im z, heat_add]
  exact CStarRing.norm_mul_mem_unitary _ (heat_imag_unitary hH z.im)

variable [Nonempty n]

@[simp] theorem opNorm_one : opNorm (1 : Matrix n n ℂ) = 1 :=
  norm_one (α := CStarMatrix n n ℂ)

/-- A bound used only to verify boundedness on the interpolation strip. -/
theorem norm_exp_le (A : CStarMatrix n n ℂ) :
    ‖NormedSpace.exp ℂ A‖ ≤ Real.exp ‖A‖ := by
  have hs : HasSum (fun k : ℕ => (k.factorial : ℝ)⁻¹ * ‖A‖ ^ k) (Real.exp ‖A‖) := by
    simpa only [Real.exp_eq_exp_ℝ, smul_eq_mul] using
      (NormedSpace.exp_series_hasSum_exp' (𝕂 := ℝ) ‖A‖)
  apply (NormedSpace.exp_series_hasSum_exp' (𝕂 := ℂ) A).norm_le_of_bounded hs
  intro k
  rw [norm_smul ((k.factorial : ℂ)⁻¹) (A ^ k), norm_inv, Complex.norm_natCast]
  exact mul_le_mul_of_nonneg_left (norm_pow_le A k) (by positivity)

theorem heat_norm_le {H : CStarMatrix n n ℂ} (hH : IsSelfAdjoint H) (z : ℂ) :
    ‖heat H z‖ ≤ Real.exp (|z.re| * ‖H‖) := by
  rw [heat_norm_eq_real hH]
  unfold heat
  calc
    ‖NormedSpace.exp ℂ ((-(z.re : ℂ)) • H)‖ ≤ Real.exp ‖(-(z.re : ℂ)) • H‖ := norm_exp_le _
    _ = Real.exp (|z.re| * ‖H‖) := by
      rw [norm_smul ((-(z.re : ℂ))) H, norm_neg, Complex.norm_real, Real.norm_eq_abs]

omit [Nonempty n] in
theorem differentiable_heat (H : CStarMatrix n n ℂ) : Differentiable ℂ (heat H) := by
  intro z
  exact (NormedSpace.exp_analytic _).differentiableAt.comp z
    ((differentiable_id.neg).smul_const H z)

/-- Equal endpoint bounds in Hadamard's theorem give the same interior bound,
including when that common bound is zero. -/
theorem three_lines_constant (f : ℂ → ℂ) {M : ℝ} (hM : 0 ≤ M)
    (hf : Differentiable ℂ f)
    (hB : BddAbove ((norm ∘ f) '' Complex.HadamardThreeLines.verticalClosedStrip 0 1))
    (h0 : ∀ z : ℂ, z.re = 0 → ‖f z‖ ≤ M)
    (h1 : ∀ z : ℂ, z.re = 1 → ‖f z‖ ≤ M)
    {z : ℂ} (hz : z.re ∈ Set.Icc (0 : ℝ) 1) : ‖f z‖ ≤ M := by
  have h := Complex.HadamardThreeLines.norm_le_interp_of_mem_verticalClosedStrip₀₁'
    f hz hf.diffContOnCl hB h0 h1
  have hp : M ^ (1 - z.re) * M ^ z.re = M := by
    rw [← Real.rpow_add' hM (by ring_nf; norm_num), sub_add_cancel, Real.rpow_one]
  exact h.trans_eq hp



/-- Ordered product; the index order is essential because insertions need not commute. -/
def orderedProd {m : ℕ} (F : Fin m → CStarMatrix n n ℂ) : CStarMatrix n n ℂ :=
  (List.ofFn F).prod

omit [Nonempty n] in
@[simp] theorem orderedProd_zero (F : Fin 0 → CStarMatrix n n ℂ) : orderedProd F = 1 := by
  simp [orderedProd]

omit [Nonempty n] in
@[simp] theorem orderedProd_succ {m : ℕ} (F : Fin (m + 1) → CStarMatrix n n ℂ) :
    orderedProd F = F 0 * orderedProd (fun i => F i.succ) := by
  simp only [orderedProd, List.ofFn_succ, List.prod_cons]

theorem norm_orderedProd_le {m : ℕ} (F : Fin m → CStarMatrix n n ℂ) :
    ‖orderedProd F‖ ≤ ∏ i, ‖F i‖ := by
  simpa [orderedProd, List.map_ofFn, List.prod_ofFn] using List.norm_prod_le (List.ofFn F)

omit [Nonempty n] in
theorem differentiable_orderedProd {m : ℕ} (F : Fin m → ℂ → CStarMatrix n n ℂ)
    (hF : ∀ i, Differentiable ℂ (F i)) :
    Differentiable ℂ (fun z => orderedProd (fun i => F i z)) := by
  induction m with
  | zero => simp
  | succ m ih =>
    simp only [orderedProd_succ]
    exact (hF 0).mul (ih _ (fun i => hF i.succ))

/-- Cyclic thermal product with one insertion after each complex-time gap. -/
def history {m : ℕ} (H : CStarMatrix n n ℂ) (t : Fin m → ℂ)
    (A : Fin m → CStarMatrix n n ℂ) : CStarMatrix n n ℂ :=
  orderedProd (fun i => heat H (t i) * A i)

/-- Affine complex interpolation of two real time gaps. -/
def blend (s t : ℝ) (z : ℂ) : ℂ := (1 - z) * (s : ℂ) + z * (t : ℂ)

@[simp] theorem blend_re (s t : ℝ) (z : ℂ) :
    (blend s t z).re = (1 - z.re) * s + z.re * t := by simp [blend]

@[simp] theorem blend_real (s t x : ℝ) :
    blend s t (x : ℂ) = (((1 - x) * s + x * t : ℝ) : ℂ) := by
  simp [blend, Complex.ofReal_add, Complex.ofReal_sub, Complex.ofReal_mul]

theorem blend_re_abs_le (s t : ℝ) {z : ℂ} (hz : z.re ∈ Set.Icc (0 : ℝ) 1) :
    |(blend s t z).re| ≤ |s| + |t| := by
  rw [blend_re]
  calc
    |(1 - z.re) * s + z.re * t| ≤ |(1 - z.re) * s| + |z.re * t| := abs_add_le _ _
    _ = (1 - z.re) * |s| + z.re * |t| := by
      rw [abs_mul, abs_mul, abs_of_nonneg (sub_nonneg.mpr hz.2), abs_of_nonneg hz.1]
    _ ≤ |s| + |t| := by
      have h1 := mul_nonneg hz.1 (abs_nonneg s)
      have h2 := mul_nonneg (sub_nonneg.mpr hz.2) (abs_nonneg t)
      nlinarith

theorem differentiable_blend_history {m : ℕ} (H : CStarMatrix n n ℂ)
    (s t : Fin m → ℝ) (A : Fin m → CStarMatrix n n ℂ) :
    Differentiable ℂ (fun z => ctrace (history H (fun i => blend (s i) (t i) z) A)) := by
  apply (ctrace (n := n)).differentiable.comp
  apply differentiable_orderedProd
  intro i
  apply Differentiable.mul_const
  exact (differentiable_heat H).comp
    (((differentiable_const _).sub differentiable_id).mul_const _ |>.add
      (differentiable_id.mul_const _))

/-- The interpolation function is uniformly bounded along the infinite strip.
This auxiliary bound is deliberately not the final thermal moment estimate. -/
theorem blend_history_bddAbove {m : ℕ} {H : CStarMatrix n n ℂ}
    (hH : IsSelfAdjoint H) (s t : Fin m → ℝ) (A : Fin m → CStarMatrix n n ℂ) :
    BddAbove ((norm ∘ (fun z => ctrace (history H (fun i => blend (s i) (t i) z) A))) ''
      Complex.HadamardThreeLines.verticalClosedStrip 0 1) := by
  refine ⟨‖(ctrace : CStarMatrix n n ℂ →L[ℂ] ℂ)‖ *
      ∏ i, (Real.exp ((|s i| + |t i|) * ‖H‖) * ‖A i‖), ?_⟩
  rintro _ ⟨z, hz, rfl⟩
  apply ((ctrace (n := n)).le_opNorm _).trans
  apply mul_le_mul_of_nonneg_left _ (norm_nonneg _)
  apply (norm_orderedProd_le _).trans
  apply Finset.prod_le_prod (fun i _ => norm_nonneg _)
  intro i _
  apply (norm_mul_le _ _).trans
  apply mul_le_mul_of_nonneg_right _ (norm_nonneg _)
  apply (heat_norm_le hH _).trans
  exact Real.exp_le_exp.mpr (mul_le_mul_of_nonneg_right (blend_re_abs_le _ _ hz) (norm_nonneg _))

omit [Nonempty n] in
/-- Separate the real thermal evolution from the imaginary unitary in every gap. -/
theorem history_real_twist {m : ℕ} (H : CStarMatrix n n ℂ) (z : Fin m → ℂ)
    (A : Fin m → CStarMatrix n n ℂ) :
    history H z A = history H (fun i => ((z i).re : ℂ))
      (fun i => heat H (((z i).im : ℂ) * Complex.I) * A i) := by
  unfold history
  apply congrArg orderedProd
  funext i
  rw [← Complex.re_add_im (z i), heat_add]
  simp only [mul_assoc, Complex.add_re, Complex.ofReal_re, Complex.mul_re,
    Complex.ofReal_im, Complex.I_re, mul_zero, Complex.I_im, zero_mul, sub_self,
    add_zero, Complex.add_im, Complex.mul_im, zero_add, mul_one]

/-- Real gap vectors for which the sharp trace bound holds for every insertion. -/
def Admissible {m : ℕ} (H : CStarMatrix n n ℂ) (Z : ℝ) : Set (Fin m → ℝ) :=
  {t | ∀ A : Fin m → CStarMatrix n n ℂ,
    ‖ctrace (history H (fun i => (t i : ℂ)) A)‖ ≤ Z * ∏ i, ‖A i‖}

/-- Hadamard interpolation proves convexity of the sharp-bound region. -/
theorem admissible_convex {m : ℕ} {H : CStarMatrix n n ℂ}
    (hH : IsSelfAdjoint H) {Z : ℝ} (hZ : 0 ≤ Z) : Convex ℝ (Admissible (m := m) H Z) := by
  intro s hs t ht a b ha hb hab A
  let F : ℂ → ℂ := fun z => ctrace (history H (fun i => blend (s i) (t i) z) A)
  have hedge (x : ℝ) (hx : (fun i => (1 - x) * s i + x * t i) ∈ Admissible H Z)
      (z : ℂ) (hz : z.re = x) : ‖F z‖ ≤ Z * ∏ i, ‖A i‖ := by
    dsimp [F]
    rw [history_real_twist]
    simp only [blend_re, hz]
    have h := hx (fun i => heat H (((blend (s i) (t i) z).im : ℂ) * Complex.I) * A i)
    simpa only [CStarRing.norm_mem_unitary_mul _ (heat_imag_unitary hH _)] using h
  have hbound := three_lines_constant F
    (mul_nonneg hZ (Finset.prod_nonneg (fun i _ => norm_nonneg (A i))))
    (differentiable_blend_history H s t A) (blend_history_bddAbove hH s t A)
    (hedge 0 (by simpa using hs)) (hedge 1 (by simpa using ht))
    (z := (b : ℂ)) (by simpa using (show b ∈ Set.Icc (0 : ℝ) 1 from ⟨hb, by linarith⟩))
  have ha' : a = 1 - b := by linarith
  simpa only [F, blend_real, Pi.add_apply, Pi.smul_apply, smul_eq_mul, ha'] using hbound



omit [DecidableEq n] [Nonempty n] in
@[simp] theorem ctrace_mul_comm (A B : CStarMatrix n n ℂ) :
    ctrace (A * B) = ctrace (B * A) :=
  Matrix.trace_mul_comm (CStarMatrix.ofMatrix.symm A) (CStarMatrix.ofMatrix.symm B)

omit [Nonempty n] in
@[simp] theorem history_zero {m : ℕ} (H : CStarMatrix n n ℂ)
    (A : Fin m → CStarMatrix n n ℂ) : history H (fun _ => 0) A = orderedProd A := by
  simp [history]

/-- The simplex vertex placing the whole thermal period in a single gap. -/
def vertex {m : ℕ} (β : ℝ) (j : Fin m) : Fin m → ℝ := fun i => if i = j then β else 0

/-- A single-gap cyclic history obeys the sharp bound, including arbitrary
noncommuting insertions before and after the thermal gap. -/
theorem vertex_bound {H : Matrix n n ℂ} (hH : H.IsHermitian) (β : ℝ) :
    ∀ {m : ℕ} (j : Fin m) (A : Fin m → CStarMatrix n n ℂ) (B : CStarMatrix n n ℂ),
    ‖ctrace (history (CStarMatrix.ofMatrix H) (fun i => (vertex β j i : ℂ)) A * B)‖ ≤
      Gibbs.partition β H * (∏ i, ‖A i‖) * ‖B‖ := by
  intro m
  induction m with
  | zero => intro j; exact Fin.elim0 j
  | succ m ih =>
    intro j
    refine Fin.cases ?_ (fun j => ?_) j
    · intro A B
      have h := one_gap_bound hH β (CStarMatrix.ofMatrix.symm
        (A 0 * orderedProd (fun i => A i.succ) * B))
      have hh : history (CStarMatrix.ofMatrix H) (fun i => (vertex β (0 : Fin (m+1)) i : ℂ)) A =
          heat (CStarMatrix.ofMatrix H) (β : ℂ) * A 0 * orderedProd (fun i => A i.succ) := by
        simp only [history, orderedProd_succ, vertex, Fin.succ_ne_zero,
          if_true, if_false, Complex.ofReal_zero, heat_zero, one_mul, mul_assoc]
      rw [hh]
      have hp := (Gibbs.partition_pos hH β).le
      change ‖ctrace ((heat (CStarMatrix.ofMatrix H) (β : ℂ) * A 0 *
        orderedProd (fun i => A i.succ)) * B)‖ ≤ _
      calc
        _ = ‖ctrace (heat (CStarMatrix.ofMatrix H) (β : ℂ) *
            (A 0 * orderedProd (fun i => A i.succ) * B))‖ := by simp only [mul_assoc]
        _ ≤ Gibbs.partition β H * ‖A 0 * orderedProd (fun i => A i.succ) * B‖ := by
          simpa only [heat_real, opNorm] using h
        _ ≤ Gibbs.partition β H * ((‖A 0‖ * ∏ i : Fin m, ‖A i.succ‖) * ‖B‖) := by
          apply mul_le_mul_of_nonneg_left _ hp
          exact (norm_mul_le (A 0 * orderedProd (fun i => A i.succ)) B).trans
            (mul_le_mul_of_nonneg_right
              ((norm_mul_le (A 0) (orderedProd (fun i => A i.succ))).trans
                (mul_le_mul_of_nonneg_left (norm_orderedProd_le _) (norm_nonneg (A 0))))
              (norm_nonneg B))
        _ = _ := by rw [Fin.prod_univ_succ]; ring
    · intro A B
      have hh : history (CStarMatrix.ofMatrix H) (fun i => (vertex β j.succ i : ℂ)) A =
          A 0 * history (CStarMatrix.ofMatrix H) (fun i => (vertex β j i : ℂ))
            (fun i => A i.succ) := by
        simp only [history, orderedProd_succ, vertex, (Fin.succ_ne_zero j).symm,
          Fin.succ_inj, if_false, Complex.ofReal_zero, heat_zero, one_mul]
      rw [hh]
      have hp : 0 ≤ Gibbs.partition β H * ∏ i : Fin m, ‖A i.succ‖ :=
        mul_nonneg (Gibbs.partition_pos hH β).le (Finset.prod_nonneg (fun i _ => norm_nonneg _))
      calc
        _ = ‖ctrace (history (CStarMatrix.ofMatrix H) (fun i => (vertex β j i : ℂ))
            (fun i => A i.succ) * (B * A 0))‖ := by
          rw [mul_assoc, ctrace_mul_comm]
          simp only [mul_assoc]
        _ ≤ Gibbs.partition β H * (∏ i : Fin m, ‖A i.succ‖) * ‖B * A 0‖ := ih j _ _
        _ ≤ Gibbs.partition β H * (∏ i : Fin m, ‖A i.succ‖) * (‖B‖ * ‖A 0‖) :=
          mul_le_mul_of_nonneg_left (norm_mul_le _ _) hp
        _ = _ := by rw [Fin.prod_univ_succ]; ring

/-- Every vertex belongs to the proven sharp-bound region. -/
theorem vertex_admissible {H : Matrix n n ℂ} (hH : H.IsHermitian) (β : ℝ)
    {m : ℕ} (j : Fin m) : vertex β j ∈ Admissible (CStarMatrix.ofMatrix H) (Gibbs.partition β H) := by
  intro A
  simpa using vertex_bound hH β j A 1

/-- The exact multi-gap thermal trace bound, for arbitrary noncommuting insertions.
Its proof uses only the actual positive Gibbs trace and Hadamard interpolation. -/
theorem thermal_history_bound {H : Matrix n n ℂ} (hH : H.IsHermitian)
    {β : ℝ} (hβ : 0 < β) {m : ℕ} (t : Fin m → ℝ)
    (ht : ∀ i, 0 ≤ t i) (hsum : ∑ i, t i = β) (A : Fin m → CStarMatrix n n ℂ) :
    ‖ctrace (history (CStarMatrix.ofMatrix H) (fun i => (t i : ℂ)) A)‖ ≤
      Gibbs.partition β H * ∏ i, ‖A i‖ := by
  have hH' : IsSelfAdjoint (CStarMatrix.ofMatrix H) := hH
  have hc := admissible_convex (m := m) hH' (Gibbs.partition_pos hH β).le
  have hcomb := hc.sum_mem (t := Finset.univ) (w := fun i => t i / β)
    (z := fun i => vertex β i) (fun i _ => div_nonneg (ht i) hβ.le)
    (by rw [← Finset.sum_div, hsum, div_self hβ.ne']) (fun i _ => vertex_admissible hH β i)
  have heq : (∑ i, (t i / β) • vertex β i) = t := by
    funext j
    simp [vertex, Finset.sum_apply, div_mul_cancel₀ _ hβ.ne']
  rw [heq] at hcomb
  exact hcomb A



/-- The same sharp estimate stated entirely with ordinary matrices. -/
theorem matrix_history_bound {H : Matrix n n ℂ} (hH : H.IsHermitian)
    {β : ℝ} (hβ : 0 < β) {m : ℕ} (t : Fin m → ℝ)
    (ht : ∀ i, 0 ≤ t i) (hsum : ∑ i, t i = β) (A : Fin m → Matrix n n ℂ) :
    ‖Matrix.trace ((List.ofFn (fun i => Gibbs.weight (t i) H * A i)).prod)‖ ≤
      Gibbs.partition β H * ∏ i, opNorm (A i) := by
  have h := thermal_history_bound hH hβ t ht hsum (fun i => CStarMatrix.ofMatrix (A i))
  simp only [history, heat_real] at h
  exact h

/-- Usual transfer-product notation with the final heat gap after the last insertion. -/
theorem transfer_product_bound {H : Matrix n n ℂ} (hH : H.IsHermitian)
    {β : ℝ} (hβ : 0 < β) {k : ℕ} (t : Fin (k+1) → ℝ)
    (ht : ∀ i, 0 ≤ t i) (hsum : ∑ i, t i = β) (A : Fin k → Matrix n n ℂ) :
    ‖Matrix.trace ((List.ofFn (fun i => Gibbs.weight (t i.castSucc) H * A i)).prod *
        Gibbs.weight (t (Fin.last k)) H)‖ ≤ Gibbs.partition β H * ∏ i, opNorm (A i) := by
  have h := matrix_history_bound hH hβ t ht hsum (Fin.snoc A 1)
  rw [List.ofFn_succ', List.prod_concat, Fin.prod_univ_castSucc] at h
  simpa only [Fin.snoc_castSucc, Fin.snoc_last, mul_one, opNorm_one] using h

/-- Normalized actual thermal history. -/
def normalizedHistory {m : ℕ} (H : Matrix n n ℂ) (β : ℝ) (t : Fin m → ℝ)
    (A : Fin m → Matrix n n ℂ) : ℂ :=
  (Gibbs.partition β H : ℂ)⁻¹ *
    Matrix.trace ((List.ofFn (fun i => Gibbs.weight (t i) H * A i)).prod)

/-- Normalization removes the actual Gibbs partition factor exactly. -/
theorem normalized_history_bound {H : Matrix n n ℂ} (hH : H.IsHermitian)
    {β : ℝ} (hβ : 0 < β) {m : ℕ} (t : Fin m → ℝ)
    (ht : ∀ i, 0 ≤ t i) (hsum : ∑ i, t i = β) (A : Fin m → Matrix n n ℂ) :
    ‖normalizedHistory H β t A‖ ≤ ∏ i, opNorm (A i) := by
  have hp := Gibbs.partition_pos hH β
  rw [normalizedHistory, norm_mul, norm_inv, Complex.norm_real, Real.norm_eq_abs, abs_of_pos hp]
  calc
    _ ≤ (Gibbs.partition β H)⁻¹ * (Gibbs.partition β H * ∏ i, opNorm (A i)) :=
      mul_le_mul_of_nonneg_left (matrix_history_bound hH hβ t ht hsum A) (inv_nonneg.mpr hp.le)
    _ = _ := by rw [← mul_assoc, inv_mul_cancel₀ hp.ne', one_mul]

/-- The exact uniform bound for any concrete Majorana word in an arbitrary
Hermitian Gibbs state, allowing zero gaps and repeated flavors. -/
theorem majorana_history_bound (d k : ℕ) {H : Matrix (Majorana.Basis d) (Majorana.Basis d) ℂ}
    (hH : H.IsHermitian) {β : ℝ} (hβ : 0 < β) (t : Fin k → ℝ)
    (ht : ∀ i, 0 ≤ t i) (hsum : ∑ i, t i = β) (v : Fin k → Fin (2*d)) :
    ‖normalizedHistory H β t (fun i => Majorana.chiFin d (v i))‖ ≤
      ((Real.sqrt 2)⁻¹) ^ k := by
  have h := normalized_history_bound hH hβ t ht hsum (fun i => Majorana.chiFin d (v i))
  simpa only [opNorm, Majorana.chiFin, Majorana.norm_chi, Finset.prod_const,
    Finset.card_univ, Fintype.card_fin] using h

/-- For 2m fields the bound is exactly 2^(-m), independently of dimension,
couplings, times, repeated flavors, or endpoint collisions. -/
theorem majorana_even_history_bound (d m : ℕ)
    {H : Matrix (Majorana.Basis d) (Majorana.Basis d) ℂ} (hH : H.IsHermitian)
    {β : ℝ} (hβ : 0 < β) (t : Fin (2*m) → ℝ)
    (ht : ∀ i, 0 ≤ t i) (hsum : ∑ i, t i = β) (v : Fin (2*m) → Fin (2*d)) :
    ‖normalizedHistory H β t (fun i => Majorana.chiFin d (v i))‖ ≤ (1 / 2 : ℝ) ^ m := by
  have h := majorana_history_bound d (2*m) hH hβ t ht hsum v
  have hp : ((Real.sqrt 2)⁻¹ : ℝ)^2 = 1/2 := by
    rw [inv_pow, Real.sq_sqrt (by norm_num)]; norm_num
  simpa only [pow_mul, hp] using h

end SYK.ThermalBound
