import FieldDisorderSeries
import InsertedWickSymmetry
import CollectiveFieldExpansion
import ActualWickChamberSeries
import CollectiveWeylAverage
import WickSeriesPressure

/-!
# The physical interacting Wick correspondence at all external configurations

The finite Weyl sum handles all external collisions exactly; interaction-time
collisions are removed only on their proved Lebesgue-null sets.
-/
noncomputable section
open scoped BigOperators NNReal ComplexOrder
open MeasureTheory
namespace SYK.ActualWickCorrespondence
open ThermalWick Interacting InsertedWickSeries InsertedWickSymmetry

/-- Every sorting of distinct complete external labels is compatible with
actual equal-time CAR/Weyl conventions. Distinct times are not required. -/
theorem sorted_labels_compatible (d : ℕ) {β : ℝ} {m : ℕ}
    (L : Fin m → Label (2*d) β) (hL : Function.Injective L)
    (σ : Equiv.Perm (Fin m)) (hσ : σ ∈ sortingPerms (fun i => (L i).2.val)) :
    (List.ofFn (L ∘ σ)).Pairwise (fun p q => q.2.val < p.2.val ∨ p.1 ≠ q.1) := by
  apply List.pairwise_ofFn.mpr
  intro i j hij
  have htime := (mem_sortingPerms _ σ).mp hσ hij.le
  dsimp only [Function.comp_def] at htime ⊢
  rcases lt_or_eq_of_le htime with hlt | heq
  · exact Or.inl hlt
  · right
    intro hflavor
    apply (ne_of_lt hij) (σ.injective (hL ?_))
    apply Prod.ext hflavor
    apply Subtype.ext
    exact heq.symm

/-- The actual annealed Weyl numerator has exact repeated-label exclusion,
even with the interacting Hamiltonian and arbitrary endpoint coincidences. -/
theorem annealedWeyl_zero_of_repeat (d : ℕ) {β : ℝ} (lam : ℝ≥0) {m : ℕ}
    (L : Fin m → Label (2*d) β) (i j : Fin m) (hij : i ≠ j) (hL : L i = L j) :
    ((2 : ℂ)^d)⁻¹ * (∫ z, weylNumerator (Majorana.hamiltonian d z) β
      (fun r => (L r).2.val) (fun r => Majorana.chiFin d (L r).1)
      ∂Microscopic.disorder d lam) = 0 := by
  have ht : (L i).2.val = (L j).2.val := congrArg (fun p : Label (2*d) β => p.2.val) hL
  have ha : Majorana.chiFin d (L i).1 = Majorana.chiFin d (L j).1 :=
    congrArg (fun p : Label (2*d) β => Majorana.chiFin d p.1) hL
  have hz (z : Majorana.FourSet d → ℝ) : weylNumerator (Majorana.hamiltonian d z) β
      (fun r => (L r).2.val) (fun r => Majorana.chiFin d (L r).1) = 0 :=
    weylNumerator_eq_zero_of_repeat (Majorana.hamiltonian d z) β
      (fun r => (L r).2.val) (fun r => Majorana.chiFin d (L r).1) i j hij ht ha
  simp_rw [hz]
  simp

/-- The genuine interacting exterior series of a sorted, tie-compatible
external word is its actual normalized annealed operator transfer history. -/
theorem fieldNumerator_sorted_eq_ordered (d : ℕ) (hd : 0 < d) {β : ℝ}
    (hβ : 0 < β) (lam : ℝ≥0) {m : ℕ} (L : Fin m → Label (2*d) β)
    (heven : Even m) (horder : Antitone (fun i => (L i).2.val))
    (htie : (List.ofFn L).Pairwise (fun p q => q.2.val < p.2.val ∨ p.1 ≠ q.1)) :
    fieldNumerator d hβ (List.ofFn L) (lam : ℝ) =
      ∫ j, Majorana.normalizedTrace d
        (timeProduct (Majorana.hamiltonian d j) β (fun i => (L i).2.val)
          (fun i => Majorana.chiFin d (L i).1)) ∂Microscopic.disorder d lam := by
  rw [FieldDisorderSeries.fieldNumerator_eq_integral_disorderSeries d hd hβ (List.ofFn L)
    (by simpa using heven)]
  apply integral_congr_ae
  exact Filter.Eventually.of_forall (fun j =>
    (ActualWickChamberSeries.hasSum_sorted_disorderCoefficient d hβ L heven horder htie j).tsum_eq)

/-- The full physical interacting Wick correspondence for an arbitrary even
external field tuple. External ordering, ties, and repeated complete labels
are all resolved by the exact finite Weyl convention. -/
theorem fieldNumerator_eq_annealedWeyl (d : ℕ) (hd : 0 < d) {β : ℝ}
    (hβ : 0 < β) (lam : ℝ≥0) {m : ℕ} (L : Fin m → Label (2*d) β) (heven : Even m) :
    fieldNumerator d hβ (List.ofFn L) (lam : ℝ) =
      ((2 : ℂ)^d)⁻¹ * (∫ j, weylNumerator (Majorana.hamiltonian d j) β
        (fun i => (L i).2.val) (fun i => Majorana.chiFin d (L i).1)
        ∂Microscopic.disorder d lam) := by
  classical
  by_cases hinj : Function.Injective L
  · rw [annealedWeyl_eq_average]
    symm
    apply FreeWeyl.signedAverage_eq _ (sortingPerms_nonempty _)
    intro σ hσ
    have ho : Antitone (fun i => (L (σ i)).2.val) := (mem_sortingPerms _ σ).mp hσ
    have ht := sorted_labels_compatible d L hinj σ hσ
    have he := fieldNumerator_sorted_eq_ordered d hd hβ lam (L ∘ σ) heven ho ht
    change Equiv.Perm.sign σ • (∫ j, Majorana.normalizedTrace d
      (timeProduct (Majorana.hamiltonian d j) β (fun i => ((L ∘ σ) i).2.val)
        (fun i => Majorana.chiFin d ((L ∘ σ) i).1)) ∂Microscopic.disorder d lam) = _
    rw [← he, fieldNumerator_permutation]
    rcases Int.units_eq_one_or (Equiv.Perm.sign σ) with h | h <;> simp [h]
  · simp only [Function.Injective, not_forall, _root_.not_imp] at hinj
    obtain ⟨i,j,hL,hne⟩ := hinj
    rw [fieldNumerator_zero_of_repeat d hβ L i j hne hL]
    exact (annealedWeyl_zero_of_repeat d lam L i j hne hL).symm

/-- The genuine collective continuum numerator is the dimension-normalized
Gaussian average of the physical collective operator numerator, at every
fundamental-domain endpoint configuration, including all coincidences. -/
theorem numerator_eq_annealedCollective (d : ℕ) (hd : 0 < d) {β : ℝ}
    (hβ : 0 < β) (lam : ℝ≥0) (ps : List (Time β × Time β)) :
    ContinuumWickSeries.numerator d β hβ ps (lam : ℝ) =
      ((2 : ℂ)^d)⁻¹ * (∫ j, collectiveNumerator d (Majorana.hamiltonian d j) β
        (CollectiveWeylAverage.endpointTuple ps) ∂Microscopic.disorder d lam) := by
  rw [CollectiveFieldExpansion.numerator_eq_field_sum d hd hβ ps (lam : ℝ)]
  simp_rw [CollectiveFieldExpansion.pairLabelList,
    fieldNumerator_eq_annealedWeyl d hd hβ lam _ (Even.mul_left (by decide : Even 2) ps.length)]
  exact CollectiveWeylAverage.normalized_flavor_average d lam ps

/-- The actual annealed SYK collective moment equals the fully convergent
continuum Wick series ratio. Every microscopic construction, Gaussian/time
integral, coefficient, collision convention and convergence estimate is
already proved; only the model parameters remain as hypotheses. -/
theorem normalizedMoment_eq_collectiveMoment (d : ℕ) (hd : 0 < d) {β : ℝ}
    (hβ : 0 < β) (lam : ℝ≥0) (ps : List (Time β × Time β)) :
    ContinuumWickSeries.normalizedMoment d β hβ ps (lam : ℝ) =
      collectiveMoment d β lam
        (fun i : Fin ps.length => ((ps.get i).1.val, (ps.get i).2.val)) := by
  rw [ContinuumWickSeries.normalizedMoment,
    CollectiveFieldExpansion.numerator_eq_field_sum d hd hβ ps (lam : ℝ),
    WickGaussianRegrouping.numerator_empty_eq_partition d hd hβ lam]
  simp_rw [CollectiveFieldExpansion.pairLabelList,
    fieldNumerator_eq_annealedWeyl d hd hβ lam _ (Even.mul_left (by decide : Even 2) ps.length)]
  exact CollectiveWeylAverage.normalized_flavor_average_ratio d lam ps

end SYK.ActualWickCorrespondence
