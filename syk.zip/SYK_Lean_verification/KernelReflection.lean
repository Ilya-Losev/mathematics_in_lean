import KernelSpace

/-!
# Exact endpoint reflection of integral kernels

Reflection reverses the composition order. The substitution is made in the
actual finite-interval Bochner integral, preserving all external endpoint values.
-/

noncomputable section
namespace SYK

open MeasureTheory Set

variable {A : Type*} [NormedCommRing A] [NormedAlgebra ℂ A] [NormOneClass A]

/-- The endpoint reversal used by thermal reflection. The coefficient
involution, when present, is a separate operation. -/
def reflectKernel (β : ℝ) (f : KernelSpace A) : KernelSpace A :=
  kernelOfFunction (fun p => f (β-p.2,β-p.1))
    ((KernelSpace.stronglyMeasurable f).comp_measurable
      ((measurable_const.sub measurable_snd).prodMk (measurable_const.sub measurable_fst)))
    ‖f‖ (fun _ => kernel_norm_apply_le f _)

@[simp] theorem reflectKernel_apply (β : ℝ) (f : KernelSpace A) (s t : ℝ) :
    reflectKernel β f (s,t) = f (β-t,β-s) := rfl

@[simp] theorem reflectKernel_involutive (β : ℝ) (f : KernelSpace A) :
    reflectKernel β (reflectKernel β f) = f := by
  ext p
  rcases p with ⟨s,t⟩
  simp only [reflectKernel_apply, sub_sub_cancel]

theorem reflectKernel_norm_le (β : ℝ) (f : KernelSpace A) :
    ‖reflectKernel β f‖ ≤ ‖f‖ :=
  lp.norm_le_of_forall_le (norm_nonneg _) (fun _ => kernel_norm_apply_le f _)

@[simp] theorem reflectKernel_norm (β : ℝ) (f : KernelSpace A) :
    ‖reflectKernel β f‖ = ‖f‖ := by
  apply le_antisymm (reflectKernel_norm_le β f)
  simpa only [reflectKernel_involutive] using reflectKernel_norm_le β (reflectKernel β f)

@[simp] theorem reflectKernel_add (β : ℝ) (f g : KernelSpace A) :
    reflectKernel β (f+g) = reflectKernel β f+reflectKernel β g := by
  ext p; rfl

@[simp] theorem reflectKernel_sub (β : ℝ) (f g : KernelSpace A) :
    reflectKernel β (f-g) = reflectKernel β f-reflectKernel β g := by
  ext p; rfl

@[simp] theorem reflectKernel_smul (β : ℝ) (c : ℂ) (f : KernelSpace A) :
    reflectKernel β (c • f) = c • reflectKernel β f := by
  ext p; rfl

@[simp] theorem reflectKernel_mul (β : ℝ) (f g : KernelSpace A) :
    reflectKernel β (f*g) = reflectKernel β f*reflectKernel β g := by
  ext p; rfl

@[simp] theorem reflectKernel_one (β : ℝ) :
    reflectKernel β (1 : KernelSpace A) = 1 := by
  ext p; rfl

@[simp] theorem reflectKernel_pow (β : ℝ) (f : KernelSpace A) (n : ℕ) :
    reflectKernel β (f^n) = (reflectKernel β f)^n := by
  induction n with
  | zero => simp only [pow_zero, reflectKernel_one]
  | succ n ih => simp only [pow_succ, reflectKernel_mul, ih]

@[simp] theorem reflectKernel_free (β : ℝ) :
    reflectKernel β (freeThermalKernel (A := A) β) = freeThermalKernel β := by
  ext p
  rcases p with ⟨s,t⟩
  simp only [reflectKernel_apply, freeThermalKernel_apply, Thermal.kernel]
  rw [show (β-t)-(β-s) = s-t by ring]

/-- Reflection reverses real translations exactly. -/
theorem reflectKernel_translate (β u : ℝ) (f : KernelSpace A) :
    reflectKernel β (translateKernel u f) = translateKernel (-u) (reflectKernel β f) := by
  ext p
  rcases p with ⟨s,t⟩
  simp only [reflectKernel_apply, translateKernel_apply]
  congr 1 <;> congr 1 <;> ring

variable [NormedSpace ℝ A] [IsScalarTower ℝ ℂ A] [CompleteSpace A]

/-- Reflection reverses the actual Bochner convolution. Commutativity of the
coefficient algebra is used only to reverse the two pointwise factors. -/
theorem reflectKernel_convolution (β : ℝ) (hβ : 0 ≤ β) (f g : KernelSpace A) :
    reflectKernel β (kernelConvolution β hβ f g) =
      kernelConvolution β hβ (reflectKernel β g) (reflectKernel β f) := by
  ext p
  rcases p with ⟨s,t⟩
  change (∫ v in (0 : ℝ)..β, f (β-t,v)*g (v,β-s)) =
    ∫ v in (0 : ℝ)..β, g (β-v,β-s)*f (β-t,β-v)
  have he := intervalIntegral.integral_comp_sub_left
    (fun v => f (β-t,v)*g (v,β-s)) β (a := 0) (b := β)
  simpa only [sub_self, sub_zero, mul_comm] using he.symm

end SYK
