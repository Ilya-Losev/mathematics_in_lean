import Mathlib.Analysis.SpecialFunctions.Trigonometric.Basic
import Mathlib.MeasureTheory.Constructions.BorelSpace.Basic
import Mathlib.Tactic

/-!
# The actual midpoint-prescribed free thermal covariance

Using the sign of sin(πr/β) realizes exactly the antiperiodic step function,
including value zero at every multiple of β. The sine is used only to define
its sign; this covariance is piecewise constant, not a sine propagator.
-/

noncomputable section
namespace SYK.Thermal

def halfSign (x : ℝ) : ℝ := if 0 < x then 1 / 2 else if x < 0 then -(1 / 2) else 0

@[simp] theorem halfSign_zero : halfSign 0 = 0 := by norm_num [halfSign]

theorem halfSign_neg (x : ℝ) : halfSign (-x) = -halfSign x := by
  rcases lt_trichotomy x 0 with h | h | h
  · simp [halfSign, h, not_lt_of_ge (le_of_lt h), neg_pos.mpr h]
  · subst x; simp
  · simp [halfSign, h, not_lt_of_ge (le_of_lt h), neg_neg_of_pos h]

theorem abs_halfSign_le (x : ℝ) : |halfSign x| ≤ 1 / 2 := by
  unfold halfSign
  split_ifs <;> norm_num [abs_div]

theorem halfSign_measurable : Measurable halfSign := by
  exact Measurable.ite (measurableSet_lt measurable_const measurable_id) measurable_const
    (Measurable.ite (measurableSet_lt measurable_id measurable_const)
      measurable_const measurable_const)

def covariance (β r : ℝ) : ℝ := halfSign (Real.sin (Real.pi * r / β))

theorem covariance_measurable (β : ℝ) : Measurable (covariance β) := by
  exact halfSign_measurable.comp
    (Real.continuous_sin.comp ((continuous_const.mul continuous_id).div_const β)).measurable

@[simp] theorem covariance_zero (β : ℝ) : covariance β 0 = 0 := by
  simp [covariance]

theorem covariance_neg (β r : ℝ) : covariance β (-r) = -covariance β r := by
  simp [covariance, mul_neg, neg_div, Real.sin_neg, halfSign_neg]

theorem covariance_antiperiodic (β : ℝ) (hβ : β ≠ 0) (r : ℝ) :
    covariance β (r + β) = -covariance β r := by
  have he : Real.pi * (r + β) / β = Real.pi * r / β + Real.pi := by
    field_simp
    ring
  simp only [covariance, he, Real.sin_add_pi, halfSign_neg]

theorem covariance_on_interval (β : ℝ) (hβ : 0 < β) (r : ℝ)
    (hr : 0 < r) (hrβ : r < β) : covariance β r = 1 / 2 := by
  have hp : 0 < Real.pi * r / β := by positivity
  have hq : Real.pi * r / β < Real.pi := by
    rw [div_lt_iff₀ hβ]
    exact mul_lt_mul_of_pos_left hrβ Real.pi_pos
  simp [covariance, halfSign, Real.sin_pos_of_pos_of_lt_pi hp hq]

theorem abs_covariance_le (β r : ℝ) : |covariance β r| ≤ 1 / 2 :=
  abs_halfSign_le _

def kernel (β s t : ℝ) : ℝ := covariance β (s - t)

theorem kernel_measurable (β : ℝ) : Measurable (fun p : ℝ × ℝ => kernel β p.1 p.2) := by
  exact (covariance_measurable β).comp (measurable_fst.sub measurable_snd)

@[simp] theorem kernel_diagonal (β s : ℝ) : kernel β s s = 0 := by
  simp [kernel]

theorem kernel_skew (β s t : ℝ) : kernel β t s = -kernel β s t := by
  unfold kernel
  rw [show t - s = -(s - t) by ring, covariance_neg]

theorem kernel_translation (β s t u : ℝ) : kernel β (s + u) (t + u) = kernel β s t := by
  unfold kernel
  congr 1
  ring

/-- On the fundamental square this is exactly the manuscript's sign covariance. -/
theorem kernel_on_fundamental (β : ℝ) (hβ : 0 < β) (s t : ℝ)
    (hs : s ∈ Set.Ico 0 β) (ht : t ∈ Set.Ico 0 β) :
    kernel β s t = halfSign (s - t) := by
  rcases lt_trichotomy t s with h | h | h
  · have hd : 0 < s - t := sub_pos.mpr h
    have hdβ : s - t < β := by linarith [hs.2, ht.1]
    simp [kernel, covariance_on_interval β hβ (s - t) hd hdβ, halfSign, hd]
  · subst t; simp
  · have hd : 0 < t - s := sub_pos.mpr h
    have hdβ : t - s < β := by linarith [ht.2, hs.1]
    rw [kernel_skew, kernel, covariance_on_interval β hβ (t - s) hd hdβ]
    simp [halfSign, sub_neg.mpr h, not_lt_of_ge (le_of_lt (sub_neg.mpr h))]

end SYK.Thermal
