import MomentSymmetry
import Mathlib.GroupTheory.Perm.Finite

/-!
# Weyl sorting of strictly separated time blocks

This module derives the finite sorting-permutation decomposition needed to
identify the full time-ordered Weyl average with reflected half-history
products. Internal ties in either block are retained.
-/

noncomputable section
open scoped BigOperators
open Set
namespace SYK.WeylBlocks
open Interacting

/-- A permutation acting independently inside two consecutive blocks. -/
def blockPerm {k l : ℕ} (σ : Equiv.Perm (Fin k)) (τ : Equiv.Perm (Fin l)) :
    Equiv.Perm (Fin (k+l)) := finSumFinEquiv.permCongr (Equiv.sumCongr σ τ)

@[simp] theorem blockPerm_left {k l : ℕ} (σ : Equiv.Perm (Fin k)) (τ : Equiv.Perm (Fin l))
    (i : Fin k) : blockPerm σ τ (i.castAdd l) = (σ i).castAdd l := by
  simp [blockPerm, Equiv.permCongr_apply]

@[simp] theorem blockPerm_right {k l : ℕ} (σ : Equiv.Perm (Fin k)) (τ : Equiv.Perm (Fin l))
    (i : Fin l) : blockPerm σ τ (i.natAdd k) = (τ i).natAdd k := by
  simp [blockPerm, Equiv.permCongr_apply]

@[simp] theorem blockPerm_sign {k l : ℕ} (σ : Equiv.Perm (Fin k)) (τ : Equiv.Perm (Fin l)) :
    Equiv.Perm.sign (blockPerm σ τ) = Equiv.Perm.sign σ * Equiv.Perm.sign τ := by
  simp [blockPerm, Equiv.Perm.sign_sumCongr]

/-- Strict temporal separation prevents a sorting permutation from moving
any lower-block time into the upper block's output positions. The proof uses
finite cardinality, so neither distinct times nor distinct labels are assumed. -/
theorem sorting_preserves_left {k l : ℕ} (t : Fin k → ℝ) (u : Fin l → ℝ)
    (hsep : ∀ i j, u j < t i) (σ : Equiv.Perm (Fin (k+l)))
    (hσ : Antitone (Fin.append t u ∘ σ)) (i : Fin k) :
    (σ (i.castAdd l)).val < k := by
  classical
  apply Fin.addCases (motive := fun z : Fin (k+l) => σ (i.castAdd l) = z → z.val < k)
    (fun j _ => j.isLt) (fun j hj => ?_) (σ (i.castAdd l)) rfl
  have hpre (a : Fin k) : (σ.symm (a.castAdd l)).val < i.val := by
    by_contra h
    have hle : i.castAdd l ≤ σ.symm (a.castAdd l) := le_of_not_gt h
    have hc := hσ hle
    simp only [Function.comp_def, Equiv.apply_symm_apply, hj,
      Fin.append, Fin.addCases_left, Fin.addCases_right] at hc
    exact (not_le_of_gt (hsep a j)) hc
  let f : Fin k → Fin i.val := fun a => ⟨(σ.symm (a.castAdd l)).val, hpre a⟩
  have hf : Function.Injective f := by
    intro a b hab
    apply Fin.castAdd_injective k l
    apply σ.symm.injective
    apply Fin.ext
    exact congrArg (fun z : Fin i.val => z.val) hab
  have hcard : k ≤ i.val := by simpa using Fintype.card_le_of_injective f hf
  exact False.elim (Nat.not_le_of_lt i.isLt hcard)

/-- Every sorting permutation of separated blocks is uniquely a block
permutation; existence is obtained from preservation of the finite left set. -/
theorem sorting_is_blockPerm {k l : ℕ} (t : Fin k → ℝ) (u : Fin l → ℝ)
    (hsep : ∀ i j, u j < t i) (σ : Equiv.Perm (Fin (k+l)))
    (hσ : Antitone (Fin.append t u ∘ σ)) :
    ∃ σ₁ : Equiv.Perm (Fin k), ∃ σ₂ : Equiv.Perm (Fin l), blockPerm σ₁ σ₂ = σ := by
  let e : Fin k ⊕ Fin l ≃ Fin (k+l) := finSumFinEquiv
  let σ' : Equiv.Perm (Fin k ⊕ Fin l) := e.symm.permCongr σ
  have hmaps : MapsTo σ' (range Sum.inl) (range Sum.inl) := by
    rintro _ ⟨i, rfl⟩
    let j : Fin k := ⟨(σ (i.castAdd l)).val, sorting_preserves_left t u hsep σ hσ i⟩
    refine ⟨j, ?_⟩
    apply e.injective
    change e (Sum.inl j) = e (e.symm (σ (e (Sum.inl i))))
    simp only [Equiv.apply_symm_apply]
    exact Fin.ext rfl
  obtain ⟨⟨σ₁, σ₂⟩, h⟩ := Equiv.Perm.mem_sumCongrHom_range_of_perm_mapsTo_inl hmaps
  refine ⟨σ₁, σ₂, ?_⟩
  apply Equiv.ext
  intro i
  have hh := congrArg (fun f : Equiv.Perm (Fin k ⊕ Fin l) => e (f (e.symm i))) h
  simpa only [Equiv.Perm.sumCongrHom_apply, blockPerm, Equiv.permCongr_apply,
    σ', Equiv.symm_symm, Equiv.apply_symm_apply, e] using hh

/-- Sorting the separated concatenation is equivalent to sorting each block. -/
theorem blockPerm_sorting_iff {k l : ℕ} (t : Fin k → ℝ) (u : Fin l → ℝ)
    (hsep : ∀ i j, u j < t i) (σ : Equiv.Perm (Fin k)) (τ : Equiv.Perm (Fin l)) :
    Antitone (Fin.append t u ∘ blockPerm σ τ) ↔ Antitone (t ∘ σ) ∧ Antitone (u ∘ τ) := by
  constructor
  · intro h
    constructor
    · intro i j hij
      simpa only [Function.comp_def, blockPerm_left, Fin.append, Fin.addCases_left] using
        h (show i.castAdd l ≤ j.castAdd l from hij)
    · intro i j hij
      simpa only [Function.comp_def, blockPerm_right, Fin.append, Fin.addCases_right] using
        h (show i.natAdd k ≤ j.natAdd k by simpa using hij)
  · rintro ⟨hσ, hτ⟩ x y hxy
    revert hxy
    refine Fin.addCases (fun i => ?_) (fun i => ?_) x <;>
      refine Fin.addCases (fun j => ?_) (fun j => ?_) y
    · intro h
      simpa only [Function.comp_def, blockPerm_left, Fin.append, Fin.addCases_left] using hσ h
    · intro _
      simpa only [Function.comp_def, blockPerm_left, blockPerm_right, Fin.append,
        Fin.addCases_left, Fin.addCases_right] using (hsep (σ i) (τ j)).le
    · intro h
      have hi := i.isLt
      have hj := j.isLt
      have hv : k + i.val ≤ j.val := h
      omega
    · intro h
      have hh : i ≤ j := by
        have hv : k + i.val ≤ k + j.val := h
        exact Nat.le_of_add_le_add_left hv
      simpa only [Function.comp_def, blockPerm_right, Fin.append, Fin.addCases_right] using hτ hh

theorem blockPerm_injective {k l : ℕ} :
    Function.Injective (fun p : Equiv.Perm (Fin k) × Equiv.Perm (Fin l) => blockPerm p.1 p.2) := by
  intro p q h
  apply Prod.ext
  · apply Equiv.ext
    intro i
    have hi := congrArg (fun σ => σ (i.castAdd l)) h
    simpa only [blockPerm_left, Fin.castAdd_inj] using hi
  · apply Equiv.ext
    intro i
    have hi := congrArg (fun σ => σ (i.natAdd k)) h
    simpa only [blockPerm_right, Fin.natAdd_inj] using hi

/-- Exact finite-set factorization of the admitted sorting permutations,
including every permutation within tied time blocks. -/
theorem sortingPerms_append {k l : ℕ} (t : Fin k → ℝ) (u : Fin l → ℝ)
    (hsep : ∀ i j, u j < t i) :
    sortingPerms (Fin.append t u) =
      ((sortingPerms t).product (sortingPerms u)).image (fun p => blockPerm p.1 p.2) := by
  classical
  ext σ
  constructor
  · intro hσ
    obtain ⟨σ₁, σ₂, he⟩ := sorting_is_blockPerm t u hsep σ ((mem_sortingPerms _ _).mp hσ)
    refine Finset.mem_image.mpr ⟨(σ₁, σ₂), ?_, he⟩
    apply Finset.mem_product.mpr
    simpa only [mem_sortingPerms] using
      (blockPerm_sorting_iff t u hsep σ₁ σ₂).mp (he.symm ▸ (mem_sortingPerms _ _).mp hσ)
  · intro hσ
    obtain ⟨⟨σ₁, σ₂⟩, hmem, rfl⟩ := Finset.mem_image.mp hσ
    apply (mem_sortingPerms _ _).mpr
    apply (blockPerm_sorting_iff t u hsep σ₁ σ₂).mpr
    simpa only [mem_sortingPerms] using Finset.mem_product.mp hmem

/-- The full normalization factor is the product of the two independent
Weyl normalization factors, even at internal coincidences. -/
theorem sortingPerms_append_card {k l : ℕ} (t : Fin k → ℝ) (u : Fin l → ℝ)
    (hsep : ∀ i j, u j < t i) :
    (sortingPerms (Fin.append t u)).card = (sortingPerms t).card * (sortingPerms u).card := by
  rw [sortingPerms_append t u hsep, Finset.card_image_of_injective _ blockPerm_injective]
  exact Finset.card_product _ _

section Transfer
variable {ν : Type*} [Fintype ν] [DecidableEq ν]

/-- Changing the upper endpoint of a thermal history adds exactly one heat
factor. No ordering or sign assumption is needed for this algebraic identity. -/
theorem transfer_shift_start (H : Matrix ν ν ℂ) (a r : ℝ)
    (L : List (ℝ × Matrix ν ν ℂ)) :
    ThermalRP.evaluate H (ThermalRP.halfFactors (r+a) L) =
      Gibbs.weight r H * ThermalRP.evaluate H (ThermalRP.halfFactors a L) := by
  cases L with
  | nil => simp only [ThermalRP.evaluate_halfFactors_nil, ThermalRP.heat_add]
  | cons v L =>
    rcases v with ⟨t, A⟩
    simp only [ThermalRP.evaluate_halfFactors_cons]
    rw [show r+a-t = r+(a-t) by ring, ThermalRP.heat_add]
    simp only [mul_assoc]

/-- An arbitrary real cut splits a concatenated thermal history into its
upper shifted block and its lower unshifted block. -/
theorem transfer_append (H : Matrix ν ν ℂ) (a c : ℝ)
    (L M : List (ℝ × Matrix ν ν ℂ)) :
    ThermalRP.evaluate H (ThermalRP.halfFactors a (L ++ M)) =
      ThermalRP.evaluate H (ThermalRP.halfFactors (a-c) (L.map (fun p => (p.1-c,p.2)))) *
      ThermalRP.evaluate H (ThermalRP.halfFactors c M) := by
  induction L generalizing a with
  | nil =>
    simp only [List.nil_append, List.map_nil, ThermalRP.evaluate_halfFactors_nil]
    have h := transfer_shift_start H c (a-c) M
    simpa only [sub_add_cancel] using h
  | cons v L ih =>
    rcases v with ⟨t, A⟩
    simp only [List.cons_append, List.map_cons, ThermalRP.evaluate_halfFactors_cons, ih]
    rw [show (a-c)-(t-c) = a-t by ring]
    simp only [mul_assoc]

/-- The exact gap-product split for two endpoint tuples. -/
theorem timeProduct_append (H : Matrix ν ν ℂ) (a c : ℝ) {k l : ℕ}
    (t : Fin k → ℝ) (u : Fin l → ℝ)
    (A : Fin k → Matrix ν ν ℂ) (B : Fin l → Matrix ν ν ℂ) :
    timeProduct H a (Fin.append t u) (Fin.append A B) =
      timeProduct H (a-c) (fun i => t i-c) A * timeProduct H c u B := by
  have hp : (fun i => (Fin.append t u i, Fin.append A B i)) =
      Fin.append (fun i => (t i,A i)) (fun i => (u i,B i)) := by
    funext i
    refine Fin.addCases (fun _ => ?_) (fun _ => ?_) i <;> simp [Fin.append]
  unfold timeProduct
  rw [hp, List.ofFn_fin_append, transfer_append H a c]
  rw [List.map_ofFn]
  rfl

/-- Acting separately inside the two blocks commutes with concatenation. -/
theorem append_comp_blockPerm {α : Type*} {k l : ℕ} (A : Fin k → α) (B : Fin l → α)
    (σ : Equiv.Perm (Fin k)) (τ : Equiv.Perm (Fin l)) :
    Fin.append A B ∘ blockPerm σ τ = Fin.append (A ∘ σ) (B ∘ τ) := by
  funext i
  refine Fin.addCases (fun j => ?_) (fun j => ?_) i <;>
    simp only [Function.comp_def, blockPerm_left, blockPerm_right, Fin.append,
      Fin.addCases_left, Fin.addCases_right]

/-- A common real shift does not change any admitted sorting permutation,
including permutations of tied times. -/
theorem sortingPerms_sub {k : ℕ} (t : Fin k → ℝ) (c : ℝ) :
    sortingPerms (fun i => t i-c) = sortingPerms t := by
  classical
  ext σ
  simp only [mem_sortingPerms, Antitone, Function.comp_def, sub_le_sub_iff_right]

/-- The matrix-valued full Weyl average of the actual thermal transfer
products. Its trace is the previously constructed numerator. -/
def weylTransfer {k : ℕ} (H : Matrix ν ν ℂ) (a : ℝ) (t : Fin k → ℝ)
    (A : Fin k → Matrix ν ν ℂ) : Matrix ν ν ℂ :=
  (((sortingPerms t).card : ℂ)⁻¹) •
    ∑ σ ∈ sortingPerms t, Equiv.Perm.sign σ • timeProduct H a (t ∘ σ) (A ∘ σ)

@[simp] theorem trace_weylTransfer {k : ℕ} (H : Matrix ν ν ℂ) (a : ℝ) (t : Fin k → ℝ)
    (A : Fin k → Matrix ν ν ℂ) : Matrix.trace (weylTransfer H a t A) = weylNumerator H a t A := by
  classical
  unfold weylTransfer weylNumerator signedAverage
  simp only [Matrix.trace_smul, Matrix.trace_sum, smul_eq_mul]

/-- Full signed sorting-average factorization across a strict temporal cut.
All internal Weyl coincidences and their exact normalization factors remain. -/
theorem weylTransfer_append (H : Matrix ν ν ℂ) (a c : ℝ) {k l : ℕ}
    (t : Fin k → ℝ) (u : Fin l → ℝ) (hsep : ∀ i j, u j < t i)
    (A : Fin k → Matrix ν ν ℂ) (B : Fin l → Matrix ν ν ℂ) :
    weylTransfer H a (Fin.append t u) (Fin.append A B) =
      weylTransfer H (a-c) (fun i => t i-c) A * weylTransfer H c u B := by
  classical
  have hterm (σ : Equiv.Perm (Fin k)) (τ : Equiv.Perm (Fin l)) :
      Equiv.Perm.sign (blockPerm σ τ) •
        timeProduct H a ((Fin.append t u) ∘ blockPerm σ τ) ((Fin.append A B) ∘ blockPerm σ τ) =
      (Equiv.Perm.sign σ • timeProduct H (a-c) (fun i => t (σ i)-c) (A ∘ σ)) *
      (Equiv.Perm.sign τ • timeProduct H c (u ∘ τ) (B ∘ τ)) := by
    rw [blockPerm_sign, append_comp_blockPerm, append_comp_blockPerm, timeProduct_append H a c]
    rcases Int.units_eq_one_or (Equiv.Perm.sign σ) with hσ | hσ <;>
      rcases Int.units_eq_one_or (Equiv.Perm.sign τ) with hτ | hτ <;> simp [hσ, hτ]
  unfold weylTransfer
  rw [sortingPerms_sub, sortingPerms_append_card t u hsep, sortingPerms_append t u hsep,
    Finset.sum_image (fun _ _ _ _ h => blockPerm_injective h), Finset.product_eq_sprod, Finset.sum_product]
  simp only [hterm, Nat.cast_mul, mul_inv_rev]
  simp only [← Finset.mul_sum, ← Finset.sum_mul]
  simp only [Function.comp_def, smul_mul_assoc, mul_smul_comm, smul_smul, mul_comm]

end Transfer
end SYK.WeylBlocks
