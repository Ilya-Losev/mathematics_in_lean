import Mathlib.Analysis.Analytic.Constructions
import Mathlib.Analysis.Analytic.Linear
import Mathlib.Tactic

/-!
# The quartic center-time vector field

This module proves analyticity of the actual algebraic expression in manuscript
Section 7. Pointwise multiplication is the multiplication of `A`; kernel
composition is a separate bounded bilinear map `conv`. They are deliberately
not identified. Constructing the measurable-kernel space, restricting the field
to the continuous skew antiperiodic subspace, and proving analyticity of ODE
solutions remain separate tasks.
-/

namespace SYK

variable {A : Type*} [NormedRing A] [NormedAlgebra ℂ A]

/-- The center-time field with its fixed scalar jump `C` held constant. -/
def kernelCenterField (conv : A →L[ℂ] A →L[ℂ] A) (C : A) (lam : ℂ) (r : A) : A :=
  lam • (conv ((C + r) ^ 3) (C + r) - conv (C + r) ((C + r) ^ 3))

/-- The quartic expression is complex analytic even when kernel composition is
noncommutative. No equality between composition and pointwise multiplication
is assumed. -/
theorem kernelCenterField_analyticAt
    (conv : A →L[ℂ] A →L[ℂ] A) (C : A) (lam : ℂ) (r : A) :
    AnalyticAt ℂ (kernelCenterField conv C lam) r := by
  have h : AnalyticAt ℂ (fun x : A => C + x) r :=
    analyticAt_const.add analyticAt_id
  have hl := (conv.analyticAt_bilinear _).comp₂ (h.fun_pow 3) h
  have hr := (conv.analyticAt_bilinear _).comp₂ h (h.fun_pow 3)
  exact (hl.sub hr).fun_const_smul

/-- Entire analyticity of the polynomial field in the ambient kernel algebra. -/
theorem kernelCenterField_analyticOnNhd
    (conv : A →L[ℂ] A →L[ℂ] A) (C : A) (lam : ℂ) :
    AnalyticOnNhd ℂ (kernelCenterField conv C lam) Set.univ :=
  fun r _ => kernelCenterField_analyticAt conv C lam r

/-- The field has the growth bound used in the local holomorphic Picard ball. -/
theorem norm_kernelCenterField_le
    (conv : A →L[ℂ] A →L[ℂ] A) (C : A) (lam : ℂ)
    (β M : ℝ) (hβ : 0 ≤ β) (r : A) (hr : ‖C + r‖ ≤ M)
    (hconv : ∀ x y : A, ‖conv x y‖ ≤ β * ‖x‖ * ‖y‖) :
    ‖kernelCenterField conv C lam r‖ ≤ 2 * ‖lam‖ * β * M ^ 4 := by
  have hM : 0 ≤ M := (norm_nonneg _).trans hr
  have hc : ‖(C + r) ^ 3‖ ≤ M ^ 3 := by
    exact (norm_pow_le' _ (show 0 < (3 : ℕ) by decide)).trans (pow_le_pow_left₀ (norm_nonneg _) hr 3)
  have hl : ‖conv ((C + r) ^ 3) (C + r)‖ ≤ β * M ^ 4 := by
    calc
      _ ≤ β * ‖(C + r) ^ 3‖ * ‖C + r‖ := hconv _ _
      _ ≤ β * M ^ 3 * M := by gcongr
      _ = β * M ^ 4 := by ring
  have ht : ‖conv (C + r) ((C + r) ^ 3)‖ ≤ β * M ^ 4 := by
    calc
      _ ≤ β * ‖C + r‖ * ‖(C + r) ^ 3‖ := hconv _ _
      _ ≤ β * M * M ^ 3 := by gcongr
      _ = β * M ^ 4 := by ring
  unfold kernelCenterField
  rw [norm_smul]
  calc
    _ ≤ ‖lam‖ * (‖conv ((C + r) ^ 3) (C + r)‖ +
        ‖conv (C + r) ((C + r) ^ 3)‖) :=
      mul_le_mul_of_nonneg_left (norm_sub_le _ _) (norm_nonneg _)
    _ ≤ ‖lam‖ * (β * M ^ 4 + β * M ^ 4) := by gcongr
    _ = 2 * ‖lam‖ * β * M ^ 4 := by ring

omit [NormedAlgebra ℂ A] in
/-- Cubing has the exact local bound needed by the quartic field. The proof
works in a possibly noncommutative normed ring. -/
theorem norm_cube_sub_le (x y : A) (M : ℝ)
    (hx : ‖x‖ ≤ M) (hy : ‖y‖ ≤ M) :
    ‖x ^ 3 - y ^ 3‖ ≤ 3 * M ^ 2 * ‖x - y‖ := by
  have hM : 0 ≤ M := (norm_nonneg x).trans hx
  have hx2 : ‖x ^ 2‖ ≤ M ^ 2 :=
    (norm_pow_le' _ (show 0 < (2 : ℕ) by decide)).trans
      (pow_le_pow_left₀ (norm_nonneg _) hx 2)
  have hy2 : ‖y ^ 2‖ ≤ M ^ 2 :=
    (norm_pow_le' _ (show 0 < (2 : ℕ) by decide)).trans
      (pow_le_pow_left₀ (norm_nonneg _) hy 2)
  have h1 : ‖x ^ 2 * (x - y)‖ ≤ M ^ 2 * ‖x - y‖ := by
    exact (norm_mul_le _ _).trans (mul_le_mul_of_nonneg_right hx2 (norm_nonneg _))
  have h2a : ‖x * (x - y)‖ ≤ M * ‖x - y‖ := by
    exact (norm_mul_le _ _).trans (mul_le_mul_of_nonneg_right hx (norm_nonneg _))
  have h2 : ‖x * (x - y) * y‖ ≤ M * ‖x - y‖ * M := by
    calc
      _ ≤ ‖x * (x - y)‖ * ‖y‖ := norm_mul_le _ _
      _ ≤ M * ‖x - y‖ * M := by gcongr
  have h3 : ‖(x - y) * y ^ 2‖ ≤ ‖x - y‖ * M ^ 2 := by
    exact (norm_mul_le _ _).trans (mul_le_mul_of_nonneg_left hy2 (norm_nonneg _))
  have heq : x ^ 3 - y ^ 3 =
      x ^ 2 * (x - y) + x * (x - y) * y + (x - y) * y ^ 2 := by
    noncomm_ring
  rw [heq]
  calc
    _ ≤ ‖x ^ 2 * (x - y) + x * (x - y) * y‖ + ‖(x - y) * y ^ 2‖ :=
      norm_add_le _ _
    _ ≤ (‖x ^ 2 * (x - y)‖ + ‖x * (x - y) * y‖) + ‖(x - y) * y ^ 2‖ := by
      gcongr
      exact norm_add_le _ _
    _ ≤ (M ^ 2 * ‖x - y‖ + M * ‖x - y‖ * M) + ‖x - y‖ * M ^ 2 := by
      gcongr
    _ = 3 * M ^ 2 * ‖x - y‖ := by ring

/-- The second quantitative estimate in manuscript Section 7. -/
theorem norm_kernelCenterField_sub_le
    (conv : A →L[ℂ] A →L[ℂ] A) (C : A) (lam : ℂ)
    (β M : ℝ) (hβ : 0 ≤ β) (r r' : A)
    (hr : ‖C + r‖ ≤ M) (hr' : ‖C + r'‖ ≤ M)
    (hconv : ∀ x y : A, ‖conv x y‖ ≤ β * ‖x‖ * ‖y‖) :
    ‖kernelCenterField conv C lam r - kernelCenterField conv C lam r'‖ ≤
      8 * ‖lam‖ * β * M ^ 3 * ‖r - r'‖ := by
  let x := C + r
  let y := C + r'
  have hx : ‖x‖ ≤ M := hr
  have hy : ‖y‖ ≤ M := hr'
  have hM : 0 ≤ M := (norm_nonneg x).trans hx
  have hx3 : ‖x ^ 3‖ ≤ M ^ 3 :=
    (norm_pow_le' _ (show 0 < (3 : ℕ) by decide)).trans
      (pow_le_pow_left₀ (norm_nonneg _) hx 3)
  have hy3 : ‖y ^ 3‖ ≤ M ^ 3 :=
    (norm_pow_le' _ (show 0 < (3 : ℕ) by decide)).trans
      (pow_le_pow_left₀ (norm_nonneg _) hy 3)
  have hd := norm_cube_sub_le x y M hx hy
  have hl : ‖conv (x ^ 3) x - conv (y ^ 3) y‖ ≤ 4 * β * M ^ 3 * ‖x - y‖ := by
    have heq : conv (x ^ 3) x - conv (y ^ 3) y =
        conv (x ^ 3 - y ^ 3) x + conv (y ^ 3) (x - y) := by
      simp only [map_sub, ContinuousLinearMap.sub_apply]
      abel
    rw [heq]
    calc
      _ ≤ ‖conv (x ^ 3 - y ^ 3) x‖ + ‖conv (y ^ 3) (x - y)‖ := norm_add_le _ _
      _ ≤ β * ‖x ^ 3 - y ^ 3‖ * ‖x‖ + β * ‖y ^ 3‖ * ‖x - y‖ :=
        add_le_add (hconv _ _) (hconv _ _)
      _ ≤ β * (3 * M ^ 2 * ‖x - y‖) * M + β * M ^ 3 * ‖x - y‖ := by gcongr
      _ = 4 * β * M ^ 3 * ‖x - y‖ := by ring
  have ht : ‖conv x (x ^ 3) - conv y (y ^ 3)‖ ≤ 4 * β * M ^ 3 * ‖x - y‖ := by
    have heq : conv x (x ^ 3) - conv y (y ^ 3) =
        conv x (x ^ 3 - y ^ 3) + conv (x - y) (y ^ 3) := by
      simp only [map_sub, ContinuousLinearMap.sub_apply]
      abel
    rw [heq]
    calc
      _ ≤ ‖conv x (x ^ 3 - y ^ 3)‖ + ‖conv (x - y) (y ^ 3)‖ := norm_add_le _ _
      _ ≤ β * ‖x‖ * ‖x ^ 3 - y ^ 3‖ + β * ‖x - y‖ * ‖y ^ 3‖ :=
        add_le_add (hconv _ _) (hconv _ _)
      _ ≤ β * M * (3 * M ^ 2 * ‖x - y‖) + β * ‖x - y‖ * M ^ 3 := by gcongr
      _ = 4 * β * M ^ 3 * ‖x - y‖ := by ring
  have hdxy : x - y = r - r' := by dsimp [x, y]; abel
  change ‖lam • (conv (x ^ 3) x - conv x (x ^ 3)) -
    lam • (conv (y ^ 3) y - conv y (y ^ 3))‖ ≤ _
  rw [← smul_sub, norm_smul]
  have heq : (conv (x ^ 3) x - conv x (x ^ 3)) -
      (conv (y ^ 3) y - conv y (y ^ 3)) =
      (conv (x ^ 3) x - conv (y ^ 3) y) - (conv x (x ^ 3) - conv y (y ^ 3)) := by
    abel
  rw [heq]
  calc
    _ ≤ ‖lam‖ * (‖conv (x ^ 3) x - conv (y ^ 3) y‖ +
        ‖conv x (x ^ 3) - conv y (y ^ 3)‖) :=
      mul_le_mul_of_nonneg_left (norm_sub_le _ _) (norm_nonneg _)
    _ ≤ ‖lam‖ * (4 * β * M ^ 3 * ‖x - y‖ + 4 * β * M ^ 3 * ‖x - y‖) := by gcongr
    _ = 8 * ‖lam‖ * β * M ^ 3 * ‖r - r'‖ := by rw [hdxy]; ring

end SYK
