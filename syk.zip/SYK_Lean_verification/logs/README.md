# Verification logs

The authoritative final clean check is
`verification-20261013T203624Z.txt`. It ends with `CHECK EXIT CODE: 0`.
It records the clean build of all 180 proof modules with unmodified official
Lean 4.19.0, 663 explicit axiom prints, the strict all-declaration audit,
the exact final theorem types and conclusion structures, source inventory,
dependency validation and source hashes.

The exhaustive audit passed 4,039 safe declarations, including 3,214 theorem
declarations. Only `propext`, `Classical.choice` and `Quot.sound` are allowed.
The log separately lists 1,222 unsafe compiler execution artifacts excluded
from the logical audit. Positive, forbidden-axiom and missing-module controls
passed. No mathematical axiom was granted an exception.

All other dated verification logs are earlier development checkpoints.
Undated files, including those with `current` or `final` in their historical
names, are retained diagnostics or provenance from those earlier checkpoints;
they do not supersede the authoritative final dated log above. Some historical
runs record errors subsequently fixed. The final dated run has no compiler errors.

`environment-provenance.txt` records official distribution/binary hashes and
cache provenance. The starter reproduction logs show the original input was
independently rebuilt and audited before extension.

The final main theorem and generic abstract theorem are unconditional in their
stated model assumptions. Scope adaptations are documented in
`../PROOF_GUIDE.md`, `../MANUSCRIPT_THEOREM_AUDIT.md` and `../VERIFICATION.md`.

`comment-only-aggregate-check.txt` records the subsequent correction of an obsolete
aggregate documentation block. Non-comment bytes were exactly identical, and
the corrected aggregate passed another `--trust=0` compilation. No proof changed.
