# Continuum SYK: first Lean verification project

This project checks selected implications in `SYK_continuum_free_energy.tex`.
It is **not a formal proof of the complete SYK free-energy theorem**.
The source file `SYKLean.lean` imports every proof module.

## Reproduce the check

Install Lean with its official installer, then extract this project and run:

```sh
lake update
lake exe cache get
lake build
lake env lean AxiomAudit.lean
```

The `lean-toolchain` file pins Lean 4.19.0. `lakefile.toml` pins mathlib to
commit `c44e0c8ee63ca166450922a373c7409c5d26b00b` (the v4.19.0 release).
The dependency versions in `lake-manifest.json` preserve the resolved build.

The official installation instructions are at https://lean-lang.org/install/.
On a Mac with Lean's VS Code extension, open this extracted folder, then open
the `.lean` files. Lean shows every theorem's precise inputs and conclusion.

## What a successful build means

Lean has checked each theorem from its stated hypotheses using its kernel and
the imported library. An unproved mathematical fact passed as an argument is
still an assumption. The files deliberately expose those facts rather than
declaring axioms for them or hiding them behind `sorry`.

For example, `analytic_curve_mem_closed_submodule` proves the analytic
continuation argument in Section 7. Its hypothesis that the curve is analytic
still needs to be established for the actual SYK kernel using the SD equations.

Likewise, the Section 9 module proves the infinite-series two-sign argument.
The actual Fourier transform, Parseval identity, summability, and physical
Fourier signs for the SYK kernels remain separate proof obligations.

Read `VERIFICATION.md` for the precise scope. `AxiomAudit.lean` displays the
standard foundational axioms used by the checked declarations; the audit
must not contain `sorryAx` or any project-specific postulated axiom.

## Files

- `ClosedIdeal.lean`: all inserted residual identities imply annihilation of
  the ideal they generate and its topological closure.
- `HalfGeneration.lean`: norm-analytic curves stay in a closed linear subspace
  once they do so on a nonempty open set; nonnegativity extends by continuity
  from a dense subset.
- `Translation.lean`: the final symmetric/unitary/halving argument for
  represented translations, plus elementary quotient logic.
- `Uniqueness.lean`: cubic monotonicity, the reciprocal Dyson identity, and
  rigidity from a convergent infinite sum of nonnegative Fourier energies.
- `Pressure.lean`: scalar calculus and convergence steps used in coupling
  integration, with microscopic inputs stated explicitly.

## Local execution note

The checking environment had a mismatch between its numeric process IDs and
its mounted `/proc`. A small compatibility adapter redirected only a process's
own executable-path lookup from `/proc/<its PID>/exe` to `/proc/self/exe`.
The official Lean executable, proof kernel, and mathlib proof sources were not
modified. That adapter is unnecessary on an ordinary Mac or Linux installation.
Archive extraction used `--no-same-owner` because foreign user IDs are not
available in this environment. Neither adjustment changes proof checking.
