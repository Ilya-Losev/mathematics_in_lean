# Verification scope

**Build status: passed.** All 30 project theorems compiled with Lean 4.19.0.
The complete package build and the axiom audit exited with status 0.
The audit found only standard Lean foundations and no `sorryAx`.

This is a first, partial formalization of the continuous-time derivation.
It does **not** certify the culminating SYK free-energy theorem.
Compilation checks the implications below with all their hypotheses visible.
It does not infer that the physical SYK model satisfies those hypotheses.

Source manuscript: `SYK_continuum_free_energy.tex`, supplied in this conversation.
Source SHA-256:
`c214e369a8d2ae97dc1fcbd4bc4b759119ced8ee92ae5598b4c5fb7135449562`.

## Formalized parts

| Draft step | Lean file | What is proved | What remains an input |
|---|---|---|---|
| Section 6: impose SD relations | `ClosedIdeal.lean` | All identities L(a F_i)=0 imply annihilation of the actual ideal span and its topological closure, including further insertions. | The normed algebra, continuous functional, defined residuals, and all-insertions identities. |
| Section 7: geometric seed | `HalfGeneration.lean` | A real pair with separation shorter than β/2 fits in the positive half-circle on a nonempty open interval of translations. | Choice of antiperiodic lifts; antipodal limiting argument. |
| Section 7: analytic continuation | `HalfGeneration.lean` | A norm-analytic curve lying in a closed linear subspace on an open nonempty set lies there at every real parameter. This uses the actual normed quotient, not an assumed identity principle. | Analyticity of the actual SD orbit; the actual half-algebra as a closed subspace. |
| Start of Section 8: positivity extension | `HalfGeneration.lean` | A continuous real-valued function nonnegative on a dense set is nonnegative everywhere. | Density from half-generation; continuity of a ↦ Re L(a* a); reality of the form. |
| Section 8: trivial translations | `Translation.lean` | A symmetric pairing-preserving action squares to identity; halving its parameter makes it trivial; covariance gives stationarity of represented observables. | The GNS space, nondegeneracy, symmetry, and pairing preservation obtained from the contractivity argument. |
| Section 9: physical Fourier uniqueness | `Uniqueness.lean` | Cubic monotonicity, exact reciprocal Dyson algebra, upgrading nonnegative coefficients to positive ones, and rigidity of a summable infinite weighted-square comparison. | Actual Fourier/Parseval identity, convergence, physical signs from Hankel positivity, and Fourier injectivity to recover kernels. |
| Section 10: coupling integration | `Pressure.lean` | Uniqueness from derivatives and the free anchor; FTC pressure formula; convergence of pressures from dominated convergence of finite-N derivatives. | Microscopic pressure derivative identity, the common bound, a.e. convergence of derivatives, and continuity. |

The strongest Section 9 theorem derives the negative-square representation and
energy summability from the supplied Parseval pairing and the scalar Dyson
relations. Thus those algebraic transformations are genuinely checked, rather
than being hidden in a premise asserting uniqueness.

The Section 7 continuation theorem assumes analyticity, but does not assume
membership in the subspace outside the initial open set. That membership is
the conclusion proved by Lean's analytic identity theorem.

The Section 6 theorem assumes the inserted residual equations but does not
assume that their ideal is annihilated. Its induction retains all insertions,
which is essential to the multiplication case.

## Still required for a complete SYK proof

1. Define the finite-N Clifford Hamiltonian, disorder distribution, trace,
   thermal time ordering, exterior collective symbols, and blockwise Weyl map.
   The Weyl map is linear but is not multiplicative at coincident times:
   exterior ψ_i(t)^2 is zero, whereas the Clifford operator χ_i^2 is I/2.
   Treating these multiplications as identical would formalize a different model.
2. Prove the Weyl/Wick correspondence, trace bounds, Gaussian-Duhamel series,
   reflection positivity, and exact inserted Ward identities (Sections 3–4).
3. Prove endpoint regularity, subsequential compactness in the presence of
   vanishing contact jumps, limiting inserted equations, and mixed increment
   bounds (Section 5).
4. Construct the weighted coefficient algebra, both quotient norms, and
   Banach-valued kernel integrals, identifying them with the hypotheses of
   `ClosedIdeal.lean` (Section 6).
5. Derive the differentiated SD identities and the polynomial kernel ODE;
   prove actual norm analyticity from complex Picard iteration; complete
   antipodal approximation and algebra generation (Section 7).
6. Construct the positive GNS representation and prove the contraction bounds
   and pairing preservation needed by `Translation.lean`; then construct the
   joint spectral measure (Section 8).
7. Establish the Hankel test, fermionic Fourier conventions, Parseval identity,
   required summability, and Fourier injectivity for the actual kernels;
   prove coupling continuity and moment convergence (Section 9).
8. Identify the microscopic pressure and its exact derivative, fourth-moment
   limit, and bound with the inputs of `Pressure.lean`; prove the Gaussian
   concentration estimate and the annealed/quenched comparison (Section 10).
9. Formalize the relative Fredholm determinant, trace-class property, logarithm
   series, variational maximization and envelope argument (Section 11).

## Mathematical review observations

A separate informal audit did not find a concrete sign or normalization
counterexample in Sections 3–5. That audit is not kernel verification.
The microscopic Weyl/Wick correspondence and Gaussian-Duhamel regrouping
are substantial remaining formalization obligations.

Section 8 admits a useful proof simplification: the first Cauchy–Schwarz bound
already proves preservation of zero-norm vectors. Split that zero case before
using the iterated fractional-power bound to prove contractivity for nonzero
vectors. This clarification has not been turned into a Hilbert-space Lean
proof in this first project.

## Trust boundary

There are no project-specific postulated axioms or unfinished proof placeholders
in the delivered proof modules. Standard Lean/mathlib foundational axioms may
appear in `#print axioms`; this is normal and different from assuming an SYK
claim. Inspect `AxiomAudit.lean` and its recorded output.

The local execution used the official Lean 4.19.0 distribution and the pinned
mathlib sources. The executable-path compatibility adapter described in the
README alters only process-path discovery; it does not change the kernel or
any proof. The adapter is not required to reproduce the check on a normal Mac.

Compilation and axiom audit results are recorded in `verification-log.txt`.
