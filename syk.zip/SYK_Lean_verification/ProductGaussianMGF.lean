import GaussianDisorder
import Mathlib.MeasureTheory.Integral.Prod

/-! # Exact real exponential moments of the actual finite product Gaussian law -/

noncomputable section
open MeasureTheory ProbabilityTheory
open scoped BigOperators NNReal
namespace SYK.ProductGaussianMGF

variable (ι : Type*) [Fintype ι]

/-- Independent centered Gaussians with a common, possibly zero, variance. -/
def law (v : ℝ≥0) : Measure (ι → ℝ) := Measure.pi (fun _ : ι => gaussianReal 0 v)

instance law_isProbabilityMeasure (v : ℝ≥0) : IsProbabilityMeasure (law ι v) := by
  unfold law
  infer_instance

theorem integral_exp_linear (v : ℝ≥0) (a : ℝ) :
    (∫ x, Real.exp (a * x) ∂gaussianReal 0 v) = Real.exp ((v : ℝ) * a^2 / 2) := by
  have h := mgf_gaussianReal (X := id) (p := gaussianReal 0 v) (μ := 0) (v := v)
    (by simp) a
  simpa only [mgf, id_eq, zero_mul, zero_add] using h

/-- Every linear exponential moment of the finite product is a genuine integral. -/
theorem integrable_exp_sum_linear (v : ℝ≥0) (a : ι → ℝ) :
    Integrable (fun x : ι → ℝ => Real.exp (∑ i, a i * x i)) (law ι v) := by
  letI : MeasureSpace ℝ := ⟨gaussianReal 0 v⟩
  haveI : IsProbabilityMeasure (volume : Measure ℝ) :=
    inferInstanceAs (IsProbabilityMeasure (gaussianReal 0 v))
  have h : Integrable (fun x : ι → ℝ => ∏ i, Real.exp (a i * x i)) :=
    Integrable.fintype_prod (fun i => GaussianDisorder.integrable_exp_linear v (a i))
  simpa only [Real.exp_sum, MeasureTheory.volume_pi, law] using h

/-- Exact finite-dimensional Gaussian MGF, without an independence or MGF axiom. -/
theorem integral_exp_sum_linear (v : ℝ≥0) (a : ι → ℝ) :
    (∫ x, Real.exp (∑ i, a i * x i) ∂law ι v) =
      Real.exp ((v : ℝ) * (∑ i, (a i)^2) / 2) := by
  letI : MeasureSpace ℝ := ⟨gaussianReal 0 v⟩
  haveI : IsProbabilityMeasure (volume : Measure ℝ) :=
    inferInstanceAs (IsProbabilityMeasure (gaussianReal 0 v))
  have h := integral_fintype_prod_eq_prod ι (fun i (x : ℝ) => Real.exp (a i * x))
  change (∫ x, (∏ i, Real.exp (a i * x i)) ∂law ι v) =
    ∏ i, ∫ x, Real.exp (a i * x) ∂gaussianReal 0 v at h
  simp only [integral_exp_linear, ← Real.exp_sum] at h
  change (∫ x, Real.exp (∑ i, a i * x i) ∂law ι v) =
      Real.exp (∑ i, (v : ℝ) * (a i)^2 / 2) at h
  rw [h]
  congr 1
  simp only [Finset.sum_div, Finset.mul_sum]

/-- Absolute-sum exponential moments, used to justify changes of integration order. -/
theorem integrable_exp_sum_abs (v : ℝ≥0) (c : ℝ) :
    Integrable (fun x : ι → ℝ => Real.exp (c * ∑ i, |x i|)) (law ι v) := by
  letI : MeasureSpace ℝ := ⟨gaussianReal 0 v⟩
  haveI : IsProbabilityMeasure (volume : Measure ℝ) :=
    inferInstanceAs (IsProbabilityMeasure (gaussianReal 0 v))
  have h : Integrable (fun x : ι → ℝ => ∏ i, Real.exp (c * |x i|)) :=
    Integrable.fintype_prod (fun _ => GaussianDisorder.integrable_exp_abs v c)
  simpa only [Finset.mul_sum, Real.exp_sum, MeasureTheory.volume_pi, law] using h

/-- Joint exponential majorants for two independent copies are also integrable. -/
theorem integrable_exp_pair_abs (v : ℝ≥0) (c : ℝ) :
    Integrable (fun p : (ι → ℝ) × (ι → ℝ) =>
      Real.exp (c * ((∑ i, |p.1 i|) + ∑ i, |p.2 i|))) ((law ι v).prod (law ι v)) := by
  have h := (integrable_exp_sum_abs ι v c).mul_prod (integrable_exp_sum_abs ι v c)
  simpa only [mul_add, Real.exp_add] using h

/-- The conditional moment used in Pisier rotation. The only hypothesis here
is an explicit squared Euclidean bound on the coefficient vector. -/
theorem integral_exp_dot_le (v : ℝ≥0) (c K : ℝ) (a : ι → ℝ)
    (ha : ∑ i, (a i)^2 ≤ K) :
    (∫ y, Real.exp (c * ∑ i, a i * y i) ∂law ι v) ≤
      Real.exp ((v : ℝ) * c^2 * K / 2) := by
  have he : (fun y : ι → ℝ => Real.exp (c * ∑ i, a i * y i)) =
      (fun y => Real.exp (∑ i, (c * a i) * y i)) := by
    funext y
    simp only [Finset.mul_sum, mul_assoc]
  rw [he, integral_exp_sum_linear]
  apply Real.exp_le_exp.mpr
  have hs : (∑ i, (c * a i)^2) = c^2 * ∑ i, (a i)^2 := by
    simp only [mul_pow, Finset.mul_sum]
  rw [hs]
  simpa only [mul_assoc] using div_le_div_of_nonneg_right
    (mul_le_mul_of_nonneg_left ha (mul_nonneg (NNReal.coe_nonneg v) (sq_nonneg c))) (by norm_num : (0 : ℝ) ≤ 2)

end SYK.ProductGaussianMGF
