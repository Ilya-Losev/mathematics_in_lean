import TranslationContraction
import Mathlib.Analysis.InnerProductSpace.Completion
import Mathlib.Analysis.InnerProductSpace.Adjoint
import Mathlib.Analysis.NormedSpace.OperatorNorm.Completeness

/-!
# Bounded GNS multiplication for the Section 8 reflection functional

The Banach-algebra norm is not assumed to be a C*-norm. Bounded multiplication
is proved from positivity and continuity by iterated Cauchy--Schwarz on powers
of `star a * a`. This is an alternative to the manuscript's binomial-series
argument, with the same conclusion and no square-root hypothesis.
-/

noncomputable section

namespace SYK.GNS

open SYK.TranslationContraction
open UniformSpace

variable {A : Type*} [NormedRing A] [NormedAlgebra ℂ A]
  [StarRing A] [StarModule ℂ A] [NormedStarGroup A]

/-- Positivity and continuity imply contraction of left multiplication by
any algebra element whose Banach norm is at most one. -/
theorem reflection_mul_square_le_of_norm_le_one
    (L : A →L[ℂ] ℂ) (hreal : ∀ a, (L (star a * a)).im = 0)
    (hpositive : ∀ a, 0 ≤ (L (star a * a)).re)
    (a c : A) (ha : ‖a‖ ≤ 1) :
    (L (star (a * c) * (a * c))).re ≤ (L (star c * c)).re := by
  let z := star a * a
  let r : ℕ → ℝ := fun n => (L (star c * z ^ (2 ^ n) * c)).re
  have hzstar : star z = z := by simp [z, star_mul]
  have hznorm : ‖z‖ ≤ 1 := by
    calc
      ‖z‖ ≤ ‖star a‖ * ‖a‖ := norm_mul_le _ _
      _ = ‖a‖ * ‖a‖ := by rw [norm_star]
      _ ≤ 1 := by nlinarith [norm_nonneg a]
  have hpow (n : ℕ) : ‖z ^ (2 ^ n)‖ ≤ 1 := by
    exact (norm_pow_le' z (pow_pos (by norm_num) n)).trans
      (pow_le_one₀ (norm_nonneg _) hznorm)
  have hquad (n : ℕ) : r n ^ 2 ≤ (L (star c * c)).re * r (n + 1) := by
    have hCS := reflection_cauchy_schwarz L hreal hpositive c (z ^ (2 ^ n) * c)
    have hexpand : star (z ^ (2 ^ n) * c) * (z ^ (2 ^ n) * c) =
        star c * z ^ (2 ^ (n + 1)) * c := by
      rw [star_mul, star_pow, hzstar]
      simp only [pow_succ, Nat.mul_two]
      rw [pow_add]
      simp only [mul_assoc]
    rw [hexpand] at hCS
    have hsquare : (L (star c * z ^ (2 ^ n) * c)).re ^ 2 ≤
        ‖L (star c * z ^ (2 ^ n) * c)‖ ^ 2 := by
      have h := Complex.sq_norm_sub_sq_re (L (star c * z ^ (2 ^ n) * c))
      nlinarith [sq_nonneg (L (star c * z ^ (2 ^ n) * c)).im]
    exact hsquare.trans (by simpa only [mul_assoc, r] using hCS)
  have hbound (n : ℕ) : r n ≤ ‖L‖ * ‖c‖ ^ 2 := by
    have hprod : ‖star c * z ^ (2 ^ n) * c‖ ≤ ‖c‖ ^ 2 := by
      calc
        ‖star c * z ^ (2 ^ n) * c‖ ≤ ‖star c * z ^ (2 ^ n)‖ * ‖c‖ := norm_mul_le _ _
        _ ≤ (‖star c‖ * ‖z ^ (2 ^ n)‖) * ‖c‖ :=
          mul_le_mul_of_nonneg_right (norm_mul_le _ _) (norm_nonneg _)
        _ ≤ (‖star c‖ * 1) * ‖c‖ :=
          mul_le_mul_of_nonneg_right
            (mul_le_mul_of_nonneg_left (hpow n) (norm_nonneg _)) (norm_nonneg _)
        _ = ‖c‖ ^ 2 := by simp [pow_two]
    calc
      r n ≤ ‖L (star c * z ^ (2 ^ n) * c)‖ := Complex.re_le_norm _
      _ ≤ ‖L‖ * ‖star c * z ^ (2 ^ n) * c‖ := L.le_opNorm _
      _ ≤ ‖L‖ * ‖c‖ ^ 2 := mul_le_mul_of_nonneg_left hprod (norm_nonneg _)
  have h := bounded_quadratic_sequence_le (L (star c * c)).re r
    (hpositive c) hquad (‖L‖ * ‖c‖ ^ 2) hbound
  simpa only [r, pow_zero, pow_one, z, star_mul, mul_assoc] using h


/-- Real scalar homogeneity of the reflection quadratic form. -/
theorem reflection_square_real_smul (L : A →L[ℂ] ℂ) (r : ℝ) (a : A) :
    (L (star ((r : ℂ) • a) * ((r : ℂ) • a))).re = r ^ 2 * (L (star a * a)).re := by
  simp only [star_smul, smul_mul_assoc, mul_smul_comm, map_smul]
  simp [smul_eq_mul, Complex.star_def, Complex.mul_re, pow_two]
  ring

/-- The bounded multiplication estimate required for the GNS construction.
This proves the estimate from positivity and continuity, rather than assuming
it as part of a representation. -/
theorem reflection_mul_square_le
    (L : A →L[ℂ] ℂ) (hreal : ∀ a, (L (star a * a)).im = 0)
    (hpositive : ∀ a, 0 ≤ (L (star a * a)).re)
    (a c : A) :
    (L (star (a * c) * (a * c))).re ≤ ‖a‖ ^ 2 * (L (star c * c)).re := by
  by_cases ha : ‖a‖ = 0
  · have hazero : a = 0 := norm_eq_zero.mp ha
    simp [hazero]
  · have hapos : 0 < ‖a‖ := lt_of_le_of_ne (norm_nonneg _) (Ne.symm ha)
    have hnorm : ‖((‖a‖⁻¹ : ℝ) : ℂ) • a‖ ≤ 1 := by
      rw [norm_smul, Complex.norm_real, Real.norm_eq_abs, abs_of_pos (inv_pos.mpr hapos)]
      simp [ha]
    have h := reflection_mul_square_le_of_norm_le_one L hreal hpositive
      (((‖a‖⁻¹ : ℝ) : ℂ) • a) c hnorm
    rw [smul_mul_assoc, reflection_square_real_smul] at h
    have hm := mul_le_mul_of_nonneg_left h (sq_nonneg ‖a‖)
    calc
      (L (star (a * c) * (a * c))).re =
          ‖a‖ ^ 2 * ((‖a‖⁻¹) ^ 2 * (L (star (a * c) * (a * c))).re) := by
        field_simp [ha]
      _ ≤ ‖a‖ ^ 2 * (L (star c * c)).re := hm

/-- In particular, null vectors form a left ideal. This establishes that
multiplication descends to the null quotient. -/
theorem reflection_mul_preserves_null
    (L : A →L[ℂ] ℂ) (hreal : ∀ a, (L (star a * a)).im = 0)
    (hpositive : ∀ a, 0 ≤ (L (star a * a)).re)
    (a c : A) (hc : (L (star c * c)).re = 0) :
    (L (star (a * c) * (a * c))).re = 0 := by
  apply le_antisymm _ (hpositive _)
  have h := reflection_mul_square_le L hreal hpositive a c
  simpa only [hc, mul_zero] using h


/-- The analytic input to the GNS construction. Diagonal reality and
nonnegativity state complex positivity without imposing a C*-norm on `A`. -/
structure PositiveFunctional (A : Type*) [NormedRing A] [NormedAlgebra ℂ A]
    [StarRing A] where
  map : A →L[ℂ] ℂ
  diagonal_real : ∀ a, (map (star a * a)).im = 0
  diagonal_nonneg : ∀ a, 0 ≤ (map (star a * a)).re

/-- A separate type synonym ensures that the reflection seminorm does not
replace the original Banach algebra norm on `A`. -/
def PreGNS (φ : PositiveFunctional A) : Type _ := A

namespace PreGNS

variable (φ : PositiveFunctional A)

instance : AddCommGroup (PreGNS φ) := inferInstanceAs (AddCommGroup A)
instance : Module ℂ (PreGNS φ) := inferInstanceAs (Module ℂ A)

/-- Regard an algebra element as a reflection-seminorm vector. -/
def ofAlgebra (a : A) : PreGNS φ := a

/-- Forget the reflection-seminorm interpretation. -/
def toAlgebra (x : PreGNS φ) : A := x

instance core : PreInnerProductSpace.Core ℂ (PreGNS φ) :=
  reflectionCore (A := A) φ.map φ.diagonal_real φ.diagonal_nonneg

instance seminormedAddCommGroup : SeminormedAddCommGroup (PreGNS φ) :=
  InnerProductSpace.Core.toSeminormedAddCommGroup (𝕜 := ℂ)

instance normedSpace : NormedSpace ℂ (PreGNS φ) :=
  InnerProductSpace.Core.toSeminormedSpace (𝕜 := ℂ)

instance innerProductSpace : InnerProductSpace ℂ (PreGNS φ) where
  __ := core φ
  __ := normedSpace φ
  norm_sq_eq_re_inner x := by
    change Real.sqrt (φ.map (star (toAlgebra φ x) * toAlgebra φ x)).re ^ 2 =
      (φ.map (star (toAlgebra φ x) * toAlgebra φ x)).re
    exact Real.sq_sqrt (φ.diagonal_nonneg _)

@[simp] theorem norm_ofAlgebra (a : A) :
    ‖ofAlgebra φ a‖ = Real.sqrt (φ.map (star a * a)).re := rfl

@[simp] theorem inner_ofAlgebra (a b : A) :
    inner (𝕜 := ℂ) (ofAlgebra φ a) (ofAlgebra φ b) = φ.map (star a * b) := rfl

/-- Multiplication is bounded for the reflection seminorm. -/
theorem norm_mul_le (a : A) (x : PreGNS φ) :
    ‖ofAlgebra φ (a * toAlgebra φ x)‖ ≤ ‖a‖ * ‖x‖ := by
  change Real.sqrt (φ.map (star (a * toAlgebra φ x) * (a * toAlgebra φ x))).re ≤
    ‖a‖ * Real.sqrt (φ.map (star (toAlgebra φ x) * toAlgebra φ x)).re
  calc
    _ ≤ Real.sqrt (‖a‖ ^ 2 * (φ.map (star (toAlgebra φ x) * toAlgebra φ x)).re) :=
      Real.sqrt_le_sqrt (reflection_mul_square_le φ.map φ.diagonal_real φ.diagonal_nonneg a _)
    _ = _ := by rw [Real.sqrt_mul (sq_nonneg _), Real.sqrt_sq (norm_nonneg _)]

/-- Left multiplication on the algebra, now as a bounded linear map for the
reflection seminorm. No quotient well-definedness is presupposed. -/
def leftMul (a : A) : PreGNS φ →L[ℂ] PreGNS φ :=
  LinearMap.mkContinuous
    { toFun := fun x => ofAlgebra φ (a * toAlgebra φ x)
      map_add' := fun x y => mul_add a x y
      map_smul' := fun r x => mul_smul_comm r a x }
    ‖a‖ (norm_mul_le φ a)

@[simp] theorem leftMul_ofAlgebra (a b : A) :
    leftMul φ a (ofAlgebra φ b) = ofAlgebra φ (a * b) := rfl

end PreGNS

/-- Completing the semidefinite pre-inner-product space simultaneously
identifies null vectors and supplies the completed GNS Hilbert space. -/
def GNSHilbert (φ : PositiveFunctional A) : Type _ := Completion (PreGNS φ)

namespace GNSHilbert

variable (φ : PositiveFunctional A)

instance : NormedAddCommGroup (GNSHilbert φ) := inferInstanceAs
  (NormedAddCommGroup (Completion (PreGNS φ)))
instance : InnerProductSpace ℂ (GNSHilbert φ) := inferInstanceAs
  (InnerProductSpace ℂ (Completion (PreGNS φ)))
instance : CompleteSpace (GNSHilbert φ) := inferInstanceAs
  (CompleteSpace (Completion (PreGNS φ)))

/-- Canonical dense algebra vectors in the completed GNS space. -/
def ofAlgebra (a : A) : GNSHilbert φ := (PreGNS.ofAlgebra φ a : Completion (PreGNS φ))

@[simp] theorem norm_ofAlgebra (a : A) :
    ‖ofAlgebra φ a‖ = Real.sqrt (φ.map (star a * a)).re := by
  exact Completion.norm_coe (PreGNS.ofAlgebra φ a)

@[simp] theorem inner_ofAlgebra (a b : A) :
    inner (𝕜 := ℂ) (ofAlgebra φ a) (ofAlgebra φ b) = φ.map (star a * b) := by
  exact Completion.inner_coe (𝕜 := ℂ) (PreGNS.ofAlgebra φ a) (PreGNS.ofAlgebra φ b)


/-- Algebra vectors are dense in the completed GNS space. -/
theorem denseRange_ofAlgebra : DenseRange (ofAlgebra φ) :=
  Completion.denseRange_coe (α := PreGNS φ)

/-- Extend the proved bounded multiplication map to the completed Hilbert
space using mathlib's completion functor. -/
def representation (a : A) : GNSHilbert φ →L[ℂ] GNSHilbert φ where
  toFun := Completion.map (PreGNS.leftMul φ a)
  map_add' x y := by
    induction x, y using Completion.induction_on₂ with
    | hp =>
      exact isClosed_eq (Completion.continuous_map.comp continuous_add)
        ((Completion.continuous_map.comp continuous_fst).add
          (Completion.continuous_map.comp continuous_snd))
    | ih x y =>
      rw [← Completion.coe_add x y]
      simp only [Completion.map_coe (PreGNS.leftMul φ a).uniformContinuous]
      rw [(PreGNS.leftMul φ a).map_add, Completion.coe_add]
  map_smul' r x := by
    induction x using Completion.induction_on with
    | hp =>
      exact isClosed_eq (Completion.continuous_map.comp (continuous_const_smul r))
        ((continuous_const_smul r).comp Completion.continuous_map)
    | ih x =>
      rw [← Completion.coe_smul r x]
      simp only [Completion.map_coe (PreGNS.leftMul φ a).uniformContinuous]
      rw [(PreGNS.leftMul φ a).map_smul, Completion.coe_smul]
      rfl
  cont := Completion.continuous_map

@[simp] theorem representation_ofAlgebra (a b : A) :
    representation φ a (ofAlgebra φ b) = ofAlgebra φ (a * b) :=
  Completion.map_coe (PreGNS.leftMul φ a).uniformContinuous (PreGNS.ofAlgebra φ b)

/-- The operator norm is bounded by the original Banach-algebra norm. -/
theorem norm_representation_le (a : A) : ‖representation φ a‖ ≤ ‖a‖ := by
  apply ContinuousLinearMap.opNorm_le_bound _ (norm_nonneg _)
  intro x
  induction x using Completion.induction_on with
  | hp =>
    exact isClosed_le (representation φ a).continuous.norm (continuous_const.mul continuous_norm)
  | ih x =>
    change ‖Completion.map (PreGNS.leftMul φ a) (x : Completion (PreGNS φ))‖ ≤
      ‖a‖ * ‖(x : Completion (PreGNS φ))‖
    rw [Completion.map_coe (PreGNS.leftMul φ a).uniformContinuous,
      Completion.norm_coe, Completion.norm_coe]
    exact PreGNS.norm_mul_le φ a x

/-- Continuous operators agreeing on algebra vectors agree everywhere. -/
theorem operator_ext (f g : GNSHilbert φ →L[ℂ] GNSHilbert φ)
    (h : ∀ a : A, f (ofAlgebra φ a) = g (ofAlgebra φ a)) : f = g := by
  apply ContinuousLinearMap.ext
  exact congrFun ((denseRange_ofAlgebra φ).equalizer f.continuous g.continuous (funext h))

@[simp] theorem representation_one : representation φ (1 : A) = 1 := by
  apply operator_ext φ
  intro a
  simp only [representation_ofAlgebra, one_mul, ContinuousLinearMap.one_apply]

@[simp] theorem representation_mul (a b : A) :
    representation φ (a * b) = representation φ a * representation φ b := by
  apply operator_ext φ
  intro c
  simp only [representation_ofAlgebra, ContinuousLinearMap.mul_apply]
  rw [mul_assoc]

@[simp] theorem representation_add (a b : A) :
    representation φ (a + b) = representation φ a + representation φ b := by
  apply operator_ext φ
  intro c
  simp only [representation_ofAlgebra, ContinuousLinearMap.add_apply]
  change ((PreGNS.ofAlgebra φ ((a + b) * c)) : Completion (PreGNS φ)) =
    (PreGNS.ofAlgebra φ (a * c) : Completion (PreGNS φ)) + PreGNS.ofAlgebra φ (b * c)
  rw [← Completion.coe_add]
  congr 1
  exact add_mul a b c

@[simp] theorem representation_smul (r : ℂ) (a : A) :
    representation φ (r • a) = r • representation φ a := by
  apply operator_ext φ
  intro c
  simp only [representation_ofAlgebra, ContinuousLinearMap.smul_apply]
  change ((PreGNS.ofAlgebra φ ((r • a) * c)) : Completion (PreGNS φ)) =
    r • (PreGNS.ofAlgebra φ (a * c) : Completion (PreGNS φ))
  rw [← Completion.coe_smul]
  congr 1
  exact smul_mul_assoc r a c


@[simp] theorem representation_zero : representation φ (0 : A) = 0 := by
  have h := representation_smul φ (0 : ℂ) (0 : A)
  simpa only [zero_smul] using h

/-- The bounded operators form an algebra representation. -/
def representationAlgHom : A →ₐ[ℂ] (GNSHilbert φ →L[ℂ] GNSHilbert φ) where
  toFun := representation φ
  map_one' := representation_one φ
  map_mul' := representation_mul φ
  map_zero' := representation_zero φ
  map_add' := representation_add φ
  commutes' r := by
    rw [Algebra.algebraMap_eq_smul_one, representation_smul, representation_one]
    exact (Algebra.algebraMap_eq_smul_one r).symm

/-- Multiplication by `star a` is the Hilbert adjoint of multiplication by `a`.
The identity is first checked on algebra vectors, then extended by density. -/
theorem inner_representation_left (a : A) (x y : GNSHilbert φ) :
    inner (𝕜 := ℂ) (representation φ a x) y =
      inner (𝕜 := ℂ) x (representation φ (star a) y) := by
  refine (denseRange_ofAlgebra φ).induction_on₂
    (p := fun x y => inner (𝕜 := ℂ) (representation φ a x) y =
      inner (𝕜 := ℂ) x (representation φ (star a) y)) ?_ ?_ x y
  · exact isClosed_eq
      (((representation φ a).continuous.comp continuous_fst).inner continuous_snd)
      (continuous_fst.inner ((representation φ (star a)).continuous.comp continuous_snd))
  · intro b c
    simp only [representation_ofAlgebra, inner_ofAlgebra, star_mul, mul_assoc]

@[simp] theorem representation_star (a : A) :
    representation φ (star a) = star (representation φ a) := by
  rw [ContinuousLinearMap.star_eq_adjoint, ContinuousLinearMap.eq_adjoint_iff]
  intro x y
  simpa only [star_star] using inner_representation_left φ (star a) x y

/-- The resulting unital bounded star-algebra representation. -/
def representationStarAlgHom : A →⋆ₐ[ℂ] (GNSHilbert φ →L[ℂ] GNSHilbert φ) :=
  { representationAlgHom φ with map_star' := representation_star φ }

/-- The GNS cyclic vector represented by the algebra unit. -/
def omega : GNSHilbert φ := ofAlgebra φ (1 : A)

@[simp] theorem representation_omega (a : A) :
    representation φ a (omega φ) = ofAlgebra φ a := by
  simp only [omega, representation_ofAlgebra, mul_one]

/-- The original functional is recovered as the vector functional. -/
theorem vector_state (a : A) :
    inner (𝕜 := ℂ) (omega φ) (representation φ a (omega φ)) = φ.map a := by
  simp only [omega, representation_ofAlgebra, mul_one, inner_ofAlgebra, star_one, one_mul]

/-- The orbit of the cyclic vector is dense in the completed Hilbert space. -/
theorem cyclic : DenseRange (fun a : A => representation φ a (omega φ)) := by
  simpa only [representation_omega] using denseRange_ofAlgebra φ

/-- If the input functional is normalized, its cyclic vector is a unit vector. -/
theorem norm_omega (hnormalized : φ.map 1 = 1) : ‖omega φ‖ = 1 := by
  simp [omega, norm_ofAlgebra, hnormalized]

/-- The completed GNS map identifies exactly the null vectors. -/
theorem ofAlgebra_eq_zero_iff (a : A) :
    ofAlgebra φ a = 0 ↔ (φ.map (star a * a)).re = 0 := by
  rw [← norm_eq_zero, norm_ofAlgebra, Real.sqrt_eq_zero (φ.diagonal_nonneg _)]

@[simp] theorem ofAlgebra_sub (a b : A) :
    ofAlgebra φ (a - b) = ofAlgebra φ a - ofAlgebra φ b :=
  Completion.coe_sub (PreGNS.ofAlgebra φ a) (PreGNS.ofAlgebra φ b)

/-- Translations act trivially on the actual completed GNS algebra vectors,
using the pre-quotient contraction theorem already proved. -/
theorem translated_vector_eq
    (α : ℝ → A ≃ₐ[ℂ] A)
    (hzero : ∀ a, α 0 a = a)
    (hadd : ∀ u v a, α (u + v) a = α u (α v a))
    (hinvariant : ∀ u a, φ.map (α u a) = φ.map a)
    (hreversal : ∀ u a, star (α u a) = α (-u) (star a))
    (hisometric : ∀ u a, ‖α u a‖ = ‖a‖)
    (u : ℝ) (a : A) : ofAlgebra φ (α u a) = ofAlgebra φ a := by
  apply sub_eq_zero.mp
  rw [← ofAlgebra_sub, ofAlgebra_eq_zero_iff]
  exact reflection_translation_difference_null φ.map φ.diagonal_real φ.diagonal_nonneg
    α hzero hadd hinvariant hreversal hisometric u a

/-- Lemma 8.1 for the constructed bounded Hilbert-space representation:
represented translations of observables are exactly stationary. The limiting
algebra, functional, and its action remain explicit input data. -/
theorem represented_observables_stationary
    (α : ℝ → A ≃ₐ[ℂ] A)
    (hzero : ∀ a, α 0 a = a)
    (hadd : ∀ u v a, α (u + v) a = α u (α v a))
    (hinvariant : ∀ u a, φ.map (α u a) = φ.map a)
    (hreversal : ∀ u a, star (α u a) = α (-u) (star a))
    (hisometric : ∀ u a, ‖α u a‖ = ‖a‖)
    (u : ℝ) (a : A) : representation φ (α u a) = representation φ a := by
  apply operator_ext φ
  intro b
  calc
    representation φ (α u a) (ofAlgebra φ b) =
        representation φ (α u a) (ofAlgebra φ (α u b)) := by
      rw [translated_vector_eq φ α hzero hadd hinvariant hreversal hisometric]
    _ = ofAlgebra φ (α u a * α u b) := representation_ofAlgebra φ _ _
    _ = ofAlgebra φ (α u (a * b)) := by rw [map_mul]
    _ = ofAlgebra φ (a * b) :=
      translated_vector_eq φ α hzero hadd hinvariant hreversal hisometric u _
    _ = representation φ a (ofAlgebra φ b) := (representation_ofAlgebra φ _ _).symm

end GNSHilbert

end SYK.GNS
