import Majorana
import GaussianDisorder

/-!
# Actual microscopic SYK pressures

The finite flavor count is N = 2m, and the Hilbert-space dimension is 2^m.
The disorder index consists of increasing four-subsets, not all ordered
quadruples. The Gaussian law has exactly the variance in the supplied paper.
The target interacting limit is not asserted in this file.
-/

noncomputable section
open MeasureTheory
open scoped NNReal

namespace SYK.Microscopic

def disorder (m : ℕ) (lam : ℝ≥0) : Measure (Majorana.FourSet m → ℝ) :=
  GaussianDisorder.law (Majorana.FourSet m) (2 * m) lam

instance disorder_isProbabilityMeasure (m : ℕ) (lam : ℝ≥0) :
    IsProbabilityMeasure (disorder m lam) := by
  unfold disorder
  infer_instance

def annealedPressure (m : ℕ) (β : ℝ) (lam : ℝ≥0) : ℝ :=
  GaussianDisorder.annealedPressure (Majorana.FourSet m) (2 * m) lam
    (fun j => (Majorana.partitionFunction m β j).re)

def quenchedPressure (m : ℕ) (β : ℝ) (lam : ℝ≥0) : ℝ :=
  GaussianDisorder.quenchedPressure (Majorana.FourSet m) (2 * m) lam
    (fun j => (Majorana.partitionFunction m β j).re)

/-- The disorder average defining the annealed partition function is a genuine integral. -/
theorem partitionFunction_integrable (m : ℕ) (β : ℝ) (lam : ℝ≥0) :
    Integrable (Majorana.partitionFunction m β) (disorder m lam) := by
  have hg := (GaussianDisorder.integrable_exp_sum_abs (Majorana.FourSet m)
    (2 * m) lam (|β| / 4)).const_mul ((2 : ℝ) ^ m)
  apply hg.mono'
  · exact ((Majorana.continuous_partitionFunction m).comp
      (continuous_const.prod_mk continuous_id)).aestronglyMeasurable
  · filter_upwards [] with j
    convert Majorana.norm_partitionFunction_le m β j using 1 <;> congr 2 <;> ring

theorem real_partitionFunction_integrable (m : ℕ) (β : ℝ) (lam : ℝ≥0) :
    Integrable (fun j => (Majorana.partitionFunction m β j).re) (disorder m lam) :=
  (partitionFunction_integrable m β lam).re

theorem annealedPressure_free (m : ℕ) (hm : 0 < m) (β : ℝ) :
    annealedPressure m β 0 = Real.log 2 / 2 := by
  unfold annealedPressure
  rw [GaussianDisorder.annealedPressure_zero]
  simp only [Nat.cast_mul, Nat.cast_ofNat]
  exact Majorana.pressure_zero m hm β

theorem quenchedPressure_free (m : ℕ) (hm : 0 < m) (β : ℝ) :
    quenchedPressure m β 0 = Real.log 2 / 2 := by
  unfold quenchedPressure
  rw [GaussianDisorder.quenchedPressure_zero]
  simp only [Nat.cast_mul, Nat.cast_ofNat]
  exact Majorana.pressure_zero m hm β

end SYK.Microscopic
