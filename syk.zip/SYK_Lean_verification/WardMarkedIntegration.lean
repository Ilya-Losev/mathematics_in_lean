import WickCoefficientParameters
import WardInteractionSwap
import SymmetricInteractionIntegral

/-! # Integrating the actual marked quartic Ward vertex -/
set_option maxHeartbeats 1200000
noncomputable section
open MeasureTheory Set
open scoped NNReal Topology BigOperators
namespace SYK.ContinuumWickSeries
open ThermalWick Ward WickVertexIntegrals WardInteraction

local instance (β : ℝ) : MeasurableSpace (Time β) :=
  inferInstanceAs (MeasurableSpace {t : ℝ // t ∈ Ico 0 β})

def pairFirst (β : ℝ) (hβ : 0 < β) (p : ℝ×ℝ) : Time β := timeRepresentative β hβ p.1
def pairSecond (β : ℝ) (hβ : 0 < β) (p : ℝ×ℝ) : Time β := timeRepresentative β hβ p.2

theorem pairFirst_measurable (β : ℝ) (hβ : 0 < β) : Measurable (fun p => (pairFirst β hβ p).val) :=
  measurable_subtype_coe.comp ((timeRepresentative_measurable β hβ).comp measurable_fst)
theorem pairSecond_measurable (β : ℝ) (hβ : 0 < β) : Measurable (fun p => (pairSecond β hβ p).val) :=
  measurable_subtype_coe.comp ((timeRepresentative_measurable β hβ).comp measurable_snd)

def cubicPairs (a b c t : Time β) : List (Time β × Time β) := List.replicate 3 (a,b) ++ [(c,t)]

@[simp] theorem cubicPairs_length (a b c t : Time β) : (cubicPairs a b c t).length = 4 := by
  simp [cubicPairs]

/-- Generic measurable cubic Ward insertion, before the residual time integral. -/
theorem cubic_integrand_measurable (d : ℕ) (β : ℝ) (hβ : 0 < β)
    (ps : List (Time β × Time β)) (t : Time β) (c : ℝ×ℝ → Time β)
    (hc : Measurable (fun p => (c p).val)) (n : ℕ) :
    Measurable (fun z : (ℝ×ℝ) × (Fin n → ℝ×ℝ) => coefficientIntegrand d β hβ
      (ps ++ cubicPairs (pairFirst β hβ z.1) (pairSecond β hβ z.1) (c z.1) t) z.2) := by
  let qs : List (((ℝ×ℝ) → Time β) × ((ℝ×ℝ) → Time β)) :=
    ps.map (fun q => ((fun _ => q.1),(fun _ => q.2))) ++
      List.replicate 3 (pairFirst β hβ,pairSecond β hβ) ++ [(c,fun _ => t)]
  have hqs : ∀ q ∈ qs, Measurable (fun p => (q.1 p).val) ∧ Measurable (fun p => (q.2 p).val) := by
    intro q hq
    rcases List.mem_append.mp hq with hq | hq
    · rcases List.mem_append.mp hq with hq | hq
      · obtain ⟨r,_,rfl⟩ := List.mem_map.mp hq
        constructor
        · change Measurable (fun _ : ℝ×ℝ => r.1.val)
          exact measurable_const
        · change Measurable (fun _ : ℝ×ℝ => r.2.val)
          exact measurable_const
      · obtain ⟨_,rfl⟩ := List.mem_replicate.mp hq
        exact ⟨pairFirst_measurable β hβ,pairSecond_measurable β hβ⟩
    · have he : q = (c,fun _ => t) := List.mem_singleton.mp hq
      subst q
      constructor
      · exact hc
      · change Measurable (fun _ : ℝ×ℝ => t.val)
        exact measurable_const
  have h := coefficientIntegrand_parameter_measurable d β hβ qs hqs n
  simpa [qs,cubicPairs,List.map_append,List.map_map,List.map_replicate,Function.comp_def] using h

theorem cubic_coefficient_measurable (d : ℕ) (β : ℝ) (hβ : 0 < β)
    (ps : List (Time β × Time β)) (t : Time β) (c : ℝ×ℝ → Time β)
    (hc : Measurable (fun p => (c p).val)) (n : ℕ) :
    Measurable (fun p => coefficient d β hβ
      (ps ++ cubicPairs (pairFirst β hβ p) (pairSecond β hβ p) (c p) t) n) := by
  have hi := (cubic_integrand_measurable d β hβ ps t c hc n).stronglyMeasurable.integral_prod_right'
    (ν := interactionMeasure β n)
  exact hi.measurable.const_smul _

def wardBranch (d : ℕ) (β : ℝ) (hβ : 0 < β) (ps : List (Time β × Time β))
    (s t : Time β) (a c : ℝ×ℝ → Time β) (n : ℕ) (p : ℝ×ℝ) : ℂ :=
  (Thermal.kernel β s.val (a p).val : ℂ) * coefficient d β hβ
    (ps ++ cubicPairs (pairFirst β hβ p) (pairSecond β hβ p) (c p) t) n

def wardBranchIntegrand (d : ℕ) (β : ℝ) (hβ : 0 < β) (ps : List (Time β × Time β))
    (s t : Time β) (a c : ℝ×ℝ → Time β) {n : ℕ} (z : (ℝ×ℝ) × (Fin n → ℝ×ℝ)) : ℂ :=
  (Thermal.kernel β s.val (a z.1).val : ℂ) * coefficientIntegrand d β hβ
    (ps ++ cubicPairs (pairFirst β hβ z.1) (pairSecond β hβ z.1) (c z.1) t) z.2

theorem wardBranchIntegrand_measurable (d : ℕ) (β : ℝ) (hβ : 0 < β)
    (ps : List (Time β × Time β)) (s t : Time β) (a c : ℝ×ℝ → Time β)
    (ha : Measurable (fun p => (a p).val)) (hc : Measurable (fun p => (c p).val)) (n : ℕ) :
    Measurable (wardBranchIntegrand d β hβ ps s t a c (n := n)) := by
  have hk : Measurable (fun z : (ℝ×ℝ) × (Fin n → ℝ×ℝ) =>
      (Thermal.kernel β s.val (a z.1).val : ℂ)) :=
    Complex.measurable_ofReal.comp ((Thermal.covariance_measurable β).comp
      (measurable_const.sub (ha.comp measurable_fst)))
  exact hk.mul (cubic_integrand_measurable d β hβ ps t c hc n)

theorem wardBranch_measurable (d : ℕ) (β : ℝ) (hβ : 0 < β)
    (ps : List (Time β × Time β)) (s t : Time β) (a c : ℝ×ℝ → Time β)
    (ha : Measurable (fun p => (a p).val)) (hc : Measurable (fun p => (c p).val)) (n : ℕ) :
    Measurable (wardBranch d β hβ ps s t a c n) := by
  have hk : Measurable (fun p : ℝ×ℝ => (Thermal.kernel β s.val (a p).val : ℂ)) :=
    Complex.measurable_ofReal.comp ((Thermal.covariance_measurable β).comp (measurable_const.sub ha))
  exact hk.mul (cubic_coefficient_measurable d β hβ ps t c hc n)

theorem norm_covariance_time_le (β : ℝ) (s t : Time β) : ‖(Thermal.kernel β s.val t.val : ℂ)‖ ≤ 1/2 := by
  simpa only [Complex.norm_real,Real.norm_eq_abs] using Thermal.abs_covariance_le β (s.val-t.val)

theorem wardBranchIntegrand_bound (d : ℕ) (hd : 0 < d) (β : ℝ) (hβ : 0 < β)
    (ps : List (Time β × Time β)) (s t : Time β) (a c : ℝ×ℝ → Time β)
    {n : ℕ} (z : (ℝ×ℝ) × (Fin n → ℝ×ℝ)) :
    ‖wardBranchIntegrand d β hβ ps s t a c z‖ ≤ (1/2:ℝ)*(1/2:ℝ)^(ps.length+4+4*n) := by
  apply (norm_mul_le _ _).trans
  have hc := coefficientIntegrand_bound d hd β hβ
    (ps ++ cubicPairs (pairFirst β hβ z.1) (pairSecond β hβ z.1) (c z.1) t) z.2
  simp only [List.length_append,cubicPairs_length] at hc
  exact mul_le_mul (norm_covariance_time_le β s _) hc (norm_nonneg _) (by norm_num)

theorem wardBranch_bound (d : ℕ) (hd : 0 < d) (β : ℝ) (hβ : 0 < β)
    (ps : List (Time β × Time β)) (s t : Time β) (a c : ℝ×ℝ → Time β)
    (n : ℕ) (p : ℝ×ℝ) :
    ‖wardBranch d β hβ ps s t a c n p‖ ≤
      ((1/2:ℝ)*(1/2:ℝ)^(ps.length+4)) * (((2*d:ℕ):ℝ)*β^2/128)^n := by
  apply (norm_mul_le _ _).trans
  have hc := coefficient_bound d hd β hβ
    (ps ++ cubicPairs (pairFirst β hβ p) (pairSecond β hβ p) (c p) t) n
  simp only [List.length_append,cubicPairs_length] at hc
  exact (mul_le_mul (norm_covariance_time_le β s _) hc (norm_nonneg _) (by norm_num)).trans_eq (by ring)

theorem wardBranch_integrable (d : ℕ) (hd : 0 < d) (β : ℝ) (hβ : 0 < β)
    (ps : List (Time β × Time β)) (s t : Time β) (a c : ℝ×ℝ → Time β)
    (ha : Measurable (fun p => (a p).val)) (hc : Measurable (fun p => (c p).val)) (n : ℕ) :
    Integrable (wardBranch d β hβ ps s t a c n) (pairMeasure β) := by
  exact (integrable_const _).mono'
    (wardBranch_measurable d β hβ ps s t a c ha hc n).aestronglyMeasurable
    (ae_of_all _ (wardBranch_bound d hd β hβ ps s t a c n))

theorem markedIntegrand_eq_branches (d : ℕ) (hd : 0 < d) (β : ℝ) (hβ : 0 < β)
    (ps : List (Time β × Time β)) (s t : Time β) {n : ℕ}
    (u : Fin (n+1) → ℝ×ℝ) (r : Fin (n+1)) :
    markedIntegrand d β hβ ps s t u r = (((2*d:ℕ):ℂ)/8)^n/2 *
      (wardBranchIntegrand d β hβ ps s t (pairFirst β hβ) (pairSecond β hβ)
        (u r,fun i => u (r.succAbove i)) -
       wardBranchIntegrand d β hβ ps s t (pairSecond β hβ) (pairFirst β hβ)
        (u r,fun i => u (r.succAbove i))) := by
  simpa only [wardBranchIntegrand,cubicPairs,pairFirst,pairSecond,List.append_assoc] using
    markedIntegrand_eq d hd β hβ ps s t u r

theorem markedIntegrand_measurable (d : ℕ) (hd : 0 < d) (β : ℝ) (hβ : 0 < β)
    (ps : List (Time β × Time β)) (s t : Time β) {n : ℕ} (r : Fin (n+1)) :
    Measurable (fun u => markedIntegrand d β hβ ps s t u r) := by
  have hm : Measurable (fun u : Fin (n+1) → ℝ×ℝ => (u r,fun i => u (r.succAbove i))) :=
    (measurable_pi_apply r).prodMk (measurable_pi_lambda _ (fun i => measurable_pi_apply _))
  have hA := (wardBranchIntegrand_measurable d β hβ ps s t (pairFirst β hβ) (pairSecond β hβ)
    (pairFirst_measurable β hβ) (pairSecond_measurable β hβ) n).comp hm
  have hB := (wardBranchIntegrand_measurable d β hβ ps s t (pairSecond β hβ) (pairFirst β hβ)
    (pairSecond_measurable β hβ) (pairFirst_measurable β hβ) n).comp hm
  simpa only [markedIntegrand_eq_branches d hd β hβ ps s t] using (hA.sub hB).const_mul ((((2*d:ℕ):ℂ)/8)^n/2)

theorem markedIntegrand_integrable (d : ℕ) (hd : 0 < d) (β : ℝ) (hβ : 0 < β)
    (ps : List (Time β × Time β)) (s t : Time β) {n : ℕ} (r : Fin (n+1)) :
    Integrable (fun u => markedIntegrand d β hβ ps s t u r) (interactionMeasure β (n+1)) := by
  apply (integrable_const (‖(((2*d:ℕ):ℂ)/8)^n/2‖ *
    (2*((1/2:ℝ)*(1/2:ℝ)^(ps.length+4+4*n))))).mono'
    (markedIntegrand_measurable d hd β hβ ps s t r).aestronglyMeasurable
  filter_upwards [] with u
  rw [markedIntegrand_eq_branches d hd]
  apply (norm_mul_le _ _).trans
  apply mul_le_mul_of_nonneg_left _ (norm_nonneg _)
  exact (norm_sub_le _ _).trans ((add_le_add
    (wardBranchIntegrand_bound d hd β hβ ps s t _ _ _)
    (wardBranchIntegrand_bound d hd β hβ ps s t _ _ _)).trans_eq (by ring))

/-- The inner residual time integral reproduces the exact coefficient prefactor. -/
theorem integral_marked_insertNth (d : ℕ) (hd : 0 < d) (β : ℝ) (hβ : 0 < β)
    (ps : List (Time β × Time β)) (s t : Time β) (n : ℕ) (r : Fin (n+1)) (p : ℝ×ℝ) :
    (∫ u, markedIntegrand d β hβ ps s t (r.insertNth p u) r ∂interactionMeasure β n) =
      (1/2:ℂ) * (wardBranch d β hβ ps s t (pairFirst β hβ) (pairSecond β hβ) n p -
        wardBranch d β hβ ps s t (pairSecond β hβ) (pairFirst β hβ) n p) := by
  simp_rw [markedIntegrand_eq_branches d hd β hβ ps s t,
    Fin.insertNth_apply_same,Fin.insertNth_apply_succAbove]
  have hA := (coefficientIntegrand_integrable d hd β hβ
    (ps ++ cubicPairs (pairFirst β hβ p) (pairSecond β hβ p) (pairSecond β hβ p) t) n).const_mul
      (Thermal.kernel β s.val (pairFirst β hβ p).val:ℂ)
  have hB := (coefficientIntegrand_integrable d hd β hβ
    (ps ++ cubicPairs (pairFirst β hβ p) (pairSecond β hβ p) (pairFirst β hβ p) t) n).const_mul
      (Thermal.kernel β s.val (pairSecond β hβ p).val:ℂ)
  simp only [wardBranchIntegrand]
  rw [integral_const_mul,integral_sub hA hB]
  simp only [wardBranchIntegrand,integral_const_mul,wardBranch,coefficient,Complex.real_smul,
    Complex.ofReal_pow,Complex.ofReal_div,Complex.ofReal_natCast]
  norm_num
  ring

/-- The antisymmetric swap survives the residual integral and coefficient prefactor. -/
theorem wardBranch_swap (d : ℕ) (β : ℝ) (hβ : 0 < β)
    (ps : List (Time β × Time β)) (s t : Time β) (n : ℕ) (p : ℝ×ℝ) :
    wardBranch d β hβ ps s t (pairSecond β hβ) (pairFirst β hβ) n p.swap =
      -wardBranch d β hβ ps s t (pairFirst β hβ) (pairSecond β hβ) n p := by
  unfold wardBranch coefficient cubicPairs pairFirst pairSecond
  simp only [Prod.swap]
  simp only [← List.append_assoc]
  have hc := fun u : Fin n → ℝ×ℝ => coefficientIntegrand_cubic_swap d β hβ ps
    (timeRepresentative β hβ p.1) (timeRepresentative β hβ p.2)
    (timeRepresentative β hβ p.2) t u
  simp_rw [hc]
  simp only [integral_neg,smul_neg,mul_neg]

/-- Every actual marked quartic has the same integrated single-branch Ward kernel. -/
theorem integral_markedIntegrand (d : ℕ) (hd : 0 < d) (β : ℝ) (hβ : 0 < β)
    (ps : List (Time β × Time β)) (s t : Time β) (n : ℕ) (r : Fin (n+1)) :
    (∫ u, markedIntegrand d β hβ ps s t u r ∂interactionMeasure β (n+1)) =
      ∫ p, wardBranch d β hβ ps s t (pairFirst β hβ) (pairSecond β hβ) n p ∂pairMeasure β := by
  rw [integral_interaction_marked β n r _ (markedIntegrand_integrable d hd β hβ ps s t r)]
  simp_rw [integral_marked_insertNth d hd β hβ ps s t n r]
  rw [integral_const_mul,integral_sub
    (wardBranch_integrable d hd β hβ ps s t _ _ (pairFirst_measurable β hβ) (pairSecond_measurable β hβ) n)
    (wardBranch_integrable d hd β hβ ps s t _ _ (pairSecond_measurable β hβ) (pairFirst_measurable β hβ) n)]
  have hswap := integral_pair_swap β (wardBranch d β hβ ps s t (pairSecond β hβ) (pairFirst β hβ) n)
  simp_rw [wardBranch_swap,integral_neg] at hswap
  rw [← hswap]
  ring

end SYK.ContinuumWickSeries
