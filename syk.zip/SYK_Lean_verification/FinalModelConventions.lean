import PhysicalEndpoints
import PressureGap

/-!
# Exact final model conventions

These are conversion theorems for actual microscopic pressures, not assertions
of their missing interacting limit. They fix every integer midpoint, the real
coupling parameter λ=J², and free energy per Majorana as −p/β.
-/
noncomputable section
open Filter
open scoped Topology NNReal
namespace SYK

namespace Microscopic
/-- Actual annealed free energy per Majorana, for N=2m. -/
def annealedFreeEnergy (m : ℕ) (β : ℝ) (lam : ℝ≥0) : ℝ :=
  -annealedPressure m β lam / β

/-- Actual quenched free energy per Majorana, for N=2m. -/
def quenchedFreeEnergy (m : ℕ) (β : ℝ) (lam : ℝ≥0) : ℝ :=
  -quenchedPressure m β lam / β
end Microscopic

namespace Continuum
/-- The manuscript's nonnegative variance parameter for a real disorder scale. -/
def couplingOfJ (J : ℝ) : ℝ≥0 := ⟨J^2, sq_nonneg J⟩

@[simp] theorem couplingOfJ_coe (J : ℝ) : (couplingOfJ J : ℝ) = J^2 := rfl
@[simp] theorem couplingOfJ_neg (J : ℝ) : couplingOfJ (-J) = couplingOfJ J := by
  apply Subtype.ext
  simp [couplingOfJ]

/-- All jump midpoints, including negative thermal lifts, are exactly zero. -/
theorem physical_integer_midpoint (β : ℝ) (lam : ℝ≥0) (g : ℝ → ℝ)
    (hg : PhysicalSolution β lam g) (k : ℤ) : g ((k : ℝ)*β) = 0 := by
  exact (show Function.Antiperiodic g β from hg.2.2.1).int_mul_eq_of_eq_zero
    hg.2.2.2.1 k

/-- Reflection and fermionic antiperiodicity imply actual skewness on all lifts. -/
theorem physical_odd (β : ℝ) (lam : ℝ≥0) (g : ℝ → ℝ)
    (hg : PhysicalSolution β lam g) (t : ℝ) : g (-t) = -g t := by
  have h := hg.2.2.1 (-t)
  have hs := hg.2.2.2.2.1 t
  rw [show -t+β = β-t by ring, hs] at h
  linarith

/-- Convergence of both actual microscopic pressures gives convergence of both
actual microscopic free energies with exactly the manuscript's sign and scale. -/
theorem freeEnergy_convergence_of_pressure_convergence (β : ℝ) (lam : ℝ≥0) (p : ℝ)
    (hp : PressureConvergence β lam p) :
    Tendsto (fun m : ℕ => Microscopic.annealedFreeEnergy m β lam) atTop (𝓝 (-p/β)) ∧
    Tendsto (fun m : ℕ => Microscopic.quenchedFreeEnergy m β lam) atTop (𝓝 (-p/β)) := by
  exact ⟨hp.1.neg.div_const β, hp.2.neg.div_const β⟩

/-- The predicted free energy, with the original real scale J and λ=J². -/
def couplingFreeEnergy (β : ℝ) (g : ℝ≥0 → ℝ → ℝ) (J : ℝ) : ℝ :=
  -couplingPressure β g (couplingOfJ J) / β

theorem couplingFreeEnergy_formula (β : ℝ) (g : ℝ≥0 → ℝ → ℝ) (J : ℝ) :
    couplingFreeEnergy β g J = -(Real.log 2 / 2 + β/8 *
      ∫ l in (0 : ℝ)..J^2, ∫ t in (0 : ℝ)..β, (g (Real.toNNReal l) t)^4) / β := rfl

/-- Final conversion at λ=J²; its pressure-convergence premise is the actual
microscopic predicate and must be proved by the main assembly. -/
theorem freeEnergy_convergence_J (β : ℝ) (g : ℝ≥0 → ℝ → ℝ) (J : ℝ)
    (hp : PressureConvergence β (couplingOfJ J) (couplingPressure β g (couplingOfJ J))) :
    Tendsto (fun m : ℕ => Microscopic.annealedFreeEnergy m β (couplingOfJ J))
      atTop (𝓝 (couplingFreeEnergy β g J)) ∧
    Tendsto (fun m : ℕ => Microscopic.quenchedFreeEnergy m β (couplingOfJ J))
      atTop (𝓝 (couplingFreeEnergy β g J)) :=
  freeEnergy_convergence_of_pressure_convergence β _ _ hp

end Continuum
end SYK
