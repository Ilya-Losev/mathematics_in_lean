import KernelSDAnalyticity
import KernelResidualAlgebra

/-!
# Analyticity and half-generation in the constructed double quotient

The integrated SD equations and the endpoint Lipschitz bound are theorems of
this concrete quotient, not hypotheses about an unspecified kernel. Nontriviality
and the chosen polynomial symmetry relations remain separate inputs supplied
by the limiting functional and the first-quotient construction.
-/

noncomputable section
namespace SYK.KernelQuotientAnalyticity

open Set
open SYK.WeightedKernelAlgebra SYK.KernelResidualAlgebra

variable {J : Type*} (b K : ℝ) (hb : 0 < b) (hK : 0 < K)
  (β : ℝ) (hβ : 0 < β) (lam : ℂ) (extra : J → MvPolynomial KernelIndex ℂ)
  [Nontrivial (RegularityAlgebra b K hb hK (thermalCovariance β) extra)]

/-- The actual thermal double quotient with the scalar midpoint covariance. -/
abbrev ThermalSDAlgebra :=
  SchwingerDysonAlgebra b K hb hK (thermalCovariance β) extra β hβ.le lam
    (thermalCovariance_stronglyMeasurable β) (1/2) (norm_thermalCovariance_le β)

variable [Nontrivial (ThermalSDAlgebra b K hb hK β hβ lam extra)]

/-- The actual final bilocal kernel, with no selection of a.e. representatives. -/
abbrev thermalFinalKernel : KernelSpace (ThermalSDAlgebra b K hb hK β hβ lam extra) :=
  finalKernel b K hb hK (thermalCovariance β) extra β hβ.le lam
    (thermalCovariance_stronglyMeasurable β) (1/2) (norm_thermalCovariance_le β)

/-- The prescribed jump is removed before differentiation. -/
def thermalFinalRemainder : KernelSpace (ThermalSDAlgebra b K hb hK β hβ lam extra) :=
  thermalFinalKernel b K hb hK β hβ lam extra-freeThermalKernel β

@[simp] theorem free_add_thermalFinalRemainder :
    freeThermalKernel β+thermalFinalRemainder b K hb hK β hβ lam extra =
      thermalFinalKernel b K hb hK β hβ lam extra := by
  unfold thermalFinalRemainder
  abel

/-- Both integral SD identities hold in the constructed quotient with the
actual free covariance and the target's parenthesization. -/
theorem thermalFinal_integratedSD :
    TwoSidedIntegratedKernelSD β hβ.le lam
      (thermalFinalRemainder b K hb hK β hβ lam extra) := by
  have hl := final_left_sd b K hb hK (thermalCovariance β) extra β hβ.le lam
    (thermalCovariance_stronglyMeasurable β) (1/2) (norm_thermalCovariance_le β)
  have hr := final_right_sd b K hb hK (thermalCovariance β) extra β hβ.le lam
    (thermalCovariance_stronglyMeasurable β) (1/2) (norm_thermalCovariance_le β)
  rw [finalCovariance_eq_free] at hl hr
  dsimp only [TwoSidedIntegratedKernelSD]
  rw [free_add_thermalFinalRemainder]
  exact ⟨hl,hr⟩

/-- The weighted increment relations give the exact all-endpoint Lipschitz
bound in the second quotient's actual norm. -/
theorem thermalFinal_remainder_lipschitz (s t s' t' : ℝ) :
    ‖thermalFinalRemainder b K hb hK β hβ lam extra (s,t)-
      thermalFinalRemainder b K hb hK β hβ lam extra (s',t')‖ ≤
        K*(|s-s'|+|t-t'|) := by
  have h := norm_finalRemainder_sub_le b K hb hK (thermalCovariance β) extra β hβ.le lam
    (thermalCovariance_stronglyMeasurable β) (1/2) (norm_thermalCovariance_le β) (s,t) (s',t')
  rw [finalCovariance_eq_free] at h
  exact h

/-- Center-time analyticity for the constructed thermal double quotient. The
actual SD and regularity obligations have been discharged by its construction. -/
theorem thermalFinal_remainder_analytic
    (hanti : KernelAntiperiodic β (thermalFinalKernel b K hb hK β hβ lam extra)) :
    AnalyticOnNhd ℝ (fun u => translateKernel u
      (thermalFinalRemainder b K hb hK β hβ lam extra)) Set.univ := by
  apply integratedSD_analytic_of_endpoint_lipschitz β hβ lam _
    (thermalFinal_integratedSD b K hb hK β hβ lam extra) _ K hK.le
    (thermalFinal_remainder_lipschitz b K hb hK β hβ lam extra)
  simpa only [free_add_thermalFinalRemainder] using hanti

/-- Analyticity of every actual quotient coordinate orbit. -/
theorem thermalFinal_coordinate_analytic
    (hanti : KernelAntiperiodic β (thermalFinalKernel b K hb hK β hβ lam extra)) (s t : ℝ) :
    AnalyticOnNhd ℝ (fun u => thermalFinalKernel b K hb hK β hβ lam extra (s+u,t+u)) Set.univ := by
  have ha := integratedSD_coordinate_orbit_analytic β hβ lam
    (thermalFinalRemainder b K hb hK β hβ lam extra)
    (thermalFinal_integratedSD b K hb hK β hβ lam extra)
    (by simpa only [free_add_thermalFinalRemainder] using hanti)
    K hK.le (thermalFinal_remainder_lipschitz b K hb hK β hβ lam extra) s t
  simpa only [free_add_thermalFinalRemainder] using ha

/-- Every coordinate of the actual double quotient lies in any closed unital
subalgebra containing the positive-half-time coordinates. -/
theorem thermalFinal_all_coordinates_mem_half_algebra
    (hanti : KernelAntiperiodic β (thermalFinalKernel b K hb hK β hβ lam extra))
    (B : Subalgebra ℂ (ThermalSDAlgebra b K hb hK β hβ lam extra))
    [IsClosed (B : Set (ThermalSDAlgebra b K hb hK β hβ lam extra))]
    (hhalf : ∀ s ∈ Ioo (0:ℝ) (β/2), ∀ t ∈ Ioo (0:ℝ) (β/2),
      thermalFinalKernel b K hb hK β hβ lam extra (s,t) ∈ B) :
    ∀ s t, thermalFinalKernel b K hb hK β hβ lam extra (s,t) ∈ B := by
  have hm := integratedSD_all_coordinates_mem_half_algebra β hβ lam
    (thermalFinalRemainder b K hb hK β hβ lam extra)
    (thermalFinal_integratedSD b K hb hK β hβ lam extra)
    (by simpa only [free_add_thermalFinalRemainder] using hanti)
    K hK.le (thermalFinal_remainder_lipschitz b K hb hK β hβ lam extra) B
    (by simpa only [free_add_thermalFinalRemainder] using hhalf)
  simpa only [free_add_thermalFinalRemainder] using hm

end SYK.KernelQuotientAnalyticity
