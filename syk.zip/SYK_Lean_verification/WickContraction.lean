import Mathlib.LinearAlgebra.CliffordAlgebra.Contraction
import Mathlib.LinearAlgebra.Matrix.BilinearForm
import Mathlib.LinearAlgebra.Finsupp.LinearCombination
import Mathlib.Tactic.Ring

/-!
# An actual exterior-algebra Wick functional and contraction identities

This module constructs the normalized Wick functional of an alternating bilinear
covariance on the genuine exterior algebra. It does not assume a functional with
the desired Wick identity. The construction uses the proved Clifford change-of-form
map and the exterior scalar augmentation.

The algebraic contraction identity, two-point function, four-point Pfaffian, and
coincident-generator exclusion below are unconditional once a covariance is fixed.
The physical identification with time-ordered Majorana traces, Duhamel expansion,
and Gaussian disorder integration remain separate obligations.
-/

noncomputable section

namespace SYK.Wick

variable {R M : Type*} [CommRing R] [AddCommGroup M] [Module R M]

/-- A bilinear covariance with the exterior (zero diagonal) convention. -/
structure Covariance (R M : Type*) [CommRing R] [AddCommGroup M] [Module R M] where
  form : LinearMap.BilinForm R M
  diagonal_zero : ∀ m, form m m = 0

namespace Covariance

variable (C : Covariance R M)

/-- The scalar augmentation of the genuine exterior algebra. -/
def augmentation : ExteriorAlgebra R M →ₐ[R] R := ExteriorAlgebra.algebraMapInv

@[simp] theorem augmentation_ι (m : M) :
    augmentation (R := R) (M := M) (ExteriorAlgebra.ι R m) = 0 := by
  simp [augmentation, ExteriorAlgebra.algebraMapInv]

theorem negative_form_zero :
    (-C.form).toQuadraticMap =
      (0 : QuadraticForm R M) - (0 : QuadraticForm R M) := by
  ext m
  simp [LinearMap.BilinMap.toQuadraticMap_apply, C.diagonal_zero]

/-- Wick reordering as a concrete linear automorphism of the exterior algebra. -/
def reorder : ExteriorAlgebra R M →ₗ[R] ExteriorAlgebra R M :=
  CliffordAlgebra.changeForm C.negative_form_zero

/-- The actual normalized exterior Wick functional. -/
def expectation : ExteriorAlgebra R M →ₗ[R] R :=
  (augmentation (R := R) (M := M)).toLinearMap.comp C.reorder

/-- Odd contraction with one external vector, defined on the exterior quotient. -/
def contraction (a : M) : ExteriorAlgebra R M →ₗ[R] ExteriorAlgebra R M :=
  CliffordAlgebra.contractLeft (C.form a)

@[simp] theorem reorder_one : C.reorder 1 = 1 := by
  exact CliffordAlgebra.changeForm_one _

@[simp] theorem reorder_ι (a : M) :
    C.reorder (ExteriorAlgebra.ι R a) = ExteriorAlgebra.ι R a := by
  exact CliffordAlgebra.changeForm_ι _ _

@[simp] theorem expectation_one : C.expectation 1 = 1 := by
  simp [expectation]

@[simp] theorem expectation_ι (a : M) :
    C.expectation (ExteriorAlgebra.ι R a) = 0 := by
  simp [expectation]

@[simp] theorem contraction_one (a : M) : C.contraction a 1 = 0 := by
  simp [contraction]

@[simp] theorem contraction_ι (a b : M) :
    C.contraction a (ExteriorAlgebra.ι R b) =
      algebraMap R (ExteriorAlgebra R M) (C.form a b) := by
  exact CliffordAlgebra.contractLeft_ι _ _ _

/-- The odd product rule against a generator, valid including repeated generators. -/
theorem contraction_ι_mul (a b : M) (F : ExteriorAlgebra R M) :
    C.contraction a (ExteriorAlgebra.ι R b * F) =
      C.form a b • F - ExteriorAlgebra.ι R b * C.contraction a F := by
  exact CliffordAlgebra.contractLeft_ι_mul (C.form a) b F

theorem reorder_contraction (a : M) (F : ExteriorAlgebra R M) :
    C.reorder (C.contraction a F) = C.contraction a (C.reorder F) := by
  exact CliffordAlgebra.changeForm_contractLeft _ _ _

/-- Gaussian integration by parts on the actual exterior algebra. -/
theorem expectation_ι_mul (a : M) (F : ExteriorAlgebra R M) :
    C.expectation (ExteriorAlgebra.ι R a * F) =
      C.expectation (C.contraction a F) := by
  dsimp [expectation, reorder, contraction]
  rw [CliffordAlgebra.changeForm_ι_mul, map_sub, map_mul, augmentation_ι, zero_mul,
    zero_sub, CliffordAlgebra.changeForm_contractLeft]
  simp [contraction]

/-- The covariance is genuinely the two-point function of the constructed functional. -/
theorem expectation_two (a b : M) :
    C.expectation (ExteriorAlgebra.ι R a * ExteriorAlgebra.ι R b) = C.form a b := by
  rw [C.expectation_ι_mul, C.contraction_ι]
  simp [expectation, reorder]

/-- The scalar term for a distinguished partner plus the full insertion contraction. -/
theorem expectation_two_inserted (a b : M) (F : ExteriorAlgebra R M) :
    C.expectation (ExteriorAlgebra.ι R a * (ExteriorAlgebra.ι R b * F)) =
      C.form a b * C.expectation F -
        C.expectation (ExteriorAlgebra.ι R b * C.contraction a F) := by
  rw [C.expectation_ι_mul, C.contraction_ι_mul, map_sub, map_smul]
  rfl

/-- The full graded product rule, proved on the exterior algebra rather than on words. -/
theorem contraction_mul (a : M) (F H : ExteriorAlgebra R M) :
    C.contraction a (F * H) = C.contraction a F * H +
      CliffordAlgebra.involute F * C.contraction a H := by
  induction F using CliffordAlgebra.left_induction with
  | algebraMap r =>
    simp [contraction, CliffordAlgebra.contractLeft_algebraMap_mul]
  | add F G hF hG =>
    simp only [add_mul, map_add, hF, hG]
    abel
  | ι_mul F v hF =>
    rw [mul_assoc, C.contraction_ι_mul, hF, C.contraction_ι_mul, map_mul,
      CliffordAlgebra.involute_ι]
    simp only [mul_add, sub_mul, smul_mul_assoc, neg_mul, mul_neg, mul_assoc]
    abel

/-- Even insertions have the ordinary unsigned Leibniz rule. -/
theorem contraction_even_mul (a : M) (P Q : ExteriorAlgebra R M)
    (hP : CliffordAlgebra.involute P = P) :
    C.contraction a (P * Q) = C.contraction a P * Q + P * C.contraction a Q := by
  rw [C.contraction_mul, hP]

/-- The three contributions used in the Ward identity, before thermal integration. -/
theorem expectation_ward_split (a b : M) (P Q : ExteriorAlgebra R M)
    (hP : CliffordAlgebra.involute P = P) :
    C.expectation (ExteriorAlgebra.ι R a * (ExteriorAlgebra.ι R b * (P * Q))) =
      C.form a b * C.expectation (P * Q) -
        C.expectation (ExteriorAlgebra.ι R b * (C.contraction a P * Q)) -
        C.expectation (ExteriorAlgebra.ι R b * (P * C.contraction a Q)) := by
  rw [C.expectation_two_inserted, C.contraction_even_mul a P Q hP, mul_add, map_add]
  abel

/-- A bilocal exterior observable is even. -/
theorem bilocal_even (a b : M) :
    CliffordAlgebra.involute (ExteriorAlgebra.ι R a * ExteriorAlgebra.ι R b) =
      ExteriorAlgebra.ι R a * ExteriorAlgebra.ι R b := by
  simp

/-- Exact derivative of one bilocal coordinate. -/
theorem contraction_bilocal (a b c : M) :
    C.contraction a (ExteriorAlgebra.ι R b * ExteriorAlgebra.ι R c) =
      C.form a b • ExteriorAlgebra.ι R c - C.form a c • ExteriorAlgebra.ι R b := by
  rw [C.contraction_ι_mul, C.contraction_ι]
  simp [Algebra.algebraMap_eq_smul_one]

/-- Four-point Pfaffian, with all contact signs fixed by the exterior quotient. -/
theorem expectation_four (a b c d : M) :
    C.expectation (ExteriorAlgebra.ι R a * (ExteriorAlgebra.ι R b *
      (ExteriorAlgebra.ι R c * ExteriorAlgebra.ι R d))) =
      C.form a b * C.form c d - C.form a c * C.form b d +
        C.form a d * C.form b c := by
  rw [C.expectation_two_inserted, C.expectation_two, C.contraction_ι_mul,
    C.contraction_ι]
  simp only [mul_sub, map_sub, mul_smul_comm, map_smul, C.expectation_two,
    Algebra.algebraMap_eq_smul_one, mul_one, smul_eq_mul]
  ring

/-- Exterior equal-time exclusion is exact, rather than an asymptotic assertion. -/
theorem repeated_generator (a : M) (F : ExteriorAlgebra R M) :
    C.expectation (ExteriorAlgebra.ι R a * (ExteriorAlgebra.ι R a * F)) = 0 := by
  rw [← mul_assoc, ExteriorAlgebra.ι_sq_zero, zero_mul, map_zero]

/-- Alternation entails the skew covariance identity. -/
theorem form_skew (a b : M) : C.form a b = -C.form b a := by
  have h := C.diagonal_zero (a + b)
  have h' : C.form b a = -C.form a b := by
    simpa [map_add, C.diagonal_zero, add_eq_zero_iff_eq_neg] using h
  rw [h', neg_neg]

/-- A vector in the covariance radical has identically zero contraction. -/
theorem contraction_eq_zero (a : M) (ha : ∀ b, C.form a b = 0) :
    C.contraction a = 0 := by
  have h : C.form a = 0 := LinearMap.ext ha
  simp [contraction, h]

/-- Covariance-radical relations vanish even with arbitrary exterior insertions. -/
theorem expectation_radical_inserted (a : M) (ha : ∀ b, C.form a b = 0)
    (F : ExteriorAlgebra R M) :
    C.expectation (ExteriorAlgebra.ι R a * F) = 0 := by
  rw [C.expectation_ι_mul, C.contraction_eq_zero a ha]
  simp

/-- A flavor-averaged bilocal; use `scale = (N : R)⁻¹` over a field. -/
def collective {ι : Type*} [Fintype ι] (scale : R) (v w : ι → M) :
    ExteriorAlgebra R M :=
  scale • ∑ i, ExteriorAlgebra.ι R (v i) * ExteriorAlgebra.ι R (w i)

/-- Finite flavor averaging preserves the exact odd contraction formula. -/
theorem contraction_collective {ι : Type*} [Fintype ι] (a : M) (scale : R)
    (v w : ι → M) :
    C.contraction a (collective scale v w) =
      scale • ∑ i, (C.form a (v i) • ExteriorAlgebra.ι R (w i) -
        C.form a (w i) • ExteriorAlgebra.ι R (v i)) := by
  simp only [collective, map_smul, map_sum, C.contraction_bilocal]

end Covariance

section Indexed

variable {ι : Type*} [Fintype ι] [DecidableEq ι]

/-- Extending a skew matrix to arbitrary coefficient vectors preserves skewness. -/
theorem matrix_form_skew (B : Matrix ι ι R) (hB : ∀ i j, B i j = -B j i)
    (x y : ι → R) : Matrix.toBilin' B x y = -Matrix.toBilin' B y x := by
  simp only [Matrix.toBilin'_apply]
  calc
    (∑ i, ∑ j, x i * B i j * y j) =
        ∑ i, ∑ j, -(y j * B j i * x i) := by
      apply Finset.sum_congr rfl
      intro i _
      apply Finset.sum_congr rfl
      intro j _
      rw [hB i j]
      ring
    _ = -(∑ i, ∑ j, y j * B j i * x i) := by simp
    _ = -(∑ i, ∑ j, y i * B i j * x j) := by rw [Finset.sum_comm]

/-- A concrete finite indexed covariance; there is no assumed Wick functional. -/
def covarianceOfMatrix [NoZeroDivisors R] [CharZero R]
    (B : Matrix ι ι R) (hB : ∀ i j, B i j = -B j i) : Covariance R (ι → R) where
  form := Matrix.toBilin' B
  diagonal_zero x := CharZero.eq_neg_self_iff.mp (matrix_form_skew B hB x x)

/-- The indexed generators recover the specified scalar covariance entries exactly. -/
theorem indexed_expectation_two [NoZeroDivisors R] [CharZero R]
    (B : Matrix ι ι R) (hB : ∀ i j, B i j = -B j i) (i j : ι) :
    (covarianceOfMatrix B hB).expectation
      (ExteriorAlgebra.ι R (Pi.single i 1) * ExteriorAlgebra.ι R (Pi.single j 1)) =
      B i j := by
  rw [Covariance.expectation_two]
  exact Matrix.toBilin'_single B i j

variable {τ : Type*} [Fintype τ] [DecidableEq τ]

/-- The finite flavor/time covariance has an exact Kronecker flavor delta. -/
def flavorMatrix (K : τ → τ → R) : Matrix (ι × τ) (ι × τ) R :=
  fun p q => if p.1 = q.1 then K p.2 q.2 else 0

omit [Fintype ι] [Fintype τ] [DecidableEq τ] in
theorem flavorMatrix_skew (K : τ → τ → R) (hK : ∀ s t, K s t = -K t s) :
    ∀ p q : ι × τ, flavorMatrix K p q = -flavorMatrix K q p := by
  intro p q
  by_cases h : p.1 = q.1
  · rw [flavorMatrix, flavorMatrix, if_pos h, if_pos h.symm]
    exact hK p.2 q.2
  · simp [flavorMatrix, h, Ne.symm h]

/-- Finite flavor/time covariance constructed from the specified skew time kernel. -/
def flavorCovariance [NoZeroDivisors R] [CharZero R]
    (K : τ → τ → R) (hK : ∀ s t, K s t = -K t s) :
    Covariance R ((ι × τ) → R) :=
  covarianceOfMatrix (flavorMatrix K) (flavorMatrix_skew K hK)

/-- One finite flavor/time exterior generator. -/
def field (i : ι) (t : τ) : ExteriorAlgebra R ((ι × τ) → R) :=
  ExteriorAlgebra.ι R (Pi.single (i, t) 1)

@[simp] theorem flavor_form [NoZeroDivisors R] [CharZero R]
    (K : τ → τ → R) (hK : ∀ s t, K s t = -K t s) (i j : ι) (s t : τ) :
    (flavorCovariance K hK).form (Pi.single (i, s) 1) (Pi.single (j, t) 1) =
      if i = j then K s t else 0 := by
  exact Matrix.toBilin'_single (flavorMatrix K) (i, s) (j, t)

/-- The microscopic bilocal contraction formula, including its normalization factor.
Taking `scale = 1/N` gives precisely the exterior derivative used in the paper. -/
theorem flavor_collective_contraction [NoZeroDivisors R] [CharZero R]
    (K : τ → τ → R) (hK : ∀ s t, K s t = -K t s)
    (i : ι) (s u v : τ) (scale : R) :
    (flavorCovariance K hK).contraction (Pi.single (i, s) 1)
      (Covariance.collective scale
        (fun j : ι => Pi.single (j, u) 1) (fun j : ι => Pi.single (j, v) 1)) =
      scale • (K s u • field i v - K s v • field i u) := by
  rw [Covariance.contraction_collective]
  simp only [flavor_form]
  simp [field, ite_smul]

end Indexed
section ArbitraryIndices

variable {κ : Type*}

/-- Bilinear extension of a scalar kernel to finitely supported coefficient vectors.
The index type may be uncountable; only each individual vector has finite support. -/
def kernelForm (B : κ → κ → R) : LinearMap.BilinForm R (κ →₀ R) :=
  Finsupp.linearCombination R (fun i => Finsupp.linearCombination R (B i))

@[simp] theorem kernelForm_single (B : κ → κ → R) (i j : κ) (a b : R) :
    kernelForm B (Finsupp.single i a) (Finsupp.single j b) = a * b * B i j := by
  simp [kernelForm, mul_assoc]

theorem kernelForm_skew (B : κ → κ → R) (hB : ∀ i j, B i j = -B j i)
    (x y : κ →₀ R) : kernelForm B x y = -kernelForm B y x := by
  induction x using Finsupp.induction_linear with
  | zero => simp
  | add x z hx hz =>
    simp only [map_add, LinearMap.add_apply, hx, hz, neg_add]
  | single i a =>
    induction y using Finsupp.induction_linear with
    | zero => simp
    | add y z hy hz =>
      simp only [map_add, LinearMap.add_apply, hy, hz, neg_add]
    | single j b =>
      simp only [kernelForm_single]
      rw [hB i j]
      ring

/-- An exterior Wick covariance for any index set, including flavor × real time. -/
def covarianceOfKernel [NoZeroDivisors R] [CharZero R]
    (B : κ → κ → R) (hB : ∀ i j, B i j = -B j i) : Covariance R (κ →₀ R) where
  form := kernelForm B
  diagonal_zero x := CharZero.eq_neg_self_iff.mp (kernelForm_skew B hB x x)

/-- The two-point function of arbitrary-index exterior fields is the chosen kernel. -/
theorem kernel_expectation_two [NoZeroDivisors R] [CharZero R]
    (B : κ → κ → R) (hB : ∀ i j, B i j = -B j i) (i j : κ) :
    (covarianceOfKernel B hB).expectation
      (ExteriorAlgebra.ι R (Finsupp.single i 1) *
        ExteriorAlgebra.ι R (Finsupp.single j 1)) = B i j := by
  rw [Covariance.expectation_two]
  simp [covarianceOfKernel]

end ArbitraryIndices
end SYK.Wick
