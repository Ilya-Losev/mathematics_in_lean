import ContactWickEvaluation
import RealWardContacts

noncomputable section
namespace SYK.FundamentalWardContacts
open ThermalWick MvPolynomial ContinuumWickSeries
abbrev Polynomial (β : ℝ) := MvPolynomial (Time β × Time β) ℂ

def coordinateProduct {β : ℝ} (ps : List (Time β × Time β)) : Polynomial β :=
  (ps.map X).prod

def contactGenerator {β : ℝ} (s t : Time β) (p : Time β × Time β) : Polynomial β :=
  (Thermal.kernel β s.val p.1.val:ℂ) • X (p.2,t) -
    (Thermal.kernel β s.val p.2.val:ℂ) • X (p.1,t)

def contact {β : ℝ} (s t : Time β) : Derivation ℂ (Polynomial β) (Polynomial β) :=
  MvPolynomial.mkDerivation ℂ (contactGenerator s t)

@[simp] theorem contact_X {β : ℝ} (s t : Time β) (p : Time β × Time β) :
    contact s t (X p)=contactGenerator s t p := MvPolynomial.mkDerivation_X ..

@[simp] theorem contact_C {β : ℝ} (s t : Time β) (z : ℂ) : contact s t (C z)=0 :=
  Derivation.map_algebraMap _ z

/-- The polynomial derivation and genuine exterior contraction have the same
finite contact evaluation, for every linear polynomial functional. -/
theorem eval_contact_product {β : ℝ} (L : Polynomial β →ₗ[ℂ] ℂ) (s t : Time β)
    (ps qs : List (Time β × Time β)) :
    L (contact s t (coordinateProduct ps)*coordinateProduct qs) =
      contactValue (fun l => L (coordinateProduct l)) s t ps qs := by
  induction ps generalizing qs with
  | nil => simp [coordinateProduct,contactValue]
  | cons p ps ih =>
    have hp : coordinateProduct (p::ps)=X p*coordinateProduct ps := rfl
    rw [hp,Derivation.leibniz]
    simp only [smul_eq_mul,contact_X,add_mul,map_add]
    have htail : L (X p*contact s t (coordinateProduct ps)*coordinateProduct qs) =
        contactValue (fun l => L (coordinateProduct l)) s t ps (p::qs) := by
      rw [show X p*contact s t (coordinateProduct ps)*coordinateProduct qs =
        contact s t (coordinateProduct ps)*coordinateProduct (p::qs) by
          simp only [coordinateProduct,List.map_cons,List.prod_cons]; ring]
      exact ih _
    rw [htail]
    simp only [contactGenerator,contactValue,mul_sub,sub_mul,mul_smul_comm,smul_mul_assoc,
      map_sub,map_smul,smul_eq_mul]
    have he (a : Time β × Time β) :
        L (coordinateProduct ps*X a*coordinateProduct qs)=L (coordinateProduct (a::(ps++qs))) := by
      congr 1
      simp only [coordinateProduct,List.map_cons,List.map_append,List.prod_cons,List.prod_append]
      ring
    rw [he,he]
    ring

theorem eval_contact {β : ℝ} (L : Polynomial β →ₗ[ℂ] ℂ) (s t : Time β)
    (ps : List (Time β × Time β)) :
    L (contact s t (coordinateProduct ps)) =
      contactValue (fun l => L (coordinateProduct l)) s t ps [] := by
  simpa [coordinateProduct] using eval_contact_product L s t ps []

end SYK.FundamentalWardContacts
