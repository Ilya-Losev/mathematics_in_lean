import ContinuumWickSeries
import IntegralMomentSeries

/-!
# The concrete quartic insertion derivative of the continuum Wick series

A genuine product-measure decomposition proves the coefficient insertion
recurrence. Factorial bounds then justify both termwise differentiation and the
exchange with the inserted two-time integral. The separate operator
correspondence identifies these series with the microscopic thermal objects.
-/
set_option maxHeartbeats 1000000
noncomputable section
open MeasureTheory Set
open scoped NNReal Topology BigOperators
namespace SYK.ContinuumWickSeries
open ThermalWick WickVertexIntegrals

/-- The four equal bilocals supplied by a single quartic interaction. -/
def quarticPairs (β : ℝ) (hβ : 0 < β) (p : ℝ×ℝ) : List (Time β × Time β) :=
  List.replicate 4 (timeRepresentative β hβ p.1,timeRepresentative β hβ p.2)

@[simp] theorem quarticPairs_length (β : ℝ) (hβ : 0 < β) (p : ℝ×ℝ) :
    (quarticPairs β hβ p).length = 4 := by simp [quarticPairs]

@[simp] theorem interactionPairs_cons (β : ℝ) (hβ : 0 < β) {n : ℕ}
    (p : ℝ×ℝ) (u : Fin n → ℝ×ℝ) :
    interactionPairs β hβ (Fin.cons p u) = quarticPairs β hβ p ++ interactionPairs β hβ u := by
  simp [interactionPairs, quarticPairs, List.ofFn_succ]

@[simp] theorem coefficientIntegrand_cons (d : ℕ) (β : ℝ) (hβ : 0 < β)
    (ps : List (Time β × Time β)) {n : ℕ} (p : ℝ×ℝ) (u : Fin n → ℝ×ℝ) :
    coefficientIntegrand d β hβ ps (Fin.cons p u) =
      coefficientIntegrand d β hβ (ps ++ quarticPairs β hβ p) u := by
  simp [coefficientIntegrand, interactionPairs_cons, List.append_assoc]

/-- The first time pair and remaining pairs form the actual product measure. -/
theorem interaction_cons_measurePreserving (β : ℝ) (n : ℕ) :
    MeasurePreserving (fun p : (ℝ×ℝ) × (Fin n → ℝ×ℝ) => Fin.cons p.1 p.2)
      ((pairMeasure β).prod (interactionMeasure β n)) (interactionMeasure β (n+1)) := by
  have h := (measurePreserving_piFinSuccAbove
    (fun _ : Fin (n+1) => pairMeasure β) 0).symm
  simpa only [interactionMeasure, MeasurableEquiv.piFinSuccAbove_symm_apply,
    Fin.insertNthEquiv, Fin.insertNth_zero', Equiv.coe_fn_mk] using h

/-- Fubini in the true n+1-fold pair measure, with integrability proved for
the composed function rather than assumed as an independent condition. -/
theorem integral_interaction_succ (β : ℝ) (n : ℕ) (f : (Fin (n+1) → ℝ×ℝ) → ℂ)
    (hf : Integrable f (interactionMeasure β (n+1))) :
    (∫ u, f u ∂interactionMeasure β (n+1)) =
      ∫ p, ∫ u, f (Fin.cons p u) ∂interactionMeasure β n ∂pairMeasure β := by
  let e := (MeasurableEquiv.piFinSuccAbove (fun _ : Fin (n+1) => ℝ×ℝ) 0).symm
  have he : MeasurePreserving e ((pairMeasure β).prod (interactionMeasure β n))
      (interactionMeasure β (n+1)) :=
    (measurePreserving_piFinSuccAbove (fun _ : Fin (n+1) => pairMeasure β) 0).symm
  have hi := (he.integrable_comp_emb e.measurableEmbedding).mpr hf
  rw [← he.integral_comp' f]
  change (∫ z, (f ∘ e) z ∂(pairMeasure β).prod (interactionMeasure β n)) = _
  rw [integral_prod _ hi]
  simp only [Function.comp_apply, e, MeasurableEquiv.piFinSuccAbove_symm_apply, Fin.insertNthEquiv,
    Fin.insertNth_zero', Equiv.coe_fn_mk]

/-- Inserting one quartic factor is exactly shifting the factorial-free
interaction coefficient, with its true factor N/8. -/
theorem coefficient_succ_insertion (d : ℕ) (hd : 0 < d) (β : ℝ) (hβ : 0 < β)
    (ps : List (Time β × Time β)) (n : ℕ) :
    coefficient d β hβ ps (n+1) = (((2*d:ℕ):ℝ)/8) •
      ∫ p, coefficient d β hβ (ps ++ quarticPairs β hβ p) n ∂pairMeasure β := by
  unfold coefficient
  rw [integral_interaction_succ β n _ (coefficientIntegrand_integrable d hd β hβ ps (n+1))]
  simp only [coefficientIntegrand_cons, integral_smul, smul_smul, pow_succ']

/-- Inserted coefficients are measurable in the genuine two-time insertion. -/
theorem inserted_coefficient_measurable (d : ℕ) (β : ℝ) (hβ : 0 < β)
    (ps : List (Time β × Time β)) (n : ℕ) :
    Measurable (fun p : ℝ×ℝ => coefficient d β hβ (ps ++ quarticPairs β hβ p) n) := by
  have hm := (coefficientIntegrand_measurable d β hβ ps (n+1)).comp
    (interaction_cons_measurePreserving β n).measurable
  have hi := hm.stronglyMeasurable.integral_prod_right' (ν := interactionMeasure β n)
  simpa only [Function.comp_apply, coefficientIntegrand_cons, coefficient] using
    hi.measurable.const_smul ((((2*d:ℕ):ℝ)/8)^n)

/-- The actual scalar Wick numerator is differentiable, and its derivative is
the integrated inserted numerator. Every Fubini and summability input is proved. -/
theorem hasDerivAt_numerator_insertion (d : ℕ) (hd : 0 < d) (β : ℝ) (hβ : 0 < β)
    (ps : List (Time β × Time β)) (lam : ℝ) :
    HasDerivAt (numerator d β hβ ps)
      ((((2*d:ℕ):ℝ)/8) • ∫ p, numerator d β hβ (ps ++ quarticPairs β hβ p) lam
        ∂pairMeasure β) lam := by
  apply ExponentialMomentSeries.hasDerivAt_value_integrated_insertion
    (pairMeasure β) (coefficient d β hβ ps)
    (fun p => coefficient d β hβ (ps ++ quarticPairs β hβ p))
    ((1/2:ℝ)^ps.length) ((1/2:ℝ)^(ps.length+4))
    (((2*d:ℕ):ℝ)*β^2/128) (((2*d:ℕ):ℝ)/8) (by positivity) (by positivity)
    (coefficient_bound d hd β hβ ps)
    (fun n => (inserted_coefficient_measurable d β hβ ps n).aestronglyMeasurable)
    (fun p n => by simpa only [List.length_append, quarticPairs_length] using
      coefficient_bound d hd β hβ (ps ++ quarticPairs β hβ p) n)
    (coefficient_succ_insertion d hd β hβ ps) lam

end SYK.ContinuumWickSeries
