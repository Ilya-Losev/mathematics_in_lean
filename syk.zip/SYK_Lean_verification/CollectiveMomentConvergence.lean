import ThermalRPTransport
import ThermalWardLimit
import KernelConstructedSelection
import PhysicalUniqueness

/-!
# Physical selection and convergence of the actual collective moments

Microscopic Ward, reflection and translation obligations stay explicit. The
limiting functional and both Banach quotients are constructed from the actual
finite-size moments, and physical uniqueness is pointwise, not merely a.e.
-/

noncomputable section
open scoped BigOperators Topology NNReal
open MeasureTheory Filter Set
open SYK.WeightedKernelAlgebra SYK.MomentCompactness SYK.MomentLimit
open SYK.ThermalEndpointLift SYK.ThermalMomentTransport SYK.ThermalWeightedState
open SYK.ThermalWardLimit
open SYK.ThermalResidualState SYK.ThermalRPTransport SYK.KernelResidualAlgebra
open SYK.KernelFinalActions SYK.KernelQuotientAnalyticity SYK.KernelCoordinateGeneration

namespace SYK.CollectiveMomentConvergence

/-- Uniform subsequence principle, with no continuity or compactness
assumption on the functions themselves. -/
theorem tendstoUniformly_of_subsubsequences {X Y : Type*} [PseudoMetricSpace Y]
    (f : ℕ → X → Y) (g : X → Y)
    (h : ∀ φ : ℕ → ℕ, StrictMono φ → ∃ ψ : ℕ → ℕ, StrictMono ψ ∧
      TendstoUniformly (fun n => f (φ (ψ n))) g atTop) : TendstoUniformly f g atTop := by
  rw [Metric.tendstoUniformly_iff]
  intro ε hε
  by_contra hn
  have hf : ∃ᶠ n in atTop, ¬ ∀ x, dist (g x) (f n x) < ε := by
    simpa only [Filter.Frequently, not_not] using hn
  obtain ⟨φ, hφ, hbad⟩ := extraction_of_frequently_atTop hf
  obtain ⟨ψ, hψ, hconv⟩ := h φ hφ
  have he := Metric.tendstoUniformly_iff.mp hconv ε hε
  obtain ⟨n, hn⟩ := he.exists
  exact hbad (ψ n) hn

/-- Concrete finite-size selection tests on literal thermal polynomial
moments. These fields are microscopic premises, not properties built into a
limiting-state definition. -/
structure FiniteSelectionTests (β : ℝ) (hβ : 0 < β) (lam : ℝ≥0) (d : ℕ → ℕ) : Prop where
  even_real : ∀ n (P : MvPolynomial (HalfPair β) ℂ),
    (actualThermalPolynomial β hβ (d n) lam
      (reflectPolynomial β (halfPolynomial β P) * halfPolynomial β P)).im = 0
  even_nonnegative : ∀ n (P : MvPolynomial (HalfPair β) ℂ),
    0 ≤ (actualThermalPolynomial β hβ (d n) lam
      (reflectPolynomial β (halfPolynomial β P) * halfPolynomial β P)).re
  odd_nonnegative : ∀ n (P : MvPolynomial (HalfPair β) ℂ) (k : ℕ)
    (x : Fin k → Ioo (0:ℝ) (β/2)) (c : Fin k → ℂ),
    0 ≤ (actualThermalPolynomial β hβ (d n) lam
      (reflectPolynomial β (halfPolynomial β P) * halfPolynomial β P *
        hankelPolynomial β (fun i => x i) c)).re
  translation : ∀ n u P,
    actualThermalPolynomial β hβ (d n) lam (translatePolynomial u P) =
      actualThermalPolynomial β hβ (d n) lam P

/-- Finite microscopic tests survive taking any subsequence, by evaluation. -/
theorem FiniteSelectionTests.comp {β : ℝ} {hβ : 0 < β} {lam : ℝ≥0} {d : ℕ → ℕ}
    (h : FiniteSelectionTests β hβ lam d) (φ : ℕ → ℕ) :
    FiniteSelectionTests β hβ lam (d ∘ φ) :=
  ⟨fun n => h.even_real (φ n), fun n => h.even_nonnegative (φ n),
    fun n => h.odd_nonnegative (φ n), fun n => h.translation (φ n)⟩

/-- A subsequential limit of the actual finite-size moments, satisfying the
explicit limiting inserted Ward equations, is a sharply bounded physical
solution and its moments factorize uniformly at every degree. -/
theorem selected_of_uniform_thermal_limit (β : ℝ) (hβ : 0 < β) (lam : ℝ≥0)
    (d : ℕ → ℕ) (hd : ∀ n, 0 < d n) (G : ∀ k, EndpointCube β k → ℂ)
    (hG : ∀ k, TendstoUniformly
      (fun n => functionalCenteredMoment (actualCorrectedPolynomial β hβ (d n) lam)) (G k) atTop)
    (hleft : LeftWard β (lam : ℝ) (polynomialState β hβ G))
    (hright : RightWard β (lam : ℝ) (polynomialState β hβ G))
    (htests : FiniteSelectionTests β hβ lam d) :
    ∃ g : ℝ → ℝ, Continuum.PhysicalSolution β lam g ∧ (∀ s, |g s| ≤ 1/2) ∧
      ∀ k, TendstoUniformly
        (fun n (p : Fin k → Endpoint) => actualThermalPolynomial β hβ (d n) lam (∏ i, MvPolynomial.X (p i)))
        (fun p => ∏ i, (g ((p i).1-(p i).2) : ℂ)) atTop := by
  let K : ℝ := (lam : ℝ)*β*(1/2:ℝ)^4+1
  have hK : 0 < K := by dsimp [K]; positivity
  have hKlarge : (lam : ℝ)*β*(1/2:ℝ)^4 ≤ K := by dsimp [K]; linarith
  have hhalf : (0 : ℝ) < 1/2 := by norm_num
  let hrep := polynomialState_replacement β hβ lam d hd G hG hleft hright
  letI : Nontrivial (FirstAlgebra (1/2) K hhalf hK β) :=
    regularityAlgebra_nontrivial β hβ lam d hd G hG K hK hKlarge hrep
  letI : Nontrivial (FinalAlgebra (1/2) K hhalf hK β hβ (lam : ℝ)) :=
    finalAlgebra_nontrivial β hβ lam d hd G hG K hK hKlarge hrep hleft hright
  let L := finalState β hβ lam d hd G hG K hK hKlarge hrep hleft hright
  obtain ⟨g, hg, hfactor⟩ := KernelConstructedSelection.exists_physical_factorization
    (1/2) K hhalf hK β hβ lam L
    (finalState_one β hβ lam d hd G hG K hK hKlarge hrep hleft hright)
    (finalState_half_real β hβ lam d hd G hG K hK hKlarge hrep hleft hright htests.even_real)
    (finalState_half_nonnegative β hβ lam d hd G hG K hK hKlarge hrep hleft hright htests.even_nonnegative)
    (finalState_translation_tests β hβ lam d hd G hG K hK hKlarge hrep hleft hright htests.translation)
    (finalState_half_odd β hβ lam d hd G hG K hK hKlarge hrep hleft hright htests.odd_nonnegative)
  dsimp only [L] at hfactor
  refine ⟨g, hg, ?_, ?_⟩
  · intro s
    have he := hfactor 1 (fun _ => (s,0))
    have htuple := finalState_tuple β hβ lam d hd G hG K hK hKlarge hrep hleft hright
      (fun _ : Fin 1 => (s,0))
    have hval : polynomialState β hβ G (MvPolynomial.X (s,0)) = (g s : ℂ) := by
      simpa only [Fin.prod_univ_one, finalCoordinate_eq_kernel, sub_zero] using htuple.symm.trans he
    have hb := polynomialState_plain_bound β hβ lam d hd G hG [(s,0)]
    simpa only [SYK.MixedIncrement.coordinateProduct, List.map_cons, List.map_nil,
      List.prod_cons, List.prod_nil, mul_one, List.length_cons, List.length_nil,
      Nat.zero_add, pow_one, hval, Complex.norm_real, Real.norm_eq_abs] using hb
  · intro k
    have hc := actual_moments_to_finalState β hβ lam d hd G hG K hK hKlarge hrep hleft hright k
    simpa only [finalCoordinate_eq_kernel, hfactor] using hc

/-- Every cofinal sequence of positive flavor half-counts has a further
subsequence converging uniformly in every degree to a physical factorization.
Only literal finite microscopic Ward/RP/translation premises remain. -/
theorem exists_physical_subsequence (β : ℝ) (hβ : 0 < β) (lam : ℝ≥0)
    (d : ℕ → ℕ) (hd : ∀ n, 0 < d n) (hdtop : Tendsto d atTop atTop)
    (hward : FiniteWardControl β hβ lam d) (htests : FiniteSelectionTests β hβ lam d) :
    ∃ (φ : ℕ → ℕ) (g : ℝ → ℝ), StrictMono φ ∧ Continuum.PhysicalSolution β lam g ∧
      (∀ s, |g s| ≤ 1/2) ∧ ∀ k, TendstoUniformly
        (fun n (p : Fin k → Endpoint) => actualThermalPolynomial β hβ (d (φ n)) lam (∏ i, MvPolynomial.X (p i)))
        (fun p => ∏ i, (g ((p i).1-(p i).2) : ℂ)) atTop := by
  obtain ⟨φ, G, hφ, hG, _hLip, _hBound, _hPoly, _hTuple, _hUnit, _hNorm⟩ :=
    exists_actual_thermal_limit β hβ lam d hd
      (fun k => (k:ℝ)*(lam:ℝ)*β/8) (fun k => by positivity)
      (fun k n => ((k:ℝ)*((k-1:ℕ):ℝ))/(d n:ℝ))
      (fun k => contact_scale_tendsto d hdtop _)
      (actual_centered_modulus β hβ lam d hd hward)
  have hleft := leftWard_of_finite β hβ lam (d ∘ φ) (fun n => hd (φ n)) G hG
    (hdtop.comp hφ.tendsto_atTop) (hward.comp φ)
  have hright := rightWard_of_finite β hβ lam (d ∘ φ) (fun n => hd (φ n)) G hG
    (hdtop.comp hφ.tendsto_atTop) (hward.comp φ)
  obtain ⟨g, hg, hb, hconv⟩ := selected_of_uniform_thermal_limit β hβ lam (d ∘ φ)
    (fun n => hd (φ n)) G hG hleft hright (htests.comp φ)
  exact ⟨φ, g, hφ, hg, hb, hconv⟩

/-- Physical uniqueness upgrades compactness and spectral selection to full
uniform convergence of the actual finite-size thermal moments, without
choosing a subsequence in the conclusion. -/
theorem exists_physical_full_convergence (β : ℝ) (hβ : 0 < β) (lam : ℝ≥0)
    (d : ℕ → ℕ) (hd : ∀ n, 0 < d n) (hdtop : Tendsto d atTop atTop)
    (hward : FiniteWardControl β hβ lam d) (htests : FiniteSelectionTests β hβ lam d) :
    ∃ g : ℝ → ℝ, Continuum.PhysicalSolution β lam g ∧ (∀ s, |g s| ≤ 1/2) ∧
      ∀ k, TendstoUniformly
        (fun n (p : Fin k → Endpoint) => actualThermalPolynomial β hβ (d n) lam (∏ i, MvPolynomial.X (p i)))
        (fun p => ∏ i, (g ((p i).1-(p i).2) : ℂ)) atTop := by
  letI : Fact (0 < β) := ⟨hβ⟩
  obtain ⟨φ₀, g, _hφ₀, hg, hb, _hconv₀⟩ :=
    exists_physical_subsequence β hβ lam d hd hdtop hward htests
  refine ⟨g, hg, hb, fun k => ?_⟩
  apply tendstoUniformly_of_subsubsequences
  intro φ hφ
  obtain ⟨ψ, g', hψ, hg', _hb', hc⟩ := exists_physical_subsequence β hβ lam (d ∘ φ)
    (fun n => hd (φ n)) (hdtop.comp hφ.tendsto_atTop) (hward.comp φ) (htests.comp φ)
  have he : g' = g := Continuum.physical_unique β lam g' g hg' hg
  subst g'
  exact ⟨ψ, hψ, hc k⟩

/-- On the fundamental half-open interval, thermal reduction is exactly the
literal finite-dimensional collective moment, with no seam convention changed. -/
theorem actualThermal_tuple_eq_raw (β : ℝ) (hβ : 0 < β) (lam : ℝ≥0) (d : ℕ)
    {k : ℕ} (p : Fin k → Endpoint) (hp : ∀ i, (p i).1 ∈ Ico 0 β ∧ (p i).2 ∈ Ico 0 β) :
    actualThermalPolynomial β hβ d lam (∏ i, MvPolynomial.X (p i)) =
      Interacting.collectiveMoment d β lam p := by
  rw [actualThermalPolynomial_tuple]
  have hs : (∏ i, pairSign β hβ (p i)) = 1 := by
    simp only [pairSign, endpointSign_of_mem β hβ (hp _).1,
      endpointSign_of_mem β hβ (hp _).2, one_mul, Finset.prod_const_one]
  rw [hs, one_mul]
  congr 1
  funext i
  simp only [representative_of_mem β hβ (hp i).1, representative_of_mem β hβ (hp i).2, Prod.eta]

/-- Uniform convergence for the literal actual moments on the fundamental
half-open thermal domain, including all internal coincidence loci. -/
theorem raw_moments_converge_of_thermal {β : ℝ} (hβ : 0 < β) (lam : ℝ≥0)
    (d : ℕ → ℕ) (g : ℝ → ℝ) (k : ℕ)
    (hconv : TendstoUniformly
      (fun n (p : Fin k → Endpoint) => actualThermalPolynomial β hβ (d n) lam (∏ i, MvPolynomial.X (p i)))
      (fun p => ∏ i, (g ((p i).1-(p i).2) : ℂ)) atTop) :
    TendstoUniformly
      (fun n (p : Fin k → Ico (0:ℝ) β × Ico (0:ℝ) β) =>
        Interacting.collectiveMoment (d n) β lam (fun i => ((p i).1.val,(p i).2.val)))
      (fun p => ∏ i, (g ((p i).1.val-(p i).2.val) : ℂ)) atTop := by
  have h := hconv.comp (fun p : Fin k → Ico (0:ℝ) β × Ico (0:ℝ) β =>
    fun i => ((p i).1.val,(p i).2.val))
  have he (n : ℕ) (p : Fin k → Ico (0:ℝ) β × Ico (0:ℝ) β) :
      actualThermalPolynomial β hβ (d n) lam
        (∏ i, MvPolynomial.X ((p i).1.val,(p i).2.val)) =
      Interacting.collectiveMoment (d n) β lam (fun i => ((p i).1.val,(p i).2.val)) :=
    actualThermal_tuple_eq_raw β hβ lam (d n) _ (fun i => ⟨(p i).1.property,(p i).2.property⟩)
  simpa only [Function.comp_def, he] using h

/-- Removing the exceptional zero-flavor term does not change uniform convergence. -/
theorem tendstoUniformly_of_succ {X Y : Type*} [PseudoMetricSpace Y]
    (f : ℕ → X → Y) (g : X → Y)
    (h : TendstoUniformly (fun n => f (n+1)) g atTop) : TendstoUniformly f g atTop := by
  rw [Metric.tendstoUniformly_iff] at h ⊢
  intro ε hε
  obtain ⟨N, hN⟩ := eventually_atTop.mp (h ε hε)
  refine eventually_atTop.mpr ⟨N+1, fun n hn x => ?_⟩
  have hn1 : 1 ≤ n := by omega
  have hh := hN (n-1) (by omega) x
  simpa only [Nat.sub_add_cancel hn1] using hh

/-- Existence of the physical scalar solution and full convergence along
the literal finite SYK flavor half-counts d=0,1,2,... . The explicit premises
are finite Ward residuals and finite RP/translation tests for d≥1. -/
theorem exists_physical_actual_moment_limit (β : ℝ) (hβ : 0 < β) (lam : ℝ≥0)
    (hward : FiniteWardControl β hβ lam (fun n => n+1))
    (htests : FiniteSelectionTests β hβ lam (fun n => n+1)) :
    ∃ g : ℝ → ℝ, Continuum.PhysicalSolution β lam g ∧ (∀ s, |g s| ≤ 1/2) ∧
      (∀ k, TendstoUniformly
        (fun d (p : Fin k → Endpoint) => actualThermalPolynomial β hβ d lam (∏ i, MvPolynomial.X (p i)))
        (fun p => ∏ i, (g ((p i).1-(p i).2) : ℂ)) atTop) ∧
      (∀ k, TendstoUniformly
        (fun d (p : Fin k → Ico (0:ℝ) β × Ico (0:ℝ) β) =>
          Interacting.collectiveMoment d β lam (fun i => ((p i).1.val,(p i).2.val)))
        (fun p => ∏ i, (g ((p i).1.val-(p i).2.val) : ℂ)) atTop) := by
  obtain ⟨g, hg, hb, hconv⟩ := exists_physical_full_convergence β hβ lam (fun n => n+1)
    (fun n => Nat.succ_pos n) (tendsto_add_atTop_nat 1) hward htests
  have hall (k) := tendstoUniformly_of_succ
    (fun d (p : Fin k → Endpoint) => actualThermalPolynomial β hβ d lam (∏ i, MvPolynomial.X (p i)))
    (fun p => ∏ i, (g ((p i).1-(p i).2) : ℂ)) (hconv k)
  exact ⟨g, hg, hb, hall, fun k => raw_moments_converge_of_thermal hβ lam id g k (hall k)⟩

end SYK.CollectiveMomentConvergence
