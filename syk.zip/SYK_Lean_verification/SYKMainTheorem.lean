import ContinuumSYKCorollaries
import ActualCorrespondenceConsequences
import IntegratedWickWard
import ActualWickCorrespondence

/-!
# Final microscopic-to-continuum assembly

The actual inserted operator/Wick correspondence and the exact finite Ward
identity are both proved from the concrete model. Their composition gives an
unconditional continuum theorem for each positive inverse temperature, all
nonnegative variance parameters, and every real disorder scale. No microscopic
identity, limiting state, physical solution, response, or convergence result is
left as an assumption in `continuum_free_energy`.
-/
noncomputable section
open MeasureTheory
open scoped NNReal
namespace SYK.SYKMainTheorem
open ThermalWick ContinuumWickSeries ContinuumSYKMain

/-- The actual inserted list correspondence, including every external collision
and repeated endpoint, closes both moment and pressure branches at once. -/
theorem exists_main_of_list_correspondence (β : ℝ) (hβ : 0 < β)
    (hMoment : ∀ d : ℕ, 0 < d → ∀ lam : ℝ≥0, ∀ ps : List (Time β × Time β),
      normalizedMoment d β hβ ps (lam : ℝ) =
        Interacting.collectiveMoment d β lam
          (fun i => ((ps.get i).1.val, (ps.get i).2.val))) :
    ∃ g : ℝ≥0 → ℝ → ℝ, @MainConclusion β ⟨hβ⟩ g := by
  letI : Fact (0 < β) := ⟨hβ⟩
  apply exists_main_of_microscopic_identities β
  · intro lam d hd
    apply ActualWickWard.exact_left_of_wick_identities d hd β hβ lam (hMoment d hd lam)
    intro ps s t
    exact numerator_ward d hd β hβ ps s t (lam : ℝ)
  · intro d hd l hl p
    have h := ActualCorrespondenceConsequences.fourth_of_list_correspondence d hβ l.toNNReal
      (hMoment d hd l.toNNReal) p
    simpa only [Real.coe_toNNReal _ hl.le] using h

/-- The continuum SYK theorem for every fixed positive inverse temperature.
Its conclusion contains the unique physical solution at every nonnegative
coupling, full actual moment convergence, both actual pressure limits, sharp
pointwise regularity and jump limits, and the positive ordinary Fredholm
determinant action. The real-scale, free-energy, arbitrary-realization, and
literal complex integral-operator statements are the proved `MainConclusion`
corollaries. There are no unresolved mathematical hypotheses. -/
theorem continuum_free_energy (β : ℝ) (hβ : 0 < β) :
    ∃ g : ℝ≥0 → ℝ → ℝ, @MainConclusion β ⟨hβ⟩ g := by
  apply exists_main_of_list_correspondence β hβ
  intro d hd lam ps
  exact ActualWickCorrespondence.normalizedMoment_eq_collectiveMoment d hd hβ lam ps

/-- Pointwise unique physical solution, not just uniqueness almost everywhere,
including the exact midpoint convention on every thermal lift. -/
theorem existsUnique_physical_solution (β : ℝ) (hβ : 0 < β) (lam : ℝ≥0) :
    ∃! g : ℝ → ℝ, Continuum.PhysicalSolution β lam g := by
  letI : Fact (0 < β) := ⟨hβ⟩
  obtain ⟨g,hg⟩ := continuum_free_energy β hβ
  exact ⟨g lam, (hg.solution lam).physical, (hg.solution lam).unique⟩

end SYK.SYKMainTheorem
