import GaussianCoefficientIdentity
import Mathlib.Algebra.MvPolynomial.PDeriv
import Mathlib.LinearAlgebra.Finsupp.LSum

/-! # Coefficientwise Gaussian averaging of commuting symbols -/
noncomputable section
open scoped BigOperators NNReal
open MvPolynomial MeasureTheory
namespace SYK.GaussianCoefficient
variable {ι : Type*} [Fintype ι] [DecidableEq ι]

/-- The actual Gaussian monomial weight. -/
def monomialMoment (v : ℝ≥0) (n : ι →₀ ℕ) : ℝ := ∏ i, moment v (n i)

omit [DecidableEq ι] in
@[simp] theorem monomialMoment_zero (v : ℝ≥0) : monomialMoment (ι := ι) v 0 = 1 := by
  simp [monomialMoment]

/-- Discrete Stein identity for genuine product-monomial integrals. -/
theorem monomialMoment_step (v : ℝ≥0) (n : ι →₀ ℕ) (i : ι) :
    monomialMoment v (Finsupp.single i 1 + n) =
      (v : ℝ) * (n i) * monomialMoment v (n - Finsupp.single i 1) := by
  have hprod (s : ι →₀ ℕ) : monomialMoment v s =
      moment v (s i) * ∏ j ∈ Finset.univ.erase i, moment v (s j) :=
    (Finset.mul_prod_erase _ _ (Finset.mem_univ i)).symm
  rw [hprod, hprod]
  have he : (∏ j ∈ Finset.univ.erase i, moment v ((Finsupp.single i 1 + n : ι →₀ ℕ) j)) =
      ∏ j ∈ Finset.univ.erase i, moment v ((n-Finsupp.single i 1 : ι →₀ ℕ) j) := by
    apply Finset.prod_congr rfl
    intro j hj
    have hji := (Finset.mem_erase.mp hj).1
    simp [Finsupp.single_apply, hji, Ne.symm hji]
  rw [he]
  simp only [Finsupp.add_apply, Finsupp.single_eq_same, Finsupp.tsub_apply]
  have hm : moment v (1+n i) = (v : ℝ) * (n i) * moment v (n i-1) := by
    cases hn : n i with
    | zero => simp
    | succ k =>
      simp only [Nat.add_sub_cancel, Nat.cast_add, Nat.cast_one]
      rw [show 1+(k+1) = k+2 by omega, moment_add_two]
  rw [hm]
  ring

variable (A : Type*) [CommRing A] [Algebra ℝ A]

/-- Integrate the disorder variables coefficientwise, leaving arbitrary
commuting algebra coefficients untouched. -/
def average (v : ℝ≥0) : MvPolynomial ι A →ₗ[A] A :=
  Finsupp.lsum A (fun n => (algebraMap ℝ A (monomialMoment v n)) • LinearMap.id)

omit [DecidableEq ι] in
@[simp] theorem average_monomial (v : ℝ≥0) (n : ι →₀ ℕ) (a : A) :
    average A v (monomial n a) = algebraMap ℝ A (monomialMoment v n) * a := by
  change Finsupp.lsum A _ (Finsupp.single n a) = _
  rw [Finsupp.lsum_single]
  rfl

omit [DecidableEq ι] in
@[simp] theorem average_C (v : ℝ≥0) (a : A) :
    average (ι := ι) A v (C a) = a := by
  rw [C_apply, average_monomial, monomialMoment_zero, map_one, one_mul]

omit [DecidableEq ι] in
theorem average_C_mul (v : ℝ≥0) (a : A) (p : MvPolynomial ι A) :
    average A v (C a * p) = a * average A v p := by
  rw [C_mul', map_smul, smul_eq_mul]

/-- Algebraic Stein identity, whose coefficients are the actual Gaussian
integrals proved above. -/
theorem average_X_mul (v : ℝ≥0) (i : ι) (p : MvPolynomial ι A) :
    average A v (X i * p) = algebraMap ℝ A v * average A v (pderiv i p) := by
  induction p using MvPolynomial.induction_on' with
  | monomial n a =>
    rw [X, monomial_mul, one_mul, average_monomial, pderiv_monomial, average_monomial,
      monomialMoment_step]
    simp only [map_mul, map_natCast]
    ring
  | add p q hp hq => simp [mul_add, hp, hq]

/-- A linear combination of the independent formal Gaussian variables. -/
def linearSymbol (x : ι → A) : MvPolynomial ι A := ∑ i, C (x i) * X i

omit [Algebra ℝ A] in
@[simp] theorem pderiv_linearSymbol (x : ι → A) (i : ι) :
    pderiv i (linearSymbol A x) = C (x i) := by
  simp [linearSymbol, pderiv_C_mul, Pi.single_apply, Finset.sum_ite_eq']

/-- Gaussian averaging converts the linear-symbol power recurrence into
multiplication by the quadratic symbol, with its exact variance. -/
theorem average_linearSymbol_add_two (v : ℝ≥0) (x : ι → A) (n : ℕ) :
    average A v ((linearSymbol A x)^(n+2)) =
      (n+1 : A) * (algebraMap ℝ A v * ∑ i, (x i)^2) *
        average A v ((linearSymbol A x)^n) := by
  rw [pow_succ', linearSymbol, Finset.sum_mul, map_sum]
  simp only [mul_assoc, average_C_mul, average_X_mul, pderiv_pow,
    Nat.add_sub_cancel, pderiv_linearSymbol]
  have he (i : ι) : average A v ((n+1 : MvPolynomial ι A) *
      (linearSymbol A x)^n * C (x i)) =
      (n+1 : A) * x i * average A v ((linearSymbol A x)^n) := by
    rw [show (n+1 : MvPolynomial ι A) = C (n+1 : A) by simp]
    rw [mul_comm _ (C (x i)), ← mul_assoc, ← map_mul, average_C_mul]
    ring
  simp only [Nat.cast_add, Nat.cast_one]
  change (∑ i, x i * (algebraMap ℝ A v * average A v
    ((n+1 : MvPolynomial ι A) * ((linearSymbol A x)^n * pderiv i (linearSymbol A x))))) = _
  simp only [pderiv_linearSymbol, ← mul_assoc, he]
  simp only [Finset.mul_sum, Finset.sum_mul]
  apply Finset.sum_congr rfl
  intro i _
  dsimp only [linearSymbol]
  ring


@[simp] theorem average_linearSymbol (v : ℝ≥0) (x : ι → A) :
    average A v (linearSymbol A x) = 0 := by
  have hx (i : ι) : average A v (X i) = 0 := by
    simpa using average_X_mul A v i (1 : MvPolynomial ι A)
  simp [linearSymbol, average_C_mul, hx]

/-- Odd coefficients of the actual coefficientwise Gaussian average vanish. -/
theorem average_linearSymbol_odd (v : ℝ≥0) (x : ι → A) (k : ℕ) :
    average A v ((linearSymbol A x)^(2*k+1)) = 0 := by
  induction k with
  | zero => simp
  | succ k ih =>
    rw [show 2*(k+1)+1 = (2*k+1)+2 by omega, average_linearSymbol_add_two, ih, mul_zero]

/-- Even coefficients are powers of the quadratic symbol with the genuine
scalar Gaussian moment coefficient. -/
theorem average_linearSymbol_even (v : ℝ≥0) (x : ι → A) (k : ℕ) :
    average A v ((linearSymbol A x)^(2*k)) =
      algebraMap ℝ A (moment 1 (2*k)) * (algebraMap ℝ A v * ∑ i, (x i)^2)^k := by
  induction k with
  | zero => simpa using average_C (ι := ι) A v 1
  | succ k ih =>
    rw [show 2*(k+1) = 2*k+2 by omega, average_linearSymbol_add_two, ih,
      moment_add_two]
    simp only [NNReal.coe_one, one_mul, map_mul, map_natCast, map_add, map_one]
    rw [pow_succ]
    ring


/-- The exact coefficient identity for Gaussian averaging of the exponential
of a linear combination of commuting symbols. -/
theorem average_exponential_coefficient (v : ℝ≥0) (x : ι → A) (k : ℕ) :
    (1 / ((2*k).factorial : ℝ)) • average A v ((linearSymbol A x)^(2*k)) =
      (1 / (k.factorial : ℝ)) • (((v : ℝ)/2) • ∑ i, (x i)^2)^k := by
  rw [average_linearSymbol_even, ← Algebra.smul_def]
  rw [smul_smul]
  have hc := moment_even_div_factorial 1 k
  simp only [NNReal.coe_one] at hc
  rw [show (1 / ((2*k).factorial : ℝ)) * moment 1 (2*k) =
      moment 1 (2*k) / ((2*k).factorial : ℝ) by ring, hc]
  rw [← Algebra.smul_def, smul_pow, smul_pow, smul_smul, smul_smul]
  congr 1
  rw [div_pow, div_pow]
  ring


/-- Evaluate the independent disorder variables at their actual real values. -/
def evaluateReal (p : MvPolynomial ι A) (j : ι → ℝ) : A :=
  MvPolynomial.eval₂ (RingHom.id A) (fun i => algebraMap ℝ A (j i)) p

omit [DecidableEq ι] in
@[simp] theorem evaluateReal_monomial (n : ι →₀ ℕ) (a : A) (j : ι → ℝ) :
    evaluateReal A (monomial n a) j = (∏ i, (j i)^(n i)) • a := by
  rw [evaluateReal, eval₂_monomial, Finsupp.prod_fintype _ _ (fun _ => by simp)]
  simp only [RingHom.id_apply, ← map_pow, ← map_prod, Algebra.smul_def]
  exact mul_comm _ _

omit [Fintype ι] [DecidableEq ι] in
@[simp] theorem evaluateReal_add (p q : MvPolynomial ι A) (j : ι → ℝ) :
    evaluateReal A (p+q) j = evaluateReal A p j + evaluateReal A q j := by
  simp [evaluateReal]

omit [DecidableEq ι] in
/-- Every scalar functional applied to a disorder-evaluated polynomial is
integrable. No norm or topology on the symbolic algebra is needed. -/
theorem integrable_functional_evaluate (v : ℝ≥0) (φ : A →ₗ[ℝ] ℂ) (p : MvPolynomial ι A) :
    Integrable (fun j => φ (evaluateReal A p j)) (ProductGaussianMGF.law ι v) := by
  induction p using MvPolynomial.induction_on' with
  | monomial n a =>
    simpa using (integrable_monomial ι v n).smul_const (φ a)
  | add p q hp hq =>
    simpa using hp.add hq

omit [DecidableEq ι] in
/-- The coefficientwise averaging map is identified with an actual Gaussian
integral after every scalar linear functional. -/
theorem integral_functional_evaluate (v : ℝ≥0) (φ : A →ₗ[ℝ] ℂ) (p : MvPolynomial ι A) :
    (∫ j, φ (evaluateReal A p j) ∂ProductGaussianMGF.law ι v) = φ (average A v p) := by
  induction p using MvPolynomial.induction_on' with
  | monomial n a =>
    simp only [evaluateReal_monomial, map_smul, integral_smul_const, integral_monomial,
      average_monomial, ← Algebra.smul_def, map_smul, monomialMoment]
  | add p q hp hq =>
    simp only [evaluateReal_add, map_add]
    rw [integral_add (integrable_functional_evaluate A v φ p)
      (integrable_functional_evaluate A v φ q), hp, hq]

omit [DecidableEq ι] in
@[simp] theorem evaluateReal_linearSymbol (x : ι → A) (j : ι → ℝ) :
    evaluateReal A (linearSymbol A x) j = ∑ i, (j i) • x i := by
  simp [evaluateReal, linearSymbol, Algebra.smul_def, mul_comm]

omit [Fintype ι] [DecidableEq ι] in
@[simp] theorem evaluateReal_pow (p : MvPolynomial ι A) (n : ℕ) (j : ι → ℝ) :
    evaluateReal A (p^n) j = (evaluateReal A p j)^n := by
  simp [evaluateReal, eval₂_pow]

/-- Actual Gaussian integration of an odd exponential coefficient vanishes. -/
theorem integral_linearSymbol_odd (v : ℝ≥0) (x : ι → A) (φ : A →ₗ[ℝ] ℂ) (k : ℕ) :
    (∫ j, φ ((∑ i, (j i) • x i)^(2*k+1)) ∂ProductGaussianMGF.law ι v) = 0 := by
  have h := integral_functional_evaluate A v φ ((linearSymbol A x)^(2*k+1))
  simpa [average_linearSymbol_odd] using h

/-- Actual Gaussian integration of each even exponential coefficient is
exactly the corresponding quadratic-exponential coefficient. -/
theorem integral_exponential_coefficient (v : ℝ≥0) (x : ι → A) (φ : A →ₗ[ℝ] ℂ) (k : ℕ) :
    (1 / ((2*k).factorial : ℝ)) •
      (∫ j, φ ((∑ i, (j i) • x i)^(2*k)) ∂ProductGaussianMGF.law ι v) =
      (1 / (k.factorial : ℝ)) • φ ((((v : ℝ)/2) • ∑ i, (x i)^2)^k) := by
  have hi := integral_functional_evaluate A v φ ((linearSymbol A x)^(2*k))
  simp only [evaluateReal_pow, evaluateReal_linearSymbol] at hi
  rw [hi, ← map_smul, average_exponential_coefficient, map_smul]


omit [DecidableEq ι] in
/-- Every actual scalar coefficient entering the exponential identity is
integrable, independently of any later summation or time integration. -/
theorem integrable_linearSymbol_power (v : ℝ≥0) (x : ι → A) (φ : A →ₗ[ℝ] ℂ) (n : ℕ) :
    Integrable (fun j => φ ((∑ i, (j i) • x i)^n)) (ProductGaussianMGF.law ι v) := by
  simpa using integrable_functional_evaluate A v φ ((linearSymbol A x)^n)

/-- Exact microscopic normalization: variance 6λ/N³ becomes the coefficient
3λ/N³ in the quadratic exponential, including N=0 and λ=0. -/
theorem disorder_exponential_coefficient (N : ℕ) (lam : ℝ≥0)
    (x : ι → A) (φ : A →ₗ[ℝ] ℂ) (k : ℕ) :
    (1 / ((2*k).factorial : ℝ)) •
      (∫ j, φ ((∑ i, (j i) • x i)^(2*k)) ∂GaussianDisorder.law ι N lam) =
      (1 / (k.factorial : ℝ)) •
        φ (((3 * (lam : ℝ) / (N : ℝ)^3) • ∑ i, (x i)^2)^k) := by
  have hv : ((GaussianDisorder.variance N lam : ℝ) / 2) = 3 * (lam : ℝ) / (N : ℝ)^3 := by
    simp only [GaussianDisorder.variance, NNReal.coe_div, NNReal.coe_mul,
      NNReal.coe_pow, NNReal.coe_natCast, NNReal.coe_ofNat]
    ring
  simpa only [GaussianDisorder.law, ProductGaussianMGF.law, hv] using
    integral_exponential_coefficient A (GaussianDisorder.variance N lam) x φ k

/-- Direct formal-variable instance for coefficient functionals on complex
multivariate polynomials, the interface used by integrated Wick vertices. -/
theorem disorder_polynomial_coefficient (N : ℕ) (lam : ℝ≥0)
    (φ : MvPolynomial ι ℂ →ₗ[ℂ] ℂ) (k : ℕ) :
    (1 / ((2*k).factorial : ℝ)) •
      (∫ j, φ ((∑ i, (j i : ℝ) • (X i : MvPolynomial ι ℂ))^(2*k))
        ∂GaussianDisorder.law ι N lam) =
      (1 / (k.factorial : ℝ)) •
        φ (((3 * (lam : ℝ) / (N : ℝ)^3) • ∑ i, (X i : MvPolynomial ι ℂ)^2)^k) :=
  disorder_exponential_coefficient (MvPolynomial ι ℂ) N lam X (φ.restrictScalars ℝ) k

end SYK.GaussianCoefficient
