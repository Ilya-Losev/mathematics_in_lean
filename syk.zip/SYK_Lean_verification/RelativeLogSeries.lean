import PhysicalSelection
import Mathlib.Analysis.SpecialFunctions.Log.Summable

/-!
Convergent scalar logarithmic series and positive products for the relative
spectrum. The identification with the ordinary operator Fredholm determinant
is a separate obligation; this file does not rename a scalar product as that
operator theorem.
-/
noncomputable section
open scoped BigOperators
namespace SYK.Continuum

variable {ι : Type*}

def logAction (a : ι → ℝ) : ℝ := ∑' i, Real.log (1 + a i)

def relativeProduct (a : ι → ℝ) : ℝ := ∏' i, (1 + a i)

theorem logAction_summable (a : ι → ℝ) (ha : Summable a) :
    Summable (fun i => Real.log (1+a i)) := Real.summable_log_one_add_of_summable ha

theorem relativeProduct_eq_exp (a : ι → ℝ) (ha : Summable a)
    (hp : ∀ i, 0 < 1+a i) : relativeProduct a = Real.exp (logAction a) :=
  (Real.rexp_tsum_eq_tprod hp (logAction_summable a ha)).symm

theorem relativeProduct_pos (a : ι → ℝ) (ha : Summable a)
    (hp : ∀ i, 0 < 1+a i) : 0 < relativeProduct a := by
  rw [relativeProduct_eq_exp a ha hp]
  exact Real.exp_pos _

theorem log_relativeProduct (a : ι → ℝ) (ha : Summable a)
    (hp : ∀ i, 0 < 1+a i) : Real.log (relativeProduct a) = logAction a := by
  rw [relativeProduct_eq_exp a ha hp, Real.log_exp]

/-- The precise tangent bound used to compare determinant actions. -/
theorem log_one_add_tangent (a b : ℝ) (ha : 0 < 1+a) (hb : 0 < 1+b) :
    Real.log (1+b)-Real.log (1+a) ≤ (b-a)/(1+a) := by
  have h := Real.log_le_sub_one_of_pos (div_pos hb ha)
  rw [Real.log_div hb.ne' ha.ne'] at h
  convert h using 1
  field_simp
  <;> ring

/-- The infinite-dimensional logarithmic comparison includes convergence of
all series; no manipulation of an undefined totalized sum is used. -/
theorem logAction_tangent (a b : ι → ℝ) (ha : Summable a) (hb : Summable b)
    (hpa : ∀ i, 0 < 1+a i) (hpb : ∀ i, 0 < 1+b i)
    (hd : Summable (fun i => (b i-a i)/(1+a i))) :
    logAction b-logAction a ≤ ∑' i, (b i-a i)/(1+a i) := by
  rw [logAction, logAction, ← (logAction_summable b hb).tsum_sub (logAction_summable a ha)]
  exact tsum_le_tsum (fun i => log_one_add_tangent _ _ (hpa i) (hpb i))
    ((logAction_summable b hb).sub (logAction_summable a ha)) hd

/-- Frequency pairing doubles the logarithm and leaves a strictly positive product. -/
theorem paired_product_log (a : ι → ℝ) (ha : Summable a)
    (hp : ∀ i, 0 < 1+a i) :
    Real.log ((relativeProduct a)^2) / 2 = logAction a := by
  rw [Real.log_pow, log_relativeProduct a ha hp]
  ring

end SYK.Continuum
