import BilocalReflection

/-! # Odd insertions in actual Weyl reflection forms -/
noncomputable section
open scoped BigOperators ComplexOrder NNReal
namespace SYK.OddWeylReflection
open Interacting WeylBlocks WeylReflection BilocalReflection

/-- A tuple of paired fields, with time and insertion kept together. -/
def pairedWord (d : ℕ) {m : ℕ} (p : Fin m → ℝ × ℝ) (f : Fin m → Fin (2*d)) :
    Fin (m*2) → ℝ × Matrix (Majorana.Basis d) (Majorana.Basis d) ℂ :=
  fun i => (pairTimes p i, Majorana.chiFin d (pairFlavors f i))

/-- The flattened field word consists of exactly two entries per bilocal. -/
theorem ofFn_pairedWord (d : ℕ) {m : ℕ} (p : Fin m → ℝ × ℝ) (f : Fin m → Fin (2*d)) :
    List.ofFn (pairedWord d p f) =
      (List.ofFn (fun r => [((p r).1, Majorana.chiFin d (f r)),
        ((p r).2, Majorana.chiFin d (f r))])).flatten := by
  rw [List.ofFn_mul]
  congr 1
  apply congrArg List.ofFn
  funext r
  have he (u : Fin 2) : (⟨r.val*2+u.val, by omega⟩ : Fin (m*2)) = finProdFinEquiv (r,u) := by
    apply Fin.ext
    simp [finProdFinEquiv, Nat.add_comm, Nat.mul_comm]
  simp only [pairedWord, he, MomentSymmetry.pairTimes_finProd, MomentSymmetry.pairFlavors_finProd]
  simp [List.ofFn_succ]

/-- Prepending one bilocal prepends its two actual Majorana fields. -/
theorem ofFn_pairedWord_cons (d : ℕ) {m : ℕ} (p : ℝ × ℝ) (q : Fin m → ℝ × ℝ)
    (v : Fin (2*d)) (f : Fin m → Fin (2*d)) :
    List.ofFn (pairedWord d (Fin.cons p q) (Fin.cons v f)) =
      (p.1,Majorana.chiFin d v)::(p.2,Majorana.chiFin d v)::List.ofFn (pairedWord d q f) := by
  rw [ofFn_pairedWord, ofFn_pairedWord]
  simp only [List.ofFn_succ, Fin.cons_zero, Fin.cons_succ,
    List.flatten_cons, List.cons_append, List.nil_append]

/-- Concatenating bilocals concatenates their complete field lists. -/
theorem ofFn_pairedWord_append (d : ℕ) {m n : ℕ} (p : Fin m → ℝ × ℝ) (q : Fin n → ℝ × ℝ)
    (f : Fin m → Fin (2*d)) (g : Fin n → Fin (2*d)) :
    List.ofFn (pairedWord d (Fin.append p q) (Fin.append f g)) =
      List.ofFn (pairedWord d p f) ++ List.ofFn (pairedWord d q g) := by
  simp only [ofFn_pairedWord]
  have hh : (fun r => [((Fin.append p q r).1, Majorana.chiFin d (Fin.append f g r)),
      ((Fin.append p q r).2, Majorana.chiFin d (Fin.append f g r))]) =
      Fin.append (fun r => [((p r).1, Majorana.chiFin d (f r)),((p r).2, Majorana.chiFin d (f r))])
        (fun r => [((q r).1, Majorana.chiFin d (g r)),((q r).2, Majorana.chiFin d (g r))]) := by
    funext i
    refine Fin.addCases (fun _ => ?_) (fun _ => ?_) i <;> simp only [Fin.append_left, Fin.append_right]
  rw [hh, List.ofFn_fin_append, List.flatten_append]

/-- Canonical word equality gives exactly the same full Weyl transfer, even
when its two tuple presentations have different dependent lengths. -/
theorem weylTransfer_word_congr {ν : Type*} [Fintype ν] [DecidableEq ν] {k l : ℕ}
    (H : Matrix ν ν ℂ) (β : ℝ) (t : Fin k → ℝ) (A : Fin k → Matrix ν ν ℂ)
    (u : Fin l → ℝ) (B : Fin l → Matrix ν ν ℂ)
    (h : List.ofFn (fun i => (t i,A i)) = List.ofFn (fun i => (u i,B i))) :
    weylTransfer H β t A = weylTransfer H β u B := by
  have hkl : k=l := by simpa only [List.length_ofFn] using congrArg List.length h
  subst l
  have hh := List.ofFn_injective h
  have ht : t=u := funext (fun i => congrArg Prod.fst (congrFun hh i))
  have hA : A=B := funext (fun i => congrArg Prod.snd (congrFun hh i))
  rw [ht,hA]

/-- Reflecting all bilocals reverses precisely the full field list. -/
theorem ofFn_pairedWord_reflected (d : ℕ) {m : ℕ} (β : ℝ)
    (p : Fin m → ℝ × ℝ) (f : Fin m → Fin (2*d)) :
    List.ofFn (pairedWord d (fun r => reflectPair β (p r.rev)) (fun r => f r.rev)) =
      reflectedWord β (List.ofFn (pairedWord d p f)) := by
  have ht := pairTimes_reflected β p
  have hf := pairFlavors_reflected f
  unfold pairedWord
  rw [ht,hf]
  simp only [reflectedWord, ← ofFn_rev, List.map_ofFn, Function.comp_def, Majorana.chiFin_star]

/-- One additional odd field is placed before the even collective word. -/
def oddTime {m : ℕ} (s : ℝ) (p : Fin m → ℝ × ℝ) : Fin (m*2+1) → ℝ :=
  Fin.cons s (pairTimes p)

def oddField (d : ℕ) {m : ℕ} (v : Fin (2*d)) (f : Fin m → Fin (2*d)) :
    Fin (m*2+1) → Matrix (Majorana.Basis d) (Majorana.Basis d) ℂ :=
  Fin.cons (Majorana.chiFin d v) (fun i => Majorana.chiFin d (pairFlavors f i))

 theorem ofFn_oddWord (d : ℕ) {m : ℕ} (s : ℝ) (p : Fin m → ℝ × ℝ)
    (v : Fin (2*d)) (f : Fin m → Fin (2*d)) :
    List.ofFn (fun i => (oddTime s p i,oddField d v f i)) =
      (s,Majorana.chiFin d v)::List.ofFn (pairedWord d p f) := by
  simp only [List.ofFn_succ, oddTime, oddField, Fin.cons_zero, Fin.cons_succ]
  rfl

/-- The reflected odd word and the ordinary odd word join into one additional
cross-reflection bilocal. No sign is inserted or assumed. -/
theorem odd_pair_transfer (d : ℕ) {m n : ℕ}
    {H : Matrix (Majorana.Basis d) (Majorana.Basis d) ℂ} (hH : H.IsHermitian)
    (a s t : ℝ) (p : Fin m → ℝ × ℝ) (q : Fin n → ℝ × ℝ)
    (hs : s<a) (ht : t<a) (hp : ∀ i, (p i).1<a ∧ (p i).2<a)
    (hq : ∀ i, (q i).1<a ∧ (q i).2<a)
    (v : Fin (2*d)) (f : Fin m → Fin (2*d)) (g : Fin n → Fin (2*d)) :
    weylTransfer H (2*a)
      (pairTimes (Fin.append (fun r => reflectPair (2*a) (p r.rev)) (Fin.cons (2*a-s,t) q)))
      (fun i => Majorana.chiFin d (pairFlavors (Fin.append (fun r => f r.rev) (Fin.cons v g)) i)) =
      star (weylTransfer H a (oddTime s p) (oddField d v f)) *
        weylTransfer H a (oddTime t q) (oddField d v g) := by
  have hpt : ∀ i, oddTime s p i<a := by
    intro i
    refine Fin.cases hs (fun r => ?_) i
    simp only [oddTime, Fin.cons_succ, pairTimes]
    split_ifs
    · exact (hp _).1
    · exact (hp _).2
  have hqt : ∀ i, oddTime t q i<a := by
    intro i
    refine Fin.cases ht (fun r => ?_) i
    simp only [oddTime, Fin.cons_succ, pairTimes]
    split_ifs
    · exact (hq _).1
    · exact (hq _).2
  rw [← weylTransfer_reflected_pair hH a (oddTime s p) (oddTime t q) hpt hqt]
  apply weylTransfer_word_congr
  change List.ofFn (pairedWord d _ _) = _
  rw [ofFn_pairedWord_append, ofFn_pairedWord_cons, ofFn_pairedWord_reflected]
  have happ {k l : ℕ} (u : Fin k → ℝ) (v : Fin l → ℝ)
      (A : Fin k → Matrix (Majorana.Basis d) (Majorana.Basis d) ℂ)
      (B : Fin l → Matrix (Majorana.Basis d) (Majorana.Basis d) ℂ) :
      (fun i => (Fin.append u v i,Fin.append A B i)) =
        Fin.append (fun i => (u i,A i)) (fun i => (v i,B i)) := by
    funext i
    refine Fin.addCases (fun _ => ?_) (fun _ => ?_) i <;> simp only [Fin.append_left, Fin.append_right]
  rw [happ, List.ofFn_fin_append, ofFn_oddWord]
  have href : List.ofFn (fun r => (2*a-oddTime s p r.rev,star (oddField d v f r.rev))) =
      reflectedWord (2*a) (List.ofFn (fun i => (oddTime s p i,oddField d v f i))) := by
    simp only [reflectedWord, ← ofFn_rev, List.map_ofFn, Function.comp_def]
  rw [href, ofFn_oddWord]
  simp only [reflectedWord, List.reverse_cons, List.map_append, List.map_cons,
    List.map_nil, Majorana.chiFin_star, List.append_assoc, List.cons_append, List.nil_append]

/-- Split a flavor assignment into its head and remaining bilocal flavors. -/
def consFlavorEquiv (m N : ℕ) : (Fin N × (Fin m → Fin N)) ≃ (Fin (m+1) → Fin N) where
  toFun z := Fin.cons z.1 z.2
  invFun f := (f 0, fun i => f i.succ)
  left_inv z := by simp
  right_inv f := Fin.cons_self_tail f

/-- The actual flavor-averaged odd half-history with one unsummed flavor. -/
def oddCollectiveTransfer (d : ℕ) {m : ℕ}
    (H : Matrix (Majorana.Basis d) (Majorana.Basis d) ℂ) (a s : ℝ)
    (p : Fin m → ℝ × ℝ) (v : Fin (2*d)) : Matrix (Majorana.Basis d) (Majorana.Basis d) ℂ :=
  (((2*d : ℕ):ℂ)^m)⁻¹ • ∑ f : Fin m → Fin (2*d),
    weylTransfer H a (oddTime s p) (oddField d v f)

/-- Summing the common odd flavor inserts exactly the reflected bilocal,
with normalization 1/N. -/
theorem odd_collective_pair (d : ℕ) {m n : ℕ}
    {H : Matrix (Majorana.Basis d) (Majorana.Basis d) ℂ} (hH : H.IsHermitian)
    (a s t : ℝ) (p : Fin m → ℝ × ℝ) (q : Fin n → ℝ × ℝ)
    (hs : s<a) (ht : t<a) (hp : ∀ i, (p i).1<a ∧ (p i).2<a)
    (hq : ∀ i, (q i).1<a ∧ (q i).2<a) :
    collectiveTransfer d H (2*a)
      (Fin.append (fun r => reflectPair (2*a) (p r.rev)) (Fin.cons (2*a-s,t) q)) =
      (((2*d : ℕ):ℂ)⁻¹) • ∑ v : Fin (2*d),
        star (oddCollectiveTransfer d H a s p v) * oddCollectiveTransfer d H a t q v := by
  classical
  let e := (Equiv.prodCongr (Equiv.arrowCongr Fin.revPerm (Equiv.refl (Fin (2*d))))
    (consFlavorEquiv n (2*d))).trans (Fin.appendEquiv m (n+1))
  unfold collectiveTransfer
  rw [← Equiv.sum_comp e]
  simp only [Fintype.sum_prod_type]
  change ((((2*d : ℕ):ℂ)^(m+(n+1)))⁻¹) • (∑ f : Fin m → Fin (2*d), ∑ v : Fin (2*d), ∑ g : Fin n → Fin (2*d),
    weylTransfer H (2*a)
      (pairTimes (Fin.append (fun r => reflectPair (2*a) (p r.rev)) (Fin.cons (2*a-s,t) q)))
      (fun i => Majorana.chiFin d (pairFlavors (Fin.append (fun r => f r.rev) (Fin.cons v g)) i))) = _
  simp only [odd_pair_transfer d hH a s t p q hs ht hp hq]
  rw [Finset.sum_comm]
  unfold oddCollectiveTransfer
  simp only [← Nat.cast_pow, star_inv_natCast_smul, star_sum]
  simp only [smul_mul_assoc, mul_smul_comm, Finset.sum_mul, Finset.mul_sum, smul_smul,
    Finset.smul_sum]
  simp only [Nat.cast_pow, Nat.cast_mul, pow_add, pow_succ, mul_inv_rev]
  apply Finset.sum_congr rfl
  intro v _
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro f _
  apply Finset.sum_congr rfl
  intro g _
  congr 1
  ring

/-- Scalar form of the exact microscopic inserted-odd identification. -/
theorem odd_collective_numerator_pair (d : ℕ) {m n : ℕ}
    {H : Matrix (Majorana.Basis d) (Majorana.Basis d) ℂ} (hH : H.IsHermitian)
    (a s t : ℝ) (p : Fin m → ℝ × ℝ) (q : Fin n → ℝ × ℝ)
    (hs : s<a) (ht : t<a) (hp : ∀ i, (p i).1<a ∧ (p i).2<a)
    (hq : ∀ i, (q i).1<a ∧ (q i).2<a) :
    collectiveNumerator d H (2*a)
      (Fin.append (fun r => reflectPair (2*a) (p r.rev)) (Fin.cons (2*a-s,t) q)) =
      (((2*d : ℕ):ℂ)⁻¹) * ∑ v : Fin (2*d),
        Matrix.trace (star (oddCollectiveTransfer d H a s p v) * oddCollectiveTransfer d H a t q v) := by
  rw [← trace_collectiveTransfer, odd_collective_pair d hH a s t p q hs ht hp hq]
  simp only [Matrix.trace_smul, Matrix.trace_sum, smul_eq_mul]

/-- Actual odd amplitude for a finite family of collective monomials with
one extra, common-flavor insertion in each term. -/
def oddAmplitude {ι : Type*} [Fintype ι] (d : ℕ)
    (H : Matrix (Majorana.Basis d) (Majorana.Basis d) ℂ) (a : ℝ)
    (k : ι → ℕ) (c : ι → ℂ) (p : ∀ i, Fin (k i) → ℝ × ℝ) (s : ι → ℝ)
    (v : Fin (2*d)) : Matrix (Majorana.Basis d) (Majorana.Basis d) ℂ :=
  ∑ i, c i • oddCollectiveTransfer d H a (s i) (p i) v

/-- A finite odd collective reflection form is exactly the average of actual
trace star-squares, one for each unsummed flavor. -/
theorem odd_numerator_reflected_sum {ι : Type*} [Fintype ι] (d : ℕ)
    {H : Matrix (Majorana.Basis d) (Majorana.Basis d) ℂ} (hH : H.IsHermitian)
    (a : ℝ) (k : ι → ℕ) (c : ι → ℂ) (p : ∀ i, Fin (k i) → ℝ × ℝ) (s : ι → ℝ)
    (hp : ∀ i r, (p i r).1<a ∧ (p i r).2<a) (hs : ∀ i, s i<a) :
    (∑ i, ∑ j, (star (c i)*c j) * collectiveNumerator d H (2*a)
      (Fin.append (fun r => reflectPair (2*a) (p i r.rev)) (Fin.cons (2*a-s i,s j) (p j)))) =
      (((2*d : ℕ):ℂ)⁻¹) * ∑ v : Fin (2*d),
        Matrix.trace (star (oddAmplitude d H a k c p s v) * oddAmplitude d H a k c p s v) := by
  simp only [odd_collective_numerator_pair d hH a _ _ _ _ (hs _) (hs _) (hp _) (hp _)]
  have hsquare (v : Fin (2*d)) :
      Matrix.trace (star (oddAmplitude d H a k c p s v)*oddAmplitude d H a k c p s v) =
      ∑ i, ∑ j, (star (c i)*c j) * Matrix.trace
        (star (oddCollectiveTransfer d H a (s i) (p i) v)*oddCollectiveTransfer d H a (s j) (p j) v) := by
    simp only [oddAmplitude, star_sum, star_smul, Finset.sum_mul, Finset.mul_sum,
      smul_mul_assoc, mul_smul_comm, smul_smul, Finset.smul_sum,
      Matrix.trace_sum, Matrix.trace_smul, smul_eq_mul]
    rw [Finset.sum_comm]
    simp only [mul_comm]
  simp only [hsquare, Finset.mul_sum]
  conv_rhs => rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro i _
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro v _
  apply Finset.sum_congr rfl
  intro j _
  ring

end SYK.OddWeylReflection
