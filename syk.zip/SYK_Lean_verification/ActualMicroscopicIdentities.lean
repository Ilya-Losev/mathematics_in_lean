import ActualWickCorrespondence
import ActualCorrespondenceConsequences
import IntegratedWickWard

/-! Unconditional microscopic identities used by the continuum theorem. -/
noncomputable section
open MeasureTheory
open scoped NNReal
namespace SYK.ActualMicroscopicIdentities
open ActualFiniteWardControl ContinuumWickSeries

/-- The exact finite inserted left Ward identity for the actual thermally
corrected polynomial moment, with its full finite contact derivation. -/
theorem exact_left_ward (d : ℕ) (hd : 0 < d) (β : ℝ) (hβ : 0 < β) (lam : ℝ≥0) :
    ExactLeftWard β hβ lam d := by
  apply ActualWickWard.exact_left_of_wick_identities d hd β hβ lam
    (fun ps => ActualWickCorrespondence.normalizedMoment_eq_collectiveMoment d hd hβ lam ps)
  intro ps s t
  exact numerator_ward d hd β hβ ps s t (lam : ℝ)

/-- Exact differentiation of the actual annealed pressure gives the actual
fourth collective moment. No response or operator/series identity is assumed. -/
theorem quartic_response (d : ℕ) (hd : 0 < d) (β : ℝ) (hβ : 0 < β)
    (lam : ℝ) (hlam : 0 < lam) :
    HasDerivAt (fun l => Microscopic.annealedPressure d β l.toNNReal)
      (FourthMomentIntegral.fourthIntegral d β lam.toNNReal) lam := by
  apply ActualCorrespondenceConsequences.pressure_response_of_list_correspondence d hd hβ lam hlam
  intro ps
  exact ActualWickCorrespondence.normalizedMoment_eq_collectiveMoment d hd hβ lam.toNNReal ps

/-- All finite Ward control, including the opposite orientation and sharp
centered endpoint contact bounds, is now an actual theorem of the model. -/
theorem finite_ward_control (β : ℝ) (hβ : 0 < β) (lam : ℝ≥0)
    (d : ℕ → ℕ) (hd : ∀ n, 0 < d n) :
    ThermalWardLimit.FiniteWardControl β hβ lam d :=
  finiteWardControl_of_exact_left β hβ lam d hd
    (fun n => exact_left_ward (d n) (hd n) β hβ lam)

end SYK.ActualMicroscopicIdentities
