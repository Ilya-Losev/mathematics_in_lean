import BilocalReflection
import MomentLimitHierarchy

/-! # Actual annealed polynomial reflection positivity

The polynomial reflection form is identified with an integral of the trace of
an explicit flavor-averaged Weyl amplitude squared. Internal equal-time blocks
are retained throughout the identification.
-/
noncomputable section
open scoped BigOperators ComplexOrder NNReal
open MeasureTheory
namespace SYK.PolynomialRP
open MomentLimit MomentCompactness BilocalReflection

/-- Time reflection of a closed-cube endpoint pair, reversing field order. -/
def reflectEndpoint (β : ℝ) (p : EndpointPair β) : EndpointPair β :=
  (⟨β-p.2.val, by constructor <;> linarith [p.2.property.1, p.2.property.2]⟩,
   ⟨β-p.1.val, by constructor <;> linarith [p.1.property.1, p.1.property.2]⟩)

/-- A finite coordinate polynomial represented by possibly different degrees. -/
def tuplePolynomial {ι : Type*} [Fintype ι] (β : ℝ) (k : ι → ℕ)
    (c : ι → ℂ) (p : ∀ i, EndpointCube β (k i)) : CoordinatePolynomial β :=
  ∑ i, c i • ∏ r, MvPolynomial.X (p i r)

/-- Coefficient conjugation and reversed endpoint reflection on the same
finite polynomial representation. -/
def reflectedTuplePolynomial {ι : Type*} [Fintype ι] (β : ℝ) (k : ι → ℕ)
    (c : ι → ℂ) (p : ∀ i, EndpointCube β (k i)) : CoordinatePolynomial β :=
  ∑ i, star (c i) • ∏ r, MvPolynomial.X (reflectEndpoint β (p i r))

/-- The polynomial product is exactly the original microscopic collective
moment of the concatenated reflected and ordinary words. -/
theorem actualPolynomial_reflected_product (d : ℕ) (β : ℝ) (lam : ℝ≥0)
    {m n : ℕ} (p : EndpointCube β m) (q : EndpointCube β n) :
    actualPolynomial d β lam
      ((∏ r, MvPolynomial.X (reflectEndpoint β (p r))) * (∏ r, MvPolynomial.X (q r))) =
      Interacting.collectiveMoment d β lam
        (Fin.append (fun r => reflectPair β (endpointValues p r.rev)) (endpointValues q)) := by
  have hrev : (∏ r : Fin m, (MvPolynomial.X (reflectEndpoint β (p r.rev)) : CoordinatePolynomial β)) =
      (∏ r, MvPolynomial.X (reflectEndpoint β (p r))) :=
    Equiv.prod_comp Fin.revPerm (fun r => MvPolynomial.X (reflectEndpoint β (p r)))
  rw [← hrev]
  have hp : (∏ r : Fin m, (MvPolynomial.X (reflectEndpoint β (p r.rev)) : CoordinatePolynomial β)) * (∏ r, MvPolynomial.X (q r)) =
      ∏ r, MvPolynomial.X (Fin.append (fun r : Fin m => reflectEndpoint β (p r.rev)) q r) := by
    rw [Fin.prod_univ_add]
    simp only [Fin.append_left, Fin.append_right]
  rw [hp, actualPolynomial_tuple_prod]
  congr 1
  funext i
  refine Fin.addCases (fun _ => ?_) (fun _ => ?_) i <;>
    simp only [endpointValues, Fin.append_left, Fin.append_right, reflectEndpoint, reflectPair]

/-- Expansion of the complete reflected polynomial uses actual collective
moments, not an assumed positivity axiom. -/
theorem actualPolynomial_reflected_sum {ι : Type*} [Fintype ι]
    (d : ℕ) (β : ℝ) (lam : ℝ≥0) (k : ι → ℕ) (c : ι → ℂ)
    (p : ∀ i, EndpointCube β (k i)) :
    actualPolynomial d β lam (reflectedTuplePolynomial β k c p * tuplePolynomial β k c p) =
      ∑ i, ∑ j, (star (c i)*c j) * Interacting.collectiveMoment d β lam
        (Fin.append (fun r => reflectPair β (endpointValues (p i) r.rev)) (endpointValues (p j))) := by
  simp only [reflectedTuplePolynomial, tuplePolynomial, Finset.sum_mul, Finset.mul_sum,
    smul_mul_assoc, mul_smul_comm, smul_smul, map_sum, map_smul,
    smul_eq_mul, actualPolynomial_reflected_product]
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro i _
  apply Finset.sum_congr rfl
  intro j _
  ring

/-- The explicit microscopic star-square appearing in polynomial RP. -/
def squareTrace {ι : Type*} [Fintype ι] (d : ℕ) (β : ℝ)
    (k : ι → ℕ) (c : ι → ℂ) (p : ∀ i, EndpointCube β (k i))
    (j : Majorana.FourSet d → ℝ) : ℂ :=
  let A := collectiveAmplitude d (Majorana.hamiltonian d j) (β/2) k c
    (fun i => endpointValues (p i))
  Matrix.trace (star A * A)

/-- Identification before integration, including all Weyl and flavor sums. -/
theorem squareTrace_eq_sum {ι : Type*} [Fintype ι] (d : ℕ) (β : ℝ)
    (k : ι → ℕ) (c : ι → ℂ) (p : ∀ i, EndpointCube β (k i))
    (hp : ∀ i r, (p i r).1.val < β/2 ∧ (p i r).2.val < β/2)
    (j : Majorana.FourSet d → ℝ) :
    squareTrace d β k c p j =
      ∑ i, ∑ l, (star (c i)*c l) * Interacting.collectiveNumerator d
        (Majorana.hamiltonian d j) β
        (Fin.append (fun r => reflectPair β (endpointValues (p i) r.rev)) (endpointValues (p l))) := by
  have h := collectiveNumerator_reflected_sum d (Majorana.hamiltonian_star d j)
    (β/2) k c (fun i => endpointValues (p i)) hp
  rw [show 2*(β/2)=β by ring] at h
  exact h.symm

/-- The actual star-square is Gaussian-integrable; this follows from the
already established integrability of each actual collective numerator. -/
theorem squareTrace_integrable {ι : Type*} [Fintype ι] (d : ℕ) (β : ℝ) (lam : ℝ≥0)
    (k : ι → ℕ) (c : ι → ℂ) (p : ∀ i, EndpointCube β (k i))
    (hp : ∀ i r, (p i r).1.val < β/2 ∧ (p i r).2.val < β/2) :
    Integrable (squareTrace d β k c p) (Microscopic.disorder d lam) := by
  simp only [funext (squareTrace_eq_sum d β k c p hp)]
  apply integrable_finset_sum
  intro i _
  apply integrable_finset_sum
  intro l _
  exact (Interacting.collectiveNumerator_integrable d β lam _).const_mul _

/-- Exact annealed operator representation of the actual polynomial
reflection form, with the positive physical partition normalization. -/
theorem actualPolynomial_reflected_eq_integral {ι : Type*} [Fintype ι]
    (d : ℕ) (β : ℝ) (lam : ℝ≥0) (k : ι → ℕ) (c : ι → ℂ)
    (p : ∀ i, EndpointCube β (k i))
    (hp : ∀ i r, (p i r).1.val < β/2 ∧ (p i r).2.val < β/2) :
    actualPolynomial d β lam (reflectedTuplePolynomial β k c p * tuplePolynomial β k c p) =
      (∫ j, squareTrace d β k c p j ∂Microscopic.disorder d lam) /
        ((∫ j, (Majorana.partitionFunction d β j).re ∂Microscopic.disorder d lam : ℝ) : ℂ) := by
  rw [actualPolynomial_reflected_sum]
  simp only [Interacting.collectiveMoment, div_eq_mul_inv, mul_comm _ (_⁻¹)]
  simp_rw [mul_left_comm (star (c _) * c _)]
  simp only [← Finset.mul_sum]
  congr 1
  simp_rw [squareTrace_eq_sum d β k c p hp]
  rw [integral_finset_sum _ (fun i _ => integrable_finset_sum _
    (fun l _ => (Interacting.collectiveNumerator_integrable d β lam _).const_mul _))]
  apply Finset.sum_congr rfl
  intro i _
  rw [integral_finset_sum _ (fun l _ =>
    (Interacting.collectiveNumerator_integrable d β lam _).const_mul _)]
  simp only [integral_const_mul]

/-- The actual microscopic polynomial reflection form is nonnegative. -/
theorem actualPolynomial_reflection_nonnegative {ι : Type*} [Fintype ι]
    (d : ℕ) (β : ℝ) (lam : ℝ≥0) (k : ι → ℕ) (c : ι → ℂ)
    (p : ∀ i, EndpointCube β (k i))
    (hp : ∀ i r, (p i r).1.val < β/2 ∧ (p i r).2.val < β/2) :
    0 ≤ (actualPolynomial d β lam
      (reflectedTuplePolynomial β k c p * tuplePolynomial β k c p)).re := by
  have hre : (∫ j, (squareTrace d β k c p j).re ∂Microscopic.disorder d lam) =
      (∫ j, squareTrace d β k c p j ∂Microscopic.disorder d lam).re :=
    integral_re (squareTrace_integrable d β lam k c p hp)
  rw [actualPolynomial_reflected_eq_integral d β lam k c p hp, Complex.div_ofReal_re, ← hre]
  apply div_nonneg _ (ThermalRP.annealed_partition_positive d β lam).le
  apply integral_nonneg
  intro j
  exact AntiCommuting.trace_re_nonneg (Matrix.posSemidef_conjTranspose_mul_self _)

/-- The actual microscopic polynomial reflection form is real. -/
theorem actualPolynomial_reflection_im_zero {ι : Type*} [Fintype ι]
    (d : ℕ) (β : ℝ) (lam : ℝ≥0) (k : ι → ℕ) (c : ι → ℂ)
    (p : ∀ i, EndpointCube β (k i))
    (hp : ∀ i r, (p i r).1.val < β/2 ∧ (p i r).2.val < β/2) :
    (actualPolynomial d β lam
      (reflectedTuplePolynomial β k c p * tuplePolynomial β k c p)).im = 0 := by
  have him : (∫ j, (squareTrace d β k c p j).im ∂Microscopic.disorder d lam) =
      (∫ j, squareTrace d β k c p j ∂Microscopic.disorder d lam).im :=
    integral_im (squareTrace_integrable d β lam k c p hp)
  rw [actualPolynomial_reflected_eq_integral d β lam k c p hp, Complex.div_ofReal_im, ← him]
  have hzero : ∀ j, (squareTrace d β k c p j).im = 0 := fun j =>
    Gibbs.trace_im_eq_zero (Matrix.posSemidef_conjTranspose_mul_self _).isHermitian
  simp only [hzero, integral_zero, zero_div]

end SYK.PolynomialRP
