import FourierOperators
import VariationalEnvelope

/-! The checked coupling action uses the determinant limit of the actual
physical L² operator compressions. This is not yet a general, basis-independent
Fredholm determinant theorem. -/
noncomputable section
open scoped NNReal
namespace SYK.FourierOperators
open Continuum
variable (β : ℝ) [Fact (0 < β)]

/-- Exact operator-compression action formula for any bounded actual physical
family; its existence is not postulated by this theorem. -/
theorem couplingPressure_eq_physical_operator_action (g : ℝ≥0 → ℝ → ℝ)
    (hp : ∀ l, PhysicalSolution β l (g l)) (B : ℝ) (hb : ∀ l t, |g l t| ≤ B)
    (lam : ℝ≥0) :
    couplingPressure β g lam = Real.log 2 / 2 +
      (1/2 : ℝ) * Real.log (physicalDeterminant β lam (g lam)).re -
        (3 * β / 8) * (lam : ℝ) * quarticIntegral β (g lam) := by
  rw [physicalDeterminant_eq β lam (g lam) (hp lam), Complex.ofReal_re]
  exact couplingPressure_eq_relative_log_action β g hp B hb lam

end SYK.FourierOperators
