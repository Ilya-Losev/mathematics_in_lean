import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Data.Finset.Powerset
import Mathlib.Data.Nat.Factorial.Basic
import Mathlib.Tactic

/-!
# Powers of a finite sum of commuting square-zero elements

The combinatorial factorial is proved, not assumed. The result applies to the
commutative center of an exterior algebra and includes the quartic coefficient24.
-/

namespace SYK.NilpotentSymmetricSum

open scoped BigOperators

variable {R ι : Type*} [CommSemiring R]

/-- With a square-zero summand, only the zeroth and first binomial terms remain. -/
theorem add_pow_of_sq_zero (a x : R) (ha : a^2=0) (n : ℕ) :
    (a+x)^(n+1) = x^(n+1)+(n+1:R)*a*x^n := by
  induction n with
  | zero => simp [add_comm]
  | succ n ih =>
      simp only [Nat.cast_add, Nat.cast_one]
      calc
        (a+x)^(n+1+1) = (x^(n+1)+(n+1:R)*a*x^n)*(a+x) := by
          rw [pow_succ, ih]
        _ = x^(n+1+1)+(n+1+1:R)*a*x^(n+1)+((n+1:R)*x^n)*a^2 := by ring
        _ = x^(n+1+1)+(n+1+1:R)*a*x^(n+1) := by rw [ha, mul_zero, add_zero]

/-- The elementary symmetric sum recurrence, with the disjointness of the
subset split and injectivity of inserting the new element proved explicitly. -/
theorem symmetric_sum_insert [DecidableEq ι] (s : Finset ι) (a : ι) (ha : a ∉ s)
    (b : ι → R) (n : ℕ) :
    (∑ T ∈ (insert a s).powersetCard (n+1), ∏ i ∈ T, b i) =
      (∑ T ∈ s.powersetCard (n+1), ∏ i ∈ T, b i) +
        b a*(∑ T ∈ s.powersetCard n, ∏ i ∈ T, b i) := by
  rw [Finset.powersetCard_succ_insert ha]
  have hd : Disjoint (s.powersetCard (n+1)) ((s.powersetCard n).image (insert a)) := by
    apply Finset.disjoint_left.mpr
    intro T hT hI
    obtain ⟨U,hU,rfl⟩ := Finset.mem_image.mp hI
    exact ha ((Finset.mem_powersetCard.mp hT).1 (Finset.mem_insert_self a U))
  rw [Finset.sum_union hd]
  congr 1
  rw [Finset.sum_image]
  · rw [Finset.mul_sum]
    apply Finset.sum_congr rfl
    intro T hT
    exact Finset.prod_insert (fun h => ha ((Finset.mem_powersetCard.mp hT).1 h))
  · intro T hT U hU he
    have hTa : a ∉ T := fun h => ha ((Finset.mem_powersetCard.mp hT).1 h)
    have hUa : a ∉ U := fun h => ha ((Finset.mem_powersetCard.mp hU).1 h)
    have hh := congrArg (fun S : Finset ι => S.erase a) he
    simpa only [Finset.erase_insert hTa, Finset.erase_insert hUa] using hh

/-- Any power of a finite sum of commuting square-zero elements is factorial
times its elementary symmetric sum of that degree. -/
theorem sum_pow_eq_factorial_mul_powersetCard (s : Finset ι) (b : ι → R)
    (h : ∀ i ∈ s, (b i)^2=0) (n : ℕ) :
    (∑ i ∈ s, b i)^n = (n.factorial:R)*(∑ T ∈ s.powersetCard n, ∏ i ∈ T, b i) := by
  classical
  revert h
  induction s using Finset.induction_on generalizing n with
  | empty =>
      intro h
      cases n with
      | zero => simp
      | succ n =>
          have he : (∅ : Finset ι).powersetCard (n+1) = ∅ :=
            Finset.powersetCard_eq_empty.mpr (by simp)
          simp [he]
  | @insert a s ha ih =>
      intro h
      have hs : ∀ i ∈ s, (b i)^2=0 := fun i hi => h i (Finset.mem_insert_of_mem hi)
      cases n with
      | zero => simp
      | succ n =>
          rw [Finset.sum_insert ha, add_pow_of_sq_zero (b a) _ (h a (Finset.mem_insert_self a s)),
            ih (n+1) hs, ih n hs, symmetric_sum_insert s a ha]
          simp only [Nat.factorial_succ, Nat.cast_mul, Nat.cast_add, Nat.cast_one]
          ring

/-- The exact quartic regrouping coefficient is 4! = 24. -/
theorem sum_fourth_eq_twentyfour_mul_powersetCard (s : Finset ι) (b : ι → R)
    (h : ∀ i ∈ s, (b i)^2=0) :
    (∑ i ∈ s, b i)^4 = (24:R)*(∑ T ∈ s.powersetCard 4, ∏ i ∈ T, b i) := by
  simpa using sum_pow_eq_factorial_mul_powersetCard s b h 4

/-- Fintype form for the full family of microscopic flavor bilocals. -/
theorem sum_fourth_eq_twentyfour_mul_subsets [Fintype ι] (b : ι → R)
    (h : ∀ i, (b i)^2=0) :
    (∑ i, b i)^4 = (24:R)*(∑ T ∈ Finset.univ.powersetCard 4, ∏ i ∈ T, b i) :=
  sum_fourth_eq_twentyfour_mul_powersetCard Finset.univ b (fun i _ => h i)

end SYK.NilpotentSymmetricSum
