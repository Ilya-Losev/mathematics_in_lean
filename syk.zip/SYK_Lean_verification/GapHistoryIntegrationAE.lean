import GapHistoryIntegration

/-!
# Ordered history integration with null interaction collisions removed

The genuine exterior and operator histories need agree only when the interaction
times are distinct. Their collision set is already proved Lebesgue null.
-/
noncomputable section
open scoped BigOperators
open MeasureTheory Set
open SYK.OrderedSimplexIntegral SYK.GapAssignmentPartition
open SYK.GapChamberCoordinates SYK.GapCountCompositions SYK.DuhamelHistory

namespace SYK.GapHistoryIntegrationAE

/-- Constancy away from internal collisions implies actual a.e. constancy on
any fixed ordered external-time chamber. -/
theorem chamber_ae_constant {E : Type*} {n k : ℕ}
    (t : Fin (k+1) → ℝ) (g : Fin n → Fin k) (f : (Fin n → ℝ) → E) (v : E)
    (h : ∀ u ∈ orderedAssignmentRegion t g, Function.Injective u → f u = v) :
    f =ᵐ[volume.restrict (orderedAssignmentRegion t g)] fun _ => v := by
  filter_upwards [ae_restrict_of_ae (ae_injective_times n),
    ae_restrict_mem (orderedAssignmentRegion_measurable t g)] with u hi hu
  exact h u hu hi

/-- Null interaction collisions, and arbitrary values there, impose no
additional measurability assumption on a chamberwise constant history. -/
theorem integrableOn_of_chamber_constant {E : Type*} [NormedAddCommGroup E]
    {n k : ℕ} (t : Fin (k+1) → ℝ) (ht : Antitone t)
    (f : (Fin n → ℝ) → E) (F : (Fin k → ℕ) → E)
    (hconst : ∀ (g : Fin n → Fin k), Monotone g →
      ∀ u ∈ orderedAssignmentRegion t g, Function.Injective u → f u = F (gapCount g)) :
    IntegrableOn f (orderedSimplex n (t (Fin.last k)) (t 0)) := by
  classical
  have hi (g : Fin n → Fin k) : IntegrableOn f (orderedAssignmentRegion t g) := by
    by_cases hg : Monotone g
    · have hc : IntegrableOn (fun _ : Fin n → ℝ => F (gapCount g)) (orderedAssignmentRegion t g) :=
        integrableOn_const.mpr (Or.inr ((measure_mono inter_subset_left).trans_lt
          (orderedSimplex_volume_lt_top n _ _)))
      exact hc.congr (chamber_ae_constant t g f _ (hconst g hg)).symm
    · rw [orderedAssignmentRegion_eq_empty_of_not_monotone t ht g hg]
      exact integrableOn_empty
  have hall : IntegrableOn f (⋃ g : Fin n → Fin k, orderedAssignmentRegion t g) := by
    simpa only [Finset.mem_univ, iUnion_true] using
      (integrableOn_finset_iUnion.mpr (fun g (_ : g ∈ (Finset.univ : Finset (Fin n → Fin k))) => hi g))
  exact hall.congr_set_ae (orderedAssignmentRegion_union_ae_simplex n t ht).symm

/-- The exact composition coefficient formula tolerates every internal
collision value, as required by exterior Wick integrands. -/
theorem integral_simplex_of_chamber_constant {E : Type*}
    [NormedAddCommGroup E] [NormedSpace ℝ E] [CompleteSpace E] {n k : ℕ}
    (t : Fin (k+1) → ℝ) (ht : Antitone t) (f : (Fin n → ℝ) → E)
    (F : (Fin k → ℕ) → E)
    (hconst : ∀ (g : Fin n → Fin k), Monotone g →
      ∀ u ∈ orderedAssignmentRegion t g, Function.Injective u → f u = F (gapCount g)) :
    ∫ u in orderedSimplex n (t (Fin.last k)) (t 0), f u =
      ∑ r : CountComposition n k,
        (∏ j, (t j.castSucc-t j.succ)^(r.val j) / (r.val j).factorial) • F r.val := by
  classical
  rw [integral_simplex_eq_sum_monotone_assignments t ht f
    (integrableOn_of_chamber_constant t ht f F hconst),
    Finset.sum_subtype (p := fun g : Fin n → Fin k => Monotone g) _ (fun g => by simp)]
  calc
    _ = ∑ g : MonotoneAssignment n k,
        (∏ j, (t j.castSucc-t j.succ)^(gapCount g.val j) / (gapCount g.val j).factorial) •
          F (gapCount g.val) := by
      apply Finset.sum_congr rfl
      intro g _
      rw [integral_congr_ae (chamber_ae_constant t g.val f _ (hconst g.val g.property)),
        setIntegral_const, orderedAssignmentRegion_volume_real t ht g.val g.property]
    _ = _ := sum_monotone_assignments_eq_sum_counts n k
      (fun r => (∏ j, (t j.castSucc-t j.succ)^(r j) / (r j).factorial) • F r)

/-- The actual global ordered-integral series follows from the convergent
exponential gap series with only off-collision chamber constancy. -/
theorem hasSum_ordered_integrals_of_gap_series {E : Type*}
    [NormedAddCommGroup E] [NormedSpace ℝ E] [CompleteSpace E] {k : ℕ}
    (t : Fin (k+1) → ℝ) (ht : Antitone t)
    (f : (n : ℕ) → (Fin n → ℝ) → E) (F : (Fin k → ℕ) → E) (v : E)
    (hconst : ∀ n (g : Fin n → Fin k), Monotone g →
      ∀ u ∈ orderedAssignmentRegion t g, Function.Injective u → f n u = F (gapCount g))
    (hseries : HasSum (fun r : Fin k → ℕ =>
      (∏ j, (t j.castSucc-t j.succ)^(r j) / (r j).factorial) • F r) v) :
    HasSum (fun n => ∫ u in orderedSimplex n (t (Fin.last k)) (t 0), f n u) v := by
  apply (hasSum_group_by_total hseries).congr_fun
  intro n
  exact integral_simplex_of_chamber_constant t ht (f n) F (hconst n)

end SYK.GapHistoryIntegrationAE
