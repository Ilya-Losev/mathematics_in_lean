import FourierDyson

noncomputable section
open MeasureTheory Set
open scoped ComplexConjugate NNReal
namespace SYK.Continuum

/-- Reality of the time-domain kernel relates the two signs of frequency. -/
theorem fourier_neg_frequency (β : ℝ) (g : ℝ → ℝ) (ω : ℝ) :
    fourier β g (-ω) = conj (fourier β g ω) := by
  have he (t : ℝ) : Complex.exp (Complex.I * ((-ω : ℝ) : ℂ) * (t : ℂ)) * (g t : ℂ) =
      conj (Complex.exp (Complex.I * (ω : ℂ) * (t : ℂ)) * (g t : ℂ)) := by
    rw [map_mul, ← Complex.exp_conj]
    simp only [map_mul, Complex.conj_I, Complex.conj_ofReal, Complex.ofReal_neg]
    congr 2
    ring
  unfold fourier
  simp only [← mul_assoc]
  simp_rw [he]
  simp only [intervalIntegral, integral_conj, map_sub]

variable (β : ℝ) [Fact (0 < β)]

theorem integerFrequency_nonneg (k : ℤ) (hk : 0 ≤ k) :
    integerFrequency β k = frequency β k.toNat := by
  have hc : (k.toNat : ℝ) = (k : ℝ) := by exact_mod_cast Int.toNat_of_nonneg hk
  simp only [integerFrequency, frequency, hc]

theorem integerFrequency_neg (k : ℤ) (hk : k < 0) :
    integerFrequency β k = -frequency β (-k-1).toNat := by
  have hk' : 0 ≤ -k-1 := by omega
  have hc : ((-k-1).toNat : ℝ) = ((-k-1 : ℤ) : ℝ) := by
    exact_mod_cast Int.toNat_of_nonneg hk'
  simp only [integerFrequency, frequency, hc]
  push_cast
  ring

/-- The Fourier coefficient is purely imaginary at every odd frequency. -/
theorem integer_fourier_imaginary (g : ℝ → ℝ) (hsym : ∀ t, g (β-t) = g t) (k : ℤ) :
    fourier β g (integerFrequency β k) = Complex.I *
      (fourier β g (integerFrequency β k)).im := by
  have hβ : 0 < β := Fact.out
  have hr : (fourier β g (integerFrequency β k)).re = 0 := by
    by_cases hk : 0 ≤ k
    · rw [integerFrequency_nonneg β k hk]
      exact fourier_re_zero β hβ g hsym _
    · rw [integerFrequency_neg β k (lt_of_not_ge hk), fourier_neg_frequency, Complex.conj_re]
      exact fourier_re_zero β hβ g hsym _
  apply Complex.ext <;> simp [hr]

theorem physical_integer_signs (lam : ℝ≥0) (g : ℝ → ℝ)
    (hphys : PhysicalSolution β lam g) (k : ℤ) :
    (0 ≤ k → 0 < (fourier β g (integerFrequency β k)).im) ∧
    (k < 0 → (fourier β g (integerFrequency β k)).im < 0) := by
  constructor
  · intro hk
    rw [integerFrequency_nonneg β k hk]
    rcases hphys.2.2.2.2.2.1 k.toNat with ⟨x, hx, he⟩
    simpa [he] using hx
  · intro hk
    rw [integerFrequency_neg β k hk, fourier_neg_frequency, Complex.conj_im]
    rcases hphys.2.2.2.2.2.1 (-k-1).toNat with ⟨x, hx, he⟩
    rw [he]
    simpa using neg_neg_of_pos hx

/-- Actual physical coefficients have the same nonzero sign at every odd frequency. -/
theorem physical_integer_product_pos (lam : ℝ≥0) (g h : ℝ → ℝ)
    (hg : PhysicalSolution β lam g) (hh : PhysicalSolution β lam h) (k : ℤ) :
    0 < (fourier β g (integerFrequency β k)).im *
      (fourier β h (integerFrequency β k)).im := by
  by_cases hk : 0 ≤ k
  · exact mul_pos ((physical_integer_signs β lam g hg k).1 hk)
      ((physical_integer_signs β lam h hh k).1 hk)
  · exact mul_pos_of_neg_of_neg ((physical_integer_signs β lam g hg k).2 (lt_of_not_ge hk))
      ((physical_integer_signs β lam h hh k).2 (lt_of_not_ge hk))

/-- The actual Dyson equation holds at every signed odd frequency. -/
theorem physical_integer_dyson (lam : ℝ≥0) (g : ℝ → ℝ)
    (hphys : PhysicalSolution β lam g) (k : ℤ) :
    (fourier β g (integerFrequency β k)).im *
      (integerFrequency β k + (lam : ℝ) *
        (fourier β (fun t => (g t)^3) (integerFrequency β k)).im) = 1 := by
  have hβ : 0 < β := Fact.out
  have hp (n : ℕ) : (fourier β g (frequency β n)).im *
      (frequency β n + (lam : ℝ) *
        (fourier β (fun t => (g t)^3) (frequency β n)).im) = 1 := by
    rcases physical_scalar_dyson β hβ lam g hphys n with ⟨x, _, he, hd⟩
    rw [he]
    simpa only [Complex.mul_im, Complex.I_re, Complex.I_im, Complex.ofReal_re,
      Complex.ofReal_im, zero_mul, one_mul, zero_add] using hd
  by_cases hk : 0 ≤ k
  · rw [integerFrequency_nonneg β k hk]
    exact hp _
  · rw [integerFrequency_neg β k (lt_of_not_ge hk)]
    rw [fourier_neg_frequency β g, fourier_neg_frequency β (fun t => (g t)^3)]
    simp only [Complex.conj_im]
    nlinarith [hp (-k-1).toNat]

end SYK.Continuum
