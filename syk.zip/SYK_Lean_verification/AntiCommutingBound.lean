import Mathlib.LinearAlgebra.Matrix.PosDef
import Mathlib.LinearAlgebra.Matrix.Trace
import Mathlib.Data.Finset.Powerset
import Mathlib.Tactic

/-!
# The anticommuting-observable bound used in SYK concentration

This file proves the exact square identity for a real linear combination of
anticommuting involutions and the resulting sum-of-squared-expectations bound
for a positive normalized real-linear state. The positivity and normalization
are the definition-level assumptions of a state; the bound is derived, rather
than included as an assumption. No concentration or SYK limit is postulated.
-/

noncomputable section
open scoped BigOperators ComplexOrder

namespace SYK.AntiCommuting

section Algebra

variable {A ι : Type*} [Ring A] [Algebra ℝ A]

omit [Algebra ℝ A] in
/-- Cross terms vanish for the square of two anticommuting elements. -/
theorem add_square_of_anticommute (a b : A) (h : a * b + b * a = 0) :
    (a + b) * (a + b) = a * a + b * b := by
  calc
    (a + b) * (a + b) = a * a + (a * b + b * a) + b * b := by noncomm_ring
    _ = a * a + b * b := by rw [h]; simp

/-- Real rescaling preserves the vanishing anticommutator. -/
theorem scaled_anticommute (a b : A) (r s : ℝ) (h : a * b + b * a = 0) :
    (r • a) * (s • b) + (s • b) * (r • a) = 0 := by
  simp only [smul_mul_assoc, mul_smul_comm, smul_smul]
  rw [mul_comm s r, ← smul_add, h, smul_zero]

/-- The square identity is proved for arbitrary finite subsets, not just a
preselected matrix size. The cross-term hypothesis is ordinary anticommutation. -/
theorem sum_square (s : Finset ι) (U : ι → A) (r : ι → ℝ)
    (hsquare : ∀ i ∈ s, U i * U i = 1)
    (hanti : ∀ i ∈ s, ∀ j ∈ s, i ≠ j → U i * U j + U j * U i = 0) :
    (∑ i ∈ s, r i • U i) * (∑ i ∈ s, r i • U i) =
      (∑ i ∈ s, (r i) ^ 2) • (1 : A) := by
  classical
  revert hsquare hanti
  induction s using Finset.induction_on with
  | empty => intro _ _; simp
  | @insert i s hi ih =>
    intro hsquare hanti
    have hs : ∀ j ∈ s, U j * U j = 1 := fun j hj => hsquare j (Finset.mem_insert_of_mem hj)
    have ha : ∀ j ∈ s, ∀ k ∈ s, j ≠ k → U j * U k + U k * U j = 0 :=
      fun j hj k hk h => hanti j (Finset.mem_insert_of_mem hj)
        k (Finset.mem_insert_of_mem hk) h
    have hcross :
        (r i • U i) * (∑ j ∈ s, r j • U j) +
          (∑ j ∈ s, r j • U j) * (r i • U i) = 0 := by
      rw [Finset.mul_sum, Finset.sum_mul, ← Finset.sum_add_distrib]
      apply Finset.sum_eq_zero
      intro j hj
      apply scaled_anticommute
      exact hanti i (Finset.mem_insert_self i s) j (Finset.mem_insert_of_mem hj)
        (fun h => hi (h.symm ▸ hj))
    simp only [Finset.sum_insert hi]
    rw [add_square_of_anticommute _ _ hcross, ih hs ha]
    rw [smul_mul_assoc, mul_smul_comm, smul_smul, hsquare i (Finset.mem_insert_self i s)]
    rw [← add_smul, pow_two]

omit [Algebra ℝ A] in
/-- A product of three mutually anticommuting involutions has square minus one. -/
theorem triple_square (a b c : A)
    (ha : a * a = 1) (hb : b * b = 1) (hc : c * c = 1)
    (hba : b * a = -(a * b)) (hca : c * a = -(a * c))
    (hcb : c * b = -(b * c)) :
    (a * b * c) * (a * b * c) = -1 := by
  calc
    (a * b * c) * (a * b * c) = a * b * (c * a) * b * c := by noncomm_ring
    _ = a * b * (-(a * c)) * b * c := by rw [hca]
    _ = -(a * (b * a) * (c * b) * c) := by noncomm_ring
    _ = -(a * (-(a * b)) * (-(b * c)) * c) := by rw [hba, hcb]
    _ = -(a * a * (b * b) * (c * c)) := by noncomm_ring
    _ = -1 := by rw [ha, hb, hc]; simp

omit [Algebra ℝ A] in
/-- An outside Majorana anticommutes with a product of three Majoranas. -/
theorem triple_anticommute (a b c d : A)
    (hda : d * a = -(a * d)) (hdb : d * b = -(b * d))
    (hdc : d * c = -(c * d)) :
    d * (a * b * c) = -((a * b * c) * d) := by
  calc
    d * (a * b * c) = (d * a) * b * c := by noncomm_ring
    _ = (-(a * d)) * b * c := by rw [hda]
    _ = -a * (d * b) * c := by noncomm_ring
    _ = -a * (-(b * d)) * c := by rw [hdb]
    _ = a * b * (d * c) := by noncomm_ring
    _ = a * b * (-(c * d)) := by rw [hdc]
    _ = -((a * b * c) * d) := by noncomm_ring

omit [Algebra ℝ A] in
/-- Multiplication by a shared skew-involutive triple turns outside
anticommuting generators into quartic involutions. -/
theorem shared_triple_square (T b : A) (hT : T * T = -1)
    (hb : b * b = 1) (hTb : b * T = -(T * b)) :
    (T * b) * (T * b) = 1 := by
  calc
    (T * b) * (T * b) = T * (b * T) * b := by noncomm_ring
    _ = T * (-(T * b)) * b := by rw [hTb]
    _ = -(T * T) * (b * b) := by noncomm_ring
    _ = 1 := by rw [hT, hb]; simp

omit [Algebra ℝ A] in
/-- Quartics built from the same triple anticommute when their fourth
Majoranas do. This identity is independent of a choice of sorting signs. -/
theorem shared_triple_anticommute (T b c : A)
    (hbT : b * T = -(T * b)) (hcT : c * T = -(T * c))
    (hbc : b * c + c * b = 0) :
    (T * b) * (T * c) + (T * c) * (T * b) = 0 := by
  calc
    (T * b) * (T * c) + (T * c) * (T * b) =
        T * (b * T) * c + T * (c * T) * b := by noncomm_ring
    _ = T * (-(T * b)) * c + T * (-(T * c)) * b := by rw [hbT, hcT]
    _ = -(T * T) * (b * c + c * b) := by noncomm_ring
    _ = 0 := by rw [hbc]; simp

/-- Sorting a product of pairwise anticommuting generators does not change
its squared real-linear expectation, even with fixed left/right factors. This
removes increasing-order sign choices from the concentration estimate. -/
theorem perm_expectation_sq (U : ι → A) (φ : A →ₗ[ℝ] ℝ)
    (hanti : ∀ i j, i ≠ j → U i * U j = -(U j * U i))
    {l k : List ι} (hp : l.Perm k) :
    ∀ a b : A,
      (φ (a * (l.map U).prod * b)) ^ 2 = (φ (a * (k.map U).prod * b)) ^ 2 := by
  induction hp with
  | nil => intro a b; rfl
  | cons i hp ih =>
    intro a b
    simpa only [List.map_cons, List.prod_cons, mul_assoc] using ih (a * U i) b
  | swap i j l =>
    intro a b
    by_cases hij : i = j
    · subst j; rfl
    · simp only [List.map_cons, List.prod_cons]
      have hswap : a * (U j * (U i * (l.map U).prod)) * b =
          -(a * (U i * (U j * (l.map U).prod)) * b) := by
        rw [← mul_assoc (U j) (U i), hanti j i (Ne.symm hij)]
        noncomm_ring
      rw [hswap, map_neg, neg_sq]
  | trans hp hq ihp ihq =>
    intro a b
    exact (ihp a b).trans (ihq a b)

variable [StarRing A] [StarModule ℝ A]

omit [Algebra ℝ A] [StarModule ℝ A] in
/-- The shared triple is skew-adjoint when its three generators are self-adjoint. -/
theorem triple_skewAdjoint (a b c : A)
    (ha : star a = a) (hb : star b = b) (hc : star c = c)
    (hba : b * a = -(a * b)) (hca : c * a = -(a * c))
    (hcb : c * b = -(b * c)) :
    star (a * b * c) = -(a * b * c) := by
  simp only [star_mul, ha, hb, hc]
  calc
    c * (b * a) = (c * b) * a := by noncomm_ring
    _ = (-(b * c)) * a := by rw [hcb]
    _ = -b * (c * a) := by noncomm_ring
    _ = -b * (-(a * c)) := by rw [hca]
    _ = (b * a) * c := by noncomm_ring
    _ = (-(a * b)) * c := by rw [hba]
    _ = -(a * b * c) := by noncomm_ring

omit [Algebra ℝ A] [StarModule ℝ A] in
/-- The quartic product is self-adjoint when the shared triple is skew-adjoint. -/
theorem shared_triple_selfAdjoint (T b : A) (hT : star T = -T)
    (hb : star b = b) (hbT : b * T = -(T * b)) :
    star (T * b) = T * b := by
  simp [star_mul, hT, hb, hbT]

/-- The square-sum state bound, proved by applying positivity to the variance
of the real combination with coefficients equal to its expectations. -/
theorem sum_state_sq_le_one (s : Finset ι) (U : ι → A)
    (φ : A →ₗ[ℝ] ℝ) (hunit : φ 1 = 1)
    (hpositive : ∀ a : A, 0 ≤ φ (star a * a))
    (hself : ∀ i ∈ s, star (U i) = U i)
    (hsquare : ∀ i ∈ s, U i * U i = 1)
    (hanti : ∀ i ∈ s, ∀ j ∈ s, i ≠ j → U i * U j + U j * U i = 0) :
    ∑ i ∈ s, (φ (U i)) ^ 2 ≤ 1 := by
  classical
  let b : A := ∑ i ∈ s, φ (U i) • U i
  let S : ℝ := ∑ i ∈ s, (φ (U i)) ^ 2
  have hstar : star b = b := by
    dsimp [b]
    simp only [star_sum, star_smul, star_trivial]
    apply Finset.sum_congr rfl
    intro i hi
    rw [hself i hi]
  have hb : b * b = S • (1 : A) := sum_square s U (fun i => φ (U i)) hsquare hanti
  have hφb : φ b = S := by
    dsimp [b, S]
    simp only [map_sum, map_smul, smul_eq_mul, pow_two]
  have hφbb : φ (b * b) = S := by rw [hb, map_smul, hunit, smul_eq_mul, mul_one]
  have hvar : 0 ≤ φ ((b - S • (1 : A)) * (b - S • (1 : A))) := by
    simpa only [star_sub, hstar, star_smul, star_trivial, star_one] using
      hpositive (b - S • (1 : A))
  have hexpand :
      φ ((b - S • (1 : A)) * (b - S • (1 : A))) = S - S ^ 2 := by
    simp only [sub_mul, mul_sub, mul_smul_comm, smul_mul_assoc, one_mul, mul_one,
      smul_smul, map_sub, map_smul, hφbb, hφb, hunit, smul_eq_mul]
    ring
  rw [hexpand] at hvar
  dsimp [S] at hvar ⊢
  nlinarith [sq_nonneg ((∑ i ∈ s, (φ (U i)) ^ 2) - 1)]

end Algebra

section Matrices

variable {n ι : Type*} [Fintype n] [DecidableEq n]

/-- A density matrix acts as a real-linear functional via the real part of its
usual trace pairing. Positivity is proved below from matrix positive semidefiniteness. -/
def densityState (ρ : Matrix n n ℂ) : Matrix n n ℂ →ₗ[ℝ] ℝ where
  toFun M := (Matrix.trace (ρ * M)).re
  map_add' A B := by simp [mul_add]
  map_smul' r A := by simp [mul_smul_comm]

@[simp] theorem densityState_apply (ρ M : Matrix n n ℂ) :
    densityState ρ M = (Matrix.trace (ρ * M)).re := rfl

/-- The real part of the trace of a positive semidefinite matrix is nonnegative. -/
theorem trace_re_nonneg {M : Matrix n n ℂ} (hM : M.PosSemidef) :
    0 ≤ (Matrix.trace M).re := by
  simp only [Matrix.trace, Complex.re_sum, Matrix.diag_apply]
  apply Finset.sum_nonneg
  intro i hi
  have hstar : star (Pi.single i (1 : ℂ) : n → ℂ) = (Pi.single i (1 : ℂ) : n → ℂ) := by
    ext j
    by_cases h : j = i
    · subst j; simp
    · simp [Pi.single_apply, h, Ne.symm h]
  simpa [hstar] using hM.re_dotProduct_nonneg (Pi.single i 1)

/-- Positive semidefiniteness of a density matrix supplies positivity on every
star-square; no operator-state positivity assumption remains in the matrix theorem. -/
theorem densityState_positive {ρ : Matrix n n ℂ} (hρ : ρ.PosSemidef)
    (M : Matrix n n ℂ) : 0 ≤ densityState ρ (star M * M) := by
  change 0 ≤ (Matrix.trace (ρ * (M.conjTranspose * M))).re
  rw [Matrix.trace_mul_cycle', ← Matrix.mul_assoc]
  exact trace_re_nonneg (hρ.mul_mul_conjTranspose_same M)

/-- The manuscript's sum-of-squared-expectations bound for an arbitrary finite
family of Hermitian, pairwise anticommuting involutive complex matrices and any
genuine positive semidefinite trace-one density matrix. -/
theorem density_sum_sq_le_one (s : Finset ι) (U : ι → Matrix n n ℂ)
    (ρ : Matrix n n ℂ) (hρ : ρ.PosSemidef) (htrace : Matrix.trace ρ = 1)
    (hself : ∀ i ∈ s, star (U i) = U i)
    (hsquare : ∀ i ∈ s, U i * U i = 1)
    (hanti : ∀ i ∈ s, ∀ j ∈ s, i ≠ j → U i * U j + U j * U i = 0) :
    ∑ i ∈ s, ((Matrix.trace (ρ * U i)).re) ^ 2 ≤ 1 := by
  apply sum_state_sq_le_one s U (densityState ρ)
  · simp [densityState, htrace]
  · exact densityState_positive hρ
  · exact hself
  · exact hsquare
  · exact hanti

/-- Applying the bound to quartic products with three shared Majoranas. All
quartic properties are derived from the generator CAR, not assumed separately. -/
theorem density_common_triple_bound (s : Finset ι) (U : ι → Matrix n n ℂ)
    (ρ : Matrix n n ℂ) (hρ : ρ.PosSemidef) (htrace : Matrix.trace ρ = 1)
    (hself : ∀ i, star (U i) = U i)
    (hsquare : ∀ i, U i * U i = 1)
    (hanti : ∀ i j, i ≠ j → U i * U j = -(U j * U i))
    (a b c : ι) (hab : a ≠ b) (hac : a ≠ c) (hbc : b ≠ c)
    (houtside : ∀ i ∈ s, i ≠ a ∧ i ≠ b ∧ i ≠ c) :
    ∑ i ∈ s, ((Matrix.trace (ρ * (U a * U b * U c * U i))).re) ^ 2 ≤ 1 := by
  let T := U a * U b * U c
  have hT : T * T = -1 :=
    triple_square (U a) (U b) (U c) (hsquare a) (hsquare b) (hsquare c)
      (hanti b a hab.symm) (hanti c a hac.symm) (hanti c b hbc.symm)
  have hTstar : star T = -T :=
    triple_skewAdjoint (U a) (U b) (U c) (hself a) (hself b) (hself c)
      (hanti b a hab.symm) (hanti c a hac.symm) (hanti c b hbc.symm)
  have hout (i : ι) (hi : i ∈ s) : U i * T = -(T * U i) := by
    obtain ⟨hia, hib, hic⟩ := houtside i hi
    exact triple_anticommute (U a) (U b) (U c) (U i)
      (hanti i a hia) (hanti i b hib) (hanti i c hic)
  apply density_sum_sq_le_one s (fun i => T * U i) ρ hρ htrace
  · intro i hi
    exact shared_triple_selfAdjoint T (U i) hTstar (hself i) (hout i hi)
  · intro i hi
    exact shared_triple_square T (U i) hT (hsquare i) (hout i hi)
  · intro i hi j hj hij
    apply shared_triple_anticommute T (U i) (U j) (hout i hi) (hout j hj)
    rw [hanti i j hij, neg_add_cancel]

/-- Scaling the common-triple quartics to the manuscript's normalization
OI = cI/4 gives the per-triple bound 1/16. -/
theorem density_normalized_common_triple_bound
    (s : Finset ι) (U : ι → Matrix n n ℂ)
    (ρ : Matrix n n ℂ) (hρ : ρ.PosSemidef) (htrace : Matrix.trace ρ = 1)
    (hself : ∀ i, star (U i) = U i)
    (hsquare : ∀ i, U i * U i = 1)
    (hanti : ∀ i j, i ≠ j → U i * U j = -(U j * U i))
    (a b c : ι) (hab : a ≠ b) (hac : a ≠ c) (hbc : b ≠ c)
    (houtside : ∀ i ∈ s, i ≠ a ∧ i ≠ b ∧ i ≠ c) :
    ∑ i ∈ s, ((Matrix.trace
      (ρ * ((1 / 4 : ℝ) • (U a * U b * U c * U i)))).re) ^ 2 ≤ 1 / 16 := by
  have h := density_common_triple_bound s U ρ hρ htrace hself hsquare hanti
    a b c hab hac hbc houtside
  have hscaled := mul_le_mul_of_nonneg_left h (by norm_num : (0 : ℝ) ≤ 1 / 16)
  have heq :
      (∑ i ∈ s, ((Matrix.trace
        (ρ * ((1 / 4 : ℝ) • (U a * U b * U c * U i)))).re) ^ 2) =
      (1 / 16 : ℝ) * ∑ i ∈ s,
        ((Matrix.trace (ρ * (U a * U b * U c * U i))).re) ^ 2 := by
    rw [Finset.mul_sum]
    apply Finset.sum_congr rfl
    intro i hi
    simp only [mul_smul_comm, Matrix.trace_smul, Complex.real_smul, Complex.mul_re,
      Complex.ofReal_re, Complex.ofReal_im, zero_mul, sub_zero]
    ring
  rw [heq]
  simpa using hscaled

end Matrices

section Counting

variable {ι : Type*} [DecidableEq ι]

/-- A four-set contains exactly four three-subsets, also when enumerated inside
a larger ambient finite set. This is the fourfold counting used in Section 10. -/
theorem count_triples_in_fourset (s I : Finset ι) (hIs : I ⊆ s) (hI : I.card = 4) :
    ((s.powersetCard 3).filter (fun K => K ⊆ I)).card = 4 := by
  have heq : (s.powersetCard 3).filter (fun K => K ⊆ I) = I.powersetCard 3 := by
    ext K
    simp only [Finset.mem_filter, Finset.mem_powersetCard]
    exact ⟨fun h => ⟨h.2, h.1.2⟩, fun h => ⟨⟨h.1.trans hIs, h.2⟩, h.1⟩⟩
  rw [heq, Finset.card_powersetCard, hI]
  norm_num

/-- Summing the per-triple bound 1/16 counts each quartic weight four times,
giving exactly binomial(N,3)/64. No sign or positivity assumption on the
individual weights is needed for this finite combinatorial implication. -/
theorem quartic_sum_bound_of_triple_bounds (s : Finset ι) (w : Finset ι → ℝ)
    (hbound : ∀ K ∈ s.powersetCard 3,
      ∑ I ∈ s.powersetCard 4, (if K ⊆ I then w I else 0) ≤ 1 / 16) :
    ∑ I ∈ s.powersetCard 4, w I ≤ (Nat.choose s.card 3 : ℝ) / 64 := by
  have hsum := Finset.sum_le_sum hbound
  have hdouble :
      (∑ K ∈ s.powersetCard 3,
        ∑ I ∈ s.powersetCard 4, (if K ⊆ I then w I else 0)) =
      4 * ∑ I ∈ s.powersetCard 4, w I := by
    rw [Finset.sum_comm, Finset.mul_sum]
    apply Finset.sum_congr rfl
    intro I hI
    obtain ⟨hIs, hcard⟩ := Finset.mem_powersetCard.mp hI
    rw [← Finset.sum_filter]
    simp only [Finset.sum_const, count_triples_in_fourset s I hIs hcard,
      nsmul_eq_mul, Nat.cast_ofNat]
  rw [hdouble] at hsum
  simp only [Finset.sum_const, Finset.card_powersetCard, nsmul_eq_mul] at hsum
  linarith

end Counting

end SYK.AntiCommuting
