import Mathlib.Analysis.NormedSpace.OperatorNorm.Basic
import Mathlib.Analysis.Complex.Basic
import Mathlib.Analysis.InnerProductSpace.Defs
import Mathlib.Analysis.CStarAlgebra.Basic
import Mathlib.Algebra.Order.Archimedean.Basic
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.Ring

/-!
# The bounded-orbit argument in Section 8

The manuscript's Cauchy--Schwarz iteration is proved here before any quotient
by null vectors. We use an equivalent elementary iteration: if an orbit starts
strictly above its value at zero, the quadratic inequality forces unbounded
linear growth along its doubled times. This avoids fractional powers and proves
the zero-seminorm case separately.

The functional and action hypotheses below are explicit analytic obligations.
This file does not construct the manuscript's limiting functional, Banach algebra,
or completed GNS Hilbert space. It introduces no axioms and contains no `sorry`.
-/

namespace SYK.TranslationContraction

/-- A bounded real sequence satisfying `x n ^ 2 ≤ a * x (n+1)`
cannot start above the nonnegative constant `a`. The case `a = 0` is included;
nonnegativity of the sequence is not needed for this stronger statement. -/
theorem bounded_quadratic_sequence_le
    (a : ℝ) (x : ℕ → ℝ) (ha : 0 ≤ a)
    (hquadratic : ∀ n, x n ^ 2 ≤ a * x (n + 1))
    (M : ℝ) (hbounded : ∀ n, x n ≤ M) : x 0 ≤ a := by
  by_cases hazero : a = 0
  · have h := hquadratic 0
    rw [hazero, zero_mul] at h
    nlinarith [sq_nonneg (x 0)]
  · have hapos : 0 < a := lt_of_le_of_ne ha (Ne.symm hazero)
    by_contra hnot
    have hstart : a < x 0 := lt_of_not_ge hnot
    have hdelta : 0 < x 0 - a := sub_pos.mpr hstart
    have hstep (n : ℕ) : 2 * x n - a ≤ x (n + 1) := by
      apply (mul_le_mul_left hapos).mp
      calc
        a * (2 * x n - a) ≤ x n ^ 2 := by nlinarith [sq_nonneg (x n - a)]
        _ ≤ a * x (n + 1) := hquadratic n
    have hgrowth (n : ℕ) : x 0 + (n : ℝ) * (x 0 - a) ≤ x n := by
      induction n with
      | zero => simp
      | succ n ih =>
        have hn : 0 ≤ (n : ℝ) * (x 0 - a) :=
          mul_nonneg (Nat.cast_nonneg _) hdelta.le
        rw [Nat.cast_succ]
        nlinarith [hstep n]
    obtain ⟨n, hn⟩ := exists_nat_gt (M / (x 0 - a))
    have hn' : M < (n : ℝ) * (x 0 - a) := (div_lt_iff₀ hdelta).mp hn
    linarith [hgrowth n, hbounded n]

/-- The bounded doubled-time orbit contracts to its zero-time value.
Only boundedness along the particular doubled orbit is required. -/
theorem bounded_doubling_orbit_le
    (q : ℝ → ℝ) (hq : ∀ t, 0 ≤ q t)
    (hquadratic : ∀ t, q t ^ 2 ≤ q 0 * q (2 * t))
    (u M : ℝ) (hbounded : ∀ n : ℕ, q ((2 : ℝ) ^ n * u) ≤ M) :
    q u ≤ q 0 := by
  have h := bounded_quadratic_sequence_le (q 0)
    (fun n => q ((2 : ℝ) ^ n * u)) (hq 0)
    (fun n => by
      have ht : (2 : ℝ) ^ (n + 1) * u = 2 * ((2 : ℝ) ^ n * u) := by
        rw [pow_succ]
        ring
      simpa only [ht] using hquadratic ((2 : ℝ) ^ n * u)) M hbounded
  simpa using h

/-- In particular, a zero initial value forces every bounded orbit value to
vanish. No division by the initial seminorm is used. -/
theorem bounded_doubling_orbit_null
    (q : ℝ → ℝ) (hq : ∀ t, 0 ≤ q t)
    (hquadratic : ∀ t, q t ^ 2 ≤ q 0 * q (2 * t))
    (hzero : q 0 = 0) (u M : ℝ)
    (hbounded : ∀ n : ℕ, q ((2 : ℝ) ^ n * u) ≤ M) : q u = 0 := by
  have h := bounded_doubling_orbit_le q hq hquadratic u M hbounded
  rw [hzero] at h
  exact le_antisymm h (hq u)

/-- Abstract contractivity before quotienting: `p` may be the squared
reflection seminorm. Uniform orbit boundedness and the doubled-time inequality
are the only analytic inputs. -/
theorem bounded_action_contractive {A : Type*}
    (p : A → ℝ) (α : ℝ → A → A)
    (hzero : ∀ a, α 0 a = a) (hp : ∀ a, 0 ≤ p a)
    (hquadratic : ∀ u a, p (α u a) ^ 2 ≤ p a * p (α (2 * u) a))
    (hbounded : ∀ a, ∃ M, ∀ u, p (α u a) ≤ M)
    (u : ℝ) (a : A) : p (α u a) ≤ p a := by
  obtain ⟨M, hM⟩ := hbounded a
  have h := bounded_doubling_orbit_le (fun t => p (α t a))
    (fun t => hp _) (fun t => by simpa only [hzero] using hquadratic t a)
    u M (fun n => hM _)
  simpa only [hzero] using h

/-- The zero subspace is invariant, as required before defining translations
on the GNS quotient. -/
theorem bounded_action_preserves_null {A : Type*}
    (p : A → ℝ) (α : ℝ → A → A)
    (hzero : ∀ a, α 0 a = a) (hp : ∀ a, 0 ≤ p a)
    (hquadratic : ∀ u a, p (α u a) ^ 2 ≤ p a * p (α (2 * u) a))
    (hbounded : ∀ a, ∃ M, ∀ u, p (α u a) ≤ M)
    (u : ℝ) (a : A) (ha : p a = 0) : p (α u a) = 0 := by
  apply le_antisymm _ (hp _)
  rw [← ha]
  exact bounded_action_contractive p α hzero hp hquadratic hbounded u a

/-- Contractivity for both signs of time and the action law imply exact
preservation of the reflection seminorm, still before taking a quotient. -/
theorem bounded_action_preserves {A : Type*}
    (p : A → ℝ) (α : ℝ → A → A)
    (hzero : ∀ a, α 0 a = a)
    (hadd : ∀ u v a, α (u + v) a = α u (α v a))
    (hp : ∀ a, 0 ≤ p a)
    (hquadratic : ∀ u a, p (α u a) ^ 2 ≤ p a * p (α (2 * u) a))
    (hbounded : ∀ a, ∃ M, ∀ u, p (α u a) ≤ M)
    (u : ℝ) (a : A) : p (α u a) = p a := by
  apply le_antisymm (bounded_action_contractive p α hzero hp hquadratic hbounded u a)
  have h := bounded_action_contractive p α hzero hp hquadratic hbounded (-u) (α u a)
  simpa only [← hadd, neg_add_cancel, hzero] using h


section ReflectionFunctional

variable {A : Type*} [NormedRing A] [NormedAlgebra ℂ A]
  [StarRing A] [StarModule ℂ A] [NormedStarGroup A]

/-- Reality of all diagonal values of a complex sesquilinear reflection form
already forces Hermitian symmetry. This is proved by testing `a + b` and
`a + I • b`; it is not an additional symmetry assumption. -/
theorem reflection_pairing_conj_symm
    (L : A →L[ℂ] ℂ) (hreal : ∀ a, (L (star a * a)).im = 0)
    (a b : A) : star (L (star b * a)) = L (star a * b) := by
  have hexpand : L (star (a + b) * (a + b)) =
      L (star a * a) + L (star a * b) +
        L (star b * a) + L (star b * b) := by
    simp only [star_add, add_mul, mul_add, map_add]
    ring
  have hiexpand : L (star (a + Complex.I • b) * (a + Complex.I • b)) =
      L (star a * a) + Complex.I * L (star a * b) -
        Complex.I * L (star b * a) + L (star b * b) := by
    simp only [star_add, star_smul, add_mul, mul_add, smul_mul_assoc,
      mul_smul_comm, map_add, map_smul, smul_eq_mul,
      Complex.star_def, Complex.conj_I]
    ring_nf
    simp [Complex.I_sq, add_assoc]
  have hsum := hreal (a + b)
  rw [hexpand] at hsum
  simp only [Complex.add_im, hreal] at hsum
  have hdiff := hreal (a + Complex.I • b)
  rw [hiexpand] at hdiff
  simp only [Complex.add_im, Complex.sub_im, Complex.mul_im,
    Complex.I_re, Complex.I_im, zero_mul, one_mul, zero_add, hreal] at hdiff
  apply Complex.ext
  · simp only [Complex.star_def, Complex.conj_re]
    linarith
  · simp only [Complex.star_def, Complex.conj_im]
    linarith

/-- A positive continuous reflection functional gives a semidefinite inner
product core on the algebra itself, prior to quotienting by null vectors. The
usual Banach algebra norm is not replaced with the reflection seminorm. -/
def reflectionCore
    (L : A →L[ℂ] ℂ) (hreal : ∀ a, (L (star a * a)).im = 0)
    (hpositive : ∀ a, 0 ≤ (L (star a * a)).re) :
    PreInnerProductSpace.Core ℂ A where
  inner a b := L (star a * b)
  conj_inner_symm a b := reflection_pairing_conj_symm L hreal a b
  re_inner_nonneg := hpositive
  add_left a b c := by simp only [star_add, add_mul, map_add]
  smul_left a b r := by
    simp only [star_smul, smul_mul_assoc, map_smul, smul_eq_mul, Complex.star_def]

/-- Cauchy--Schwarz is available on the algebra before the null quotient.
It is obtained from mathlib's semidefinite inner product core theorem. -/
theorem reflection_cauchy_schwarz
    (L : A →L[ℂ] ℂ) (hreal : ∀ a, (L (star a * a)).im = 0)
    (hpositive : ∀ a, 0 ≤ (L (star a * a)).re)
    (a b : A) :
    ‖L (star a * b)‖ ^ 2 ≤ (L (star a * a)).re * (L (star b * b)).re := by
  letI : PreInnerProductSpace.Core ℂ A := reflectionCore L hreal hpositive
  have h := InnerProductSpace.Core.inner_mul_inner_self_le (𝕜 := ℂ) a b
  change ‖L (star a * b)‖ * ‖L (star b * a)‖ ≤
    (L (star a * a)).re * (L (star b * b)).re at h
  have hn : ‖L (star b * a)‖ = ‖L (star a * b)‖ := by
    calc
      ‖L (star b * a)‖ = ‖star (L (star b * a))‖ := by rw [norm_star]
      _ = ‖L (star a * b)‖ := congrArg norm (reflection_pairing_conj_symm L hreal a b)
  simpa only [hn, pow_two] using h

/-- Continuity of the functional and the isometric star operation bound the
squared reflection seminorm by a fixed multiple of the Banach norm squared.
The manuscript has the stronger normalization `‖L‖ ≤ 1`; finiteness suffices
for the contraction argument. -/
theorem reflection_square_bound (L : A →L[ℂ] ℂ) (a : A) :
    (L (star a * a)).re ≤ ‖L‖ * ‖a‖ ^ 2 := by
  calc
    (L (star a * a)).re ≤ ‖L (star a * a)‖ := Complex.re_le_norm _
    _ ≤ ‖L‖ * ‖star a * a‖ := L.le_opNorm _
    _ ≤ ‖L‖ * (‖star a‖ * ‖a‖) :=
      mul_le_mul_of_nonneg_left (norm_mul_le _ _) (norm_nonneg _)
    _ = ‖L‖ * ‖a‖ ^ 2 := by rw [norm_star, pow_two]

/-- Invariance of the functional and reversal by reflection make each
translation symmetric for the reflection form. -/
theorem reflection_action_symmetric
    (L : A →L[ℂ] ℂ) (α : ℝ → A ≃ₐ[ℂ] A)
    (hzero : ∀ a, α 0 a = a)
    (hadd : ∀ u v a, α (u + v) a = α u (α v a))
    (hinvariant : ∀ u a, L (α u a) = L a)
    (hreversal : ∀ u a, star (α u a) = α (-u) (star a))
    (u : ℝ) (a b : A) : L (star (α u a) * b) = L (star a * α u b) := by
  calc
    L (star (α u a) * b) = L (α (-u) (star a) * b) := by rw [hreversal]
    _ = L (α u (α (-u) (star a) * b)) := (hinvariant u _).symm
    _ = L (α u (α (-u) (star a)) * α u b) := by rw [map_mul]
    _ = L (star a * α u b) := by rw [← hadd, add_neg_cancel, hzero]

/-- The manuscript's doubled-time inequality, for the squared reflection
seminorm, follows from symmetry and semidefinite Cauchy--Schwarz. -/
theorem reflection_action_quadratic
    (L : A →L[ℂ] ℂ) (hreal : ∀ a, (L (star a * a)).im = 0)
    (hpositive : ∀ a, 0 ≤ (L (star a * a)).re)
    (α : ℝ → A ≃ₐ[ℂ] A)
    (hzero : ∀ a, α 0 a = a)
    (hadd : ∀ u v a, α (u + v) a = α u (α v a))
    (hinvariant : ∀ u a, L (α u a) = L a)
    (hreversal : ∀ u a, star (α u a) = α (-u) (star a))
    (u : ℝ) (a : A) :
    (L (star (α u a) * α u a)).re ^ 2 ≤
      (L (star a * a)).re * (L (star (α (2 * u) a) * α (2 * u) a)).re := by
  have hsym := reflection_action_symmetric L α hzero hadd hinvariant hreversal u a (α u a)
  have htime : α u (α u a) = α (2 * u) a := by
    rw [← hadd]
    congr 2
    ring
  rw [htime] at hsym
  have hCS := reflection_cauchy_schwarz L hreal hpositive a (α (2 * u) a)
  have hsquare : (L (star (α u a) * α u a)).re ^ 2 ≤
      ‖L (star (α u a) * α u a)‖ ^ 2 := by
    have h := Complex.sq_norm_sub_sq_re (L (star (α u a) * α u a))
    nlinarith [sq_nonneg (L (star (α u a) * α u a)).im]
  calc
    (L (star (α u a) * α u a)).re ^ 2 ≤
        ‖L (star (α u a) * α u a)‖ ^ 2 := hsquare
    _ = ‖L (star a * α (2 * u) a)‖ ^ 2 := by rw [hsym]
    _ ≤ _ := hCS

/-- Main pre-quotient result: an isometric algebra action that preserves the
positive functional and is reversed by the involution preserves the squared
reflection seminorm exactly. In particular it contracts and preserves null
vectors, without presupposing that an action on a GNS quotient exists. -/
theorem reflection_action_preserves_square
    (L : A →L[ℂ] ℂ) (hreal : ∀ a, (L (star a * a)).im = 0)
    (hpositive : ∀ a, 0 ≤ (L (star a * a)).re)
    (α : ℝ → A ≃ₐ[ℂ] A)
    (hzero : ∀ a, α 0 a = a)
    (hadd : ∀ u v a, α (u + v) a = α u (α v a))
    (hinvariant : ∀ u a, L (α u a) = L a)
    (hreversal : ∀ u a, star (α u a) = α (-u) (star a))
    (hisometric : ∀ u a, ‖α u a‖ = ‖a‖)
    (u : ℝ) (a : A) :
    (L (star (α u a) * α u a)).re = (L (star a * a)).re := by
  apply bounded_action_preserves (fun b => (L (star b * b)).re)
    (fun t b => α t b) hzero hadd hpositive
  · exact reflection_action_quadratic L hreal hpositive α hzero hadd hinvariant hreversal
  · intro b
    refine ⟨‖L‖ * ‖b‖ ^ 2, ?_⟩
    intro t
    simpa only [hisometric] using reflection_square_bound L (α t b)

/-- The actual reflection seminorm is the square root of its nonnegative
quadratic form and is therefore preserved as well. -/
theorem reflection_action_preserves_seminorm
    (L : A →L[ℂ] ℂ) (hreal : ∀ a, (L (star a * a)).im = 0)
    (hpositive : ∀ a, 0 ≤ (L (star a * a)).re)
    (α : ℝ → A ≃ₐ[ℂ] A)
    (hzero : ∀ a, α 0 a = a)
    (hadd : ∀ u v a, α (u + v) a = α u (α v a))
    (hinvariant : ∀ u a, L (α u a) = L a)
    (hreversal : ∀ u a, star (α u a) = α (-u) (star a))
    (hisometric : ∀ u a, ‖α u a‖ = ‖a‖)
    (u : ℝ) (a : A) :
    Real.sqrt (L (star (α u a) * α u a)).re = Real.sqrt (L (star a * a)).re := by
  rw [reflection_action_preserves_square L hreal hpositive α hzero hadd hinvariant hreversal hisometric]


/-- Expansion of the reflection quadratic form of a difference. -/
theorem reflection_square_sub
    (L : A →L[ℂ] ℂ) (hreal : ∀ a, (L (star a * a)).im = 0)
    (a b : A) :
    (L (star (a - b) * (a - b))).re =
      (L (star a * a)).re + (L (star b * b)).re - 2 * (L (star a * b)).re := by
  have h := congrArg Complex.re (reflection_pairing_conj_symm L hreal a b)
  simp only [Complex.star_def, Complex.conj_re] at h
  simp only [star_sub, sub_mul, mul_sub, map_sub, Complex.sub_re]
  linarith

/-- The half-translation argument already gives stationarity modulo null
vectors in the algebra. This proves the pre-quotient content of Lemma 8.1
without assuming a well-defined Hilbert-space action in advance. -/
theorem reflection_translation_difference_null
    (L : A →L[ℂ] ℂ) (hreal : ∀ a, (L (star a * a)).im = 0)
    (hpositive : ∀ a, 0 ≤ (L (star a * a)).re)
    (α : ℝ → A ≃ₐ[ℂ] A)
    (hzero : ∀ a, α 0 a = a)
    (hadd : ∀ u v a, α (u + v) a = α u (α v a))
    (hinvariant : ∀ u a, L (α u a) = L a)
    (hreversal : ∀ u a, star (α u a) = α (-u) (star a))
    (hisometric : ∀ u a, ‖α u a‖ = ‖a‖)
    (u : ℝ) (a : A) :
    (L (star (α u a - a) * (α u a - a))).re = 0 := by
  have hhalf : u / 2 + u / 2 = u := by ring
  have hcompose : α (u / 2) (α (u / 2) a) = α u a := by
    rw [← hadd, hhalf]
  have hsym := reflection_action_symmetric L α hzero hadd hinvariant hreversal
    (u / 2) (α (u / 2) a) a
  rw [hcompose] at hsym
  have hpair : (L (star (α u a) * a)).re = (L (star a * a)).re := by
    rw [hsym]
    exact reflection_action_preserves_square L hreal hpositive α hzero hadd
      hinvariant hreversal hisometric (u / 2) a
  rw [reflection_square_sub L hreal,
    reflection_action_preserves_square L hreal hpositive α hzero hadd
      hinvariant hreversal hisometric u a, hpair]
  ring

/-- The quotient relation used to identify algebra vectors differing by a
null vector. This is only an algebra-vector quotient, not a claim that the
completed GNS Hilbert space has been constructed in this file. -/
def reflectionNullRelation (L : A →L[ℂ] ℂ) (a b : A) : Prop :=
  (L (star (a - b) * (a - b))).re = 0

/-- Every translated algebra vector has the same class in the quotient by
null differences. The proof uses the contraction and half-time results above. -/
theorem reflection_translation_class_stationary
    (L : A →L[ℂ] ℂ) (hreal : ∀ a, (L (star a * a)).im = 0)
    (hpositive : ∀ a, 0 ≤ (L (star a * a)).re)
    (α : ℝ → A ≃ₐ[ℂ] A)
    (hzero : ∀ a, α 0 a = a)
    (hadd : ∀ u v a, α (u + v) a = α u (α v a))
    (hinvariant : ∀ u a, L (α u a) = L a)
    (hreversal : ∀ u a, star (α u a) = α (-u) (star a))
    (hisometric : ∀ u a, ‖α u a‖ = ‖a‖)
    (u : ℝ) (a : A) :
    Quot.mk (reflectionNullRelation L) (α u a) = Quot.mk (reflectionNullRelation L) a := by
  apply Quot.sound
  exact reflection_translation_difference_null L hreal hpositive α hzero hadd
    hinvariant hreversal hisometric u a

end ReflectionFunctional

end SYK.TranslationContraction
