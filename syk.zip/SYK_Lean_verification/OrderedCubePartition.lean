import OrderedSimplexIntegral
import Mathlib.Data.Fin.Tuple.Sort

/-!
# Actual Lebesgue cube decomposition into ordering regions

Every interaction-time cube splits, modulo the explicitly proved null collision
and endpoint sets, into disjoint strict ordering chambers indexed by finite
permutations. Change of variables preserves genuine Lebesgue product measure.
-/

noncomputable section
open scoped BigOperators
open MeasureTheory MeasureTheory.Measure Set
open SYK.OrderedSimplexIntegral

namespace SYK.OrderedCubePartition

/-- The full, labelled interaction-time cube. -/
def timeCube (n : ℕ) (a b : ℝ) : Set (Fin n → ℝ) :=
  univ.pi (fun _ => Icc a b)

/-- Permute actual time coordinates. -/
def timePermutation {n : ℕ} (σ : Equiv.Perm (Fin n)) :
    (Fin n → ℝ) ≃ᵐ (Fin n → ℝ) :=
  MeasurableEquiv.piCongrLeft (fun _ => ℝ) σ.symm

@[simp] theorem timePermutation_apply {n : ℕ} (σ : Equiv.Perm (Fin n)) (u : Fin n → ℝ) :
    timePermutation σ u = u ∘ σ := by
  ext i
  simp [timePermutation, MeasurableEquiv.coe_piCongrLeft, Equiv.piCongrLeft_apply]

theorem timePermutation_measurePreserving {n : ℕ} (σ : Equiv.Perm (Fin n)) :
    MeasurePreserving (timePermutation σ) volume volume :=
  volume_measurePreserving_piCongrLeft (fun _ : Fin n => ℝ) σ.symm

/-- One strictly ordered chamber, retaining the original labels. -/
def orderingRegion {n : ℕ} (a b : ℝ) (σ : Equiv.Perm (Fin n)) : Set (Fin n → ℝ) :=
  timePermutation σ ⁻¹' strictOrderedSimplex n a b

theorem strictOrderedSimplex_measurable (n : ℕ) (a b : ℝ) :
    MeasurableSet (strictOrderedSimplex n a b) := by
  have h₁ := MeasurableSet.iInter (fun i : Fin n =>
    (isOpen_lt (f := fun _ : Fin n → ℝ => a) continuous_const (continuous_apply i)).measurableSet)
  have h₂ := MeasurableSet.iInter (fun i : Fin n =>
    (isOpen_lt (g := fun _ : Fin n → ℝ => b) (continuous_apply i) continuous_const).measurableSet)
  have h₃ := MeasurableSet.iInter (fun i : Fin n => MeasurableSet.iInter (fun j : Fin n =>
    MeasurableSet.iInter (fun _ : i < j => (isOpen_lt
      (f := fun u : Fin n → ℝ => u j) (continuous_apply j) (continuous_apply i)).measurableSet)))
  convert h₁.inter (h₂.inter h₃) using 1
  ext u
  simp [strictOrderedSimplex, StrictAnti]

theorem orderingRegion_measurable {n : ℕ} (a b : ℝ) (σ : Equiv.Perm (Fin n)) :
    MeasurableSet (orderingRegion a b σ) :=
  (strictOrderedSimplex_measurable n a b).preimage (timePermutation σ).measurable

theorem orderingRegion_subset_cube {n : ℕ} (a b : ℝ) (σ : Equiv.Perm (Fin n)) :
    orderingRegion a b σ ⊆ timeCube n a b := by
  intro u hu i _
  simp only [orderingRegion, mem_preimage, timePermutation_apply] at hu
  simpa using And.intro (hu.1 (σ.symm i)).le (hu.2.1 (σ.symm i)).le

/-- Strict chambers are genuinely disjoint, not only almost disjoint. -/
theorem orderingRegion_pairwise_disjoint (n : ℕ) (a b : ℝ) :
    Pairwise (fun σ τ : Equiv.Perm (Fin n) => Disjoint (orderingRegion a b σ) (orderingRegion a b τ)) := by
  intro σ τ hστ
  rw [disjoint_left]
  intro u hσ hτ
  simp only [orderingRegion, mem_preimage, timePermutation_apply] at hσ
  simp only [orderingRegion, mem_preimage, timePermutation_apply] at hτ
  have hu : Function.Injective u := by
    intro i j hij
    apply σ.symm.injective
    apply hσ.2.2.injective
    simpa using hij
  have heq := Tuple.unique_antitone hσ.2.2.antitone hτ.2.2.antitone
  exact hστ (Equiv.ext fun i => hu (congrFun heq i))

/-- Sorting gives an exhaustive partition away from the null tie/endpoints. -/
theorem orderingRegion_union_ae_cube (n : ℕ) (a b : ℝ) :
    (⋃ σ : Equiv.Perm (Fin n), orderingRegion a b σ) =ᵐ[volume] timeCube n a b := by
  filter_upwards [ae_injective_times n, ae_times_avoid n a, ae_times_avoid n b] with u hu ha hb
  apply propext
  constructor
  · intro h
    rcases mem_iUnion.mp h with ⟨σ, hσ⟩
    exact orderingRegion_subset_cube a b σ hσ
  · intro h
    let σ : Equiv.Perm (Fin n) := Tuple.sort (fun i => OrderDual.toDual (u i))
    apply mem_iUnion.mpr
    refine ⟨σ, ?_⟩
    simp only [orderingRegion, mem_preimage, timePermutation_apply]
    refine ⟨?_, ?_, ?_⟩
    · intro i
      exact lt_of_le_of_ne (h (σ i) (mem_univ _)).1 (ha (σ i)).symm
    · intro i
      exact lt_of_le_of_ne (h (σ i) (mem_univ _)).2 (hb (σ i))
    · have hm : Antitone (u ∘ σ) := Tuple.monotone_sort (fun i => OrderDual.toDual (u i))
      exact hm.strictAnti_of_injective (hu.comp σ.injective)

/-- Each labelled chamber has exactly the computed simplex volume. -/
theorem orderingRegion_volume {n : ℕ} (a b : ℝ) (hab : a ≤ b) (σ : Equiv.Perm (Fin n)) :
    volume (orderingRegion a b σ) = ENNReal.ofReal ((b-a)^n / n.factorial) := by
  rw [orderingRegion,
    (timePermutation_measurePreserving σ).measure_preimage
      (strictOrderedSimplex_measurable n a b).nullMeasurableSet,
    strictOrderedSimplex_volume n a b hab]

section Integrals
variable {E : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E]

/-- The change of labels in a chamber is an actual measure-preserving
change of variables, valid for every Bochner integrand. -/
theorem integral_orderingRegion {n : ℕ} (a b : ℝ) (σ : Equiv.Perm (Fin n))
    (f : (Fin n → ℝ) → E) :
    ∫ u in orderingRegion a b σ, f u =
      ∫ u in orderedSimplex n a b, f (u ∘ σ.symm) := by
  have h := (timePermutation_measurePreserving σ).setIntegral_preimage_emb
    (timePermutation σ).measurableEmbedding (fun u => f (u ∘ σ.symm))
    (strictOrderedSimplex n a b)
  rw [setIntegral_congr_set (strictOrderedSimplex_ae_eq n a b)] at h
  simpa only [orderingRegion, timePermutation_apply, Function.comp_assoc,
    Equiv.self_comp_symm, Function.comp_id] using h

/-- Finite permutation decomposition of an integrable, possibly
noncommutative-matrix-valued history on the actual interaction-time cube. -/
theorem integral_cube_eq_sum_ordered {n : ℕ} (a b : ℝ) (f : (Fin n → ℝ) → E)
    (hf : IntegrableOn f (timeCube n a b)) :
    ∫ u in timeCube n a b, f u =
      ∑ σ : Equiv.Perm (Fin n), ∫ u in orderedSimplex n a b, f (u ∘ σ.symm) := by
  rw [← setIntegral_congr_set (orderingRegion_union_ae_cube n a b),
    integral_fintype_iUnion (orderingRegion_measurable a b)
      (orderingRegion_pairwise_disjoint n a b)
      (fun σ => hf.mono_set (orderingRegion_subset_cube a b σ))]
  exact Finset.sum_congr rfl (fun σ _ => integral_orderingRegion a b σ f)

/-- A symmetric history has the familiar factorial relation, derived from
all labelled ordering chambers rather than postulated. -/
theorem integral_cube_eq_factorial_smul_ordered {n : ℕ} (a b : ℝ)
    (f : (Fin n → ℝ) → E) (hf : IntegrableOn f (timeCube n a b))
    (hsym : ∀ (σ : Equiv.Perm (Fin n)) u, f (u ∘ σ) = f u) :
    ∫ u in timeCube n a b, f u = n.factorial • ∫ u in orderedSimplex n a b, f u := by
  rw [integral_cube_eq_sum_ordered a b f hf]
  simp_rw [hsym]
  simp [Fintype.card_perm]

end Integrals
end SYK.OrderedCubePartition
