import OnShellAction
import Pressure
import CouplingContinuity
import Mathlib.Analysis.Calculus.Deriv.Slope
import Mathlib.Analysis.SpecialFunctions.Pow.Deriv

/-!
# Variational envelope without differentiating the physical solution

The scalar squeeze theorem is applied below to the actual infinite-mode action.
Only continuity of the quartic integral is used; it was derived independently
from actual SD compactness and uniqueness.
-/

set_option maxHeartbeats 1000000
noncomputable section
open MeasureTheory Set Filter
open scoped BigOperators Topology NNReal
namespace SYK.Continuum

/-- Two comparison inequalities imply the envelope derivative, with no
assumption that the optimizing argument itself is differentiable. -/
theorem hasDerivAt_of_two_comparisons (F c Q : ℝ → ℝ) (t c' : ℝ) (ht : 0 < t)
    (hc : HasDerivAt c c' t) (hQ : ContinuousAt Q t)
    (hcomp : ∀ s, 0 < s →
      (c t-c s)*Q t ≤ F s-F t ∧ F s-F t ≤ (c t-c s)*Q s) :
    HasDerivAt F (-c' * Q t) t := by
  apply hasDerivAt_iff_tendsto_slope.mpr
  have hct := (hasDerivAt_iff_tendsto_slope.mp hc).neg
  have hQt : Tendsto Q (𝓝[≠] t) (𝓝 (Q t)) := hQ.mono_left inf_le_left
  have hA := hct.mul (tendsto_const_nhds (x := Q t))
  have hB := hct.mul hQt
  have hmin := hA.min hB
  have hmax := hA.max hB
  simp only [min_self] at hmin
  simp only [max_self] at hmax
  have hbounds : ∀ᶠ s in 𝓝[≠] t,
      min (-slope c t s * Q t) (-slope c t s * Q s) ≤ slope F t s ∧
      slope F t s ≤ max (-slope c t s * Q t) (-slope c t s * Q s) := by
    have hnear : ∀ᶠ s in 𝓝[≠] t, 0 < s :=
      (eventually_gt_nhds ht).filter_mono inf_le_left
    filter_upwards [hnear] with s hs
    obtain ⟨hl,hu⟩ := hcomp s hs
    have hF : slope F t s = (F s-F t) * (s-t)⁻¹ := by simp [slope, smul_eq_mul, mul_comm]
    have h₁ : -slope c t s * Q t = ((c t-c s)*Q t) * (s-t)⁻¹ := by
      simp only [slope, smul_eq_mul, vsub_eq_sub]
      ring
    have h₂ : -slope c t s * Q s = ((c t-c s)*Q s) * (s-t)⁻¹ := by
      simp only [slope, smul_eq_mul, vsub_eq_sub]
      ring
    rw [hF,h₁,h₂]
    by_cases hd : 0 ≤ (s-t)⁻¹
    · exact ⟨(min_le_left _ _).trans (mul_le_mul_of_nonneg_right hl hd),
        (mul_le_mul_of_nonneg_right hu hd).trans (le_max_right _ _)⟩
    · have hd' : (s-t)⁻¹ ≤ 0 := (lt_of_not_ge hd).le
      exact ⟨(min_le_right _ _).trans (mul_le_mul_of_nonpos_right hu hd'),
        (mul_le_mul_of_nonpos_right hl hd').trans (le_max_left _ _)⟩
  exact tendsto_of_tendsto_of_tendsto_of_le_of_le' hmin hmax
    (hbounds.mono fun _ h => h.1) (hbounds.mono fun _ h => h.2)

/-- The convex tangent inequality specialized to cubic sources has a purely
polynomial sum-of-squares proof, valid for either sign of the kernels. -/
theorem cubic_source_tangent (u v : ℝ) :
    4 * u * (v^3-u^3) ≤ 3 * (v^4-u^4) := by
  have h := mul_nonneg (sq_nonneg (v-u))
    (add_nonneg (mul_nonneg (by norm_num : (0 : ℝ) ≤ 2) (sq_nonneg v)) (sq_nonneg (v+u)))
  nlinarith

/-- Rescale the polynomial inequality by the positive coupling cube roots. -/
theorem scaled_cubic_source_tangent (lam mu u v : ℝ) (hlam : 0 < lam) (hmu : 0 < mu) :
    (4 / 3 : ℝ) * lam ^ (1/3 : ℝ) * u * (mu*v^3-lam*u^3) ≤
      mu ^ (4/3 : ℝ) * v^4 - lam ^ (4/3 : ℝ) * u^4 := by
  have hp3 (x : ℝ) (hx : 0 ≤ x) : (x ^ (1/3 : ℝ))^3 = x := by
    rw [← Real.rpow_mul_natCast hx]
    norm_num
  have hp4 (x : ℝ) (hx : 0 ≤ x) : (x ^ (1/3 : ℝ))^4 = x ^ (4/3 : ℝ) := by
    rw [← Real.rpow_mul_natCast hx]
    norm_num
  have h := cubic_source_tangent (lam^(1/3 : ℝ)*u) (mu^(1/3 : ℝ)*v)
  simp only [mul_pow, hp3 lam hlam.le, hp3 mu hmu.le, hp4 lam hlam.le, hp4 mu hmu.le] at h
  nlinarith


variable (β : ℝ) [Fact (0 < β)]

def sourcePenalty (lam : ℝ≥0) (g : ℝ → ℝ) : ℝ :=
  (lam : ℝ) ^ (4/3 : ℝ) * quarticIntegral β g

def penaltyCoefficient (lam : ℝ) : ℝ :=
  (3 * β / 8) * lam ^ (-1/3 : ℝ)

omit [Fact (0 < β)] in
theorem penaltyCoefficient_mul_sourcePenalty (lam : ℝ≥0) (hlam : 0 < (lam : ℝ)) (g : ℝ → ℝ) :
    penaltyCoefficient β lam * sourcePenalty β lam g =
      (3 * β / 8) * (lam : ℝ) * quarticIntegral β g := by
  unfold penaltyCoefficient sourcePenalty
  have he : (lam : ℝ)^(-1/3 : ℝ) * (lam : ℝ)^(4/3 : ℝ) = (lam : ℝ) := by
    rw [← Real.rpow_add hlam]
    norm_num
  calc
    _ = (3 * β / 8) * ((lam : ℝ)^(-1/3 : ℝ) * (lam : ℝ)^(4/3 : ℝ)) * quarticIntegral β g := by ring
    _ = _ := by rw [he]

/-- Integral form of the actual cubic-source penalty tangent inequality. -/
theorem sourcePenalty_tangent (lam mu : ℝ≥0) (hlam : 0 < (lam : ℝ)) (hmu : 0 < (mu : ℝ))
    (g h : ℝ → ℝ) (hg : PhysicalSolution β lam g) (hh : PhysicalSolution β mu h) :
    (4/3 : ℝ) * (lam : ℝ)^(1/3 : ℝ) *
      ((mu : ℝ) * (∫ t in (0 : ℝ)..β, g t * (h t)^3) - (lam : ℝ) * quarticIntegral β g) ≤
      sourcePenalty β mu h - sourcePenalty β lam g := by
  obtain ⟨B,hb⟩ := hg.2.1
  obtain ⟨D,hd⟩ := hh.2.1
  have hB : 0 ≤ B := (abs_nonneg (g 0)).trans (hb 0)
  have hD : 0 ≤ D := (abs_nonneg (h 0)).trans (hd 0)
  have hi : IntervalIntegrable (fun t => g t * (h t)^3) volume 0 β := by
    apply bounded_intervalIntegrable β _ (hg.1.mul (hh.1.pow_const 3)) (B*D^3)
    intro t
    rw [abs_mul,abs_pow]
    exact mul_le_mul (hb t) (pow_le_pow_left₀ (abs_nonneg _) (hd t) 3) (by positivity) hB
  have hiG : IntervalIntegrable (fun t => (g t)^4) volume 0 β := by
    apply bounded_intervalIntegrable β _ (hg.1.pow_const 4) (B^4)
    intro t
    rw [abs_pow]
    exact pow_le_pow_left₀ (abs_nonneg _) (hb t) 4
  have hiH : IntervalIntegrable (fun t => (h t)^4) volume 0 β := by
    apply bounded_intervalIntegrable β _ (hh.1.pow_const 4) (D^4)
    intro t
    rw [abs_pow]
    exact pow_le_pow_left₀ (abs_nonneg _) (hd t) 4
  have hleft := ((hi.const_mul (mu : ℝ)).sub (hiG.const_mul (lam : ℝ))).const_mul
    ((4/3 : ℝ) * (lam : ℝ)^(1/3 : ℝ))
  have hright := (hiH.const_mul ((mu : ℝ)^(4/3 : ℝ))).sub
    (hiG.const_mul ((lam : ℝ)^(4/3 : ℝ)))
  have hp (t : ℝ) :
      ((4/3 : ℝ) * (lam : ℝ)^(1/3 : ℝ)) * ((mu : ℝ) * (g t*(h t)^3) - (lam : ℝ)*(g t)^4) ≤
      (mu : ℝ)^(4/3 : ℝ)*(h t)^4 - (lam : ℝ)^(4/3 : ℝ)*(g t)^4 := by
    nlinarith [scaled_cubic_source_tangent lam mu (g t) (h t) hlam hmu]
  have hs := intervalIntegral.integral_mono (Fact.out : 0 < β).le hleft hright hp
  rw [intervalIntegral.integral_const_mul,
    intervalIntegral.integral_sub (hi.const_mul (mu : ℝ)) (hiG.const_mul (lam : ℝ)),
    intervalIntegral.integral_sub (hiH.const_mul ((mu : ℝ)^(4/3 : ℝ)))
      (hiG.const_mul ((lam : ℝ)^(4/3 : ℝ)))] at hs
  simpa only [intervalIntegral.integral_const_mul, sourcePenalty, quarticIntegral] using hs

/-- The logarithmic tangent is cancelled by the actual local penalty tangent. -/
theorem onShellLog_le_penalty_difference (lam mu : ℝ≥0)
    (hlam : 0 < (lam : ℝ)) (hmu : 0 < (mu : ℝ))
    (g h : ℝ → ℝ) (hg : PhysicalSolution β lam g) (hh : PhysicalSolution β mu h) :
    onShellLog β mu h - onShellLog β lam g ≤
      penaltyCoefficient β lam * (sourcePenalty β mu h - sourcePenalty β lam g) := by
  have hβ : 0 < β := Fact.out
  have hs := mul_le_mul_of_nonneg_left (sourcePenalty_tangent β lam mu hlam hmu g h hg hh)
    (show 0 ≤ penaltyCoefficient β lam by unfold penaltyCoefficient; positivity)
  have he : penaltyCoefficient β lam * ((4/3 : ℝ) * (lam : ℝ)^(1/3 : ℝ)) = β/2 := by
    unfold penaltyCoefficient
    have hp : (lam : ℝ)^(-1/3 : ℝ) * (lam : ℝ)^(1/3 : ℝ) = 1 := by
      rw [← Real.rpow_add hlam]
      norm_num
    calc
      _ = β / 2 * ((lam : ℝ)^(-1/3 : ℝ) * (lam : ℝ)^(1/3 : ℝ)) := by ring
      _ = _ := by rw [hp,mul_one]
  rw [← mul_assoc,he] at hs
  exact (onShellLog_tangent β lam mu g h hg hh).trans hs

/-- Two actual physical sources satisfy both envelope comparisons. No
maximizer-existence assumption or derivative of the source is introduced. -/
theorem onShellAction_two_comparisons (lam mu : ℝ≥0)
    (hlam : 0 < (lam : ℝ)) (hmu : 0 < (mu : ℝ))
    (g h : ℝ → ℝ) (hg : PhysicalSolution β lam g) (hh : PhysicalSolution β mu h) :
    (penaltyCoefficient β lam - penaltyCoefficient β mu) * sourcePenalty β lam g ≤
      onShellAction β mu h - onShellAction β lam g ∧
    onShellAction β mu h - onShellAction β lam g ≤
      (penaltyCoefficient β lam - penaltyCoefficient β mu) * sourcePenalty β mu h := by
  have hupper := onShellLog_le_penalty_difference β lam mu hlam hmu g h hg hh
  have hlower := onShellLog_le_penalty_difference β mu lam hmu hlam h g hh hg
  have heG := penaltyCoefficient_mul_sourcePenalty β lam hlam g
  have heH := penaltyCoefficient_mul_sourcePenalty β mu hmu h
  unfold onShellAction
  constructor <;> nlinarith


/-- Extend the on-shell family by zero-coupling values on the negative axis. -/
def familyAction (g : ℝ≥0 → ℝ → ℝ) (l : ℝ) : ℝ :=
  onShellAction β l.toNNReal (g l.toNNReal)

def familyPenalty (g : ℝ≥0 → ℝ → ℝ) (l : ℝ) : ℝ :=
  l^(4/3 : ℝ) * quarticIntegral β (g l.toNNReal)

/-- Envelope differentiation of the actual on-shell family. The only family
regularity used is itself proved from bounded physical SD solutions. -/
theorem hasDerivAt_familyAction (g : ℝ≥0 → ℝ → ℝ)
    (hp : ∀ l, PhysicalSolution β l (g l)) (B : ℝ) (hb : ∀ l t, |g l t| ≤ B)
    (l : ℝ) (hl : 0 < l) :
    HasDerivAt (familyAction β g)
      (β / 8 * quarticIntegral β (g l.toNNReal)) l := by
  have hQ := physical_quartic_integral_continuous β (Fact.out : 0 < β) g hp B hb
  have hQc := hQ.comp continuous_real_toNNReal
  have hpen : ContinuousAt (familyPenalty β g) l :=
    (continuousAt_id.rpow_const (Or.inr (by norm_num : (0 : ℝ) ≤ 4/3))).mul hQc.continuousAt
  have hpow := Real.hasDerivAt_rpow_const (x := l) (p := (-1/3 : ℝ)) (Or.inl hl.ne')
  have hc := hpow.const_mul (3 * β / 8)
  have hcomp (s : ℝ) (hs : 0 < s) :
      (penaltyCoefficient β l - penaltyCoefficient β s) * familyPenalty β g l ≤
        familyAction β g s - familyAction β g l ∧
      familyAction β g s - familyAction β g l ≤
        (penaltyCoefficient β l - penaltyCoefficient β s) * familyPenalty β g s := by
    have h := onShellAction_two_comparisons β l.toNNReal s.toNNReal
      (by simpa only [Real.coe_toNNReal _ hl.le] using hl)
      (by simpa only [Real.coe_toNNReal _ hs.le] using hs)
      (g l.toNNReal) (g s.toNNReal) (hp _) (hp _)
    simpa only [familyAction, familyPenalty, sourcePenalty,
      Real.coe_toNNReal _ hl.le, Real.coe_toNNReal _ hs.le] using h
  have h := hasDerivAt_of_two_comparisons (familyAction β g) (penaltyCoefficient β)
    (familyPenalty β g) l _ hl hc hpen hcomp
  have he : l^(-4/3 : ℝ) * l^(4/3 : ℝ) = 1 := by
    rw [← Real.rpow_add hl]
    norm_num
  have he' : (-1/3 : ℝ)-1 = -4/3 := by norm_num
  simp only [he'] at h
  have hd : -((3 * β / 8) * ((-1/3 : ℝ) * l^(-4/3 : ℝ))) * familyPenalty β g l =
      β / 8 * quarticIntegral β (g l.toNNReal) := by
    unfold familyPenalty
    calc
      _ = (β / 8) * (l^(-4/3 : ℝ) * l^(4/3 : ℝ)) * quarticIntegral β (g l.toNNReal) := by ring
      _ = _ := by rw [he,mul_one]
  rw [hd] at h
  exact h

/-- The zero endpoint follows from the proved O(λ) action bound, not from
an assumed determinant-continuity theorem. -/
theorem continuousAt_familyAction_zero (g : ℝ≥0 → ℝ → ℝ)
    (hp : ∀ l, PhysicalSolution β l (g l)) (B : ℝ) (hb : ∀ l t, |g l t| ≤ B) :
    ContinuousAt (familyAction β g) 0 := by
  have hzero : familyAction β g 0 = 0 := by simp [familyAction]
  rw [ContinuousAt,hzero]
  have hu : Tendsto (fun s : ℝ => (s.toNNReal : ℝ) * β^2 * B^3 / 4) (𝓝 0) (𝓝 0) := by
    have hc : Continuous (fun s : ℝ => (s.toNNReal : ℝ) * β^2 * B^3 / 4) :=
      (((NNReal.continuous_coe.comp continuous_real_toNNReal).mul continuous_const).mul
        continuous_const).div_const 4
    have ht := hc.continuousAt (x := (0 : ℝ))
    simp only [ContinuousAt] at ht
    simpa using ht
  exact squeeze_zero
    (fun s => (onShellAction_bounds β s.toNNReal (g s.toNNReal) (hp _) B (hb _)).1)
    (fun s => (onShellAction_bounds β s.toNNReal (g s.toNNReal) (hp _) B (hb _)).2) hu

/-- The action is continuous on the closed nonnegative axis and differentiable
inside it, with no derivative assumption on the physical solution. -/
theorem continuousOn_familyAction (g : ℝ≥0 → ℝ → ℝ)
    (hp : ∀ l, PhysicalSolution β l (g l)) (B : ℝ) (hb : ∀ l t, |g l t| ≤ B) :
    ContinuousOn (familyAction β g) (Ici 0) := by
  intro l hl
  have hl' : (0 : ℝ) ≤ l := hl
  rcases eq_or_lt_of_le hl' with h | h
  · subst l
    exact (continuousAt_familyAction_zero β g hp B hb).continuousWithinAt
  · exact (hasDerivAt_familyAction β g hp B hb l h).continuousAt.continuousWithinAt

/-- The continuum coupling-pressure functional is exactly the on-shell action.
All Fourier summability, positivity, comparison, envelope and endpoint facts
are derived from the actual physical family and its common pointwise bound. -/
theorem couplingPressure_eq_onShellAction (g : ℝ≥0 → ℝ → ℝ)
    (hp : ∀ l, PhysicalSolution β l (g l)) (B : ℝ) (hb : ∀ l t, |g l t| ≤ B)
    (lam : ℝ≥0) :
    couplingPressure β g lam = Real.log 2 / 2 + onShellAction β lam (g lam) := by
  have hc := (physical_quartic_integral_continuous β (Fact.out : 0 < β) g hp B hb).comp
    continuous_real_toNNReal
  have hd : Continuous (fun l : ℝ => β / 8 * quarticIntegral β (g l.toNNReal)) :=
    continuous_const.mul hc
  have hF := SYK.pressure_integral_formula (familyAction β g)
    (fun l => β / 8 * quarticIntegral β (g l.toNNReal)) 0 (lam : ℝ) lam.coe_nonneg
    ((continuousOn_familyAction β g hp B hb).mono (fun _ h => h.1))
    (fun l hl => hasDerivAt_familyAction β g hp B hb l hl.1)
    (hd.intervalIntegrable 0 lam) (by simp [familyAction])
  simp only [zero_add, familyAction, Real.toNNReal_coe, intervalIntegral.integral_const_mul] at hF
  unfold couplingPressure
  rw [hF]
  rfl

/-- The explicit relative-log-series action formula, with its standard
on-shell interaction coefficient and genuine signed-frequency spectrum. -/
theorem couplingPressure_eq_relative_log_action (g : ℝ≥0 → ℝ → ℝ)
    (hp : ∀ l, PhysicalSolution β l (g l)) (B : ℝ) (hb : ∀ l t, |g l t| ≤ B)
    (lam : ℝ≥0) :
    couplingPressure β g lam = Real.log 2 / 2 +
      (1/2 : ℝ) * Real.log (relativeProduct (sourceRatio β lam (g lam))) -
        (3 * β / 8) * (lam : ℝ) * quarticIntegral β (g lam) := by
  rw [couplingPressure_eq_onShellAction β g hp B hb lam]
  rw [log_relativeProduct (sourceRatio β lam (g lam))
    (sourceRatio_summable β lam (g lam) (hp lam))
    (sourceRatio_factor_pos β lam (g lam) (hp lam))]
  unfold onShellAction onShellLog
  ring

end SYK.Continuum


