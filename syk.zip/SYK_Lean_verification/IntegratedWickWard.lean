import WardMarkedIntegration
import ContactWickEvaluation
import MomentSeriesIntegrability

/-! # The integrated and summed exact continuum Wick Ward identity -/
set_option maxHeartbeats 1600000
noncomputable section
open MeasureTheory Set
open scoped Topology BigOperators
namespace SYK.ContinuumWickSeries
open ThermalWick Ward WickVertexIntegrals WardInteraction DuhamelHistory

/-- The finite contact recursion is complex-linear in its moment functional. -/
theorem contactValue_mul {β : ℝ} (c : ℂ) (F : List (Time β × Time β) → ℂ)
    (s t : Time β) (ps qs : List (Time β × Time β)) :
    contactValue (fun l => c * F l) s t ps qs = c * contactValue F s t ps qs := by
  induction ps generalizing qs with
  | nil => simp [contactValue]
  | cons p ps ih => simp only [contactValue,ih]; ring

/-- A fixed trailing insertion may be moved into the underlying functional. -/
theorem contactValue_append {β : ℝ} (F : List (Time β × Time β) → ℂ)
    (s t : Time β) (ps qs vs : List (Time β × Time β)) :
    contactValue F s t ps (qs ++ vs) =
      contactValue (fun l => F (l ++ vs)) s t ps qs := by
  induction ps generalizing qs with
  | nil => rfl
  | cons p ps ih => simp only [contactValue,← List.append_assoc,List.cons_append,← ih]

/-- Every coefficient retains the exact finite insertion contacts. -/
theorem expectation_contact_quartics (d : ℕ) (β : ℝ) (hβ : 0 < β)
    (ps : List (Time β × Time β)) (s t : Time β) {n : ℕ} (u : Fin n → ℝ×ℝ) :
    expectation (2*d) β (contactPolynomial s t ps * orderedProduct
      (fun i => densityAt (2*d) β hβ (u i))) =
      (((2*d:ℕ):ℂ)/8)^n * contactValue (fun l => coefficientIntegrand d β hβ l u) s t ps [] := by
  unfold densityAt
  rw [quartic_product,mul_smul_comm,map_smul,expectation_contact_monomial]
  change (((2*d:ℕ):ℂ)/8)^n * _ = _
  congr 1
  simpa only [List.nil_append,coefficientIntegrand] using
    contactValue_append (fun l => expectation (2*d) β (collectiveMonomial l))
      s t ps [] (interactionPairs β hβ u)

/-- Exact pointwise Ward splitting with a finite sum over all marked vertices. -/
theorem weightedIntegrand_ward_succ (d : ℕ) (hd : 0 < d) (β : ℝ) (hβ : 0 < β)
    (ps : List (Time β × Time β)) (s t : Time β) (n : ℕ) (u : Fin (n+1) → ℝ×ℝ) :
    ((((2*d:ℕ):ℝ)/8)^(n+1)) • coefficientIntegrand d β hβ ((s,t)::ps) u =
      (Thermal.kernel β s.val t.val:ℂ) *
        (((((2*d:ℕ):ℝ)/8)^(n+1)) • coefficientIntegrand d β hβ ps u) +
      (((2*d:ℕ):ℂ)⁻¹) * (((((2*d:ℕ):ℂ)/8)^(n+1)) *
        contactValue (fun l => coefficientIntegrand d β hβ l u) s t ps []) +
      ∑ r : Fin (n+1), markedIntegrand d β hβ ps s t u r := by
  let V := orderedProduct (fun i => densityAt (2*d) β hβ (u i))
  have h := expectation_inserted_ward (by omega : 0<2*d) s t ps V
  have hm : expectation (2*d) β (collectiveMonomial ps * normalizedPartner s t V) =
      ∑ r : Fin (n+1), markedIntegrand d β hβ ps s t u r := by
    rw [show normalizedPartner s t V = _ from normalizedPartner_product s t _
      (fun i => quarticDensity_even (2*d) β 1 _ _)]
    simp only [Finset.mul_sum,map_sum,markedIntegrand,normalizedPartner]
  have hn : -(((2*d:ℕ):ℂ)⁻¹) * expectation (2*d) β
      (collectiveMonomial ps * partnerContraction s t V) =
      expectation (2*d) β (collectiveMonomial ps * normalizedPartner s t V) := by
    simp only [normalizedPartner,mul_smul_comm,map_smul,smul_eq_mul]
  rw [coefficientIntegrand_eq_quartic_product,coefficientIntegrand_eq_quartic_product]
  change expectation (2*d) β (collectiveMonomial ((s,t)::ps) * V) = _
  rw [show collectiveMonomial (N:=2*d) ((s,t)::ps) = collective (2*d) β s t * collectiveMonomial ps by rfl,
    mul_assoc,h,show expectation (2*d) β (contactPolynomial s t ps * V) = _ from
      expectation_contact_quartics d β hβ ps s t u]
  rw [sub_eq_add_neg,← neg_mul,hn,hm]
  rfl

/-- The actual complex coefficient is the integral of its weighted scalar integrand. -/
theorem coefficient_eq_integral_weighted (d : ℕ) (β : ℝ) (hβ : 0 < β)
    (ps : List (Time β × Time β)) (n : ℕ) :
    coefficient d β hβ ps n = ∫ u, ((((2*d:ℕ):ℝ)/8)^n) •
      coefficientIntegrand d β hβ ps u ∂interactionMeasure β n := by
  rw [integral_smul]
  rfl

/-- Exact integrated Ward recurrence at positive interaction degree. -/
theorem coefficient_ward_succ (d : ℕ) (hd : 0 < d) (β : ℝ) (hβ : 0 < β)
    (ps : List (Time β × Time β)) (s t : Time β) (n : ℕ) :
    coefficient d β hβ ((s,t)::ps) (n+1) =
      (Thermal.kernel β s.val t.val:ℂ) * coefficient d β hβ ps (n+1) +
      (((2*d:ℕ):ℂ)⁻¹) * contactValue (fun l => coefficient d β hβ l (n+1)) s t ps [] +
      ((n+1:ℕ):ℂ) * ∫ p, wardBranch d β hβ ps s t (pairFirst β hβ) (pairSecond β hβ) n p ∂pairMeasure β := by
  have hi (l) := coefficientIntegrand_integrable d hd β hβ l (n+1)
  have hc := contactValue_integrable (interactionMeasure β (n+1))
    (fun u l => coefficientIntegrand d β hβ l u) hi s t ps []
  have hm := fun r : Fin (n+1) => markedIntegrand_integrable d hd β hβ ps s t r
  rw [coefficient_eq_integral_weighted]
  simp_rw [weightedIntegrand_ward_succ d hd β hβ ps s t n]
  simp only [Complex.real_smul,Complex.ofReal_pow,Complex.ofReal_div,
    Complex.ofReal_natCast,Complex.ofReal_ofNat]
  have hA := ((hi ps).const_mul ((((2*d:ℕ):ℂ)/8)^(n+1))).const_mul
    (Thermal.kernel β s.val t.val:ℂ)
  have hB := (hc.const_mul ((((2*d:ℕ):ℂ)/8)^(n+1))).const_mul (((2*d:ℕ):ℂ)⁻¹)
  have hM := integrable_finset_sum Finset.univ (fun r _ => hm r)
  simp only [Pi.add_apply] at hA hB hM
  erw [integral_add (hA.add hB) hM,integral_add hA hB,
    integral_const_mul,integral_const_mul,integral_const_mul,integral_const_mul,
    integral_contactValue _ _ hi,integral_finset_sum _ (fun r _ => hm r)]
  simp_rw [integral_markedIntegrand d hd β hβ ps s t n]
  simp only [Finset.sum_const,Finset.card_univ,Fintype.card_fin,nsmul_eq_mul]
  congr 2
  · simp only [integral_const_mul,coefficient,Complex.real_smul,Complex.ofReal_pow,
      Complex.ofReal_div,Complex.ofReal_natCast,Complex.ofReal_ofNat]
  · rw [← contactValue_mul]
    simp only [coefficient,Complex.real_smul,Complex.ofReal_pow,Complex.ofReal_div,
      Complex.ofReal_natCast,Complex.ofReal_ofNat]

/-- The free coefficient has contacts but no interaction contribution. -/
theorem coefficient_ward_zero (d : ℕ) (hd : 0 < d) (β : ℝ) (hβ : 0 < β)
    (ps : List (Time β × Time β)) (s t : Time β) :
    coefficient d β hβ ((s,t)::ps) 0 =
      (Thermal.kernel β s.val t.val:ℂ) * coefficient d β hβ ps 0 +
      (((2*d:ℕ):ℂ)⁻¹) * contactValue (fun l => coefficient d β hβ l 0) s t ps [] := by
  have h := expectation_inserted_ward (by omega : 0<2*d) s t ps (1 : FieldAlgebra (2*d) β)
  have hz : partnerContraction (N:=2*d) s t 1 = 0 := by simp [partnerContraction]
  rw [hz] at h
  simp only [mul_one,mul_zero,map_zero,sub_zero] at h
  simp only [coefficient_zero]
  rw [show collectiveMonomial (N:=2*d) ((s,t)::ps) =
    collective (2*d) β s t * collectiveMonomial ps by rfl,h]
  congr 2
  simpa only [collectiveMonomial,List.map_nil,List.prod_nil,mul_one] using
    expectation_contact_monomial (N:=2*d) s t ps []

/-- The cubic branch series really sums to the inserted numerator under the
same bounded continuum time integral. -/
theorem wardBranch_hasSum_integral (d : ℕ) (hd : 0 < d) (β : ℝ) (hβ : 0 < β)
    (ps : List (Time β × Time β)) (s t : Time β) (lam : ℝ) :
    HasSum (ExponentialMomentSeries.term (fun n =>
      ∫ p, wardBranch d β hβ ps s t (pairFirst β hβ) (pairSecond β hβ) n p ∂pairMeasure β) lam)
      (∫ p, (Thermal.kernel β s.val (pairFirst β hβ p).val:ℂ) *
        numerator d β hβ (ps ++ cubicPairs (pairFirst β hβ p) (pairSecond β hβ p)
          (pairSecond β hβ p) t) lam ∂pairMeasure β) := by
  let b := fun p n => wardBranch d β hβ ps s t (pairFirst β hβ) (pairSecond β hβ) n p
  let K : ℝ := (1/2)*(1/2)^(ps.length+4)
  let R : ℝ := ((2*d:ℕ):ℝ)*β^2/128
  have hm n : AEStronglyMeasurable (fun p => b p n) (pairMeasure β) :=
    (wardBranch_measurable d β hβ ps s t _ _ (pairFirst_measurable β hβ)
      (pairSecond_measurable β hβ) n).aestronglyMeasurable
  have hb p n : ‖b p n‖ ≤ K*R^n := wardBranch_bound d hd β hβ ps s t _ _ n p
  have hs := hasSum_integral_of_summable_integral_norm
    (ExponentialMomentSeries.integrable_term_parameter (pairMeasure β) b K R hm hb lam)
    (ExponentialMomentSeries.summable_integral_norm_term (pairMeasure β) b K R hm hb lam)
  have he p : ExponentialMomentSeries.value (b p) lam =
      (Thermal.kernel β s.val (pairFirst β hβ p).val:ℂ) *
        numerator d β hβ (ps ++ cubicPairs (pairFirst β hβ p) (pairSecond β hβ p)
          (pairSecond β hβ p) t) lam := by
    unfold ExponentialMomentSeries.value numerator ExponentialMomentSeries.value
    rw [← tsum_mul_left]
    apply tsum_congr
    intro n
    simp only [ExponentialMomentSeries.term,b,wardBranch,Complex.real_smul]
    ring
  change HasSum (fun n => ∫ p, ExponentialMomentSeries.term (b p) lam n ∂pairMeasure β)
    (∫ p, ExponentialMomentSeries.value (b p) lam ∂pairMeasure β) at hs
  simp_rw [he] at hs
  simpa only [ExponentialMomentSeries.term,integral_smul,b] using hs

/-- Factorial cancellation at a marked interaction vertex gives precisely
one power of the coupling and no extraneous N or factorial factor. -/
theorem factorial_marked_term (a : ℂ) (lam : ℝ) (n : ℕ) :
    (lam^(n+1)/((n+1).factorial:ℝ)) • (((n+1:ℕ):ℂ)*a) =
      (lam:ℂ)*((lam^n/(n.factorial:ℝ)) • a) := by
  simp only [Complex.real_smul,Complex.ofReal_div,Complex.ofReal_pow,Complex.ofReal_natCast,
    Nat.factorial_succ,Nat.cast_mul,pow_succ,Nat.cast_add,Nat.cast_one]
  have hn : (n:ℂ)+1 ≠ 0 := by exact_mod_cast Nat.succ_ne_zero n
  have hf : (n.factorial:ℂ) ≠ 0 := by exact_mod_cast Nat.factorial_ne_zero n
  field_simp
  ring

/-- The actual marked interaction coefficients, including their zero constant
term, have the required integrated interacting series as their sum. -/
theorem ward_interaction_hasSum (d : ℕ) (hd : 0 < d) (β : ℝ) (hβ : 0 < β)
    (ps : List (Time β × Time β)) (s t : Time β) (lam : ℝ) :
    HasSum (fun n => (lam^n/(n.factorial:ℝ)) •
      (coefficient d β hβ ((s,t)::ps) n -
        (Thermal.kernel β s.val t.val:ℂ)*coefficient d β hβ ps n -
        (((2*d:ℕ):ℂ)⁻¹)*contactValue (fun l => coefficient d β hβ l n) s t ps []))
      ((lam:ℂ) * ∫ p, (Thermal.kernel β s.val (pairFirst β hβ p).val:ℂ) *
        numerator d β hβ (ps ++ cubicPairs (pairFirst β hβ p) (pairSecond β hβ p)
          (pairSecond β hβ p) t) lam ∂pairMeasure β) := by
  have hs := (wardBranch_hasSum_integral d hd β hβ ps s t lam).mul_left (lam:ℂ)
  have hs' : HasSum (fun n => (lam^(n+1)/((n+1).factorial:ℝ)) •
      (coefficient d β hβ ((s,t)::ps) (n+1) -
        (Thermal.kernel β s.val t.val:ℂ)*coefficient d β hβ ps (n+1) -
        (((2*d:ℕ):ℂ)⁻¹)*contactValue (fun l => coefficient d β hβ l (n+1)) s t ps []))
      ((lam:ℂ) * ∫ p, (Thermal.kernel β s.val (pairFirst β hβ p).val:ℂ) *
        numerator d β hβ (ps ++ cubicPairs (pairFirst β hβ p) (pairSecond β hβ p)
          (pairSecond β hβ p) t) lam ∂pairMeasure β) := by
    apply hs.congr_fun
    intro n
    rw [coefficient_ward_succ d hd β hβ ps s t n]
    rw [show ∀ a b c : ℂ, a+b+c-a-b=c by intros; ring]
    exact factorial_marked_term _ lam n
  have h := (hasSum_nat_add_iff (f := fun n => (lam^n/(n.factorial:ℝ)) •
      (coefficient d β hβ ((s,t)::ps) n -
        (Thermal.kernel β s.val t.val:ℂ)*coefficient d β hβ ps n -
        (((2*d:ℕ):ℂ)⁻¹)*contactValue (fun l => coefficient d β hβ l n) s t ps [])) 1).mp hs'
  simpa only [Finset.sum_range_one,coefficient_ward_zero d hd β hβ ps s t,
    add_sub_cancel_left,sub_self,smul_zero,add_zero] using h

/-- The exact left Ward identity for the genuine convergent continuum numerator.
Every finite insertion contact is retained; the interaction term is the actual
Lebesgue pair integral. No Ward identity or response formula is assumed. -/
theorem numerator_ward (d : ℕ) (hd : 0 < d) (β : ℝ) (hβ : 0 < β)
    (ps : List (Time β × Time β)) (s t : Time β) (lam : ℝ) :
    numerator d β hβ ((s,t)::ps) lam =
      (Thermal.kernel β s.val t.val:ℂ)*numerator d β hβ ps lam +
      (((2*d:ℕ):ℂ)⁻¹)*contactValue (fun l => numerator d β hβ l lam) s t ps [] +
      (lam:ℂ)*(∫ p, (Thermal.kernel β s.val (pairFirst β hβ p).val:ℂ)*
        numerator d β hβ (ps ++ cubicPairs (pairFirst β hβ p) (pairSecond β hβ p)
          (pairSecond β hβ p) t) lam ∂pairMeasure β) := by
  have hs l : HasSum (fun n => ExponentialMomentSeries.term (coefficient d β hβ l) lam n)
      (numerator d β hβ l lam) := (numerator_summable d hd β hβ l lam).hasSum
  have hc := contactValue_hasSum (fun n l => ExponentialMomentSeries.term (coefficient d β hβ l) lam n)
    (fun l => numerator d β hβ l lam) hs s t ps []
  have hleft := ((hs ((s,t)::ps)).sub ((hs ps).mul_left (Thermal.kernel β s.val t.val:ℂ))).sub
    (hc.mul_left (((2*d:ℕ):ℂ)⁻¹))
  have he : HasSum (fun n => (lam^n/(n.factorial:ℝ)) •
      (coefficient d β hβ ((s,t)::ps) n -
        (Thermal.kernel β s.val t.val:ℂ)*coefficient d β hβ ps n -
        (((2*d:ℕ):ℂ)⁻¹)*contactValue (fun l => coefficient d β hβ l n) s t ps []))
      (numerator d β hβ ((s,t)::ps) lam -
        (Thermal.kernel β s.val t.val:ℂ)*numerator d β hβ ps lam -
        (((2*d:ℕ):ℂ)⁻¹)*contactValue (fun l => numerator d β hβ l lam) s t ps []) := by
    apply hleft.congr_fun
    intro n
    simp only [ExponentialMomentSeries.term,Complex.real_smul,contactValue_mul]
    ring
  have h := he.unique (ward_interaction_hasSum d hd β hβ ps s t lam)
  linear_combination h

end SYK.ContinuumWickSeries
