import KernelSpace
import CovarianceRegularity
import Mathlib.MeasureTheory.Integral.IntervalIntegral.Periodic

/-!
# Endpoint regularity of the actual thermal convolution

The midpoint thermal covariance retains its jumps. Its translations are
Lipschitz only after integration in the internal time. These estimates are
proved on all real lifts before they are used for the Banach-valued kernels.
-/

noncomputable section
open MeasureTheory Set Filter
open scoped Topology

namespace SYK.Thermal

/-- Right-endpoint antiperiodicity, including the midpoint values at jumps. -/
theorem kernel_antiperiodic_right (β : ℝ) (hβ : β ≠ 0) (s t : ℝ) :
    kernel β s (t + β) = -kernel β s t := by
  have hl : kernel β (t + β) s = -kernel β t s := by
    unfold kernel
    rw [show (t + β) - s = (t - s) + β by ring, covariance_antiperiodic β hβ]
  rw [kernel_skew β (t + β) s, hl, neg_neg]
  exact kernel_skew β s t

/-- The absolute difference of two covariance rows is β-periodic. -/
theorem kernel_difference_periodic (β : ℝ) (hβ : β ≠ 0) (a b : ℝ) :
    Function.Periodic (fun u => |kernel β a u - kernel β b u|) β := by
  intro u
  dsimp only
  rw [kernel_antiperiodic_right β hβ, kernel_antiperiodic_right β hβ]
  rw [show -kernel β a u - -kernel β b u = -(kernel β a u - kernel β b u) by ring, abs_neg]

theorem kernel_difference_le_one (β a b u : ℝ) :
    |kernel β a u - kernel β b u| ≤ 1 := by
  calc
    _ ≤ |kernel β a u| + |kernel β b u| := abs_sub _ _
    _ ≤ 1 / 2 + 1 / 2 := add_le_add (abs_covariance_le β _) (abs_covariance_le β _)
    _ = 1 := by norm_num

theorem kernel_difference_intervalIntegrable (β a b : ℝ) :
    IntervalIntegrable (fun u => |kernel β a u - kernel β b u|) volume 0 β := by
  have hma : Measurable (fun u : ℝ => kernel β a u) :=
    (covariance_measurable β).comp (measurable_const.sub measurable_id)
  have hmb : Measurable (fun u : ℝ => kernel β b u) :=
    (covariance_measurable β).comp (measurable_const.sub measurable_id)
  have hm : Measurable (fun u => |kernel β a u - kernel β b u|) :=
    continuous_abs.measurable.comp (hma.sub hmb)
  apply (intervalIntegrable_const (c := (1 : ℝ))).mono_fun' hm.aestronglyMeasurable
  filter_upwards [] with u
  simpa only [Real.norm_eq_abs, abs_abs] using kernel_difference_le_one β a b u

/-- Simultaneous endpoint translation preserves the integrated row distance.
Periodicity of the absolute difference handles arbitrary real lifts. -/
theorem integral_kernel_difference_translate (β : ℝ) (hβ : 0 < β) (a b : ℝ) :
    (∫ u in (0 : ℝ)..β, |kernel β a u - kernel β b u|) =
      ∫ u in (0 : ℝ)..β, |kernel β 0 u - kernel β (b - a) u| := by
  have heq : (fun u => |kernel β a u - kernel β b u|) =
      (fun u => |kernel β 0 (u - a) - kernel β (b - a) (u - a)|) := by
    funext u
    unfold kernel
    rw [show 0 - (u - a) = a - u by ring,
      show (b - a) - (u - a) = b - u by ring]
  rw [heq, intervalIntegral.integral_comp_sub_right
    (fun u => |kernel β 0 u - kernel β (b - a) u|) a]
  have hp := (kernel_difference_periodic β hβ.ne' 0 (b - a)).intervalIntegral_add_eq (-a) 0
  simpa only [zero_sub, zero_add, add_zero, sub_eq_add_neg, add_comm] using hp

/-- One thermal period contains at most the length of the displacement in
jump variation. Endpoints at jumps retain the prescribed midpoint values. -/
theorem integral_kernel_difference_zero_le (β : ℝ) (hβ : 0 < β) (d : ℝ) (hd : 0 ≤ d) :
    (∫ u in (0 : ℝ)..β, |kernel β 0 u - kernel β d u|) ≤ d := by
  by_cases hsmall : d < β
  · have hf := integrable_halfSign_difference 0 d hd
    calc
      _ ≤ ∫ u in (0 : ℝ)..β, |halfSign (0 - u) - halfSign (d - u)| := by
        apply intervalIntegral.integral_mono_on_of_le_Ioo hβ.le
          (kernel_difference_intervalIntegrable β 0 d) hf.intervalIntegrable
        intro u hu
        rw [kernel_on_fundamental β hβ 0 u ⟨le_rfl, hβ⟩ ⟨hu.1.le, hu.2⟩,
          kernel_on_fundamental β hβ d u ⟨hd, hsmall⟩ ⟨hu.1.le, hu.2⟩]
      _ = ∫ u in Ioc (0 : ℝ) β, |halfSign (0 - u) - halfSign (d - u)| :=
        intervalIntegral.integral_of_le hβ.le
      _ ≤ ∫ u : ℝ, |halfSign (0 - u) - halfSign (d - u)| :=
        setIntegral_le_integral hf (Filter.Eventually.of_forall (fun u => abs_nonneg _))
      _ ≤ d := by simpa only [sub_zero] using integral_halfSign_difference_le 0 d hd
  · have hbd : β ≤ d := le_of_not_gt hsmall
    calc
      _ ≤ ∫ _u in (0 : ℝ)..β, (1 : ℝ) :=
        intervalIntegral.integral_mono hβ.le (kernel_difference_intervalIntegrable β 0 d)
          intervalIntegrable_const (fun u => kernel_difference_le_one β 0 d u)
      _ = β := by simp
      _ ≤ d := hbd

/-- The exact global L¹ endpoint modulus of the actual thermal covariance. -/
theorem integral_kernel_difference_le (β : ℝ) (hβ : 0 < β) (a b : ℝ) :
    (∫ u in (0 : ℝ)..β, |kernel β a u - kernel β b u|) ≤ |a - b| := by
  rcases le_total a b with hab | hba
  · rw [integral_kernel_difference_translate β hβ a b, abs_of_nonpos (sub_nonpos.mpr hab)]
    simpa only [neg_sub] using integral_kernel_difference_zero_le β hβ (b - a) (sub_nonneg.mpr hab)
  · have heq : (fun u => |kernel β a u - kernel β b u|) =
        (fun u => |kernel β b u - kernel β a u|) := by funext u; exact abs_sub_comm _ _
    rw [heq, integral_kernel_difference_translate β hβ b a, abs_of_nonneg (sub_nonneg.mpr hba)]
    exact integral_kernel_difference_zero_le β hβ (a - b) (sub_nonneg.mpr hba)

/-- The same estimate for the other endpoint follows from exact skewness. -/
theorem integral_kernel_difference_right_le (β : ℝ) (hβ : 0 < β) (a b : ℝ) :
    (∫ u in (0 : ℝ)..β, |kernel β u a - kernel β u b|) ≤ |a - b| := by
  have heq : (fun u => |kernel β u a - kernel β u b|) =
      (fun u => |kernel β a u - kernel β b u|) := by
    funext u
    rw [kernel_skew β a u, kernel_skew β b u]
    rw [show -kernel β a u - -kernel β b u = -(kernel β a u - kernel β b u) by ring, abs_neg]
  rw [heq]
  exact integral_kernel_difference_le β hβ a b

end SYK.Thermal

namespace SYK.ConvolutionRegularity

variable {A : Type*} [NormedRing A] [NormedAlgebra ℂ A] [NormOneClass A]
  [NormedSpace ℝ A] [IsScalarTower ℝ ℂ A] [CompleteSpace A]

/-- Bounded measurable kernels have integrable row differences. -/
theorem row_difference_integrable (β : ℝ) (f : KernelSpace A) (s s' : ℝ) :
    IntervalIntegrable (fun u => ‖f (s, u) - f (s', u)‖) volume 0 β := by
  have hm : StronglyMeasurable (fun u : ℝ => f (s, u) - f (s', u)) :=
    ((KernelSpace.stronglyMeasurable f).comp_measurable
      (measurable_const.prodMk measurable_id)).sub
      ((KernelSpace.stronglyMeasurable f).comp_measurable
        (measurable_const.prodMk measurable_id))
  apply (intervalIntegrable_const (c := 2 * ‖f‖)).mono_fun' hm.norm.aestronglyMeasurable
  filter_upwards [] with u
  simp only [norm_norm]
  calc
    _ ≤ ‖f (s, u)‖ + ‖f (s', u)‖ := norm_sub_le _ _
    _ ≤ ‖f‖ + ‖f‖ := add_le_add (kernel_norm_apply_le f _) (kernel_norm_apply_le f _)
    _ = _ := by ring

/-- Bounded measurable kernels have integrable column differences. -/
theorem column_difference_integrable (β : ℝ) (f : KernelSpace A) (t t' : ℝ) :
    IntervalIntegrable (fun u => ‖f (u, t) - f (u, t')‖) volume 0 β := by
  have hm : StronglyMeasurable (fun u : ℝ => f (u, t) - f (u, t')) :=
    ((KernelSpace.stronglyMeasurable f).comp_measurable
      (measurable_id.prodMk measurable_const)).sub
      ((KernelSpace.stronglyMeasurable f).comp_measurable
        (measurable_id.prodMk measurable_const))
  apply (intervalIntegrable_const (c := 2 * ‖f‖)).mono_fun' hm.norm.aestronglyMeasurable
  filter_upwards [] with u
  simp only [norm_norm]
  calc
    _ ≤ ‖f (u, t)‖ + ‖f (u, t')‖ := norm_sub_le _ _
    _ ≤ ‖f‖ + ‖f‖ := add_le_add (kernel_norm_apply_le f _) (kernel_norm_apply_le f _)
    _ = _ := by ring

/-- A jump-prescribed free covariance plus an endpoint-Lipschitz remainder has
an L¹ row modulus, globally in both real endpoint lifts. -/
theorem free_add_row_L1 (β : ℝ) (hβ : 0 < β) (R : KernelSpace A) (K : ℝ)
    (hR : ∀ s t s' t', ‖R (s, t) - R (s', t')‖ ≤ K * (|s - s'| + |t - t'|))
    (s s' : ℝ) :
    (∫ u in (0 : ℝ)..β,
      ‖(freeThermalKernel (A := A) β + R) (s, u) - (freeThermalKernel (A := A) β + R) (s', u)‖) ≤
      (1 + β * K) * |s - s'| := by
  have hp (u : ℝ) :
      ‖(freeThermalKernel (A := A) β + R) (s, u) - (freeThermalKernel (A := A) β + R) (s', u)‖ ≤
        |Thermal.kernel β s u - Thermal.kernel β s' u| + K * |s - s'| := by
    have he : (freeThermalKernel (A := A) β + R) (s, u) - (freeThermalKernel (A := A) β + R) (s', u) =
        ((Thermal.kernel β s u - Thermal.kernel β s' u : ℝ) : ℂ) • (1 : A) +
          (R (s, u) - R (s', u)) := by
      simp only [kernel_add_apply, freeThermalKernel_apply, Complex.ofReal_sub, sub_smul]
      abel
    rw [he]
    apply (norm_add_le _ _).trans
    rw [norm_smul, norm_one, mul_one, Complex.norm_real, Real.norm_eq_abs]
    exact add_le_add_left (by simpa using hR s u s' u) _
  calc
    _ ≤ ∫ u in (0 : ℝ)..β,
        (|Thermal.kernel β s u - Thermal.kernel β s' u| + K * |s - s'|) :=
      intervalIntegral.integral_mono hβ.le (row_difference_integrable β _ s s')
        ((Thermal.kernel_difference_intervalIntegrable β s s').add intervalIntegrable_const) hp
    _ = (∫ u in (0 : ℝ)..β, |Thermal.kernel β s u - Thermal.kernel β s' u|) +
        β * (K * |s - s'|) := by
      rw [intervalIntegral.integral_add (Thermal.kernel_difference_intervalIntegrable β s s')
        intervalIntegrable_const]
      simp
      ring
    _ ≤ |s - s'| + β * (K * |s - s'|) :=
      add_le_add_right (Thermal.integral_kernel_difference_le β hβ s s') _
    _ = _ := by ring

/-- A corresponding column modulus, retaining the covariance's exact skew sign. -/
theorem free_add_column_L1 (β : ℝ) (hβ : 0 < β) (R : KernelSpace A) (K : ℝ)
    (hR : ∀ s t s' t', ‖R (s, t) - R (s', t')‖ ≤ K * (|s - s'| + |t - t'|))
    (t t' : ℝ) :
    (∫ u in (0 : ℝ)..β,
      ‖(freeThermalKernel (A := A) β + R) (u, t) - (freeThermalKernel (A := A) β + R) (u, t')‖) ≤
      (1 + β * K) * |t - t'| := by
  have hp (u : ℝ) :
      ‖(freeThermalKernel (A := A) β + R) (u, t) - (freeThermalKernel (A := A) β + R) (u, t')‖ ≤
        |Thermal.kernel β t u - Thermal.kernel β t' u| + K * |t - t'| := by
    have he : (freeThermalKernel (A := A) β + R) (u, t) - (freeThermalKernel (A := A) β + R) (u, t') =
        ((Thermal.kernel β u t - Thermal.kernel β u t' : ℝ) : ℂ) • (1 : A) +
          (R (u, t) - R (u, t')) := by
      simp only [kernel_add_apply, freeThermalKernel_apply, Complex.ofReal_sub, sub_smul]
      abel
    rw [he]
    apply (norm_add_le _ _).trans
    rw [norm_smul, norm_one, mul_one, Complex.norm_real, Real.norm_eq_abs,
      Thermal.kernel_skew β t u, Thermal.kernel_skew β t' u]
    rw [show -Thermal.kernel β t u - -Thermal.kernel β t' u =
      -(Thermal.kernel β t u - Thermal.kernel β t' u) by ring, abs_neg]
    exact add_le_add_left (by simpa using hR u t u t') _
  calc
    _ ≤ ∫ u in (0 : ℝ)..β,
        (|Thermal.kernel β t u - Thermal.kernel β t' u| + K * |t - t'|) :=
      intervalIntegral.integral_mono hβ.le (column_difference_integrable β _ t t')
        ((Thermal.kernel_difference_intervalIntegrable β t t').add intervalIntegrable_const) hp
    _ = (∫ u in (0 : ℝ)..β, |Thermal.kernel β t u - Thermal.kernel β t' u|) +
        β * (K * |t - t'|) := by
      rw [intervalIntegral.integral_add (Thermal.kernel_difference_intervalIntegrable β t t')
        intervalIntegrable_const]
      simp
      ring
    _ ≤ |t - t'| + β * (K * |t - t'|) :=
      add_le_add_right (Thermal.integral_kernel_difference_le β hβ t t') _
    _ = _ := by ring

/-- Integrating against a bounded kernel turns an L¹ row modulus into a
pointwise operator-norm endpoint modulus. -/
theorem convolution_left_bound (β : ℝ) (hβ : 0 ≤ β) (f g : KernelSpace A) (s s' t : ℝ) :
    ‖kernelConvolution β hβ f g (s, t) - kernelConvolution β hβ f g (s', t)‖ ≤
      ‖g‖ * (∫ u in (0 : ℝ)..β, ‖f (s, u) - f (s', u)‖) := by
  rw [kernelConvolution_apply, kernelConvolution_apply,
    ← intervalIntegral.integral_sub (kernelProduct_intervalIntegrable β f g (s, t))
      (kernelProduct_intervalIntegrable β f g (s', t))]
  simp only [← sub_mul]
  have hbound (u : ℝ) : ‖(f (s, u) - f (s', u)) * g (u, t)‖ ≤
      ‖g‖ * ‖f (s, u) - f (s', u)‖ := by
    calc
      _ ≤ ‖f (s, u) - f (s', u)‖ * ‖g (u, t)‖ := norm_mul_le _ _
      _ ≤ ‖f (s, u) - f (s', u)‖ * ‖g‖ :=
        mul_le_mul_of_nonneg_left (kernel_norm_apply_le g _) (norm_nonneg _)
      _ = _ := mul_comm _ _
  have hi := intervalIntegral.norm_integral_le_of_norm_le
    (Filter.Eventually.of_forall hbound) ((row_difference_integrable β f s s').const_mul ‖g‖)
  rw [intervalIntegral.integral_const_mul,
    abs_of_nonneg (mul_nonneg (norm_nonneg _) (intervalIntegral.integral_nonneg_of_forall hβ
      (fun u => norm_nonneg _)))] at hi
  exact hi

/-- The dual endpoint estimate for the right convolution factor. -/
theorem convolution_right_bound (β : ℝ) (hβ : 0 ≤ β) (f g : KernelSpace A) (s t t' : ℝ) :
    ‖kernelConvolution β hβ f g (s, t) - kernelConvolution β hβ f g (s, t')‖ ≤
      ‖f‖ * (∫ u in (0 : ℝ)..β, ‖g (u, t) - g (u, t')‖) := by
  rw [kernelConvolution_apply, kernelConvolution_apply,
    ← intervalIntegral.integral_sub (kernelProduct_intervalIntegrable β f g (s, t))
      (kernelProduct_intervalIntegrable β f g (s, t'))]
  simp only [← mul_sub]
  have hbound (u : ℝ) : ‖f (s, u) * (g (u, t) - g (u, t'))‖ ≤
      ‖f‖ * ‖g (u, t) - g (u, t')‖ := by
    exact (norm_mul_le _ _).trans
      (mul_le_mul_of_nonneg_right (kernel_norm_apply_le f _) (norm_nonneg _))
  have hi := intervalIntegral.norm_integral_le_of_norm_le
    (Filter.Eventually.of_forall hbound) ((column_difference_integrable β g t t').const_mul ‖f‖)
  rw [intervalIntegral.integral_const_mul,
    abs_of_nonneg (mul_nonneg (norm_nonneg _) (intervalIntegral.integral_nonneg_of_forall hβ
      (fun u => norm_nonneg _)))] at hi
  exact hi

/-- The left endpoint estimate needed to upgrade the SD center derivative:
V = G * G³ is globally Lipschitz in its first endpoint. -/
theorem G_cube_convolution_left (β : ℝ) (hβ : 0 < β) (R : KernelSpace A) (K : ℝ)
    (hR : ∀ s t s' t', ‖R (s, t) - R (s', t')‖ ≤ K * (|s - s'| + |t - t'|))
    (s s' t : ℝ) :
    let G := freeThermalKernel (A := A) β + R
    ‖kernelConvolution β hβ.le G (G ^ 3) (s, t) -
      kernelConvolution β hβ.le G (G ^ 3) (s', t)‖ ≤
        (‖G ^ 3‖ * (1 + β * K)) * |s - s'| := by
  dsimp only
  calc
    _ ≤ ‖(freeThermalKernel (A := A) β + R) ^ 3‖ *
      (∫ u in (0 : ℝ)..β, ‖(freeThermalKernel (A := A) β + R) (s, u) -
        (freeThermalKernel (A := A) β + R) (s', u)‖) := convolution_left_bound β hβ.le _ _ s s' t
    _ ≤ ‖(freeThermalKernel (A := A) β + R) ^ 3‖ * ((1 + β * K) * |s - s'|) :=
      mul_le_mul_of_nonneg_left (free_add_row_L1 β hβ R K hR s s') (norm_nonneg _)
    _ = _ := by ring

/-- Cubic products obey the noncommutative telescoping norm estimate. -/
theorem norm_cube_sub_le (x y : A) (B : ℝ) (hB : 0 ≤ B) (hx : ‖x‖ ≤ B) (hy : ‖y‖ ≤ B) :
    ‖x ^ 3 - y ^ 3‖ ≤ 3 * B ^ 2 * ‖x - y‖ := by
  have hx2 : ‖x ^ 2‖ ≤ B ^ 2 := (norm_pow_le x 2).trans (pow_le_pow_left₀ (norm_nonneg x) hx 2)
  have hy2 : ‖y ^ 2‖ ≤ B ^ 2 := (norm_pow_le y 2).trans (pow_le_pow_left₀ (norm_nonneg y) hy 2)
  have he : x ^ 3 - y ^ 3 = (x - y) * x ^ 2 + y * (x - y) * x + y ^ 2 * (x - y) := by
    noncomm_ring
  rw [he]
  calc
    _ ≤ ‖(x - y) * x ^ 2 + y * (x - y) * x‖ + ‖y ^ 2 * (x - y)‖ := norm_add_le _ _
    _ ≤ (‖(x - y) * x ^ 2‖ + ‖y * (x - y) * x‖) + ‖y ^ 2 * (x - y)‖ :=
      add_le_add_right (norm_add_le _ _) _
    _ ≤ (‖x - y‖ * B ^ 2 + B * ‖x - y‖ * B) + B ^ 2 * ‖x - y‖ := by
      apply add_le_add
      · apply add_le_add
        · exact (norm_mul_le _ _).trans (mul_le_mul_of_nonneg_left hx2 (norm_nonneg _))
        · apply (norm_mul_le _ _).trans
          apply mul_le_mul _ hx (norm_nonneg _) (mul_nonneg hB (norm_nonneg _))
          exact (norm_mul_le _ _).trans (mul_le_mul_of_nonneg_right hy (norm_nonneg _))
      · exact (norm_mul_le _ _).trans (mul_le_mul_of_nonneg_right hy2 (norm_nonneg _))
    _ = _ := by ring

@[simp] theorem kernel_pow_apply (f : KernelSpace A) (k : ℕ) (p : ℝ × ℝ) :
    (f ^ k) p = (f p) ^ k := by
  induction k with
  | zero => rfl
  | succ k ih => simp only [pow_succ, kernel_mul_apply, ih]

/-- Pointwise cubic powers preserve the integrated row modulus. -/
theorem cube_row_L1 (β : ℝ) (hβ : 0 ≤ β) (f : KernelSpace A) (s s' : ℝ) :
    (∫ u in (0 : ℝ)..β, ‖(f ^ 3) (s, u) - (f ^ 3) (s', u)‖) ≤
      (3 * ‖f‖ ^ 2) * (∫ u in (0 : ℝ)..β, ‖f (s, u) - f (s', u)‖) := by
  rw [← intervalIntegral.integral_const_mul]
  apply intervalIntegral.integral_mono hβ (row_difference_integrable β (f ^ 3) s s')
    ((row_difference_integrable β f s s').const_mul _)
  intro u
  dsimp only
  rw [kernel_pow_apply, kernel_pow_apply]
  exact norm_cube_sub_le _ _ ‖f‖ (norm_nonneg _) (kernel_norm_apply_le f _) (kernel_norm_apply_le f _)

/-- Pointwise cubic powers preserve the integrated column modulus. -/
theorem cube_column_L1 (β : ℝ) (hβ : 0 ≤ β) (f : KernelSpace A) (t t' : ℝ) :
    (∫ u in (0 : ℝ)..β, ‖(f ^ 3) (u, t) - (f ^ 3) (u, t')‖) ≤
      (3 * ‖f‖ ^ 2) * (∫ u in (0 : ℝ)..β, ‖f (u, t) - f (u, t')‖) := by
  rw [← intervalIntegral.integral_const_mul]
  apply intervalIntegral.integral_mono hβ (column_difference_integrable β (f ^ 3) t t')
    ((column_difference_integrable β f t t').const_mul _)
  intro u
  dsimp only
  rw [kernel_pow_apply, kernel_pow_apply]
  exact norm_cube_sub_le _ _ ‖f‖ (norm_nonneg _) (kernel_norm_apply_le f _) (kernel_norm_apply_le f _)

/-- U = G³ * G is globally Lipschitz in its first endpoint. -/
theorem cube_G_convolution_left (β : ℝ) (hβ : 0 < β) (R : KernelSpace A) (K : ℝ)
    (hR : ∀ s t s' t', ‖R (s, t) - R (s', t')‖ ≤ K * (|s - s'| + |t - t'|))
    (s s' t : ℝ) :
    let G := freeThermalKernel (A := A) β + R
    ‖kernelConvolution β hβ.le (G ^ 3) G (s, t) -
      kernelConvolution β hβ.le (G ^ 3) G (s', t)‖ ≤
        (‖G‖ * (3 * ‖G‖ ^ 2) * (1 + β * K)) * |s - s'| := by
  dsimp only
  let G := freeThermalKernel (A := A) β + R
  calc
    _ ≤ ‖G‖ * (∫ u in (0 : ℝ)..β, ‖(G ^ 3) (s, u) - (G ^ 3) (s', u)‖) :=
      convolution_left_bound β hβ.le _ _ s s' t
    _ ≤ ‖G‖ * ((3 * ‖G‖ ^ 2) * (∫ u in (0 : ℝ)..β, ‖G (s, u) - G (s', u)‖)) :=
      mul_le_mul_of_nonneg_left (cube_row_L1 β hβ.le G s s') (norm_nonneg _)
    _ ≤ ‖G‖ * ((3 * ‖G‖ ^ 2) * ((1 + β * K) * |s - s'|)) := by
      apply mul_le_mul_of_nonneg_left _ (norm_nonneg _)
      exact mul_le_mul_of_nonneg_left (free_add_row_L1 β hβ R K hR s s') (by positivity)
    _ = _ := by ring

/-- U = G³ * G is globally Lipschitz in its second endpoint. -/
theorem cube_G_convolution_right (β : ℝ) (hβ : 0 < β) (R : KernelSpace A) (K : ℝ)
    (hR : ∀ s t s' t', ‖R (s, t) - R (s', t')‖ ≤ K * (|s - s'| + |t - t'|))
    (s t t' : ℝ) :
    let G := freeThermalKernel (A := A) β + R
    ‖kernelConvolution β hβ.le (G ^ 3) G (s, t) -
      kernelConvolution β hβ.le (G ^ 3) G (s, t')‖ ≤
        (‖G ^ 3‖ * (1 + β * K)) * |t - t'| := by
  dsimp only
  calc
    _ ≤ ‖(freeThermalKernel (A := A) β + R) ^ 3‖ *
      (∫ u in (0 : ℝ)..β, ‖(freeThermalKernel (A := A) β + R) (u, t) -
        (freeThermalKernel (A := A) β + R) (u, t')‖) := convolution_right_bound β hβ.le _ _ s t t'
    _ ≤ ‖(freeThermalKernel (A := A) β + R) ^ 3‖ * ((1 + β * K) * |t - t'|) :=
      mul_le_mul_of_nonneg_left (free_add_column_L1 β hβ R K hR t t') (norm_nonneg _)
    _ = _ := by ring

/-- V = G * G³ is globally Lipschitz in its second endpoint. -/
theorem G_cube_convolution_right (β : ℝ) (hβ : 0 < β) (R : KernelSpace A) (K : ℝ)
    (hR : ∀ s t s' t', ‖R (s, t) - R (s', t')‖ ≤ K * (|s - s'| + |t - t'|))
    (s t t' : ℝ) :
    let G := freeThermalKernel (A := A) β + R
    ‖kernelConvolution β hβ.le G (G ^ 3) (s, t) -
      kernelConvolution β hβ.le G (G ^ 3) (s, t')‖ ≤
        (‖G‖ * (3 * ‖G‖ ^ 2) * (1 + β * K)) * |t - t'| := by
  dsimp only
  let G := freeThermalKernel (A := A) β + R
  calc
    _ ≤ ‖G‖ * (∫ u in (0 : ℝ)..β, ‖(G ^ 3) (u, t) - (G ^ 3) (u, t')‖) :=
      convolution_right_bound β hβ.le _ _ s t t'
    _ ≤ ‖G‖ * ((3 * ‖G‖ ^ 2) * (∫ u in (0 : ℝ)..β, ‖G (u, t) - G (u, t')‖)) :=
      mul_le_mul_of_nonneg_left (cube_column_L1 β hβ.le G t t') (norm_nonneg _)
    _ ≤ ‖G‖ * ((3 * ‖G‖ ^ 2) * ((1 + β * K) * |t - t'|)) := by
      apply mul_le_mul_of_nonneg_left _ (norm_nonneg _)
      exact mul_le_mul_of_nonneg_left (free_add_column_L1 β hβ R K hR t t') (by positivity)
    _ = _ := by ring

/-- Explicit separate Lipschitz bounds imply a joint Lipschitz bound in the
product metric, and hence ordinary joint continuity. -/
theorem joint_lipschitz_of_endpoint_bounds (F : ℝ × ℝ → A) (L M : ℝ)
    (hL : 0 ≤ L) (hM : 0 ≤ M)
    (hleft : ∀ s s' t, ‖F (s, t) - F (s', t)‖ ≤ L * |s - s'|)
    (hright : ∀ s t t', ‖F (s, t) - F (s, t')‖ ≤ M * |t - t'|) :
    LipschitzWith ⟨L + M, add_nonneg hL hM⟩ F := by
  apply LipschitzWith.of_dist_le_mul
  intro p q
  rw [dist_eq_norm]
  have h1 : |p.1 - q.1| ≤ dist p q := by
    rw [Prod.dist_eq, Real.dist_eq, Real.dist_eq]
    exact le_max_left _ _
  have h2 : |p.2 - q.2| ≤ dist p q := by
    rw [Prod.dist_eq, Real.dist_eq, Real.dist_eq]
    exact le_max_right _ _
  calc
    _ ≤ ‖F p - F (q.1, p.2)‖ + ‖F (q.1, p.2) - F q‖ := norm_sub_le_norm_sub_add_norm_sub _ _ _
    _ ≤ L * |p.1 - q.1| + M * |p.2 - q.2| := add_le_add (hleft p.1 q.1 p.2) (hright q.1 p.2 q.2)
    _ ≤ L * dist p q + M * dist p q := add_le_add
      (mul_le_mul_of_nonneg_left h1 hL) (mul_le_mul_of_nonneg_left h2 hM)
    _ = _ := by simp only [NNReal.coe_mk]; ring

/-- The cubic-left convolution is jointly continuous on all real endpoint lifts. -/
theorem continuous_cube_G_convolution (β : ℝ) (hβ : 0 < β) (R : KernelSpace A)
    (K : ℝ) (hK : 0 ≤ K)
    (hR : ∀ s t s' t', ‖R (s, t) - R (s', t')‖ ≤ K * (|s - s'| + |t - t'|)) :
    let G := freeThermalKernel (A := A) β + R
    Continuous (fun p => kernelConvolution β hβ.le (G ^ 3) G p) := by
  dsimp only
  let G := freeThermalKernel (A := A) β + R
  have hbase : 0 ≤ 1 + β * K := add_nonneg zero_le_one (mul_nonneg hβ.le hK)
  have hcubic : 0 ≤ ‖G‖ * (3 * ‖G‖ ^ 2) * (1 + β * K) :=
    mul_nonneg (mul_nonneg (norm_nonneg G) (mul_nonneg (by norm_num) (sq_nonneg ‖G‖))) hbase
  have hnorm : 0 ≤ ‖G ^ 3‖ * (1 + β * K) := mul_nonneg (norm_nonneg _) hbase
  exact (joint_lipschitz_of_endpoint_bounds
    (fun p => kernelConvolution β hβ.le (G ^ 3) G p)
    (‖G‖ * (3 * ‖G‖ ^ 2) * (1 + β * K)) (‖G ^ 3‖ * (1 + β * K))
    hcubic hnorm
    (cube_G_convolution_left β hβ R K hR) (cube_G_convolution_right β hβ R K hR)).continuous

/-- The cubic-right convolution is jointly continuous on all real endpoint lifts. -/
theorem continuous_G_cube_convolution (β : ℝ) (hβ : 0 < β) (R : KernelSpace A)
    (K : ℝ) (hK : 0 ≤ K)
    (hR : ∀ s t s' t', ‖R (s, t) - R (s', t')‖ ≤ K * (|s - s'| + |t - t'|)) :
    let G := freeThermalKernel (A := A) β + R
    Continuous (fun p => kernelConvolution β hβ.le G (G ^ 3) p) := by
  dsimp only
  let G := freeThermalKernel (A := A) β + R
  have hbase : 0 ≤ 1 + β * K := add_nonneg zero_le_one (mul_nonneg hβ.le hK)
  have hcubic : 0 ≤ ‖G‖ * (3 * ‖G‖ ^ 2) * (1 + β * K) :=
    mul_nonneg (mul_nonneg (norm_nonneg G) (mul_nonneg (by norm_num) (sq_nonneg ‖G‖))) hbase
  have hnorm : 0 ≤ ‖G ^ 3‖ * (1 + β * K) := mul_nonneg (norm_nonneg _) hbase
  exact (joint_lipschitz_of_endpoint_bounds
    (fun p => kernelConvolution β hβ.le G (G ^ 3) p)
    (‖G ^ 3‖ * (1 + β * K)) (‖G‖ * (3 * ‖G‖ ^ 2) * (1 + β * K))
    hnorm hcubic
    (G_cube_convolution_left β hβ R K hR) (G_cube_convolution_right β hβ R K hR)).continuous

end SYK.ConvolutionRegularity
