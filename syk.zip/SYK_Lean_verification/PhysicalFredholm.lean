import SpectralFredholm
import PhysicalOperatorAction

/-!
# Ordinary spectral Fredholm determinant of the actual physical operator

For this compact self-adjoint operator, the nonzero spectrum is exhausted by the
proved Fourier modes, has finite eigenspace multiplicities, no Jordan chains,
and an absolutely summable eigenvalue list. The ordinary spectral Fredholm
product is intrinsic to the operator and invariant under unitary changes of
basis. It is proved equal to the previous actual compression determinant.
-/
noncomputable section
open Filter Set Module.End
open scoped Topology NNReal
namespace SYK.PhysicalFredholm
open Continuum DiagonalFredholm FourierOperators SpectralFredholm

section Similarity
variable {E F : Type*} [NormedAddCommGroup E] [NormedSpace ℂ E] [CompleteSpace E]
  [NormedAddCommGroup F] [NormedSpace ℂ F] [CompleteSpace F]

theorem conjugate_bijective_iff (f : E → E) (g : F → F) (e : E ≃ F)
    (he : ∀ x, g (e x) = e (f x)) : Function.Bijective f ↔ Function.Bijective g := by
  have hg : g = e ∘ f ∘ e.symm := by
    funext y
    simpa only [Function.comp_def, e.apply_symm_apply] using he (e.symm y)
  have hf : f = e.symm ∘ g ∘ e := by
    funext x
    simp only [Function.comp_def, he, e.symm_apply_apply]
  constructor
  · intro h
    rw [hg]
    exact e.bijective.comp (h.comp e.symm.bijective)
  · intro h
    rw [hf]
    exact e.symm.bijective.comp (h.comp e.bijective)

theorem conjugate_spectrum (T : E →L[ℂ] E) (U : F →L[ℂ] F)
    (e : E ≃ₗ[ℂ] F) (he : ∀ x, U (e x) = e (T x)) : spectrum ℂ T = spectrum ℂ U := by
  ext z
  simp only [spectrum.mem_iff, ContinuousLinearMap.isUnit_iff_bijective]
  apply not_congr
  apply conjugate_bijective_iff _ _ e.toEquiv
  intro x
  simp only [ContinuousLinearMap.sub_apply, ContinuousLinearMap.algebraMap_apply,
    LinearEquiv.coe_toEquiv, he, map_sub, map_smul]

theorem intertwine_power (T : Module.End ℂ E) (U : Module.End ℂ F)
    (e : E ≃ₗ[ℂ] F) (he : ∀ x, U (e x) = e (T x)) (n : ℕ) (x : E) :
    (U^n) (e x) = e ((T^n) x) := by
  induction n generalizing x with
  | zero => simp
  | succ n ih => rw [pow_succ, pow_succ, Module.End.mul_apply, Module.End.mul_apply, he, ih]

theorem conjugate_gen_eigenspace (T : E →L[ℂ] E) (U : F →L[ℂ] F)
    (e : E ≃ₗ[ℂ] F) (he : ∀ x, U (e x) = e (T x)) (z : ℂ) (x : E) :
    e x ∈ Module.End.genEigenspace U.toLinearMap z ⊤ ↔
      x ∈ Module.End.genEigenspace T.toLinearMap z ⊤ := by
  have hs : ∀ y, (U.toLinearMap-z • 1) (e y) = e ((T.toLinearMap-z • 1) y) := by
    intro y
    change U (e y) - z • e y = e (T y-z • y)
    rw [he, map_sub, map_smul]
  constructor
  · intro hx
    rcases Module.End.mem_genEigenspace.mp hx with ⟨n,hn,hx⟩
    refine Module.End.mem_genEigenspace.mpr ⟨n,hn,?_⟩
    apply e.injective
    rw [← intertwine_power _ _ e hs n, map_zero]
    exact hx
  · intro hx
    rcases Module.End.mem_genEigenspace.mp hx with ⟨n,hn,hx⟩
    refine Module.End.mem_genEigenspace.mpr ⟨n,hn,?_⟩
    change ((U.toLinearMap-z • 1)^n) (e x) = 0
    rw [intertwine_power _ _ e hs n]
    simpa only [map_zero] using congrArg e hx
end Similarity

variable (β : ℝ) [Fact (0 < β)]

theorem physical_intertwining (lam : ℝ≥0) (g : ℝ → ℝ) (f : TimeHilbert β) :
    diagonal (sourceRatio β lam g) (transform β f) =
      transform β (physicalPerturbation β lam g f) := by
  rw [physicalPerturbation, transform_transport]

theorem physical_compact (lam : ℝ≥0) (g : ℝ → ℝ) (hg : PhysicalSolution β lam g) :
    IsCompactOperator (physicalPerturbation β lam g) := by
  have ha : Summable (fun n => |sourceRatio β lam g n|) := by
    simpa only [Real.norm_eq_abs] using (sourceRatio_summable β lam g hg).norm
  exact ((diagonal_compact _ ha).comp_clm
    (transform β).toContinuousLinearEquiv.toContinuousLinearMap).clm_comp
      (transform β).symm.toContinuousLinearEquiv.toContinuousLinearMap

theorem physical_selfAdjoint (lam : ℝ≥0) (g : ℝ → ℝ) (hg : PhysicalSolution β lam g) :
    IsSelfAdjoint (physicalPerturbation β lam g) := by
  have ha : Summable (fun n => |sourceRatio β lam g n|) := by
    simpa only [Real.norm_eq_abs] using (sourceRatio_summable β lam g hg).norm
  have hd := ContinuousLinearMap.isSelfAdjoint_iff_isSymmetric.mp (diagonal_selfAdjoint _ ha)
  apply ContinuousLinearMap.isSelfAdjoint_iff_isSymmetric.mpr
  intro x y
  rw [← (transform β).inner_map_map, ← (transform β).inner_map_map]
  simp only [ContinuousLinearMap.coe_coe, ← physical_intertwining]
  exact hd _ _

theorem physical_nonzero_spectrum (lam : ℝ≥0) (g : ℝ → ℝ)
    (hg : PhysicalSolution β lam g) (z : ℂ) (hz : z ≠ 0) :
    z ∈ spectrum ℂ (physicalPerturbation β lam g) ↔
      ∃ n : ℤ, (sourceRatio β lam g n : ℂ) = z := by
  rw [conjugate_spectrum _ _ (transform β).toLinearEquiv (physical_intertwining β lam g)]
  apply nonzero_spectrum_iff _ _ z hz
  simpa only [Real.norm_eq_abs] using (sourceRatio_summable β lam g hg).norm

theorem physical_eigenspace_finite (lam : ℝ≥0) (g : ℝ → ℝ)
    (hg : PhysicalSolution β lam g) (r : ℝ) (hr : r ≠ 0) :
    FiniteDimensional ℂ (Module.End.eigenspace (physicalPerturbation β lam g).toLinearMap (r : ℂ)) := by
  have ha : Summable (fun n => |sourceRatio β lam g n|) := by
    simpa only [Real.norm_eq_abs] using (sourceRatio_summable β lam g hg).norm
  letI := finite_fiber (sourceRatio β lam g) ha r hr
  letI := Fintype.ofFinite (Fiber (sourceRatio β lam g) r)
  let e := (conjugateEigenspaceEquiv _ _ (transform β).toLinearEquiv
    (physical_intertwining β lam g) r).trans (eigenspaceEquiv _ ha r)
  exact FiniteDimensional.of_injective e.toLinearMap e.injective

theorem physical_multiplicity (lam : ℝ≥0) (g : ℝ → ℝ)
    (hg : PhysicalSolution β lam g) (r : ℝ) (hr : r ≠ 0) :
    Module.finrank ℂ (Module.End.eigenspace (physicalPerturbation β lam g).toLinearMap (r : ℂ)) =
      Nat.card (Fiber (sourceRatio β lam g) r) := by
  rw [(conjugateEigenspaceEquiv _ _ (transform β).toLinearEquiv
    (physical_intertwining β lam g) r).finrank_eq]
  apply diagonal_multiplicity _ _ r hr
  simpa only [Real.norm_eq_abs] using (sourceRatio_summable β lam g hg).norm

theorem ordinary_determinant_eq_compression (lam : ℝ≥0) (g : ℝ → ℝ)
    (hg : PhysicalSolution β lam g) :
    spectralDeterminant (physicalPerturbation β lam g) = (physicalDeterminant β lam g).re := by
  rw [spectralDeterminant_conjugate _ _ (transform β).toLinearEquiv
    (physical_intertwining β lam g), physicalDeterminant_eq β lam g hg, Complex.ofReal_re]
  apply diagonal_spectralDeterminant
  simpa only [Real.norm_eq_abs] using (sourceRatio_summable β lam g hg).norm

theorem physical_no_jordan_chains (lam : ℝ≥0) (g : ℝ → ℝ)
    (hg : PhysicalSolution β lam g) (r : ℝ) :
    Module.End.genEigenspace (physicalPerturbation β lam g).toLinearMap (r : ℂ) ⊤ =
      Module.End.eigenspace (physicalPerturbation β lam g).toLinearMap (r : ℂ) := by
  have ha : Summable (fun n => |sourceRatio β lam g n|) := by
    simpa only [Real.norm_eq_abs] using (sourceRatio_summable β lam g hg).norm
  ext x
  rw [← conjugate_gen_eigenspace _ _ (transform β).toLinearEquiv
    (physical_intertwining β lam g) (r : ℂ) x,
    generalized_eigenspace_eq _ ha r, Module.End.mem_eigenspace_iff,
    Module.End.mem_eigenspace_iff]
  change diagonal (sourceRatio β lam g) (transform β x) = (r : ℂ) • transform β x ↔
    physicalPerturbation β lam g x = (r : ℂ) • x
  rw [physical_intertwining, ← map_smul]
  exact (transform β).injective.eq_iff

theorem physical_algebraic_multiplicity (lam : ℝ≥0) (g : ℝ → ℝ)
    (hg : PhysicalSolution β lam g) (r : ℝ) (hr : r ≠ 0) :
    Module.finrank ℂ (Module.End.genEigenspace (physicalPerturbation β lam g).toLinearMap
      (r : ℂ) ⊤) = Nat.card (Fiber (sourceRatio β lam g) r) := by
  rw [physical_no_jordan_chains β lam g hg]
  exact physical_multiplicity β lam g hg r hr

/-- The intrinsic eigenvalues, counted with actual algebraic multiplicity,
are absolutely summable. Together with compact self-adjointness this is the
spectral trace-class condition for this concrete relative operator. -/
theorem physical_spectral_trace_class (lam : ℝ≥0) (g : ℝ → ℝ)
    (hg : PhysicalSolution β lam g) :
    HasSum (fun r : ℝ =>
      (Module.finrank ℂ (Module.End.genEigenspace (physicalPerturbation β lam g).toLinearMap
        (r : ℂ) ⊤) : ℝ) * |r|)
      (∑' n : ℤ, |sourceRatio β lam g n|) := by
  have ha : Summable (fun n => |sourceRatio β lam g n|) := by
    simpa only [Real.norm_eq_abs] using (sourceRatio_summable β lam g hg).norm
  convert spectral_absolute_sum (sourceRatio β lam g) ha using 1
  funext r
  rw [physical_no_jordan_chains β lam g hg,
    (conjugateEigenspaceEquiv _ _ (transform β).toLinearEquiv
      (physical_intertwining β lam g) r).finrank_eq]

/-- Strict positivity of the ordinary spectral Fredholm determinant. -/
theorem ordinary_determinant_pos (lam : ℝ≥0) (g : ℝ → ℝ)
    (hg : PhysicalSolution β lam g) :
    0 < spectralDeterminant (physicalPerturbation β lam g) := by
  rw [ordinary_determinant_eq_compression β lam g hg]
  exact (physicalDeterminant_pos β lam g hg).2

/-- The ordinary, basis-independent spectral Fredholm action equals the
coupling-integral pressure for every actual bounded physical family. -/
theorem couplingPressure_eq_ordinary_fredholm_action (g : ℝ≥0 → ℝ → ℝ)
    (hp : ∀ l, PhysicalSolution β l (g l)) (B : ℝ) (hb : ∀ l t, |g l t| ≤ B)
    (lam : ℝ≥0) :
    couplingPressure β g lam = Real.log 2 / 2 +
      (1/2 : ℝ) * Real.log (spectralDeterminant (physicalPerturbation β lam (g lam))) -
        (3 * β / 8) * (lam : ℝ) * quarticIntegral β (g lam) := by
  rw [ordinary_determinant_eq_compression β lam (g lam) (hp lam)]
  exact couplingPressure_eq_physical_operator_action β g hp B hb lam

end SYK.PhysicalFredholm
