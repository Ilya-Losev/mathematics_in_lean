import ContinuumWickSeries

/-! # Exact pointwise algebra of the continuum interaction coefficients

All statements are identities in the actual exterior algebra or its constructed
scalar Wick expectation. No exterior-valued integral or Ward premise is used.
-/
noncomputable section
open scoped BigOperators
namespace SYK.WardInteraction
open ThermalWick Ward WickVertexIntegrals ContinuumWickSeries DuhamelHistory DuhamelVertex

@[simp] theorem collectiveMonomial_append {N : ℕ} {β : ℝ}
    (ps qs : List (Time β × Time β)) :
    collectiveMonomial (N := N) (ps++qs) = collectiveMonomial ps * collectiveMonomial qs := by
  simp only [collectiveMonomial, List.map_append, List.prod_append]

@[simp] theorem collectiveMonomial_replicate {N : ℕ} {β : ℝ}
    (n : ℕ) (p : Time β × Time β) :
    collectiveMonomial (N := N) (List.replicate n p) = collective N β p.1 p.2 ^ n := by
  simp only [collectiveMonomial, List.map_replicate, List.prod_replicate]

/-- Four repeated collective coordinates are exactly the fourth power at
each ordered continuum interaction vertex. -/
theorem interactionPairs_monomial (N : ℕ) (β : ℝ) (hβ : 0<β)
    {n : ℕ} (u : Fin n → ℝ×ℝ) :
    collectiveMonomial (N := N) (interactionPairs β hβ u) =
      orderedProduct (fun i => collective N β
        (timeRepresentative β hβ (u i).1) (timeRepresentative β hβ (u i).2)^4) := by
  induction n with
  | zero => simp [interactionPairs,collectiveMonomial,orderedProduct]
  | succ n ih =>
    rw [orderedProduct_succ]
    have he : interactionPairs β hβ u =
        List.replicate 4 (timeRepresentative β hβ (u 0).1,timeRepresentative β hβ (u 0).2) ++
          interactionPairs β hβ (fun i => u i.succ) := by
      simp only [interactionPairs,List.ofFn_succ,List.flatten_cons]
    rw [he,collectiveMonomial_append,collectiveMonomial_replicate,ih]

/-- The exact N/8 factor appears once per quartic vertex. -/
theorem quartic_product (N : ℕ) (β : ℝ) (hβ : 0<β)
    {n : ℕ} (u : Fin n → ℝ×ℝ) :
    orderedProduct (fun i => quarticDensity N β 1
      (timeRepresentative β hβ (u i).1) (timeRepresentative β hβ (u i).2)) =
      ((N:ℂ)/8)^n • collectiveMonomial (N := N) (interactionPairs β hβ u) := by
  simp only [quarticDensity,Complex.ofReal_one,mul_one,orderedProduct_smul,
    Finset.prod_const,Finset.card_univ,Fintype.card_fin,interactionPairs_monomial]

/-- The actual coefficient integrand times its prefactor is precisely the
Wick expectation with the ordered product of physical quartic densities. -/
theorem coefficientIntegrand_eq_quartic_product (d : ℕ) (β : ℝ) (hβ : 0<β)
    (ps : List (Time β × Time β)) {n : ℕ} (u : Fin n → ℝ×ℝ) :
    ((((2*d:ℕ):ℝ)/8)^n) • coefficientIntegrand d β hβ ps u =
      expectation (2*d) β (collectiveMonomial ps * orderedProduct
        (fun i => quarticDensity (2*d) β 1
          (timeRepresentative β hβ (u i).1) (timeRepresentative β hβ (u i).2))) := by
  rw [quartic_product, mul_smul_comm, map_smul]
  simp only [coefficientIntegrand,collectiveMonomial_append,smul_eq_mul]
  simp only [Complex.real_smul,Complex.ofReal_pow,Complex.ofReal_div,Complex.ofReal_natCast,
    Complex.ofReal_ofNat]

/-- Even exterior elements have a genuine commutative-center representative. -/
def centralEven {N : ℕ} {β : ℝ} (P : FieldAlgebra N β)
    (hP : CliffordAlgebra.involute P=P) : Subalgebra.center ℂ (FieldAlgebra N β) :=
  ⟨P,Subalgebra.mem_center_iff.mpr (fun Q => (even_commutes P Q hP).symm)⟩

/-- Ordered products of even elements agree with products in the actual
commutative exterior center. -/
theorem orderedProduct_even_center {N : ℕ} {β : ℝ} {n : ℕ}
    (P : Fin n → FieldAlgebra N β) (hP : ∀ i, CliffordAlgebra.involute (P i)=P i) :
    orderedProduct P =
      ((∏ i, centralEven (P i) (hP i) : Subalgebra.center ℂ (FieldAlgebra N β)) : FieldAlgebra N β) := by
  change _ = (Subalgebra.val (Subalgebra.center ℂ (FieldAlgebra N β))) _
  rw [← List.prod_ofFn,map_list_prod,List.map_ofFn]
  rfl

/-- The marked factor may be extracted at any index because every factor
really is even; its remaining order is the canonical succAbove order. -/
theorem orderedProduct_even_update {N : ℕ} {β : ℝ} {n : ℕ}
    (P : Fin (n+1) → FieldAlgebra N β)
    (hP : ∀ i, CliffordAlgebra.involute (P i)=P i)
    (r : Fin (n+1)) (Q : FieldAlgebra N β) (hQ : CliffordAlgebra.involute Q=Q) :
    orderedProduct (Function.update P r Q) = Q * orderedProduct (fun i => P (r.succAbove i)) := by
  classical
  have hu : ∀ i, CliffordAlgebra.involute (Function.update P r Q i) = Function.update P r Q i := by
    intro i
    by_cases hi : i=r
    · subst i; simpa using hQ
    · simpa only [Function.update_of_ne hi] using hP i
  rw [orderedProduct_even_center _ hu,orderedProduct_even_center _ (fun i => hP (r.succAbove i))]
  rw [Fin.prod_univ_succAbove _ r, Subalgebra.coe_mul]
  congr 1
  · simp only [centralEven,Function.update_self]
  · congr 1
    apply Finset.prod_congr rfl
    intro i _
    apply Subtype.ext
    simp only [centralEven,Function.update_of_ne (Fin.succAbove_ne r i)]

@[simp] theorem collectiveMonomial_singleton {N : ℕ} {β : ℝ} (p : Time β × Time β) :
    collectiveMonomial (N := N) [p] = collective N β p.1 p.2 := by
  simp only [collectiveMonomial,List.map_cons,List.map_nil,List.prod_cons,List.prod_nil,mul_one]

/-- The two exact marked quartic partner terms, with the residual interaction
vertices left in their original order. The N/8 factor belongs only to those
residual vertices; the marked density contributes its exact factor 1/2. -/
theorem normalized_partner_inserted_quartic (d : ℕ) (hd : 0<d)
    (β : ℝ) (hβ : 0<β) (ps : List (Time β × Time β))
    (s t a b : Time β) {n : ℕ} (u : Fin n → ℝ×ℝ) :
    expectation (2*d) β
      (collectiveMonomial ps * (-(((2*d:ℕ):ℂ)⁻¹) •
        partnerContraction s t (quarticDensity (2*d) β 1 a b)) *
        orderedProduct (fun i => quarticDensity (2*d) β 1
          (timeRepresentative β hβ (u i).1) (timeRepresentative β hβ (u i).2))) =
      ((((2*d:ℕ):ℂ)/8)^n/2) *
        ((Thermal.kernel β s.val a.val : ℂ) *
          coefficientIntegrand d β hβ (ps ++ List.replicate 3 (a,b) ++ [(b,t)]) u -
        (Thermal.kernel β s.val b.val : ℂ) *
          coefficientIntegrand d β hβ (ps ++ List.replicate 3 (a,b) ++ [(a,t)]) u) := by
  rw [normalized_quartic_partner (by omega : 0<2*d) 1,quartic_product]
  simp only [coefficientIntegrand,collectiveMonomial_append,collectiveMonomial_replicate,
    collectiveMonomial_singleton,Complex.ofReal_one,mul_smul_comm,smul_mul_assoc,
    mul_sub,sub_mul,map_sub,map_smul,smul_eq_mul,mul_assoc]
  ring

/-- The actual quartic density at one real continuum time pair. -/
def densityAt (N : ℕ) (β : ℝ) (hβ : 0<β) (x : ℝ×ℝ) : FieldAlgebra N β :=
  quarticDensity N β 1 (timeRepresentative β hβ x.1) (timeRepresentative β hβ x.2)

/-- Pointwise scalar term with an arbitrary marked vertex replaced by its
normalized distinguished-flavor partner contraction. -/
def markedIntegrand (d : ℕ) (β : ℝ) (hβ : 0<β)
    (ps : List (Time β × Time β)) (s t : Time β) {n : ℕ}
    (u : Fin (n+1) → ℝ×ℝ) (r : Fin (n+1)) : ℂ :=
  expectation (2*d) β (collectiveMonomial ps * orderedProduct
    (Function.update (fun i => densityAt (2*d) β hβ (u i)) r
      (-(((2*d:ℕ):ℂ)⁻¹) • partnerContraction s t (densityAt (2*d) β hβ (u r)))))

/-- The marked normalized partner insertion is even as an actual exterior
identity, so it can be moved through every other quartic interaction factor. -/
theorem normalized_quartic_partner_even {N : ℕ} (hN : 0<N) {β : ℝ}
    (s t a b : Time β) :
    CliffordAlgebra.involute (-((N:ℂ)⁻¹) • partnerContraction s t (quarticDensity N β 1 a b)) =
      -((N:ℂ)⁻¹) • partnerContraction s t (quarticDensity N β 1 a b) := by
  rw [normalized_quartic_partner hN 1]
  simp only [map_smul,map_mul,map_pow,map_sub,collective_even]

/-- Exact arbitrary-index marked coefficient identity. The remaining n
vertices are indexed by succAbove, ready for the product-measure Fubini split. -/
theorem markedIntegrand_eq (d : ℕ) (hd : 0<d) (β : ℝ) (hβ : 0<β)
    (ps : List (Time β × Time β)) (s t : Time β) {n : ℕ}
    (u : Fin (n+1) → ℝ×ℝ) (r : Fin (n+1)) :
    markedIntegrand d β hβ ps s t u r =
      ((((2*d:ℕ):ℂ)/8)^n/2) *
        ((Thermal.kernel β s.val (timeRepresentative β hβ (u r).1).val : ℂ) *
          coefficientIntegrand d β hβ
            (ps ++ List.replicate 3 (timeRepresentative β hβ (u r).1,timeRepresentative β hβ (u r).2) ++
              [(timeRepresentative β hβ (u r).2,t)]) (fun i => u (r.succAbove i)) -
        (Thermal.kernel β s.val (timeRepresentative β hβ (u r).2).val : ℂ) *
          coefficientIntegrand d β hβ
            (ps ++ List.replicate 3 (timeRepresentative β hβ (u r).1,timeRepresentative β hβ (u r).2) ++
              [(timeRepresentative β hβ (u r).1,t)]) (fun i => u (r.succAbove i))) := by
  unfold markedIntegrand densityAt
  rw [orderedProduct_even_update _ (fun i => quarticDensity_even (2*d) β 1 _ _) r _
    (normalized_quartic_partner_even (by omega : 0<2*d) s t _ _)]
  simp only [← mul_assoc]
  exact normalized_partner_inserted_quartic d hd β hβ ps s t _ _ _

end SYK.WardInteraction
