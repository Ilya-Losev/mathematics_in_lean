import GapChamberCoordinates

/-!
# Ordered gap assignments and genuine count compositions

The bijection is constructed from finite fibers and sorting. Its counting
content is not assumed as a multinomial identity.
-/

noncomputable section
open scoped BigOperators
open MeasureTheory
open SYK.GapChamberCoordinates SYK.GapAssignmentPartition SYK.OrderedSimplexIntegral

namespace SYK.GapCountCompositions

/-- A globally ordered history visits the external gaps in this order. -/
abbrev MonotoneAssignment (n k : ℕ) := {g : Fin n → Fin k // Monotone g}

/-- The exact finite set of gap-count vectors at total vertex number n. -/
def CountComposition (n k : ℕ) := {r : Fin k → ℕ // ∑ j, r j = n}

instance (n k : ℕ) : Fintype (MonotoneAssignment n k) := Fintype.ofFinite _

/-- Permuting labels preserves every actual fiber count. -/
theorem gapCount_comp_perm {n k : ℕ} (g : Fin n → Fin k) (σ : Equiv.Perm (Fin n)) :
    gapCount (g ∘ σ) = gapCount g := by
  funext j
  apply Fintype.card_congr
  exact σ.subtypeEquiv (fun i => Iff.rfl)

/-- An ordered assignment is uniquely determined by its counts. -/
theorem eq_of_gapCount_eq {n k : ℕ} (g h : Fin n → Fin k)
    (hg : Monotone g) (hh : Monotone h) (he : gapCount g = gapCount h) : g = h := by
  let es (j : Fin k) : {i : Fin n // g i = j} ≃ {i : Fin n // h i = j} :=
    Fintype.equivOfCardEq (congrFun he j)
  let σ : Equiv.Perm (Fin n) := Equiv.ofFiberEquiv es
  have hs : h ∘ σ = g := funext (Equiv.ofFiberEquiv_map es)
  have hm : Monotone (h ∘ σ) := hs.symm ▸ hg
  have hu := Tuple.unique_monotone (f := h) (σ := σ) (τ := Equiv.refl _) hm hh
  simpa only [hs, Equiv.coe_refl, Function.comp_id] using hu

/-- An arbitrary finite block labelling realizes its prescribed counts. -/
theorem exists_assignment_of_counts {n k : ℕ} (r : Fin k → ℕ) (hr : ∑ j, r j = n) :
    ∃ g : Fin n → Fin k, gapCount g = r := by
  let e : (Σ j : Fin k, Fin (r j)) ≃ Fin n :=
    Fintype.equivOfCardEq (by simpa only [Fintype.card_sigma, Fintype.card_fin] using hr)
  let g : Fin n → Fin k := fun i => (e.symm i).1
  refine ⟨g, ?_⟩
  funext j
  let f : Fin (r j) → {i : Fin n // g i = j} := fun l =>
    ⟨e ⟨j,l⟩, by simp [g]⟩
  have hf : Function.Bijective f := by
    constructor
    · intro l m hlm
      have h := e.injective (congrArg Subtype.val hlm)
      simpa using h
    · intro i
      obtain ⟨j', l, he⟩ : ∃ (j' : Fin k) (l : Fin (r j')), e.symm i.val = ⟨j',l⟩ := by
        rcases e.symm i.val with ⟨j', l⟩
        exact ⟨j', l, rfl⟩
      have hj : j' = j := by simpa only [g, he] using i.property
      subst j'
      refine ⟨l, Subtype.eq ?_⟩
      change e ⟨j,l⟩ = i.val
      rw [← he, e.apply_symm_apply]
  have hc := Fintype.card_congr (Equiv.ofBijective f hf)
  simpa only [Fintype.card_fin, gapCount] using hc.symm

/-- Sorting an arbitrary realization constructs an ordered realization
without changing any count. -/
theorem exists_monotone_assignment_of_counts {n k : ℕ}
    (r : Fin k → ℕ) (hr : ∑ j, r j = n) :
    ∃ g : Fin n → Fin k, Monotone g ∧ gapCount g = r := by
  obtain ⟨g, hg⟩ := exists_assignment_of_counts r hr
  exact ⟨g ∘ Tuple.sort g, Tuple.monotone_sort g, (gapCount_comp_perm g _).trans hg⟩

def assignmentCounts {n k : ℕ} (g : MonotoneAssignment n k) : CountComposition n k :=
  ⟨gapCount g.val, sum_gapCount g.val⟩

theorem assignmentCounts_bijective (n k : ℕ) :
    Function.Bijective (@assignmentCounts n k) := by
  constructor
  · intro g h he
    apply Subtype.eq
    exact eq_of_gapCount_eq g.val h.val g.property h.property (congrArg Subtype.val he)
  · intro r
    obtain ⟨g, hg, hgr⟩ := exists_monotone_assignment_of_counts r.val r.property
    exact ⟨⟨g,hg⟩, Subtype.eq hgr⟩

/-- The actual bijection used to regroup ordered chambers by gap counts. -/
def assignmentCountEquiv (n k : ℕ) : MonotoneAssignment n k ≃ CountComposition n k :=
  Equiv.ofBijective assignmentCounts (assignmentCounts_bijective n k)

instance (n k : ℕ) : Fintype (CountComposition n k) :=
  Fintype.ofEquiv (MonotoneAssignment n k) (assignmentCountEquiv n k)

@[simp] theorem assignmentCountEquiv_apply {n k : ℕ} (g : MonotoneAssignment n k) :
    (assignmentCountEquiv n k g).val = gapCount g.val := rfl

@[simp] theorem gapCount_assignmentCountEquiv_symm {n k : ℕ} (r : CountComposition n k) :
    gapCount ((assignmentCountEquiv n k).symm r).val = r.val := by
  exact congrArg Subtype.val ((assignmentCountEquiv n k).apply_symm_apply r)

/-- Exact finite reindexing; no combinatorial multiplicity remains on the
ordered simplex because each composition has one ordered assignment. -/
theorem sum_monotone_assignments_eq_sum_counts {M : Type*} [AddCommMonoid M]
    (n k : ℕ) (F : (Fin k → ℕ) → M) :
    (∑ g : MonotoneAssignment n k, F (gapCount g.val)) =
      ∑ r : CountComposition n k, F r.val := by
  exact (assignmentCountEquiv n k).sum_comp (fun r => F r.val)

/-- Exact total-degree regrouping of any genuinely convergent gap series.
The finite fibers are the count compositions constructed above. -/
theorem hasSum_group_by_total {E : Type*} [NormedAddCommGroup E] [CompleteSpace E]
    {k : ℕ} {F : (Fin k → ℕ) → E} {v : E} (hF : HasSum F v) :
    HasSum (fun n : ℕ => ∑ r : CountComposition n k, F r.val) v := by
  have h := hF.tsum_fiberwise (fun r : Fin k → ℕ => ∑ j, r j)
  convert h using 1
  funext n
  change (∑ r : CountComposition n k, F r.val) = ∑' r : CountComposition n k, F r.val
  exact (tsum_fintype (fun r : CountComposition n k => F r.val)).symm

/-- The final finite integral combinatorics for a piecewise-constant free
ordered history: each actual chamber contributes its product simplex volume,
and every count composition occurs once. -/
theorem integral_simplex_eq_sum_counts_of_chamber_constant {E : Type*}
    [NormedAddCommGroup E] [NormedSpace ℝ E] [CompleteSpace E] {n k : ℕ}
    (t : Fin (k+1) → ℝ) (ht : Antitone t) (f : (Fin n → ℝ) → E)
    (hf : IntegrableOn f (orderedSimplex n (t (Fin.last k)) (t 0)))
    (F : (Fin k → ℕ) → E)
    (hconst : ∀ (g : Fin n → Fin k), Monotone g →
      ∀ u ∈ orderedAssignmentRegion t g, f u = F (gapCount g)) :
    ∫ u in orderedSimplex n (t (Fin.last k)) (t 0), f u =
      ∑ r : CountComposition n k,
        (∏ j, (t j.castSucc-t j.succ)^(r.val j) / (r.val j).factorial) • F r.val := by
  classical
  rw [integral_simplex_eq_sum_monotone_assignments t ht f hf,
    Finset.sum_subtype (p := fun g : Fin n → Fin k => Monotone g) _ (fun g => by simp)]
  calc
    _ = ∑ g : MonotoneAssignment n k,
        (∏ j, (t j.castSucc-t j.succ)^(gapCount g.val j) / (gapCount g.val j).factorial) •
          F (gapCount g.val) := by
      apply Finset.sum_congr rfl
      intro g _
      rw [setIntegral_congr_fun (orderedAssignmentRegion_measurable t g.val)
        (hconst g.val g.property), setIntegral_const,
        orderedAssignmentRegion_volume_real t ht g.val g.property]
    _ = _ := sum_monotone_assignments_eq_sum_counts n k
      (fun r => (∏ j, (t j.castSucc-t j.succ)^(r j) / (r j).factorial) • F r)

end SYK.GapCountCompositions
