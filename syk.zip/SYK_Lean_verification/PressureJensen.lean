import PressureWellDefined

noncomputable section
open MeasureTheory
open scoped NNReal
namespace SYK.Microscopic

/-- Jensen's inequality for the actual finite-N pressures. This establishes
only the direction of their comparison, not the asymptotic vanishing gap. -/
theorem quenchedPressure_le_annealedPressure (m : ℕ) (β : ℝ) (lam : ℝ≥0) :
    quenchedPressure m β lam ≤ annealedPressure m β lam := by
  let Z := fun j => (Majorana.partitionFunction m β j).re
  let a := ∫ j, Z j ∂disorder m lam
  have ha : 0 < a := annealed_partition_pos m β lam
  have hZ : Integrable Z (disorder m lam) := real_partitionFunction_integrable m β lam
  have hl : Integrable (fun j => Real.log (Z j)) (disorder m lam) :=
    log_partitionFunction_integrable m β lam
  have hpoint (j) : Real.log (Z j) ≤ Real.log a + Z j / a - 1 := by
    have hpos : 0 < Z j := Gibbs.syk_partition_re_pos m β j
    have h := Real.log_le_sub_one_of_pos (div_pos hpos ha)
    rw [Real.log_div hpos.ne' ha.ne'] at h
    linarith
  have hi := integral_mono hl
    (((integrable_const (Real.log a)).add (hZ.div_const a)).sub (integrable_const 1))
    hpoint
  simp only [Pi.sub_apply, Pi.add_apply] at hi
  have hmean : (∫ j, (Real.log a + Z j / a - 1) ∂disorder m lam) = Real.log a := by
    have hsub := integral_sub
      ((integrable_const (Real.log a)).add (hZ.div_const a))
      (integrable_const (μ := disorder m lam) (1 : ℝ))
    simp only [Pi.add_apply] at hsub
    rw [hsub]
    have hadd := integral_add (integrable_const (Real.log a)) (hZ.div_const a)
    rw [hadd, integral_div]
    simp only [integral_const, measureReal_univ_eq_one, one_smul]
    change Real.log a + a / a - 1 = Real.log a
    rw [div_self ha.ne']
    ring
  rw [hmean] at hi
  exact div_le_div_of_nonneg_right hi (Nat.cast_nonneg (2 * m))

end SYK.Microscopic
