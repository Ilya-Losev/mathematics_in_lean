import DuhamelTrace
import GaussianDisorder

/-!
# A concrete dimension-uniform SYK gradient bound

Four-subsets are partitioned by their first three increasing indices. Within
each fiber their normalized quartic operators anticommute, so positivity of
the actual Gibbs density bounds the sum of squared expectations by 1/16.
There are at most N^3 fibers. This deliberately nonsharp constant is sufficient
for a Gaussian concentration argument: multiplying by variance 6λ/N^3 leaves
a bound independent of N.
-/

set_option maxHeartbeats 600000
noncomputable section
open scoped BigOperators ComplexOrder NNReal
namespace SYK.GlobalGradient
open Majorana AntiCommuting

/-- Concrete involutive Majorana matrices, indexed by Fin N. -/
def gammaFin (m : ℕ) (i : Fin (2 * m)) : Matrix (Basis m) (Basis m) ℂ :=
  gamma m ((flavorEquivFin m).symm i)

@[simp] theorem gammaFin_star (m : ℕ) (i : Fin (2 * m)) :
    star (gammaFin m i) = gammaFin m i := gamma_star _ _

@[simp] theorem gammaFin_square (m : ℕ) (i : Fin (2 * m)) :
    gammaFin m i * gammaFin m i = 1 := gamma_square _ _

theorem gammaFin_anticommute (m : ℕ) (i k : Fin (2 * m)) (hik : i ≠ k) :
    gammaFin m i * gammaFin m k = -(gammaFin m k * gammaFin m i) :=
  gamma_anticommute _ _ _ (fun h => hik ((flavorEquivFin m).symm.injective h))

def firstTriple (m : ℕ) (I : FourSet m) : Fin (2 * m) × Fin (2 * m) × Fin (2 * m) :=
  (fourIndex m I 0, fourIndex m I 1, fourIndex m I 2)

/-- First three indices and the last index determine the actual four-subset. -/
theorem fourSet_eq_of_indices (m : ℕ) (I J : FourSet m)
    (htr : firstTriple m I = firstTriple m J)
    (hlast : fourIndex m I 3 = fourIndex m J 3) : I = J := by
  have h0 : fourIndex m I 0 = fourIndex m J 0 := congrArg Prod.fst htr
  have h1 : fourIndex m I 1 = fourIndex m J 1 := congrArg (fun t => t.2.1) htr
  have h2 : fourIndex m I 2 = fourIndex m J 2 := congrArg (fun t => t.2.2) htr
  have he : (fourIndex m I : Fin 4 → Fin (2 * m)) = fourIndex m J := by
    funext k
    fin_cases k <;> assumption
  apply Subtype.ext
  apply Finset.coe_injective
  rw [← Finset.range_orderEmbOfFin I.val I.property,
    ← Finset.range_orderEmbOfFin J.val J.property]
  exact congrArg Set.range he

/-- Actual Gibbs quartic expectation, with the paper's Majorana normalization. -/
def quarticExpectation (m : ℕ) (β : ℝ) (j : FourSet m → ℝ) (I : FourSet m) : ℝ :=
  (Matrix.trace (Gibbs.sykDensity m β j * quartic m I)).re

/-- A fiber of the first-three-index map has the sharp common-triple bound. -/
theorem fiber_sq_bound (m : ℕ) (β : ℝ) (j : FourSet m → ℝ)
    (t : Fin (2 * m) × Fin (2 * m) × Fin (2 * m)) :
    ∑ I ∈ Finset.univ.filter (fun I : FourSet m => firstTriple m I = t),
      (quarticExpectation m β j I)^2 ≤ 1 / 16 := by
  classical
  let s := Finset.univ.filter (fun I : FourSet m => firstTriple m I = t)
  by_cases hs : s.Nonempty
  · obtain ⟨I₀, hI₀⟩ := hs
    have hI₀t : firstTriple m I₀ = t := (Finset.mem_filter.mp hI₀).2
    let U := gammaFin m
    let T := U (fourIndex m I₀ 0) * U (fourIndex m I₀ 1) * U (fourIndex m I₀ 2)
    have hdistinct (r q : Fin 4) (hrq : r ≠ q) : fourIndex m I₀ r ≠ fourIndex m I₀ q :=
      fun h => hrq ((fourIndex m I₀).injective h)
    have hT : T * T = -1 := triple_square _ _ _
      (gammaFin_square m _) (gammaFin_square m _) (gammaFin_square m _)
      (gammaFin_anticommute m _ _ (hdistinct 1 0 (by decide)))
      (gammaFin_anticommute m _ _ (hdistinct 2 0 (by decide)))
      (gammaFin_anticommute m _ _ (hdistinct 2 1 (by decide)))
    have hTstar : star T = -T := triple_skewAdjoint _ _ _
      (gammaFin_star m _) (gammaFin_star m _) (gammaFin_star m _)
      (gammaFin_anticommute m _ _ (hdistinct 1 0 (by decide)))
      (gammaFin_anticommute m _ _ (hdistinct 2 0 (by decide)))
      (gammaFin_anticommute m _ _ (hdistinct 2 1 (by decide)))
    have htr (I : FourSet m) (hI : I ∈ s) : firstTriple m I = firstTriple m I₀ :=
      (Finset.mem_filter.mp hI).2.trans hI₀t.symm
    have hprod (I : FourSet m) (hI : I ∈ s) : gammaQuartic m I = T * U (fourIndex m I 3) := by
      have h := htr I hI
      have h0 := congrArg Prod.fst h
      have h1 := congrArg (fun t => t.2.1) h
      have h2 := congrArg (fun t => t.2.2) h
      simp only [firstTriple] at h0 h1 h2
      change U (fourIndex m I 0) * U (fourIndex m I 1) * U (fourIndex m I 2) * U (fourIndex m I 3) = _
      rw [h0, h1, h2]
    have hout (I : FourSet m) (hI : I ∈ s) :
        U (fourIndex m I 3) * T = -(T * U (fourIndex m I 3)) := by
      have h := htr I hI
      have h0 := congrArg Prod.fst h
      have h1 := congrArg (fun t => t.2.1) h
      have h2 := congrArg (fun t => t.2.2) h
      simp only [firstTriple] at h0 h1 h2
      apply triple_anticommute
      · apply gammaFin_anticommute
        rw [← h0]
        exact fun e => (by decide : (3 : Fin 4) ≠ 0) ((fourIndex m I).injective e)
      · apply gammaFin_anticommute
        rw [← h1]
        exact fun e => (by decide : (3 : Fin 4) ≠ 1) ((fourIndex m I).injective e)
      · apply gammaFin_anticommute
        rw [← h2]
        exact fun e => (by decide : (3 : Fin 4) ≠ 2) ((fourIndex m I).injective e)
    have hb := density_sum_sq_le_one s (gammaQuartic m) (Gibbs.sykDensity m β j)
      (Gibbs.sykDensity_posSemidef m β j) (Gibbs.sykDensity_trace_one m β j)
      (fun I hI => by rw [hprod I hI]; exact shared_triple_selfAdjoint _ _ hTstar (gammaFin_star m _) (hout I hI))
      (fun I hI => by rw [hprod I hI]; exact shared_triple_square _ _ hT (gammaFin_square m _) (hout I hI))
      (fun I hI J hJ hIJ => by
        rw [hprod I hI, hprod J hJ]
        apply shared_triple_anticommute _ _ _ (hout I hI) (hout J hJ)
        have hlast : fourIndex m I 3 ≠ fourIndex m J 3 := by
          intro he
          exact hIJ (fourSet_eq_of_indices m I J ((htr I hI).trans (htr J hJ).symm) he)
        rw [gammaFin_anticommute m _ _ hlast, neg_add_cancel])
    have heq : (∑ I ∈ s, (quarticExpectation m β j I)^2) =
        (1 / 16 : ℝ) * ∑ I ∈ s, ((Matrix.trace (Gibbs.sykDensity m β j * gammaQuartic m I)).re)^2 := by
      rw [Finset.mul_sum]
      apply Finset.sum_congr rfl
      intro I _
      simp only [quarticExpectation, quartic_eq, mul_smul_comm, Matrix.trace_smul,
        Complex.real_smul, Complex.mul_re, Complex.ofReal_re, Complex.ofReal_im,
        zero_mul, sub_zero]
      ring
    change (∑ I ∈ s, (quarticExpectation m β j I)^2) ≤ _
    rw [heq]
    linarith
  · have he : s = ∅ := Finset.not_nonempty_iff_eq_empty.mp hs
    change (∑ I ∈ s, (quarticExpectation m β j I)^2) ≤ _
    rw [he]
    norm_num


/-- Summing the actual fibers yields the crucial O(N³), rather than O(N⁴),
quartic expectation bound. Its nonsharp numerical constant is sufficient for
vanishing annealed–quenched pressure gap. -/
theorem quartic_expectation_sq_sum_le (m : ℕ) (β : ℝ) (j : FourSet m → ℝ) :
    ∑ I, (quarticExpectation m β j I)^2 ≤ (2 * m : ℝ)^3 / 16 := by
  classical
  rw [← Finset.sum_fiberwise Finset.univ (firstTriple m)
    (fun I => (quarticExpectation m β j I)^2)]
  calc
    _ ≤ ∑ _t : Fin (2 * m) × Fin (2 * m) × Fin (2 * m), (1 / 16 : ℝ) :=
      Finset.sum_le_sum (fun t _ => fiber_sq_bound m β j t)
    _ = _ := by
      simp only [Finset.sum_const, Finset.card_univ, Fintype.card_prod,
        Fintype.card_fin, nsmul_eq_mul, Nat.cast_mul, Nat.cast_ofNat]
      ring

/-- The actual vector of coupling partial derivatives of log Z. -/
def logGradient (m : ℕ) (β : ℝ) (j : FourSet m → ℝ) (I : FourSet m) : ℝ :=
  β * quarticExpectation m β j I

theorem logGradient_sq_sum_le (m : ℕ) (β : ℝ) (j : FourSet m → ℝ) :
    ∑ I, (logGradient m β j I)^2 ≤ β^2 * (2 * m : ℝ)^3 / 16 := by
  have he : (∑ I, (logGradient m β j I)^2) =
      β^2 * ∑ I, (quarticExpectation m β j I)^2 := by
    simp only [logGradient, mul_pow, Finset.mul_sum]
  rw [he]
  exact (mul_le_mul_of_nonneg_left (quartic_expectation_sq_sum_le m β j) (sq_nonneg β)).trans_eq (by ring)

/-- Multiplying the actual squared-gradient bound by the exact disorder
variance removes all dependence on the flavor count. -/
theorem variance_mul_logGradient_sq_sum_le (m : ℕ) (hm : 0 < m) (β : ℝ)
    (j : FourSet m → ℝ) (lam : ℝ≥0) :
    (GaussianDisorder.variance (2 * m) lam : ℝ) * ∑ I, (logGradient m β j I)^2 ≤
      3 * β^2 * (lam : ℝ) / 8 := by
  have hm' : (m : ℝ) ≠ 0 := Nat.cast_ne_zero.mpr (Nat.ne_of_gt hm)
  calc
    _ ≤ (GaussianDisorder.variance (2 * m) lam : ℝ) * (β^2 * (2 * m : ℝ)^3 / 16) :=
      mul_le_mul_of_nonneg_left (logGradient_sq_sum_le m β j) (NNReal.coe_nonneg _)
    _ = _ := by
      simp only [GaussianDisorder.variance, NNReal.coe_div, NNReal.coe_mul,
        NNReal.coe_pow, NNReal.coe_natCast, NNReal.coe_ofNat, Nat.cast_mul, Nat.cast_ofNat]
      field_simp [hm']
      ring

/-- Cauchy–Schwarz turns the actual gradient vector bound into a bound for
every concrete directional derivative. -/
theorem directional_response_sq_le (m : ℕ) (β : ℝ)
    (j w : FourSet m → ℝ) :
    (∑ I, logGradient m β j I * w I)^2 ≤
      (β^2 * (2 * m : ℝ)^3 / 16) * ∑ I, (w I)^2 := by
  exact (Finset.sum_mul_sq_le_sq_mul_sq Finset.univ (logGradient m β j) w).trans
    (mul_le_mul_of_nonneg_right (logGradient_sq_sum_le m β j)
      (Finset.sum_nonneg (fun _ _ => sq_nonneg _)))

/-- This is the derivative of the concrete log partition function, with its
coefficients identified as the bounded gradient above. -/
theorem hasDerivAt_logPartition_line (m : ℕ) (β : ℝ) (j w : FourSet m → ℝ) (t : ℝ) :
    HasDerivAt (fun s : ℝ => Real.log (partitionFunction m β (fun I => j I + s * w I)).re)
      (∑ I, logGradient m β (fun I => j I + t * w I) I * w I) t := by
  convert DuhamelTrace.hasDerivAt_syk_log_partition_direction_at m β j w t using 1
  simp only [logGradient, quarticExpectation, Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro I _
  ring

end SYK.GlobalGradient

