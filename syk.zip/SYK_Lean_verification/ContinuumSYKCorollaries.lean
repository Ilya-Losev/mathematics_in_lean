import ContinuumSYKMain
import ComplexPhysicalUniqueness

/-! Literal complex integral-operator identification and model-independent
free-energy consequences of the assembled continuum theorem. -/
noncomputable section
open MeasureTheory Filter
open scoped Topology NNReal
namespace SYK.ContinuumSYKMain
open Continuum FourierOperators ComplexFourierOperatorAction
variable (β : ℝ) [Fact (0 < β)]

/-- Every bounded measurable complex test has precisely the actual nested
Lebesgue integral action of −CΣ, in the genuine time-domain Hilbert space. -/
theorem MainConclusion.operator_complex_integral_action {g : ℝ≥0 → ℝ → ℝ}
    (h : MainConclusion β g) (lam : ℝ≥0) (f : ℝ → ℂ) (hf : Measurable f)
    (D : ℝ) (hD : ∀ t, ‖f t‖ ≤ D) :
    (physicalPerturbation β lam (g lam) (complexCircleL2 β f hf D hD) : AddCircle β → ℂ)
      =ᵐ[AddCircle.haarAddCircle] -complexCircleLift β (complexCovarianceSource β lam (g lam) f) :=
  physicalPerturbation_complex_integral_action β lam (g lam) f
    (h.solution lam).physical hf (1/2) D (h.solution lam).sharp_bound hD

/-- The literal complex integral action uniquely identifies the entire
continuous Hilbert operator. Density of the tests is proved by the Fourier
basis, and is not an additional hypothesis. -/
theorem MainConclusion.operator_unique {g : ℝ≥0 → ℝ → ℝ}
    (h : MainConclusion β g) (lam : ℝ≥0)
    (T : TimeHilbert β →L[ℂ] TimeHilbert β)
    (hT : ∀ (f : ℝ → ℂ) (hf : Measurable f) (D : ℝ) (hD : ∀ t, ‖f t‖ ≤ D),
      (T (complexCircleL2 β f hf D hD) : AddCircle β → ℂ) =ᵐ[AddCircle.haarAddCircle]
        -complexCircleLift β (complexCovarianceSource β lam (g lam) f)) :
    T = physicalPerturbation β lam (g lam) :=
  physical_operator_unique β lam (g lam) (h.solution lam).physical (1/2)
    (h.solution lam).sharp_bound T hT

/-- Uniqueness holds pointwise for the whole simultaneously chosen family. -/
theorem MainConclusion.family_unique {g f : ℝ≥0 → ℝ → ℝ}
    (h : MainConclusion β g) (hf : ∀ lam, PhysicalSolution β lam (f lam)) : f = g := by
  funext lam
  exact (h.solution lam).unique (f lam) (hf lam)

/-- The actual arbitrary-representation free energies have the same limit,
with the exact minus sign and normalization per Majorana. -/
theorem MainConclusion.arbitrary_representation_freeEnergy {g : ℝ≥0 → ℝ → ℝ}
    (h : MainConclusion β g) {κ : ℕ → Type*}
    [∀ d, Fintype (κ d)] [∀ d, DecidableEq (κ d)]
    (x : ∀ d, Fin (2*d) → Matrix (κ d) (κ d) ℂ)
    (hx : ∀ d, 2 ≤ d → ∀ i j, x d i*x d j+x d j*x d i =
      FreeWick.flavorDelta i j • (1 : Matrix (κ d) (κ d) ℂ))
    (hcard : ∀ d, 2 ≤ d → Fintype.card (κ d) = 2^d) (J : ℝ) :
    Tendsto (fun d => -RepresentationIndependence.annealedPressure d (x d) β (couplingOfJ J)/β)
      atTop (𝓝 (couplingFreeEnergy β g J)) ∧
    Tendsto (fun d => -RepresentationIndependence.quenchedPressure d (x d) β (couplingOfJ J)/β)
      atTop (𝓝 (couplingFreeEnergy β g J)) := by
  have hp := h.arbitrary_representation β x hx hcard J
  exact ⟨hp.1.neg.div_const β, hp.2.neg.div_const β⟩

end SYK.ContinuumSYKMain
