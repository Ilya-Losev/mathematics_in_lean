import OrderedCubePartition
import GapSimplexIntegral

/-!
# Partitioning genuine interaction-time regions by fixed external-time gaps

All gap assignments are finite, disjoint measurable regions. Their union
covers the full cube, and its ordered simplex, modulo the already-proved null
sets at the fixed external times. Coincident external times are allowed.
-/

noncomputable section
open scoped BigOperators
open MeasureTheory MeasureTheory.Measure Set
open SYK.OrderedSimplexIntegral SYK.OrderedCubePartition

namespace SYK.GapAssignmentPartition

/-- Open gap between consecutive descending external boundary times. -/
def gapInterval {k : ℕ} (t : Fin (k+1) → ℝ) (g : Fin k) : Set ℝ :=
  Ioo (t g.succ) (t g.castSucc)

/-- A labelled interaction time belongs to its specified external-time gap. -/
def assignmentRegion {n k : ℕ} (t : Fin (k+1) → ℝ) (g : Fin n → Fin k) :
    Set (Fin n → ℝ) := univ.pi (fun i => gapInterval t (g i))

theorem exists_gap_of_avoid {k : ℕ} (t : Fin (k+1) → ℝ) (ht : Antitone t)
    (x : ℝ) (hl : t (Fin.last k) < x) (hr : x < t 0)
    (ha : ∀ j, x ≠ t j) : ∃ g : Fin k, x ∈ gapInterval t g := by
  induction k with
  | zero => exact False.elim (lt_irrefl x (hr.trans hl))
  | succ k ih =>
      by_cases hx : t (Fin.succ 0) < x
      · exact ⟨0, hx, hr⟩
      · have hx' : x < t (Fin.succ 0) := lt_of_le_of_ne (le_of_not_gt hx) (ha _)
        obtain ⟨g, hg⟩ := ih (fun i => t i.succ)
          (fun _ _ hij => ht (Fin.succ_le_succ_iff.mpr hij)) hl hx' (fun _ => ha _)
        refine ⟨g.succ, ?_⟩
        simpa [gapInterval, Fin.succ_castSucc] using hg

theorem gapInterval_subset_bounds {k : ℕ} (t : Fin (k+1) → ℝ) (ht : Antitone t)
    (g : Fin k) : gapInterval t g ⊆ Icc (t (Fin.last k)) (t 0) := by
  intro x hx
  exact ⟨(ht (Fin.le_last g.succ)).trans hx.1.le,
    hx.2.le.trans (ht (Fin.zero_le g.castSucc))⟩

theorem gapInterval_pairwise_disjoint {k : ℕ} (t : Fin (k+1) → ℝ) (ht : Antitone t) :
    Pairwise (fun g h : Fin k => Disjoint (gapInterval t g) (gapInterval t h)) := by
  intro g h hgh
  rw [disjoint_left]
  intro x hx hy
  rcases lt_or_gt_of_ne hgh with hlt | hlt
  · have he : g.succ ≤ h.castSucc := by simpa only [Fin.le_iff_val_le_val, Fin.val_succ,
      Fin.coe_castSucc] using Nat.succ_le_of_lt hlt
    exact (lt_irrefl x) (hy.2.trans_le (ht he) |>.trans hx.1)
  · have he : h.succ ≤ g.castSucc := by simpa only [Fin.le_iff_val_le_val, Fin.val_succ,
      Fin.coe_castSucc] using Nat.succ_le_of_lt hlt
    exact (lt_irrefl x) (hx.2.trans_le (ht he) |>.trans hy.1)

theorem assignmentRegion_measurable {n k : ℕ} (t : Fin (k+1) → ℝ) (g : Fin n → Fin k) :
    MeasurableSet (assignmentRegion t g) := MeasurableSet.univ_pi (fun _ => measurableSet_Ioo)

theorem assignmentRegion_subset_cube {n k : ℕ} (t : Fin (k+1) → ℝ) (ht : Antitone t)
    (g : Fin n → Fin k) : assignmentRegion t g ⊆ timeCube n (t (Fin.last k)) (t 0) := by
  intro u hu i hi
  exact gapInterval_subset_bounds t ht (g i) (hu i hi)

theorem assignmentRegion_pairwise_disjoint {n k : ℕ} (t : Fin (k+1) → ℝ) (ht : Antitone t) :
    Pairwise (fun g h : Fin n → Fin k => Disjoint (assignmentRegion t g) (assignmentRegion t h)) := by
  intro g h hgh
  rw [disjoint_left]
  intro u hu hv
  apply hgh
  funext i
  by_contra hi
  exact (disjoint_left.mp (gapInterval_pairwise_disjoint t ht hi))
    (hu i (mem_univ _)) (hv i (mem_univ _))

/-- Fixed insertion boundaries have measure zero even when they repeat. -/
theorem ae_avoid_boundaries (n : ℕ) {k : ℕ} (t : Fin (k+1) → ℝ) :
    ∀ᵐ u : Fin n → ℝ, ∀ j i, u i ≠ t j :=
  ae_all_iff.mpr (fun j => ae_times_avoid n (t j))

theorem assignmentRegion_union_ae_cube (n : ℕ) {k : ℕ}
    (t : Fin (k+1) → ℝ) (ht : Antitone t) :
    (⋃ g : Fin n → Fin k, assignmentRegion t g) =ᵐ[volume]
      timeCube n (t (Fin.last k)) (t 0) := by
  filter_upwards [ae_avoid_boundaries n t] with u hu
  apply propext
  constructor
  · intro h
    obtain ⟨g, hg⟩ := mem_iUnion.mp h
    exact assignmentRegion_subset_cube t ht g hg
  · intro h
    have he (i : Fin n) : ∃ g : Fin k, u i ∈ gapInterval t g :=
      exists_gap_of_avoid t ht (u i)
        (lt_of_le_of_ne (h i (mem_univ _)).1 (hu _ i).symm)
        (lt_of_le_of_ne (h i (mem_univ _)).2 (hu _ i)) (fun j => hu j i)
    choose g hg using he
    exact mem_iUnion.mpr ⟨g, fun i _ => hg i⟩

/-- Each labelled gap assignment is a literal rectangle, with its exact
product Lebesgue measure. -/
theorem assignmentRegion_volume_real {n k : ℕ} (t : Fin (k+1) → ℝ) (ht : Antitone t)
    (g : Fin n → Fin k) :
    volume.real (assignmentRegion t g) = ∏ i : Fin n, (t (g i).castSucc - t (g i).succ) := by
  rw [measureReal_def, assignmentRegion, volume_pi_pi, ENNReal.toReal_prod]
  apply Finset.prod_congr rfl
  intro i _
  rw [gapInterval, Real.volume_Ioo, ENNReal.toReal_ofReal]
  exact sub_nonneg.mpr (ht (by simp [Fin.le_iff_val_le_val]))

/-- The portion of the globally ordered simplex having a prescribed gap assignment. -/
def orderedAssignmentRegion {n k : ℕ} (t : Fin (k+1) → ℝ) (g : Fin n → Fin k) :
    Set (Fin n → ℝ) :=
  orderedSimplex n (t (Fin.last k)) (t 0) ∩ assignmentRegion t g

theorem orderedAssignmentRegion_measurable {n k : ℕ} (t : Fin (k+1) → ℝ)
    (g : Fin n → Fin k) : MeasurableSet (orderedAssignmentRegion t g) :=
  (orderedSimplex_measurable n _ _).inter (assignmentRegion_measurable t g)

theorem orderedAssignmentRegion_union_ae_simplex (n : ℕ) {k : ℕ}
    (t : Fin (k+1) → ℝ) (ht : Antitone t) :
    (⋃ g : Fin n → Fin k, orderedAssignmentRegion t g) =ᵐ[volume]
      orderedSimplex n (t (Fin.last k)) (t 0) := by
  filter_upwards [assignmentRegion_union_ae_cube n t ht] with u hu
  apply propext
  change (u ∈ ⋃ g : Fin n → Fin k, orderedAssignmentRegion t g) ↔
    u ∈ orderedSimplex n (t (Fin.last k)) (t 0)
  simp only [mem_iUnion, orderedAssignmentRegion, mem_inter_iff]
  constructor
  · rintro ⟨g, h, _⟩; exact h
  · intro h
    have hc : u ∈ timeCube n (t (Fin.last k)) (t 0) := fun i _ => ⟨h.1 i, h.2.1 i⟩
    have hh : u ∈ ⋃ g : Fin n → Fin k, assignmentRegion t g := hu.mpr hc
    obtain ⟨g, hg⟩ := mem_iUnion.mp hh
    exact ⟨g, h, hg⟩

/-- Ordered times can only visit the descending gaps in their natural order. -/
theorem monotone_of_mem_orderedAssignmentRegion {n k : ℕ} (t : Fin (k+1) → ℝ)
    (ht : Antitone t) (g : Fin n → Fin k) {u : Fin n → ℝ}
    (hu : u ∈ orderedAssignmentRegion t g) : Monotone g := by
  intro i j hij
  by_contra h
  have hlt : g j < g i := lt_of_not_ge h
  have he : (g j).succ ≤ (g i).castSucc := by
    simpa only [Fin.le_iff_val_le_val, Fin.val_succ, Fin.coe_castSucc] using Nat.succ_le_of_lt hlt
  have hui := hu.2 i (mem_univ _)
  have huj := hu.2 j (mem_univ _)
  have hh : u i < u j := hui.2.trans_le (ht he) |>.trans huj.1
  exact (hu.1.2.2 hij).not_lt hh

theorem orderedAssignmentRegion_eq_empty_of_not_monotone {n k : ℕ}
    (t : Fin (k+1) → ℝ) (ht : Antitone t) (g : Fin n → Fin k) (hg : ¬ Monotone g) :
    orderedAssignmentRegion t g = ∅ := by
  apply Set.eq_empty_iff_forall_not_mem.mpr
  intro u hu
  exact hg (monotone_of_mem_orderedAssignmentRegion t ht g hu)

section Integrals
variable {E : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E]

theorem integral_cube_eq_sum_assignments {n k : ℕ} (t : Fin (k+1) → ℝ) (ht : Antitone t)
    (f : (Fin n → ℝ) → E) (hf : IntegrableOn f (timeCube n (t (Fin.last k)) (t 0))) :
    ∫ u in timeCube n (t (Fin.last k)) (t 0), f u =
      ∑ g : Fin n → Fin k, ∫ u in assignmentRegion t g, f u := by
  rw [← setIntegral_congr_set (assignmentRegion_union_ae_cube n t ht)]
  exact integral_fintype_iUnion (assignmentRegion_measurable t)
    (assignmentRegion_pairwise_disjoint t ht)
    (fun g => hf.mono_set (assignmentRegion_subset_cube t ht g))

theorem integral_simplex_eq_sum_ordered_assignments {n k : ℕ}
    (t : Fin (k+1) → ℝ) (ht : Antitone t) (f : (Fin n → ℝ) → E)
    (hf : IntegrableOn f (orderedSimplex n (t (Fin.last k)) (t 0))) :
    ∫ u in orderedSimplex n (t (Fin.last k)) (t 0), f u =
      ∑ g : Fin n → Fin k, ∫ u in orderedAssignmentRegion t g, f u := by
  rw [← setIntegral_congr_set (orderedAssignmentRegion_union_ae_simplex n t ht)]
  apply integral_fintype_iUnion (orderedAssignmentRegion_measurable t)
  · intro g h hgh
    exact (assignmentRegion_pairwise_disjoint t ht hgh).mono inter_subset_right inter_subset_right
  · intro g; exact hf.mono_set inter_subset_left

/-- Only weakly increasing gap assignments contribute to an ordered history;
all other chambers are proved empty. -/
theorem integral_simplex_eq_sum_monotone_assignments {n k : ℕ}
    (t : Fin (k+1) → ℝ) (ht : Antitone t) (f : (Fin n → ℝ) → E)
    (hf : IntegrableOn f (orderedSimplex n (t (Fin.last k)) (t 0))) :
    ∫ u in orderedSimplex n (t (Fin.last k)) (t 0), f u =
      ∑ g ∈ Finset.univ.filter (fun g : Fin n → Fin k => Monotone g),
        ∫ u in orderedAssignmentRegion t g, f u := by
  classical
  rw [integral_simplex_eq_sum_ordered_assignments t ht f hf, Finset.sum_filter]
  apply Finset.sum_congr rfl
  intro g _
  by_cases hg : Monotone g
  · simp [hg]
  · simp [hg, orderedAssignmentRegion_eq_empty_of_not_monotone t ht g hg]

end Integrals
end SYK.GapAssignmentPartition
