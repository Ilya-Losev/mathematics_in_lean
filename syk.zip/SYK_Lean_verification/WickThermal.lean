import WickContraction
import ThermalCovariance

/-!
# The concrete free thermal exterior functional

This module instantiates the exterior Wick construction with the actual midpoint
thermal covariance and Kronecker flavor delta. Time labels range over the whole
fundamental interval, not a finite grid. Every algebraic element uses finitely
many labels, as in the exterior algebra in the manuscript.

The fundamental-interval construction avoids imposing inconsistent independent
symbols for antiperiodic lifts. A definition of lifted fields, operator trace
correspondence, and interacting Duhamel integration are still separate work.
-/

noncomputable section

namespace SYK.ThermalWick

/-- Exact continuous time in the fundamental thermal interval. -/
def Time (β : ℝ) := {t : ℝ // t ∈ Set.Ico 0 β}

/-- A finite flavor and an arbitrary time in the fundamental interval. -/
def Label (N : ℕ) (β : ℝ) := Fin N × Time β

/-- Free field vectors have finite support, even though time is continuous. -/
abbrev FieldSpace (N : ℕ) (β : ℝ) := Label N β →₀ ℂ

/-- The actual thermal covariance, with the Kronecker flavor delta. -/
def kernel (N : ℕ) (β : ℝ) (p q : Label N β) : ℂ :=
  if p.1 = q.1 then (SYK.Thermal.kernel β p.2.val q.2.val : ℂ) else 0

theorem kernel_skew (N : ℕ) (β : ℝ) (p q : Label N β) :
    kernel N β p q = -kernel N β q p := by
  unfold kernel
  by_cases h : p.1 = q.1
  · rw [if_pos h, if_pos h.symm]
    exact_mod_cast (SYK.Thermal.kernel_skew β q.2.val p.2.val)
  · rw [if_neg h, if_neg (Ne.symm h), neg_zero]

@[simp] theorem kernel_diagonal (N : ℕ) (β : ℝ) (p : Label N β) :
    kernel N β p p = 0 := by
  simp [kernel]

/-- The genuine alternating covariance of the continuous-time field space. -/
def covariance (N : ℕ) (β : ℝ) : SYK.Wick.Covariance ℂ (FieldSpace N β) :=
  SYK.Wick.covarianceOfKernel (kernel N β) (kernel_skew N β)

/-- The genuine exterior field at one flavor and one continuous time. -/
def field {N : ℕ} {β : ℝ} (i : Fin N) (s : Time β) :
    ExteriorAlgebra ℂ (FieldSpace N β) :=
  ExteriorAlgebra.ι ℂ (Finsupp.single (i, s) 1)

/-- The constructed free thermal Wick functional, before interactions. -/
def expectation (N : ℕ) (β : ℝ) : ExteriorAlgebra ℂ (FieldSpace N β) →ₗ[ℂ] ℂ :=
  (covariance N β).expectation

@[simp] theorem expectation_one (N : ℕ) (β : ℝ) : expectation N β 1 = 1 := by
  exact SYK.Wick.Covariance.expectation_one _

/-- The actual two-point function, including coincident times and flavors. -/
theorem expectation_two {N : ℕ} {β : ℝ} (i j : Fin N) (s t : Time β) :
    expectation N β (field i s * field j t) =
      if i = j then (SYK.Thermal.kernel β s.val t.val : ℂ) else 0 := by
  exact SYK.Wick.kernel_expectation_two (kernel N β) (kernel_skew N β) (i, s) (j, t)

/-- A normalized collective bilocal with the exact microscopic 1/N convention. -/
def collective (N : ℕ) (β : ℝ) (s t : Time β) :
    ExteriorAlgebra ℂ (FieldSpace N β) :=
  ((N : ℂ)⁻¹) • ∑ i : Fin N, field i s * field i t

@[simp] theorem covariance_single {N : ℕ} {β : ℝ} (i j : Fin N) (s t : Time β) :
    (covariance N β).form (Finsupp.single (i, s) 1) (Finsupp.single (j, t) 1) =
      if i = j then (SYK.Thermal.kernel β s.val t.val : ℂ) else 0 := by
  simp [covariance, SYK.Wick.covarianceOfKernel, kernel]

/-- The exact flavor-averaged contraction identity used in the continuum Ward proof. -/
theorem contraction_collective {N : ℕ} {β : ℝ} (i : Fin N) (s u v : Time β) :
    (covariance N β).contraction (Finsupp.single (i, s) 1) (collective N β u v) =
      ((N : ℂ)⁻¹) •
        ((SYK.Thermal.kernel β s.val u.val : ℂ) • field i v -
          (SYK.Thermal.kernel β s.val v.val : ℂ) • field i u) := by
  change (covariance N β).contraction (Finsupp.single (i, s) 1)
    (SYK.Wick.Covariance.collective ((N : ℂ)⁻¹)
      (fun j : Fin N => Finsupp.single (j, u) 1)
      (fun j : Fin N => Finsupp.single (j, v) 1)) = _
  rw [SYK.Wick.Covariance.contraction_collective]
  simp only [covariance_single]
  simp [field, ite_smul]

/-- Every same-time collective coordinate is zero by exterior exclusion. -/
@[simp] theorem collective_diagonal (N : ℕ) (β : ℝ) (s : Time β) :
    collective N β s s = 0 := by
  simp [collective, field, ExteriorAlgebra.ι_sq_zero]

/-- Collective bilocals have even exterior parity. -/
theorem collective_even (N : ℕ) (β : ℝ) (s t : Time β) :
    CliffordAlgebra.involute (collective N β s t) = collective N β s t := by
  simp [collective, field]

/-- Exchanging the endpoints produces the exact fermionic minus sign. -/
theorem collective_skew (N : ℕ) (β : ℝ) (s t : Time β) :
    collective N β s t = -collective N β t s := by
  unfold collective
  rw [← smul_neg, ← Finset.sum_neg_distrib]
  congr 1
  apply Finset.sum_congr rfl
  intro i _
  exact eq_neg_of_add_eq_zero_left
    (ExteriorAlgebra.ι_add_mul_swap (Finsupp.single (i, s) 1) (Finsupp.single (i, t) 1))

/-- Free collective expectation has exactly the prescribed kernel normalization. -/
theorem expectation_collective {N : ℕ} (hN : 0 < N) (β : ℝ) (s t : Time β) :
    expectation N β (collective N β s t) = (SYK.Thermal.kernel β s.val t.val : ℂ) := by
  have hNC : (N : ℂ) ≠ 0 := by exact_mod_cast (Nat.ne_of_gt hN)
  simp [collective, map_smul, map_sum, expectation_two, smul_eq_mul, hNC,
    Finset.sum_const, nsmul_eq_mul, ← mul_assoc]

/-- A four-field computation checks the microscopic repeated-flavor contact sign. -/
theorem expectation_bilocal_product {N : ℕ} {β : ℝ} (i j : Fin N) (s t : Time β) :
    expectation N β ((field i s * field i t) * (field j s * field j t)) =
      (SYK.Thermal.kernel β s.val t.val : ℂ) ^ 2 -
        if i = j then (SYK.Thermal.kernel β s.val t.val : ℂ) ^ 2 else 0 := by
  rw [mul_assoc]
  change (covariance N β).expectation
    (ExteriorAlgebra.ι ℂ (Finsupp.single (i, s) 1) *
      (ExteriorAlgebra.ι ℂ (Finsupp.single (i, t) 1) *
        (ExteriorAlgebra.ι ℂ (Finsupp.single (j, s) 1) *
          ExteriorAlgebra.ι ℂ (Finsupp.single (j, t) 1)))) = _
  refine ((covariance N β).expectation_four (Finsupp.single (i, s) 1)
    (Finsupp.single (i, t) 1) (Finsupp.single (j, s) 1) (Finsupp.single (j, t) 1)).trans ?_
  simp only [covariance_single, ite_true, SYK.Thermal.kernel_diagonal,
    Complex.ofReal_zero, ite_self, zero_mul, sub_zero]
  by_cases h : i = j
  · rw [if_pos h, if_pos h, if_pos h, SYK.Thermal.kernel_skew β s.val t.val]
    simp [Complex.ofReal_neg, pow_two]
  · simp [h, pow_two]

/-- The exact free finite-N collective second moment, with the 1/N contact term. -/
theorem expectation_collective_square {N : ℕ} (hN : 0 < N)
    (β : ℝ) (s t : Time β) :
    expectation N β (collective N β s t * collective N β s t) =
      (1 - (N : ℂ)⁻¹) * (SYK.Thermal.kernel β s.val t.val : ℂ) ^ 2 := by
  have hNC : (N : ℂ) ≠ 0 := by exact_mod_cast (Nat.ne_of_gt hN)
  simp only [collective, smul_mul_assoc, mul_smul_comm, smul_smul,
    Finset.sum_mul, Finset.mul_sum, map_smul, map_sum, expectation_bilocal_product]
  simp only [Finset.sum_sub_distrib, Finset.sum_const, Finset.card_univ,
    Fintype.card_fin, Finset.sum_ite_eq, Finset.mem_univ, ite_true, nsmul_eq_mul,
    smul_eq_mul]
  field_simp
  ring

end SYK.ThermalWick
