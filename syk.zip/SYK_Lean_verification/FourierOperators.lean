import OnShellAction
import DiagonalFredholm

/-!
# The physical relative operator on the actual fermionic L² space

The half-frequency twist identifies the time-domain Hilbert space with the
circle's ordinary L² space. The operator below is built by unitary transport
of a summable diagonal operator. Its action is proved to be the literal nested
Lebesgue convolution with the free covariance and the physical cubic source.
-/
noncomputable section
open MeasureTheory Filter
open scoped Topology ComplexConjugate BigOperators NNReal
namespace SYK.FourierOperators
open Continuum DiagonalFredholm

variable (β : ℝ) [Fact (0 < β)]
abbrev TimeHilbert := Lp ℂ 2 (@AddCircle.haarAddCircle β _)

/-- The genuine unitary Fourier transform, including the half-frequency twist
when applied to `circleL2`. -/
def transform : TimeHilbert β ≃ₗᵢ[ℂ] H (ι := ℤ) :=
  (@_root_.fourierBasis β _).repr

/-- Transport an actual bounded operator, not just its scalar coefficients. -/
def transport (T : H (ι := ℤ) →L[ℂ] H (ι := ℤ)) :
    TimeHilbert β →L[ℂ] TimeHilbert β :=
  (transform β).symm.toContinuousLinearEquiv.toContinuousLinearMap.comp
    (T.comp (transform β).toContinuousLinearEquiv.toContinuousLinearMap)

@[simp] theorem transform_transport (T : H (ι := ℤ) →L[ℂ] H (ι := ℤ))
    (f : TimeHilbert β) : transform β (transport β T f) = T (transform β f) := by
  simp [transport]

/-- This operator is minus CΣ; hence the relative operator is one plus this. -/
def physicalPerturbation (lam : ℝ≥0) (g : ℝ → ℝ) :
    TimeHilbert β →L[ℂ] TimeHilbert β :=
  transport β (diagonal (sourceRatio β lam g))

theorem perturbation_coefficient (lam : ℝ≥0) (g : ℝ → ℝ)
    (hg : PhysicalSolution β lam g) (f : TimeHilbert β) (n : ℤ) :
    _root_.fourierCoeff (physicalPerturbation β lam g f) n =
      (sourceRatio β lam g n : ℂ) * _root_.fourierCoeff f n := by
  rw [← _root_.fourierBasis_repr, ← _root_.fourierBasis_repr]
  change transform β (physicalPerturbation β lam g f) n = _
  rw [physicalPerturbation, transform_transport, diagonal_apply]
  · rfl
  · simpa only [Real.norm_eq_abs] using (sourceRatio_summable β lam g hg).norm

/-- The source is the actual scalar function λg³. -/
def source (lam : ℝ≥0) (g : ℝ → ℝ) (t : ℝ) : ℝ := (lam : ℝ) * (g t)^3

theorem source_fourier_product (lam : ℝ≥0) (g : ℝ → ℝ)
    (hg : PhysicalSolution β lam g) (n : ℤ) :
    fourier β (Thermal.covariance β) (integerFrequency β n) *
      fourier β (source lam g) (integerFrequency β n) =
        -(sourceRatio β lam g (-n) : ℂ) := by
  have hc := free_physicalSolution β (Fact.out : 0 < β)
  have hs : ∀ t, source lam g (β-t) = source lam g t := by
    intro t; simp only [source, hg.2.2.2.2.1]
  rw [integer_fourier_imaginary β _ hc.2.2.2.2.1,
    integer_fourier_imaginary β _ hs, free_integer_fourier_im,
    sourceRatio_eq_source_fourier]
  simp only [neg_neg, Complex.ofReal_div, Complex.ofReal_inv]
  calc
    _ = (Complex.I * Complex.I) *
        ((fourier β (source lam g) (integerFrequency β n)).im : ℂ) *
          (integerFrequency β n : ℂ)⁻¹ := by ring
    _ = _ := by
      rw [Complex.I_mul_I]
      change (-1 : ℂ) * ((fourier β (source lam g) (integerFrequency β n)).im : ℂ) *
        (integerFrequency β n : ℂ)⁻¹ =
          -(((fourier β (source lam g) (integerFrequency β n)).im : ℂ) /
            (integerFrequency β n : ℂ))
      ring

/-- Every signed odd frequency has the correct antiperiodic phase. -/
theorem integer_wave_phase (n : ℤ) : wave (integerFrequency β n) β = -1 := by
  by_cases hn : 0 ≤ n
  · rw [integerFrequency_nonneg β n hn]
    simpa [wave, mul_assoc] using frequency_phase β (Fact.out : 0 < β) n.toNat
  · rw [integerFrequency_neg β n (lt_of_not_ge hn)]
    have hp := frequency_phase β (Fact.out : 0 < β) (-n-1).toNat
    have hnexp : wave (-frequency β (-n-1).toNat) β =
        conj (Complex.exp (Complex.I * (frequency β (-n-1).toNat : ℂ) * (β : ℂ))) := by
      rw [← Complex.exp_conj]
      simp [wave, mul_assoc]
    rw [hnexp, hp]
    simp

theorem source_measurable (lam : ℝ≥0) (g : ℝ → ℝ) (hg : Measurable g) :
    Measurable (source lam g) := measurable_const.mul (hg.pow_const 3)

theorem source_bound (lam : ℝ≥0) (g : ℝ → ℝ) (B : ℝ)
    (hb : ∀ t, |g t| ≤ B) (t : ℝ) : |source lam g t| ≤ (lam : ℝ) * B^3 := by
  simp only [source, abs_mul, abs_of_nonneg lam.coe_nonneg, abs_pow]
  exact mul_le_mul_of_nonneg_left (pow_le_pow_left₀ (abs_nonneg _) (hb t) 3) lam.coe_nonneg

omit [Fact (0 < β)] in
theorem source_antiperiodic (lam : ℝ≥0) (g : ℝ → ℝ)
    (ha : ∀ t, g (t+β) = -g t) (t : ℝ) : source lam g (t+β) = -source lam g t := by
  simp only [source, ha]
  ring

/-- The literal time-domain composition CΣ, using two ordinary Lebesgue integrals. -/
def covarianceSource (lam : ℝ≥0) (g h : ℝ → ℝ) : ℝ → ℝ :=
  scalarConvolution β (Thermal.covariance β) (scalarConvolution β (source lam g) h)

theorem covarianceSource_measurable (lam : ℝ≥0) (g h : ℝ → ℝ)
    (hg : Measurable g) (hh : Measurable h) : Measurable (covarianceSource β lam g h) :=
  scalarConvolution_measurable β (Fact.out : 0 < β).le _ _
    (Thermal.covariance_measurable β)
    (scalarConvolution_measurable β (Fact.out : 0 < β).le _ _
      (source_measurable lam g hg) hh)

theorem covarianceSource_bound (lam : ℝ≥0) (g h : ℝ → ℝ)
    (B D : ℝ) (hb : ∀ t, |g t| ≤ B) (hd : ∀ t, |h t| ≤ D) (t : ℝ) :
    |covarianceSource β lam g h t| ≤ β * ((1/2) * (β * ((lam : ℝ) * B^3 * D))) :=
  scalarConvolution_bound β (Fact.out : 0 < β).le _ _ (1/2) _
    (Thermal.abs_covariance_le β)
    (scalarConvolution_bound β (Fact.out : 0 < β).le _ _ _ D (source_bound lam g B hb) hd) t

theorem covarianceSource_fourier (lam : ℝ≥0) (g h : ℝ → ℝ)
    (hg : PhysicalSolution β lam g) (hh : Measurable h)
    (B D : ℝ) (hb : ∀ t, |g t| ≤ B) (hd : ∀ t, |h t| ≤ D) (n : ℤ) :
    fourier β (covarianceSource β lam g h) (integerFrequency β n) =
      -(sourceRatio β lam g (-n) : ℂ) * fourier β h (integerFrequency β n) := by
  have hβ : 0 < β := Fact.out
  rw [covarianceSource,
    fourier_scalarConvolution β hβ _ _ _ (Thermal.covariance_measurable β)
      (scalarConvolution_measurable β hβ.le _ _ (source_measurable lam g hg.1) hh)
      (1/2) _ (Thermal.abs_covariance_le β)
      (scalarConvolution_bound β hβ.le _ _ _ D (source_bound lam g B hb) hd)
      (Thermal.covariance_antiperiodic β hβ.ne') (integer_wave_phase β n),
    fourier_scalarConvolution β hβ _ _ _ (source_measurable lam g hg.1) hh
      _ D (source_bound lam g B hb) hd (source_antiperiodic β lam g hg.2.2.1)
      (integer_wave_phase β n), ← mul_assoc, source_fourier_product β lam g hg n]

/-- The transported diagonal is exactly minus the literal integral operator on
all bounded measurable real test kernels. No convolution identity is assumed. -/
theorem physicalPerturbation_integral_action (lam : ℝ≥0) (g h : ℝ → ℝ)
    (hg : PhysicalSolution β lam g) (hh : Measurable h)
    (B D : ℝ) (hb : ∀ t, |g t| ≤ B) (hd : ∀ t, |h t| ≤ D) :
    physicalPerturbation β lam g (circleL2 β h hh D hd) =
      -circleL2 β (covarianceSource β lam g h)
        (covarianceSource_measurable β lam g h hg.1 hh)
        (β * ((1/2) * (β * ((lam : ℝ) * B^3 * D))))
        (covarianceSource_bound β lam g h B D hb hd) := by
  apply circle_fourier_injective β
  intro n
  rw [perturbation_coefficient β lam g hg, circleL2_coefficient]
  rw [← _root_.fourierBasis_repr, map_neg]
  simp only [lp.coeFn_neg, Pi.neg_apply, _root_.fourierBasis_repr]
  rw [circleL2_coefficient, covarianceSource_fourier β lam g h hg hh B D hb hd]
  simp only [neg_neg, Complex.real_smul]
  ring

/-- Unitary conjugation is itself a bounded linear map on operator spaces. -/
def transportMap : (H (ι := ℤ) →L[ℂ] H (ι := ℤ)) →L[ℂ]
    (TimeHilbert β →L[ℂ] TimeHilbert β) :=
  (ContinuousLinearMap.compL ℂ (TimeHilbert β) (H (ι := ℤ)) (TimeHilbert β)
    (transform β).symm.toContinuousLinearEquiv.toContinuousLinearMap).comp
      ((ContinuousLinearMap.compL ℂ (TimeHilbert β) (H (ι := ℤ)) (H (ι := ℤ))).flip
        (transform β).toContinuousLinearEquiv.toContinuousLinearMap)

@[simp] theorem transportMap_apply (T : H (ι := ℤ) →L[ℂ] H (ι := ℤ)) :
    transportMap β T = transport β T := rfl

def coefficientFunctional (n : ℤ) : TimeHilbert β →L[ℂ] ℂ :=
  (evaluation n).comp (transform β).toContinuousLinearEquiv.toContinuousLinearMap

def modeVector (a : ℤ → ℝ) (n : ℤ) : TimeHilbert β :=
  (transform β).symm (nuclearVector a n)

theorem norm_coefficientFunctional_le (n : ℤ) : ‖coefficientFunctional β n‖ ≤ 1 := by
  apply ContinuousLinearMap.opNorm_le_bound (coefficientFunctional β n) (by norm_num)
  intro f
  change ‖transform β f n‖ ≤ 1 * ‖f‖
  simpa only [one_mul, LinearIsometryEquiv.norm_map] using
    lp.norm_apply_le_norm (by norm_num : (2 : ENNReal) ≠ 0) (transform β f) n

theorem norm_modeVector (a : ℤ → ℝ) (n : ℤ) : ‖modeVector β a n‖ = |a n| := by
  simp [modeVector, nuclearVector, norm_smul,
    lp.norm_single (by norm_num : (0 : ENNReal) < 2), Complex.norm_real, Real.norm_eq_abs]

theorem transport_rankOne (a : ℤ → ℝ) (n : ℤ) :
    transport β ((a n : ℂ) • projection n) =
      (coefficientFunctional β n).smulRight (modeVector β a n) := by
  rw [← nuclear_rankOne_eq]
  apply ContinuousLinearMap.ext
  intro f
  simp only [transport, ContinuousLinearMap.comp_apply, ContinuousLinearMap.smulRight_apply,
    LinearIsometryEquiv.coe_toContinuousLinearEquiv, ContinuousLinearEquiv.coe_coe, map_smul]
  rfl

/-- Actual absolutely summable rank-one series on the time-domain Hilbert space. -/
theorem physical_nuclear_expansion (lam : ℝ≥0) (g : ℝ → ℝ)
    (hg : PhysicalSolution β lam g) :
    Summable (fun n : ℤ => ‖coefficientFunctional β n‖ * ‖modeVector β (sourceRatio β lam g) n‖) ∧
    HasSum (fun n : ℤ => (coefficientFunctional β n).smulRight
      (modeVector β (sourceRatio β lam g) n)) (physicalPerturbation β lam g) := by
  have ha : Summable (fun n => |sourceRatio β lam g n|) := by
    simpa only [Real.norm_eq_abs] using (sourceRatio_summable β lam g hg).norm
  constructor
  · apply Summable.of_nonneg_of_le (fun _ => mul_nonneg (norm_nonneg _) (norm_nonneg _)) _ ha
    intro n
    rw [norm_modeVector]
    exact mul_le_of_le_one_left (abs_nonneg _) (norm_coefficientFunctional_le β n)
  · have hs := (summable_rankOne (sourceRatio β lam g) ha).hasSum.mapL (transportMap β)
    simpa only [transportMap_apply, transport_rankOne, physicalPerturbation] using hs

/-- Actual finite matrices of I−CΣ in the Fourier orthonormal modes. -/
def physicalCompression (lam : ℝ≥0) (g : ℝ → ℝ) (s : Finset ℤ) : Matrix s s ℂ :=
  fun i j => _root_.fourierCoeff ((@_root_.fourierBasis β _) (j : ℤ) +
    physicalPerturbation β lam g ((@_root_.fourierBasis β _) (j : ℤ))) (i : ℤ)

theorem physicalCompression_eq (lam : ℝ≥0) (g : ℝ → ℝ)
    (s : Finset ℤ) :
    physicalCompression β lam g s = compressionMatrix (sourceRatio β lam g) s := by
  ext i j
  unfold physicalCompression compressionMatrix operatorCompressionMatrix
  rw [← _root_.fourierBasis_repr, map_add]
  change (transform β ((@_root_.fourierBasis β _) (j : ℤ)) +
    transform β (physicalPerturbation β lam g ((@_root_.fourierBasis β _) (j : ℤ)))) (i : ℤ) = _
  rw [physicalPerturbation, transform_transport]
  simp only [transform, HilbertBasis.repr_self]

theorem physical_compression_determinants (lam : ℝ≥0) (g : ℝ → ℝ)
    (hg : PhysicalSolution β lam g) :
    Tendsto (fun s : Finset ℤ => Matrix.det (physicalCompression β lam g s)) atTop
      (𝓝 (relativeProduct (sourceRatio β lam g) : ℂ)) := by
  simp_rw [physicalCompression_eq β lam g]
  apply compression_determinants_tendsto
  simpa only [Real.norm_eq_abs] using (sourceRatio_summable β lam g hg).norm

/-- The determinant limit is defined from the actual physical operator
compressions. Its scalar product value is a theorem, not its definition. -/
def physicalDeterminant (lam : ℝ≥0) (g : ℝ → ℝ) : ℂ :=
  limUnder atTop (fun s : Finset ℤ => Matrix.det (physicalCompression β lam g s))

theorem physicalDeterminant_eq (lam : ℝ≥0) (g : ℝ → ℝ)
    (hg : PhysicalSolution β lam g) :
    physicalDeterminant β lam g = (relativeProduct (sourceRatio β lam g) : ℂ) :=
  (physical_compression_determinants β lam g hg).limUnder_eq

theorem physicalDeterminant_pos (lam : ℝ≥0) (g : ℝ → ℝ)
    (hg : PhysicalSolution β lam g) :
    (physicalDeterminant β lam g).im = 0 ∧ 0 < (physicalDeterminant β lam g).re := by
  rw [physicalDeterminant_eq β lam g hg]
  simp only [Complex.ofReal_im, Complex.ofReal_re, true_and]
  exact relativeProduct_pos _ (sourceRatio_summable β lam g hg)
    (sourceRatio_factor_pos β lam g hg)

theorem physicalDeterminant_log (lam : ℝ≥0) (g : ℝ → ℝ)
    (hg : PhysicalSolution β lam g) :
    (1/2 : ℝ) * Real.log (physicalDeterminant β lam g).re = onShellLog β lam g := by
  rw [physicalDeterminant_eq β lam g hg, Complex.ofReal_re,
    log_relativeProduct _ (sourceRatio_summable β lam g hg)
      (sourceRatio_factor_pos β lam g hg)]
  rfl

/-- Every cofinal Fourier-mode cutoff gives the same actual determinant limit. -/
theorem physical_determinants_cofinal {α : Type*} {l : Filter α}
    (lam : ℝ≥0) (g : ℝ → ℝ) (hg : PhysicalSolution β lam g)
    (s : α → Finset ℤ) (hs : Tendsto s l atTop) :
    Tendsto (fun i => Matrix.det (physicalCompression β lam g (s i))) l
      (𝓝 (physicalDeterminant β lam g)) := by
  rw [physicalDeterminant_eq β lam g hg]
  exact (physical_compression_determinants β lam g hg).comp hs

end SYK.FourierOperators
