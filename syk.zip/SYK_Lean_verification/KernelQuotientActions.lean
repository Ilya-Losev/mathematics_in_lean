import KernelAlgebraActions
import KernelCoordinateGeneration
import KernelReflection

/-!
# Reflection and time translation on the two actual kernel quotients

Preservation of the defining ideals is derived from the exact canonical
relations. No ideal-invariance field is added to the model.
-/

noncomputable section
namespace SYK.KernelQuotientActions
open SYK.WeightedKernelAlgebra SYK.KernelResidualAlgebra
open SYK.KernelCoordinateGeneration SYK.KernelAlgebraActions

section FirstTranslation
variable (b K : ℝ) (hb : 0 < b) (hK : 0 < K) (β : ℝ) (C₀ : Endpoint → ℂ)

/-- Translate a polynomial, then pass to the first actual quotient. -/
def translatedPolynomial (u : ℝ) : MvPolynomial KernelIndex ℂ →ₐ[ℂ]
    RegularityAlgebra b K hb hK C₀ (symmetryRelations β) :=
  (RelationQuotient.mk _ _).comp
    ((translation b K hb hK u).toAlgHom.comp (WeightedAlgebra.ofPolynomialAlgHom _))

@[simp] theorem translatedPolynomial_coordinate (u : ℝ) (p : Endpoint) :
    translatedPolynomial b K hb hK β C₀ u (MvPolynomial.X (.inl p)) =
      coordinate b K hb hK C₀ (symmetryRelations β) (translateEndpoint u p) := by
  change RelationQuotient.mk _ _ (translation b K hb hK u (WeightedAlgebra.generator _ (.inl p))) = _
  rw [translation_generator]
  rfl

@[simp] theorem translatedPolynomial_increment (u : ℝ) (pq : IncrementIndex) :
    translatedPolynomial b K hb hK β C₀ u (MvPolynomial.X (.inr pq)) =
      increment b K hb hK C₀ (symmetryRelations β) (incrementEquiv (translateEndpoint u) pq) := by
  change RelationQuotient.mk _ _ (translation b K hb hK u (WeightedAlgebra.generator _ (.inr pq))) = _
  rw [translation_generator]
  rfl

/-- Each translated generator relation vanishes in the already constructed
first quotient, by its exact increment and coordinate identities. -/
theorem translated_relation_zero (u : ℝ) (hC : ∀ p, C₀ (translateEndpoint u p) = C₀ p)
    (j : IncrementIndex ⊕ SymmetryIndex) :
    translatedPolynomial b K hb hK β C₀ u (kernelRelations C₀ (symmetryRelations β) j) = 0 := by
  cases j with
  | inl pq =>
      simp only [kernelRelations, map_sub, map_add, translatedPolynomial_increment,
        translatedPolynomial_coordinate, ← MvPolynomial.algebraMap_eq, AlgHom.commutes]
      rw [increment_eq_remainder_sub]
      dsimp only [incrementEquiv, remainder, Equiv.coe_fn_mk]
      rw [hC, hC]
      ring
  | inr j =>
      cases j with
      | skew p =>
          simp only [kernelRelations, symmetryRelations, map_add, translatedPolynomial_coordinate]
          change coordinate _ _ _ _ _ _ (p.2+u,p.1+u) + coordinate _ _ _ _ _ _ (p.1+u,p.2+u) = 0
          rw [coordinate_skew]
          exact neg_add_cancel _
      | antiperiodicLeft p =>
          simp only [kernelRelations, symmetryRelations, map_add, translatedPolynomial_coordinate]
          change coordinate _ _ _ _ _ _ (p.1+β+u,p.2+u) + coordinate _ _ _ _ _ _ (p.1+u,p.2+u) = 0
          rw [show p.1+β+u = (p.1+u)+β by ring, coordinate_antiperiodic_left]
          exact neg_add_cancel _
      | antiperiodicRight p =>
          simp only [kernelRelations, symmetryRelations, map_add, translatedPolynomial_coordinate]
          change coordinate _ _ _ _ _ _ (p.1+u,p.2+β+u) + coordinate _ _ _ _ _ _ (p.1+u,p.2+u) = 0
          rw [show p.2+β+u = (p.2+u)+β by ring, coordinate_antiperiodic_right]
          exact neg_add_cancel _
      | diagonal t =>
          simpa only [kernelRelations, symmetryRelations, translatedPolynomial_coordinate] using
            coordinate_diagonal b K hb hK C₀ β (t+u)

/-- Continuity upgrades preservation of all defining polynomials to preservation
of their entire closed ideal. -/
theorem translation_preserves_firstIdeal (u : ℝ)
    (hC : ∀ p, C₀ (translateEndpoint u p) = C₀ p) :
    ∀ a ∈ closedRelationIdeal (kernelWeights b K hb hK) (kernelRelations C₀ (symmetryRelations β)),
      translation b K hb hK u a ∈
        closedRelationIdeal (kernelWeights b K hb hK) (kernelRelations C₀ (symmetryRelations β)) := by
  apply maps_closedGeneratedIdeal (translation b K hb hK u).toRingHom
    (translation_isometry b K hb hK u).continuous
  intro j
  apply Ideal.Quotient.eq_zero_iff_mem.mp
  exact translated_relation_zero b K hb hK β C₀ u hC j

/-- Equality of the ideal under every translated action follows using negative
time, rather than assuming the quotient action exists. -/
theorem translation_firstIdeal_iff (hC : ∀ u p, C₀ (translateEndpoint u p) = C₀ p)
    (u : ℝ) (a : WeightedAlgebra (kernelWeights b K hb hK)) :
    a ∈ closedRelationIdeal (kernelWeights b K hb hK) (kernelRelations C₀ (symmetryRelations β)) ↔
      translation b K hb hK u a ∈
        closedRelationIdeal (kernelWeights b K hb hK) (kernelRelations C₀ (symmetryRelations β)) := by
  constructor
  · exact translation_preserves_firstIdeal b K hb hK β C₀ u (hC u) a
  · intro ha
    have hh := translation_preserves_firstIdeal b K hb hK β C₀ (-u) (hC (-u)) _ ha
    simpa only [translation_add, neg_add_cancel, translation_zero] using hh

/-- The first quotient time translation is now constructed as an algebra equivalence. -/
def firstTranslation (hC : ∀ u p, C₀ (translateEndpoint u p) = C₀ p) (u : ℝ) :
    RegularityAlgebra b K hb hK C₀ (symmetryRelations β) ≃ₐ[ℂ]
      RegularityAlgebra b K hb hK C₀ (symmetryRelations β) :=
  { quotientRingEquiv _ (translation b K hb hK u).toRingEquiv
      (translation_firstIdeal_iff b K hb hK β C₀ hC u) with
    commutes' c := by
      change quotientRingEquiv _ _ _ (Ideal.Quotient.mk _ (algebraMap ℂ _ c)) = _
      rw [quotientRingEquiv_mk]
      exact congrArg (Ideal.Quotient.mk _) ((translation b K hb hK u).commutes c) }

theorem firstTranslation_isometry (hC : ∀ u p, C₀ (translateEndpoint u p) = C₀ p) (u : ℝ) :
    Isometry (firstTranslation b K hb hK β C₀ hC u) :=
  quotientRingEquiv_isometry _ _ (translation_isometry b K hb hK u)
    (translation_firstIdeal_iff b K hb hK β C₀ hC u)

@[simp] theorem firstTranslation_mk (hC : ∀ u p, C₀ (translateEndpoint u p) = C₀ p) (u : ℝ)
    (a : WeightedAlgebra (kernelWeights b K hb hK)) :
    firstTranslation b K hb hK β C₀ hC u (RelationQuotient.mk _ _ a) =
      RelationQuotient.mk _ _ (translation b K hb hK u a) :=
  quotientRingEquiv_mk _ _ (translation_firstIdeal_iff b K hb hK β C₀ hC u) a

@[simp] theorem firstTranslation_coordinate (hC : ∀ u p, C₀ (translateEndpoint u p) = C₀ p)
    (u : ℝ) (p : Endpoint) :
    firstTranslation b K hb hK β C₀ hC u (coordinate b K hb hK C₀ (symmetryRelations β) p) =
      coordinate b K hb hK C₀ (symmetryRelations β) (translateEndpoint u p) := by
  change firstTranslation _ _ _ _ _ _ _ _ (RelationQuotient.mk _ _ (WeightedAlgebra.generator _ (.inl p))) = _
  rw [firstTranslation_mk, translation_generator]
  rfl

end FirstTranslation
section FirstReflection
variable (b K : ℝ) (hb : 0 < b) (hK : 0 < K) (β : ℝ) (C₀ : Endpoint → ℂ)

/-- Reflect the endpoint labels and conjugate the coefficients before quotienting. -/
def reflectedPolynomial : MvPolynomial KernelIndex ℂ →+*
    RegularityAlgebra b K hb hK C₀ (symmetryRelations β) :=
  (RelationQuotient.mk _ _).toRingHom.comp
    ((reflection b K hb hK β).toRingHom.comp (WeightedAlgebra.ofPolynomialAlgHom _).toRingHom)

@[simp] theorem reflectedPolynomial_C (c : ℂ) :
    reflectedPolynomial b K hb hK β C₀ (MvPolynomial.C c) = algebraMap ℂ _ (star c) := by
  change RelationQuotient.mk _ _ (reflection b K hb hK β (algebraMap ℂ _ c)) = _
  rw [reflection_constant, AlgHom.commutes]

@[simp] theorem reflectedPolynomial_coordinate (p : Endpoint) :
    reflectedPolynomial b K hb hK β C₀ (MvPolynomial.X (.inl p)) =
      coordinate b K hb hK C₀ (symmetryRelations β) (reflectEndpoint β p) := by
  change RelationQuotient.mk _ _ (reflection b K hb hK β (WeightedAlgebra.generator _ (.inl p))) = _
  rw [reflection_generator]
  rfl

@[simp] theorem reflectedPolynomial_increment (pq : IncrementIndex) :
    reflectedPolynomial b K hb hK β C₀ (MvPolynomial.X (.inr pq)) =
      increment b K hb hK C₀ (symmetryRelations β) (incrementEquiv (reflectEndpoint β) pq) := by
  change RelationQuotient.mk _ _ (reflection b K hb hK β (WeightedAlgebra.generator _ (.inr pq))) = _
  rw [reflection_generator]
  rfl

/-- Reflection preserves the first relations. Negative endpoint shifts in the
antiperiodic identities are justified using the corresponding positive shift. -/
theorem reflected_relation_zero (hC : ∀ p, C₀ (reflectEndpoint β p) = star (C₀ p))
    (j : IncrementIndex ⊕ SymmetryIndex) :
    reflectedPolynomial b K hb hK β C₀ (kernelRelations C₀ (symmetryRelations β) j) = 0 := by
  cases j with
  | inl pq =>
      simp only [kernelRelations, map_sub, map_add, reflectedPolynomial_increment,
        reflectedPolynomial_coordinate, reflectedPolynomial_C]
      rw [increment_eq_remainder_sub]
      dsimp only [incrementEquiv, remainder, Equiv.coe_fn_mk]
      rw [hC, hC]
      ring
  | inr j =>
      cases j with
      | skew p =>
          simp only [kernelRelations, symmetryRelations, map_add, reflectedPolynomial_coordinate]
          change coordinate _ _ _ _ _ _ (β-p.1,β-p.2) + coordinate _ _ _ _ _ _ (β-p.2,β-p.1) = 0
          rw [coordinate_skew]
          exact neg_add_cancel _
      | antiperiodicLeft p =>
          simp only [kernelRelations, symmetryRelations, map_add, reflectedPolynomial_coordinate]
          change coordinate _ _ _ _ _ _ (β-p.2,β-(p.1+β)) + coordinate _ _ _ _ _ _ (β-p.2,β-p.1) = 0
          rw [show β-(p.1+β) = -p.1 by ring, show β-p.1 = -p.1+β by ring,
            coordinate_antiperiodic_right]
          exact add_neg_cancel _
      | antiperiodicRight p =>
          simp only [kernelRelations, symmetryRelations, map_add, reflectedPolynomial_coordinate]
          change coordinate _ _ _ _ _ _ (β-(p.2+β),β-p.1) + coordinate _ _ _ _ _ _ (β-p.2,β-p.1) = 0
          rw [show β-(p.2+β) = -p.2 by ring, show β-p.2 = -p.2+β by ring,
            coordinate_antiperiodic_left]
          exact add_neg_cancel _
      | diagonal t =>
          simpa only [kernelRelations, symmetryRelations, reflectedPolynomial_coordinate] using
            coordinate_diagonal b K hb hK C₀ β (β-t)

theorem reflection_preserves_firstIdeal (hC : ∀ p, C₀ (reflectEndpoint β p) = star (C₀ p)) :
    ∀ a ∈ closedRelationIdeal (kernelWeights b K hb hK) (kernelRelations C₀ (symmetryRelations β)),
      reflection b K hb hK β a ∈
        closedRelationIdeal (kernelWeights b K hb hK) (kernelRelations C₀ (symmetryRelations β)) := by
  apply maps_closedGeneratedIdeal (reflection b K hb hK β).toRingHom
    (reflection_isometry b K hb hK β).continuous
  intro j
  apply Ideal.Quotient.eq_zero_iff_mem.mp
  exact reflected_relation_zero b K hb hK β C₀ hC j

theorem reflection_firstIdeal_iff (hC : ∀ p, C₀ (reflectEndpoint β p) = star (C₀ p))
    (a : WeightedAlgebra (kernelWeights b K hb hK)) :
    a ∈ closedRelationIdeal (kernelWeights b K hb hK) (kernelRelations C₀ (symmetryRelations β)) ↔
      reflection b K hb hK β a ∈
        closedRelationIdeal (kernelWeights b K hb hK) (kernelRelations C₀ (symmetryRelations β)) := by
  constructor
  · exact reflection_preserves_firstIdeal b K hb hK β C₀ hC a
  · intro ha
    have hh := reflection_preserves_firstIdeal b K hb hK β C₀ hC _ ha
    simpa only [reflection_involutive] using hh

def firstReflection (hC : ∀ p, C₀ (reflectEndpoint β p) = star (C₀ p)) :
    RegularityAlgebra b K hb hK C₀ (symmetryRelations β) ≃+*
      RegularityAlgebra b K hb hK C₀ (symmetryRelations β) :=
  quotientRingEquiv _ (reflection b K hb hK β)
    (reflection_firstIdeal_iff b K hb hK β C₀ hC)

theorem firstReflection_isometry (hC : ∀ p, C₀ (reflectEndpoint β p) = star (C₀ p)) :
    Isometry (firstReflection b K hb hK β C₀ hC) :=
  quotientRingEquiv_isometry _ _ (reflection_isometry b K hb hK β) _

@[simp] theorem firstReflection_mk (hC : ∀ p, C₀ (reflectEndpoint β p) = star (C₀ p))
    (a : WeightedAlgebra (kernelWeights b K hb hK)) :
    firstReflection b K hb hK β C₀ hC (RelationQuotient.mk _ _ a) =
      RelationQuotient.mk _ _ (reflection b K hb hK β a) :=
  quotientRingEquiv_mk _ _ _ a

@[simp] theorem firstReflection_coordinate (hC : ∀ p, C₀ (reflectEndpoint β p) = star (C₀ p))
    (p : Endpoint) :
    firstReflection b K hb hK β C₀ hC (coordinate b K hb hK C₀ (symmetryRelations β) p) =
      coordinate b K hb hK C₀ (symmetryRelations β) (reflectEndpoint β p) := by
  change firstReflection _ _ _ _ _ _ _ (RelationQuotient.mk _ _ (WeightedAlgebra.generator _ (.inl p))) = _
  rw [firstReflection_mk, reflection_generator]
  rfl

@[simp] theorem firstReflection_constant (hC : ∀ p, C₀ (reflectEndpoint β p) = star (C₀ p)) (c : ℂ) :
    firstReflection b K hb hK β C₀ hC (algebraMap ℂ _ c) = algebraMap ℂ _ (star c) := by
  change firstReflection _ _ _ _ _ _ _ (RelationQuotient.mk _ _ (algebraMap ℂ _ c)) = _
  rw [firstReflection_mk, reflection_constant, AlgHom.commutes]

@[simp] theorem firstReflection_involutive (hC : ∀ p, C₀ (reflectEndpoint β p) = star (C₀ p))
    (a : RegularityAlgebra b K hb hK C₀ (symmetryRelations β)) :
    firstReflection b K hb hK β C₀ hC (firstReflection b K hb hK β C₀ hC a) = a := by
  obtain ⟨a, rfl⟩ := Ideal.Quotient.mk_surjective a
  change firstReflection _ _ _ _ _ _ _ (firstReflection _ _ _ _ _ _ _ (RelationQuotient.mk _ _ a)) = _
  rw [firstReflection_mk, firstReflection_mk, reflection_involutive]
  rfl

end FirstReflection

/-- The actual thermal covariance is translation invariant at every real pair. -/
theorem thermal_translation (β u : ℝ) (p : Endpoint) :
    thermalCovariance β (translateEndpoint u p) = thermalCovariance β p := by
  exact congrArg Complex.ofReal (Thermal.kernel_translation β p.1 p.2 u)

/-- It is real and invariant under reversed-endpoint reflection, including jumps. -/
theorem thermal_reflection (β : ℝ) (p : Endpoint) :
    thermalCovariance β (reflectEndpoint β p) = star (thermalCovariance β p) := by
  change (Thermal.covariance β ((β-p.2)-(β-p.1)) : ℂ) = star ((Thermal.covariance β (p.1-p.2)) : ℂ)
  rw [show (β-p.2)-(β-p.1) = p.1-p.2 by ring]
  exact (Complex.conj_ofReal _).symm

section FirstActionLaws
variable (b K : ℝ) (hb : 0 < b) (hK : 0 < K) (β : ℝ) (C₀ : Endpoint → ℂ)
  (hT : ∀ u p, C₀ (translateEndpoint u p) = C₀ p)
  (hR : ∀ p, C₀ (reflectEndpoint β p) = star (C₀ p))

@[simp] theorem firstTranslation_zero (a : RegularityAlgebra b K hb hK C₀ (symmetryRelations β)) :
    firstTranslation b K hb hK β C₀ hT 0 a = a := by
  obtain ⟨a, rfl⟩ := Ideal.Quotient.mk_surjective a
  change firstTranslation _ _ _ _ _ _ _ _ (RelationQuotient.mk _ _ a) = _
  rw [firstTranslation_mk, translation_zero]
  rfl

theorem firstTranslation_add (u v : ℝ) (a : RegularityAlgebra b K hb hK C₀ (symmetryRelations β)) :
    firstTranslation b K hb hK β C₀ hT u (firstTranslation b K hb hK β C₀ hT v a) =
      firstTranslation b K hb hK β C₀ hT (u+v) a := by
  obtain ⟨a, rfl⟩ := Ideal.Quotient.mk_surjective a
  change firstTranslation _ _ _ _ _ _ _ _ (firstTranslation _ _ _ _ _ _ _ _ (RelationQuotient.mk _ _ a)) =
    firstTranslation _ _ _ _ _ _ _ _ (RelationQuotient.mk _ _ a)
  rw [firstTranslation_mk, firstTranslation_mk, firstTranslation_mk, translation_add]

/-- The crucial reflection/time-reversal covariance survives the first quotient. -/
theorem firstReflection_translation (u : ℝ)
    (a : RegularityAlgebra b K hb hK C₀ (symmetryRelations β)) :
    firstReflection b K hb hK β C₀ hR (firstTranslation b K hb hK β C₀ hT u a) =
      firstTranslation b K hb hK β C₀ hT (-u) (firstReflection b K hb hK β C₀ hR a) := by
  obtain ⟨a, rfl⟩ := Ideal.Quotient.mk_surjective a
  change firstReflection _ _ _ _ _ _ _ (firstTranslation _ _ _ _ _ _ _ _ (RelationQuotient.mk _ _ a)) =
    firstTranslation _ _ _ _ _ _ _ _ (firstReflection _ _ _ _ _ _ _ (RelationQuotient.mk _ _ a))
  rw [firstTranslation_mk, firstReflection_mk, firstReflection_mk, firstTranslation_mk,
    reflection_translation]

/-- Reflection remains genuinely conjugate-linear on the quotient algebra. -/
theorem firstReflection_smul (c : ℂ) (a : RegularityAlgebra b K hb hK C₀ (symmetryRelations β)) :
    firstReflection b K hb hK β C₀ hR (c • a) = star c • firstReflection b K hb hK β C₀ hR a := by
  simp only [Algebra.smul_def, map_mul, firstReflection_constant]

end FirstActionLaws

end SYK.KernelQuotientActions
