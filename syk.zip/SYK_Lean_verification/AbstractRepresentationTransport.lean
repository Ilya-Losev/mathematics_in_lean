import RepresentationIndependence
import Mathlib.LinearAlgebra.Trace

/-!
# Actual finite-dimensional operator model and matrix coordinates

A chosen finite complex basis gives an algebra equivalence from continuous
endomorphisms to matrices. Ordinary trace and the genuine exponential are
proved to agree, so arbitrary finite-dimensional complex Hilbert realizations
are covered without any unstated coordinate reduction. Orthonormality is not
needed for CAR, trace, or exponential transport.
-/
noncomputable section
open MeasureTheory Filter
open scoped BigOperators NNReal Topology ComplexOrder
namespace SYK.AbstractRepresentation
open RepresentationIndependence FreeWick

variable {E : Type*} [NormedAddCommGroup E] [NormedSpace ℂ E] [FiniteDimensional ℂ E]
variable {κ : Type*} [Fintype κ] [DecidableEq κ]

/-- Genuine algebra equivalence induced by a supplied finite basis. -/
def coordinates (b : Basis κ ℂ E) : (E →L[ℂ] E) ≃ₐ[ℂ] Matrix κ κ ℂ :=
  (Module.End.toContinuousLinearMap E).symm.trans (LinearMap.toMatrixAlgEquiv b)

theorem coordinates_continuous (b : Basis κ ℂ E) : Continuous (coordinates b) :=
  (coordinates b).toLinearEquiv.toLinearMap.continuous_of_finiteDimensional

theorem coordinates_trace (b : Basis κ ℂ E) (T : E →L[ℂ] E) :
    Matrix.trace (coordinates b T) = LinearMap.trace ℂ E T.toLinearMap := by
  exact (LinearMap.trace_eq_matrix_trace ℂ b T.toLinearMap).symm

theorem coordinates_exp (b : Basis κ ℂ E) (T : E →L[ℂ] E) :
    coordinates b (NormedSpace.exp ℂ T) = NormedSpace.exp ℂ (coordinates b T) := by
  letI : CompleteSpace E := FiniteDimensional.complete ℂ E
  let e : (E →L[ℂ] E) →+* CStarMatrix κ κ ℂ :=
    CStarMatrix.ofMatrixRingEquiv.toRingHom.comp (coordinates b).toRingHom
  have he : Continuous e :=
    CStarMatrix.ofMatrixL.continuous.comp (coordinates_continuous b)
  exact NormedSpace.map_exp ℂ e he T

/-- The quartic operator Hamiltonian before choosing any coordinates. -/
def hamiltonian (d : ℕ) (x : Fin (2*d) → E →L[ℂ] E)
    (j : Majorana.FourSet d → ℝ) : E →L[ℂ] E :=
  -∑ I, j I • word x (quarticWord d I)

def partitionFunction (d : ℕ) (x : Fin (2*d) → E →L[ℂ] E)
    (β : ℝ) (j : Majorana.FourSet d → ℝ) : ℂ :=
  LinearMap.trace ℂ E (NormedSpace.exp ℂ ((-β) • hamiltonian d x j)).toLinearMap

theorem coordinates_word (b : Basis κ ℂ E) (d : ℕ)
    (x : Fin (2*d) → E →L[ℂ] E) (L : List (Fin (2*d))) :
    coordinates b (word x L) = word (fun i => coordinates b (x i)) L := by
  induction L with
  | nil => simp
  | cons i L ih => simp [word_cons,ih]

theorem coordinates_hamiltonian (b : Basis κ ℂ E) (d : ℕ)
    (x : Fin (2*d) → E →L[ℂ] E) (j : Majorana.FourSet d → ℝ) :
    coordinates b (hamiltonian d x j) =
      RepresentationIndependence.hamiltonian d (fun i => coordinates b (x i)) j := by
  simp only [hamiltonian,RepresentationIndependence.hamiltonian,map_neg,map_sum]
  congr 1
  apply Finset.sum_congr rfl
  intro I _
  rw [← Complex.coe_smul (j I),map_smul,coordinates_word,Complex.coe_smul]

theorem coordinates_car (b : Basis κ ℂ E) (d : ℕ)
    (x : Fin (2*d) → E →L[ℂ] E)
    (hx : ∀ i j, x i*x j+x j*x i = flavorDelta i j • (1:E →L[ℂ] E)) :
    ∀ i j, coordinates b (x i)*coordinates b (x j)+
      coordinates b (x j)*coordinates b (x i) = flavorDelta i j • (1:Matrix κ κ ℂ) := by
  intro i j
  simpa only [map_add,map_mul,map_smul,map_one] using congrArg (coordinates b) (hx i j)

theorem partitionFunction_eq (b : Basis κ ℂ E) (d : ℕ)
    (x : Fin (2*d) → E →L[ℂ] E)
    (hx : ∀ i j, x i*x j+x j*x i = flavorDelta i j • (1:E →L[ℂ] E))
    (hcard : Fintype.card κ = 2^d) (β : ℝ) (j : Majorana.FourSet d → ℝ) :
    partitionFunction d x β j = Majorana.partitionFunction d β j := by
  unfold partitionFunction
  rw [← coordinates_trace b, coordinates_exp]
  have hc : coordinates b ((-β) • hamiltonian d x j) =
      (-β) • RepresentationIndependence.hamiltonian d (fun i => coordinates b (x i)) j := by
    rw [← Complex.coe_smul (-β),map_smul,coordinates_hamiltonian,Complex.coe_smul]
  rw [hc]
  exact RepresentationIndependence.partitionFunction_eq d _ (coordinates_car b d x hx) hcard β j

/-- No basis is supplied to the model statement: finite dimension constructs
one, and the resulting ordinary partition function is the canonical value. -/
theorem partitionFunction_eq_of_finrank (d : ℕ) (x : Fin (2*d) → E →L[ℂ] E)
    (hx : ∀ i j, x i*x j+x j*x i = flavorDelta i j • (1:E →L[ℂ] E))
    (hdim : Module.finrank ℂ E = 2^d) (β : ℝ) (j : Majorana.FourSet d → ℝ) :
    partitionFunction d x β j = Majorana.partitionFunction d β j := by
  exact partitionFunction_eq (Module.finBasis ℂ E) d x hx
    (by simpa using hdim) β j

/-- The actual abstract-space annealed pressure, without chosen coordinates. -/
def annealedPressure (d : ℕ) (x : Fin (2*d) → E →L[ℂ] E) (β : ℝ) (lam : ℝ≥0) : ℝ :=
  GaussianDisorder.annealedPressure (Majorana.FourSet d) (2*d) lam
    (fun j => (partitionFunction d x β j).re)

/-- The actual abstract-space quenched pressure, without chosen coordinates. -/
def quenchedPressure (d : ℕ) (x : Fin (2*d) → E →L[ℂ] E) (β : ℝ) (lam : ℝ≥0) : ℝ :=
  GaussianDisorder.quenchedPressure (Majorana.FourSet d) (2*d) lam
    (fun j => (partitionFunction d x β j).re)

theorem annealedPressure_eq (d : ℕ) (x : Fin (2*d) → E →L[ℂ] E)
    (hx : ∀ i j, x i*x j+x j*x i = flavorDelta i j • (1:E →L[ℂ] E))
    (hdim : Module.finrank ℂ E = 2^d) (β : ℝ) (lam : ℝ≥0) :
    annealedPressure d x β lam = Microscopic.annealedPressure d β lam := by
  unfold annealedPressure Microscopic.annealedPressure
  simp only [partitionFunction_eq_of_finrank d x hx hdim]

theorem quenchedPressure_eq (d : ℕ) (x : Fin (2*d) → E →L[ℂ] E)
    (hx : ∀ i j, x i*x j+x j*x i = flavorDelta i j • (1:E →L[ℂ] E))
    (hdim : Module.finrank ℂ E = 2^d) (β : ℝ) (lam : ℝ≥0) :
    quenchedPressure d x β lam = Microscopic.quenchedPressure d β lam := by
  unfold quenchedPressure Microscopic.quenchedPressure
  simp only [partitionFunction_eq_of_finrank d x hx hdim]

end SYK.AbstractRepresentation
