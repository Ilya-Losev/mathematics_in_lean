import WickThermal
import Mathlib.Tactic
import Mathlib.Topology.Algebra.InfiniteSum.NatInt

/-!
# Polynomial and exponential Ward identities from the actual Wick functional

The identities in this module are derived from the constructed exterior Wick
functional. No Ward identity is an input. The coefficientwise and finite
exponential statements do not assert convergence of the continuum Duhamel series.
-/

noncomputable section
namespace SYK.Ward

variable {R M : Type*} [CommRing R] [AddCommGroup M] [Module R M]

/-- Graded commutation of a generator with every exterior element. -/
theorem generator_mul (a : M) (F : ExteriorAlgebra R M) :
    ExteriorAlgebra.ι R a * F = CliffordAlgebra.involute F * ExteriorAlgebra.ι R a := by
  induction F using CliffordAlgebra.left_induction with
  | algebraMap r =>
    simpa only [AlgHom.commutes] using (Algebra.commutes r (ExteriorAlgebra.ι R a)).symm
  | add F G hF hG => simp only [mul_add, map_add, add_mul, hF, hG]
  | ι_mul F b hF =>
    rw [← mul_assoc, eq_neg_of_add_eq_zero_left (ExteriorAlgebra.ι_add_mul_swap a b),
      neg_mul, mul_assoc, hF]
    simp [mul_assoc]

/-- Every even exterior element commutes with every exterior element. -/
theorem even_commutes (S F : ExteriorAlgebra R M)
    (hS : CliffordAlgebra.involute S = S) : S * F = F * S := by
  have hg (a : M) : ExteriorAlgebra.ι R a * S = S * ExteriorAlgebra.ι R a := by
    rw [generator_mul, hS]
  induction F using CliffordAlgebra.left_induction with
  | algebraMap r => exact (Algebra.commutes r S).symm
  | add F G hF hG => simp only [mul_add, add_mul, hF, hG]
  | ι_mul F a hF => rw [← mul_assoc, ← hg a, mul_assoc, hF, ← mul_assoc]

variable (C : SYK.Wick.Covariance R M)

/-- Differentiating a power of an even interaction produces its exact integer factor. -/
theorem contraction_pow_succ (a : M) (S : ExteriorAlgebra R M)
    (hS : CliffordAlgebra.involute S = S) (n : ℕ) :
    C.contraction a (S ^ (n + 1)) = ((n + 1 : ℕ) : R) • (S ^ n * C.contraction a S) := by
  induction n with
  | zero => simp
  | succ n ih =>
    rw [pow_succ S (n + 1), C.contraction_mul, ih]
    simp only [map_pow, hS]
    rw [smul_mul_assoc, mul_assoc,
      ← even_commutes S (C.contraction a S) hS, ← mul_assoc, ← pow_succ]
    simp [Nat.cast_add, Nat.cast_one, add_smul]

/-- The derivative of a product of even vertices, retaining every insertion term. -/
def insertionDerivative (D : ExteriorAlgebra R M →ₗ[R] ExteriorAlgebra R M) :
    List (ExteriorAlgebra R M) → ExteriorAlgebra R M
  | [] => 0
  | P :: Ps => D P * Ps.prod + P * insertionDerivative D Ps

theorem contraction_list_prod (a : M) (Ps : List (ExteriorAlgebra R M))
    (hPs : ∀ P ∈ Ps, CliffordAlgebra.involute P = P) :
    C.contraction a Ps.prod = insertionDerivative (C.contraction a) Ps := by
  induction Ps with
  | nil => simp [insertionDerivative]
  | cons P Ps ih =>
    rw [List.prod_cons, C.contraction_even_mul a P Ps.prod (hPs P (by simp))]
    rw [ih (fun Q hQ => hPs Q (by simp [hQ]))]
    rfl

/-- One insertion slot, with its preceding and following exterior factors preserved. -/
def insertionSlot (D : ExteriorAlgebra R M →ₗ[R] ExteriorAlgebra R M)
    (Ps : List (ExteriorAlgebra R M)) (r : ℕ) : ExteriorAlgebra R M :=
  (Ps.take r).prod * D (Ps.getD r 0) * (Ps.drop (r + 1)).prod

/-- The recursive insertion derivative is exactly the sum over every external slot. -/
theorem insertionDerivative_sum (D : ExteriorAlgebra R M →ₗ[R] ExteriorAlgebra R M)
    (Ps : List (ExteriorAlgebra R M)) :
    insertionDerivative D Ps = ∑ r ∈ Finset.range Ps.length, insertionSlot D Ps r := by
  induction Ps with
  | nil => simp [insertionDerivative]
  | cons P Ps ih =>
    rw [insertionDerivative, ih, List.length_cons, Finset.sum_range_succ']
    simp only [insertionSlot, List.take_succ_cons, List.prod_cons, List.getD_cons_succ,
      List.drop_succ_cons, List.take_zero, List.prod_nil, List.getD_cons_zero, List.drop_zero,
      one_mul, mul_assoc]
    rw [← Finset.mul_sum]
    exact add_comm _ _

/-- All polynomial insertion contacts explicitly indexed by the slot of the factor. -/
theorem contraction_list_prod_sum (a : M) (Ps : List (ExteriorAlgebra R M))
    (hPs : ∀ P ∈ Ps, CliffordAlgebra.involute P = P) :
    C.contraction a Ps.prod =
      ∑ r ∈ Finset.range Ps.length, insertionSlot (C.contraction a) Ps r := by
  rw [contraction_list_prod C a Ps hPs, insertionDerivative_sum]

/-- Exact coefficientwise Ward identity for the nth interaction power. -/
theorem power_ward (a b : M) (P S : ExteriorAlgebra R M)
    (hP : CliffordAlgebra.involute P = P)
    (hS : CliffordAlgebra.involute S = S) (n : ℕ) :
    C.expectation (ExteriorAlgebra.ι R a *
      (ExteriorAlgebra.ι R b * (P * S ^ (n + 1)))) =
      C.form a b * C.expectation (P * S ^ (n + 1)) -
        C.expectation (ExteriorAlgebra.ι R b * (C.contraction a P * S ^ (n + 1))) -
        ((n + 1 : ℕ) : R) * C.expectation
          (ExteriorAlgebra.ι R b * (P * (S ^ n * C.contraction a S))) := by
  rw [C.expectation_ward_split a b P (S ^ (n + 1)) hP,
    contraction_pow_succ C a S hS n, mul_smul_comm, mul_smul_comm, map_smul]
  rfl

section ComplexExponential

variable {V : Type*} [AddCommGroup V] [Module ℂ V]

/-- The factorial-weighted exponential polynomial of degree n. -/
def truncatedExp (S : ExteriorAlgebra ℂ V) (n : ℕ) : ExteriorAlgebra ℂ V :=
  ∑ r ∈ Finset.range (n + 1), ((r.factorial : ℂ)⁻¹) • S ^ r

private theorem factorial_coefficient (n : ℕ) :
    (((n + 1).factorial : ℂ)⁻¹) * ((n + 1 : ℕ) : ℂ) = (n.factorial : ℂ)⁻¹ := by
  have hn : ((n + 1 : ℕ) : ℂ) ≠ 0 := by exact_mod_cast Nat.succ_ne_zero n
  rw [Nat.factorial_succ, Nat.cast_mul, mul_inv_rev, mul_assoc, inv_mul_cancel₀ hn, mul_one]

/-- Exact derivative of the truncated exponential, including the correct truncation shift. -/
theorem contraction_truncatedExp_succ (C : SYK.Wick.Covariance ℂ V) (a : V)
    (S : ExteriorAlgebra ℂ V) (hS : CliffordAlgebra.involute S = S) (n : ℕ) :
    C.contraction a (truncatedExp S (n + 1)) =
      truncatedExp S n * C.contraction a S := by
  unfold truncatedExp
  simp only [map_sum, map_smul]
  rw [Finset.sum_range_succ']
  simp only [pow_zero, C.contraction_one, smul_zero, add_zero]
  simp only [contraction_pow_succ C a S hS, smul_smul, factorial_coefficient,
    Finset.sum_mul, smul_mul_assoc]

/-- Exact Ward identity for a finite exponential polynomial, retaining its final-order boundary. -/
theorem truncated_exponential_ward (C : SYK.Wick.Covariance ℂ V) (a b : V)
    (P S : ExteriorAlgebra ℂ V) (hP : CliffordAlgebra.involute P = P)
    (hS : CliffordAlgebra.involute S = S) (n : ℕ) :
    C.expectation (ExteriorAlgebra.ι ℂ a *
      (ExteriorAlgebra.ι ℂ b * (P * truncatedExp S (n + 1)))) =
      C.form a b * C.expectation (P * truncatedExp S (n + 1)) -
        C.expectation (ExteriorAlgebra.ι ℂ b * (C.contraction a P * truncatedExp S (n + 1))) -
        C.expectation (ExteriorAlgebra.ι ℂ b * (P * (truncatedExp S n * C.contraction a S))) := by
  rw [C.expectation_ward_split a b P (truncatedExp S (n + 1)) hP,
    contraction_truncatedExp_succ C a S hS n]

/-- Beyond a nilpotence cutoff, the next exponential polynomial equals the previous one. -/
theorem truncatedExp_stable (S : ExteriorAlgebra ℂ V) (n : ℕ) (hnil : S ^ (n + 1) = 0) :
    truncatedExp S (n + 1) = truncatedExp S n := by
  unfold truncatedExp
  rw [Finset.sum_range_succ]
  simp [hnil]

/-- An exact interacting exponential Ward identity for a nilpotent even interaction.
The nilpotence cutoff is explicit; no convergence of a continuum series is presumed. -/
theorem nilpotent_exponential_ward (C : SYK.Wick.Covariance ℂ V) (a b : V)
    (P S : ExteriorAlgebra ℂ V) (hP : CliffordAlgebra.involute P = P)
    (hS : CliffordAlgebra.involute S = S) (n : ℕ) (hnil : S ^ (n + 1) = 0) :
    C.expectation (ExteriorAlgebra.ι ℂ a *
      (ExteriorAlgebra.ι ℂ b * (P * truncatedExp S n))) =
      C.form a b * C.expectation (P * truncatedExp S n) -
        C.expectation (ExteriorAlgebra.ι ℂ b * (C.contraction a P * truncatedExp S n)) -
        C.expectation (ExteriorAlgebra.ι ℂ b * (P * (truncatedExp S n * C.contraction a S))) := by
  simpa only [truncatedExp_stable S n hnil] using
    truncated_exponential_ward C a b P S hP hS n

/-- The numerical coefficients used to evaluate an exterior exponential with an insertion. -/
def exponentialCoefficient (C : SYK.Wick.Covariance ℂ V)
    (S P : ExteriorAlgebra ℂ V) (n : ℕ) : ℂ :=
  (n.factorial : ℂ)⁻¹ * C.expectation (P * S ^ n)

/-- A scalar Wick exponential series; convergence is stated explicitly when used. -/
def exponentialMoment (C : SYK.Wick.Covariance ℂ V)
    (S P : ExteriorAlgebra ℂ V) : ℂ :=
  ∑' n, exponentialCoefficient C S P n

private theorem exponential_partials_tendsto (C : SYK.Wick.Covariance ℂ V)
    (S P : ExteriorAlgebra ℂ V) (h : Summable (exponentialCoefficient C S P)) :
    Filter.Tendsto (fun n => C.expectation (P * truncatedExp S n)) Filter.atTop
      (nhds (exponentialMoment C S P)) := by
  have he (n : ℕ) : C.expectation (P * truncatedExp S n) =
      ∑ r ∈ Finset.range (n + 1), exponentialCoefficient C S P r := by
    simp [truncatedExp, exponentialCoefficient, Finset.mul_sum, mul_smul_comm, map_smul,
      map_sum, smul_eq_mul]
  simp only [he]
  exact h.hasSum.tendsto_sum_nat.comp (Filter.tendsto_add_atTop_nat 1)

private theorem truncated_ward_reassociated (C : SYK.Wick.Covariance ℂ V) (a b : V)
    (P S : ExteriorAlgebra ℂ V) (hP : CliffordAlgebra.involute P = P)
    (hS : CliffordAlgebra.involute S = S) (n : ℕ) :
    C.expectation ((ExteriorAlgebra.ι ℂ a * (ExteriorAlgebra.ι ℂ b * P)) *
      truncatedExp S (n + 1)) =
      C.form a b * C.expectation (P * truncatedExp S (n + 1)) -
        C.expectation ((ExteriorAlgebra.ι ℂ b * C.contraction a P) * truncatedExp S (n + 1)) -
        C.expectation ((ExteriorAlgebra.ι ℂ b * (P * C.contraction a S)) * truncatedExp S n) := by
  have he : CliffordAlgebra.involute (truncatedExp S n) = truncatedExp S n := by
    simp [truncatedExp, hS]
  have hw := truncated_exponential_ward C a b P S hP hS n
  rw [even_commutes (truncatedExp S n) (C.contraction a S) he] at hw
  simpa only [mul_assoc] using hw

/-- The interacting exponential Ward identity follows from convergence of its four
actual numerical Wick series. Convergence, rather than the Ward identity, is the
remaining hypothesis to be supplied by analytic bounds in a continuum model. -/
theorem exponential_ward_of_summable (C : SYK.Wick.Covariance ℂ V) (a b : V)
    (P S : ExteriorAlgebra ℂ V) (hP : CliffordAlgebra.involute P = P)
    (hS : CliffordAlgebra.involute S = S)
    (hleft : Summable (exponentialCoefficient C S
      (ExteriorAlgebra.ι ℂ a * (ExteriorAlgebra.ι ℂ b * P))))
    (hbase : Summable (exponentialCoefficient C S P))
    (hcontact : Summable (exponentialCoefficient C S
      (ExteriorAlgebra.ι ℂ b * C.contraction a P)))
    (hinteraction : Summable (exponentialCoefficient C S
      (ExteriorAlgebra.ι ℂ b * (P * C.contraction a S)))) :
    exponentialMoment C S (ExteriorAlgebra.ι ℂ a * (ExteriorAlgebra.ι ℂ b * P)) =
      C.form a b * exponentialMoment C S P -
        exponentialMoment C S (ExteriorAlgebra.ι ℂ b * C.contraction a P) -
        exponentialMoment C S (ExteriorAlgebra.ι ℂ b * (P * C.contraction a S)) := by
  have hl := (exponential_partials_tendsto C S _ hleft).comp
    (Filter.tendsto_add_atTop_nat 1)
  have hb := (exponential_partials_tendsto C S _ hbase).comp
    (Filter.tendsto_add_atTop_nat 1)
  have hc := (exponential_partials_tendsto C S _ hcontact).comp
    (Filter.tendsto_add_atTop_nat 1)
  have hi := exponential_partials_tendsto C S _ hinteraction
  apply tendsto_nhds_unique hl
  have hconst : Filter.Tendsto (fun _ : ℕ => C.form a b) Filter.atTop
      (nhds (C.form a b)) := tendsto_const_nhds
  have hr := ((hconst.mul hb).sub hc).sub hi
  convert hr using 1
  ext n
  exact truncated_ward_reassociated C a b P S hP hS n

end ComplexExponential
section ThermalQuartic

open SYK.ThermalWick

/-- Sum of all distinguished-flavor partner contractions for an arbitrary insertion. -/
def partnerContraction {N : ℕ} {β : ℝ} (s t : Time β)
    (P : ExteriorAlgebra ℂ (FieldSpace N β)) : ExteriorAlgebra ℂ (FieldSpace N β) :=
  ∑ i : Fin N, field i t * (covariance N β).contraction (Finsupp.single (i, s) 1) P

/-- The flavor sum exactly converts one external bilocal contraction into bilocals. -/
theorem partnerContraction_collective {N : ℕ} {β : ℝ} (s t a b : Time β) :
    partnerContraction s t (collective N β a b) =
      (SYK.Thermal.kernel β s.val a.val : ℂ) • collective N β t b -
        (SYK.Thermal.kernel β s.val b.val : ℂ) • collective N β t a := by
  unfold partnerContraction
  simp_rw [SYK.ThermalWick.contraction_collective]
  simp only [mul_smul_comm, mul_sub, Finset.sum_sub_distrib,
    ← Finset.smul_sum, collective, smul_sub, smul_smul]
  congr 1 <;> congr 1 <;> ring

/-- The two contact signs in the printed Ward equation follow by endpoint skewness. -/
theorem partnerContraction_contact_sign {N : ℕ} {β : ℝ} (s t a b : Time β) :
    -partnerContraction s t (collective N β a b) =
      (SYK.Thermal.kernel β s.val a.val : ℂ) • collective N β b t -
        (SYK.Thermal.kernel β s.val b.val : ℂ) • collective N β a t := by
  rw [partnerContraction_collective, collective_skew N β t b, collective_skew N β t a]
  simp only [smul_neg, neg_sub]
  abel

/-- Partner contraction obeys the even product rule before any expectation is taken. -/
theorem partnerContraction_even_mul {N : ℕ} {β : ℝ} (s t : Time β)
    (P Q : ExteriorAlgebra ℂ (FieldSpace N β))
    (hP : CliffordAlgebra.involute P = P) :
    partnerContraction s t (P * Q) = partnerContraction s t P * Q +
      P * partnerContraction s t Q := by
  unfold partnerContraction
  rw [Finset.sum_mul, Finset.mul_sum, ← Finset.sum_add_distrib]
  apply Finset.sum_congr rfl
  intro i _
  rw [(covariance N β).contraction_even_mul _ P Q hP, mul_add]
  congr 1
  · exact (mul_assoc _ _ _).symm
  · rw [← mul_assoc, ← even_commutes P (field i t) hP, mul_assoc]

/-- An arbitrary finite monomial in actual continuous-time collective coordinates. -/
def collectiveMonomial {N : ℕ} {β : ℝ} (pairs : List (Time β × Time β)) :
    ExteriorAlgebra ℂ (FieldSpace N β) :=
  (pairs.map (fun p => collective N β p.1 p.2)).prod

/-- The full contact polynomial, one term for every insertion, with the printed signs. -/
def contactPolynomial {N : ℕ} {β : ℝ} (s t : Time β) :
    List (Time β × Time β) → ExteriorAlgebra ℂ (FieldSpace N β)
  | [] => 0
  | p :: ps =>
      ((SYK.Thermal.kernel β s.val p.1.val : ℂ) • collective N β p.2 t -
        (SYK.Thermal.kernel β s.val p.2.val : ℂ) • collective N β p.1 t) *
          collectiveMonomial ps + collective N β p.1 p.2 * contactPolynomial s t ps

/-- Every inserted monomial retains all its exact flavor-summed contact terms. -/
theorem partnerContraction_monomial {N : ℕ} {β : ℝ} (s t : Time β)
    (pairs : List (Time β × Time β)) :
    -partnerContraction s t (collectiveMonomial (N := N) pairs) =
      contactPolynomial s t pairs := by
  induction pairs with
  | nil => simp [collectiveMonomial, contactPolynomial, partnerContraction]
  | cons p ps ih =>
    change -partnerContraction s t
      (collective N β p.1 p.2 * collectiveMonomial ps) = _
    rw [partnerContraction_even_mul s t _ _ (collective_even N β p.1 p.2), neg_add]
    rw [← neg_mul, ← mul_neg, partnerContraction_contact_sign, ih]
    rfl

theorem partnerContraction_smul {N : ℕ} {β : ℝ} (s t : Time β)
    (c : ℂ) (P : ExteriorAlgebra ℂ (FieldSpace N β)) :
    partnerContraction s t (c • P) = c • partnerContraction s t P := by
  simp [partnerContraction, map_smul, mul_smul_comm, Finset.smul_sum]

/-- The exact power multiplicity survives the flavor-summed partner contraction. -/
theorem partnerContraction_pow_succ {N : ℕ} {β : ℝ} (s t : Time β)
    (P : ExteriorAlgebra ℂ (FieldSpace N β))
    (hP : CliffordAlgebra.involute P = P) (n : ℕ) :
    partnerContraction s t (P ^ (n + 1)) =
      ((n + 1 : ℕ) : ℂ) • (P ^ n * partnerContraction s t P) := by
  unfold partnerContraction
  simp_rw [contraction_pow_succ (covariance N β) _ P hP n]
  simp only [mul_smul_comm, ← Finset.smul_sum]
  congr 1
  rw [Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro i _
  rw [← mul_assoc, ← even_commutes (P ^ n) (field i t) (by simp [hP]), mul_assoc]

/-- The actual pointwise quartic interaction density N lambda G(u,v)^4 / 8.
The continuum interaction integrates this density coefficient by coefficient. -/
def quarticDensity (N : ℕ) (β lam : ℝ) (u v : Time β) :
    ExteriorAlgebra ℂ (FieldSpace N β) :=
  ((N : ℂ) * (lam : ℂ) / 8) • collective N β u v ^ 4

/-- The quartic density is even, as required in all insertion identities. -/
theorem quarticDensity_even (N : ℕ) (β lam : ℝ) (u v : Time β) :
    CliffordAlgebra.involute (quarticDensity N β lam u v) = quarticDensity N β lam u v := by
  simp [quarticDensity, collective_even]

/-- Exact microscopic derivative of the actual thermal quartic density.
This proves the lambda/2 factor before swapping the two integration variables. -/
theorem contraction_quarticDensity {N : ℕ} {β : ℝ} (lam : ℝ)
    (i : Fin N) (s u v : Time β) :
    (covariance N β).contraction (Finsupp.single (i, s) 1) (quarticDensity N β lam u v) =
      ((lam : ℂ) / 2) • (collective N β u v ^ 3 *
        ((SYK.Thermal.kernel β s.val u.val : ℂ) • field i v -
          (SYK.Thermal.kernel β s.val v.val : ℂ) • field i u)) := by
  have hN : 0 < N := Nat.zero_lt_of_lt i.isLt
  have hNC : (N : ℂ) ≠ 0 := by exact_mod_cast (Nat.ne_of_gt hN)
  unfold quarticDensity
  rw [map_smul, contraction_pow_succ (covariance N β) _ _ (collective_even N β u v) 3,
    contraction_collective, mul_smul_comm, smul_smul, smul_smul]
  congr 1
  norm_num
  field_simp
  ring

/-- After the distinguished flavor average, the quartic interaction has the precise
lambda/2 coefficient and endpoint signs that precede continuum symmetrization. -/
theorem normalized_quartic_partner {N : ℕ} (hN : 0 < N) {β : ℝ}
    (lam : ℝ) (s t u v : Time β) :
    -((N : ℂ)⁻¹) • partnerContraction s t (quarticDensity N β lam u v) =
      ((lam : ℂ) / 2) • (collective N β u v ^ 3 *
        ((SYK.Thermal.kernel β s.val u.val : ℂ) • collective N β v t -
          (SYK.Thermal.kernel β s.val v.val : ℂ) • collective N β u t)) := by
  have hNC : (N : ℂ) ≠ 0 := by exact_mod_cast (Nat.ne_of_gt hN)
  have hs : -((N : ℂ)⁻¹) * (((N : ℂ) * (lam : ℂ) / 8) * 4) = -((lam : ℂ) / 2) := by
    field_simp
    ring
  unfold quarticDensity
  rw [partnerContraction_smul, partnerContraction_pow_succ s t _ (collective_even N β u v) 3,
    smul_smul, smul_smul]
  norm_num only [Nat.cast_add, Nat.cast_one, Nat.cast_ofNat] at *
  rw [mul_assoc, hs]
  rw [neg_smul, ← smul_neg, ← mul_neg, partnerContraction_contact_sign]

/-- Quartic vertex lists are even and so preserve every external insertion term. -/
theorem quartic_list_contraction {N : ℕ} {β : ℝ} (lam : ℝ) (i : Fin N) (s : Time β)
    (vertices : List (Time β × Time β)) :
    (covariance N β).contraction (Finsupp.single (i, s) 1)
        (vertices.map (fun p => quarticDensity N β lam p.1 p.2)).prod =
      insertionDerivative ((covariance N β).contraction (Finsupp.single (i, s) 1))
        (vertices.map (fun p => quarticDensity N β lam p.1 p.2)) := by
  apply contraction_list_prod
  intro P hP
  rcases List.mem_map.mp hP with ⟨p, _, rfl⟩
  exact quarticDensity_even N β lam p.1 p.2

end ThermalQuartic
end SYK.Ward
