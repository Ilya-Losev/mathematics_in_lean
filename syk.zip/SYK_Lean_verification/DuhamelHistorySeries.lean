import MomentMeasurability
import Mathlib.Analysis.Normed.Ring.InfiniteSum
import Mathlib.MeasureTheory.Integral.DominatedConvergence

/-!
# Absolutely convergent exponential expansion of actual thermal histories

The coefficients are constructed from the genuine propagator power series.
No Duhamel or interacting Wick identity is assumed. Rewriting this convergent
multi-index expansion as ordered continuous-time vertex integrals is a separate
subsequent step.
-/

set_option maxHeartbeats 400000

noncomputable section
open scoped BigOperators NNReal ComplexOrder
open MeasureTheory

namespace SYK.DuhamelHistory

/-- Ordered finite product, with no commutativity assumption. -/
def orderedProduct {A : Type*} [Monoid A] {k : ℕ} (F : Fin k → A) : A := (List.ofFn F).prod

@[simp] theorem orderedProduct_zero {A : Type*} [Monoid A] (F : Fin 0 → A) :
    orderedProduct F = 1 := by simp [orderedProduct]

@[simp] theorem orderedProduct_succ {A : Type*} [Monoid A] {k : ℕ} (F : Fin (k+1) → A) :
    orderedProduct F = F 0 * orderedProduct (fun i => F i.succ) := by
  simp only [orderedProduct, List.ofFn_succ, List.prod_cons]

section OrderedSeries
variable {A : Type*} [NormedRing A] [NormOneClass A] [CompleteSpace A]

/-- Absolute convergence is preserved by every finite noncommutative product
of independently indexed series. -/
theorem summable_norm_orderedProduct {k : ℕ} (F : Fin k → ℕ → A)
    (hF : ∀ i, Summable (fun r => ‖F i r‖)) :
    Summable (fun r : Fin k → ℕ => ‖orderedProduct (fun i => F i (r i))‖) := by
  induction k with
  | zero =>
    letI : Fintype (Fin 0 → ℕ) := Fintype.ofFinite _
    exact (hasSum_fintype _).summable
  | succ k ih =>
    apply (Fin.consEquiv (fun _ : Fin (k+1) => ℕ)).summable_iff.mp
    simpa only [Function.comp_def, Fin.consEquiv, Equiv.coe_fn_mk,
      orderedProduct_succ, Fin.cons_zero, Fin.cons_succ] using
      (hF 0).mul_norm (ih (fun i => F i.succ) (fun i => hF i.succ))

/-- Multiplying the true sums produces exactly the independently indexed
noncommutative product coefficients. -/
theorem hasSum_orderedProduct {k : ℕ} (F : Fin k → ℕ → A) (a : Fin k → A)
    (hF : ∀ i, HasSum (F i) (a i)) (habs : ∀ i, Summable (fun r => ‖F i r‖)) :
    HasSum (fun r : Fin k → ℕ => orderedProduct (fun i => F i (r i))) (orderedProduct a) := by
  induction k with
  | zero =>
    letI : Fintype (Fin 0 → ℕ) := Fintype.ofFinite _
    simpa using (hasSum_fintype (fun _ : Fin 0 → ℕ => (1 : A)))
  | succ k ih =>
    apply (Fin.consEquiv (fun _ : Fin (k+1) => ℕ)).hasSum_iff.mp
    have ht := ih (fun i => F i.succ) (fun i => a i.succ) (fun i => hF i.succ) (fun i => habs i.succ)
    have ha := summable_norm_orderedProduct (fun i => F i.succ) (fun i => habs i.succ)
    have hp : Summable (fun p : ℕ × (Fin k → ℕ) =>
        ‖F 0 p.1 * orderedProduct (fun i => F i.succ (p.2 i))‖) :=
      Summable.mul_norm (f := F 0) (g := fun r : Fin k → ℕ =>
        orderedProduct (fun i => F i.succ (r i))) (habs 0) ha
    have hp' : Summable (fun p : ℕ × (Fin k → ℕ) =>
        F 0 p.1 * orderedProduct (fun i => F i.succ (p.2 i))) := hp.of_norm
    have hh : HasSum (fun p : ℕ × (Fin k → ℕ) =>
        F 0 p.1 * orderedProduct (fun i => F i.succ (p.2 i)))
        (a 0 * orderedProduct (fun i => a i.succ)) :=
      HasSum.mul (f := F 0) (g := fun r : Fin k → ℕ =>
        orderedProduct (fun i => F i.succ (r i))) (hF 0) ht hp'
    simpa only [Function.comp_def, Fin.consEquiv, Equiv.coe_fn_mk,
      orderedProduct_succ, Fin.cons_zero, Fin.cons_succ] using hh

end OrderedSeries

section Exponentials
variable {A : Type*} [NormedRing A] [NormedAlgebra ℂ A] [NormOneClass A] [CompleteSpace A]

/-- The actual factorial-normalized exponential coefficient. -/
def expCoefficient (B : A) (r : ℕ) : A := (r.factorial : ℂ)⁻¹ • B^r

/-- Its absolute scalar majorant. -/
def scalarCoefficient (b : ℝ) (r : ℕ) : ℝ := (r.factorial : ℝ)⁻¹ * b^r

theorem norm_expCoefficient_le (B : A) (r : ℕ) :
    ‖expCoefficient B r‖ ≤ scalarCoefficient ‖B‖ r := by
  rw [expCoefficient, norm_smul, norm_inv, Complex.norm_natCast]
  exact mul_le_mul_of_nonneg_left (norm_pow_le B r) (by positivity)

theorem hasSum_scalarCoefficient (b : ℝ) : HasSum (scalarCoefficient b) (Real.exp b) := by
  simpa only [scalarCoefficient, Real.exp_eq_exp_ℝ, smul_eq_mul] using
    (NormedSpace.exp_series_hasSum_exp' (𝕂 := ℝ) b)

theorem summable_norm_expCoefficient (B : A) : Summable (fun r => ‖expCoefficient B r‖) :=
  Summable.of_nonneg_of_le (fun _ => norm_nonneg _) (norm_expCoefficient_le B)
    (hasSum_scalarCoefficient ‖B‖).summable

theorem hasSum_expCoefficient (B : A) : HasSum (expCoefficient B) (NormedSpace.exp ℂ B) :=
  NormedSpace.exp_series_hasSum_exp' B

/-- Each expanded propagator followed by an insertion is absolutely summable. -/
theorem summable_norm_expCoefficient_mul (B U : A) :
    Summable (fun r => ‖expCoefficient B r * U‖) := by
  apply Summable.of_nonneg_of_le (fun _ => norm_nonneg _) (fun r => norm_mul_le _ _)
  exact (summable_norm_expCoefficient B).mul_right ‖U‖

/-- True simultaneous expansion of a finite product of matrix exponentials
and arbitrary interspersed insertions. -/
theorem hasSum_exponential_history {k : ℕ} (B U : Fin k → A) :
    HasSum (fun r : Fin k → ℕ => orderedProduct (fun i => expCoefficient (B i) (r i) * U i))
      (orderedProduct (fun i => NormedSpace.exp ℂ (B i) * U i)) := by
  apply hasSum_orderedProduct (fun i r => expCoefficient (B i) r * U i)
    (fun i => NormedSpace.exp ℂ (B i) * U i)
  · intro i; exact (hasSum_expCoefficient (B i)).mul_right (U i)
  · intro i; exact summable_norm_expCoefficient_mul _ _

/-- Absolute convergence of the simultaneous expansion. -/
theorem summable_norm_exponential_history {k : ℕ} (B U : Fin k → A) :
    Summable (fun r : Fin k → ℕ => ‖orderedProduct (fun i => expCoefficient (B i) (r i) * U i)‖) :=
  summable_norm_orderedProduct (fun i r => expCoefficient (B i) r * U i)
    (fun i => summable_norm_expCoefficient_mul (B i) (U i))



/-- The scalar product majorant sums to the exact exponential envelope. -/
theorem hasSum_scalar_history {k : ℕ} (b c : Fin k → ℝ)
    (hb : ∀ i, 0 ≤ b i) (hc : ∀ i, 0 ≤ c i) :
    HasSum (fun r : Fin k → ℕ => ∏ i, scalarCoefficient (b i) (r i) * c i)
      (Real.exp (∑ i, b i) * ∏ i, c i) := by
  have h := hasSum_orderedProduct
    (fun i r => scalarCoefficient (b i) r * c i)
    (fun i => Real.exp (b i) * c i)
    (fun i => (hasSum_scalarCoefficient (b i)).mul_right (c i))
    (fun i => by
      have hn (r : ℕ) : 0 ≤ scalarCoefficient (b i) r * c i := by
        unfold scalarCoefficient
        exact mul_nonneg (mul_nonneg (by positivity) (pow_nonneg (hb i) r)) (hc i)
      simpa only [Real.norm_eq_abs, abs_of_nonneg (hn _)] using
        (hasSum_scalarCoefficient (b i)).summable.mul_right (c i))
  simpa only [orderedProduct, List.prod_ofFn, Finset.prod_mul_distrib, Real.exp_sum] using h

/-- Termwise domination of the genuine noncommutative coefficients. -/
theorem norm_history_coefficient_le {k : ℕ} (B U : Fin k → A) (r : Fin k → ℕ) :
    ‖orderedProduct (fun i => expCoefficient (B i) (r i) * U i)‖ ≤
      ∏ i, scalarCoefficient ‖B i‖ (r i) * ‖U i‖ := by
  have h := List.norm_prod_le (List.ofFn (fun i => expCoefficient (B i) (r i) * U i))
  apply h.trans
  simp only [List.map_ofFn, List.prod_ofFn]
  apply Finset.prod_le_prod (fun _ _ => norm_nonneg _)
  intro i _
  exact (norm_mul_le _ _).trans
    (mul_le_mul_of_nonneg_right (norm_expCoefficient_le _ _) (norm_nonneg _))

/-- The complete absolute expansion is bounded by the usual exponential
Duhamel envelope, without any commutativity of the inserted matrices. -/
theorem tsum_norm_history_le {k : ℕ} (B U : Fin k → A) :
    (∑' r : Fin k → ℕ, ‖orderedProduct (fun i => expCoefficient (B i) (r i) * U i)‖) ≤
      Real.exp (∑ i, ‖B i‖) * ∏ i, ‖U i‖ := by
  have hmaj := hasSum_scalar_history (fun i => ‖B i‖) (fun i => ‖U i‖)
    (fun _ => norm_nonneg _) (fun _ => norm_nonneg _)
  exact (tsum_le_tsum (norm_history_coefficient_le B U)
    (summable_norm_exponential_history B U) hmaj.summable).trans_eq hmaj.tsum_eq

end Exponentials



/-- Ordinary Clifford trace divided by the actual Hilbert-space dimension. -/
def normalizedTraceCLM (d : ℕ) : CStarMatrix (Majorana.Basis d) (Majorana.Basis d) ℂ →L[ℂ] ℂ :=
  ((2 : ℂ)^d)⁻¹ • ThermalBound.ctrace

@[simp] theorem normalizedTraceCLM_ofMatrix (d : ℕ)
    (A : Matrix (Majorana.Basis d) (Majorana.Basis d) ℂ) :
    normalizedTraceCLM d (CStarMatrix.ofMatrix A) = Majorana.normalizedTrace d A := by
  simp [normalizedTraceCLM, Majorana.normalizedTrace, div_eq_mul_inv, mul_comm]

/-- The normalized trace has operator norm at most one. -/
theorem norm_normalizedTraceCLM_le (d : ℕ)
    (A : CStarMatrix (Majorana.Basis d) (Majorana.Basis d) ℂ) :
    ‖normalizedTraceCLM d A‖ ≤ ‖A‖ := by
  change ‖((2 : ℂ)^d)⁻¹ * Matrix.trace (CStarMatrix.ofMatrix.symm A)‖ ≤ _
  rw [norm_mul, norm_inv, norm_pow]
  norm_num only [Complex.norm_ofNat]
  calc
    _ ≤ ((2 : ℝ)^d)⁻¹ * ((2 : ℝ)^d * ‖A‖) :=
      mul_le_mul_of_nonneg_left (Majorana.norm_trace_le d (CStarMatrix.ofMatrix.symm A)) (by positivity)
    _ = _ := by rw [← mul_assoc, inv_mul_cancel₀ (by positivity), one_mul]

/-- A coefficient of the actual independently expanded thermal gaps. -/
def gapCoefficient (d : ℕ) {k : ℕ}
    (H : Matrix (Majorana.Basis d) (Majorana.Basis d) ℂ) (t : Fin k → ℝ)
    (U : Fin k → Matrix (Majorana.Basis d) (Majorana.Basis d) ℂ) (r : Fin k → ℕ) : ℂ :=
  normalizedTraceCLM d (orderedProduct (fun i =>
    expCoefficient ((-(t i : ℂ)) • CStarMatrix.ofMatrix H) (r i) * CStarMatrix.ofMatrix (U i)))

/-- Actual operator transfer histories are the sums of their genuine gap coefficients. -/
theorem hasSum_gapCoefficient (d : ℕ) {k : ℕ}
    (H : Matrix (Majorana.Basis d) (Majorana.Basis d) ℂ) (t : Fin k → ℝ)
    (U : Fin k → Matrix (Majorana.Basis d) (Majorana.Basis d) ℂ) :
    HasSum (gapCoefficient d H t U)
      (Majorana.normalizedTrace d ((List.ofFn (fun i => Gibbs.weight (t i) H * U i)).prod)) := by
  have h := (hasSum_exponential_history (fun i => (-(t i : ℂ)) • CStarMatrix.ofMatrix H)
    (fun i => CStarMatrix.ofMatrix (U i))).mapL (normalizedTraceCLM d)
  change HasSum (gapCoefficient d H t U)
    (normalizedTraceCLM d (orderedProduct (fun i =>
      ThermalBound.heat (CStarMatrix.ofMatrix H) (t i : ℂ) * CStarMatrix.ofMatrix (U i)))) at h
  simp_rw [ThermalBound.heat_real] at h
  change HasSum (gapCoefficient d H t U)
    (normalizedTraceCLM d (CStarMatrix.ofMatrix
      ((List.ofFn (fun i => Gibbs.weight (t i) H * U i)).prod))) at h
  rw [normalizedTraceCLM_ofMatrix] at h
  exact h

/-- Absolute convergence is proved for the actual scalar trace coefficients. -/
theorem summable_norm_gapCoefficient (d : ℕ) {k : ℕ}
    (H : Matrix (Majorana.Basis d) (Majorana.Basis d) ℂ) (t : Fin k → ℝ)
    (U : Fin k → Matrix (Majorana.Basis d) (Majorana.Basis d) ℂ) :
    Summable (fun r => ‖gapCoefficient d H t U r‖) := by
  apply Summable.of_nonneg_of_le (fun _ => norm_nonneg _)
    (fun r => norm_normalizedTraceCLM_le d _)
  exact summable_norm_exponential_history (fun i => (-(t i : ℂ)) • CStarMatrix.ofMatrix H)
    (fun i => CStarMatrix.ofMatrix (U i))

/-- The complete absolute gap expansion has the dimension-free normalized
Duhamel majorant with the actual Hamiltonian operator norm. -/
theorem tsum_norm_gapCoefficient_le (d : ℕ) {k : ℕ}
    (H : Matrix (Majorana.Basis d) (Majorana.Basis d) ℂ) (t : Fin k → ℝ)
    (U : Fin k → Matrix (Majorana.Basis d) (Majorana.Basis d) ℂ) :
    (∑' r, ‖gapCoefficient d H t U r‖) ≤
      Real.exp ((∑ i, |t i|) * ThermalBound.opNorm H) * ∏ i, ThermalBound.opNorm (U i) := by
  have h := tsum_norm_history_le (fun i => (-(t i : ℂ)) • CStarMatrix.ofMatrix H)
    (fun i => CStarMatrix.ofMatrix (U i))
  calc
    _ ≤ ∑' r : Fin k → ℕ, ‖orderedProduct (fun i =>
        expCoefficient ((-(t i : ℂ)) • CStarMatrix.ofMatrix H) (r i) * CStarMatrix.ofMatrix (U i))‖ :=
      (summable_norm_gapCoefficient d H t U).tsum_le_tsum
        (fun r => norm_normalizedTraceCLM_le d _)
        (summable_norm_exponential_history
          (fun i => (-(t i : ℂ)) • CStarMatrix.ofMatrix H)
          (fun i => CStarMatrix.ofMatrix (U i)))
    _ ≤ _ := by
      have hn (i : Fin k) : ‖(-(t i : ℂ)) • CStarMatrix.ofMatrix H‖ =
          |t i| * ThermalBound.opNorm H := by
        rw [norm_smul (-(t i : ℂ)) (CStarMatrix.ofMatrix H), norm_neg,
          Complex.norm_real, Real.norm_eq_abs]
        rfl
      simpa only [hn, ← Finset.sum_mul, ThermalBound.opNorm] using h

/-- For nonnegative gaps of total duration beta, actual SYK disorder gives
precisely the Gaussian-integrable exponential envelope used in the manuscript. -/
theorem syk_tsum_norm_gapCoefficient_le (d : ℕ) {k : ℕ} (j : Majorana.FourSet d → ℝ)
    (t : Fin k → ℝ) (ht : ∀ i, 0 ≤ t i)
    (U : Fin k → Matrix (Majorana.Basis d) (Majorana.Basis d) ℂ) :
    (∑' r, ‖gapCoefficient d (Majorana.hamiltonian d j) t U r‖) ≤
      Real.exp ((∑ i, t i) / 4 * ∑ I, |j I|) * ∏ i, ThermalBound.opNorm (U i) := by
  apply (tsum_norm_gapCoefficient_le d _ t U).trans
  apply mul_le_mul_of_nonneg_right _ (Finset.prod_nonneg (fun i _ => norm_nonneg _))
  apply Real.exp_le_exp.mpr
  simp only [abs_of_nonneg (ht _)]
  have h := mul_le_mul_of_nonneg_left (Majorana.norm_hamiltonian_le d j)
    (show 0 ≤ ∑ i, t i from Finset.sum_nonneg (fun i _ => ht i))
  convert h using 1 <;> dsimp [ThermalBound.opNorm] <;> ring

/-- Continuity of an ordered finite product does not need commutativity. -/
theorem continuous_orderedProduct {X A : Type*} [TopologicalSpace X]
    [Monoid A] [TopologicalSpace A] [ContinuousMul A] {k : ℕ}
    (F : X → Fin k → A) (hF : ∀ i, Continuous (fun x => F x i)) :
    Continuous (fun x => orderedProduct (F x)) := by
  induction k with
  | zero => simpa only [orderedProduct_zero] using continuous_const
  | succ k ih =>
    simpa only [orderedProduct_succ] using
      (hF 0).mul (ih (fun x i => F x i.succ) (fun i => hF i.succ))

/-- Each genuine gap coefficient is a continuous polynomial of the disorder. -/
theorem continuous_gapCoefficient (d : ℕ) {k : ℕ} (t : Fin k → ℝ)
    (U : Fin k → Matrix (Majorana.Basis d) (Majorana.Basis d) ℂ) (r : Fin k → ℕ) :
    Continuous (fun j => gapCoefficient d (Majorana.hamiltonian d j) t U r) := by
  apply (normalizedTraceCLM d).continuous.comp
  apply continuous_orderedProduct
  intro i
  apply Continuous.mul _ continuous_const
  unfold expCoefficient
  apply Continuous.const_smul
  apply Continuous.pow
  exact (CStarMatrix.ofMatrixL.continuous.comp (Majorana.continuous_hamiltonian d)).const_smul _

/-- Every coefficient is integrable under the actual finite-dimensional SYK
Gaussian law, proved from the absolute exponential envelope. -/
theorem gapCoefficient_integrable (d : ℕ) (lam : ℝ≥0) {k : ℕ}
    (t : Fin k → ℝ) (ht : ∀ i, 0 ≤ t i)
    (U : Fin k → Matrix (Majorana.Basis d) (Majorana.Basis d) ℂ) (r : Fin k → ℕ) :
    Integrable (fun j => gapCoefficient d (Majorana.hamiltonian d j) t U r)
      (Microscopic.disorder d lam) := by
  apply ((GaussianDisorder.integrable_exp_sum_abs (Majorana.FourSet d) (2*d) lam
    ((∑ i, t i)/4)).mul_const (∏ i, ThermalBound.opNorm (U i))).mono'
  · exact (continuous_gapCoefficient d t U r).aestronglyMeasurable
  · filter_upwards [] with j
    exact (Summable.le_tsum (summable_norm_gapCoefficient d _ t U) r
      (fun _ _ => norm_nonneg _)).trans (syk_tsum_norm_gapCoefficient_le d j t ht U)

/-- Summability of the integrals of the norms establishes the full Fubini
hypothesis, rather than assuming an exchange of disorder average and series. -/
theorem summable_integral_norm_gapCoefficient (d : ℕ) (lam : ℝ≥0) {k : ℕ}
    (t : Fin k → ℝ) (ht : ∀ i, 0 ≤ t i)
    (U : Fin k → Matrix (Majorana.Basis d) (Majorana.Basis d) ℂ) :
    Summable (fun r : Fin k → ℕ => ∫ j,
      ‖gapCoefficient d (Majorana.hamiltonian d j) t U r‖ ∂Microscopic.disorder d lam) := by
  classical
  let g := fun j : Majorana.FourSet d → ℝ =>
    Real.exp ((∑ i, t i)/4 * ∑ I, |j I|) * ∏ i, ThermalBound.opNorm (U i)
  have hg : Integrable g (Microscopic.disorder d lam) :=
    (GaussianDisorder.integrable_exp_sum_abs (Majorana.FourSet d) (2*d) lam
      ((∑ i, t i)/4)).mul_const _
  apply summable_of_sum_le (fun _ => integral_nonneg (fun _ => norm_nonneg _))
    (c := ∫ j, g j ∂Microscopic.disorder d lam)
  intro s
  rw [← integral_finset_sum s (fun r _ => (gapCoefficient_integrable d lam t ht U r).norm)]
  apply integral_mono (integrable_finset_sum s
    (fun r _ => (gapCoefficient_integrable d lam t ht U r).norm)) hg
  intro j
  exact (Summable.sum_le_tsum s (fun _ _ => norm_nonneg _)
    (summable_norm_gapCoefficient d _ t U)).trans (syk_tsum_norm_gapCoefficient_le d j t ht U)

/-- The actual annealed thermal history is the sum of the actual Gaussian
averages of its gap coefficients. All convergence and exchange hypotheses
are discharged for the genuine SYK Hamiltonian. -/
theorem hasSum_integral_gapCoefficient (d : ℕ) (lam : ℝ≥0) {k : ℕ}
    (t : Fin k → ℝ) (ht : ∀ i, 0 ≤ t i)
    (U : Fin k → Matrix (Majorana.Basis d) (Majorana.Basis d) ℂ) :
    HasSum (fun r : Fin k → ℕ => ∫ j,
      gapCoefficient d (Majorana.hamiltonian d j) t U r ∂Microscopic.disorder d lam)
      (∫ j, Majorana.normalizedTrace d
        ((List.ofFn (fun i => Gibbs.weight (t i) (Majorana.hamiltonian d j) * U i)).prod)
        ∂Microscopic.disorder d lam) := by
  have h := hasSum_integral_of_summable_integral_norm
    (fun r => gapCoefficient_integrable d lam t ht U r)
    (summable_integral_norm_gapCoefficient d lam t ht U)
  simpa only [(hasSum_gapCoefficient d _ t U).tsum_eq] using h

end SYK.DuhamelHistory
