import WickSeriesDerivative

/-! # Measurable external parameters in actual scalar Wick coefficients -/
noncomputable section
open MeasureTheory Set
open scoped Topology
namespace SYK.ContinuumWickSeries
open ThermalWick Ward WickVertexIntegrals

local instance (β : ℝ) : MeasurableSpace (Time β) :=
  inferInstanceAs (MeasurableSpace {t : ℝ // t ∈ Ico 0 β})

/-- The coefficient integrand remains genuinely measurable when external
bilocal times are arbitrary measurable parameter functions. -/
theorem coefficientIntegrand_parameter_measurable {X : Type*} [MeasurableSpace X]
    (d : ℕ) (β : ℝ) (hβ : 0 < β)
    (ps : List ((X → Time β) × (X → Time β)))
    (hps : ∀ p ∈ ps, Measurable (fun x => (p.1 x).val) ∧ Measurable (fun x => (p.2 x).val))
    (n : ℕ) :
    Measurable (fun z : X × (Fin n → ℝ×ℝ) =>
      coefficientIntegrand d β hβ (ps.map (fun p => (p.1 z.1,p.2 z.1))) z.2) := by
  let qs : List (((X × (Fin n → ℝ×ℝ)) → Time β) × ((X × (Fin n → ℝ×ℝ)) → Time β)) := ps.map (fun p => ((fun z : X × (Fin n → ℝ×ℝ) => p.1 z.1), (fun z => p.2 z.1))) ++
    (interactionPairFunctions β hβ n).map (fun p => ((fun z => p.1 z.2), (fun z => p.2 z.2)))
  have hqs : ∀ p ∈ qs, Measurable (fun z => (p.1 z).val) ∧ Measurable (fun z => (p.2 z).val) := by
    intro p hp
    rcases List.mem_append.mp hp with hp | hp
    · obtain ⟨q,hq,rfl⟩ := List.mem_map.mp hp
      exact ⟨((hps q hq).1.comp measurable_fst),((hps q hq).2.comp measurable_fst)⟩
    · obtain ⟨q,hq,rfl⟩ := List.mem_map.mp hp
      have hq := interactionPairFunctions_measurable β hβ n q hq
      exact ⟨hq.1.comp measurable_snd,hq.2.comp measurable_snd⟩
  have h := measurable_word_collectives d hβ qs hqs [] (by simp) (by simp)
  have he (z : X × (Fin n → ℝ×ℝ)) :
      qs.map (fun p => (p.1 z,p.2 z)) = ps.map (fun p => (p.1 z.1,p.2 z.1)) ++ interactionPairs β hβ z.2 := by
    simp [qs,List.map_append,List.map_map,Function.comp_def,interactionPairFunctions_eval]
  simpa only [List.map_nil,FreeWick.word_nil,one_mul,he,coefficientIntegrand] using h

/-- Parameter measurability survives the actual coefficient integral. -/
theorem coefficient_parameter_measurable {X : Type*} [MeasurableSpace X]
    (d : ℕ) (β : ℝ) (hβ : 0 < β)
    (ps : List ((X → Time β) × (X → Time β)))
    (hps : ∀ p ∈ ps, Measurable (fun x => (p.1 x).val) ∧ Measurable (fun x => (p.2 x).val))
    (n : ℕ) :
    Measurable (fun x : X => coefficient d β hβ (ps.map (fun p => (p.1 x,p.2 x))) n) := by
  have h := (coefficientIntegrand_parameter_measurable d β hβ ps hps n).stronglyMeasurable.integral_prod_right'
    (ν := interactionMeasure β n)
  exact h.measurable.const_smul _

/-- Product-measure Fubini at an arbitrary marked coordinate, in exactly the
succAbove convention used by the actual even exterior-product algebra. -/
theorem integral_interaction_marked (β : ℝ) (n : ℕ) (r : Fin (n+1))
    (f : (Fin (n+1) → ℝ×ℝ) → ℂ) (hf : Integrable f (interactionMeasure β (n+1))) :
    (∫ u, f u ∂interactionMeasure β (n+1)) =
      ∫ p, ∫ u, f (r.insertNth p u) ∂interactionMeasure β n ∂pairMeasure β := by
  let e := (MeasurableEquiv.piFinSuccAbove (fun _ : Fin (n+1) => ℝ×ℝ) r).symm
  have he : MeasurePreserving e ((pairMeasure β).prod (interactionMeasure β n))
      (interactionMeasure β (n+1)) :=
    (measurePreserving_piFinSuccAbove (fun _ : Fin (n+1) => pairMeasure β) r).symm
  have hi := (he.integrable_comp_emb e.measurableEmbedding).mpr hf
  rw [← he.integral_comp' f]
  change (∫ z, (f ∘ e) z ∂(pairMeasure β).prod (interactionMeasure β n)) = _
  rw [integral_prod _ hi]
  simp only [Function.comp_apply,e,MeasurableEquiv.piFinSuccAbove_symm_apply,Fin.insertNthEquiv,
    Equiv.coe_fn_mk]

end SYK.ContinuumWickSeries
