import ThermalWardSymmetry
import ThermalWardLimit

/-!
# The actual finite right Ward residual is the skewed left residual

No finite Ward identity is assumed in the residual equality. It follows from
actual inserted bilocal skewness, actual sharp moment bounds, measurability
and Fubini on the thermal square.
-/

set_option maxHeartbeats 1200000
noncomputable section
namespace SYK.FiniteWardSymmetry
open SYK.WeightedKernelAlgebra SYK.ThermalEndpointLift SYK.ThermalMomentTransport
open SYK.MomentLimit SYK.MomentCompactness SYK.MixedIncrement SYK.ThermalWeightedState
open SYK.ThermalResidualState SYK.ThermalWardSymmetry SYK.ThermalWardLimit
open MeasureTheory Filter Set
open scoped BigOperators Topology NNReal

variable (β : ℝ) (hβ : 0 < β) (lam : ℝ≥0)

/-- The literal finite right residual is the negative left residual with
external endpoints swapped, including every contact and collision value. -/
theorem rightResidual_eq_neg_left (d : ℕ) (hd : 0 < d) (Q : RealPolynomial) (s t : ℝ) :
    ThermalWardLimit.rightResidual β hβ lam d Q s t =
      -ThermalWardLimit.leftResidual β hβ lam d Q t s := by
  let L : RealPolynomial →ₗ[ℂ] ℂ := actualThermalPolynomial β hβ d lam
  have hs : ∀ Q s t, L (Q * MvPolynomial.X (t,s)) = -L (Q * MvPolynomial.X (s,t)) :=
    actualThermal_inserted_skew β hβ d lam
  have hLb : ∀ P, ‖L P‖ ≤ coefficientNorm (fun _ => (1/2:ℝ)) P :=
    actualThermalPolynomial_bound β hβ d hd lam
  let F : ℝ → ℝ → ℂ := fun u v => (Thermal.kernel β v t : ℂ) *
    L (Q * coordinateProduct [(s,u),(u,v),(u,v),(u,v)])
  have hm : Measurable (Function.uncurry F) := by
    have hh := actualThermal_inserted_measurable β hβ d lam Q
      (fun p : ℝ×ℝ => ![(s,p.1),(p.1,p.2),(p.1,p.2),(p.1,p.2)]) (by
        intro i
        fin_cases i <;> dsimp <;> fun_prop)
    have hcoords : Measurable (fun p : ℝ×ℝ =>
        L (Q * coordinateProduct [(s,p.1),(p.1,p.2),(p.1,p.2),(p.1,p.2)])) := by
      simpa only [coordinateProduct, List.map_cons, List.map_nil, List.prod_cons,
        List.prod_nil, Fin.prod_univ_succ, Fin.prod_univ_zero, Fin.cons_zero,
        Fin.cons_succ, mul_one] using hh
    exact (Complex.measurable_ofReal.comp ((Thermal.covariance_measurable β).comp
      (measurable_snd.sub measurable_const))).mul hcoords
  have hb (u v : ℝ) : ‖F u v‖ ≤ (1/2 : ℝ) * (coefficientNorm (fun _ => (1/2:ℝ)) Q / 16) := by
    change ‖(Thermal.kernel β v t : ℂ) *
      L (Q * coordinateProduct [(s,u),(u,v),(u,v),(u,v)])‖ ≤ _
    rw [norm_mul, Complex.norm_real, Real.norm_eq_abs]
    exact mul_le_mul (Thermal.abs_covariance_le β _)
      (inserted_four_bound L hLb Q [(s,u),(u,v),(u,v),(u,v)] rfl)
      (norm_nonneg _) (by norm_num)
  let μ := volume.restrict (Ioc (0:ℝ) β)
  have hi : Integrable (Function.uncurry F) (μ.prod μ) :=
    (integrable_const ((1/2 : ℝ) * (coefficientNorm (fun _ => (1/2:ℝ)) Q / 16))).mono'
      hm.aestronglyMeasurable (Eventually.of_forall (fun p => hb p.1 p.2))
  have hswap : (∫ u in (0:ℝ)..β, ∫ v in (0:ℝ)..β, F v u) =
      ∫ u in (0:ℝ)..β, ∫ v in (0:ℝ)..β, F u v := by
    simp only [intervalIntegral.integral_of_le hβ.le]
    exact (integral_integral_swap hi).symm
  have hpoint (u v : ℝ) : (Thermal.kernel β t u : ℂ) *
      L (Q * coordinateProduct [(u,v),(u,v),(u,v),(v,s)]) = -(F v u) := by
    rw [inserted_reverse_four L hs, Thermal.kernel_skew β u t, Complex.ofReal_neg]
    simp only [F, neg_mul]
  have hIntegral : (∫ u in (0:ℝ)..β, ∫ v in (0:ℝ)..β, (Thermal.kernel β t u : ℂ) *
      L (Q * coordinateProduct [(u,v),(u,v),(u,v),(v,s)])) =
      -(∫ u in (0:ℝ)..β, ∫ v in (0:ℝ)..β, F u v) := by
    simp only [hpoint, intervalIntegral.integral_neg, hswap]
  change L (Q * SYK.MixedIncrement.remainder β (s,t)) - (lam : ℂ) *
      (∫ u in (0:ℝ)..β, ∫ v in (0:ℝ)..β, F u v) =
    -(L (Q * SYK.MixedIncrement.remainder β (t,s)) - (lam : ℂ) *
      (∫ u in (0:ℝ)..β, ∫ v in (0:ℝ)..β, (Thermal.kernel β t u : ℂ) *
        L (Q * coordinateProduct [(u,v),(u,v),(u,v),(v,s)])))
  rw [inserted_remainder_skew L hs β Q s t, hIntegral]
  ring

/-- Only the finite left inserted Ward estimate and its sharper centered
contact estimate are needed for the full two-sided compactness interface. -/
theorem finiteWardControl_of_left (d : ℕ → ℕ) (hd : ∀ n, 0 < d n)
    (hleft : ∀ Q s t, ∃ A : ℝ, ∀ n,
      ‖ThermalWardLimit.leftResidual β hβ lam (d n) Q s t‖ ≤ A / (d n : ℝ))
    (hcentered : ∀ n (l : List Endpoint) s t,
      ‖ThermalWardLimit.leftResidual β hβ lam (d n) (remainderProduct β l) s t‖ ≤
        (l.length : ℝ)/(4*d n)) : FiniteWardControl β hβ lam d where
  left := hleft
  right := by
    intro Q s t
    obtain ⟨A, hA⟩ := hleft Q t s
    refine ⟨A, fun n => ?_⟩
    rw [rightResidual_eq_neg_left β hβ lam (d n) (hd n), norm_neg]
    exact hA n
  centered := hcentered

end SYK.FiniteWardSymmetry
