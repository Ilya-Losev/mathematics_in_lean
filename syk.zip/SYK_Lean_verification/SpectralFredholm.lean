import FourierOperators
import Mathlib.Analysis.Normed.Operator.Compact
import Mathlib.Analysis.Normed.Operator.Banach
import Mathlib.LinearAlgebra.Eigenspace.Basic
import Mathlib.Topology.Algebra.InfiniteSum.Constructions

/-!
# Spectral definition of the ordinary determinant for the physical diagonal operator

The determinant is defined from the operator's eigenspaces and their actual
multiplicities. The diagonal coefficient list is used only to prove its value.
-/
noncomputable section
open Filter Set Module.End
open scoped Topology BigOperators
namespace SYK.SpectralFredholm
open DiagonalFredholm

variable {ι : Type*} [DecidableEq ι]
abbrev Fiber (a : ι → ℝ) (r : ℝ) := {i : ι // a i = r}

theorem finite_fiber (a : ι → ℝ) (ha : Summable (fun i => |a i|))
    (r : ℝ) (hr : r ≠ 0) : Finite (Fiber a r) := by
  have hs := ha.subtype (fun i => a i = r)
  have hc : Summable (fun _ : Fiber a r => |r|) := by
    exact hs.congr (fun i => by dsimp only [Function.comp_def]; rw [i.property])
  exact Finite.of_summable_const (abs_pos.mpr hr) hc

theorem eigen_support (a : ι → ℝ) (ha : Summable (fun i => |a i|))
    (r : ℝ) (x : H (ι := ι)) :
    x ∈ Module.End.eigenspace (diagonal a).toLinearMap (r : ℂ) ↔
      ∀ i, a i ≠ r → x i = 0 := by
  rw [Module.End.mem_eigenspace_iff]
  constructor
  · intro hx i hi
    have he := congrArg (fun y : H (ι := ι) => y i) hx
    simp only [ContinuousLinearMap.coe_coe, diagonal_apply a ha, lp.coeFn_smul,
      Pi.smul_apply, smul_eq_mul] at he
    have hz : ((a i : ℂ) - (r : ℂ)) * x i = 0 := by rw [sub_mul, he, sub_self]
    exact (mul_eq_zero.mp hz).resolve_left
      (sub_ne_zero.mpr (fun h => hi (Complex.ofReal_injective h)))
  · intro hx
    apply lp.ext
    funext i
    simp only [ContinuousLinearMap.coe_coe, diagonal_apply a ha, lp.coeFn_smul,
      Pi.smul_apply, smul_eq_mul]
    by_cases hi : a i = r
    · rw [hi]
    · rw [hx i hi, mul_zero, mul_zero]

def fiberVector (a : ι → ℝ) (r : ℝ) [Fintype (Fiber a r)] (v : Fiber a r → ℂ) : H (ι := ι) :=
  ∑ i : Fiber a r, lp.single 2 (i : ι) (v i)

theorem fiberVector_apply (a : ι → ℝ) (r : ℝ) [Fintype (Fiber a r)]
    (v : Fiber a r → ℂ) (j : ι) :
    fiberVector a r v j = if h : a j = r then v ⟨j,h⟩ else 0 := by
  classical
  simp only [fiberVector, lp.coeFn_sum, Finset.sum_apply]
  by_cases h : a j = r
  · rw [dif_pos h, Finset.sum_eq_single (⟨j,h⟩ : Fiber a r)]
    · simp [lp.single_apply]
    · intro i _ hi
      have hn : j ≠ (i : ι) := fun hj => hi (Subtype.ext hj.symm)
      simp [lp.single_apply, hn]
    · simp
  · rw [dif_neg h]
    apply Finset.sum_eq_zero
    intro i _
    have hn : j ≠ (i : ι) := fun hj => h (hj ▸ i.property)
    simp [lp.single_apply, hn]

def eigenspaceEquiv (a : ι → ℝ) (ha : Summable (fun i => |a i|))
    (r : ℝ) [Fintype (Fiber a r)] :
    Module.End.eigenspace (diagonal a).toLinearMap (r : ℂ) ≃ₗ[ℂ] (Fiber a r → ℂ) where
  toFun := fun x i => (x : H (ι := ι)) (i : ι)
  invFun := fun v => ⟨fiberVector a r v, (eigen_support a ha r _).mpr (by
    intro i hi; rw [fiberVector_apply, dif_neg hi])⟩
  left_inv := by
    intro x
    apply Subtype.ext
    apply lp.ext
    funext i
    rw [fiberVector_apply]
    split_ifs with hi
    · rfl
    · exact ((eigen_support a ha r x).mp x.property i hi).symm
  right_inv := by
    intro v
    funext i
    simp only [fiberVector_apply, dif_pos i.property]
  map_add' := fun _ _ => rfl
  map_smul' := fun _ _ => rfl

theorem diagonal_multiplicity (a : ι → ℝ) (ha : Summable (fun i => |a i|))
    (r : ℝ) (hr : r ≠ 0) :
    Module.finrank ℂ (Module.End.eigenspace (diagonal a).toLinearMap (r : ℂ)) = Nat.card (Fiber a r) := by
  letI := finite_fiber a ha r hr
  letI := Fintype.ofFinite (Fiber a r)
  rw [(eigenspaceEquiv a ha r).finrank_eq]
  simp [Nat.card_eq_fintype_card]

section Intrinsic
variable {E F : Type*} [NormedAddCommGroup E] [NormedSpace ℂ E]
  [NormedAddCommGroup F] [NormedSpace ℂ F]

/-- Spectral determinant of I+T from the operator's real eigenspaces and their
geometric multiplicities. For the self-adjoint trace-class operators below,
these are all nonzero eigenvalues and are also the algebraic multiplicities. -/
def spectralDeterminant (T : E →L[ℂ] E) : ℝ :=
  ∏' r : ℝ, (1+r) ^ Module.finrank ℂ (Module.End.eigenspace T.toLinearMap (r : ℂ))

def conjugateEigenspaceEquiv (T : E →L[ℂ] E) (U : F →L[ℂ] F)
    (e : E ≃ₗ[ℂ] F) (he : ∀ x, U (e x) = e (T x)) (r : ℝ) :
    Module.End.eigenspace T.toLinearMap (r : ℂ) ≃ₗ[ℂ]
      Module.End.eigenspace U.toLinearMap (r : ℂ) where
  toFun := fun x => ⟨e x, by
    rw [Module.End.mem_eigenspace_iff]
    change U (e x) = _
    have hx : T x = (r : ℂ) • (x : E) := Module.End.mem_eigenspace_iff.mp x.property
    rw [he, hx, map_smul]⟩
  invFun := fun y => ⟨e.symm y, by
    rw [Module.End.mem_eigenspace_iff]
    change T (e.symm y) = (r : ℂ) • e.symm y
    apply e.injective
    rw [← he, e.apply_symm_apply, map_smul, e.apply_symm_apply]
    exact Module.End.mem_eigenspace_iff.mp y.property⟩
  left_inv := by intro x; apply Subtype.ext; exact e.symm_apply_apply x
  right_inv := by intro y; apply Subtype.ext; exact e.apply_symm_apply y
  map_add' := by intro x y; apply Subtype.ext; exact e.map_add x y
  map_smul' := by intro c x; apply Subtype.ext; exact e.map_smul c x

/-- Intrinsic basis independence: even similarity, hence unitary equivalence,
preserves the operator-only spectral definition. -/
theorem spectralDeterminant_conjugate (T : E →L[ℂ] E) (U : F →L[ℂ] F)
    (e : E ≃ₗ[ℂ] F) (he : ∀ x, U (e x) = e (T x)) :
    spectralDeterminant T = spectralDeterminant U := by
  apply tprod_congr
  intro r
  rw [(conjugateEigenspaceEquiv T U e he r).finrank_eq]
end Intrinsic

theorem diagonal_spectralDeterminant (a : ι → ℝ)
    (ha : Summable (fun i => |a i|)) :
    spectralDeterminant (diagonal a) = Continuum.relativeProduct a := by
  classical
  have har : Summable a := (by simpa only [Real.norm_eq_abs] using ha :
    Summable (fun i => ‖a i‖)).of_norm
  have hp := Real.multipliable_one_add_of_summable har
  have hf (r : ℝ) : Multipliable (fun i : Fiber a r => 1 + a i) := by
    by_cases hr : r = 0
    · subst r
      simpa only [fun i : Fiber a 0 => i.property, add_zero] using
        (multipliable_one : Multipliable (fun _ : Fiber a 0 => (1 : ℝ)))
    · letI := finite_fiber a ha r hr
      letI := Fintype.ofFinite (Fiber a r)
      exact (hasProd_fintype _).multipliable
  have he : (∏' r : ℝ, ∏' i : Fiber a r, (1 + a i)) = ∏' i, (1 + a i) := by
    exact (((Equiv.sigmaFiberEquiv a).multipliable_iff.mpr hp).tprod_sigma' hf).symm.trans
      ((Equiv.sigmaFiberEquiv a).tprod_eq (fun i => 1 + a i))
  unfold spectralDeterminant Continuum.relativeProduct
  rw [← he]
  apply tprod_congr
  intro r
  by_cases hr : r = 0
  · subst r
    simp only [add_zero, one_pow]
    simp only [fun i : Fiber a 0 => i.property, add_zero, tprod_one]
  · letI := finite_fiber a ha r hr
    letI := Fintype.ofFinite (Fiber a r)
    rw [diagonal_multiplicity a ha r hr, Nat.card_eq_fintype_card, tprod_fintype]
    simp only [fun i : Fiber a r => i.property, Finset.prod_const, Finset.card_univ]

/-- The diagonal operator is compact because its actual finite-rank series
converges in operator norm. -/
theorem diagonal_compact (a : ι → ℝ) (ha : Summable (fun i => |a i|)) :
    IsCompactOperator (diagonal a) := by
  have hp (i : ι) : IsCompactOperator (projection (ι := ι) i) := by
    have he : IsCompactOperator (evaluation (ι := ι) i) := by
      refine ⟨Metric.closedBall (0 : ℂ) 1, isCompact_closedBall _ _, ?_⟩
      exact (evaluation i).continuous.continuousAt.preimage_mem_nhds
        (by simpa using Metric.closedBall_mem_nhds (0 : ℂ) (by norm_num : (0 : ℝ) < 1))
    exact he.clm_comp (lp.singleContinuousLinearMap ℂ (fun _ : ι => ℂ) 2 i)
  apply isCompactOperator_of_tendsto (finiteRank_tendsto a ha)
  filter_upwards [] with s
  exact (compactOperator (RingHom.id ℂ) (H (ι := ι)) (H (ι := ι))).sum_mem
    (fun i _ => (hp i).smul (a i : ℂ))

/-- Away from zero and the coefficient range, the actual resolvent multipliers
are uniformly bounded. -/
theorem resolvent_bound (a : ι → ℝ) (ha : Summable (fun i => |a i|))
    (z : ℂ) (hz : z ≠ 0) (hne : ∀ i, (a i : ℂ) ≠ z) :
    ∃ C : ℝ, ∀ i, ‖(z - (a i : ℂ))⁻¹‖ ≤ C := by
  have har : Summable a := (by simpa only [Real.norm_eq_abs] using ha :
    Summable (fun i => ‖a i‖)).of_norm
  have ht : Tendsto (fun i => (a i : ℂ)) cofinite (𝓝 0) := by
    simpa only [Complex.ofReal_zero] using Complex.continuous_ofReal.continuousAt.tendsto.comp
      har.tendsto_cofinite_zero
  have hK := ht.isCompact_insert_range_of_cofinite
  have hn (w : ℂ) (hw : w ∈ insert 0 (range (fun i => (a i : ℂ)))) : z-w ≠ 0 := by
    rcases hw with rfl | ⟨i,rfl⟩
    · simpa using hz
    · exact sub_ne_zero.mpr (hne i).symm
  have hc : ContinuousOn (fun w : ℂ => (z-w)⁻¹) (insert 0 (range (fun i => (a i : ℂ)))) :=
    (continuous_const.sub continuous_id).continuousOn.inv₀ hn
  obtain ⟨C,hC⟩ := hK.exists_bound_of_continuousOn hc
  exact ⟨C, fun i => hC _ (mem_insert_of_mem _ (mem_range_self i))⟩

/-- Coordinatewise multiplication by any uniformly bounded sequence preserves
actual ℓ² membership. -/
theorem bounded_mul_mem (c : ι → ℂ) (C : ℝ) (hc : ∀ i, ‖c i‖ ≤ C)
    (x : H (ι := ι)) : Memℓp (fun i => c i * x i) 2 := by
  apply memℓp_gen
  have hs := (lp.memℓp x).summable (by norm_num : (0 : ℝ) < (2 : ENNReal).toReal)
  simp only [ENNReal.toReal_ofNat, Real.rpow_two] at hs ⊢
  apply Summable.of_nonneg_of_le (fun _ => sq_nonneg _) _ (hs.mul_left (C^2))
  intro i
  rw [norm_mul, mul_pow]
  exact mul_le_mul_of_nonneg_right (pow_le_pow_left₀ (norm_nonneg _) (hc i) 2) (sq_nonneg _)

/-- There is no extra nonzero spectrum beyond the explicitly constructed modes. -/
theorem nonzero_spectrum_iff (a : ι → ℝ) (ha : Summable (fun i => |a i|))
    (z : ℂ) (hz : z ≠ 0) : z ∈ spectrum ℂ (diagonal a) ↔ ∃ i, (a i : ℂ) = z := by
  rw [spectrum.mem_iff, ContinuousLinearMap.isUnit_iff_bijective]
  constructor
  · contrapose!
    intro hne
    obtain ⟨C,hC⟩ := resolvent_bound a ha z hz hne
    constructor
    · intro x y he
      apply lp.ext
      funext i
      have hi := congrArg (fun w : H (ι := ι) => w i) he
      have hzi : z-(a i : ℂ) ≠ 0 := sub_ne_zero.mpr (hne i).symm
      simp only [ContinuousLinearMap.sub_apply, ContinuousLinearMap.algebraMap_apply,
        lp.coeFn_sub, Pi.sub_apply, lp.coeFn_smul, Pi.smul_apply, smul_eq_mul,
        diagonal_apply a ha] at hi
      exact mul_left_cancel₀ hzi (by simpa only [sub_mul] using hi)
    · intro y
      let x : H (ι := ι) := ⟨fun i => (z-(a i : ℂ))⁻¹ * y i,
        bounded_mul_mem _ C hC y⟩
      refine ⟨x, ?_⟩
      apply lp.ext
      funext i
      have hzi : z-(a i : ℂ) ≠ 0 := sub_ne_zero.mpr (hne i).symm
      simp only [ContinuousLinearMap.sub_apply, ContinuousLinearMap.algebraMap_apply,
        lp.coeFn_sub, Pi.sub_apply, lp.coeFn_smul, Pi.smul_apply, smul_eq_mul,
        diagonal_apply a ha]
      change z * ((z-(a i : ℂ))⁻¹*y i) - (a i : ℂ)*((z-(a i : ℂ))⁻¹*y i) = y i
      rw [← sub_mul, ← mul_assoc, mul_inv_cancel₀ hzi, one_mul]
  · rintro ⟨i,rfl⟩ hbij
    have he : (algebraMap ℂ (H (ι := ι) →L[ℂ] H (ι := ι)) (a i : ℂ) - diagonal a)
        (coordinateBasis i) = 0 := by
      rw [ContinuousLinearMap.sub_apply, ContinuousLinearMap.algebraMap_apply, diagonal_basis a ha,
        sub_self]
    have hzero := hbij.1 (he.trans (map_zero _).symm)
    have hi := congrArg (fun x : H (ι := ι) => x i) hzero
    simpa [coordinateBasis_apply, lp.single_apply] using hi

theorem shifted_power_apply (a : ι → ℝ) (ha : Summable (fun i => |a i|))
    (z : ℂ) (n : ℕ) (x : H (ι := ι)) (i : ι) :
    (((diagonal a).toLinearMap - z • 1)^n) x i = ((a i : ℂ)-z)^n * x i := by
  induction n generalizing x with
  | zero => simp
  | succ n ih =>
    rw [pow_succ, Module.End.mul_apply, ih]
    simp only [LinearMap.sub_apply, LinearMap.smul_apply, Module.End.one_apply,
      ContinuousLinearMap.coe_coe, lp.coeFn_sub, Pi.sub_apply, lp.coeFn_smul,
      Pi.smul_apply, smul_eq_mul, diagonal_apply a ha]
    ring

/-- There are no nontrivial Jordan chains: algebraic and geometric eigenspaces
coincide even before restricting to any finite-dimensional subspace. -/
theorem generalized_eigenspace_eq (a : ι → ℝ) (ha : Summable (fun i => |a i|))
    (r : ℝ) : Module.End.genEigenspace (diagonal a).toLinearMap (r : ℂ) ⊤ =
      Module.End.eigenspace (diagonal a).toLinearMap (r : ℂ) := by
  apply le_antisymm
  · intro x hx
    rcases Module.End.mem_genEigenspace.mp hx with ⟨n, _, hn⟩
    apply (eigen_support a ha r x).mpr
    intro i hi
    have he := congrArg (fun y : H (ι := ι) => y i) hn
    have hzi : (a i : ℂ)-(r : ℂ) ≠ 0 := sub_ne_zero.mpr (fun h => hi (Complex.ofReal_injective h))
    change (((diagonal a).toLinearMap - (r : ℂ) • 1)^n) x i = 0 at he
    rw [shifted_power_apply a ha] at he
    exact (mul_eq_zero.mp he).resolve_left (pow_ne_zero _ hzi)
  · intro x hx
    apply Module.End.mem_genEigenspace.mpr
    refine ⟨1, le_top, ?_⟩
    change (((diagonal a).toLinearMap - (r : ℂ) • 1 : Module.End ℂ (H (ι := ι)))^(1 : ℕ)) x = 0
    have hx' : diagonal a x = (r : ℂ) • x := Module.End.mem_eigenspace_iff.mp hx
    simp only [pow_one, LinearMap.sub_apply, LinearMap.smul_apply, Module.End.one_apply]
    change diagonal a x - (r : ℂ) • x = 0
    rw [hx', sub_self]

/-- Absolute spectral summability with the operator's intrinsic multiplicity. -/
theorem spectral_absolute_sum (a : ι → ℝ) (ha : Summable (fun i => |a i|)) :
    HasSum (fun r : ℝ =>
      (Module.finrank ℂ (Module.End.eigenspace (diagonal a).toLinearMap (r : ℂ)) : ℝ) * |r|)
      (∑' i, |a i|) := by
  have hs := ha.hasSum.tsum_fiberwise a
  convert hs using 1
  funext r
  change (Module.finrank ℂ (Module.End.eigenspace (diagonal a).toLinearMap (r : ℂ)) : ℝ) * |r| =
    ∑' i : Fiber a r, |a i|
  by_cases hr : r = 0
  · subst r
    simp only [abs_zero, mul_zero]
    simp only [fun i : Fiber a 0 => i.property, abs_zero, tsum_zero]
  · letI := finite_fiber a ha r hr
    letI := Fintype.ofFinite (Fiber a r)
    rw [diagonal_multiplicity a ha r hr, Nat.card_eq_fintype_card, tsum_fintype]
    simp only [fun i : Fiber a r => i.property, Finset.sum_const, Finset.card_univ, nsmul_eq_mul]

end SYK.SpectralFredholm
