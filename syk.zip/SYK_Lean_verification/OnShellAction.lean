import RelativeLogSeries

/-!
# The actual infinite-mode on-shell relative action

The logarithmic series uses every signed fermionic frequency with factor 1/2.
Summability follows from the already proved physical Fourier/Parseval theorem,
and positivity of every determinant factor follows from the actual SD equation.
No summability, reciprocal identity, or log-action derivative is assumed.
-/

set_option maxHeartbeats 1000000
noncomputable section
open MeasureTheory Set
open scoped BigOperators NNReal ComplexConjugate
namespace SYK.Continuum

variable (β : ℝ) [Fact (0 < β)]

/-- Real Parseval for two bounded symmetric time-domain kernels. -/
theorem symmetric_real_parseval (g h : ℝ → ℝ) (hg : Measurable g) (hh : Measurable h)
    (B D : ℝ) (hb : ∀ t, |g t| ≤ B) (hd : ∀ t, |h t| ≤ D)
    (hgs : ∀ t, g (β-t) = g t) (hhs : ∀ t, h (β-t) = h t) :
    HasSum (fun n : ℤ => (fourier β g (integerFrequency β (-n))).im *
      (fourier β h (integerFrequency β (-n))).im)
      (β * ∫ t in (0 : ℝ)..β, g t * h t) := by
  have hs := fermionic_parseval β g h hg hh B D hb hd
  have he (n : ℤ) : conj (fourier β g (integerFrequency β (-n))) *
      fourier β h (integerFrequency β (-n)) =
      (((fourier β g (integerFrequency β (-n))).im *
        (fourier β h (integerFrequency β (-n))).im : ℝ) : ℂ) := by
    rw [integer_fourier_imaginary β g hgs, integer_fourier_imaginary β h hhs]
    apply Complex.ext <;> simp [Complex.mul_re, Complex.mul_im]
  simp_rw [he] at hs
  have hi : (∫ t in (0 : ℝ)..β, ((g t * h t : ℝ) : ℂ)) =
      ((∫ t in (0 : ℝ)..β, g t * h t : ℝ) : ℂ) := by
    simp only [intervalIntegral, integral_complex_ofReal, Complex.ofReal_sub]
  rw [hi] at hs
  have hr := hs.mapL Complex.reCLM
  simpa only [Complex.reCLM_apply, Complex.ofReal_re, Complex.mul_re,
    Complex.ofReal_im, mul_zero, sub_zero] using hr

/-- At every signed frequency the free coefficient is exactly 1/ω. -/
theorem free_integer_fourier_im (n : ℤ) :
    (fourier β (Thermal.covariance β) (integerFrequency β n)).im =
      (integerFrequency β n)⁻¹ := by
  have hp := free_physicalSolution β (Fact.out : 0 < β)
  have hd := physical_integer_dyson β 0 (Thermal.covariance β) hp n
  simp only [NNReal.coe_zero, zero_mul, add_zero] at hd
  have hw : integerFrequency β n ≠ 0 := by
    intro h
    rw [h, mul_zero] at hd
    norm_num at hd
  rw [← one_div]
  exact (eq_div_iff hw).mpr hd

/-- The covariance coefficient and its signed frequency have positive product. -/
theorem physical_frequency_product_pos (lam : ℝ≥0) (g : ℝ → ℝ)
    (hg : PhysicalSolution β lam g) (n : ℤ) :
    0 < (fourier β g (integerFrequency β n)).im * integerFrequency β n := by
  by_cases hn : 0 ≤ n
  · have hs := (physical_integer_signs β lam g hg n).1 hn
    have hw : 0 < integerFrequency β n := by
      rw [integerFrequency_nonneg β n hn]
      exact frequency_pos β (Fact.out : 0 < β) _
    exact mul_pos hs hw
  · have hs := (physical_integer_signs β lam g hg n).2 (lt_of_not_ge hn)
    have hw : integerFrequency β n < 0 := by
      rw [integerFrequency_neg β n (lt_of_not_ge hn)]
      exact neg_neg_of_pos (frequency_pos β (Fact.out : 0 < β) _)
    exact mul_pos_of_neg_of_neg hs hw

/-- The actual relative multiplier CΣ has eigenvalue minus this ratio. -/
def sourceRatio (lam : ℝ≥0) (g : ℝ → ℝ) (n : ℤ) : ℝ :=
  (lam : ℝ) * (fourier β (fun t => (g t)^3) (integerFrequency β (-n))).im /
    integerFrequency β (-n)

/-- Summability is derived from actual Parseval against the free covariance. -/
theorem sourceRatio_summable (lam : ℝ≥0) (g : ℝ → ℝ) (hg : PhysicalSolution β lam g) :
    Summable (sourceRatio β lam g) := by
  rcases hg with ⟨hgm, ⟨B,hb⟩, _, _, hgs, _, _⟩
  have hc := free_physicalSolution β (Fact.out : 0 < β)
  have hcube (t : ℝ) : |(g t)^3| ≤ B^3 := by
    rw [abs_pow]
    exact pow_le_pow_left₀ (abs_nonneg _) (hb t) 3
  have hcs : ∀ t, (g (β-t))^3 = (g t)^3 := fun t => by rw [hgs]
  have hs := (symmetric_real_parseval β (Thermal.covariance β) (fun t => (g t)^3)
    (Thermal.covariance_measurable β) (hgm.pow_const 3) (1/2) (B^3)
    (Thermal.abs_covariance_le β) hcube hc.2.2.2.2.1 hcs).summable.mul_left (lam : ℝ)
  convert hs using 1
  funext n
  rw [free_integer_fourier_im]
  unfold sourceRatio
  ring

/-- The actual physical factors are positive, rather than only their product. -/
theorem sourceRatio_factor_eq (lam : ℝ≥0) (g : ℝ → ℝ)
    (hg : PhysicalSolution β lam g) (n : ℤ) :
    1 + sourceRatio β lam g n =
      ((fourier β g (integerFrequency β (-n))).im * integerFrequency β (-n))⁻¹ := by
  have hp := physical_frequency_product_pos β lam g hg (-n)
  have hx := (mul_ne_zero_iff.mp hp.ne').1
  have hw := (mul_ne_zero_iff.mp hp.ne').2
  have hd := physical_integer_dyson β lam g hg (-n)
  unfold sourceRatio
  field_simp [hx,hw]
  nlinarith [congrArg (fun z : ℝ => z * integerFrequency β (-n)) hd]

theorem sourceRatio_factor_pos (lam : ℝ≥0) (g : ℝ → ℝ)
    (hg : PhysicalSolution β lam g) (n : ℤ) : 0 < 1 + sourceRatio β lam g n := by
  rw [sourceRatio_factor_eq β lam g hg n]
  exact inv_pos.mpr (physical_frequency_product_pos β lam g hg (-n))

/-- Half of the full signed-frequency logarithmic determinant series. -/
def onShellLog (lam : ℝ≥0) (g : ℝ → ℝ) : ℝ :=
  (1 / 2 : ℝ) * logAction (sourceRatio β lam g)

def quarticIntegral (g : ℝ → ℝ) : ℝ := ∫ t in (0 : ℝ)..β, (g t)^4

/-- The standard action evaluated at the actual physical source λg³. -/
def onShellAction (lam : ℝ≥0) (g : ℝ → ℝ) : ℝ :=
  onShellLog β lam g - (3 * β / 8) * (lam : ℝ) * quarticIntegral β g

/-- Logarithmic tangent comparison between two genuine physical sources.
All signed-mode sums and their time-domain identification are proved here. -/
theorem onShellLog_tangent (lam mu : ℝ≥0) (g h : ℝ → ℝ)
    (hg : PhysicalSolution β lam g) (hh : PhysicalSolution β mu h) :
    onShellLog β mu h - onShellLog β lam g ≤
      β / 2 * ((mu : ℝ) * (∫ t in (0 : ℝ)..β, g t * (h t)^3) -
        (lam : ℝ) * quarticIntegral β g) := by
  obtain ⟨B,hb⟩ := hg.2.1
  obtain ⟨D,hd⟩ := hh.2.1
  have hgb (t : ℝ) : |(g t)^3| ≤ B^3 := by
    rw [abs_pow]; exact pow_le_pow_left₀ (abs_nonneg _) (hb t) 3
  have hhb (t : ℝ) : |(h t)^3| ≤ D^3 := by
    rw [abs_pow]; exact pow_le_pow_left₀ (abs_nonneg _) (hd t) 3
  have hgs : ∀ t, (g (β-t))^3 = (g t)^3 := fun t => by rw [hg.2.2.2.2.1]
  have hhs : ∀ t, (h (β-t))^3 = (h t)^3 := fun t => by rw [hh.2.2.2.2.1]
  have hs₁ := (symmetric_real_parseval β g (fun t => (h t)^3) hg.1 (hh.1.pow_const 3)
    B (D^3) hb hhb hg.2.2.2.2.1 hhs).mul_left (mu : ℝ)
  have hs₂ := (symmetric_real_parseval β g (fun t => (g t)^3) hg.1 (hg.1.pow_const 3)
    B (B^3) hb hgb hg.2.2.2.2.1 hgs).mul_left (lam : ℝ)
  have he (n : ℤ) :
      (sourceRatio β mu h n-sourceRatio β lam g n)/(1+sourceRatio β lam g n) =
        (mu : ℝ) * ((fourier β g (integerFrequency β (-n))).im *
          (fourier β (fun t => (h t)^3) (integerFrequency β (-n))).im) -
        (lam : ℝ) * ((fourier β g (integerFrequency β (-n))).im *
          (fourier β (fun t => (g t)^3) (integerFrequency β (-n))).im) := by
    have hp := physical_frequency_product_pos β lam g hg (-n)
    have hw := (mul_ne_zero_iff.mp hp.ne').2
    rw [sourceRatio_factor_eq β lam g hg n, div_inv_eq_mul]
    unfold sourceRatio
    field_simp [hw]
    ring
  have hsum := hs₁.sub hs₂
  have htan := logAction_tangent (sourceRatio β lam g) (sourceRatio β mu h)
    (sourceRatio_summable β lam g hg) (sourceRatio_summable β mu h hh)
    (sourceRatio_factor_pos β lam g hg) (sourceRatio_factor_pos β mu h hh)
    (by simpa only [he] using hsum.summable)
  simp only [he, hsum.tsum_eq] at htan
  have heq : (∫ t in (0 : ℝ)..β, g t * (g t)^3) = quarticIntegral β g := by
    apply intervalIntegral.integral_congr
    intro t _
    ring
  rw [heq] at htan
  unfold onShellLog
  linarith


omit [Fact (0 < β)] in
/-- Bounded measurable real functions are genuinely interval integrable. -/
theorem bounded_intervalIntegrable (f : ℝ → ℝ) (hf : Measurable f)
    (B : ℝ) (hb : ∀ t, |f t| ≤ B) : IntervalIntegrable f volume 0 β := by
  apply (intervalIntegrable_const (c := B)).mono_fun' hf.aestronglyMeasurable
  filter_upwards [] with t
  exact hb t

theorem quarticIntegral_nonneg (g : ℝ → ℝ) : 0 ≤ quarticIntegral β g :=
  intervalIntegral.integral_nonneg (Fact.out : 0 < β).le (fun t _ => by positivity)

omit [Fact (0 < β)] in
@[simp] theorem onShellLog_zero (g : ℝ → ℝ) : onShellLog β 0 g = 0 := by
  simp [onShellLog, logAction, sourceRatio]

omit [Fact (0 < β)] in
@[simp] theorem onShellAction_zero (g : ℝ → ℝ) : onShellAction β 0 g = 0 := by
  simp [onShellAction]

/-- Two tangent comparisons with the free source prove the endpoint estimate
directly, without assuming continuity of an infinite determinant. -/
theorem onShellAction_bounds (lam : ℝ≥0) (g : ℝ → ℝ)
    (hg : PhysicalSolution β lam g) (B : ℝ) (hb : ∀ t, |g t| ≤ B) :
    0 ≤ onShellAction β lam g ∧
      onShellAction β lam g ≤ (lam : ℝ) * β^2 * B^3 / 4 := by
  have hβ : 0 < β := Fact.out
  have hC := free_physicalSolution β hβ
  have hQ := quarticIntegral_nonneg β g
  have hlow := onShellLog_tangent β lam 0 g (Thermal.covariance β) hg hC
  simp only [onShellLog_zero, NNReal.coe_zero, zero_mul, zero_sub] at hlow
  have hhigh := onShellLog_tangent β 0 lam (Thermal.covariance β) g hC hg
  simp only [onShellLog_zero, NNReal.coe_zero, zero_mul, sub_zero] at hhigh
  have hB : 0 ≤ B := (abs_nonneg (g 0)).trans (hb 0)
  have hpoint (t : ℝ) : |Thermal.covariance β t * (g t)^3| ≤ (1/2 : ℝ) * B^3 := by
    rw [abs_mul, abs_pow]
    exact mul_le_mul (Thermal.abs_covariance_le β t)
      (pow_le_pow_left₀ (abs_nonneg _) (hb t) 3) (by positivity) (by norm_num)
  have hi := bounded_intervalIntegrable β (fun t => Thermal.covariance β t * (g t)^3)
    ((Thermal.covariance_measurable β).mul (hg.1.pow_const 3)) _ hpoint
  have hu : (∫ t in (0 : ℝ)..β, Thermal.covariance β t * (g t)^3) ≤ β * B^3 / 2 := by
    have h := intervalIntegral.integral_mono hβ.le hi (intervalIntegrable_const (c := (1/2 : ℝ)*B^3))
      (fun t => (le_abs_self _).trans (hpoint t))
    simp only [intervalIntegral.integral_const, sub_zero, smul_eq_mul] at h
    convert h using 1
    ring
  constructor
  · unfold onShellAction
    nlinarith [mul_nonneg lam.coe_nonneg hQ, mul_nonneg hβ.le (mul_nonneg lam.coe_nonneg hQ)]
  · have hscale := mul_le_mul_of_nonneg_left hu (show 0 ≤ β / 2 * (lam : ℝ) by positivity)
    unfold onShellAction
    nlinarith [mul_nonneg lam.coe_nonneg hQ, mul_nonneg hβ.le (mul_nonneg lam.coe_nonneg hQ)]

omit [Fact (0 < β)] in
/-- The ratio is exactly the Fourier transform of the actual source λg³,
not a separately prescribed coefficient sequence. -/
theorem sourceRatio_eq_source_fourier (lam : ℝ≥0) (g : ℝ → ℝ) (n : ℤ) :
    sourceRatio β lam g n =
      (fourier β (fun t => (lam : ℝ) * (g t)^3) (integerFrequency β (-n))).im /
        integerFrequency β (-n) := by
  have hfour : fourier β (fun t => (lam : ℝ) * (g t)^3) (integerFrequency β (-n)) =
      (lam : ℂ) * fourier β (fun t => (g t)^3) (integerFrequency β (-n)) := by
    unfold fourier
    rw [← intervalIntegral.integral_const_mul]
    apply intervalIntegral.integral_congr
    intro t _
    push_cast
    ring
  unfold sourceRatio
  rw [hfour]
  simp only [Complex.mul_im, Complex.ofReal_re, Complex.ofReal_im, zero_mul, add_zero]

end SYK.Continuum

