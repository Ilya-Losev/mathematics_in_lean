import PhysicalUniqueness
import HankelPositivity

noncomputable section
open MeasureTheory Set
open scoped ComplexConjugate NNReal
namespace SYK.Continuum

theorem fourier_im_sine (β : ℝ) (hβ : 0 < β) (g : ℝ → ℝ)
    (hg : Measurable g) (B : ℝ) (hb : ∀ t, |g t| ≤ B) (ω : ℝ) :
    (fourier β g ω).im = ∫ t in (0 : ℝ)..β, Real.sin (ω*t) * g t := by
  letI : Fact (0 < β) := ⟨hβ⟩
  have hi := Complex.imCLM.intervalIntegral_comp_comm (fourier_integrable β g hg B hb ω)
  simpa [fourier, Complex.imCLM_apply, Complex.mul_im, Complex.mul_re,
    Complex.exp_im] using hi.symm

/-- Finite Hankel positivity selects strict physical signs for an actual SD kernel. -/
theorem physical_of_hankel_sd (β : ℝ) (hβ : 0 < β) (lam : ℝ≥0) (g : ℝ → ℝ)
    (hg : Measurable g) (B : ℝ) (hb : ∀ t, |g t| ≤ B)
    (ha : ∀ t, g (t+β) = -g t) (hzero : g 0 = 0)
    (hsym : ∀ t, g (β-t) = g t) (hSD : SDEquation β lam g)
    (hpos : ∀ (k : ℕ) (x : Fin k → Ioo (0 : ℝ) (β/2)) (c : Fin k → ℂ),
      0 ≤ (∑ i, ∑ j, conj (c i) * c j * (g ((x i : ℝ)+(x j : ℝ)) : ℂ)).re) :
    PhysicalSolution β lam g := by
  refine ⟨hg, ⟨B, hb⟩, ha, hzero, hsym, ?_, hSD⟩
  intro n
  have hn : 0 ≤ (fourier β g (frequency β n)).im := by
    rw [fourier_im_sine β hβ g hg B hb]
    exact HankelPositivity.fermionic_sine_integral_nonnegative β hβ n g hg B hb hpos
  have hr := fourier_re_zero β hβ g hsym n
  have he : fourier β g (frequency β n) = Complex.I * (fourier β g (frequency β n)).im := by
    apply Complex.ext <;> simp [hr]
  have hd := scalar_dyson β hβ lam g hg B hb ha hsym hSD n _ he
  have hp := SYK.positive_of_nonnegative_dyson _ _ _ hn hd
  exact ⟨_, hp, he⟩

/-- Any two bounded canonical Hankel-positive continuum SD kernels coincide. -/
theorem hankel_sd_unique (β : ℝ) (hβ : 0 < β) (lam : ℝ≥0)
    (g h : ℝ → ℝ)
    (hg : PhysicalSolution β lam g)
    (hhm : Measurable h) (B : ℝ) (hb : ∀ t, |h t| ≤ B)
    (ha : ∀ t, h (t+β) = -h t) (hzero : h 0 = 0)
    (hsym : ∀ t, h (β-t) = h t) (hSD : SDEquation β lam h)
    (hpos : ∀ (k : ℕ) (x : Fin k → Ioo (0 : ℝ) (β/2)) (c : Fin k → ℂ),
      0 ≤ (∑ i, ∑ j, conj (c i) * c j * (h ((x i : ℝ)+(x j : ℝ)) : ℂ)).re) : g = h := by
  letI : Fact (0 < β) := ⟨hβ⟩
  exact physical_unique β lam g h hg
    (physical_of_hankel_sd β hβ lam h hhm B hb ha hzero hsym hSD hpos)

end SYK.Continuum
