import DuhamelTrace
import GaussianDisorder
import Mathlib.MeasureTheory.Integral.IntegralEqImproper

/-!
# Gaussian integration by parts for the actual disorder law

The Stein identity below is derived from the actual Gaussian density and
improper integration by parts. All integrability assumptions are explicit;
the identity is not postulated as a Gaussian-expectation axiom.
-/

set_option maxHeartbeats 1200000

noncomputable section
open MeasureTheory ProbabilityTheory Filter
open scoped NNReal Topology BigOperators ComplexOrder

namespace SYK.GaussianIBP

/-- Gaussian integrability is integrability of the actual density-weighted
Lebesgue function, for positive variance. -/
theorem integrable_density_mul {v : ℝ≥0} (hv : v ≠ 0) {f : ℝ → ℝ}
    (hf : Integrable f (gaussianReal 0 v)) :
    Integrable (fun x => gaussianPDFReal 0 v x * f x) := by
  rw [gaussianReal_of_var_ne_zero _ hv] at hf
  have h := (integrable_withDensity_iff_integrable_smul'
    (measurable_gaussianPDF 0 v) (ae_of_all _ (fun x => gaussianPDF_lt_top))).mp hf
  simpa only [toReal_gaussianPDF, smul_eq_mul] using h

/-- The logarithmic derivative of the centered Gaussian density. -/
theorem hasDerivAt_gaussian_density (v : ℝ≥0) (hv : v ≠ 0) (x : ℝ) :
    HasDerivAt (gaussianPDFReal 0 v)
      (-(x / (v : ℝ)) * gaussianPDFReal 0 v x) x := by
  have hv' : (v : ℝ) ≠ 0 := NNReal.coe_ne_zero.mpr hv
  have h := (((hasDerivAt_pow 2 x).neg.div_const (2 * (v : ℝ))).exp).const_mul
    (Real.sqrt (2 * Real.pi * (v : ℝ)))⁻¹
  convert h using 1
  · funext y
    simp only [gaussianPDFReal, sub_zero]
  · simp only [gaussianPDFReal, sub_zero, Nat.reduceSub, pow_one, Nat.cast_ofNat]
    ring

/-- Stein's identity at the exact variance v. Boundary terms disappear by the
integrability form of the fundamental theorem on the whole real line. -/
theorem centered_stein_identity {v : ℝ≥0} (hv : v ≠ 0)
    (f f' : ℝ → ℝ) (hderiv : ∀ x, HasDerivAt f (f' x) x)
    (hf : Integrable f (gaussianReal 0 v))
    (hf' : Integrable f' (gaussianReal 0 v))
    (hxf : Integrable (fun x => x * f x) (gaussianReal 0 v)) :
    (∫ x, x * f x ∂gaussianReal 0 v) = (v : ℝ) * ∫ x, f' x ∂gaussianReal 0 v := by
  have hv' : (v : ℝ) ≠ 0 := NNReal.coe_ne_zero.mpr hv
  have hF := integrable_density_mul hv hf
  have hD := integrable_density_mul hv hf'
  have hX := integrable_density_mul hv hxf
  have hleft : Integrable
      (fun x => f x * (-(x / (v : ℝ)) * gaussianPDFReal 0 v x)) := by
    convert hX.const_mul (-((v : ℝ)⁻¹)) using 1
    funext x
    ring
  have hright : Integrable (fun x => f' x * gaussianPDFReal 0 v x) := by
    simpa only [mul_comm] using hD
  have hprod : Integrable (fun x => f x * gaussianPDFReal 0 v x) := by
    simpa only [mul_comm] using hF
  have h := integral_mul_deriv_eq_deriv_mul_of_integrable hderiv
    (hasDerivAt_gaussian_density v hv) hleft hright hprod
  have hl : (∫ x, f x * (-(x / (v : ℝ)) * gaussianPDFReal 0 v x)) =
      -((v : ℝ)⁻¹) * (∫ x, x * f x ∂gaussianReal 0 v) := by
    rw [integral_gaussianReal_eq_integral_smul hv]
    simp only [smul_eq_mul]
    rw [← integral_const_mul]
    congr 1
    funext x
    ring
  have hr : (∫ x, f' x * gaussianPDFReal 0 v x) =
      (∫ x, f' x ∂gaussianReal 0 v) := by
    rw [integral_gaussianReal_eq_integral_smul hv]
    simp only [smul_eq_mul, mul_comm]
  rw [hl, hr] at h
  field_simp [hv'] at h
  linarith


open Majorana DuhamelTrace

/-- The unnormalized insertion that appears in a coupling derivative. -/
def thermalInsertion (m : ℕ) (β : ℝ) (j : FourSet m → ℝ)
    (B : Matrix (Basis m) (Basis m) ℂ) : ℝ :=
  (Matrix.trace (Gibbs.weight β (hamiltonian m j) * B)).re

/-- The actual partition derivative, before dividing by the partition function. -/
theorem hasDerivAt_syk_partition_direction_at (m : ℕ) (β : ℝ)
    (j w : FourSet m → ℝ) (t : ℝ) :
    HasDerivAt
      (fun s : ℝ => (partitionFunction m β (fun I => j I + s * w I)).re)
      (β * ∑ I, w I * thermalInsertion m β (fun I => j I + t * w I) (quartic m I)) t := by
  have h := (hasDerivAt_syk_log_partition_direction_at m β j w t).exp
  have hp : 0 < (partitionFunction m β (fun I => j I + t * w I)).re :=
    Gibbs.syk_partition_re_pos m β _
  have heq (s : ℝ) :
      Real.exp (Real.log (partitionFunction m β (fun I => j I + s * w I)).re) =
      (partitionFunction m β (fun I => j I + s * w I)).re :=
    Real.exp_log (Gibbs.syk_partition_re_pos m β _)
  simp only [heq] at h
  have hi (I : FourSet m) :
      (Matrix.trace (Gibbs.sykDensity m β (fun I => j I + t * w I) * quartic m I)).re =
      (partitionFunction m β (fun I => j I + t * w I)).re⁻¹ *
        thermalInsertion m β (fun I => j I + t * w I) (quartic m I) := by
    simp only [Gibbs.sykDensity, Gibbs.density, smul_mul_assoc, Matrix.trace_smul,
      Complex.real_smul, Complex.mul_re, Complex.ofReal_re, Complex.ofReal_im,
      zero_mul, sub_zero]
    rfl
  simp only [hi] at h
  convert h using 1
  simp only [Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro I _
  field_simp [ne_of_gt hp]

/-- Operator-norm domination of an arbitrary fixed insertion. -/
theorem abs_thermalInsertion_le (m : ℕ) (β : ℝ) (j : FourSet m → ℝ)
    (B : Matrix (Basis m) (Basis m) ℂ) :
    |thermalInsertion m β j B| ≤
      (2 : ℝ)^m * ‖CStarMatrix.ofMatrix B‖ * Real.exp (|β| * (∑ I, |j I|) / 4) := by
  have hexp : ‖CStarMatrix.ofMatrix (Gibbs.weight β (hamiltonian m j))‖ ≤
      Real.exp (|β| * (∑ I, |j I|) / 4) := by
    change ‖NormedSpace.exp ℂ ((-β) • CStarMatrix.ofMatrix (hamiltonian m j))‖ ≤ _
    refine (norm_exp_le m _).trans (Real.exp_le_exp.mpr ?_)
    rw [norm_smul (-β) (CStarMatrix.ofMatrix (hamiltonian m j)), Real.norm_eq_abs, abs_neg]
    exact (mul_le_mul_of_nonneg_left (norm_hamiltonian_le m j) (abs_nonneg β)).trans_eq (by ring)
  calc
    _ ≤ ‖Matrix.trace (Gibbs.weight β (hamiltonian m j) * B)‖ := Complex.abs_re_le_norm _
    _ ≤ (2 : ℝ)^m * ‖CStarMatrix.ofMatrix (Gibbs.weight β (hamiltonian m j) * B)‖ :=
      norm_trace_le m _
    _ ≤ (2 : ℝ)^m *
        (‖CStarMatrix.ofMatrix (Gibbs.weight β (hamiltonian m j))‖ *
          ‖CStarMatrix.ofMatrix B‖) :=
      mul_le_mul_of_nonneg_left (norm_mul_le _ _) (by positivity)
    _ ≤ _ := by
      calc
        _ ≤ (2 : ℝ)^m * (Real.exp (|β| * (∑ I, |j I|) / 4) * ‖CStarMatrix.ofMatrix B‖) :=
          mul_le_mul_of_nonneg_left (mul_le_mul_of_nonneg_right hexp (norm_nonneg _)) (by positivity)
        _ = _ := by ring

/-- A line in disorder space has an affine absolute-sum bound. -/
theorem sum_abs_line_le (m : ℕ) (j w : FourSet m → ℝ) (x : ℝ) :
    (∑ I, |j I + x * w I|) ≤ (∑ I, |j I|) + |x| * ∑ I, |w I| := by
  calc
    _ ≤ ∑ I, (|j I| + |x| * |w I|) := by
      exact Finset.sum_le_sum (fun I _ => by simpa only [abs_mul] using abs_add_le (j I) (x * w I))
    _ = _ := by rw [Finset.sum_add_distrib, Finset.mul_sum]

/-- Continuity of the actual matrix insertion. -/
theorem continuous_thermalInsertion (m : ℕ) (β : ℝ)
    (B : Matrix (Basis m) (Basis m) ℂ) : Continuous (fun j => thermalInsertion m β j B) := by
  have hexp : Continuous (fun A : Matrix (Basis m) (Basis m) ℂ => NormedSpace.exp ℂ A) := by
    change Continuous (fun A : Matrix (Basis m) (Basis m) ℂ =>
      CStarMatrix.ofMatrixL.symm (NormedSpace.exp ℂ (CStarMatrix.ofMatrixL A)))
    exact CStarMatrix.ofMatrixL.symm.continuous.comp
      (NormedSpace.exp_continuous.comp CStarMatrix.ofMatrixL.continuous)
  unfold thermalInsertion Gibbs.weight
  apply Complex.continuous_re.comp
  apply Continuous.matrix_trace
  exact (hexp.comp (continuous_const.smul (continuous_hamiltonian m))).mul continuous_const

/-- Exponential bounds along a disorder line are Gaussian integrable. -/
theorem integrable_of_exp_abs_bound (v : ℝ≥0) {f : ℝ → ℝ}
    (hf : Continuous f) (C c : ℝ) (hbound : ∀ x, |f x| ≤ C * Real.exp (c * |x|)) :
    Integrable f (gaussianReal 0 v) := by
  apply ((GaussianDisorder.integrable_exp_abs v c).const_mul C).mono'
  · exact hf.aestronglyMeasurable
  · filter_upwards [] with x
    simpa only [Real.norm_eq_abs] using hbound x

/-- Multiplication by the Gaussian coordinate preserves an exponential bound's
integrability; no polynomial-moment assumption is left to the caller. -/
theorem integrable_id_mul_of_exp_abs_bound (v : ℝ≥0) {f : ℝ → ℝ}
    (hf : Continuous f) (C c : ℝ)
    (hbound : ∀ x, |f x| ≤ C * Real.exp (c * |x|)) :
    Integrable (fun x => x * f x) (gaussianReal 0 v) := by
  apply integrable_of_exp_abs_bound v (continuous_id.mul hf) C (c + 1)
  intro x
  have hx : |x| ≤ Real.exp |x| := by linarith [Real.add_one_le_exp |x|]
  calc
    _ = |x| * |f x| := abs_mul _ _
    _ ≤ Real.exp |x| * (C * Real.exp (c * |x|)) :=
      mul_le_mul hx (hbound x) (abs_nonneg _) (by positivity)
    _ = _ := by rw [add_mul, one_mul, Real.exp_add]; ring


/-- The exponential matrix majorant restricted to a coupling line. -/
theorem exp_line_le (m : ℕ) (β : ℝ) (j w : FourSet m → ℝ) (x : ℝ) :
    Real.exp (|β| * (∑ I, |j I + x * w I|) / 4) ≤
      Real.exp (|β| * (∑ I, |j I|) / 4) *
        Real.exp ((|β| * (∑ I, |w I|) / 4) * |x|) := by
  rw [← Real.exp_add]
  apply Real.exp_le_exp.mpr
  have h := mul_le_mul_of_nonneg_left (sum_abs_line_le m j w x) (abs_nonneg β)
  linarith

/-- A fully explicit Gaussian-integrable majorant for the actual partition function. -/
theorem abs_partition_line_le (m : ℕ) (β : ℝ) (j w : FourSet m → ℝ) (x : ℝ) :
    |(partitionFunction m β (fun I => j I + x * w I)).re| ≤
      ((2 : ℝ)^m * Real.exp (|β| * (∑ I, |j I|) / 4)) *
        Real.exp ((|β| * (∑ I, |w I|) / 4) * |x|) := by
  calc
    _ ≤ ‖partitionFunction m β (fun I => j I + x * w I)‖ := Complex.abs_re_le_norm _
    _ ≤ _ := (norm_partitionFunction_le m β _).trans <| by
      simpa only [mul_assoc] using
        mul_le_mul_of_nonneg_left (exp_line_le m β j w x) (show 0 ≤ (2 : ℝ)^m by positivity)

/-- Arbitrary fixed thermal insertions on a coupling line are genuinely Gaussian integrable. -/
theorem thermalInsertion_line_integrable (m : ℕ) (β : ℝ)
    (j w : FourSet m → ℝ) (B : Matrix (Basis m) (Basis m) ℂ) (v : ℝ≥0) :
    Integrable (fun x => thermalInsertion m β (fun I => j I + x * w I) B)
      (gaussianReal 0 v) := by
  apply integrable_of_exp_abs_bound v
    ((continuous_thermalInsertion m β B).comp (by fun_prop))
    ((2 : ℝ)^m * ‖CStarMatrix.ofMatrix B‖ * Real.exp (|β| * (∑ I, |j I|) / 4))
    (|β| * (∑ I, |w I|) / 4)
  intro x
  refine (abs_thermalInsertion_le m β _ B).trans ?_
  simpa only [mul_assoc] using mul_le_mul_of_nonneg_left
    (exp_line_le m β j w x) (show 0 ≤ (2 : ℝ)^m * ‖CStarMatrix.ofMatrix B‖ by positivity)

/-- The Stein formula includes zero variance, where the Gaussian is the point mass at zero. -/
theorem centered_stein_identity_all (v : ℝ≥0)
    (f f' : ℝ → ℝ) (hderiv : ∀ x, HasDerivAt f (f' x) x)
    (hf : Integrable f (gaussianReal 0 v))
    (hf' : Integrable f' (gaussianReal 0 v))
    (hxf : Integrable (fun x => x * f x) (gaussianReal 0 v)) :
    (∫ x, x * f x ∂gaussianReal 0 v) = (v : ℝ) * ∫ x, f' x ∂gaussianReal 0 v := by
  by_cases hv : v = 0
  · subst v
    simp
  · exact centered_stein_identity hv f f' hderiv hf hf' hxf

/-- Integration by parts for the concrete SYK partition function, with every
analytic hypothesis discharged. This is a one-coordinate identity under the
actual Gaussian law, valid also at zero coupling variance. -/
theorem syk_partition_stein (m : ℕ) (β : ℝ) (j w : FourSet m → ℝ) (v : ℝ≥0) :
    (∫ x, x * (partitionFunction m β (fun I => j I + x * w I)).re ∂gaussianReal 0 v) =
      (v : ℝ) * β * ∫ x, (∑ I, w I *
        thermalInsertion m β (fun I => j I + x * w I) (quartic m I)) ∂gaussianReal 0 v := by
  have hc : Continuous (fun x : ℝ => (partitionFunction m β (fun I => j I + x * w I)).re) :=
    continuous_iff_continuousAt.mpr (fun x => (hasDerivAt_syk_partition_direction_at m β j w x).continuousAt)
  have hf := integrable_of_exp_abs_bound v hc _ _ (abs_partition_line_le m β j w)
  have hxf := integrable_id_mul_of_exp_abs_bound v hc _ _ (abs_partition_line_le m β j w)
  have hd : Integrable (fun x => β * ∑ I, w I *
      thermalInsertion m β (fun I => j I + x * w I) (quartic m I)) (gaussianReal 0 v) := by
    apply Integrable.const_mul
    exact integrable_finset_sum _ (fun I _ => (thermalInsertion_line_integrable m β j w (quartic m I) v).const_mul (w I))
  have h := centered_stein_identity_all v _ _
    (hasDerivAt_syk_partition_direction_at m β j w) hf hd hxf
  simpa only [integral_const_mul, mul_assoc] using h

/-- The paper's exact disorder variance is 6λ/N³, with N=2m. -/
theorem syk_partition_stein_variance (m : ℕ) (β : ℝ) (j w : FourSet m → ℝ) (lam : ℝ≥0) :
    (∫ x, x * (partitionFunction m β (fun I => j I + x * w I)).re
      ∂gaussianReal 0 (GaussianDisorder.variance (2 * m) lam)) =
      (6 * (lam : ℝ) / (2 * m : ℝ)^3) * β *
        ∫ x, (∑ I, w I * thermalInsertion m β (fun I => j I + x * w I) (quartic m I))
          ∂gaussianReal 0 (GaussianDisorder.variance (2 * m) lam) := by
  simpa only [GaussianDisorder.variance, NNReal.coe_div, NNReal.coe_mul,
    NNReal.coe_pow, NNReal.coe_natCast, NNReal.coe_ofNat, Nat.cast_mul, Nat.cast_ofNat]
    using syk_partition_stein m β j w (GaussianDisorder.variance (2 * m) lam)

end SYK.GaussianIBP


