import SpectralRepresentation
import KernelSDAnalyticity
import PhysicalSelection
import Mathlib.Analysis.InnerProductSpace.StarOrder

/-!
# Spectral evaluation of the actual integral kernel equations

The spectral measure and representation are constructed by the checked GNS and
Riesz modules. This file evaluates genuine bounded Bochner kernels at their
characters and preserves the pointwise endpoint equations.
-/

noncomputable section
namespace SYK.KernelSelection

open MeasureTheory Set WeakDual
open SYK.GNS SYK.Spectral
open scoped Topology NNReal ComplexConjugate BigOperators

variable {A : Type*} [NormedCommRing A] [NormedAlgebra ℂ A] [NormOneClass A]
  [NormedSpace ℝ A] [IsScalarTower ℝ ℂ A] [CompleteSpace A]
  [StarRing A] [StarModule ℂ A] [NormedStarGroup A]
  (φ : PositiveFunctional A)

/-- Construct the positive state from its actual continuous limiting functional
and reflection positivity on a dense half-time observable family. Full-algebra
positivity is a conclusion, not an additional assumption. -/
def positiveFunctionalOfDense (L : A →L[ℂ] ℂ) (S : Set A) (hS : Dense S)
    (hreal : ∀ a ∈ S, (L (star a*a)).im = 0)
    (hpos : ∀ a ∈ S, 0 ≤ (L (star a*a)).re) : PositiveFunctional A where
  map := L
  diagonal_real a := by
    have hc : IsClosed {a : A | (L (star a*a)).im = 0} :=
      isClosed_eq (Complex.continuous_im.comp
        (L.continuous.comp (continuous_star.mul continuous_id))) continuous_const
    exact closure_minimal hreal hc (hS a)
  diagonal_nonneg := nonnegative_of_continuous_of_dense S hS _
    (Complex.continuous_re.comp (L.continuous.comp (continuous_star.mul continuous_id))) hpos

/-- The multiplicative algebra map underlying the continuous spectral evaluation. -/
def evaluationAlgHom (χ : Spectrum (C := representedClosure φ)) : A →ₐ[ℂ] ℂ :=
  (CharacterSpace.equivAlgHom χ).comp (representedElementAlgHom φ)

@[simp] theorem evaluationAlgHom_apply (χ : Spectrum (C := representedClosure φ)) (a : A) :
    evaluationAlgHom φ χ a = spectralEvaluation φ χ a := rfl

/-- Pointwise spectral evaluation is a bounded, jointly strongly measurable
kernel, even when the original coefficient algebra is nonseparable. -/
def spectralKernel (χ : Spectrum (C := representedClosure φ)) (G : KernelSpace A) : KernelSpace ℂ :=
  kernelOfFunction (fun p => spectralEvaluation φ χ (G p))
    ((spectralEvaluation φ χ).continuous.comp_stronglyMeasurable (KernelSpace.stronglyMeasurable G))
    ‖G‖ (fun p => (spectral_value_norm_le φ χ (G p)).trans (kernel_norm_apply_le G p))

@[simp] theorem spectralKernel_apply (χ : Spectrum (C := representedClosure φ))
    (G : KernelSpace A) (p : ℝ × ℝ) :
    spectralKernel φ χ G p = spectralEvaluation φ χ (G p) := rfl

/-- The entire kernel algebra, not just individual coordinates, is evaluated
by one algebra homomorphism. -/
def spectralKernelAlgHom (χ : Spectrum (C := representedClosure φ)) :
    KernelSpace A →ₐ[ℂ] KernelSpace ℂ where
  toFun := spectralKernel φ χ
  map_zero' := by ext p; exact (evaluationAlgHom φ χ).map_zero
  map_one' := by ext p; exact (evaluationAlgHom φ χ).map_one
  map_add' f g := by ext p; exact (evaluationAlgHom φ χ).map_add (f p) (g p)
  map_mul' f g := by ext p; exact (evaluationAlgHom φ χ).map_mul (f p) (g p)
  commutes' c := by ext p; exact (evaluationAlgHom φ χ).commutes c

@[simp] theorem spectralKernelAlgHom_apply (χ : Spectrum (C := representedClosure φ))
    (G : KernelSpace A) : spectralKernelAlgHom φ χ G = spectralKernel φ χ G := rfl

/-- Spectral evaluation commutes with the actual finite-interval Bochner
convolution by multiplicativity and bounded linear integral commutation. -/
theorem spectralKernel_convolution (χ : Spectrum (C := representedClosure φ))
    (β : ℝ) (hβ : 0 ≤ β) (f g : KernelSpace A) :
    spectralKernelAlgHom φ χ (kernelConvolution β hβ f g) =
      kernelConvolution β hβ (spectralKernelAlgHom φ χ f) (spectralKernelAlgHom φ χ g) := by
  ext p
  change spectralEvaluation φ χ (∫ u in (0 : ℝ)..β, f (p.1,u)*g (u,p.2)) =
    ∫ u in (0 : ℝ)..β, spectralEvaluation φ χ (f (p.1,u))*spectralEvaluation φ χ (g (u,p.2))
  have hi := (spectralEvaluation φ χ).intervalIntegral_comp_comm
    (kernelProduct_intervalIntegrable β f g p)
  rw [← hi]
  apply intervalIntegral.integral_congr
  intro u _
  exact (evaluationAlgHom φ χ).map_mul _ _

@[simp] theorem spectralKernel_free (χ : Spectrum (C := representedClosure φ)) (β : ℝ) :
    spectralKernelAlgHom φ χ (freeThermalKernel (A := A) β) = freeThermalKernel (A := ℂ) β := by
  ext p
  change evaluationAlgHom φ χ ((Thermal.kernel β p.1 p.2 : ℂ) • (1:A)) =
    (Thermal.kernel β p.1 p.2 : ℂ) • (1:ℂ)
  rw [map_smul, map_one]

/-- The translation and reflection data supplied by the actual quotient
construction and invariant limiting state. Stationarity is not an input. -/
structure KernelActionData (β : ℝ) (G : KernelSpace A) where
  translation : ℝ → A ≃ₐ[ℂ] A
  zero : ∀ a, translation 0 a = a
  add : ∀ u v a, translation (u+v) a = translation u (translation v a)
  invariant : ∀ u a, φ.map (translation u a) = φ.map a
  reversal : ∀ u a, star (translation u a) = translation (-u) (star a)
  isometric : ∀ u a, ‖translation u a‖ = ‖a‖
  coordinate : ∀ u s t, translation u (G (s,t)) = G (s+u,t+u)
  reflected : ∀ s t, star (G (s,t)) = G (β-t,β-s)

variable {φ}

/-- Every spectral kernel is stationary at every character and endpoint.
There is no uncountable intersection of almost-everywhere events. -/
theorem spectralKernel_stationary {β : ℝ} {G : KernelSpace A}
    (D : KernelActionData φ β G) (χ : Spectrum (C := representedClosure φ)) (s t u : ℝ) :
    spectralKernel φ χ G (s+u,t+u) = spectralKernel φ χ G (s,t) := by
  change spectralEvaluation φ χ (G (s+u,t+u)) = spectralEvaluation φ χ (G (s,t))
  rw [← D.coordinate]
  exact spectral_value_stationary φ D.translation D.zero D.add D.invariant D.reversal D.isometric χ u (G (s,t))

/-- Reflection and the proved represented stationarity make every spectral
coordinate real, pointwise on the full character space. -/
theorem spectralKernel_real {β : ℝ} {G : KernelSpace A}
    (D : KernelActionData φ β G) (χ : Spectrum (C := representedClosure φ)) (s t : ℝ) :
    (spectralKernel φ χ G (s,t)).im = 0 := by
  apply spectral_value_real_of_reflected_translate φ D.translation D.zero D.add
    D.invariant D.reversal D.isometric χ (β-s-t) (G (s,t))
  rw [D.reflected, D.coordinate]
  rw [show s+(β-s-t) = β-t by ring, show t+(β-s-t) = β-s by ring]

/-- The real stationary kernel at one spectral point. -/
def selectedKernel (χ : Spectrum (C := representedClosure φ)) (G : KernelSpace A) (t : ℝ) : ℝ :=
  (spectralKernel φ χ G (t,0)).re

/-- The stationary scalar function represents every endpoint value exactly. -/
theorem spectralKernel_eq_selected {β : ℝ} {G : KernelSpace A}
    (D : KernelActionData φ β G) (χ : Spectrum (C := representedClosure φ)) (s t : ℝ) :
    spectralKernel φ χ G (s,t) = (selectedKernel χ G (s-t) : ℂ) := by
  have he := spectralKernel_stationary D χ s t (-t)
  simp only [add_neg_cancel, ← sub_eq_add_neg] at he
  rw [← he]
  apply Complex.ext
  · rfl
  · exact spectralKernel_real D χ (s-t) 0

/-- The selected real function is genuinely measurable. -/
theorem selectedKernel_measurable (χ : Spectrum (C := representedClosure φ)) (G : KernelSpace A) :
    Measurable (selectedKernel χ G) :=
  Complex.continuous_re.measurable.comp
    (((KernelSpace.stronglyMeasurable (spectralKernel φ χ G)).comp_measurable
      (measurable_id.prodMk measurable_const)).measurable)

/-- The Banach-algebra coordinate bound passes to every character. -/
theorem selectedKernel_bound (χ : Spectrum (C := representedClosure φ)) (G : KernelSpace A) (t : ℝ) :
    |selectedKernel χ G t| ≤ ‖G‖ :=
  (Complex.abs_re_le_norm _).trans
    ((spectral_value_norm_le φ χ (G (t,0))).trans (kernel_norm_apply_le G (t,0)))

theorem selectedKernel_antiperiodic {β : ℝ} {G : KernelSpace A}
    (hG : KernelAntiperiodic β G) (χ : Spectrum (C := representedClosure φ)) (t : ℝ) :
    selectedKernel χ G (t+β) = -selectedKernel χ G t := by
  change (spectralEvaluation φ χ (G (t+β,0))).re = -(spectralEvaluation φ χ (G (t,0))).re
  rw [hG.1, map_neg, Complex.neg_re]

theorem selectedKernel_zero {G : KernelSpace A} (hG : G (0,0) = 0)
    (χ : Spectrum (C := representedClosure φ)) : selectedKernel χ G 0 = 0 := by
  change (spectralEvaluation φ χ (G (0,0))).re = 0
  rw [hG, map_zero, Complex.zero_re]

theorem selectedKernel_reflection {β : ℝ} {G : KernelSpace A}
    (D : KernelActionData φ β G) (hanti : KernelAntiperiodic β G)
    (hskew : ∀ s t, G (t,s) = -G (s,t))
    (χ : Spectrum (C := representedClosure φ)) (t : ℝ) :
    selectedKernel χ G (β-t) = selectedKernel χ G t := by
  change (spectralEvaluation φ χ (G (β-t,0))).re = (spectralEvaluation φ χ (G (t,0))).re
  rw [show β-t = -t+β by ring, hanti.1, map_neg, Complex.neg_re]
  have hs := spectralKernel_stationary D χ (-t) 0 t
  simp only [neg_add_cancel, zero_add, spectralKernel_apply] at hs
  rw [← hs, hskew t 0, map_neg, Complex.neg_re, neg_neg]

/-- The actual norm-integral SD equation survives evaluation at every
spectral point, with its prescribed parenthesization unchanged. -/
theorem spectralKernel_sd {β : ℝ} (hβ : 0 ≤ β) (lam : ℂ) (G : KernelSpace A)
    (hSD : G-freeThermalKernel β = lam • kernelConvolution β hβ
      (kernelConvolution β hβ (freeThermalKernel β) (G^3)) G)
    (χ : Spectrum (C := representedClosure φ)) :
    spectralKernel φ χ G-freeThermalKernel β = lam • kernelConvolution β hβ
      (kernelConvolution β hβ (freeThermalKernel β) ((spectralKernel φ χ G)^3))
      (spectralKernel φ χ G) := by
  have he := congrArg (spectralKernelAlgHom φ χ) hSD
  simp only [map_sub, map_smul, map_pow, spectralKernel_convolution, spectralKernel_free] at he
  exact he


/-- Every spectral point satisfies the manuscript's real scalar integrated SD
equation. The proof evaluates the norm identity, preserves convolution, then
uses the pointwise real stationary representation. -/
theorem selectedKernel_sd {β : ℝ} (hβ : 0 ≤ β) (lam : ℝ≥0) (G : KernelSpace A)
    (D : KernelActionData φ β G)
    (hSD : G-freeThermalKernel β = (lam:ℂ) • kernelConvolution β hβ
      (kernelConvolution β hβ (freeThermalKernel β) (G^3)) G)
    (χ : Spectrum (C := representedClosure φ)) :
    SYK.Continuum.SDEquation β lam (selectedKernel χ G) := by
  intro s t
  have he := congrArg (fun f : KernelSpace ℂ => f (s,t)) (spectralKernel_sd hβ (lam:ℂ) G hSD χ)
  simp only [kernel_sub_apply, kernel_smul_apply, kernelConvolution_apply,
    freeThermalKernel_apply, kernel_pow_apply, smul_eq_mul, mul_one] at he
  simp_rw [spectralKernel_eq_selected D χ] at he
  simp_rw [← Complex.ofReal_pow, ← Complex.ofReal_mul, intervalIntegral.integral_ofReal] at he
  simp_rw [← Complex.ofReal_mul, intervalIntegral.integral_ofReal] at he
  have hr := congrArg Complex.re he
  simp only [Complex.sub_re, Complex.ofReal_re, Complex.mul_re, Complex.ofReal_im,
    mul_zero, zero_mul, sub_zero] at hr
  change selectedKernel χ G (s-t) = Thermal.kernel β s t + (lam:ℝ) *
    (∫ u in (0:ℝ)..β, (∫ v in (0:ℝ)..β,
      Thermal.kernel β s v * (selectedKernel χ G (v-u))^3) * selectedKernel χ G (u-t))
  exact (sub_eq_iff_eq_add').mp hr


/-- Inserted positivity on a dense observable family extends to all algebra
vectors by continuity; this is used after proved half-algebra generation. -/
theorem inserted_nonnegative_of_dense
    (S : Set A) (hS : Dense S) (H : A)
    (hpos : ∀ q ∈ S, 0 ≤ (φ.map (star q*q*H)).re) :
    ∀ q, 0 ≤ (φ.map (star q*q*H)).re := by
  apply nonnegative_of_continuous_of_dense S hS _ _ hpos
  exact Complex.continuous_re.comp
    (φ.map.continuous.comp ((continuous_star.mul continuous_id).mul continuous_const))

/-- Positivity of all inserted quadratic forms makes the represented operator
positive on the entire completed GNS space, using its dense algebra vectors. -/
theorem representation_positive_of_inserted (H : A) (hself : star H = H)
    (hpos : ∀ q, 0 ≤ (φ.map (star q*q*H)).re) :
    (SYK.GNS.GNSHilbert.representation φ H).IsPositive := by
  refine ⟨?_, ?_⟩
  · change star (SYK.GNS.GNSHilbert.representation φ H) =
      SYK.GNS.GNSHilbert.representation φ H
    rw [← SYK.GNS.GNSHilbert.representation_star, hself]
  · intro x
    have hc : Continuous (fun x : GNSHilbert φ =>
        (inner (𝕜 := ℂ) x (SYK.GNS.GNSHilbert.representation φ H x)).re) :=
      Complex.continuous_re.comp
        (continuous_id.inner (SYK.GNS.GNSHilbert.representation φ H).continuous)
    have hp : ∀ x : GNSHilbert φ, 0 ≤
        (inner (𝕜 := ℂ) x (SYK.GNS.GNSHilbert.representation φ H x)).re := by
      intro x
      refine (SYK.GNS.GNSHilbert.denseRange_ofAlgebra φ).induction_on x
        (isClosed_Ici.preimage hc) ?_
      intro q
      simp only [SYK.GNS.GNSHilbert.representation_ofAlgebra,
        SYK.GNS.GNSHilbert.inner_ofAlgebra]
      simpa only [mul_assoc, mul_comm H q] using hpos q
    change 0 ≤ RCLike.re (inner (𝕜 := ℂ) (SYK.GNS.GNSHilbert.representation φ H x) x)
    rw [inner_re_symm]
    exact hp x

/-- Every character is nonnegative on an observable whose inserted quadratic
forms are positive. Spectral permanence transfers operator positivity into
the represented commutative C*-algebra without an a.e. exceptional set. -/
theorem spectral_nonnegative_of_inserted (H : A) (hself : star H = H)
    (hpos : ∀ q, 0 ≤ (φ.map (star q*q*H)).re)
    (χ : Spectrum (C := representedClosure φ)) :
    0 ≤ (spectralEvaluation φ χ H).re := by
  have hp := representation_positive_of_inserted H hself hpos
  have hmem : spectralEvaluation φ χ H ∈ spectrum ℂ
      (SYK.GNS.GNSHilbert.representation φ H) := by
    have hm := AlgHom.apply_mem_spectrum χ (representedElement φ H)
    rwa [(representedClosure φ).spectrum_eq] at hm
  have hreal := hp.isSelfAdjoint.mem_spectrum_eq_re hmem
  have hmreal : (spectralEvaluation φ χ H).re ∈ spectrum ℝ
      (SYK.GNS.GNSHilbert.representation φ H) := by
    apply (spectrum.algebraMap_mem_iff ℂ).mp
    change ((spectralEvaluation φ χ H).re : ℂ) ∈ spectrum ℂ
      (SYK.GNS.GNSHilbert.representation φ H)
    rwa [← hreal]
  exact SpectrumRestricts.nnreal_iff.mp hp.spectrumRestricts _ hmreal

/-- The finite odd reflection observable appearing in the inserted RP tests. -/
def hankelObservable (β : ℝ) (G : KernelSpace A) {k : ℕ}
    (x : Fin k → ℝ) (c : Fin k → ℂ) : A :=
  ∑ i, ∑ j, (conj (c i)*c j) • G (β-x i,x j)

/-- Reflection makes each finite odd Gram observable self-adjoint in the
original algebra, before passing to any spectral point. -/
theorem hankelObservable_selfadjoint {β : ℝ} {G : KernelSpace A}
    (D : KernelActionData φ β G) {k : ℕ} (x : Fin k → ℝ) (c : Fin k → ℂ) :
    star (hankelObservable β G x c) = hankelObservable β G x c := by
  classical
  simp only [hankelObservable, star_sum, star_smul, D.reflected, sub_sub_cancel]
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro i _
  apply Finset.sum_congr rfl
  intro j _
  congr 1
  simp only [star_mul, Complex.star_def, map_mul, starRingEnd_self_apply]

/-- Spectral evaluation turns the odd reflection observable into the usual
real stationary Hankel Gram sum, pointwise at every character. -/
theorem spectral_hankelObservable {β : ℝ} {G : KernelSpace A}
    (D : KernelActionData φ β G) (hanti : KernelAntiperiodic β G)
    (hskew : ∀ s t, G (t,s) = -G (s,t))
    (χ : Spectrum (C := representedClosure φ)) {k : ℕ} (x : Fin k → ℝ) (c : Fin k → ℂ) :
    spectralEvaluation φ χ (hankelObservable β G x c) =
      ∑ i, ∑ j, conj (c i)*c j*(selectedKernel χ G (x i+x j) : ℂ) := by
  classical
  simp only [hankelObservable, map_sum, map_smul, smul_eq_mul]
  apply Finset.sum_congr rfl
  intro i _
  apply Finset.sum_congr rfl
  intro j _
  rw [← spectralKernel_apply, spectralKernel_eq_selected D χ,
    show (β-x i)-x j = β-(x i+x j) by ring,
    selectedKernel_reflection D hanti hskew]

/-- Inserted odd positivity on a dense half-time test family implies finite
Hankel Gram positivity for every scalar spectral kernel. -/
theorem selectedKernel_hankel_nonnegative {β : ℝ} {G : KernelSpace A}
    (D : KernelActionData φ β G) (hanti : KernelAntiperiodic β G)
    (hskew : ∀ s t, G (t,s) = -G (s,t))
    (S : Set A) (hS : Dense S)
    (hodd : ∀ (k : ℕ) (x : Fin k → Ioo (0:ℝ) (β/2)) (c : Fin k → ℂ) q,
      q ∈ S → 0 ≤ (φ.map (star q*q*hankelObservable β G (fun i => x i) c)).re)
    (χ : Spectrum (C := representedClosure φ))
    (k : ℕ) (x : Fin k → Ioo (0:ℝ) (β/2)) (c : Fin k → ℂ) :
    0 ≤ (∑ i, ∑ j, conj (c i)*c j*(selectedKernel χ G ((x i:ℝ)+(x j:ℝ)) : ℂ)).re := by
  have hp := inserted_nonnegative_of_dense S hS
    (hankelObservable β G (fun i => x i) c) (hodd k x c)
  have hh := spectral_nonnegative_of_inserted _
    (hankelObservable_selfadjoint D (fun i => (x i:ℝ)) c) hp χ
  rwa [spectral_hankelObservable D hanti hskew] at hh

/-- Every constructed spectral kernel belongs to the actual physical SD
class, with strict positive fermionic Fourier signs proved by Hankel positivity
and the scalar Dyson equation. No physical-solution hypothesis is assumed. -/
theorem selectedKernel_physical {β : ℝ} (hβ : 0 < β) (lam : ℝ≥0) (G : KernelSpace A)
    (D : KernelActionData φ β G) (hanti : KernelAntiperiodic β G)
    (hskew : ∀ s t, G (t,s) = -G (s,t)) (hzero : G (0,0) = 0)
    (hSD : G-freeThermalKernel β = (lam:ℂ) • kernelConvolution β hβ.le
      (kernelConvolution β hβ.le (freeThermalKernel β) (G^3)) G)
    (S : Set A) (hS : Dense S)
    (hodd : ∀ (k : ℕ) (x : Fin k → Ioo (0:ℝ) (β/2)) (c : Fin k → ℂ) q,
      q ∈ S → 0 ≤ (φ.map (star q*q*hankelObservable β G (fun i => x i) c)).re)
    (χ : Spectrum (C := representedClosure φ)) :
    SYK.Continuum.PhysicalSolution β lam (selectedKernel χ G) :=
  SYK.Continuum.physical_of_hankel_sd β hβ lam _
    (selectedKernel_measurable χ G) ‖G‖ (selectedKernel_bound χ G)
    (selectedKernel_antiperiodic hanti χ) (selectedKernel_zero hzero χ)
    (selectedKernel_reflection D hanti hskew χ) (selectedKernel_sd hβ.le lam G D hSD χ)
    (selectedKernel_hankel_nonnegative D hanti hskew S hS hodd χ)

/-- Physical uniqueness collapses all spectral kernels pointwise, before
integrating over the representing measure. -/
theorem selectedKernel_eq {β : ℝ} (hβ : 0 < β) (lam : ℝ≥0) (G : KernelSpace A)
    (D : KernelActionData φ β G) (hanti : KernelAntiperiodic β G)
    (hskew : ∀ s t, G (t,s) = -G (s,t)) (hzero : G (0,0) = 0)
    (hSD : G-freeThermalKernel β = (lam:ℂ) • kernelConvolution β hβ.le
      (kernelConvolution β hβ.le (freeThermalKernel β) (G^3)) G)
    (S : Set A) (hS : Dense S)
    (hodd : ∀ (k : ℕ) (x : Fin k → Ioo (0:ℝ) (β/2)) (c : Fin k → ℂ) q,
      q ∈ S → 0 ≤ (φ.map (star q*q*hankelObservable β G (fun i => x i) c)).re)
    (χ ψ : Spectrum (C := representedClosure φ)) :
    selectedKernel χ G = selectedKernel ψ G := by
  letI : Fact (0 < β) := ⟨hβ⟩
  exact SYK.Continuum.physical_unique β lam _ _
    (selectedKernel_physical hβ lam G D hanti hskew hzero hSD S hS hodd χ)
    (selectedKernel_physical hβ lam G D hanti hskew hzero hSD S hS hodd ψ)

/-- The constructed spectral probability space is nonempty whenever the
original state is normalized. -/
theorem spectral_nonempty (hunit : φ.map 1 = 1) :
    Nonempty (Spectrum (C := representedClosure φ)) := by
  letI := gnsSpectralMeasure_isProbability φ hunit
  by_contra hn
  have he : (Set.univ : Set (Spectrum (C := representedClosure φ))) = ∅ := by
    apply Set.eq_empty_iff_forall_not_mem.mpr
    intro χ _
    exact hn ⟨χ⟩
  have hm := measure_univ (μ := gnsSpectralMeasure φ)
  rw [he, measure_empty] at hm
  exact zero_ne_one hm

/-- The actual limiting state factorizes on every finite product of bilocal
coordinates. This follows by integrating the now constant spectral product,
not by assuming concentration of the representing measure. -/
theorem coordinate_product_factorization {β : ℝ} (hβ : 0 < β) (lam : ℝ≥0) (G : KernelSpace A)
    (D : KernelActionData φ β G) (hanti : KernelAntiperiodic β G)
    (hskew : ∀ s t, G (t,s) = -G (s,t)) (hzero : G (0,0) = 0)
    (hSD : G-freeThermalKernel β = (lam:ℂ) • kernelConvolution β hβ.le
      (kernelConvolution β hβ.le (freeThermalKernel β) (G^3)) G)
    (S : Set A) (hS : Dense S)
    (hodd : ∀ (k : ℕ) (x : Fin k → Ioo (0:ℝ) (β/2)) (c : Fin k → ℂ) q,
      q ∈ S → 0 ≤ (φ.map (star q*q*hankelObservable β G (fun i => x i) c)).re)
    (hunit : φ.map 1 = 1) (χ₀ : Spectrum (C := representedClosure φ))
    (k : ℕ) (p : Fin k → ℝ × ℝ) :
    φ.map (∏ i, G (p i)) = ∏ i, (selectedKernel χ₀ G ((p i).1-(p i).2) : ℂ) := by
  classical
  letI := gnsSpectralMeasure_isProbability φ hunit
  have hconst : ∀ χ : Spectrum (C := representedClosure φ),
      spectralEvaluation φ χ (∏ i, G (p i)) =
        ∏ i, (selectedKernel χ₀ G ((p i).1-(p i).2) : ℂ) := by
    intro χ
    change evaluationAlgHom φ χ (∏ i, G (p i)) = _
    rw [map_prod]
    apply Finset.prod_congr rfl
    intro i _
    change spectralKernel φ χ G ((p i).1,(p i).2) = _
    rw [spectralKernel_eq_selected D χ,
      selectedKernel_eq hβ lam G D hanti hskew hzero hSD S hS hodd χ χ₀]
  rw [gns_spectral_integral φ hunit]
  change (∫ χ, spectralEvaluation φ χ (∏ i, G (p i)) ∂gnsSpectralMeasure φ) = _
  simp_rw [hconst]
  simp

/-- Existence, physical selection, and full bilocal product factorization for
an actual normalized positive state satisfying the symmetry and inserted odd
RP data. All spectral points are handled simultaneously. -/
theorem exists_physical_factorization {β : ℝ} (hβ : 0 < β) (lam : ℝ≥0) (G : KernelSpace A)
    (D : KernelActionData φ β G) (hanti : KernelAntiperiodic β G)
    (hskew : ∀ s t, G (t,s) = -G (s,t)) (hzero : G (0,0) = 0)
    (hSD : G-freeThermalKernel β = (lam:ℂ) • kernelConvolution β hβ.le
      (kernelConvolution β hβ.le (freeThermalKernel β) (G^3)) G)
    (S : Set A) (hS : Dense S)
    (hodd : ∀ (k : ℕ) (x : Fin k → Ioo (0:ℝ) (β/2)) (c : Fin k → ℂ) q,
      q ∈ S → 0 ≤ (φ.map (star q*q*hankelObservable β G (fun i => x i) c)).re)
    (hunit : φ.map 1 = 1) :
    ∃ g : ℝ → ℝ, SYK.Continuum.PhysicalSolution β lam g ∧
      ∀ (k : ℕ) (p : Fin k → ℝ × ℝ), φ.map (∏ i, G (p i)) =
        ∏ i, (g ((p i).1-(p i).2) : ℂ) := by
  obtain ⟨χ⟩ := spectral_nonempty hunit
  refine ⟨selectedKernel χ G,
    selectedKernel_physical hβ lam G D hanti hskew hzero hSD S hS hodd χ, ?_⟩
  exact coordinate_product_factorization hβ lam G D hanti hskew hzero hSD S hS hodd hunit χ

end SYK.KernelSelection
