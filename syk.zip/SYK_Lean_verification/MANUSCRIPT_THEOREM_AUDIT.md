# Main theorem: conclusion-level audit

This audits `thm:main` in the exact supplied manuscript, preserved at
`reference/SYK_continuum_free_energy.tex`, lines 269–314, and its following
collective-moment convergence addendum. The unconditional entry point is
`SYK.SYKMainTheorem.continuum_free_energy`.

Its exact inputs are β : ℝ and 0 < β. It concludes existence of one family
`g : ℝ≥0 → ℝ → ℝ` satisfying `ContinuumSYKMain.MainConclusion β g`.
No finite Ward, Wick representation, positivity, compactness, physical-family
existence, pressure-convergence or determinant premise remains in that type.
The conclusion structures and their definition dependencies have been printed
and inspected. `AuditAll.lean` checks their complete logical dependency graph.

## Target conclusions and actual endpoints

| Manuscript conclusion | Checked endpoint |
|---|---|
| Physical solution for every β > 0, λ ≥ 0 | `continuum_free_energy` constructs one family; `MainConclusion.solution.physical` is the actual measurable, bounded, real canonical SD solution with antiperiodicity, reflection and positive-imaginary positive-frequency Fourier coefficients |
| Uniqueness in the full bounded physical class | `PhysicalUniqueness.physical_unique` derives actual Fourier Dyson, Parseval and pointwise injectivity; `existsUnique_physical_solution` supplies existence and uniqueness unconditionally |
| Sharp bound | `MainConclusion.solution.sharp_bound` gives |g(t)| ≤ 1/2 at every real point, inherited from actual finite-N moment bounds |
| Exact midpoint and endpoint values | `PhysicalConclusion.midpoint` covers every integer lift kβ; `right_endpoint` and `left_endpoint` give the one-sided values 1/2 |
| Lipschitz G − C | `PhysicalConclusion.centered_lipschitz` and `bilocal_lipschitz` derive the scalar and actual two-endpoint bounds from SD |
| Both actual pressures converge along even N | `MainConclusion.pressure` unfolds to convergence of the actual Gaussian `Microscopic.annealedPressure` and `quenchedPressure` at N = 2d, to the literal coupling integral |
| Original J and free energy | `MainConclusion.at_real_coupling` gives λ = J² and both actual free-energy limits with exactly −1/β |
| Positive ordinary Fredholm determinant and action | `MainConclusion.fredholm` and `ordinary_action` use the actual complex L² operator, its summable rank-one expansion, compact selfadjoint spectrum with algebraic multiplicities and intrinsic positive ordinary spectral determinant |
| Literal complex integral-operator interpretation | `operator_complex_integral_action` and `operator_unique` prove the nested Lebesgue CΣ action on all bounded complex tests and uniquely identify its continuous extension to the entire Hilbert space |
| Every fixed collective polynomial moment, including coincidences | `MainConclusion.moments` and `ActualMomentLimits.polynomial` prove full actual convergence, not only a selected subsequence; the raw fundamental-domain moments and the corrected canonical all-real lifts are explicitly distinguished |
| Independence of the matrix realization | `RepresentationIndependence` and `MomentRepresentationIndependence` prove identical actual partition functions, pressures and all interacting Weyl/flavor moments from CAR and dimension alone, without assuming unitary equivalence |

The combined endpoint `SYK.SYKMainTheorem.continuum_free_energy_abstract`
also gives actual pressures, free energies and coincident moments for arbitrary
finite-dimensional complex normed spaces, hence every Hilbert realization in
the manuscript. `AbstractRepresentationTransport` and `AbstractMomentTransport`
use ordinary `LinearMap.trace`, genuine operator exponentials and a proved
finite-basis algebra equivalence. No coordinate or unitary-equivalence premise
is supplied.

## Discharge of the formerly conditional model inputs

The decisive finite microscopic endpoints are:

1. `ActualWickCorrespondence.normalizedMoment_eq_collectiveMoment`: the genuine
   convergent continuum exterior numerator/denominator ratio equals the actual
   Gaussian-averaged thermal Weyl/flavor moment for every endpoint list,
   including repeated labels and equal-time blocks.
2. `IntegratedWickWard.numerator_ward`: exact summed inserted Ward identity,
   including the finite contact terms, derived from the actual contraction and
   convergent coefficient integrals.
3. `ActualMicroscopicIdentities.exact_left_ward` and `finite_ward_control`:
   the actual corrected polynomial residual and its quantitative contact bound.
4. `ActualMicroscopicIdentities.quartic_response`: the actual finite annealed
   pressure derivative is the required fourth-moment integral.
5. `WeylTranslation` and the even/odd polynomial reflection modules: actual
   finite-N translation symmetry and reflection positivity, including every
   fermionic sign, winding seam and tied-time antisymmetrization.

These instantiate the compactness, limiting-state, quotient, GNS, spectral
selection and dominated-pressure machinery. Intermediate theorems keep their
ordinary assumptions visible; their mere axiom cleanliness is not used as a
substitute for proving those assumptions.

## Exact model and convention checks

- N = 2d Majoranas, matrix dimension 2^d, CAR normalization χᵢ² = 1/2.
- Independent centered Gaussians indexed by increasing four-sets, variance
  6λ/N³, actual ordinary exponential trace and pressure normalization 1/N.
- Positive-exponential Fourier transform on the thermal interval.
- Canonical midpoint value zero, genuine jump limits 1/2, signed antiperiodic
  extension and exact coincident-time Weyl convention.
- The raw closed-cube seam modulus is not assumed: the signed half-open
  representative and corrected midpoint-consistent family are constructed.
- λ = J², free pressure (log 2)/2, and free energy −p/β.
- The relative operator is I − CΣ, with Σ = λg³; the constructed perturbation
  is −CΣ, and the determinant is ordinary rather than regularized.

## Scope limits and proof adaptations

This is a verification of the main free-energy theorem and the stated moment
convergence result, not a declaration that every proposition or remark in the
paper is formalized verbatim. In particular:

- The proved finite pressure gap is the nonsharp
  3π²β²λ/(128d), sufficient for the required O(1/N) vanishing gap. The paper's
  sharper finite-N constant is not claimed.
- Separate probability/almost-sure convergence remarks and the full all-L²
  maximization assertion are not asserted. The proved physical-source envelope
  suffices for the main determinant action.
- The ordinary Fredholm construction is justified for the actual compact
  selfadjoint trace-class target. It does not create a general API for arbitrary
  nonnormal trace-class operators.
- No uniformity for β depending on N, 1/N expansion or dominating contour is
  asserted, in agreement with the main theorem's stated limits.

See `PROOF_GUIDE.md` for the detailed mathematical adaptations.

## Trust and reproducibility

Every checked safe logical declaration, including private/generated ones,
may depend only on `propext`, `Classical.choice` and `Quot.sound`. Additional
axioms, proof placeholders, authored unsafe declarations and native proof
shortcuts are rejected. Unsafe compiler execution artifacts are individually
listed by Lean metadata and cannot be logical proof dependencies. The original
manuscript hash, official Lean toolchain and all dependency revisions are pinned.
The exact final clean build and audits are recorded in `VERIFICATION.md`.
