import RelativeLogSeries
import Mathlib.Analysis.InnerProductSpace.l2Space
import Mathlib.Analysis.InnerProductSpace.Adjoint
import Mathlib.Analysis.NormedSpace.OperatorNorm.Bilinear
import Mathlib.LinearAlgebra.Matrix.Determinant.Basic

/-!
# Actual diagonal Hilbert operators and determinant approximants

This file constructs an operator on genuine ℓ², not merely a scalar product.
The target is its absolutely summable rank-one expansion and actual finite
coordinate-compression determinants. A general, basis-free Fredholm determinant
API is not present in the pinned library and is not assumed here.
-/
noncomputable section
open Filter
open scoped BigOperators Topology
namespace SYK.DiagonalFredholm

variable {ι : Type*} [DecidableEq ι]
abbrev H := lp (fun _ : ι => ℂ) 2

/-- Bounded coordinate evaluation on the actual Hilbert space ℓ². -/
def evaluation (i : ι) : H (ι := ι) →L[ℂ] ℂ :=
  LinearMap.mkContinuous
    { toFun := fun x => x i
      map_add' := fun _ _ => rfl
      map_smul' := fun _ _ => rfl }
    1 (fun x => by simpa only [one_mul] using
      lp.norm_apply_le_norm (by norm_num : (2 : ENNReal) ≠ 0) x i)

@[simp] theorem evaluation_apply (i : ι) (x : H (ι := ι)) : evaluation i x = x i := rfl

theorem norm_evaluation_le (i : ι) : ‖evaluation i‖ ≤ 1 := by
  apply ContinuousLinearMap.opNorm_le_bound (evaluation i) (by norm_num)
  intro x
  simpa only [evaluation_apply, one_mul] using
    lp.norm_apply_le_norm (by norm_num : (2 : ENNReal) ≠ 0) x i

/-- Rank-one coordinate projection. -/
def projection (i : ι) : H (ι := ι) →L[ℂ] H (ι := ι) :=
  (lp.singleContinuousLinearMap ℂ (fun _ : ι => ℂ) 2 i).comp (evaluation i)

@[simp] theorem projection_apply (i : ι) (x : H (ι := ι)) :
    projection i x = lp.single 2 i (x i) := rfl

theorem norm_projection_le (i : ι) : ‖projection i‖ ≤ 1 := by
  apply ContinuousLinearMap.opNorm_le_bound (projection i) (by norm_num)
  intro x
  rw [projection_apply, lp.norm_single (by norm_num : (0 : ENNReal) < 2), one_mul]
  exact lp.norm_apply_le_norm (by norm_num : (2 : ENNReal) ≠ 0) x i

/-- The genuine bounded operator, defined by an operator-norm-convergent series. -/
def diagonal (a : ι → ℝ) : H (ι := ι) →L[ℂ] H (ι := ι) :=
  ∑' i, (a i : ℂ) • projection i

theorem summable_rankOne_norms (a : ι → ℝ) (ha : Summable (fun i => |a i|)) :
    Summable (fun i => ‖(a i : ℂ) • projection i‖) := by
  apply Summable.of_nonneg_of_le (fun i => norm_nonneg _) _ ha
  intro i
  rw [norm_smul (a i : ℂ) (projection i), Complex.norm_real, Real.norm_eq_abs]
  exact mul_le_of_le_one_right (abs_nonneg _) (norm_projection_le i)

theorem summable_rankOne (a : ι → ℝ) (ha : Summable (fun i => |a i|)) :
    Summable (fun i => (a i : ℂ) • projection i) :=
  (summable_rankOne_norms a ha).of_norm

/-- Action of the constructed operator at every coordinate. -/
theorem diagonal_apply (a : ι → ℝ) (ha : Summable (fun i => |a i|))
    (x : H (ι := ι)) (j : ι) : diagonal a x j = (a j : ℂ) * x j := by
  have hs := summable_rankOne a ha
  have he := ((evaluation j).comp (ContinuousLinearMap.apply ℂ (H (ι := ι)) x)).map_tsum hs
  change diagonal a x j = ∑' i, ((a i : ℂ) • projection i) x j at he
  rw [he, tsum_eq_single j]
  · simp [projection, lp.single_apply]
  · intro i hij
    simp [projection, lp.single_apply, hij, Ne.symm hij]

/-- Finite rank-one approximants converge in operator norm. -/
theorem finiteRank_tendsto (a : ι → ℝ) (ha : Summable (fun i => |a i|)) :
    Tendsto (fun s : Finset ι => ∑ i ∈ s, (a i : ℂ) • projection i)
      atTop (𝓝 (diagonal a)) := (summable_rankOne a ha).hasSum

/-- A genuine summable rank-one expansion, the nuclear characterization of
trace-class operators on a Hilbert space. This is data about an actual operator. -/
structure NuclearExpansion (T : H (ι := ι) →L[ℂ] H (ι := ι)) where
  vector : ι → H (ι := ι)
  functional : ι → H (ι := ι) →L[ℂ] ℂ
  summable_cost : Summable (fun i => ‖functional i‖ * ‖vector i‖)
  hasSum : HasSum (fun i => (functional i).smulRight (vector i)) T

def nuclearVector (a : ι → ℝ) (i : ι) : H (ι := ι) :=
  (a i : ℂ) • lp.single 2 i 1

theorem nuclear_rankOne_eq (a : ι → ℝ) (i : ι) :
    (evaluation i).smulRight (nuclearVector a i) = (a i : ℂ) • projection i := by
  apply ContinuousLinearMap.ext
  intro x
  rw [ContinuousLinearMap.smulRight_apply, ContinuousLinearMap.smul_apply,
    projection_apply, evaluation_apply]
  dsimp [nuclearVector]
  rw [smul_comm, ← lp.single_smul]
  simp

/-- Construct the nuclear certificate; no trace-class hypothesis is assumed. -/
def diagonalNuclearExpansion (a : ι → ℝ) (ha : Summable (fun i => |a i|)) :
    NuclearExpansion (diagonal a) where
  vector := nuclearVector a
  functional := evaluation
  summable_cost := by
    have he (i : ι) : ‖evaluation i‖ * ‖nuclearVector a i‖ =
        ‖(a i : ℂ) • projection i‖ := by
      rw [← ContinuousLinearMap.norm_smulRight_apply, nuclear_rankOne_eq]
    simp_rw [he]
    exact summable_rankOne_norms a ha
  hasSum := by
    simp_rw [nuclear_rankOne_eq]
    exact (summable_rankOne a ha).hasSum

/-- The matrix of the genuine operator `1 + diagonal a` compressed to the
finite coordinate subspace, in its actual orthonormal coordinate vectors. -/
def operatorCompressionMatrix (T : H (ι := ι) →L[ℂ] H (ι := ι))
    (s : Finset ι) : Matrix s s ℂ :=
  fun i j => ((lp.single 2 (j : ι) (1 : ℂ) : H (ι := ι)) +
    T (lp.single 2 (j : ι) 1)) (i : ι)

def compressionMatrix (a : ι → ℝ) (s : Finset ι) : Matrix s s ℂ :=
  operatorCompressionMatrix (diagonal a) s

theorem compressionMatrix_eq (a : ι → ℝ) (ha : Summable (fun i => |a i|))
    (s : Finset ι) :
    compressionMatrix a s = Matrix.diagonal (fun i : s => 1 + (a i : ℂ)) := by
  ext i j
  simp only [compressionMatrix, operatorCompressionMatrix, lp.coeFn_add, Pi.add_apply, diagonal_apply a ha,
    lp.single_apply, Pi.single_apply, Matrix.diagonal_apply]
  by_cases h : i = j
  · subst j; simp
  · have hc : (i : ι) ≠ (j : ι) := fun h' => h (Subtype.ext h')
    simp [h, hc, Ne.symm hc]

/-- These are genuine finite-dimensional determinants of operator compressions. -/
theorem compression_determinant (a : ι → ℝ) (ha : Summable (fun i => |a i|))
    (s : Finset ι) :
    Matrix.det (compressionMatrix a s) = ((∏ i ∈ s, (1+a i : ℝ)) : ℂ) := by
  rw [compressionMatrix_eq a ha, Matrix.det_diagonal]
  simp only [← Complex.ofReal_one, ← Complex.ofReal_add, ← Complex.ofReal_prod]
  exact congrArg Complex.ofReal (Finset.prod_coe_sort s (fun i => (1+a i : ℝ)))

/-- Actual finite compression determinants converge along all finite subsets,
not only a chosen enumeration. The scalar product is identified with this
operator-determinant approximation limit, rather than renamed by definition. -/
theorem compression_determinants_tendsto (a : ι → ℝ)
    (ha : Summable (fun i => |a i|)) :
    Tendsto (fun s : Finset ι => Matrix.det (compressionMatrix a s)) atTop
      (𝓝 (Continuum.relativeProduct a : ℂ)) := by
  have hreal : Summable a := (by simpa only [Real.norm_eq_abs] using ha :
    Summable (fun i => ‖a i‖)).of_norm
  have hp := (Real.multipliable_one_add_of_summable hreal).hasProd
  have hc := Complex.continuous_ofReal.continuousAt.tendsto.comp hp
  simpa only [Function.comp_def, compression_determinant a ha,
    Continuum.relativeProduct, Complex.ofReal_prod] using hc

/-- The operator-compression determinant limit is strictly positive and its
logarithm is the absolutely convergent relative log series. -/
theorem positive_compression_limit (a : ι → ℝ) (ha : Summable (fun i => |a i|))
    (hp : ∀ i, 0 < 1+a i) :
    0 < Continuum.relativeProduct a ∧
      Real.log (Continuum.relativeProduct a) = Continuum.logAction a ∧
      Tendsto (fun s : Finset ι => Matrix.det (compressionMatrix a s)) atTop
        (𝓝 (Continuum.relativeProduct a : ℂ)) := by
  have hreal : Summable a := (by simpa only [Real.norm_eq_abs] using ha :
    Summable (fun i => ‖a i‖)).of_norm
  exact ⟨Continuum.relativeProduct_pos a hreal hp,
    Continuum.log_relativeProduct a hreal hp, compression_determinants_tendsto a ha⟩

/-- A complete orthonormal basis of the actual Hilbert space. -/
def coordinateBasis : HilbertBasis ι ℂ (H (ι := ι)) :=
  HilbertBasis.ofRepr (LinearIsometryEquiv.refl ℂ _)

@[simp] theorem coordinateBasis_apply (i : ι) :
    coordinateBasis i = lp.single 2 i (1 : ℂ) := by
  simpa [coordinateBasis] using
    (HilbertBasis.repr_symm_single (coordinateBasis (ι := ι)) i).symm

theorem diagonal_basis (a : ι → ℝ) (ha : Summable (fun i => |a i|)) (i : ι) :
    diagonal a (coordinateBasis i) = (a i : ℂ) • coordinateBasis i := by
  apply lp.ext
  funext j
  rw [diagonal_apply a ha]
  simp only [coordinateBasis_apply, lp.coeFn_smul, Pi.smul_apply, smul_eq_mul]
  by_cases h : j = i
  · subst j; rfl
  · simp [lp.single_apply, h]

/-- The real diagonal operator is genuinely self-adjoint. -/
theorem diagonal_selfAdjoint (a : ι → ℝ) (ha : Summable (fun i => |a i|)) :
    IsSelfAdjoint (diagonal a) := by
  apply ContinuousLinearMap.isSelfAdjoint_iff_isSymmetric.mpr
  intro x y
  simp only [lp.inner_eq_tsum]
  apply tsum_congr
  intro i
  simp only [ContinuousLinearMap.coe_coe, diagonal_apply a ha,
    RCLike.inner_apply, map_mul, Complex.conj_ofReal]
  ring

/-- Coordinate-compression determinant is defined from an operator alone.
It is totalized outside convergence, so every use must include a convergence
proof. This is not an assertion of the absent general Fredholm determinant API. -/
def coordinateDeterminant (T : H (ι := ι) →L[ℂ] H (ι := ι)) : ℂ :=
  limUnder atTop (fun s : Finset ι => Matrix.det (operatorCompressionMatrix T s))

theorem coordinateDeterminant_diagonal (a : ι → ℝ)
    (ha : Summable (fun i => |a i|)) :
    coordinateDeterminant (diagonal a) = (Continuum.relativeProduct a : ℂ) :=
  (compression_determinants_tendsto a ha).limUnder_eq

/-- The determinant approximants are independent of the choice of an
increasing/cofinal finite-coordinate exhaustion. -/
theorem compression_determinants_along_cofinal {α : Type*} {l : Filter α}
    (a : ι → ℝ) (ha : Summable (fun i => |a i|)) (s : α → Finset ι)
    (hs : Tendsto s l atTop) :
    Tendsto (fun n => Matrix.det (compressionMatrix a (s n))) l
      (𝓝 (coordinateDeterminant (diagonal a))) := by
  rw [coordinateDeterminant_diagonal a ha]
  exact (compression_determinants_tendsto a ha).comp hs

end SYK.DiagonalFredholm
