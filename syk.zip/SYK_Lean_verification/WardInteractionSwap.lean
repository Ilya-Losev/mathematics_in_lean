import WardInteractionAlgebra

/-! # Exact antisymmetric swap of the marked interaction pair -/
noncomputable section
namespace SYK.WardInteraction
open ThermalWick Ward WickVertexIntegrals ContinuumWickSeries

/-- Three copies of a collective bilocal change sign under endpoint exchange,
including coincidences and arbitrary external and interaction insertions. -/
theorem coefficientIntegrand_cubic_swap (d : ℕ) (β : ℝ) (hβ : 0<β)
    (ps : List (Time β × Time β)) (a b c t : Time β) {n : ℕ} (u : Fin n → ℝ×ℝ) :
    coefficientIntegrand d β hβ (ps ++ List.replicate 3 (b,a) ++ [(c,t)]) u =
      -coefficientIntegrand d β hβ (ps ++ List.replicate 3 (a,b) ++ [(c,t)]) u := by
  simp only [coefficientIntegrand,collectiveMonomial_append,collectiveMonomial_replicate,
    collectiveMonomial_singleton]
  rw [collective_skew (2*d) β b a]
  simp only [pow_succ,pow_zero,mul_one,neg_mul,mul_neg,neg_neg,map_neg]

/-- The second marked term, after swapping its two time variables, is exactly
the negative of the first. This cancels the quartic partner factor 1/2 on
integration against the symmetric pair measure. -/
theorem marked_kernel_swap (d : ℕ) (β : ℝ) (hβ : 0<β)
    (ps : List (Time β × Time β)) (s t : Time β) {n : ℕ}
    (u : Fin n → ℝ×ℝ) (p : ℝ×ℝ) :
    (Thermal.kernel β s.val (timeRepresentative β hβ p.swap.2).val : ℂ) *
      coefficientIntegrand d β hβ
        (ps ++ List.replicate 3 (timeRepresentative β hβ p.swap.1,timeRepresentative β hβ p.swap.2) ++
          [(timeRepresentative β hβ p.swap.1,t)]) u =
      -((Thermal.kernel β s.val (timeRepresentative β hβ p.1).val : ℂ) *
      coefficientIntegrand d β hβ
        (ps ++ List.replicate 3 (timeRepresentative β hβ p.1,timeRepresentative β hβ p.2) ++
          [(timeRepresentative β hβ p.2,t)]) u) := by
  simp only [Prod.swap]
  rw [coefficientIntegrand_cubic_swap]
  exact mul_neg _ _

end SYK.WardInteraction
