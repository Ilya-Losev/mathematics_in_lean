import CollectiveMomentConvergence
import ThermalMicroscopicPositivity
import ThermalMicroscopicOddPositivity
import WeylTranslation
import FiniteWardSymmetry

/-!
# Full actual moment convergence with proved microscopic selection tests

The even and odd microscopic RP tests, their reality and all finite translations
are supplied by their proved operator theorems. Only explicit finite left Ward
contacts remain to be specialized by the actual microscopic Wick/Ward correspondence.
-/

noncomputable section
open scoped BigOperators Topology NNReal
open Filter Set
open SYK.WeightedKernelAlgebra SYK.ThermalEndpointLift SYK.ThermalMomentTransport
open SYK.ThermalRPTransport SYK.ThermalWardLimit SYK.CollectiveMomentConvergence

namespace SYK.MicroscopicMomentConvergence

/-- All finite selection tests are supplied by actual proved microscopic
RP and translation theorems, with no positivity or stationarity hypothesis. -/
theorem finiteSelectionTests (β : ℝ) (hβ : 0 < β) (lam : ℝ≥0) (d : ℕ → ℕ) :
    FiniteSelectionTests β hβ lam d := by
  refine ⟨?_, ?_, ?_, ?_⟩
  · intro n P
    exact ThermalMicroscopicPositivity.actualThermal_half_real β hβ (d n) lam P
  · intro n P
    exact ThermalMicroscopicPositivity.actualThermal_half_nonnegative β hβ (d n) lam P
  · intro n P k x c
    exact ThermalMicroscopicOddPositivity.actualThermal_half_odd_nonnegative β hβ (d n) lam P k x c
  · intro n u P
    exact WeylTranslation.actualThermalPolynomial_translation β hβ (d n) lam P u

/-- Physical existence and full actual factorization with no abstract state,
regularity, RP, translation, analytic or subsequential-limit assumptions. -/
theorem exists_physical_actual_moment_limit (β : ℝ) (hβ : 0 < β) (lam : ℝ≥0)
    (hward : FiniteWardControl β hβ lam (fun n => n+1)) :
    ∃ g : ℝ → ℝ, Continuum.PhysicalSolution β lam g ∧ (∀ s, |g s| ≤ 1/2) ∧
      (∀ k, TendstoUniformly
        (fun d (p : Fin k → Endpoint) => actualThermalPolynomial β hβ d lam (∏ i, MvPolynomial.X (p i)))
        (fun p => ∏ i, (g ((p i).1-(p i).2) : ℂ)) atTop) ∧
      (∀ k, TendstoUniformly
        (fun d (p : Fin k → Ico (0:ℝ) β × Ico (0:ℝ) β) =>
          Interacting.collectiveMoment d β lam (fun i => ((p i).1.val,(p i).2.val)))
        (fun p => ∏ i, (g ((p i).1.val-(p i).2.val) : ℂ)) atTop) :=
  CollectiveMomentConvergence.exists_physical_actual_moment_limit β hβ lam hward
    (finiteSelectionTests β hβ lam _)

/-- The full literal moment limit needs only the left inserted Ward bound and
its sharp centered contact estimate. Right Ward symmetry is proved exactly. -/
theorem exists_physical_actual_moment_limit_of_left (β : ℝ) (hβ : 0 < β) (lam : ℝ≥0)
    (hleft : ∀ Q s t, ∃ A : ℝ, ∀ n,
      ‖leftResidual β hβ lam (n+1) Q s t‖ ≤ A / ((n+1 : ℕ) : ℝ))
    (hcentered : ∀ n (l : List Endpoint) s t,
      ‖leftResidual β hβ lam (n+1) (MixedIncrement.remainderProduct β l) s t‖ ≤
        (l.length : ℝ)/(4*((n+1 : ℕ) : ℝ))) :
    ∃ g : ℝ → ℝ, Continuum.PhysicalSolution β lam g ∧ (∀ s, |g s| ≤ 1/2) ∧
      (∀ k, TendstoUniformly
        (fun d (p : Fin k → Endpoint) => actualThermalPolynomial β hβ d lam (∏ i, MvPolynomial.X (p i)))
        (fun p => ∏ i, (g ((p i).1-(p i).2) : ℂ)) atTop) ∧
      (∀ k, TendstoUniformly
        (fun d (p : Fin k → Ico (0:ℝ) β × Ico (0:ℝ) β) =>
          Interacting.collectiveMoment d β lam (fun i => ((p i).1.val,(p i).2.val)))
        (fun p => ∏ i, (g ((p i).1.val-(p i).2.val) : ℂ)) atTop) :=
  exists_physical_actual_moment_limit β hβ lam
    (FiniteWardSymmetry.finiteWardControl_of_left β hβ lam (fun n => n+1)
      (fun n => Nat.succ_pos n) hleft hcentered)

end SYK.MicroscopicMomentConvergence
