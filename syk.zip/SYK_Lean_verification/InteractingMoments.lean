import ThermalMomentBound
import ThermalReflectionPositivity
import Mathlib.Data.Fin.Tuple.Sort

/-!
# Actual interacting time-ordered Weyl and collective moments

The external fields are evaluated by actual finite-dimensional thermal transfer
products. Equal-time Weyl antisymmetrization is the signed average over all
permutations that put the times in decreasing order. This includes every tied
block permutation, rather than breaking ties by a chosen order.
-/

noncomputable section
open scoped BigOperators NNReal
open MeasureTheory

namespace SYK.Interacting

variable {ν : Type*} [Fintype ν] [DecidableEq ν]

/-- Nonnegative thermal durations of a decreasing-time word, including its
first and last intervals and all zero gaps. -/
def gaps : (k : ℕ) → ℝ → (Fin k → ℝ) → (Fin (k+1) → ℝ)
  | 0, a, _ => fun _ => a
  | k+1, a, t => Fin.cons (a - t 0) (gaps k (t 0) (fun i => t i.succ))

@[simp] theorem gaps_sum (k : ℕ) (a : ℝ) (t : Fin k → ℝ) : ∑ i, gaps k a t i = a := by
  induction k generalizing a with
  | zero => simp [gaps]
  | succ k ih => simp [gaps, Fin.sum_univ_succ, ih]

/-- Ordering and membership in the thermal interval imply every gap is nonnegative. -/
theorem gaps_nonneg (k : ℕ) {a : ℝ} (ha : 0 ≤ a) (t : Fin k → ℝ)
    (ht : Antitone t) (hr : ∀ i, 0 ≤ t i ∧ t i ≤ a) : ∀ i, 0 ≤ gaps k a t i := by
  induction k generalizing a with
  | zero => intro i; exact ha
  | succ k ih =>
    intro i
    refine Fin.cases ?_ (fun i => ?_) i
    · exact sub_nonneg.mpr (hr 0).2
    · apply ih (hr 0).1 (fun j => t j.succ)
      · intro j l hjl; exact ht (Fin.succ_le_succ_iff.mpr hjl)
      · intro j; exact ⟨(hr j.succ).1, ht (Fin.zero_le _)⟩

/-- Actual transfer product of a specified ordered external insertion word. -/
def timeProduct {k : ℕ} (H : Matrix ν ν ℂ) (a : ℝ) (t : Fin k → ℝ)
    (A : Fin k → Matrix ν ν ℂ) : Matrix ν ν ℂ :=
  ThermalRP.evaluate H (ThermalRP.halfFactors a (List.ofFn (fun i => (t i, A i))))

@[simp] theorem timeProduct_zero (H : Matrix ν ν ℂ) (a : ℝ)
    (t : Fin 0 → ℝ) (A : Fin 0 → Matrix ν ν ℂ) : timeProduct H a t A = Gibbs.weight a H := by
  simp [timeProduct]

@[simp] theorem timeProduct_succ {k : ℕ} (H : Matrix ν ν ℂ) (a : ℝ)
    (t : Fin (k+1) → ℝ) (A : Fin (k+1) → Matrix ν ν ℂ) :
    timeProduct H a t A = Gibbs.weight (a - t 0) H *
      (A 0 * timeProduct H (t 0) (fun i => t i.succ) (fun i => A i.succ)) := by
  simp [timeProduct, List.ofFn_succ, ThermalRP.evaluate_halfFactors_cons]

/-- The insertion transfer product is exactly the gap-indexed thermal product. -/
theorem timeProduct_eq_gaps {k : ℕ} (H : Matrix ν ν ℂ) (a : ℝ) (t : Fin k → ℝ)
    (A : Fin k → Matrix ν ν ℂ) : timeProduct H a t A =
      (List.ofFn (fun i => Gibbs.weight (gaps k a t i) H * Fin.snoc (α := fun _ => Matrix ν ν ℂ) A 1 i)).prod := by
  induction k generalizing a with
  | zero => simp [gaps, List.ofFn_succ, Fin.snoc]
  | succ k ih =>
    rw [timeProduct_succ, List.ofFn_succ, List.prod_cons, ih]
    simp only [gaps, Fin.cons_zero, Fin.cons_succ]
    have hsnoc : Fin.snoc (α := fun _ => Matrix ν ν ℂ) A 1 =
        Fin.cons (A 0) (Fin.snoc (fun i => A i.succ) 1) := by
      rw [Fin.cons_snoc_eq_snoc_cons]
      exact congrArg (fun f : Fin (k+1) → Matrix ν ν ℂ =>
        Fin.snoc (α := fun _ => Matrix ν ν ℂ) f 1) (Fin.cons_self_tail A).symm
    rw [hsnoc]
    simp only [Fin.cons_zero, Fin.cons_succ, mul_assoc]



/-- The sharp bound applies to every genuinely ordered transfer product,
including tied times and an empty external word. -/
theorem timeProduct_bound [Nonempty ν] {H : Matrix ν ν ℂ} (hH : H.IsHermitian)
    {β : ℝ} (hβ : 0 < β) {k : ℕ} (t : Fin k → ℝ) (ht : Antitone t)
    (hr : ∀ i, 0 ≤ t i ∧ t i ≤ β) (A : Fin k → Matrix ν ν ℂ) :
    ‖Matrix.trace (timeProduct H β t A)‖ ≤ Gibbs.partition β H * ∏ i, ThermalBound.opNorm (A i) := by
  rw [timeProduct_eq_gaps]
  have h := ThermalBound.matrix_history_bound hH hβ (gaps k β t)
    (gaps_nonneg k hβ.le t ht hr) (gaps_sum k β t) (Fin.snoc A 1)
  rw [Fin.prod_univ_castSucc] at h
  simpa only [Fin.snoc_castSucc, Fin.snoc_last, ThermalBound.opNorm_one, mul_one] using h

/-- All and only permutations that order the times from latest to earliest. -/
def sortingPerms {k : ℕ} (t : Fin k → ℝ) : Finset (Equiv.Perm (Fin k)) := by
  classical
  exact Finset.univ.filter (fun σ => Antitone (t ∘ σ))

@[simp] theorem mem_sortingPerms {k : ℕ} (t : Fin k → ℝ) (σ : Equiv.Perm (Fin k)) :
    σ ∈ sortingPerms t ↔ Antitone (t ∘ σ) := by
  classical
  simp [sortingPerms]

/-- A decreasing sorting permutation exists for every endpoint configuration. -/
theorem sortingPerms_nonempty {k : ℕ} (t : Fin k → ℝ) : (sortingPerms t).Nonempty := by
  refine ⟨Tuple.sort (fun i => -t i), ?_⟩
  rw [mem_sortingPerms]
  intro i j hij
  have h := Tuple.monotone_sort (fun i => -t i) hij
  dsimp [Function.comp_def] at h ⊢
  linarith

/-- Integer-unit signs have norm one on every additive normed group. -/
theorem norm_unit_smul {E : Type*} [SeminormedAddCommGroup E] (s : ℤˣ) (x : E) :
    ‖s • x‖ = ‖x‖ := by
  rcases Int.units_eq_one_or s with h | h <;> rw [h] <;> simp

/-- A genuine normalized finite signed average. -/
def signedAverage {ι : Type*} (S : Finset ι) (ε : ι → ℤˣ) (f : ι → ℂ) : ℂ :=
  (S.card : ℂ)⁻¹ * ∑ i ∈ S, ε i • f i

/-- Signed averaging never increases a uniform absolute bound. -/
theorem signedAverage_bound {ι : Type*} (S : Finset ι) (hS : S.Nonempty)
    (ε : ι → ℤˣ) (f : ι → ℂ) {M : ℝ} (hf : ∀ i ∈ S, ‖f i‖ ≤ M) :
    ‖signedAverage S ε f‖ ≤ M := by
  have hc : (S.card : ℝ) ≠ 0 := by exact_mod_cast Finset.card_ne_zero.mpr hS
  rw [signedAverage, norm_mul, norm_inv, Complex.norm_natCast]
  calc
    _ ≤ (S.card : ℝ)⁻¹ * ∑ i ∈ S, ‖ε i • f i‖ :=
      mul_le_mul_of_nonneg_left (norm_sum_le _ _) (by positivity)
    _ ≤ (S.card : ℝ)⁻¹ * ∑ _i ∈ S, M := by
      apply mul_le_mul_of_nonneg_left _ (by positivity)
      exact Finset.sum_le_sum (fun i hi => (norm_unit_smul _ _).le.trans (hf i hi))
    _ = M := by simp only [Finset.sum_const, nsmul_eq_mul]; rw [← mul_assoc, inv_mul_cancel₀ hc, one_mul]

/-- Actual time-ordered Weyl numerator. All orderings of each coincident-time
block participate with their fermionic sign and exact factorial averaging. -/
def weylNumerator {k : ℕ} (H : Matrix ν ν ℂ) (β : ℝ) (t : Fin k → ℝ)
    (A : Fin k → Matrix ν ν ℂ) : ℂ :=
  signedAverage (sortingPerms t) Equiv.Perm.sign
    (fun σ => Matrix.trace (timeProduct H β (t ∘ σ) (A ∘ σ)))

/-- Weyl averaging preserves the sharp Gibbs trace bound, at every endpoint configuration. -/
theorem weylNumerator_bound [Nonempty ν] {H : Matrix ν ν ℂ} (hH : H.IsHermitian)
    {β : ℝ} (hβ : 0 < β) {k : ℕ} (t : Fin k → ℝ)
    (hr : ∀ i, 0 ≤ t i ∧ t i ≤ β) (A : Fin k → Matrix ν ν ℂ) :
    ‖weylNumerator H β t A‖ ≤ Gibbs.partition β H * ∏ i, ThermalBound.opNorm (A i) := by
  apply signedAverage_bound _ (sortingPerms_nonempty t)
  intro σ hσ
  have h := timeProduct_bound hH hβ (t ∘ σ) ((mem_sortingPerms t σ).mp hσ)
    (fun i => hr (σ i)) (A ∘ σ)
  dsimp [Function.comp_def] at h
  rw [Equiv.prod_comp σ (fun i => ThermalBound.opNorm (A i))] at h
  exact h

/-- Every actual time-product numerator is integrable under the SYK Gaussian law. -/
theorem timeProduct_integrable (d : ℕ) (β : ℝ) (lam : ℝ≥0) {k : ℕ}
    (t : Fin k → ℝ) (A : Fin k → Matrix (Majorana.Basis d) (Majorana.Basis d) ℂ) :
    Integrable (fun j => Matrix.trace (timeProduct (Majorana.hamiltonian d j) β t A))
      (Microscopic.disorder d lam) :=
  ThermalRP.trace_evaluate_integrable d lam _

/-- Gaussian averaging of the complete finite Weyl sum is a genuine integral. -/
theorem weylNumerator_integrable (d : ℕ) (β : ℝ) (lam : ℝ≥0) {k : ℕ}
    (t : Fin k → ℝ) (A : Fin k → Matrix (Majorana.Basis d) (Majorana.Basis d) ℂ) :
    Integrable (fun j => weylNumerator (Majorana.hamiltonian d j) β t A)
      (Microscopic.disorder d lam) := by
  unfold weylNumerator signedAverage
  apply Integrable.const_mul
  apply integrable_finset_sum
  intro σ hσ
  rcases Int.units_eq_one_or (Equiv.Perm.sign σ) with h | h
  · simpa only [h, one_smul] using timeProduct_integrable d β lam (t ∘ σ) (A ∘ σ)
  · simpa only [h, Units.smul_def, Units.val_neg, Units.val_one, neg_one_zsmul, Pi.neg_apply]
      using (timeProduct_integrable d β lam (t ∘ σ) (A ∘ σ)).neg



/-- Two endpoints for each collective bilocal, flattened in the original
fermionic order (s1,t1,s2,t2,...). -/
def pairTimes {m : ℕ} (p : Fin m → ℝ × ℝ) (i : Fin (m*2)) : ℝ :=
  if i.modNat = (0 : Fin 2) then (p i.divNat).1 else (p i.divNat).2

/-- Both fields in a bilocal carry the same summed flavor. -/
def pairFlavors {m N : ℕ} (f : Fin m → Fin N) (i : Fin (m*2)) : Fin N := f i.divNat

/-- The actual finite flavor expansion of a product of m collective bilocals. -/
def collectiveNumerator (d : ℕ) {m : ℕ}
    (H : Matrix (Majorana.Basis d) (Majorana.Basis d) ℂ) (β : ℝ) (p : Fin m → ℝ × ℝ) : ℂ :=
  (((2*d : ℕ) : ℂ)^m)⁻¹ * ∑ f : Fin m → Fin (2*d),
    weylNumerator H β (pairTimes p) (fun i => Majorana.chiFin d (pairFlavors f i))

/-- Its normalization is exactly the average over all N^m flavor assignments. -/
theorem collectiveNumerator_eq_average (d : ℕ) {m : ℕ}
    (H : Matrix (Majorana.Basis d) (Majorana.Basis d) ℂ) (β : ℝ) (p : Fin m → ℝ × ℝ) :
    collectiveNumerator d H β p = signedAverage (Finset.univ : Finset (Fin m → Fin (2*d)))
      (fun _ => 1) (fun f => weylNumerator H β (pairTimes p)
        (fun i => Majorana.chiFin d (pairFlavors f i))) := by
  simp [collectiveNumerator, signedAverage, Fintype.card_fun]

/-- The all-configuration collective numerator bound, before disorder averaging. -/
theorem collectiveNumerator_bound (d : ℕ) (hd : 0 < d) {m : ℕ}
    {H : Matrix (Majorana.Basis d) (Majorana.Basis d) ℂ} (hH : H.IsHermitian)
    {β : ℝ} (hβ : 0 < β) (p : Fin m → ℝ × ℝ)
    (hr : ∀ i, p i ∈ Set.Icc 0 β ×ˢ Set.Icc 0 β) :
    ‖collectiveNumerator d H β p‖ ≤ Gibbs.partition β H * (1 / 2 : ℝ)^m := by
  letI : Nonempty (Fin (2*d)) := ⟨⟨0, by omega⟩⟩
  rw [collectiveNumerator_eq_average]
  apply signedAverage_bound _ Finset.univ_nonempty
  intro f _
  have hr' (i : Fin (m*2)) : 0 ≤ pairTimes p i ∧ pairTimes p i ≤ β := by
    unfold pairTimes
    split_ifs
    · exact (hr i.divNat).1
    · exact (hr i.divNat).2
  have h := weylNumerator_bound hH hβ (pairTimes p) hr'
    (fun i => Majorana.chiFin d (pairFlavors f i))
  have hp : ((Real.sqrt 2)⁻¹ : ℝ)^2 = 1/2 := by
    rw [inv_pow, Real.sq_sqrt (by norm_num)]; norm_num
  simpa only [ThermalBound.opNorm, Majorana.chiFin, Majorana.norm_chi, Finset.prod_const,
    Finset.card_univ, Fintype.card_fin, Nat.mul_comm m 2, pow_mul, hp] using h

/-- Integrability is established for the complete finite flavor and Weyl sum. -/
theorem collectiveNumerator_integrable (d : ℕ) (β : ℝ) (lam : ℝ≥0) {m : ℕ}
    (p : Fin m → ℝ × ℝ) :
    Integrable (fun j => collectiveNumerator d (Majorana.hamiltonian d j) β p)
      (Microscopic.disorder d lam) := by
  unfold collectiveNumerator
  apply Integrable.const_mul
  apply integrable_finset_sum
  intro f _
  exact weylNumerator_integrable d β lam _ _

/-- The actual annealed collective monomial moment of the manuscript: a
Gaussian expectation of the Weyl-ordered numerator divided by E Z_N. -/
def collectiveMoment (d : ℕ) (β : ℝ) (lam : ℝ≥0) {m : ℕ} (p : Fin m → ℝ × ℝ) : ℂ :=
  ((∫ j, (Majorana.partitionFunction d β j).re ∂(Microscopic.disorder d lam) : ℝ) : ℂ)⁻¹ *
    ∫ j, collectiveNumerator d (Majorana.hamiltonian d j) β p ∂(Microscopic.disorder d lam)

/-- The central uniform microscopic compactness estimate, for actual annealed
collective moments and all endpoint configurations, including coincidences. -/
theorem collectiveMoment_bound (d : ℕ) (hd : 0 < d) {β : ℝ} (hβ : 0 < β)
    (lam : ℝ≥0) {m : ℕ} (p : Fin m → ℝ × ℝ)
    (hr : ∀ i, p i ∈ Set.Icc 0 β ×ˢ Set.Icc 0 β) :
    ‖collectiveMoment d β lam p‖ ≤ (1 / 2 : ℝ)^m := by
  let Z : ℝ := ∫ j, (Majorana.partitionFunction d β j).re ∂(Microscopic.disorder d lam)
  have hZ : 0 < Z := ThermalRP.annealed_partition_positive d β lam
  have hnum : ‖∫ j, collectiveNumerator d (Majorana.hamiltonian d j) β p
      ∂(Microscopic.disorder d lam)‖ ≤ Z * (1/2 : ℝ)^m := by
    calc
      _ ≤ ∫ j, ‖collectiveNumerator d (Majorana.hamiltonian d j) β p‖
          ∂(Microscopic.disorder d lam) := norm_integral_le_integral_norm _
      _ ≤ ∫ j, (Majorana.partitionFunction d β j).re * (1/2 : ℝ)^m
          ∂(Microscopic.disorder d lam) := by
        apply integral_mono (collectiveNumerator_integrable d β lam p).norm
          ((Microscopic.real_partitionFunction_integrable d β lam).mul_const _)
        intro j
        exact collectiveNumerator_bound d hd (Majorana.hamiltonian_star d j) hβ p hr
      _ = Z * (1/2 : ℝ)^m := integral_mul_const _ _
  change ‖(Z : ℂ)⁻¹ * _‖ ≤ _
  rw [norm_mul, norm_inv, Complex.norm_real, Real.norm_eq_abs, abs_of_pos hZ]
  calc
    _ ≤ Z⁻¹ * (Z * (1/2 : ℝ)^m) := mul_le_mul_of_nonneg_left hnum (inv_nonneg.mpr hZ.le)
    _ = _ := by rw [← mul_assoc, inv_mul_cancel₀ hZ.ne', one_mul]



/-- Repeated identical external labels cancel in the full Weyl sum, even with
arbitrary other times and insertions. This is the exterior, rather than CAR,
equal-time convention. -/
theorem weylNumerator_eq_zero_of_repeat {k : ℕ} (H : Matrix ν ν ℂ) (β : ℝ)
    (t : Fin k → ℝ) (A : Fin k → Matrix ν ν ℂ) (a b : Fin k)
    (hab : a ≠ b) (ht : t a = t b) (hA : A a = A b) : weylNumerator H β t A = 0 := by
  classical
  let τ : Equiv.Perm (Fin k) := Equiv.swap a b
  have hτ (i : Fin k) : t (τ i) = t i := by
    dsimp [τ]
    rw [Equiv.swap_apply_def]
    split_ifs with h h
    · subst i; exact ht.symm
    · subst i; exact ht
    · rfl
  have hAτ (i : Fin k) : A (τ i) = A i := by
    dsimp [τ]
    rw [Equiv.swap_apply_def]
    split_ifs with h h
    · subst i; exact hA.symm
    · subst i; exact hA
    · rfl
  have hmem (σ : Equiv.Perm (Fin k)) (hσ : σ ∈ sortingPerms t) : τ * σ ∈ sortingPerms t := by
    rw [mem_sortingPerms] at hσ ⊢
    simpa only [Function.comp_def, Equiv.Perm.mul_apply, hτ] using hσ
  let f : Equiv.Perm (Fin k) → ℂ := fun σ => Equiv.Perm.sign σ •
    Matrix.trace (timeProduct H β (t ∘ σ) (A ∘ σ))
  have hf (σ : Equiv.Perm (Fin k)) : f (τ * σ) = -f σ := by
    dsimp [f]
    simp only [map_mul, show Equiv.Perm.sign τ = -1 from Equiv.Perm.sign_swap hab,
      neg_one_mul, Units.neg_smul]
    simp only [Function.comp_def, hτ, hAτ]
  have hsum : (∑ σ ∈ sortingPerms t, f σ) = -(∑ σ ∈ sortingPerms t, f σ) := by
    calc
      _ = ∑ σ ∈ sortingPerms t, -f σ := by
        apply Finset.sum_bij (fun σ _ => τ * σ) hmem
        · intro σ _ ρ _ h; exact mul_left_cancel h
        · intro σ hσ
          refine ⟨τ * σ, hmem σ hσ, ?_⟩
          simp [τ, ← mul_assoc]
        · intro σ _; rw [hf, neg_neg]
      _ = _ := Finset.sum_neg_distrib
  have hzero : (∑ σ ∈ sortingPerms t, f σ) = 0 := by
    apply Complex.ext
    · have h := congrArg Complex.re hsum; simp only [Complex.neg_re] at h; simp only [Complex.zero_re]; linarith
    · have h := congrArg Complex.im hsum; simp only [Complex.neg_im] at h; simp only [Complex.zero_im]; linarith
  unfold weylNumerator signedAverage
  change _ * (∑ σ ∈ sortingPerms t, f σ) = 0
  rw [hzero, mul_zero]



/-- At a single common time the propagators collapse around the ordered word. -/
theorem timeProduct_constant {k : ℕ} (H : Matrix ν ν ℂ) (a r : ℝ)
    (A : Fin k → Matrix ν ν ℂ) :
    timeProduct H a (fun _ => r) A =
      Gibbs.weight (a-r) H * (List.ofFn A).prod * Gibbs.weight r H := by
  induction k generalizing a with
  | zero =>
    simp only [timeProduct_zero, List.ofFn_zero, List.prod_nil, mul_one]
    rw [← ThermalRP.heat_add]
    rw [sub_add_cancel]
  | succ k ih =>
    rw [timeProduct_succ, ih]
    simp only [sub_self, Gibbs.weight, neg_zero, zero_smul, NormedSpace.exp_zero,
      one_mul, List.ofFn_succ, List.prod_cons, mul_assoc]

/-- The time of a complete coincident block disappears by trace cyclicity. -/
theorem trace_timeProduct_constant {k : ℕ} (H : Matrix ν ν ℂ) (β r : ℝ)
    (A : Fin k → Matrix ν ν ℂ) :
    Matrix.trace (timeProduct H β (fun _ => r) A) =
      Matrix.trace (Gibbs.weight β H * (List.ofFn A).prod) := by
  rw [timeProduct_constant, Matrix.trace_mul_cycle, ← ThermalRP.heat_add]
  rw [add_sub_cancel]

/-- Every permutation is admitted at a completely coincident block. -/
theorem sortingPerms_constant (k : ℕ) (r : ℝ) :
    sortingPerms (fun _ : Fin k => r) = Finset.univ := by
  classical
  ext σ
  simp only [mem_sortingPerms, Function.comp_def, Finset.mem_univ, iff_true]
  intro i j hij
  exact le_rfl

/-- The sorting-permutation definition exactly recovers the manuscript's
factorial-normalized Weyl block, with arbitrary repeats allowed. -/
theorem weylNumerator_constant (d k : ℕ)
    (H : Matrix (Majorana.Basis d) (Majorana.Basis d) ℂ) (β r : ℝ) (v : Fin k → Fin (2*d)) :
    weylNumerator H β (fun _ : Fin k => r) (fun i => Majorana.chiFin d (v i)) =
      Matrix.trace (Gibbs.weight β H * FreeWick.weylBlock d k v) := by
  unfold weylNumerator signedAverage
  rw [sortingPerms_constant]
  simp only [Finset.card_univ, Fintype.card_perm, Fintype.card_fin, Function.comp_def,
    trace_timeProduct_constant, FreeWick.weylBlock_sum, mul_smul_comm,
    Matrix.trace_smul, smul_eq_mul, Finset.mul_sum, Matrix.trace_sum]



/-- The empty external word is exactly the actual partition function. -/
theorem weylNumerator_empty (d : ℕ)
    (H : Matrix (Majorana.Basis d) (Majorana.Basis d) ℂ) (β : ℝ)
    (t : Fin 0 → ℝ) (v : Fin 0 → Fin (2*d)) :
    weylNumerator H β t (fun i => Majorana.chiFin d (v i)) = Matrix.trace (Gibbs.weight β H) := by
  have ht : t = (fun _ => 0) := Subsingleton.elim _ _
  rw [ht, weylNumerator_constant]
  simp [FreeWick.weylBlock_sum]

/-- The empty collective polynomial has the partition function as numerator. -/
theorem collectiveNumerator_empty (d : ℕ)
    (H : Matrix (Majorana.Basis d) (Majorana.Basis d) ℂ) (β : ℝ) (p : Fin 0 → ℝ × ℝ) :
    collectiveNumerator d H β p = Matrix.trace (Gibbs.weight β H) := by
  simp [collectiveNumerator, weylNumerator_empty]

/-- Exact normalization of the actual annealed collective moments. -/
theorem collectiveMoment_empty (d : ℕ) (β : ℝ) (lam : ℝ≥0) (p : Fin 0 → ℝ × ℝ) :
    collectiveMoment d β lam p = 1 := by
  unfold collectiveMoment
  simp only [collectiveNumerator_empty]
  have hp := ThermalRP.annealed_partition_positive d β lam
  simp_rw [Gibbs.weight_trace_real (Majorana.hamiltonian_star d _)]
  rw [integral_complex_ofReal]
  apply inv_mul_cancel₀
  exact_mod_cast hp.ne'

end SYK.Interacting
