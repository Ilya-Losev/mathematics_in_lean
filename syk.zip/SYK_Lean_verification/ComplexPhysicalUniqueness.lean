import ComplexFourierOperatorAction

/-! Bounded complex tests determine a unique continuous operator on the
actual thermal L² space, because they contain every genuine Fourier mode. -/
noncomputable section
open MeasureTheory Filter
open scoped Topology NNReal
namespace SYK.ComplexFourierOperatorAction
open Continuum FourierOperators
variable (β : ℝ) [Fact (0<β)]

def modeTest (n : ℤ) (t : ℝ) : ℂ :=
  Complex.exp (-(Complex.I*((Real.pi*t/β:ℝ):ℂ))) * _root_.fourier n (t:AddCircle β)

theorem modeTest_measurable (n : ℤ) : Measurable (modeTest β n) := by
  unfold modeTest
  fun_prop

theorem modeTest_bound (n : ℤ) (t : ℝ) : ‖modeTest β n t‖ ≤ 1 := by
  unfold modeTest
  rw [norm_mul]
  have he : ‖Complex.exp (-(Complex.I*((Real.pi*t/β:ℝ):ℂ)))‖ = 1 := by
    simp [Complex.norm_exp]
  rw [he,one_mul]
  exact (ContinuousMap.norm_coe_le_norm _ _).trans (by rw [_root_.fourier_norm])

theorem complexCircleLift_modeTest (n : ℤ) :
    complexCircleLift β (modeTest β n) = _root_.fourier n := by
  funext t
  let r := (AddCircle.equivIoc β 0) t
  have hr : (r.val : AddCircle β) = t := by
    exact (AddCircle.equivIoc β 0).symm_apply_apply t
  change Complex.exp (Complex.I*((Real.pi*r.val/β:ℝ):ℂ)) *
    (Complex.exp (-(Complex.I*((Real.pi*r.val/β:ℝ):ℂ))) * _root_.fourier n (r.val:AddCircle β)) = _
  rw [← mul_assoc, ← Complex.exp_add, add_neg_cancel,Complex.exp_zero,one_mul,hr]

theorem complexCircleL2_modeTest (n : ℤ) :
    complexCircleL2 β (modeTest β n) (modeTest_measurable β n) 1 (modeTest_bound β n) =
      (@_root_.fourierBasis β _) n := by
  apply Lp.ext
  apply (complexCircleL2_coe β _ (modeTest_measurable β n) 1 (modeTest_bound β n)).trans
  rw [complexCircleLift_modeTest]
  simpa only [_root_.coe_fourierBasis] using (_root_.coeFn_fourierLp (T:=β) 2 n).symm

/-- The literal bounded complex integral action identifies the operator
uniquely on its whole Hilbert space, without a density assumption. -/
theorem operator_eq_of_complex_tests (T S : TimeHilbert β →L[ℂ] TimeHilbert β)
    (h : ∀ (f : ℝ → ℂ) (hm : Measurable f) (D : ℝ) (hd : ∀ t, ‖f t‖ ≤ D),
      T (complexCircleL2 β f hm D hd) = S (complexCircleL2 β f hm D hd)) : T = S := by
  have hb (n : ℤ) : T ((@_root_.fourierBasis β _) n) = S ((@_root_.fourierBasis β _) n) := by
    rw [← complexCircleL2_modeTest β n]
    exact h _ _ _ _
  apply ContinuousLinearMap.ext
  intro x
  have ht := ((@_root_.fourierBasis β _).hasSum_repr x).mapL T
  have hs := ((@_root_.fourierBasis β _).hasSum_repr x).mapL S
  simp only [map_smul,hb] at ht
  simp only [map_smul] at hs
  exact ht.unique hs

/-- Any continuous Hilbert operator having the literal complex CΣ action is
exactly the already constructed physical perturbation. -/
theorem physical_operator_unique (lam : ℝ≥0) (g : ℝ → ℝ)
    (hg : PhysicalSolution β lam g) (B : ℝ) (hb : ∀ t, |g t| ≤ B)
    (T : TimeHilbert β →L[ℂ] TimeHilbert β)
    (hT : ∀ (h : ℝ → ℂ) (hm : Measurable h) (D : ℝ) (hd : ∀ t, ‖h t‖ ≤ D),
      (T (complexCircleL2 β h hm D hd) : AddCircle β → ℂ) =ᵐ[AddCircle.haarAddCircle]
        -complexCircleLift β (complexCovarianceSource β lam g h)) :
    T = physicalPerturbation β lam g := by
  apply operator_eq_of_complex_tests β
  intro h hm D hd
  apply Lp.ext
  exact (hT h hm D hd).trans
    (physicalPerturbation_complex_integral_action β lam g h hg hm B D hb hd).symm

end SYK.ComplexFourierOperatorAction
