import RealWardContacts
import SymmetricMomentFunctional

/-! Linearity extends literal listed Ward identities to every inserted polynomial. -/
noncomputable section
open MeasureTheory
open scoped BigOperators
namespace SYK.PolynomialWardExtension
open MvPolynomial

variable {ι Ω : Type*} [MeasurableSpace Ω]
abbrev Polynomial (ι : Type*) := MvPolynomial ι ℂ

def insertedIntegral (μ : Measure Ω) (L : Polynomial ι →ₗ[ℂ] ℂ)
    (W : Ω → Polynomial ι) (hI : ∀ Q, Integrable (fun x => L (Q*W x)) μ) :
    Polynomial ι →ₗ[ℂ] ℂ where
  toFun Q := ∫ x, L (Q*W x) ∂μ
  map_add' P Q := by
    simp only [add_mul,map_add]
    exact integral_add (hI P) (hI Q)
  map_smul' z Q := by
    simp only [smul_mul_assoc,map_smul,integral_smul]
    rfl

/-- Equality on finite coordinate products determines an actual polynomial
linear functional; no density or continuity assumption is needed. -/
theorem linear_eq_of_list_products (A B : Polynomial ι →ₗ[ℂ] ℂ)
    (h : ∀ ps : List ι, A ((ps.map X).prod)=B ((ps.map X).prod)) : A=B := by
  apply LinearMap.ext
  intro Q
  induction Q using MvPolynomial.induction_on' with
  | monomial e c =>
    have hmono : monomial e c = c • monomial e (1:ℂ) := by rw [smul_monomial,smul_eq_mul,mul_one]
    rw [hmono,map_smul,map_smul]
    congr 1
    rw [SymmetricMomentFunctional.monomial_eq_tuple_prod,← List.prod_ofFn]
    simpa only [List.map_ofFn,Function.comp_def] using
      h (List.ofFn (SymmetricMomentFunctional.canonicalTuple e))
  | add P Q hP hQ => simp [hP,hQ]

/-- Exact inserted Ward equations on listed coordinate products extend to all
polynomials, with Bochner integrability required and used explicitly. -/
theorem ward_of_list_products (μ : Measure Ω) (L : Polynomial ι →ₗ[ℂ] ℂ)
    (W : Ω → Polynomial ι) (hI : ∀ Q, Integrable (fun x => L (Q*W x)) μ)
    (R : Polynomial ι) (D : Polynomial ι →ₗ[ℂ] Polynomial ι) (a b : ℂ)
    (h : ∀ ps : List ι,
      L (((ps.map X).prod)*R) =
        a*(∫ x, L (((ps.map X).prod)*W x) ∂μ)+b*L (D ((ps.map X).prod)))
    (Q : Polynomial ι) :
    L (Q*R)=a*(∫ x, L (Q*W x) ∂μ)+b*L (D Q) := by
  let A : Polynomial ι →ₗ[ℂ] ℂ := L.comp (LinearMap.mulRight ℂ R)
  let B : Polynomial ι →ₗ[ℂ] ℂ := a • insertedIntegral μ L W hI + b • L.comp D
  have he : A=B := linear_eq_of_list_products A B h
  exact congrArg (fun f : Polynomial ι →ₗ[ℂ] ℂ => f Q) he

end SYK.PolynomialWardExtension
