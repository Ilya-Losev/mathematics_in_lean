import GapChamberCoordinates
import MomentSymmetry

/-! # Actual product measure change between paired and flattened time cubes -/
noncomputable section
open scoped BigOperators
open MeasureTheory MeasureTheory.Measure Set
namespace SYK.ThermalPairCube
open GapChamberCoordinates OrderedCubePartition

/-- The same adjacent-pair indexing used by the microscopic bilocal history. -/
def pairIndex (n : ℕ) : (Σ _ : Fin n, Fin 2) ≃ Fin (n*2) :=
  (Equiv.sigmaEquivProd (Fin n) (Fin 2)).trans finProdFinEquiv

/-- Group adjacent real coordinates into actual endpoint pairs. -/
def pairCoordinates (n : ℕ) : (Fin (n*2) → ℝ) ≃ᵐ (Fin n → ℝ×ℝ) :=
  (blockCoordinates (pairIndex n)).trans
    (MeasurableEquiv.piCongrRight (fun _ : Fin n => MeasurableEquiv.piFinTwo (fun _ => ℝ)))

@[simp] theorem pairCoordinates_apply (n : ℕ) (u : Fin (n*2) → ℝ) (i : Fin n) :
    pairCoordinates n u i = (u (finProdFinEquiv (i,(0:Fin 2))),u (finProdFinEquiv (i,(1:Fin 2)))) := rfl

/-- This grouping preserves the genuine Lebesgue measures. -/
theorem pairCoordinates_measurePreserving (n : ℕ) :
    MeasurePreserving (pairCoordinates n) volume volume := by
  have hp : MeasurePreserving
      (MeasurableEquiv.piCongrRight (fun _ : Fin n => MeasurableEquiv.piFinTwo (fun _ => ℝ)))
      volume volume :=
    volume_preserving_pi (fun _ : Fin n => volume_preserving_piFinTwo (fun _ => ℝ))
  exact hp.comp (blockCoordinates_measurePreserving (pairIndex n))

/-- The inverse grouping is exactly the manuscript's flattened pairTimes. -/
theorem pairCoordinates_symm_eq_pairTimes (n : ℕ) (p : Fin n → ℝ×ℝ) :
    (pairCoordinates n).symm p = Interacting.pairTimes p := by
  apply (pairCoordinates n).injective
  rw [MeasurableEquiv.apply_symm_apply]
  funext i
  simp only [pairCoordinates_apply, MomentSymmetry.pairTimes_finProd]
  norm_num

/-- The actual finite product of restricted thermal square measures. -/
def pairedMeasure (β : ℝ) (n : ℕ) : Measure (Fin n → ℝ×ℝ) :=
  Measure.pi (fun _ => (volume.restrict (Icc (0:ℝ) β)).prod (volume.restrict (Icc (0:ℝ) β)))

def pairedCube (β : ℝ) (n : ℕ) : Set (Fin n → ℝ×ℝ) :=
  univ.pi (fun _ => Icc (0:ℝ) β ×ˢ Icc (0:ℝ) β)

/-- The product of restricted square measures is exactly the restriction of
ambient product Lebesgue measure to the paired cube. -/
theorem pairedMeasure_eq_restrict (β : ℝ) (n : ℕ) :
    pairedMeasure β n = volume.restrict (pairedCube β n) := by
  unfold pairedMeasure pairedCube
  simp only [Measure.prod_restrict, ← MeasureTheory.Measure.volume_eq_prod, ← Measure.restrict_pi_pi,
    ← MeasureTheory.volume_pi]

/-- Cube membership is preserved by the exact adjacent-coordinate grouping. -/
theorem pairedCube_preimage (β : ℝ) (n : ℕ) :
    pairCoordinates n ⁻¹' pairedCube β n = timeCube (n*2) 0 β := by
  ext u
  simp only [mem_preimage, pairedCube, mem_univ_pi, mem_prod, pairCoordinates_apply,
    timeCube, mem_univ_pi]
  constructor
  · intro h i
    obtain ⟨⟨j,a⟩, rfl⟩ := finProdFinEquiv.surjective i
    fin_cases a
    · exact (h j).1
    · exact (h j).2
  · intro h i
    exact ⟨h _,h _⟩

/-- Exact paired-cube change of variables for arbitrary Banach-valued scalar
observables, with no separate integrability assumption. -/
theorem integral_pairTimes {E : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E]
    (β : ℝ) (n : ℕ) (f : (Fin (n*2) → ℝ) → E) :
    ∫ p, f (Interacting.pairTimes p) ∂pairedMeasure β n =
      ∫ u in timeCube (n*2) 0 β, f u := by
  rw [pairedMeasure_eq_restrict]
  have h := (pairCoordinates_measurePreserving n).setIntegral_preimage_emb
    (pairCoordinates n).measurableEmbedding
    (fun p => f ((pairCoordinates n).symm p)) (pairedCube β n)
  rw [pairedCube_preimage] at h
  simpa only [MeasurableEquiv.symm_apply_apply, pairCoordinates_symm_eq_pairTimes] using h.symm

end SYK.ThermalPairCube
