import ThermalResidualState
import KernelConstructedSelection

/-!
# Transporting finite microscopic symmetry and reflection tests

Every element of the actual positive-half polynomial algebra is represented by
a genuine finite endpoint polynomial. Reflection conjugates coefficients and
reverses endpoints, and every tested value agrees with the constructed limit.
-/

noncomputable section
namespace SYK.ThermalRPTransport
open SYK.WeightedKernelAlgebra SYK.ThermalEndpointLift SYK.ThermalMomentTransport
open SYK.MomentLimit SYK.MomentCompactness SYK.MixedIncrement SYK.ThermalWeightedState
open SYK.KernelResidualAlgebra SYK.KernelCoordinateGeneration SYK.KernelFinalActions
open SYK.KernelQuotientAnalyticity SYK.KernelAlgebraActions SYK.KernelQuotientActions
open SYK.ThermalResidualState SYK.ThermalKernelSelection
open MeasureTheory Filter Set
open scoped BigOperators Topology NNReal

private theorem halfPositive : (0 : ℝ) < 1/2 := by norm_num

abbrev HalfPair (β : ℝ) := Ioo (0 : ℝ) (β/2) × Ioo (0 : ℝ) (β/2)
def halfEndpoint {β : ℝ} (p : HalfPair β) : Endpoint := (p.1.val,p.2.val)
def halfPolynomial (β : ℝ) : MvPolynomial (HalfPair β) ℂ →ₐ[ℂ] RealPolynomial :=
  MvPolynomial.rename halfEndpoint

def reflectPolynomial (β : ℝ) : RealPolynomial →+* RealPolynomial :=
  (MvPolynomial.rename (reflectEndpoint β)).toRingHom.comp (MvPolynomial.map (starRingEnd ℂ))

def translatePolynomial (u : ℝ) : RealPolynomial →ₐ[ℂ] RealPolynomial :=
  MvPolynomial.rename (translateEndpoint u)

def hankelPolynomial (β : ℝ) {k : ℕ} (x : Fin k → ℝ) (c : Fin k → ℂ) : RealPolynomial :=
  ∑ i, ∑ j, (star (c i)*c j) • MvPolynomial.X (β-x i,x j)

@[simp] theorem reflectPolynomial_C (β : ℝ) (c : ℂ) :
    reflectPolynomial β (MvPolynomial.C c) = MvPolynomial.C (star c) := by
  simp [reflectPolynomial]
@[simp] theorem reflectPolynomial_X (β : ℝ) (p : Endpoint) :
    reflectPolynomial β (MvPolynomial.X p) = MvPolynomial.X (reflectEndpoint β p) := by
  simp [reflectPolynomial]

variable (β : ℝ) (hβ : 0 < β) (lam : ℝ≥0) (d : ℕ → ℕ) (hd : ∀ n, 0 < d n)
  (g : ∀ k, EndpointCube β k → ℂ)
  (hg : ∀ k, TendstoUniformly
    (fun n => functionalCenteredMoment (actualCorrectedPolynomial β hβ (d n) lam)) (g k) atTop)
  (K : ℝ) (hK : 0 < K) (hKlarge : (lam : ℝ)*β*(1/2:ℝ)^4 ≤ K)
  (hrep : ReplacementIdentity β (lam : ℝ) (polynomialState β hβ g))
  [Nontrivial (ThermalResidualState.Algebra β K hK)]
  [Nontrivial (FinalAlgebra (1/2) K halfPositive hK β hβ (lam : ℝ))]
  (hleft : LeftWard β (lam : ℝ) (polynomialState β hβ g))
  (hright : RightWard β (lam : ℝ) (polynomialState β hβ g))

abbrev finalPolynomialMap : RealPolynomial →ₐ[ℂ] FinalAlgebra (1/2) K halfPositive hK β hβ (lam : ℝ) :=
  (ResidualQuotient.mk _).comp (realPolynomialMap β K hK)

@[simp] theorem finalPolynomialMap_X (p : Endpoint) :
    finalPolynomialMap β hβ lam K hK (MvPolynomial.X p) = finalCoordinate β hβ lam K hK p := by
  simp only [finalPolynomialMap, AlgHom.comp_apply, realPolynomialMap_X, finalCoordinate]

@[simp] theorem finalCoordinate_eq_kernel (p : Endpoint) :
    finalCoordinate β hβ lam K hK p =
      thermalFinalKernel (1/2) K halfPositive hK β hβ (lam : ℂ) (symmetryRelations β) p := rfl

/-- Every real coordinate polynomial retains its exact limiting microscopic
value after both quotient maps. -/
theorem finalState_realPolynomial (P : RealPolynomial) :
    finalState β hβ lam d hd g hg K hK hKlarge hrep hleft hright
      (finalPolynomialMap β hβ lam K hK P) = polynomialState β hβ g P := by
  have h := finalState_polynomial β hβ lam d hd g hg K hK hKlarge hrep hleft hright
    (MvPolynomial.rename Sum.inl P)
  simpa only [substitutePolynomial_rename] using h

/-- Endpoint reflection and coefficient conjugation become the actual
antilinear involution on the final quotient. -/
theorem finalPolynomialMap_reflect (P : RealPolynomial) :
    finalPolynomialMap β hβ lam K hK (reflectPolynomial β P) =
      finalReflection (1/2) K halfPositive hK β hβ (lam : ℝ)
        (finalPolynomialMap β hβ lam K hK P) := by
  induction P using MvPolynomial.induction_on with
  | C c =>
    rw [reflectPolynomial_C]
    simp only [← MvPolynomial.algebraMap_eq, AlgHom.commutes,
      finalReflection_constant]
  | add P Q hP hQ => simp only [map_add, hP, hQ]
  | mul_X P p hP =>
    simp only [map_mul, hP, reflectPolynomial_X, finalPolynomialMap_X]
    simp only [finalCoordinate, finalReflection_coordinate]

/-- The scalar endpoint translation is exactly the constructed isometric
quotient translation on every finite coordinate polynomial. -/
theorem finalPolynomialMap_translate (P : RealPolynomial) (u : ℝ) :
    finalPolynomialMap β hβ lam K hK (translatePolynomial u P) =
      finalTranslation (1/2) K halfPositive hK β hβ (lam : ℝ) u
        (finalPolynomialMap β hβ lam K hK P) := by
  have h : (finalPolynomialMap β hβ lam K hK).comp (translatePolynomial u) =
      (finalTranslation (1/2) K halfPositive hK β hβ (lam : ℝ) u).toAlgHom.comp
        (finalPolynomialMap β hβ lam K hK) := by
    ext p
    simp only [AlgHom.comp_apply, translatePolynomial, MvPolynomial.rename_X,
      finalPolynomialMap_X, finalCoordinate, AlgEquiv.toAlgHom_eq_coe,
      AlgEquiv.coe_algHom, realPolynomialMap_X]
    exact (finalTranslation_coordinate (1/2) K halfPositive hK β hβ (lam : ℝ) u p).symm
  exact AlgHom.congr_fun h P

/-- Finite half-polynomials are evaluated by the actual final bilocal kernel. -/
def halfEvaluation : MvPolynomial (HalfPair β) ℂ →ₐ[ℂ] FinalAlgebra (1/2) K halfPositive hK β hβ (lam : ℝ) :=
  (finalPolynomialMap β hβ lam K hK).comp (halfPolynomial β)

/-- Every member of the half-adjoin has a finite endpoint polynomial
representative; this is algebraic generation, not an extra density assumption. -/
theorem halfPolynomial_representation (q : FinalAlgebra (1/2) K halfPositive hK β hβ (lam : ℝ))
    (hq : q ∈ halfPolynomialAlgebra (1/2) K halfPositive hK β hβ lam) :
    ∃ P : MvPolynomial (HalfPair β) ℂ, halfEvaluation β hβ lam K hK P = q := by
  have he : halfEvaluation β hβ lam K hK = MvPolynomial.aeval
      (fun p : HalfPair β => thermalFinalKernel (1/2) K halfPositive hK β hβ (lam : ℂ)
        (symmetryRelations β) (p.1,p.2)) := by
    ext p
    simp only [halfEvaluation, halfPolynomial, AlgHom.comp_apply, MvPolynomial.rename_X,
      MvPolynomial.aeval_X, finalPolynomialMap_X, realPolynomialMap_X, finalCoordinate_eq_kernel, halfEndpoint]
    rfl
  change q ∈ Algebra.adjoin ℂ (Set.range _) at hq
  rw [Algebra.adjoin_range_eq_range_aeval, ← he] at hq
  exact hq

/-- The odd inserted Hankel polynomial is exactly the final kernel's
finite reflection observable. -/
theorem finalPolynomialMap_hankel {k : ℕ} (x : Fin k → ℝ) (c : Fin k → ℂ) :
    finalPolynomialMap β hβ lam K hK (hankelPolynomial β x c) =
      SYK.KernelSelection.hankelObservable β
        (thermalFinalKernel (1/2) K halfPositive hK β hβ (lam : ℂ) (symmetryRelations β)) x c := by
  simp only [hankelPolynomial, SYK.KernelSelection.hankelObservable, map_sum, map_smul,
    finalPolynomialMap_X, finalCoordinate_eq_kernel, Complex.star_def]


/-- The exact reflection quadratic form of any final polynomial is its
all-real limiting microscopic polynomial test. -/
theorem finalState_reflection_test (P : RealPolynomial) :
    finalState β hβ lam d hd g hg K hK hKlarge hrep hleft hright
      (finalReflection (1/2) K halfPositive hK β hβ (lam : ℝ)
        (finalPolynomialMap β hβ lam K hK P) * finalPolynomialMap β hβ lam K hK P) =
      polynomialState β hβ g (reflectPolynomial β P * P) := by
  rw [← finalPolynomialMap_reflect, ← map_mul]
  exact finalState_realPolynomial β hβ lam d hd g hg K hK hKlarge hrep hleft hright _

theorem finalState_odd_test (P : RealPolynomial) {k : ℕ} (x : Fin k → ℝ) (c : Fin k → ℂ) :
    finalState β hβ lam d hd g hg K hK hKlarge hrep hleft hright
      (finalReflection (1/2) K halfPositive hK β hβ (lam : ℝ)
        (finalPolynomialMap β hβ lam K hK P) * finalPolynomialMap β hβ lam K hK P *
          SYK.KernelSelection.hankelObservable β
            (thermalFinalKernel (1/2) K halfPositive hK β hβ (lam : ℂ) (symmetryRelations β)) x c) =
      polynomialState β hβ g (reflectPolynomial β P * P * hankelPolynomial β x c) := by
  rw [← finalPolynomialMap_reflect, ← finalPolynomialMap_hankel, ← map_mul, ← map_mul]
  exact finalState_realPolynomial β hβ lam d hd g hg K hK hKlarge hrep hleft hright _

/-- Finite microscopic reality of all half-polynomial tests supplies exactly
the reality hypothesis of the constructed-algebra selection theorem. -/
theorem finalState_half_real
    (hfinite : ∀ n (P : MvPolynomial (HalfPair β) ℂ),
      (actualThermalPolynomial β hβ (d n) lam
        (reflectPolynomial β (halfPolynomial β P) * halfPolynomial β P)).im = 0)
    (q : FinalAlgebra (1/2) K halfPositive hK β hβ (lam : ℝ))
    (hq : q ∈ halfPolynomialAlgebra (1/2) K halfPositive hK β hβ lam) :
    (finalState β hβ lam d hd g hg K hK hKlarge hrep hleft hright
      (finalReflection (1/2) K halfPositive hK β hβ (lam : ℝ) q * q)).im = 0 := by
  obtain ⟨P, rfl⟩ := halfPolynomial_representation β hβ lam K hK q hq
  change (finalState β hβ lam d hd g hg K hK hKlarge hrep hleft hright
    (finalReflection _ _ _ _ _ _ _ (finalPolynomialMap β hβ lam K hK (halfPolynomial β P)) *
      finalPolynomialMap β hβ lam K hK (halfPolynomial β P))).im = 0
  rw [finalState_reflection_test]
  exact thermalLimit_real β hβ lam d g hg _ (fun n => hfinite n P)

/-- Finite microscopic even RP passes to every element of the actual half
polynomial algebra, not merely to individual monomials. -/
theorem finalState_half_nonnegative
    (hfinite : ∀ n (P : MvPolynomial (HalfPair β) ℂ),
      0 ≤ (actualThermalPolynomial β hβ (d n) lam
        (reflectPolynomial β (halfPolynomial β P) * halfPolynomial β P)).re)
    (q : FinalAlgebra (1/2) K halfPositive hK β hβ (lam : ℝ))
    (hq : q ∈ halfPolynomialAlgebra (1/2) K halfPositive hK β hβ lam) :
    0 ≤ (finalState β hβ lam d hd g hg K hK hKlarge hrep hleft hright
      (finalReflection (1/2) K halfPositive hK β hβ (lam : ℝ) q * q)).re := by
  obtain ⟨P, rfl⟩ := halfPolynomial_representation β hβ lam K hK q hq
  change 0 ≤ (finalState β hβ lam d hd g hg K hK hKlarge hrep hleft hright
    (finalReflection _ _ _ _ _ _ _ (finalPolynomialMap β hβ lam K hK (halfPolynomial β P)) *
      finalPolynomialMap β hβ lam K hK (halfPolynomial β P))).re
  rw [finalState_reflection_test]
  exact thermalLimit_nonnegative β hβ lam d g hg _ (fun n => hfinite n P)

/-- Finite inserted odd RP supplies the exact Hankel positivity tests needed
for physical scalar-branch selection. -/
theorem finalState_half_odd
    (hfinite : ∀ n (P : MvPolynomial (HalfPair β) ℂ) (k : ℕ)
      (x : Fin k → Ioo (0:ℝ) (β/2)) (c : Fin k → ℂ),
      0 ≤ (actualThermalPolynomial β hβ (d n) lam
        (reflectPolynomial β (halfPolynomial β P) * halfPolynomial β P *
          hankelPolynomial β (fun i => x i) c)).re)
    (k : ℕ) (x : Fin k → Ioo (0:ℝ) (β/2)) (c : Fin k → ℂ)
    (q : FinalAlgebra (1/2) K halfPositive hK β hβ (lam : ℝ))
    (hq : q ∈ halfPolynomialAlgebra (1/2) K halfPositive hK β hβ lam) :
    0 ≤ (finalState β hβ lam d hd g hg K hK hKlarge hrep hleft hright
      (finalReflection (1/2) K halfPositive hK β hβ (lam : ℝ) q * q *
        SYK.KernelSelection.hankelObservable β
          (thermalFinalKernel (1/2) K halfPositive hK β hβ (lam : ℂ) (symmetryRelations β))
          (fun i => x i) c)).re := by
  obtain ⟨P, rfl⟩ := halfPolynomial_representation β hβ lam K hK q hq
  change 0 ≤ (finalState β hβ lam d hd g hg K hK hKlarge hrep hleft hright
    (finalReflection _ _ _ _ _ _ _ (finalPolynomialMap β hβ lam K hK (halfPolynomial β P)) *
      finalPolynomialMap β hβ lam K hK (halfPolynomial β P) * _)).re
  rw [finalState_odd_test]
  exact thermalLimit_nonnegative β hβ lam d g hg _ (fun n => hfinite n P k x c)

/-- Elimination of increment generators identifies every mixed polynomial
class with a genuine coordinate polynomial. -/
theorem realPolynomialMap_substitution (P : MvPolynomial KernelIndex ℂ) :
    realPolynomialMap β K hK (substitutePolynomial β P) = ThermalResidualState.polyMap β K hK P := by
  have h : (realPolynomialMap β K hK).comp (substitutePolynomial β) = ThermalResidualState.polyMap β K hK := by
    ext i
    cases i with
    | inl p => simp only [AlgHom.comp_apply, substitutePolynomial_coordinate, realPolynomialMap_X, ThermalResidualState.polyMap,
        polynomialMap_coordinate]
    | inr pq =>
      simp only [AlgHom.comp_apply, substitutePolynomial_increment, SYK.MixedIncrement.increment,
        SYK.MixedIncrement.remainder, map_sub, realPolynomialMap_X, ← MvPolynomial.algebraMap_eq,
        AlgHom.commutes, ThermalResidualState.polyMap, polynomialMap_increment,
        increment_eq_remainder_sub, SYK.WeightedKernelAlgebra.remainder, thermalCovariance]
  exact AlgHom.congr_fun h P

/-- Actual real-coordinate polynomial values are dense in the final double
quotient, because the weighted increment generators are eliminated exactly. -/
theorem finalPolynomialMap_dense : DenseRange (finalPolynomialMap β hβ lam K hK) := by
  have hfirst : DenseRange (realPolynomialMap β K hK) := by
    apply (firstQuotient_polynomials_dense (kernelWeights (1/2) K halfPositive hK)
      (kernelRelations (thermalCovariance β) (symmetryRelations β))).mono
    rintro _ ⟨P, rfl⟩
    exact ⟨substitutePolynomial β P, realPolynomialMap_substitution β K hK P⟩
  have hsurj : Function.Surjective (ResidualQuotient.mk (residuals (1/2) K halfPositive hK β hβ.le (lam : ℝ))) :=
    Ideal.Quotient.mk_surjective
  exact hsurj.denseRange.comp hfirst (ResidualQuotient.mkCLM _).continuous

/-- Genuine finite-size translation symmetry supplies full invariance of the
continuous final state. The passage uses the proved coordinate density. -/
theorem finalState_translation_invariant
    (hfinite : ∀ n u P, actualThermalPolynomial β hβ (d n) lam (translatePolynomial u P) =
      actualThermalPolynomial β hβ (d n) lam P)
    (u : ℝ) (a : FinalAlgebra (1/2) K halfPositive hK β hβ (lam : ℝ)) :
    finalState β hβ lam d hd g hg K hK hKlarge hrep hleft hright
      (finalTranslation (1/2) K halfPositive hK β hβ (lam : ℝ) u a) =
        finalState β hβ lam d hd g hg K hK hKlarge hrep hleft hright a := by
  refine (finalPolynomialMap_dense β hβ lam K hK).induction_on a ?_ ?_
  · exact isClosed_eq
      ((finalState β hβ lam d hd g hg K hK hKlarge hrep hleft hright).continuous.comp
        (finalTranslation_isometry (1/2) K halfPositive hK β hβ (lam : ℝ) u).continuous)
      (finalState β hβ lam d hd g hg K hK hKlarge hrep hleft hright).continuous
  · intro P
    rw [← finalPolynomialMap_translate, finalState_realPolynomial, finalState_realPolynomial]
    exact thermalLimit_eq β hβ lam d g hg _ _ (fun n => hfinite n u P)


/-- Translation invariance in the exact mixed-polynomial form expected by
the final constructed-algebra selection theorem. -/
theorem finalState_translation_tests
    (hfinite : ∀ n u P, actualThermalPolynomial β hβ (d n) lam (translatePolynomial u P) =
      actualThermalPolynomial β hβ (d n) lam P) (u : ℝ) (P : MvPolynomial KernelIndex ℂ) :
    finalState β hβ lam d hd g hg K hK hKlarge hrep hleft hright
      (ResidualQuotient.mk _ (translatedPolynomial (1/2) K halfPositive hK β (thermalCovariance β) u P)) =
    finalState β hβ lam d hd g hg K hK hKlarge hrep hleft hright
      (ResidualQuotient.mk _ (polynomialMap (1/2) K halfPositive hK (thermalCovariance β) (symmetryRelations β) P)) := by
  have h := finalState_translation_invariant β hβ lam d hd g hg K hK hKlarge hrep hleft hright hfinite u
    (ResidualQuotient.mk _ (polynomialMap (1/2) K halfPositive hK (thermalCovariance β) (symmetryRelations β) P))
  rw [finalTranslation_mk] at h
  change finalState β hβ lam d hd g hg K hK hKlarge hrep hleft hright
    (ResidualQuotient.mk _ (firstTranslation (1/2) K halfPositive hK β (thermalCovariance β)
      (thermal_translation β) u (RelationQuotient.mk _ _ (WeightedAlgebra.ofPolynomial _ P)))) = _ at h
  rw [firstTranslation_mk] at h
  exact h

end SYK.ThermalRPTransport
