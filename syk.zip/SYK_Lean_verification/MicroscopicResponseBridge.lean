import WickSeriesPressure

/-!
# From actual Wick/operator correspondence to microscopic pressure response

The hypotheses here are explicit numerical operator/series identities. The
pressure derivative itself is derived from them, not assumed. The independent
microscopic correspondence module instantiates these identities.
-/
set_option maxHeartbeats 1000000
noncomputable section
open MeasureTheory Set Filter
open scoped NNReal Topology
namespace SYK.MicroscopicResponseBridge
open ContinuumWickSeries FourthMomentIntegral

/-- The exact normalized partition representation needed by this bridge. -/
def PartitionRepresentation (d : ℕ) (β : ℝ) (hβ : 0 < β) (lam : ℝ≥0) : Prop :=
  numerator d β hβ [] (lam : ℝ) =
    ((∫ j, (Majorana.partitionFunction d β j).re ∂Microscopic.disorder d lam : ℝ) : ℂ) /
      (2 : ℂ)^d

/-- The genuine Gibbs partition forces both realness and strict positivity
of any scalar series identified with its normalized trace. -/
theorem represented_partition_real_pos (d : ℕ) (β : ℝ) (hβ : 0 < β) (lam : ℝ≥0)
    (hZ : PartitionRepresentation d β hβ lam) :
    (numerator d β hβ [] (lam : ℝ)).im = 0 ∧ 0 < (numerator d β hβ [] (lam : ℝ)).re := by
  rw [hZ]
  have he : (2 : ℂ)^d = (((2 : ℝ)^d : ℝ) : ℂ) := by push_cast; rfl
  rw [he, ← Complex.ofReal_div]
  constructor
  · rfl
  · exact div_pos (ThermalRP.annealed_partition_positive d β lam) (by positivity)

/-- The actual finite-dimensional free trace contributes precisely log(2)/2. -/
theorem annealedPressure_eq_seriesPressure (d : ℕ) (hd : 0 < d) (β : ℝ) (hβ : 0 < β)
    (lam : ℝ≥0) (hZ : PartitionRepresentation d β hβ lam) :
    Microscopic.annealedPressure d β lam = seriesPressure d β hβ (lam : ℝ) := by
  have he : (2 : ℂ)^d = (((2 : ℝ)^d : ℝ) : ℂ) := by push_cast; rfl
  have hr := congrArg Complex.re hZ
  rw [he, ← Complex.ofReal_div, Complex.ofReal_re] at hr
  unfold seriesPressure
  rw [hr, Real.log_div (ThermalRP.annealed_partition_positive d β lam).ne' (by positivity),
    Real.log_pow]
  unfold Microscopic.annealedPressure GaussianDisorder.annealedPressure
  simp only [Nat.cast_mul, Nat.cast_ofNat]
  have hd' : (d : ℝ) ≠ 0 := by exact_mod_cast hd.ne'
  dsimp only [Microscopic.disorder]
  field_simp [hd']
  ring

/-- Full microscopic differentiation from the proved series derivative and
an actual partition correspondence. No derivative formula is an input. -/
theorem hasDerivAt_annealedPressure_series (d : ℕ) (hd : 0 < d) (β : ℝ) (hβ : 0 < β)
    (hZ : ∀ lam, PartitionRepresentation d β hβ lam) (l : ℝ) (hl : 0 < l) :
    HasDerivAt (fun s : ℝ => Microscopic.annealedPressure d β s.toNNReal)
      ((1/8 : ℝ) * ∫ p, (normalizedMoment d β hβ (quarticPairs β hβ p) l).re
        ∂pairMeasure β) l := by
  have hh := represented_partition_real_pos d β hβ l.toNNReal (hZ _)
  simp only [Real.coe_toNNReal _ hl.le] at hh
  have hs := hasDerivAt_seriesPressure d hd β hβ l hh.2 hh.1
  apply hs.congr_of_eventuallyEq
  filter_upwards [eventually_gt_nhds hl] with s hs
  have he := annealedPressure_eq_seriesPressure d hd β hβ s.toNNReal (hZ _)
  simpa only [Real.coe_toNNReal _ hs.le] using he

/-- The final microscopic fourth-moment response follows once the inserted
operator/series identity is supplied almost everywhere in the true time square.
This formulation avoids making any false raw seam-point identification. -/
theorem hasDerivAt_annealedPressure_fourth (d : ℕ) (hd : 0 < d) (β : ℝ) (hβ : 0 < β)
    (hZ : ∀ lam, PartitionRepresentation d β hβ lam) (l : ℝ) (hl : 0 < l)
    (hM : ∀ᵐ p ∂pairMeasure β,
      normalizedMoment d β hβ (quarticPairs β hβ p) l =
        Interacting.collectiveMoment d β l.toNNReal (fun _ : Fin 4 => p)) :
    HasDerivAt (fun s : ℝ => Microscopic.annealedPressure d β s.toNNReal)
      (fourthIntegral d β l.toNNReal) l := by
  have h := hasDerivAt_annealedPressure_series d hd β hβ hZ l hl
  have he : (∫ p, (normalizedMoment d β hβ (quarticPairs β hβ p) l).re ∂pairMeasure β) =
      ∫ p, fourthMoment d β l.toNNReal p ∂timeMeasure β := by
    rw [timeMeasure_eq_closed]
    exact integral_congr_ae (hM.mono fun p hp => congrArg Complex.re hp)
  simpa only [he, fourthIntegral] using h

end SYK.MicroscopicResponseBridge
