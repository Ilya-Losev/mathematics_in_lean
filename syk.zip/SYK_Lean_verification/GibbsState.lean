import AntiCommutingBound
import Majorana
import Mathlib.Analysis.Normed.Algebra.MatrixExponential

/-!
# Positive finite-dimensional Gibbs states

For every Hermitian complex matrix this file derives positivity of its
exponential from a half-exponential star-square and its invertibility. It then
constructs the normalized Gibbs density matrix and proves its positivity and
trace-one normalization. These are concrete matrix statements, not assumptions
about an unspecified partition function.
-/

noncomputable section
open scoped BigOperators ComplexOrder
open NormedSpace

namespace SYK.Gibbs

variable {n : Type*} [Fintype n] [DecidableEq n]

omit [Fintype n] [DecidableEq n] in
theorem hermitian_smul_real {H : Matrix n n ℂ} (hH : H.IsHermitian) (r : ℝ) :
    (r • H).IsHermitian := by
  change star (r • H) = r • H
  simp only [star_smul, star_trivial]
  exact congrArg (fun A => r • A) hH

/-- The exponential of a Hermitian matrix is positive definite. -/
theorem exp_posDef {H : Matrix n n ℂ} (hH : H.IsHermitian) :
    (exp ℂ H).PosDef := by
  let K : Matrix n n ℂ := (1 / 2 : ℝ) • H
  let B : Matrix n n ℂ := exp ℂ K
  have hK : K.IsHermitian := hermitian_smul_real hH _
  have hB : B.IsHermitian := hK.exp ℂ
  change B.conjTranspose = B at hB
  have hinj : Function.Injective B.mulVec :=
    Matrix.mulVec_injective_iff_isUnit.mpr (Matrix.isUnit_exp ℂ K)
  have hpos := (Matrix.PosDef.one : (1 : Matrix n n ℂ).PosDef).conjTranspose_mul_mul_same hinj
  simp only [Matrix.mul_one, hB] at hpos
  have hexp : exp ℂ H = B * B := by
    dsimp [B]
    rw [← Matrix.exp_add_of_commute ℂ K K (Commute.refl K)]
    congr 1
    dsimp [K]
    rw [← add_smul]
    norm_num
  rw [hexp]
  exact hpos

omit [DecidableEq n] in
/-- A Hermitian matrix has a real trace. -/
theorem trace_im_eq_zero {H : Matrix n n ℂ} (hH : H.IsHermitian) :
    (Matrix.trace H).im = 0 := by
  apply Complex.conj_eq_iff_im.mp
  change star (Matrix.trace H) = Matrix.trace H
  rw [← Matrix.trace_conjTranspose, hH]

/-- Positive definite matrices on nonempty spaces have strictly positive trace. -/
theorem trace_re_pos [Nonempty n] {M : Matrix n n ℂ} (hM : M.PosDef) :
    0 < (Matrix.trace M).re := by
  have hdiag (i : n) : 0 < (M i i).re := by
    have hx : (Pi.single i (1 : ℂ) : n → ℂ) ≠ 0 := by
      intro h
      have := congrFun h i
      simp at this
    have hstar : star (Pi.single i (1 : ℂ) : n → ℂ) =
        (Pi.single i (1 : ℂ) : n → ℂ) := by
      ext j
      by_cases h : j = i
      · subst j; simp
      · simp [Pi.single_apply, h, Ne.symm h]
    simpa [hstar] using hM.re_dotProduct_pos hx
  simp only [Matrix.trace, Complex.re_sum, Matrix.diag_apply]
  exact Finset.sum_pos (fun i _ => hdiag i) Finset.univ_nonempty

omit [DecidableEq n] in
/-- Nonnegative real scaling preserves matrix positive semidefiniteness. -/
theorem posSemidef_smul_real {M : Matrix n n ℂ} (hM : M.PosSemidef)
    {r : ℝ} (hr : 0 ≤ r) : (r • M).PosSemidef := by
  refine ⟨hermitian_smul_real hM.isHermitian r, ?_⟩
  intro x
  rw [Matrix.smul_mulVec_assoc, dotProduct_smul]
  exact smul_nonneg hr (hM.2 x)

/-- The unnormalized finite-dimensional Gibbs weight. -/
def weight (β : ℝ) (H : Matrix n n ℂ) : Matrix n n ℂ := exp ℂ ((-β) • H)

/-- The real ordinary trace, without dimension normalization. -/
def partition (β : ℝ) (H : Matrix n n ℂ) : ℝ := (Matrix.trace (weight β H)).re

/-- The normalized density matrix. Its denominator is proved positive below. -/
def density (β : ℝ) (H : Matrix n n ℂ) : Matrix n n ℂ :=
  (partition β H)⁻¹ • weight β H

theorem weight_posDef {H : Matrix n n ℂ} (hH : H.IsHermitian) (β : ℝ) :
    (weight β H).PosDef := exp_posDef (hermitian_smul_real hH _)

theorem partition_pos [Nonempty n] {H : Matrix n n ℂ} (hH : H.IsHermitian) (β : ℝ) :
    0 < partition β H := trace_re_pos (weight_posDef hH β)

theorem weight_trace_real {H : Matrix n n ℂ} (hH : H.IsHermitian) (β : ℝ) :
    Matrix.trace (weight β H) = (partition β H : ℂ) := by
  apply Complex.ext
  · rfl
  · simp only [Complex.ofReal_im]
    exact trace_im_eq_zero (weight_posDef hH β).isHermitian

theorem density_posSemidef [Nonempty n] {H : Matrix n n ℂ}
    (hH : H.IsHermitian) (β : ℝ) : (density β H).PosSemidef :=
  posSemidef_smul_real (weight_posDef hH β).posSemidef (le_of_lt (inv_pos.mpr (partition_pos hH β)))

theorem density_trace_one [Nonempty n] {H : Matrix n n ℂ}
    (hH : H.IsHermitian) (β : ℝ) : Matrix.trace (density β H) = 1 := by
  dsimp [density]
  rw [Matrix.trace_smul, weight_trace_real hH β]
  simp only [Complex.real_smul, Complex.ofReal_inv]
  exact inv_mul_cancel₀ (by exact_mod_cast (ne_of_gt (partition_pos hH β)))

/-- The state sum bound now applies to the actual Gibbs density; its state
positivity and normalization are conclusions of the preceding matrix proofs. -/
theorem gibbs_sum_sq_le_one [Nonempty n] {ι : Type*}
    {H : Matrix n n ℂ} (hH : H.IsHermitian) (β : ℝ)
    (s : Finset ι) (U : ι → Matrix n n ℂ)
    (hself : ∀ i ∈ s, star (U i) = U i)
    (hsquare : ∀ i ∈ s, U i * U i = 1)
    (hanti : ∀ i ∈ s, ∀ j ∈ s, i ≠ j → U i * U j + U j * U i = 0) :
    ∑ i ∈ s, ((Matrix.trace (density β H * U i)).re) ^ 2 ≤ 1 :=
  AntiCommuting.density_sum_sq_le_one s U (density β H)
    (density_posSemidef hH β) (density_trace_one hH β) hself hsquare hanti

/-- Diagonalization identifies the finite matrix trace of the exponential
with the sum of exponentials of the real eigenvalues. -/
theorem trace_exp_re_eq_sum {H : Matrix n n ℂ} (hH : H.IsHermitian) :
    (Matrix.trace (exp ℂ H)).re = ∑ i, Real.exp (hH.eigenvalues i) := by
  let U : (Matrix n n ℂ)ˣ := unitary.toUnits hH.eigenvectorUnitary
  have hdiag : H = (U : Matrix n n ℂ) *
      Matrix.diagonal (fun i => (hH.eigenvalues i : ℂ)) * (↑U⁻¹ : Matrix n n ℂ) :=
    hH.spectral_theorem
  have he : exp ℂ H = (U : Matrix n n ℂ) *
      exp ℂ (Matrix.diagonal (fun i => (hH.eigenvalues i : ℂ))) * (↑U⁻¹ : Matrix n n ℂ) := by
    exact (congrArg (exp ℂ) hdiag).trans (Matrix.exp_units_conj ℂ U _)
  rw [he, Matrix.trace_units_conj, Matrix.exp_diagonal, Matrix.trace_diagonal]
  simp only [Pi.exp_def, ← Complex.exp_eq_exp_ℂ, ← Complex.ofReal_exp,
    Complex.re_sum, Complex.ofReal_re]

/-- Every real eigenvalue is bounded in absolute value by the actual matrix
operator norm, via invariance of spectrum under the matrix type equivalence. -/
theorem eigenvalue_abs_le_norm [Nonempty n] {H : Matrix n n ℂ}
    (hH : H.IsHermitian) (i : n) :
    |hH.eigenvalues i| ≤ ‖CStarMatrix.ofMatrix H‖ := by
  let e : Matrix n n ℂ ≃⋆ₐ[ℝ] CStarMatrix n n ℂ :=
    (CStarMatrix.ofMatrixStarAlgEquiv (n := n) (A := ℂ)).restrictScalars ℝ
  have hs : hH.eigenvalues i ∈ spectrum ℝ (CStarMatrix.ofMatrix H) := by
    change hH.eigenvalues i ∈ spectrum ℝ (e H)
    rw [AlgEquiv.spectrum_eq e]
    exact hH.eigenvalues_mem_spectrum_real i
  simpa only [Real.norm_eq_abs] using spectrum.norm_le_norm_of_mem hs

/-- Even a single eigenvalue gives a positive exponential lower bound on the
ordinary partition trace. This is enough to control the logarithm. -/
theorem exp_neg_norm_le_trace_exp [Nonempty n] {H : Matrix n n ℂ}
    (hH : H.IsHermitian) :
    Real.exp (-‖CStarMatrix.ofMatrix H‖) ≤ (Matrix.trace (exp ℂ H)).re := by
  rw [trace_exp_re_eq_sum hH]
  let i : n := Classical.choice (inferInstance : Nonempty n)
  calc
    Real.exp (-‖CStarMatrix.ofMatrix H‖) ≤ Real.exp (hH.eigenvalues i) :=
      Real.exp_le_exp.mpr (abs_le.mp (eigenvalue_abs_le_norm hH i)).1
    _ ≤ ∑ j, Real.exp (hH.eigenvalues j) :=
      Finset.single_le_sum (fun j _ => (Real.exp_pos _).le) (Finset.mem_univ i)

section ConcreteSYK

open Majorana

/-- The concrete SYK Hamiltonian is Hermitian by the proved Majorana algebra. -/
theorem syk_hamiltonian_isHermitian (m : ℕ) (j : FourSet m → ℝ) :
    (hamiltonian m j).IsHermitian := hamiltonian_star m j

/-- The actual operator partition function in Majorana.lean is real. -/
theorem syk_partition_im_zero (m : ℕ) (β : ℝ) (j : FourSet m → ℝ) :
    (partitionFunction m β j).im = 0 :=
  trace_im_eq_zero (weight_posDef (syk_hamiltonian_isHermitian m j) β).isHermitian

/-- Strict positivity of the actual operator partition function, for all real β. -/
theorem syk_partition_re_pos (m : ℕ) (β : ℝ) (j : FourSet m → ℝ) :
    0 < (partitionFunction m β j).re :=
  partition_pos (syk_hamiltonian_isHermitian m j) β

/-- A lower bound for the actual SYK partition function using the same
Gaussian-integrable coupling-size control as the existing upper bound. -/
theorem syk_partition_re_lower (m : ℕ) (β : ℝ) (j : FourSet m → ℝ) :
    Real.exp (-(|β| * (∑ I, |j I|) / 4)) ≤ (partitionFunction m β j).re := by
  have hn : ‖CStarMatrix.ofMatrix ((-β) • hamiltonian m j)‖ ≤
      |β| * (∑ I, |j I|) / 4 := by
    change ‖(-β) • CStarMatrix.ofMatrix (hamiltonian m j)‖ ≤ _
    rw [norm_smul (-β) (CStarMatrix.ofMatrix (hamiltonian m j)), Real.norm_eq_abs, abs_neg]
    calc
      |β| * ‖CStarMatrix.ofMatrix (hamiltonian m j)‖ ≤
          |β| * ((∑ I, |j I|) / 4) :=
        mul_le_mul_of_nonneg_left (norm_hamiltonian_le m j) (abs_nonneg β)
      _ = _ := by ring
  exact (Real.exp_le_exp.mpr (neg_le_neg hn)).trans
    (exp_neg_norm_le_trace_exp (hermitian_smul_real (syk_hamiltonian_isHermitian m j) (-β)))

/-- The logarithm of the actual operator partition function has a linear
absolute-coupling majorant, suitable for Gaussian integrability. -/
theorem abs_log_syk_partition_le (m : ℕ) (β : ℝ) (j : FourSet m → ℝ) :
    |Real.log (partitionFunction m β j).re| ≤
      (m : ℝ) * Real.log 2 + |β| * (∑ I, |j I|) / 4 := by
  have hlo := Real.log_le_log (Real.exp_pos _) (syk_partition_re_lower m β j)
  rw [Real.log_exp] at hlo
  have hu : (partitionFunction m β j).re ≤
      (2 : ℝ) ^ m * Real.exp (|β| * (∑ I, |j I|) / 4) :=
    (Complex.re_le_norm _).trans (norm_partitionFunction_le m β j)
  have hup := Real.log_le_log (syk_partition_re_pos m β j) hu
  rw [Real.log_mul (by positivity) (by positivity), Real.log_pow, Real.log_exp] at hup
  have hd : 0 ≤ (m : ℝ) * Real.log 2 :=
    mul_nonneg (Nat.cast_nonneg m) (Real.log_nonneg (by norm_num))
  exact abs_le.mpr ⟨by linarith, hup⟩

/-- The normalized density formed from the explicitly constructed SYK Hamiltonian. -/
def sykDensity (m : ℕ) (β : ℝ) (j : FourSet m → ℝ) : Matrix (Basis m) (Basis m) ℂ :=
  density β (hamiltonian m j)

theorem sykDensity_posSemidef (m : ℕ) (β : ℝ) (j : FourSet m → ℝ) :
    (sykDensity m β j).PosSemidef := density_posSemidef (syk_hamiltonian_isHermitian m j) β

theorem sykDensity_trace_one (m : ℕ) (β : ℝ) (j : FourSet m → ℝ) :
    Matrix.trace (sykDensity m β j) = 1 := density_trace_one (syk_hamiltonian_isHermitian m j) β

/-- A concrete SYK concentration ingredient: for every fixed triple of distinct
explicit Majorana generators, the sum of squared normalized quartic Gibbs
expectations over any outside set is at most 1/16. No CAR or state-positivity
hypothesis remains: both are proved from the actual constructed matrices. -/
theorem syk_common_triple_bound (m : ℕ) (β : ℝ) (j : FourSet m → ℝ)
    (s : Finset (Flavor m)) (a b c : Flavor m)
    (hab : a ≠ b) (hac : a ≠ c) (hbc : b ≠ c)
    (houtside : ∀ i ∈ s, i ≠ a ∧ i ≠ b ∧ i ≠ c) :
    ∑ i ∈ s, ((Matrix.trace (sykDensity m β j *
      ((1 / 4 : ℝ) • (gamma m a * gamma m b * gamma m c * gamma m i)))).re) ^ 2 ≤
      1 / 16 :=
  AntiCommuting.density_normalized_common_triple_bound s (gamma m) (sykDensity m β j)
    (sykDensity_posSemidef m β j) (sykDensity_trace_one m β j)
    (gamma_star m) (gamma_square m) (gamma_anticommute m)
    a b c hab hac hbc houtside

end ConcreteSYK

end SYK.Gibbs
