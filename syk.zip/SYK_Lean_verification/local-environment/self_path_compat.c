#define _GNU_SOURCE
#include <dlfcn.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>

/* This executor exposes the current executable through /proc/self/exe,
   while numeric PIDs in its /proc mount are from a different PID namespace.
   Adapt only the current process's executable-path lookup. No Lean proof
   code, imported theorem, kernel operation, or other file access is changed. */
ssize_t readlink(const char *path, char *buf, size_t bufsiz) {
    static ssize_t (*original)(const char *, char *, size_t) = NULL;
    if (!original) original = dlsym(RTLD_NEXT, "readlink");
    char own_path[80];
    snprintf(own_path, sizeof own_path, "/proc/%ld/exe", (long)getpid());
    if (strcmp(path, own_path) == 0) path = "/proc/self/exe";
    return original(path, buf, bufsiz);
}
