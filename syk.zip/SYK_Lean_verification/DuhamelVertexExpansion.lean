import DuhamelHistorySeries
import FreeWeylCorrespondence
import QuarticRegrouping
import GapSimplexIntegral

/-!
# Exact quartic vertex expansion of finite thermal-history coefficients

The Hamiltonian powers are expanded into the actual increasing four-set
vertices, with their true coupling monomials. No Gaussian Wick or interacting
identity is assumed.
-/
noncomputable section
open scoped BigOperators ComplexOrder
namespace SYK.DuhamelVertex
open DuhamelHistory

/-- Distributing every ordered factor over its finite sum keeps all order
information in the independently chosen vertex labels. -/
theorem orderedProduct_sum {A ι : Type*} [Semiring A] [Fintype ι] {k : ℕ}
    (F : Fin k → ι → A) :
    orderedProduct (fun i => ∑ a, F i a) =
      ∑ a : Fin k → ι, orderedProduct (fun i => F i (a i)) := by
  classical
  induction k with
  | zero => simp
  | succ k ih =>
    rw [orderedProduct_succ, ih]
    rw [Finset.sum_mul_sum]
    rw [← Fintype.sum_prod_type (fun a : ι × (Fin k → ι) =>
      F 0 a.1 * orderedProduct (fun i => F i.succ (a.2 i)))]
    exact Fintype.sum_equiv (Fin.consEquiv (fun _ : Fin (k+1) => ι)) _ _ (by
      intro a
      simp only [Fin.consEquiv, Equiv.coe_fn_mk, orderedProduct_succ,
        Fin.cons_zero, Fin.cons_succ])

/-- Central scalar coefficients can be collected without commuting any
operator factors. -/
theorem orderedProduct_smul {A : Type*} [Semiring A] [Algebra ℂ A] {k : ℕ}
    (c : Fin k → ℂ) (F : Fin k → A) :
    orderedProduct (fun i => c i • F i) = (∏ i, c i) • orderedProduct F := by
  induction k with
  | zero => simp
  | succ k ih =>
    simp only [orderedProduct_succ, Fin.prod_univ_succ, ih,
      smul_mul_smul_comm]

@[simp] theorem orderedProduct_const {A : Type*} [Monoid A] (k : ℕ) (a : A) :
    orderedProduct (fun _ : Fin k => a) = a^k := by
  induction k with
  | zero => simp
  | succ k ih => simp [orderedProduct_succ, ih, pow_succ']

/-- Exact noncommutative multinomial formula for a finite power. -/
theorem sum_pow_ordered {A ι : Type*} [Semiring A] [Fintype ι]
    (F : ι → A) (k : ℕ) :
    (∑ a, F a)^k = ∑ a : Fin k → ι, orderedProduct (fun i => F (a i)) := by
  simpa using orderedProduct_sum (fun _ : Fin k => F)

/-- The minus sign in the actual Hamiltonian is canceled by the Duhamel
exponential, leaving a positive real coupling for each quartic vertex. -/
theorem neg_hamiltonian (d : ℕ) (j : Majorana.FourSet d → ℝ) :
    -Majorana.hamiltonian d j = ∑ I, (j I : ℂ) • Majorana.quartic d I := by
  simp only [Majorana.hamiltonian, neg_neg]
  congr 1

/-- Every actual Hamiltonian power is an exact sum over quartic vertex
sequences with the genuine disorder monomial. -/
theorem neg_hamiltonian_pow (d : ℕ) (j : Majorana.FourSet d → ℝ) (k : ℕ) :
    (-Majorana.hamiltonian d j)^k =
      ∑ I : Fin k → Majorana.FourSet d,
        (∏ i, (j (I i) : ℂ)) • orderedProduct (fun i => Majorana.quartic d (I i)) := by
  rw [neg_hamiltonian, sum_pow_ordered]
  apply Finset.sum_congr rfl
  intro I _
  exact orderedProduct_smul _ _

/-- The four genuine flavor-time labels of one increasing quartic vertex. -/
def vertexLabels (d : ℕ) {β : ℝ} (I : Majorana.FourSet d) (u : ThermalWick.Time β) :
    List (ThermalWick.Label (2*d) β) :=
  List.ofFn (fun a : Fin 4 => (Majorana.fourIndex d I a, u))

@[simp] theorem vertexLabels_length (d : ℕ) {β : ℝ}
    (I : Majorana.FourSet d) (u : ThermalWick.Time β) :
    (vertexLabels d I u).length = 4 := by simp [vertexLabels]

/-- The operator word of these labels is exactly the actual quartic matrix. -/
theorem vertexLabels_operator_word (d : ℕ) {β : ℝ}
    (I : Majorana.FourSet d) (u : ThermalWick.Time β) :
    FreeWick.word (fun p : ThermalWick.Label (2*d) β => Majorana.chiFin d p.1)
      (vertexLabels d I u) = Majorana.quartic d I := by
  simp [vertexLabels, FreeWick.word_ofFn, List.ofFn_succ, Majorana.quartic, mul_assoc]

/-- The exterior word uses the very same increasing quartic convention. -/
theorem vertexLabels_exterior_word (d : ℕ) {β : ℝ}
    (I : Majorana.FourSet d) (u : ThermalWick.Time β) :
    FreeWick.word (fun p : ThermalWick.Label (2*d) β => ThermalWick.field p.1 p.2)
      (vertexLabels d I u) = ThermalWick.quarticField d I u := by
  simp [vertexLabels, FreeWick.word_ofFn, List.ofFn_succ, ThermalWick.quarticField, mul_assoc]

/-- Flattening finite vertex blocks preserves their ordered product. -/
theorem word_flatten {ι A : Type*} [Ring A] (x : ι → A) (L : List (List ι)) :
    FreeWick.word x L.flatten = (L.map (FreeWick.word x)).prod := by
  induction L with
  | nil => simp
  | cons l L ih => simp [FreeWick.word_append, ih]

/-- The actual labels of an ordered finite interaction history. -/
def historyLabels (d : ℕ) {β : ℝ} {k : ℕ}
    (I : Fin k → Majorana.FourSet d) (u : Fin k → ThermalWick.Time β) :
    List (ThermalWick.Label (2*d) β) :=
  (List.ofFn (fun i => vertexLabels d (I i) (u i))).flatten

@[simp] theorem historyLabels_length (d : ℕ) {β : ℝ} {k : ℕ}
    (I : Fin k → Majorana.FourSet d) (u : Fin k → ThermalWick.Time β) :
    (historyLabels d I u).length = k*4 := by
  simp [historyLabels, List.length_flatten, List.map_ofFn, Function.comp_def, List.sum_ofFn]

/-- Exact unaveraged operator vertex expansion. -/
theorem historyLabels_operator_word (d : ℕ) {β : ℝ} {k : ℕ}
    (I : Fin k → Majorana.FourSet d) (u : Fin k → ThermalWick.Time β) :
    FreeWick.word (fun p : ThermalWick.Label (2*d) β => Majorana.chiFin d p.1)
      (historyLabels d I u) = orderedProduct (fun i => Majorana.quartic d (I i)) := by
  simp [historyLabels, word_flatten, List.map_ofFn, Function.comp_def, vertexLabels_operator_word, orderedProduct]

/-- Exact exterior interaction-vertex product. -/
theorem historyLabels_exterior_word (d : ℕ) {β : ℝ} {k : ℕ}
    (I : Fin k → Majorana.FourSet d) (u : Fin k → ThermalWick.Time β) :
    FreeWick.word (fun p : ThermalWick.Label (2*d) β => ThermalWick.field p.1 p.2)
      (historyLabels d I u) = orderedProduct (fun i => ThermalWick.quarticField d (I i) (u i)) := by
  simp [historyLabels, word_flatten, List.map_ofFn, Function.comp_def, vertexLabels_exterior_word, orderedProduct]

/-- Distinct flavors within each equal-time quartic vertex satisfy the exact
free-trace collision convention. -/
theorem vertexLabels_pairwise (d : ℕ) {β : ℝ}
    (I : Majorana.FourSet d) (u : ThermalWick.Time β) :
    (vertexLabels d I u).Pairwise (fun p q => q.2.val < p.2.val ∨ p.1 ≠ q.1) := by
  apply List.pairwise_ofFn.mpr
  intro a b hab
  exact Or.inr ((Majorana.fourIndex d I).injective.ne hab.ne)

/-- Strictly ordered interaction times guarantee the correct ordering of
all flavor-time letters, with the four equal-time letters kept in each vertex. -/
theorem historyLabels_pairwise (d : ℕ) {β : ℝ} {k : ℕ}
    (I : Fin k → Majorana.FourSet d) (u : Fin k → ThermalWick.Time β)
    (hu : StrictAnti (fun i => (u i).val)) :
    (historyLabels d I u).Pairwise (fun p q => q.2.val < p.2.val ∨ p.1 ≠ q.1) := by
  rw [historyLabels, List.pairwise_flatten]
  constructor
  · intro L hL
    obtain ⟨i, rfl⟩ := List.mem_ofFn.mp hL
    exact vertexLabels_pairwise d (I i) (u i)
  · apply List.pairwise_ofFn.mpr
    intro i j hij p hp q hq
    obtain ⟨a, rfl⟩ := List.mem_ofFn.mp hp
    obtain ⟨b, rfl⟩ := List.mem_ofFn.mp hq
    exact Or.inl (hu hij)

/-- The genuine ordered quartic matrix history equals the actual exterior
Wick expectation at all strictly ordered interaction times. No Wick
correspondence is assumed in the proof. -/
theorem ordered_vertex_trace_eq_wick (d : ℕ) {β : ℝ} (hβ : 0 < β) {k : ℕ}
    (I : Fin k → Majorana.FourSet d) (u : Fin k → ThermalWick.Time β)
    (hu : StrictAnti (fun i => (u i).val)) :
    Majorana.normalizedTrace d (orderedProduct (fun i => Majorana.quartic d (I i))) =
      ThermalWick.expectation (2*d) β
        (orderedProduct (fun i => ThermalWick.quarticField d (I i) (u i))) := by
  have he : Even (historyLabels d I u).length := by
    rw [historyLabels_length]
    exact Even.mul_left (by decide : Even 4) k
  simpa only [historyLabels_operator_word, historyLabels_exterior_word] using
    FreeWick.thermal_trace_of_ordered_equal_flavors d β hβ
      (historyLabels d I u) he (historyLabels_pairwise d I u hu)

/-- Uniform quartic Wick coefficient bound, including arbitrary interaction
collisions, derived from the concrete free operator model. -/
theorem wick_vertex_history_bound (d : ℕ) {β : ℝ} (hβ : 0 < β) {k : ℕ}
    (I : Fin k → Majorana.FourSet d) (u : Fin k → ThermalWick.Time β) :
    ‖ThermalWick.expectation (2*d) β
      (orderedProduct (fun i => ThermalWick.quarticField d (I i) (u i)))‖ ≤ (1/4 : ℝ)^k := by
  have he : Even (historyLabels d I u).length := by
    rw [historyLabels_length]
    exact Even.mul_left (by decide : Even 4) k
  have h := FreeWeyl.expectation_word_bound d hβ (historyLabels d I u) he
  rw [historyLabels_exterior_word, historyLabels_length, Nat.mul_comm k 4, pow_mul] at h
  have hq : ((Real.sqrt 2)⁻¹ : ℝ)^4 = 1/4 := by
    rw [show (4 : ℕ) = 2*2 by norm_num, pow_mul, inv_pow, Real.sq_sqrt (by norm_num)]
    norm_num
  simpa only [hq] using h

/-- Dependent version: the number of vertex choices may differ from gap
to gap. The independent choice space is exactly the dependent function type. -/
theorem orderedProduct_sum_pi {A : Type*} [Semiring A] {k : ℕ}
    (ι : Fin k → Type*) [∀ i, Fintype (ι i)] (F : (i : Fin k) → ι i → A) :
    orderedProduct (fun i => ∑ a, F i a) =
      ∑ a : (i : Fin k) → ι i, orderedProduct (fun i => F i (a i)) := by
  classical
  induction k with
  | zero => simp
  | succ k ih =>
    rw [orderedProduct_succ, ih]
    rw [Finset.sum_mul_sum]
    rw [← Fintype.sum_prod_type (fun a : ι 0 × ((i : Fin k) → ι i.succ) =>
      F 0 a.1 * orderedProduct (fun i => F i.succ (a.2 i)))]
    exact Fintype.sum_equiv (Fin.consEquiv ι) _ _ (by
      intro a
      simp only [Fin.consEquiv, Equiv.coe_fn_mk, orderedProduct_succ,
        Fin.cons_zero, Fin.cons_succ])

/-- Every unintegrated multi-gap coefficient expands into genuine quartic
matrix histories with the complete actual disorder monomial. -/
theorem hamiltonian_history_expansion (d : ℕ) {k : ℕ}
    (j : Majorana.FourSet d → ℝ) (r : Fin k → ℕ)
    (U : Fin k → Matrix (Majorana.Basis d) (Majorana.Basis d) ℂ) :
    orderedProduct (fun g => (-Majorana.hamiltonian d j)^(r g) * U g) =
      ∑ I : (g : Fin k) → Fin (r g) → Majorana.FourSet d,
        (∏ g, ∏ a, (j (I g a) : ℂ)) • orderedProduct
          (fun g => orderedProduct (fun a => Majorana.quartic d (I g a)) * U g) := by
  simp_rw [neg_hamiltonian_pow, Finset.sum_mul, smul_mul_assoc]
  rw [orderedProduct_sum_pi]
  apply Finset.sum_congr rfl
  intro I _
  exact orderedProduct_smul _ _

/-- Each genuine gap coefficient is exactly a Lebesgue integral over its
actual dependent product of ordered time simplices. This is the first
continuous-time Duhamel bridge, with no integral identity assumed. -/
theorem gapCoefficient_eq_integral (d : ℕ) {k : ℕ}
    (H : Matrix (Majorana.Basis d) (Majorana.Basis d) ℂ)
    (r : Fin k → ℕ) (a b : Fin k → ℝ) (hab : ∀ i, a i ≤ b i)
    (U : Fin k → Matrix (Majorana.Basis d) (Majorana.Basis d) ℂ) :
    gapCoefficient d H (fun i => b i-a i) U r =
      ∫ _u in GapSimplexIntegral.gapSimplex r a b,
        Majorana.normalizedTrace d (orderedProduct (fun i => (-H)^(r i) * U i)) := by
  have h := GapSimplexIntegral.integral_gap_history_observable r a b hab
    (fun _ => -CStarMatrix.ofMatrix H) (fun i => CStarMatrix.ofMatrix (U i)) (normalizedTraceCLM d)
  have hn (i : Fin k) : (((b i-a i : ℝ) : ℂ) • -CStarMatrix.ofMatrix H) =
      (-((b i-a i : ℝ) : ℂ)) • CStarMatrix.ofMatrix H := by rw [smul_neg, neg_smul]
  simp_rw [hn] at h
  change (∫ _u in GapSimplexIntegral.gapSimplex r a b,
    normalizedTraceCLM d (CStarMatrix.ofMatrix
      (orderedProduct (fun i => (-H)^(r i) * U i)))) = gapCoefficient d H _ U r at h
  simpa only [normalizedTraceCLM_ofMatrix] using h.symm

/-- Arbitrary even external field insertions retain the exact free Wick
vertex majorant, including every external or interaction endpoint collision. -/
theorem wick_inserted_vertex_history_bound (d : ℕ) {β : ℝ} (hβ : 0 < β) {k : ℕ}
    (L : List (ThermalWick.Label (2*d) β)) (hL : Even L.length)
    (I : Fin k → Majorana.FourSet d) (u : Fin k → ThermalWick.Time β) :
    ‖ThermalWick.expectation (2*d) β
      (FreeWick.word (fun p => ThermalWick.field p.1 p.2) L *
        orderedProduct (fun i => ThermalWick.quarticField d (I i) (u i)))‖ ≤
      ((Real.sqrt 2)⁻¹)^L.length * (1/4 : ℝ)^k := by
  have he : Even (L ++ historyLabels d I u).length := by
    rw [List.length_append, historyLabels_length]
    exact hL.add (Even.mul_left (by decide : Even 4) k)
  have h := FreeWeyl.expectation_word_bound d hβ (L ++ historyLabels d I u) he
  rw [FreeWick.word_append, historyLabels_exterior_word, List.length_append,
    historyLabels_length, pow_add, Nat.mul_comm k 4, pow_mul] at h
  have hq : ((Real.sqrt 2)⁻¹ : ℝ)^4 = 1/4 := by
    rw [show (4 : ℕ) = 2*2 by norm_num, pow_mul, inv_pow, Real.sq_sqrt (by norm_num)]
    norm_num
  simpa only [hq] using h

end SYK.DuhamelVertex
