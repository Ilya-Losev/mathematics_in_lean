import ThermalMomentTransport
import MixedWeightedExtension
import KernelCoordinateGeneration

/-!
# The actual limiting moments on the weighted regularity quotient

The state is constructed from the seam-corrected microscopic subsequential
limit. The mixed weighted estimate follows from the explicit limiting Ward
replacement identity. Every canonical first-ideal relation is discharged.
-/

noncomputable section
namespace SYK.ThermalWeightedState
open SYK.WeightedKernelAlgebra SYK.ThermalEndpointLift SYK.ThermalMomentTransport
open SYK.MomentLimit SYK.MomentCompactness SYK.MixedIncrement
open SYK.KernelResidualAlgebra SYK.KernelCoordinateGeneration
open MeasureTheory Filter Set
open scoped BigOperators Topology NNReal

variable (β : ℝ) (hβ : 0 < β) (lam : ℝ≥0) (d : ℕ → ℕ) (hd : ∀ n, 0 < d n)
  (g : ∀ k, EndpointCube β k → ℂ)
  (hg : ∀ k, TendstoUniformly
    (fun n => functionalCenteredMoment (actualCorrectedPolynomial β hβ (d n) lam)) (g k) atTop)

/-- The concrete all-real limiting functional, before completion. -/
abbrev polynomialState : RealPolynomial →ₗ[ℂ] ℂ := liftFunctional β hβ (limitPolynomial β g)

include hd hg in
/-- The actual limiting pure moments satisfy the sharp bound needed by the
mixed-increment Ward induction. -/
theorem polynomialState_plain_bound (p : List Endpoint) :
    ‖polynomialState β hβ g (coordinateProduct p)‖ ≤ (1/2 : ℝ)^p.length :=
  (thermalLimit_bound β hβ lam d g hg hd _).trans
    (coefficientNorm_coordinateProduct (1/2) (by norm_num) p)

include hg in
/-- Canonical skewness, separate antiperiodicity and the midpoint diagonal
are all annihilated with arbitrary mixed polynomial insertions. -/
theorem polynomialState_symmetry (P : MvPolynomial KernelIndex ℂ) (j : SymmetryIndex) :
    polynomialState β hβ g (substitutePolynomial β (P * symmetryRelations β j)) = 0 := by
  rw [map_mul]
  cases j with
  | skew p =>
    simp only [symmetryRelations, map_add, substitutePolynomial_coordinate, mul_add]
    rw [thermalLimit_inserted_skew β hβ lam d g hg, neg_add_cancel]
  | antiperiodicLeft p =>
    simp only [symmetryRelations, map_add, substitutePolynomial_coordinate, mul_add]
    change liftFunctional β hβ (limitPolynomial β g) _ + liftFunctional β hβ (limitPolynomial β g) _ = 0
    rw [liftFunctional_antiperiodic_left, neg_add_cancel]
  | antiperiodicRight p =>
    simp only [symmetryRelations, map_add, substitutePolynomial_coordinate, mul_add]
    change liftFunctional β hβ (limitPolynomial β g) _ + liftFunctional β hβ (limitPolynomial β g) _ = 0
    rw [liftFunctional_antiperiodic_right, neg_add_cancel]
  | diagonal t =>
    simp only [symmetryRelations, substitutePolynomial_coordinate]
    exact thermalLimit_inserted_diagonal β hβ lam d g hg _ t

include hg in
/-- The substitution relations vanish identically, and the remaining
canonical relations vanish by actual microscopic symmetry transport. -/
theorem polynomialState_relations (P : MvPolynomial KernelIndex ℂ)
    (j : IncrementIndex ⊕ SymmetryIndex) :
    polynomialState β hβ g
      (substitutePolynomial β (P * kernelRelations (thermalCovariance β) (symmetryRelations β) j)) = 0 := by
  cases j with
  | inl pq =>
    rw [map_mul]
    have h := substituted_increment_relation β (symmetryRelations β) pq
    change substitutePolynomial β (kernelRelations (thermalCovariance β) (symmetryRelations β) (.inl pq)) = 0 at h
    rw [h, mul_zero, map_zero]
  | inr j => exact polynomialState_symmetry β hβ lam d g hg P j


include hd hg in
/-- For the actual limiting state, both measurability and sharp bounds in the
replacement theorem are discharged. Its only analytic inputs are the two
limiting inserted Ward equations. -/
theorem polynomialState_replacement
    (hleft : ∀ Q s t, polynomialState β hβ g (Q*SYK.MixedIncrement.remainder β (s,t)) =
      (lam:ℂ)*(∫ u in (0:ℝ)..β, ∫ v in (0:ℝ)..β,
        (Thermal.kernel β s u:ℂ)*polynomialState β hβ g
          (Q*coordinateProduct [(u,v),(u,v),(u,v),(v,t)])))
    (hright : ∀ Q s t, polynomialState β hβ g (Q*SYK.MixedIncrement.remainder β (s,t)) =
      (lam:ℂ)*(∫ u in (0:ℝ)..β, ∫ v in (0:ℝ)..β,
        (Thermal.kernel β v t:ℂ)*polynomialState β hβ g
          (Q*coordinateProduct [(s,u),(u,v),(u,v),(u,v)]))) :
    ReplacementIdentity β (lam : ℝ) (polynomialState β hβ g) := by
  apply replacement_of_inserted_ward β (lam : ℝ) hβ.le _
    (thermalLimit_bound β hβ lam d g hg hd) ?_ ?_ hleft hright
  · intro Q t
    have h := thermalLimit_inserted_measurable β hβ lam d g hg Q
      (fun p : ℝ×ℝ => ![(p.1,p.2),(p.1,p.2),(p.1,p.2),(p.2,t)]) (by
        intro i
        fin_cases i <;> dsimp <;> fun_prop)
    simpa only [coordinateProduct, List.map_cons, List.map_nil, List.prod_cons,
      List.prod_nil, Fin.prod_univ_succ, Fin.prod_univ_zero, Fin.cons_zero,
      Fin.cons_succ, mul_one] using h
  · intro Q s
    have h := thermalLimit_inserted_measurable β hβ lam d g hg Q
      (fun p : ℝ×ℝ => ![(s,p.1),(p.1,p.2),(p.1,p.2),(p.1,p.2)]) (by
        intro i
        fin_cases i <;> dsimp <;> fun_prop)
    simpa only [coordinateProduct, List.map_cons, List.map_nil, List.prod_cons,
      List.prod_nil, Fin.prod_univ_succ, Fin.prod_univ_zero, Fin.cons_zero,
      Fin.cons_succ, mul_one] using h

variable (K : ℝ) (hK : 0 < K) (hKlarge : (lam : ℝ)*β*(1/2:ℝ)^4 ≤ K)
  (hrep : ReplacementIdentity β (lam : ℝ) (polynomialState β hβ g))

include hd hg hKlarge hrep in
/-- The required mixed monomial bound is derived from the limiting inserted
Ward replacement, rather than assumed as a separate weighted-state axiom. -/
theorem mixedMoment_bound (e : KernelIndex →₀ ℕ) :
    ‖substitutedMoment β (polynomialState β hβ g) e‖ ≤
      monomialWeight (kernelWeights (1/2) K (by norm_num) hK).value e :=
  substituted_monomial_bound β (lam : ℝ) (1/2) K hβ lam.coe_nonneg
    (by norm_num) hK hKlarge _ hrep (polynomialState_plain_bound β hβ lam d hd g hg) e

include hg in
theorem mixedMoment_relations (P : MvPolynomial KernelIndex ℂ) (j : IncrementIndex ⊕ SymmetryIndex) :
    WeightedPolynomial.momentLinear (kernelWeights (1/2) K (by norm_num) hK)
      (substitutedMoment β (polynomialState β hβ g))
      (WeightedPolynomial.ofPolynomial _ (P * kernelRelations (thermalCovariance β) (symmetryRelations β) j)) = 0 := by
  rw [momentLinear_substitution]
  exact polynomialState_relations β hβ lam d g hg P j

/-- Actual continuous moment functional on the first closed-ideal quotient. -/
def regularityState : RegularityAlgebra (1/2) K (by norm_num) hK
    (thermalCovariance β) (symmetryRelations β) →L[ℂ] ℂ :=
  RelationQuotient.quotientMomentFunctional _ _
    (substitutedMoment β (polynomialState β hβ g))
    (mixedMoment_bound β hβ lam d hd g hg K hK hKlarge hrep)
    (mixedMoment_relations β hβ lam d g hg K hK)

/-- The continuous quotient state agrees exactly with the limiting
microscopic polynomial functional after literal increment substitution. -/
theorem regularityState_polynomial (P : MvPolynomial KernelIndex ℂ) :
    regularityState β hβ lam d hd g hg K hK hKlarge hrep
      (polynomialMap (1/2) K (by norm_num) hK (thermalCovariance β) (symmetryRelations β) P) =
        polynomialState β hβ g (substitutePolynomial β P) := by
  change WeightedAlgebra.momentFunctional _ _ _ (WeightedAlgebra.ofPolynomial _ P) = _
  rw [WeightedAlgebra.momentFunctional_ofPolynomial, momentLinear_substitution]

@[simp] theorem regularityState_one :
    regularityState β hβ lam d hd g hg K hK hKlarge hrep 1 = 1 := by
  simpa only [map_one, polynomialState, thermalLimit_one β hβ lam d g hg] using
    regularityState_polynomial β hβ lam d hd g hg K hK hKlarge hrep 1

include hd hg hKlarge hrep in
/-- The actual normalized state proves that the canonical first ideal is
proper; no nontriviality of the quotient is assumed. -/
theorem regularityAlgebra_nontrivial : Nontrivial (RegularityAlgebra (1/2) K (by norm_num) hK
    (thermalCovariance β) (symmetryRelations β)) := by
  exact RelationQuotient.nontrivial_of_normalized_moments _ _ _
    (mixedMoment_bound β hβ lam d hd g hg K hK hKlarge hrep)
    (mixedMoment_relations β hβ lam d g hg K hK)
    (substitutedMoment_zero β _ (thermalLimit_one β hβ lam d g hg))

/-- The quotient state has norm at most one. -/
theorem regularityState_bound (a : RegularityAlgebra (1/2) K (by norm_num) hK
    (thermalCovariance β) (symmetryRelations β)) :
    ‖regularityState β hβ lam d hd g hg K hK hKlarge hrep a‖ ≤ ‖a‖ :=
  RelationQuotient.descendLinear_bound _ _ _ _ (WeightedAlgebra.momentFunctional_bound _ _ _) a


/-- Exact recovery of every bilocal tuple moment in the constructed quotient. -/
theorem regularityState_tuple {k : ℕ} (p : Fin k → Endpoint) :
    regularityState β hβ lam d hd g hg K hK hKlarge hrep
      (∏ i, coordinate (1/2) K (by norm_num) hK (thermalCovariance β) (symmetryRelations β) (p i)) =
        polynomialState β hβ g (∏ i, MvPolynomial.X (p i)) := by
  simpa only [map_prod, polynomialMap_coordinate, substitutePolynomial_coordinate] using
    regularityState_polynomial β hβ lam d hd g hg K hK hKlarge hrep (∏ i, MvPolynomial.X (.inl (p i)))

/-- The finite-size thermal tuples converge uniformly to their genuine
continuous-state moments in the weighted regularity quotient. -/
theorem actual_moments_to_regularityState (k : ℕ) :
    TendstoUniformly
      (fun n (p : Fin k → Endpoint) => actualThermalPolynomial β hβ (d n) lam (∏ i, MvPolynomial.X (p i)))
      (fun p => regularityState β hβ lam d hd g hg K hK hKlarge hrep
        (∏ i, coordinate (1/2) K (by norm_num) hK (thermalCovariance β) (symmetryRelations β) (p i))) atTop := by
  simpa only [regularityState_tuple] using actualThermal_moments_tendstoUniformly β hβ lam d g hg k

end SYK.ThermalWeightedState
