import WeylBlockFactorization
import ThermalMomentTransport
import KernelAlgebraActions
import Mathlib.GroupTheory.Perm.Fin

/-! Actual thermal time-translation invariance with complete Weyl sorting and
canonical signed thermal representatives. No stationarity hypothesis is used. -/
noncomputable section
open scoped BigOperators NNReal
namespace SYK.WeylTranslation
open Interacting WeylBlocks MomentSymmetry

variable {ν : Type*} [Fintype ν] [DecidableEq ν]

/-- Powers of the actual cyclic permutation implement modular addition. -/
theorem finRotate_pow_apply (n r : ℕ) (i : Fin (n+1)) :
    ((finRotate (n+1))^r) i = i + r := by
  induction r generalizing i with
  | zero => simp
  | succ r ih =>
    rw [pow_succ, Equiv.Perm.mul_apply, finRotate_succ_apply, ih]
    push_cast
    ac_rfl

def blockRotation (k l : ℕ) : Equiv.Perm (Fin (k+l)) := (finRotate (k+l))^k

/-- For an even total number of fields the cyclic block sign is exactly the
product of the thermal winding signs of the moved block. -/
theorem blockRotation_sign (k l : ℕ) (he : Even (k+l)) :
    Equiv.Perm.sign (blockRotation k l) = (-1 : ℤˣ)^k := by
  unfold blockRotation
  rw [map_pow]
  by_cases hn : k+l = 0
  · have hk : k = 0 := by omega
    simp [hk]
  · obtain ⟨n, hN⟩ := Nat.exists_eq_succ_of_ne_zero hn
    rw [hN, sign_finRotate]
    have ho : Odd n := by simpa only [hN, Nat.even_add_one, Nat.not_even_iff_odd] using he
    rw [ho.neg_one_pow]

theorem blockRotation_val (k l : ℕ) (i : Fin (k+l)) :
    (blockRotation k l i).val = (i.val+k) % (k+l) := by
  unfold blockRotation
  generalize hn : k+l = n at i ⊢
  cases n with
  | zero => exact Fin.elim0 i
  | succ n =>
    rw [finRotate_pow_apply]
    simp [Fin.val_add, Nat.add_mod_mod]

theorem blockRotation_left (k l : ℕ) (i : Fin l) :
    blockRotation k l (Fin.cast (Nat.add_comm l k) (i.castAdd k)) = i.natAdd k := by
  apply Fin.ext
  rw [blockRotation_val]
  change (i.val+k) % (k+l) = k+i.val
  rw [Nat.mod_eq_of_lt (by omega : i.val+k < k+l)]
  omega

theorem blockRotation_right (k l : ℕ) (i : Fin k) :
    blockRotation k l (Fin.cast (Nat.add_comm l k) (i.natAdd l)) = i.castAdd l := by
  apply Fin.ext
  rw [blockRotation_val]
  change (l+i.val+k) % (k+l) = i.val
  rw [show l+i.val+k = i.val+(k+l) by omega, Nat.add_mod_right]
  exact Nat.mod_eq_of_lt (by omega)

theorem append_comp_blockRotation {α : Type*} {k l : ℕ} (A : Fin k → α) (B : Fin l → α) :
    Fin.append A B ∘ blockRotation k l = Fin.append B A ∘ Fin.cast (Nat.add_comm k l) := by
  funext i
  let j : Fin (l+k) := Fin.cast (Nat.add_comm k l) i
  have hi : i = Fin.cast (Nat.add_comm l k) j := rfl
  rw [hi]
  refine Fin.addCases (fun q => ?_) (fun q => ?_) j <;>
    simp only [Function.comp_def, blockRotation_left, blockRotation_right,
      Fin.append_left, Fin.append_right, Fin.cast_trans, Fin.cast_refl, id_eq]

theorem weylNumerator_cast {k l : ℕ} (h : k=l) (H : Matrix ν ν ℂ) (a : ℝ)
    (t : Fin l → ℝ) (A : Fin l → Matrix ν ν ℂ) :
    weylNumerator H a (t ∘ Fin.cast h) (A ∘ Fin.cast h) = weylNumerator H a t A := by
  subst l
  rfl

/-- Exchanging two complete Weyl blocks has the exact cyclic fermionic sign. -/
theorem weylNumerator_swap_blocks (H : Matrix ν ν ℂ) (a : ℝ) {k l : ℕ}
    (he : Even (k+l)) (t : Fin k → ℝ) (u : Fin l → ℝ)
    (A : Fin k → Matrix ν ν ℂ) (B : Fin l → Matrix ν ν ℂ) :
    weylNumerator H a (Fin.append u t) (Fin.append B A) =
      (-1 : ℤˣ)^k • weylNumerator H a (Fin.append t u) (Fin.append A B) := by
  have h := weylNumerator_relabel H a (Fin.append t u) (Fin.append A B) (blockRotation k l)
  rw [append_comp_blockRotation, append_comp_blockRotation, weylNumerator_cast,
    blockRotation_sign k l he] at h
  exact h

/-- Moving an arbitrary separated group of fields around the thermal circle
is cyclicity of the two actual transfer factors, with every tied block intact. -/
theorem weylNumerator_cut_shift (H : Matrix ν ν ℂ) (β c : ℝ) {k l : ℕ}
    (he : Even (k+l)) (t : Fin k → ℝ) (u : Fin l → ℝ)
    (hsep : ∀ i j, u j < t i)
    (hsep' : ∀ i j, t i-c < u j+(β-c))
    (A : Fin k → Matrix ν ν ℂ) (B : Fin l → Matrix ν ν ℂ) :
    weylNumerator H β (Fin.append (fun i => t i-c) (fun j => u j+(β-c))) (Fin.append A B) =
      (-1 : ℤˣ)^k • weylNumerator H β (Fin.append t u) (Fin.append A B) := by
  have hswap := weylNumerator_swap_blocks H β (show Even (l+k) by simpa [add_comm] using he)
    (fun j => u j+(β-c)) (fun i => t i-c) B A
  have htrace : weylNumerator H β (Fin.append (fun j => u j+(β-c)) (fun i => t i-c))
      (Fin.append B A) = weylNumerator H β (Fin.append t u) (Fin.append A B) := by
    rw [← trace_weylTransfer, ← trace_weylTransfer,
      weylTransfer_append H β (β-c) _ _ (fun j i => hsep' i j),
      weylTransfer_append H β c _ _ hsep]
    simp only [sub_sub_cancel, add_sub_cancel_right]
    exact Matrix.trace_mul_comm _ _
  rw [hswap, htrace]
  have hpar : (-1 : ℤˣ)^l = (-1 : ℤˣ)^k := by
    have hm : (-1 : ℤˣ)^(k+l) = 1 := he.neg_one_pow
    rw [pow_add] at hm
    have hk : ((-1 : ℤˣ)^k)*((-1 : ℤˣ)^k) = 1 := Int.units_mul_self _
    exact mul_left_cancel (hm.trans hk.symm)
  rw [hpar]

/-- A reindexing between equally sized finite types has one fixed alternating
sign, independent of every time, matrix and thermal parameter. -/
theorem weylNumerator_reindex_factor {k n : ℕ} (e : Fin k ≃ Fin n) :
    ∃ ε : ℤˣ, ∀ (H : Matrix ν ν ℂ) (β : ℝ) (t : Fin n → ℝ) (A : Fin n → Matrix ν ν ℂ),
      weylNumerator H β (t ∘ e) (A ∘ e) = ε • weylNumerator H β t A := by
  have h : k = n := by simpa using Fintype.card_congr e
  subst n
  exact ⟨Equiv.Perm.sign e, fun H β t A => weylNumerator_relabel H β t A e⟩

def cutWrap (β c t : ℝ) : ℝ := if c ≤ t then t-c else t+(β-c)
def cutSign (c t : ℝ) : ℤˣ := if c ≤ t then -1 else 1

/-- Exact even-word thermal cyclicity for an arbitrary cut. It includes ties
at the cut and keeps the complete Weyl average rather than selecting one order. -/
theorem weylNumerator_wrap (H : Matrix ν ν ℂ) (β c : ℝ) {n : ℕ}
    (hn : Even n) (t : Fin n → ℝ) (ht : ∀ i, 0 ≤ t i ∧ t i < β)
    (A : Fin n → Matrix ν ν ℂ) :
    weylNumerator H β (fun i => cutWrap β c (t i)) A =
      (∏ i, cutSign c (t i)) • weylNumerator H β t A := by
  classical
  let S : Set (Fin n) := {i | c ≤ t i}
  let k := Fintype.card S
  let l := Fintype.card ↥(Sᶜ)
  let e : Fin (k+l) ≃ Fin n := finSumFinEquiv.symm.trans
    ((Equiv.sumCongr (Fintype.equivFin S).symm (Fintype.equivFin ↥(Sᶜ)).symm).trans
      (Equiv.Set.sumCompl S))
  let th : Fin k → ℝ := fun i => t (e (i.castAdd l))
  let tl : Fin l → ℝ := fun i => t (e (i.natAdd k))
  let Ah : Fin k → Matrix ν ν ℂ := fun i => A (e (i.castAdd l))
  let Al : Fin l → Matrix ν ν ℂ := fun i => A (e (i.natAdd k))
  have hhigh (i : Fin k) : c ≤ th i := by
    dsimp only [th, e]
    simp only [Equiv.trans_apply, finSumFinEquiv_symm_apply_castAdd,
      Equiv.sumCongr_apply, Sum.map_inl, Equiv.Set.sumCompl_apply_inl]
    exact ((Fintype.equivFin S).symm i).property
  have hlow (i : Fin l) : tl i < c := by
    have hi := ((Fintype.equivFin ↥(Sᶜ)).symm i).property
    apply lt_of_not_ge
    dsimp only [tl, e]
    simp only [Equiv.trans_apply, finSumFinEquiv_symm_apply_natAdd,
      Equiv.sumCongr_apply, Sum.map_inr, Equiv.Set.sumCompl_apply_inr]
    exact hi
  have hcard : k+l = n := by simpa only [Fintype.card_fin] using Fintype.card_congr e
  have heven : Even (k+l) := hcard.symm ▸ hn
  have heq : t ∘ e = Fin.append th tl := (Fin.append_castAdd_natAdd).symm
  have hAe : A ∘ e = Fin.append Ah Al := (Fin.append_castAdd_natAdd).symm
  have hwrap : (fun i => cutWrap β c (t i)) ∘ e =
      Fin.append (fun i => th i-c) (fun i => tl i+(β-c)) := by
    funext i
    refine Fin.addCases (fun j => ?_) (fun j => ?_) i
    · simp only [Function.comp_def, Fin.append_left, cutWrap, show c ≤ t (e (j.castAdd l)) from hhigh j, if_true]
      rfl
    · simp only [Function.comp_def, Fin.append_right, cutWrap,
        show ¬c ≤ t (e (j.natAdd k)) from not_le.mpr (hlow j), if_false]
      rfl
  have hsign : (∏ i, cutSign c (t i)) = (-1 : ℤˣ)^k := by
    rw [← e.prod_comp]
    rw [Fin.prod_univ_add]
    have hh (i : Fin k) : cutSign c (t (e (i.castAdd l))) = -1 := if_pos (hhigh i)
    have hl (i : Fin l) : cutSign c (t (e (i.natAdd k))) = 1 := if_neg (not_le.mpr (hlow i))
    simp only [hh, hl, Finset.prod_const, Finset.card_univ, Fintype.card_fin, one_pow, mul_one]
  obtain ⟨ε,hε⟩ := weylNumerator_reindex_factor (ν := ν) e
  have hnew := hε H β (fun i => cutWrap β c (t i)) A
  have hold := hε H β t A
  rw [hwrap, hAe] at hnew
  rw [heq, hAe] at hold
  have hcut := weylNumerator_cut_shift H β c heven th tl
    (fun i j => (hlow j).trans_le (hhigh i))
    (fun i j => by
      have hi := (ht (e (i.castAdd l))).2
      have hj := (ht (e (j.natAdd k))).1
      change th i < β at hi
      change 0 ≤ tl j at hj
      linarith) Ah Al
  rw [hold, hnew, smul_comm] at hcut
  rw [hsign]
  exact (smul_left_cancel_iff ε).mp hcut

open ThermalEndpointLift
variable (β : ℝ) (hβ : 0 < β)

theorem representative_add_reduce (s u : ℝ) :
    representative β hβ (s+u) = representative β hβ ((representative β hβ s : ℝ)+u) := by
  apply Subtype.ext
  change toIcoMod hβ 0 (s+u) = toIcoMod hβ 0 (toIcoMod hβ 0 s+u)
  have he : toIcoMod hβ 0 s+u+toIcoDiv hβ 0 s • β = s+u := by
    have h := toIcoMod_add_toIcoDiv_zsmul hβ 0 s
    linarith
  rw [← he, toIcoMod_add_zsmul]

theorem endpointSign_add_reduce (s u : ℝ) :
    endpointSign β hβ (s+u) =
      endpointSign β hβ s * endpointSign β hβ ((representative β hβ s : ℝ)+u) := by
  have he : (representative β hβ s : ℝ)+u+periodNumber β hβ s • β = s+u := by
    have h := toIcoMod_add_toIcoDiv_zsmul hβ 0 s
    change (representative β hβ s : ℝ)+periodNumber β hβ s • β = s at h
    linarith
  rw [← he]
  simp only [endpointSign, periodNumber, toIcoDiv_add_zsmul, Int.negOnePow_add,
    Units.val_mul, Int.cast_mul]
  ring

theorem representative_cut (s u : ℝ) (hs : s ∈ Set.Ico 0 β) (hu : u ∈ Set.Ico 0 β) :
    (representative β hβ (s+u) : ℝ) = cutWrap β (β-u) s := by
  unfold cutWrap
  split_ifs with h
  · have hm : s+u-β ∈ Set.Ico 0 β := ⟨by linarith [hs.1,hu.1], by linarith [hs.2,hu.2]⟩
    rw [show s+u = (s+u-β)+β by ring, representative_add_period,
      representative_of_mem β hβ hm]
    ring
  · have hm : s+u ∈ Set.Ico 0 β := ⟨by linarith [hs.1,hu.1], by linarith⟩
    rw [representative_of_mem β hβ hm]
    ring

theorem endpointSign_cut (s u : ℝ) (hs : s ∈ Set.Ico 0 β) (hu : u ∈ Set.Ico 0 β) :
    endpointSign β hβ (s+u) = ((cutSign (β-u) s : ℤ) : ℂ) := by
  unfold cutSign
  split_ifs with h
  · have hm : s+u-β ∈ Set.Ico 0 β := ⟨by linarith [hs.1,hu.1], by linarith [hs.2,hu.2]⟩
    rw [show s+u = (s+u-β)+β by ring, endpointSign_add_period,
      endpointSign_of_mem β hβ hm]
    norm_num
  · have hm : s+u ∈ Set.Ico 0 β := ⟨by linarith [hs.1,hu.1], by linarith⟩
    rw [endpointSign_of_mem β hβ hm]
    norm_num

/-- The actual signed thermal continuation of a full Weyl word. -/
def thermalNumerator {n : ℕ} (H : Matrix ν ν ℂ) (t : Fin n → ℝ)
    (A : Fin n → Matrix ν ν ℂ) : ℂ :=
  (∏ i, endpointSign β hβ (t i)) *
    weylNumerator H β (fun i => (representative β hβ (t i) : ℝ)) A

theorem unit_smul_complex (ε : ℤˣ) (z : ℂ) : ε • z = ((ε : ℤ) : ℂ) * z := by
  rcases Int.units_eq_one_or ε with h | h <;> rw [h] <;> simp

theorem thermalNumerator_primary_shift (H : Matrix ν ν ℂ) {n : ℕ} (hn : Even n)
    (t : Fin n → ℝ) (ht : ∀ i, t i ∈ Set.Ico 0 β) (A : Fin n → Matrix ν ν ℂ)
    (u : ℝ) (hu : u ∈ Set.Ico 0 β) :
    thermalNumerator β hβ H (fun i => t i+u) A = weylNumerator H β t A := by
  unfold thermalNumerator
  simp_rw [representative_cut β hβ _ u (ht _) hu, endpointSign_cut β hβ _ u (ht _) hu]
  rw [weylNumerator_wrap H β (β-u) hn t ht A, unit_smul_complex]
  have hp : (∏ i, (((cutSign (β-u) (t i)) : ℤ) : ℂ)) =
      (((∏ i, cutSign (β-u) (t i) : ℤˣ) : ℤ) : ℂ) := by simp
  rw [hp, ← mul_assoc]
  have he (ε : ℤˣ) : ((ε : ℤ) : ℂ) * ((ε : ℤ) : ℂ) = 1 := by
    rcases Int.units_eq_one_or ε with h | h <;> rw [h] <;> norm_num
  rw [he, one_mul]

theorem thermalNumerator_add_period (H : Matrix ν ν ℂ) {n : ℕ} (hn : Even n)
    (t : Fin n → ℝ) (A : Fin n → Matrix ν ν ℂ) :
    thermalNumerator β hβ H (fun i => t i+β) A = thermalNumerator β hβ H t A := by
  unfold thermalNumerator
  simp_rw [representative_add_period, endpointSign_add_period]
  have hp : (∏ i, -endpointSign β hβ (t i)) =
      (-1 : ℂ)^n * (∏ i, endpointSign β hβ (t i)) := by
    calc
      _ = ∏ i, (-1 : ℂ) * endpointSign β hβ (t i) := by
        apply Finset.prod_congr rfl
        intro i _
        ring
      _ = _ := by rw [Finset.prod_mul_distrib]; simp
  rw [hp, hn.neg_one_pow, one_mul]

theorem thermalNumerator_primary_translation (H : Matrix ν ν ℂ) {n : ℕ} (hn : Even n)
    (t : Fin n → ℝ) (ht : ∀ i, t i ∈ Set.Ico 0 β) (A : Fin n → Matrix ν ν ℂ)
    (u : ℝ) : thermalNumerator β hβ H (fun i => t i+u) A = weylNumerator H β t A := by
  let F : ℝ → ℂ := fun v => thermalNumerator β hβ H (fun i => t i+v) A
  have hp : Function.Periodic F β := by
    intro v
    simpa only [F, add_assoc] using thermalNumerator_add_period β hβ H hn (fun i => t i+v) A
  have hr : F (representative β hβ u) = F u := by
    change F (u-toIcoDiv hβ 0 u • β) = F u
    exact hp.sub_zsmul_eq _
  change F u = _
  rw [← hr]
  exact thermalNumerator_primary_shift β hβ H hn t ht A _ (toIcoMod_mem_Ico' hβ u)

/-- Complete even-word stationarity on all real lifts, including every tie
and every integer thermal seam, with the midpoint-consistent Weyl convention. -/
theorem thermalNumerator_translation (H : Matrix ν ν ℂ) {n : ℕ} (hn : Even n)
    (t : Fin n → ℝ) (A : Fin n → Matrix ν ν ℂ) (u : ℝ) :
    thermalNumerator β hβ H (fun i => t i+u) A = thermalNumerator β hβ H t A := by
  have hred : thermalNumerator β hβ H (fun i => t i+u) A =
      (∏ i, endpointSign β hβ (t i)) *
        thermalNumerator β hβ H (fun i => (representative β hβ (t i) : ℝ)+u) A := by
    have hs : (∏ i, endpointSign β hβ (t i+u)) =
        ∏ i, endpointSign β hβ (t i) * endpointSign β hβ ((representative β hβ (t i) : ℝ)+u) := by
      apply Finset.prod_congr rfl
      intro i _
      exact endpointSign_add_reduce β hβ (t i) u
    have hr : (fun i => (representative β hβ (t i+u) : ℝ)) =
        (fun i => (representative β hβ ((representative β hβ (t i) : ℝ)+u) : ℝ)) := by
      funext i
      exact congrArg Subtype.val (representative_add_reduce β hβ (t i) u)
    unfold thermalNumerator
    rw [hs, hr, Finset.prod_mul_distrib, mul_assoc]
  have hh := thermalNumerator_primary_translation β hβ H hn
    (fun i => (representative β hβ (t i) : ℝ)) (fun i => toIcoMod_mem_Ico' hβ (t i)) A u
  rw [hred, hh]
  rfl

theorem pairTimes_map {m : ℕ} (p : Fin m → ℝ × ℝ) (f : ℝ → ℝ) :
    pairTimes (fun i => (f (p i).1, f (p i).2)) = fun j => f (pairTimes p j) := by
  funext j
  simp only [pairTimes]
  split_ifs <;> rfl

theorem pairSigns_product {m : ℕ} (p : Fin m → ℝ × ℝ) :
    (∏ j : Fin (m*2), endpointSign β hβ (pairTimes p j)) = ∏ i, pairSign β hβ (p i) := by
  rw [← finProdFinEquiv.prod_comp]
  simp only [Fintype.prod_prod_type, pairTimes_finProd]
  apply Finset.prod_congr rfl
  intro i _
  simp [Fin.prod_univ_two, pairSign]

def thermalCollectiveNumerator (d : ℕ) {m : ℕ}
    (H : Matrix (Majorana.Basis d) (Majorana.Basis d) ℂ) (p : Fin m → ℝ × ℝ) : ℂ :=
  (((2*d : ℕ) : ℂ)^m)⁻¹ * ∑ f : Fin m → Fin (2*d),
    thermalNumerator β hβ H (pairTimes p) (fun i => Majorana.chiFin d (pairFlavors f i))

theorem thermalCollectiveNumerator_formula (d : ℕ) {m : ℕ}
    (H : Matrix (Majorana.Basis d) (Majorana.Basis d) ℂ) (p : Fin m → ℝ × ℝ) :
    thermalCollectiveNumerator β hβ d H p = (∏ i, pairSign β hβ (p i)) *
      collectiveNumerator d H β
        (fun i => ((representative β hβ (p i).1 : ℝ), (representative β hβ (p i).2 : ℝ))) := by
  unfold thermalCollectiveNumerator thermalNumerator collectiveNumerator
  rw [pairTimes_map p (fun x => (representative β hβ x : ℝ))]
  simp only [pairSigns_product]
  rw [← Finset.mul_sum]
  ring

theorem thermalCollectiveNumerator_translation (d : ℕ) {m : ℕ}
    (H : Matrix (Majorana.Basis d) (Majorana.Basis d) ℂ) (p : Fin m → ℝ × ℝ) (u : ℝ) :
    thermalCollectiveNumerator β hβ d H (fun i => KernelAlgebraActions.translateEndpoint u (p i)) =
      thermalCollectiveNumerator β hβ d H p := by
  unfold thermalCollectiveNumerator
  change _ * (∑ f, thermalNumerator β hβ H
    (pairTimes (fun i => ((p i).1+u,(p i).2+u))) _) = _
  rw [pairTimes_map p (fun x => x+u)]
  simp only [thermalNumerator_translation β hβ H (show Even (m*2) from ⟨m, by omega⟩)]

open ThermalMomentTransport

theorem actualThermalPolynomial_tuple_integral (d : ℕ) (lam : ℝ≥0)
    {m : ℕ} (p : Fin m → ℝ × ℝ) :
    actualThermalPolynomial β hβ d lam (∏ i, MvPolynomial.X (p i)) =
      ((∫ j, (Majorana.partitionFunction d β j).re ∂(Microscopic.disorder d lam) : ℝ) : ℂ)⁻¹ *
        ∫ j, thermalCollectiveNumerator β hβ d (Majorana.hamiltonian d j) p
          ∂(Microscopic.disorder d lam) := by
  rw [actualThermalPolynomial_tuple]
  simp_rw [thermalCollectiveNumerator_formula]
  rw [MeasureTheory.integral_const_mul]
  unfold collectiveMoment
  ring

theorem actualThermalPolynomial_tuple_translation (d : ℕ) (lam : ℝ≥0)
    {m : ℕ} (p : Fin m → ℝ × ℝ) (u : ℝ) :
    actualThermalPolynomial β hβ d lam
      (∏ i, MvPolynomial.X (KernelAlgebraActions.translateEndpoint u (p i))) =
    actualThermalPolynomial β hβ d lam (∏ i, MvPolynomial.X (p i)) := by
  rw [actualThermalPolynomial_tuple_integral, actualThermalPolynomial_tuple_integral]
  simp_rw [thermalCollectiveNumerator_translation]

/-- Actual finite-N stationarity on every polynomial test. Includes arbitrary
real lifts, thermal seams and coincident endpoint blocks. -/
theorem actualThermalPolynomial_translation (d : ℕ) (lam : ℝ≥0)
    (P : RealPolynomial) (u : ℝ) :
    actualThermalPolynomial β hβ d lam
      (MvPolynomial.rename (KernelAlgebraActions.translateEndpoint u) P) =
      actualThermalPolynomial β hβ d lam P := by
  induction P using MvPolynomial.induction_on' with
  | monomial e c =>
    have hc : MvPolynomial.monomial e c = c • MvPolynomial.monomial e (1 : ℂ) := by
      rw [MvPolynomial.smul_monomial]; simp only [smul_eq_mul, mul_one]
    rw [hc, MomentLimit.monomial_eq_tuple_prod]
    simp only [map_smul, map_prod, MvPolynomial.rename_X]
    rw [actualThermalPolynomial_tuple_translation]
  | add P Q hP hQ => simp only [map_add, hP, hQ]

end SYK.WeylTranslation
