import InteractingMoments

/-! # Actual permutation symmetry of the microscopic collective moments

The symmetry is derived from the signed sorting-permutation definition, rather
than assumed as a property of an abstract moment functional.
-/
noncomputable section
open scoped BigOperators NNReal

namespace SYK.MomentSymmetry
open Interacting

variable {ν : Type*} [Fintype ν] [DecidableEq ν]

/-- Relabeling preserves the number of admissible sorting permutations. -/
theorem sortingPerms_card_relabel {k : ℕ} (t : Fin k → ℝ) (τ : Equiv.Perm (Fin k)) :
    (sortingPerms (t ∘ τ)).card = (sortingPerms t).card := by
  classical
  apply Finset.card_bij (fun σ _ => τ * σ)
  · intro σ hσ
    simpa only [mem_sortingPerms, Function.comp_assoc, Equiv.Perm.coe_mul] using hσ
  · intro σ _ ρ _ h; exact mul_left_cancel h
  · intro σ hσ
    refine ⟨τ⁻¹ * σ, ?_, by simp⟩
    rw [mem_sortingPerms] at hσ ⊢
    simpa only [Function.comp_def, Equiv.Perm.mul_apply, Equiv.Perm.apply_inv_self] using hσ

/-- The full operator Weyl numerator is alternating under arbitrary field relabeling. -/
theorem weylNumerator_relabel {k : ℕ} (H : Matrix ν ν ℂ) (β : ℝ)
    (t : Fin k → ℝ) (A : Fin k → Matrix ν ν ℂ) (τ : Equiv.Perm (Fin k)) :
    weylNumerator H β (t ∘ τ) (A ∘ τ) = Equiv.Perm.sign τ • weylNumerator H β t A := by
  classical
  have hsum : (∑ σ ∈ sortingPerms (t ∘ τ), Equiv.Perm.sign σ •
      Matrix.trace (timeProduct H β ((t ∘ τ) ∘ σ) ((A ∘ τ) ∘ σ))) =
      Equiv.Perm.sign τ • ∑ σ ∈ sortingPerms t, Equiv.Perm.sign σ •
        Matrix.trace (timeProduct H β (t ∘ σ) (A ∘ σ)) := by
    rw [Finset.smul_sum]
    apply Finset.sum_bij (fun σ _ => τ * σ)
    · intro σ hσ
      simpa only [mem_sortingPerms, Function.comp_assoc, Equiv.Perm.coe_mul] using hσ
    · intro σ _ ρ _ h; exact mul_left_cancel h
    · intro σ hσ
      refine ⟨τ⁻¹ * σ, ?_, by simp⟩
      rw [mem_sortingPerms] at hσ ⊢
      simpa only [Function.comp_def, Equiv.Perm.mul_apply, Equiv.Perm.apply_inv_self] using hσ
    · intro σ _
      rw [map_mul]
      rcases Int.units_eq_one_or (Equiv.Perm.sign τ) with h | h <;>
        simp [h, Equiv.Perm.coe_mul, Function.comp_assoc]
  unfold weylNumerator signedAverage
  rw [sortingPerms_card_relabel, hsum]
  rcases Int.units_eq_one_or (Equiv.Perm.sign τ) with h | h <;> simp [h]

/-- Reordering whole bilocals permutes two field copies in parallel. -/
def pairPerm {m : ℕ} (σ : Equiv.Perm (Fin m)) : Equiv.Perm (Fin (m*2)) :=
  finProdFinEquiv.permCongr (Equiv.prodCongrLeft (fun _ : Fin 2 => σ))

/-- The permutation of 2m fields induced by a bilocal permutation is even. -/
@[simp] theorem pairPerm_sign {m : ℕ} (σ : Equiv.Perm (Fin m)) :
    Equiv.Perm.sign (pairPerm σ) = 1 := by
  simp only [pairPerm, Equiv.Perm.sign_permCongr, Equiv.Perm.sign_prodCongrLeft,
    Finset.prod_const, Finset.card_univ, Fintype.card_fin]
  rw [pow_two, Int.units_mul_self]

/-- The first pair coordinate transforms exactly by the bilocal permutation. -/
@[simp] theorem pairPerm_divNat {m : ℕ} (σ : Equiv.Perm (Fin m)) (i : Fin (m*2)) :
    (pairPerm σ i).divNat = σ i.divNat := by
  have h := congrArg Prod.fst (finProdFinEquiv.symm_apply_apply (σ i.divNat, i.modNat))
  exact h

/-- The position inside each pair is unchanged. -/
@[simp] theorem pairPerm_modNat {m : ℕ} (σ : Equiv.Perm (Fin m)) (i : Fin (m*2)) :
    (pairPerm σ i).modNat = i.modNat := by
  have h := congrArg Prod.snd (finProdFinEquiv.symm_apply_apply (σ i.divNat, i.modNat))
  exact h

/-- Simultaneous reindexing of endpoint pairs and their flavor assignments has
no fermionic sign. -/
theorem paired_weyl_relabel (d : ℕ) {m : ℕ}
    (H : Matrix (Majorana.Basis d) (Majorana.Basis d) ℂ) (β : ℝ)
    (p : Fin m → ℝ × ℝ) (f : Fin m → Fin (2*d)) (σ : Equiv.Perm (Fin m)) :
    weylNumerator H β (pairTimes (p ∘ σ))
      (fun i => Majorana.chiFin d (pairFlavors (f ∘ σ) i)) =
    weylNumerator H β (pairTimes p) (fun i => Majorana.chiFin d (pairFlavors f i)) := by
  have ht : pairTimes (p ∘ σ) = pairTimes p ∘ pairPerm σ := by
    funext i
    simp [pairTimes, Function.comp_def]
  have hf : (fun i => Majorana.chiFin d (pairFlavors (f ∘ σ) i)) =
      (fun i => Majorana.chiFin d (pairFlavors f i)) ∘ pairPerm σ := by
    funext i
    simp [pairFlavors, Function.comp_def]
  rw [ht, hf, weylNumerator_relabel, pairPerm_sign, one_smul]

/-- The actual finite flavor average is invariant under every bilocal permutation. -/
theorem collectiveNumerator_relabel (d : ℕ) {m : ℕ}
    (H : Matrix (Majorana.Basis d) (Majorana.Basis d) ℂ) (β : ℝ)
    (p : Fin m → ℝ × ℝ) (σ : Equiv.Perm (Fin m)) :
    collectiveNumerator d H β (p ∘ σ) = collectiveNumerator d H β p := by
  unfold collectiveNumerator
  congr 1
  rw [← Equiv.sum_comp (Equiv.arrowCongr σ.symm (Equiv.refl (Fin (2*d))))]
  apply Finset.sum_congr rfl
  intro f _
  exact paired_weyl_relabel d H β p f σ

/-- Exact permutation symmetry for the actual annealed collective moments. -/
theorem collectiveMoment_relabel (d : ℕ) (β : ℝ) (lam : ℝ≥0) {m : ℕ}
    (p : Fin m → ℝ × ℝ) (σ : Equiv.Perm (Fin m)) :
    collectiveMoment d β lam (p ∘ σ) = collectiveMoment d β lam p := by
  unfold collectiveMoment
  simp_rw [collectiveNumerator_relabel]



@[simp] theorem pairTimes_finProd {m : ℕ} (p : Fin m → ℝ × ℝ) (r : Fin m) (u : Fin 2) :
    pairTimes p (finProdFinEquiv (r,u)) = if u = 0 then (p r).1 else (p r).2 := by
  have h := finProdFinEquiv.symm_apply_apply (r,u)
  have hd := congrArg Prod.fst h
  have hm := congrArg Prod.snd h
  change (finProdFinEquiv (r,u)).divNat = r at hd
  change (finProdFinEquiv (r,u)).modNat = u at hm
  simp [pairTimes, hd, hm]

@[simp] theorem pairFlavors_finProd {m N : ℕ} (f : Fin m → Fin N) (r : Fin m) (u : Fin 2) :
    pairFlavors f (finProdFinEquiv (r,u)) = f r := by
  have h := congrArg Prod.fst (finProdFinEquiv.symm_apply_apply (r,u))
  exact congrArg f h

/-- Transpose the two fields of one chosen bilocal. -/
def flipPair {m : ℕ} (r : Fin m) : Equiv.Perm (Fin (m*2)) :=
  Equiv.swap (finProdFinEquiv (r,(0 : Fin 2))) (finProdFinEquiv (r,(1 : Fin 2)))

@[simp] theorem flipPair_sign {m : ℕ} (r : Fin m) : Equiv.Perm.sign (flipPair r) = -1 := by
  apply Equiv.Perm.sign_swap
  intro h
  have := congrArg Prod.snd (finProdFinEquiv.injective h)
  exact (by decide : (0 : Fin 2) ≠ 1) this

/-- Updating a bilocal's two endpoints is exactly its single field transposition. -/
theorem pairTimes_flip {m : ℕ} (p : Fin m → ℝ × ℝ) (r : Fin m) :
    pairTimes (Function.update p r ((p r).2, (p r).1)) = pairTimes p ∘ flipPair r := by
  classical
  funext i
  obtain ⟨⟨s,u⟩, rfl⟩ := finProdFinEquiv.surjective i
  fin_cases u <;> by_cases h : s = r
  all_goals simp [Function.comp_def, flipPair, Equiv.swap_apply_def,
    finProdFinEquiv.injective.eq_iff, h, Function.update_apply]

/-- The common flavor carried by a bilocal is unchanged when its fields swap. -/
theorem pairFlavors_flip {m N : ℕ} (f : Fin m → Fin N) (r : Fin m) :
    pairFlavors f ∘ flipPair r = pairFlavors f := by
  classical
  funext i
  obtain ⟨⟨s,u⟩, rfl⟩ := finProdFinEquiv.surjective i
  fin_cases u <;> by_cases h : s = r
  all_goals simp [Function.comp_def, flipPair, Equiv.swap_apply_def,
    finProdFinEquiv.injective.eq_iff, h]

/-- Actual collective numerators are skew in either endpoint pair, with all
other pairs and coincidences retained. -/
theorem collectiveNumerator_flip (d : ℕ) {m : ℕ}
    (H : Matrix (Majorana.Basis d) (Majorana.Basis d) ℂ) (β : ℝ)
    (p : Fin m → ℝ × ℝ) (r : Fin m) :
    collectiveNumerator d H β (Function.update p r ((p r).2, (p r).1)) =
      -collectiveNumerator d H β p := by
  have hterm (f : Fin m → Fin (2*d)) :
      weylNumerator H β (pairTimes (Function.update p r ((p r).2, (p r).1)))
        (fun i => Majorana.chiFin d (pairFlavors f i)) =
      -weylNumerator H β (pairTimes p) (fun i => Majorana.chiFin d (pairFlavors f i)) := by
    rw [pairTimes_flip]
    have hf : (fun i => Majorana.chiFin d (pairFlavors f i)) =
        (fun i => Majorana.chiFin d (pairFlavors f i)) ∘ flipPair r := by
      exact congrArg (fun v => Majorana.chiFin d ∘ v) (pairFlavors_flip f r).symm
    conv_lhs => rw [hf, weylNumerator_relabel, flipPair_sign]
    simp
  unfold collectiveNumerator
  simp only [hterm, Finset.sum_neg_distrib, mul_neg]

/-- The actual annealed moment is skew in every individual bilocal. -/
theorem collectiveMoment_flip (d : ℕ) (β : ℝ) (lam : ℝ≥0) {m : ℕ}
    (p : Fin m → ℝ × ℝ) (r : Fin m) :
    collectiveMoment d β lam (Function.update p r ((p r).2, (p r).1)) =
      -collectiveMoment d β lam p := by
  unfold collectiveMoment
  simp_rw [collectiveNumerator_flip]
  rw [MeasureTheory.integral_neg, mul_neg]

/-- An exactly coincident bilocal vanishes in the full actual moment. -/
theorem collectiveMoment_diagonal (d : ℕ) (β : ℝ) (lam : ℝ≥0) {m : ℕ}
    (p : Fin m → ℝ × ℝ) (r : Fin m) (hr : (p r).1 = (p r).2) :
    collectiveMoment d β lam p = 0 := by
  have hp : ((p r).2, (p r).1) = p r := by ext <;> simp [hr]
  have h := collectiveMoment_flip d β lam p r
  rw [hp, Function.update_eq_self] at h
  exact CharZero.eq_neg_self_iff.mp h



/-- A list permutation is realized by a bijection of occurrence indices,
including lists with repeated entries and different definitional lengths. -/
theorem listPerm_get_equiv {α : Type*} {l r : List α} (h : l.Perm r) :
    ∃ e : Fin l.length ≃ Fin r.length, ∀ i, l.get i = r.get (e i) := by
  induction h with
  | nil => exact ⟨Equiv.refl _, fun i => Fin.elim0 i⟩
  | @cons a l r h ih =>
    obtain ⟨e, he⟩ := ih
    refine ⟨(finSuccEquiv l.length).trans (e.optionCongr.trans (finSuccEquiv r.length).symm), ?_⟩
    intro i
    refine Fin.cases ?_ (fun i => ?_) i
    · simp
    · simpa using he i
  | swap a b l =>
    refine ⟨Equiv.swap (0 : Fin (l.length+2)) (1 : Fin (l.length+2)), ?_⟩
    intro i
    refine Fin.cases ?_ (fun i => ?_) i
    · simp
    · refine Fin.cases ?_ (fun i => ?_) i
      · simp
      · have h0 : i.succ.succ ≠ (0 : Fin (l.length+2)) := Fin.succ_ne_zero _
        have h1 : i.succ.succ ≠ (1 : Fin (l.length+2)) := by
          intro h
          have hv := congrArg Fin.val h
          simp only [Fin.val_succ, Fin.val_one] at hv
          omega
        simp [Equiv.swap_apply_of_ne_of_ne h0 h1]
  | trans h₁ h₂ ih₁ ih₂ =>
    obtain ⟨e₁, he₁⟩ := ih₁
    obtain ⟨e₂, he₂⟩ := ih₂
    exact ⟨e₁.trans e₂, fun i => (he₁ i).trans (he₂ (e₁ i))⟩

/-- Relabeling by an equivalence also covers dependent tuple lengths. -/
theorem collectiveMoment_eq_of_equiv (d : ℕ) (β : ℝ) (lam : ℝ≥0) {m k : ℕ}
    (p : Fin m → ℝ × ℝ) (q : Fin k → ℝ × ℝ) (e : Fin m ≃ Fin k)
    (he : ∀ i, p i = q (e i)) : collectiveMoment d β lam p = collectiveMoment d β lam q := by
  have hmk : m = k := by simpa using Fintype.card_congr e
  subst k
  have hp : p = q ∘ e := funext he
  rw [hp, collectiveMoment_relabel]

/-- List-form permutation symmetry for the polynomial functional's monomial enumeration. -/
theorem collectiveMoment_list_perm (d : ℕ) (β : ℝ) (lam : ℝ≥0)
    {l r : List (ℝ × ℝ)} (h : l.Perm r) :
    collectiveMoment d β lam l.get = collectiveMoment d β lam r.get := by
  obtain ⟨e, he⟩ := listPerm_get_equiv h
  exact collectiveMoment_eq_of_equiv d β lam l.get r.get e he

end SYK.MomentSymmetry
