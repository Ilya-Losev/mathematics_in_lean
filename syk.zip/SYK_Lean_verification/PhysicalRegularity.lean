import PhysicalClosedness
import ConvolutionRegularity

noncomputable section
open MeasureTheory Set Filter Function
open scoped Topology NNReal
namespace SYK.Continuum

theorem bounded_product_intervalIntegrable (β : ℝ) (f h : ℝ → ℝ)
    (hf : Measurable f) (hh : Measurable h) (B D : ℝ)
    (hb : ∀ t, |f t| ≤ B) (hd : ∀ t, |h t| ≤ D) (s : ℝ) :
    IntervalIntegrable (fun u => f (s-u)*h u) volume 0 β := by
  apply (intervalIntegrable_const (c := B*D)).mono_fun'
    (((hf.comp (measurable_const.sub measurable_id)).mul hh).aestronglyMeasurable)
  filter_upwards [] with u
  simp only [Real.norm_eq_abs, abs_mul]
  exact mul_le_mul (hb _) (hd _) (abs_nonneg _) ((abs_nonneg (f 0)).trans (hb 0))

/-- Convolution with the discontinuous midpoint covariance is Lipschitz after
integration, with no regularity assumption on the bounded measurable source. -/
theorem covariance_convolution_lipschitz (β : ℝ) (hβ : 0 < β)
    (f : ℝ → ℝ) (hf : Measurable f) (B : ℝ) (hb : ∀ t, |f t| ≤ B) :
    LipschitzWith ⟨B,(abs_nonneg (f 0)).trans (hb 0)⟩
      (scalarConvolution β (Thermal.covariance β) f) := by
  have hB : 0 ≤ B := (abs_nonneg (f 0)).trans (hb 0)
  apply LipschitzWith.of_dist_le_mul
  intro s t
  simp only [Real.dist_eq, NNReal.coe_mk, scalarConvolution]
  rw [← intervalIntegral.integral_sub
    (bounded_product_intervalIntegrable β _ f (Thermal.covariance_measurable β) hf _ B
      (Thermal.abs_covariance_le β) hb s)
    (bounded_product_intervalIntegrable β _ f (Thermal.covariance_measurable β) hf _ B
      (Thermal.abs_covariance_le β) hb t)]
  have hd := (Thermal.kernel_difference_intervalIntegrable β s t).const_mul B
  have hi := intervalIntegral.norm_integral_le_of_norm_le
    (Eventually.of_forall (fun u => show
      ‖Thermal.covariance β (s-u)*f u - Thermal.covariance β (t-u)*f u‖ ≤
        B*|Thermal.kernel β s u-Thermal.kernel β t u| from by
      rw [← sub_mul, Real.norm_eq_abs, abs_mul]
      exact (mul_le_mul_of_nonneg_left (hb u) (abs_nonneg _)).trans_eq (mul_comm _ _))) hd
  rw [intervalIntegral.integral_const_mul, abs_of_nonneg
    (mul_nonneg hB (intervalIntegral.integral_nonneg_of_forall hβ.le (fun _ => abs_nonneg _)))] at hi
  exact hi.trans (mul_le_mul_of_nonneg_left
    (Thermal.integral_kernel_difference_le β hβ s t) hB)

/-- A Lipschitz first convolution factor remains Lipschitz after integration
against a bounded second factor. -/
theorem scalarConvolution_lipschitz_left (β : ℝ) (hβ : 0 ≤ β)
    (f h : ℝ → ℝ) (hf : Measurable f) (hh : Measurable h)
    (B D K : ℝ) (hK : 0 ≤ K) (hb : ∀ t, |f t| ≤ B)
    (hd : ∀ t, |h t| ≤ D) (hl : LipschitzWith ⟨K,hK⟩ f) :
    LipschitzWith ⟨β*K*D, mul_nonneg (mul_nonneg hβ hK) ((abs_nonneg (h 0)).trans (hd 0))⟩ (scalarConvolution β f h) := by
  have hD : 0 ≤ D := (abs_nonneg (h 0)).trans (hd 0)
  apply LipschitzWith.of_dist_le_mul
  intro s t
  simp only [Real.dist_eq, NNReal.coe_mk, scalarConvolution]
  rw [← intervalIntegral.integral_sub
    (bounded_product_intervalIntegrable β f h hf hh B D hb hd s)
    (bounded_product_intervalIntegrable β f h hf hh B D hb hd t)]
  have hi := intervalIntegral.norm_integral_le_of_norm_le_const
    (a := (0:ℝ)) (b := β) (C := K*|s-t| * D)
    (f := fun u => f (s-u)*h u-f (t-u)*h u) (fun u _ => by
      dsimp only
      rw [← sub_mul, Real.norm_eq_abs, abs_mul]
      have he := hl.dist_le_mul (s-u) (t-u)
      simp only [Real.dist_eq, NNReal.coe_mk] at he
      rw [show s-u-(t-u)=s-t by ring] at he
      exact mul_le_mul he (hd u) (abs_nonneg _) (by positivity))
  simp only [Real.norm_eq_abs, sub_zero, abs_of_nonneg hβ] at hi
  nlinarith [hi]

/-- The SD equation itself gives a global Lipschitz bound on G−C. -/
theorem physical_centered_lipschitz (β : ℝ) (hβ : 0 < β) (lam : ℝ≥0)
    (g : ℝ → ℝ) (hg : PhysicalSolution β lam g) (B : ℝ)
    (hb : ∀ t, |g t| ≤ B) :
    LipschitzWith ⟨(lam:ℝ)*β*B^4, by positivity⟩
      (fun t => g t - Thermal.covariance β t) := by
  have hB : 0 ≤ B := (abs_nonneg (g 0)).trans (hb 0)
  have hcube (t) : |(g t)^3| ≤ B^3 := by
    rw [abs_pow]
    exact pow_le_pow_left₀ (abs_nonneg _) (hb t) 3
  let k := scalarConvolution β (Thermal.covariance β) (fun t => (g t)^3)
  have hk := covariance_convolution_lipschitz β hβ (fun t => (g t)^3)
    (hg.1.pow_const 3) (B^3) hcube
  have hkm := scalarConvolution_measurable β hβ.le _ _
    (Thermal.covariance_measurable β) (hg.1.pow_const 3)
  have hkb := scalarConvolution_bound β hβ.le _ _ _ _
    (Thermal.abs_covariance_le β) hcube
  have ho := scalarConvolution_lipschitz_left β hβ.le k g hkm hg.1
    (β*((1/2)*B^3)) B (B^3) (by positivity) hkb hb hk
  apply LipschitzWith.of_dist_le_mul
  intro s t
  have he (u) : g u - Thermal.covariance β u =
      (lam:ℝ)*scalarConvolution β k g u := by
    have h := sd_scalar_equation β hβ lam g hg.2.2.1 hg.2.2.2.2.2.2 u
    dsimp [k]
    linarith
  rw [he, he]
  have h := ho.dist_le_mul s t
  simp only [Real.dist_eq, NNReal.coe_mk] at h ⊢
  rw [← mul_sub, abs_mul, abs_of_nonneg lam.coe_nonneg]
  calc
    _ ≤ (lam:ℝ)*((β*B^3*B)*|s-t|) := mul_le_mul_of_nonneg_left h lam.coe_nonneg
    _ = _ := by ring

end SYK.Continuum
