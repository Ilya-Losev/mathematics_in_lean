import KernelQuotientAnalyticity
import KernelCoordinateGeneration

/-! Full half-algebra generation in the actual thermal double quotient. -/
noncomputable section
namespace SYK.ThermalHalfGeneration

open Set
open SYK.WeightedKernelAlgebra SYK.KernelResidualAlgebra
open SYK.KernelCoordinateGeneration SYK.KernelQuotientAnalyticity

variable (b K : ℝ) (hb : 0 < b) (hK : 0 < K)
  (β : ℝ) (hβ : 0 < β) (lam : ℂ)
  [Nontrivial (RegularityAlgebra b K hb hK (thermalCovariance β) (symmetryRelations β))]
  [Nontrivial (ThermalSDAlgebra b K hb hK β hβ lam (symmetryRelations β))]

/-- Every actual coordinate orbit is analytic; all symmetry, SD, and regularity
properties here are proved from the two concrete quotients. -/
theorem coordinate_orbit_analytic (s t : ℝ) :
    AnalyticOnNhd ℝ (fun u => thermalFinalKernel b K hb hK β hβ lam (symmetryRelations β)
      (s+u,t+u)) Set.univ :=
  thermalFinal_coordinate_analytic b K hb hK β hβ lam (symmetryRelations β)
    (finalKernel_antiperiodic b K hb hK (thermalCovariance β) β hβ.le lam
      (thermalCovariance_stronglyMeasurable β) (1/2) (norm_thermalCovariance_le β)) s t

/-- Theorem 7's full generation conclusion in the actual Section 6 algebra.
Neither analytic orbits, SD identities, coordinate density, nor symmetry are
assumed: each is proved for this constructed thermal quotient. -/
theorem closed_half_algebra_eq_top
    (B : Subalgebra ℂ (ThermalSDAlgebra b K hb hK β hβ lam (symmetryRelations β)))
    [IsClosed (B : Set (ThermalSDAlgebra b K hb hK β hβ lam (symmetryRelations β)))]
    (hhalf : ∀ s ∈ Ioo (0:ℝ) (β/2), ∀ t ∈ Ioo (0:ℝ) (β/2),
      thermalFinalKernel b K hb hK β hβ lam (symmetryRelations β) (s,t) ∈ B) : B = ⊤ := by
  have hall := thermalFinal_all_coordinates_mem_half_algebra b K hb hK β hβ lam
    (symmetryRelations β)
    (finalKernel_antiperiodic b K hb hK (thermalCovariance β) β hβ.le lam
      (thermalCovariance_stronglyMeasurable β) (1/2) (norm_thermalCovariance_le β)) B hhalf
  apply final_closed_subalgebra_eq_top b K hb hK (thermalCovariance β) (symmetryRelations β)
    (sdResiduals b K hb hK (thermalCovariance β) (symmetryRelations β) β hβ.le lam
      (thermalCovariance_stronglyMeasurable β) (1/2) (norm_thermalCovariance_le β)) B inferInstance
  intro p
  exact hall p.1 p.2

end SYK.ThermalHalfGeneration
