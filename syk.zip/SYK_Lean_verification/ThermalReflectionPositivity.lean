import GibbsState
import FreeWickTrace
import MicroscopicPressure

/-!
# Finite-dimensional thermal reflection positivity

Thermal histories below are actual ordered products of matrix exponentials and
local insertion matrices. Reflection reverses the factor list and adjoints the
local insertions; thermal propagators are unchanged because the Hamiltonian is
Hermitian. The trace of the resulting closed history is proved to be a genuine
Hilbert--Schmidt square. No positivity of a correlation functional is assumed.

The finite sums allow complex linear combinations and odd as well as even
histories. The final weighted odd-history kernel is an explicit finite thermal
sum. Identifying this sum with the manuscript's exterior expression q* q H_c
still requires a separately constructed antilinear exterior time reflection.
-/

noncomputable section
open scoped BigOperators ComplexOrder NNReal

namespace SYK.ThermalRP

variable {ν : Type*} [Fintype ν] [DecidableEq ν]

/-- Factors occurring in a thermal transfer product. -/
inductive Factor (ν : Type*) where
  | heat : ℝ → Factor ν
  | insertion : Matrix ν ν ℂ → Factor ν

/-- Every heat factor is the actual finite-dimensional exponential. -/
def evalFactor (H : Matrix ν ν ℂ) : Factor ν → Matrix ν ν ℂ
  | .heat r => Gibbs.weight r H
  | .insertion A => A

/-- Reflection preserves elapsed thermal time and adjoints local insertions. -/
def reflectFactor : Factor ν → Factor ν
  | .heat r => .heat r
  | .insertion A => .insertion (star A)

/-- An ordered thermal product. -/
def evaluate (H : Matrix ν ν ℂ) (L : List (Factor ν)) : Matrix ν ν ℂ :=
  (L.map (evalFactor H)).prod

@[simp] theorem evaluate_nil (H : Matrix ν ν ℂ) : evaluate H [] = 1 := rfl
@[simp] theorem evaluate_cons (H : Matrix ν ν ℂ) (f : Factor ν) (L : List (Factor ν)) :
    evaluate H (f :: L) = evalFactor H f * evaluate H L := rfl

@[simp] theorem evaluate_append (H : Matrix ν ν ℂ) (L K : List (Factor ν)) :
    evaluate H (L ++ K) = evaluate H L * evaluate H K := by
  simp [evaluate]

/-- Reflection reverses the history, rather than preserving its fermionic order. -/
def reflect (L : List (Factor ν)) : List (Factor ν) := L.reverse.map reflectFactor

omit [Fintype ν] [DecidableEq ν] in
@[simp] theorem reflectFactor_involutive (f : Factor ν) :
    reflectFactor (reflectFactor f) = f := by cases f <;> simp [reflectFactor]

@[simp] theorem reflect_involutive (L : List (Factor ν)) : reflect (reflect L) = L := by
  simp [reflect, List.map_reverse, List.map_map, Function.comp_def]

/-- The actual heat propagators are self-adjoint. -/
theorem heat_star {H : Matrix ν ν ℂ} (hH : H.IsHermitian) (r : ℝ) :
    star (Gibbs.weight r H) = Gibbs.weight r H :=
  (Gibbs.weight_posDef hH r).isHermitian

@[simp] theorem evalFactor_reflect {H : Matrix ν ν ℂ} (hH : H.IsHermitian) (f : Factor ν) :
    evalFactor H (reflectFactor f) = star (evalFactor H f) := by
  cases f with
  | heat r => exact (heat_star hH r).symm
  | insertion A => rfl

/-- Reversing a real-time thermal history is exactly taking its matrix adjoint. -/
theorem evaluate_reflect {H : Matrix ν ν ℂ} (hH : H.IsHermitian) (L : List (Factor ν)) :
    evaluate H (reflect L) = star (evaluate H L) := by
  induction L with
  | nil => simp [reflect]
  | cons f L ih =>
    simp only [reflect, List.reverse_cons, List.map_append, List.map_cons,
      List.map_nil, evaluate_append, evaluate_cons, evaluate_nil, mul_one] at *
    rw [ih, evalFactor_reflect hH, star_mul]

/-- The closed reflected thermal history is a star-square as a matrix identity. -/
theorem reflected_circle_eq_star_mul {H : Matrix ν ν ℂ} (hH : H.IsHermitian)
    (L : List (Factor ν)) :
    evaluate H (reflect L ++ L) = star (evaluate H L) * evaluate H L := by
  rw [evaluate_append, evaluate_reflect hH]

/-- Explicit factors for insertion times listed from latest to earliest. -/
def halfFactors (a : ℝ) : List (ℝ × Matrix ν ν ℂ) → List (Factor ν)
  | [] => [.heat a]
  | (t, A) :: L => .heat (a - t) :: .insertion A :: halfFactors t L

@[simp] theorem evaluate_halfFactors_nil (H : Matrix ν ν ℂ) (a : ℝ) :
    evaluate H (halfFactors a []) = Gibbs.weight a H := by simp [halfFactors, evalFactor]

/-- This is precisely the transfer product in the manuscript: the next local
block is preceded by propagation from the current boundary to its time. -/
theorem evaluate_halfFactors_cons (H : Matrix ν ν ℂ) (a t : ℝ) (A : Matrix ν ν ℂ)
    (L : List (ℝ × Matrix ν ν ℂ)) :
    evaluate H (halfFactors a ((t, A) :: L)) =
      Gibbs.weight (a - t) H * (A * evaluate H (halfFactors t L)) := rfl

/-- Duration counts heat intervals only. -/
def duration : Factor ν → ℝ
  | .heat r => r
  | .insertion _ => 0

omit [Fintype ν] [DecidableEq ν] in
/-- The telescoping thermal durations are exact, including zero intervals. -/
theorem halfFactors_duration (a : ℝ) (L : List (ℝ × Matrix ν ν ℂ)) :
    ((halfFactors a L).map duration).sum = a := by
  induction L generalizing a with
  | nil => simp [halfFactors, duration]
  | cons p L ih =>
    rcases p with ⟨t, A⟩
    simp [halfFactors, duration, ih]

omit [Fintype ν] [DecidableEq ν] in
/-- Every propagator interval is nonnegative for a genuinely ordered half-history. -/
theorem halfFactors_nonnegative (a : ℝ) (L : List (ℝ × Matrix ν ν ℂ))
    (ha : 0 ≤ a) (horder : L.Pairwise (fun p q => q.1 ≤ p.1))
    (hrange : ∀ p ∈ L, 0 ≤ p.1 ∧ p.1 ≤ a) :
    ∀ f ∈ halfFactors a L, 0 ≤ duration f := by
  induction L generalizing a with
  | nil => simp [halfFactors, duration, ha]
  | cons p L ih =>
    rcases p with ⟨t, A⟩
    obtain ⟨hhead, htail⟩ := List.pairwise_cons.mp horder
    have ht := hrange (t, A) (by simp)
    intro f hf
    simp only [halfFactors, List.mem_cons] at hf
    rcases hf with rfl | rfl | hf
    · exact sub_nonneg.mpr ht.2
    · exact le_rfl
    · apply ih t ht.1 htail _ f hf
      intro p hp
      exact ⟨(hrange p (by simp [hp])).1, hhead p hp⟩

/-- Arbitrary complex linear combinations of ordered histories. -/
def amplitude {ι : Type*} [Fintype ι] (H : Matrix ν ν ℂ)
    (c : ι → ℂ) (L : ι → List (Factor ν)) : Matrix ν ν ℂ :=
  ∑ i, c i • evaluate H (L i)

/-- The explicit double thermal sum obtained by reflection and gluing. -/
def circleMatrix {ι : Type*} [Fintype ι] (H : Matrix ν ν ℂ)
    (c : ι → ℂ) (L : ι → List (Factor ν)) : Matrix ν ν ℂ :=
  ∑ i, ∑ j, (star (c i) * c j) • evaluate H (reflect (L i) ++ L j)

/-- Reflection positivity for linear combinations follows from an exact
identity of the original double sum with one matrix star-square. -/
theorem circleMatrix_eq_star_mul {ι : Type*} [Fintype ι]
    {H : Matrix ν ν ℂ} (hH : H.IsHermitian)
    (c : ι → ℂ) (L : ι → List (Factor ν)) :
    circleMatrix H c L = star (amplitude H c L) * amplitude H c L := by
  simp only [circleMatrix, amplitude, star_sum, star_smul, Finset.sum_mul,
    Finset.mul_sum, smul_mul_assoc, mul_smul_comm, smul_smul,
    evaluate_append, evaluate_reflect hH, Finset.smul_sum]
  rw [Finset.sum_comm]
  simp only [mul_comm]

/-- The normalized physical reflected correlation is the ordinary trace of the
explicit closed thermal sum, divided by the actual positive partition function. -/
def reflectedValue {ι : Type*} [Fintype ι] (β : ℝ) (H : Matrix ν ν ℂ)
    (c : ι → ℂ) (L : ι → List (Factor ν)) : ℂ :=
  Matrix.trace (circleMatrix H c L) / (Gibbs.partition β H : ℂ)

/-- No evenness assumption appears: odd and even histories have the same
positive star-square, with no additional odd reflection phase. -/
theorem reflectedValue_re_nonnegative [Nonempty ν] {ι : Type*} [Fintype ι]
    {H : Matrix ν ν ℂ} (hH : H.IsHermitian) (β : ℝ)
    (c : ι → ℂ) (L : ι → List (Factor ν)) :
    0 ≤ (reflectedValue β H c L).re := by
  have hp := AntiCommuting.trace_re_nonneg
    (Matrix.posSemidef_conjTranspose_mul_self (amplitude H c L))
  rw [reflectedValue, circleMatrix_eq_star_mul hH, Complex.div_ofReal_re]
  exact div_nonneg hp (Gibbs.partition_pos hH β).le

/-- The same thermal sum is real, not merely nonnegative in real part. -/
theorem reflectedValue_im_zero [Nonempty ν] {ι : Type*} [Fintype ι]
    {H : Matrix ν ν ℂ} (hH : H.IsHermitian) (β : ℝ)
    (c : ι → ℂ) (L : ι → List (Factor ν)) :
    (reflectedValue β H c L).im = 0 := by
  have hp := Gibbs.trace_im_eq_zero
    (Matrix.posSemidef_conjTranspose_mul_self (amplitude H c L)).isHermitian
  change (Matrix.trace (star (amplitude H c L) * amplitude H c L)).im = 0 at hp
  rw [reflectedValue, circleMatrix_eq_star_mul hH, Complex.div_ofReal_im, hp, zero_div]

/-- Splitting a thermal interval at the reflection cut does not change its
actual propagator. -/
theorem heat_add (H : Matrix ν ν ℂ) (r s : ℝ) :
    Gibbs.weight (r + s) H = Gibbs.weight r H * Gibbs.weight s H := by
  unfold Gibbs.weight
  rw [neg_add, add_smul]
  exact Matrix.exp_add_of_commute ℂ _ _
    (((Commute.refl H).smul_left (-r)).smul_right (-s))

/-- The two reflected halves have the full inverse-temperature duration. -/
theorem reflected_half_duration (a : ℝ) (L : List (ℝ × Matrix ν ν ℂ)) :
    ((reflect (halfFactors a L) ++ halfFactors a L).map duration).sum = 2 * a := by
  have hd (f : Factor ν) : duration (reflectFactor f) = duration f := by cases f <;> rfl
  simp only [List.map_append, List.sum_append, reflect, List.map_map,
    Function.comp_def, hd, List.map_reverse, List.sum_reverse, halfFactors_duration]
  ring

/-- Star reverses a product, in the precise order required for fermionic reflection. -/
theorem star_list_prod (L : List (Matrix ν ν ℂ)) :
    star L.prod = (L.reverse.map star).prod := by
  induction L with
  | nil => simp
  | cons A L ih => simp [List.reverse_cons, List.prod_append, star_mul, ih]

/-- Reflection of the full Weyl average, reversing every summand. -/
def reversedWeylBlock (m k : ℕ) (v : Fin k → Fin (2 * m)) :
    Matrix (Majorana.Basis m) (Majorana.Basis m) ℂ :=
  (k.factorial : ℂ)⁻¹ • ∑ σ : Equiv.Perm (Fin k), Equiv.Perm.sign σ •
    (List.ofFn (fun i => Majorana.chiFin m (v (σ i)))).reverse.prod

/-- For every block size, including odd sizes, Weyl reversal agrees with
matrix adjunction term by term. There is no inserted parity phase. -/
theorem weyl_reversal_is_star (m k : ℕ) (v : Fin k → Fin (2 * m)) :
    reversedWeylBlock m k v = star (FreeWick.weylBlock m k v) := by
  rw [FreeWick.weylBlock_sum]
  simp only [star_smul, map_inv₀, map_natCast, star_sum]
  unfold reversedWeylBlock
  congr 1
  · simp
  · apply Finset.sum_congr rfl
    intro σ _
    have hp : star ((List.ofFn (fun i => Majorana.chiFin m (v (σ i)))).prod) =
        (List.ofFn (fun i => Majorana.chiFin m (v (σ i)))).reverse.prod := by
      rw [star_list_prod, List.map_reverse, List.map_ofFn]
      simp only [Function.comp_def, Majorana.chiFin_star]
    have hu : star (-1 : ℤˣ) = (-1 : ℤˣ) := by rfl
    rcases Int.units_eq_one_or (Equiv.Perm.sign σ) with hs | hs <;> simp [hs, hp, hu]
/-- The physical normalized cross-correlation of two half histories. -/
def kernel (β : ℝ) (H : Matrix ν ν ℂ) (L K : List (Factor ν)) : ℂ :=
  Matrix.trace (evaluate H (reflect L ++ K)) / (Gibbs.partition β H : ℂ)

/-- The kernel really is the transfer-matrix Gram kernel. -/
theorem kernel_eq {H : Matrix ν ν ℂ} (hH : H.IsHermitian) (β : ℝ)
    (L K : List (Factor ν)) :
    kernel β H L K = Matrix.trace (star (evaluate H L) * evaluate H K) /
      (Gibbs.partition β H : ℂ) := by
  rw [kernel, evaluate_append, evaluate_reflect hH]

/-- All coefficients in the reflected thermal polynomial are kept explicit. -/
theorem reflectedValue_eq_kernel_sum {ι : Type*} [Fintype ι] (β : ℝ)
    (H : Matrix ν ν ℂ) (c : ι → ℂ) (L : ι → List (Factor ν)) :
    reflectedValue β H c L =
      ∑ i, ∑ j, star (c i) * c j * kernel β H (L i) (L j) := by
  simp only [reflectedValue, circleMatrix, Matrix.trace_sum, Matrix.trace_smul,
    smul_eq_mul, Finset.sum_div, kernel, mul_div_assoc]

/-- A finite set of odd-field insertion times can be combined with arbitrary
complex coefficients and an arbitrary finite history polynomial q. This is the
flavor-averaged thermal Gram expression before identifying exterior notation. -/
def weightedOddValue {κ ι : Type*} [Fintype κ] [Fintype ι]
    (m : ℕ) (β : ℝ) (j : Majorana.FourSet m → ℝ) (q : κ → ℂ) (c : ι → ℂ)
    (L : Fin (2 * m) → κ → ι → List (Factor (Majorana.Basis m))) : ℂ :=
  ((2 * m : ℝ)⁻¹) • ∑ i : Fin (2 * m),
    reflectedValue β (Majorana.hamiltonian m j)
      (fun p : κ × ι => q p.1 * c p.2) (fun p => L i p.1 p.2)

/-- The q-weighted odd-history kernel is nonnegative for the actual SYK
Hamiltonian, with its genuine positive partition denominator. -/
theorem weightedOddValue_re_nonnegative {κ ι : Type*} [Fintype κ] [Fintype ι]
    (m : ℕ) (β : ℝ) (j : Majorana.FourSet m → ℝ) (q : κ → ℂ) (c : ι → ℂ)
    (L : Fin (2 * m) → κ → ι → List (Factor (Majorana.Basis m))) :
    0 ≤ (weightedOddValue m β j q c L).re := by
  unfold weightedOddValue
  simp only [Complex.smul_re, Complex.re_sum]
  apply mul_nonneg (by positivity)
  apply Finset.sum_nonneg
  intro i _
  exact reflectedValue_re_nonnegative (Gibbs.syk_hamiltonian_isHermitian m j) β _ _

/-- The weighted odd-history value is real for every complex choice of q,c. -/
theorem weightedOddValue_im_zero {κ ι : Type*} [Fintype κ] [Fintype ι]
    (m : ℕ) (β : ℝ) (j : Majorana.FourSet m → ℝ) (q : κ → ℂ) (c : ι → ℂ)
    (L : Fin (2 * m) → κ → ι → List (Factor (Majorana.Basis m))) :
    (weightedOddValue m β j q c L).im = 0 := by
  unfold weightedOddValue
  simp only [Complex.smul_im, Complex.im_sum]
  simp only [reflectedValue_im_zero (Gibbs.syk_hamiltonian_isHermitian m j),
    Finset.sum_const_zero, mul_zero, smul_zero]

/-- Explicit coefficients of the q-weighted odd Gram expression. -/
theorem weightedOddValue_expansion {κ ι : Type*} [Fintype κ] [Fintype ι]
    (m : ℕ) (β : ℝ) (j : Majorana.FourSet m → ℝ) (q : κ → ℂ) (c : ι → ℂ)
    (L : Fin (2 * m) → κ → ι → List (Factor (Majorana.Basis m))) :
    weightedOddValue m β j q c L = ((2 * m : ℝ)⁻¹) •
      ∑ i : Fin (2 * m), ∑ p : κ × ι, ∑ r : κ × ι,
        (star (q p.1) * q r.1 * (star (c p.2) * c r.2)) *
          kernel β (Majorana.hamiltonian m j) (L i p.1 p.2) (L i r.1 r.2) := by
  unfold weightedOddValue
  simp only [reflectedValue_eq_kernel_sum, star_mul]
  congr 1
  apply Finset.sum_congr rfl
  intro i _
  apply Finset.sum_congr rfl
  intro p _
  apply Finset.sum_congr rfl
  intro r _
  ring

/-- One actual Majorana inserted at a specified half-time. -/
def singleMajoranaHistory (m : ℕ) (β t : ℝ) (i : Fin (2 * m)) :
    List (Factor (Majorana.Basis m)) :=
  halfFactors (β / 2) [(t, Majorana.chiFin m i)]

/-- The odd two-history kernel is exactly the ordinary time-ordered thermal
bilocal at reflected times β-s and t, with the middle interval unsplit. -/
theorem singleMajorana_kernel (m : ℕ) (β : ℝ) (j : Majorana.FourSet m → ℝ)
    (s t : ℝ) (i : Fin (2 * m)) :
    kernel β (Majorana.hamiltonian m j)
      (singleMajoranaHistory m β s i) (singleMajoranaHistory m β t i) =
      Matrix.trace
        (Gibbs.weight s (Majorana.hamiltonian m j) * Majorana.chiFin m i *
          Gibbs.weight (β - s - t) (Majorana.hamiltonian m j) *
            Majorana.chiFin m i * Gibbs.weight t (Majorana.hamiltonian m j)) /
              (Gibbs.partition β (Majorana.hamiltonian m j) : ℂ) := by
  rw [kernel_eq (Gibbs.syk_hamiltonian_isHermitian m j)]
  simp only [singleMajoranaHistory, evaluate_halfFactors_cons,
    evaluate_halfFactors_nil, star_mul, heat_star (Gibbs.syk_hamiltonian_isHermitian m j),
    Majorana.chiFin_star]
  have hg : Gibbs.weight (β - s - t) (Majorana.hamiltonian m j) =
      Gibbs.weight (β / 2 - s) (Majorana.hamiltonian m j) *
        Gibbs.weight (β / 2 - t) (Majorana.hamiltonian m j) := by
    rw [show β - s - t = (β / 2 - s) + (β / 2 - t) by ring, heat_add]
  rw [hg]
  simp only [mul_assoc]

/-- A flavor-averaged reflected thermal Gram kernel. -/
def averageKernel {ι : Type*} (m : ℕ) (β : ℝ) (j : Majorana.FourSet m → ℝ)
    (L : Fin (2 * m) → ι → List (Factor (Majorana.Basis m))) (r v : ι) : ℂ :=
  ((2 * m : ℝ)⁻¹) • ∑ i : Fin (2 * m),
    kernel β (Majorana.hamiltonian m j) (L i r) (L i v)

/-- Expanding the quadratic form of the averaged kernel gives a sum of
actual reflected polynomial traces. -/
theorem averageKernel_quadratic {ι : Type*} [Fintype ι]
    (m : ℕ) (β : ℝ) (j : Majorana.FourSet m → ℝ) (c : ι → ℂ)
    (L : Fin (2 * m) → ι → List (Factor (Majorana.Basis m))) :
    (∑ r, ∑ v, star (c r) * c v * averageKernel m β j L r v) =
      ((2 * m : ℝ)⁻¹) • ∑ i : Fin (2 * m),
        reflectedValue β (Majorana.hamiltonian m j) c (L i) := by
  simp only [averageKernel, reflectedValue_eq_kernel_sum, mul_smul_comm,
    Finset.mul_sum, ← Finset.smul_sum]
  congr 1
  trans ∑ r : ι, ∑ i : Fin (2 * m), ∑ v : ι,
    star (c r) * c v * kernel β (Majorana.hamiltonian m j) (L i r) (L i v)
  · apply Finset.sum_congr rfl
    intro r _
    rw [Finset.sum_comm]
  · rw [Finset.sum_comm]

/-- The actual finite-N reflected thermal bilocal kernel is positive on every
finite collection of half-times and every complex test vector. -/
theorem averageKernel_quadratic_re_nonnegative {ι : Type*} [Fintype ι]
    (m : ℕ) (β : ℝ) (j : Majorana.FourSet m → ℝ) (c : ι → ℂ)
    (L : Fin (2 * m) → ι → List (Factor (Majorana.Basis m))) :
    0 ≤ (∑ r, ∑ v, star (c r) * c v * averageKernel m β j L r v).re := by
  rw [averageKernel_quadratic]
  simp only [Complex.smul_re, Complex.re_sum]
  apply mul_nonneg (by positivity)
  exact Finset.sum_nonneg (fun i _ =>
    reflectedValue_re_nonnegative (Gibbs.syk_hamiltonian_isHermitian m j) β c (L i))

/-- Concrete odd reflection positivity: here every history really contains the
flavor-i Majorana at the requested time, rather than an unspecified operator. -/
theorem reflected_bilocal_positive {ι : Type*} [Fintype ι]
    (m : ℕ) (β : ℝ) (j : Majorana.FourSet m → ℝ) (c : ι → ℂ) (s : ι → ℝ) :
    0 ≤ (∑ r, ∑ v, star (c r) * c v *
      averageKernel m β j (fun i r => singleMajoranaHistory m β (s r) i) r v).re :=
  averageKernel_quadratic_re_nonnegative m β j c _

/-- Deterministic insertion-norm factor; heat growth is accounted for separately. -/
def factorSize (f : Factor ν) : ℝ :=
  match f with
  | .heat _ => 1
  | .insertion A => ‖CStarMatrix.ofMatrix A‖

/-- Absolute propagation duration, sufficient for Gaussian-integrable bounds. -/
def factorTime (f : Factor ν) : ℝ :=
  match f with
  | .heat r => |r|
  | .insertion _ => 0

def historySize (L : List (Factor ν)) : ℝ := (L.map factorSize).prod

def historyTime (L : List (Factor ν)) : ℝ := (L.map factorTime).sum

omit [DecidableEq ν] in
theorem factorSize_nonnegative (f : Factor ν) : 0 ≤ factorSize f := by
  cases f <;> simp [factorSize]

theorem historySize_nonnegative (L : List (Factor ν)) : 0 ≤ historySize L := by
  induction L with
  | nil => simp [historySize]
  | cons f L ih =>
    exact mul_nonneg (factorSize_nonnegative f) ih

/-- Every propagator or local insertion has an explicit exponential coupling bound. -/
theorem norm_evalFactor_le (m : ℕ) (j : Majorana.FourSet m → ℝ)
    (f : Factor (Majorana.Basis m)) :
    ‖CStarMatrix.ofMatrix (evalFactor (Majorana.hamiltonian m j) f)‖ ≤
      factorSize f * Real.exp (factorTime f * (∑ I, |j I|) / 4) := by
  cases f with
  | insertion A => simp [evalFactor, factorSize, factorTime]
  | heat r =>
    simp only [evalFactor, Gibbs.weight, Majorana.ofMatrix_exp, factorSize, factorTime, one_mul]
    apply (Majorana.norm_exp_le m _).trans
    apply Real.exp_le_exp.mpr
    change ‖(-r) • CStarMatrix.ofMatrix (Majorana.hamiltonian m j)‖ ≤ _
    rw [norm_smul (-r) (CStarMatrix.ofMatrix (Majorana.hamiltonian m j)),
      Real.norm_eq_abs, abs_neg]
    calc
      _ ≤ |r| * ((∑ I, |j I|) / 4) :=
        mul_le_mul_of_nonneg_left (Majorana.norm_hamiltonian_le m j) (abs_nonneg r)
      _ = _ := by ring

/-- Finite transfer products have a Gaussian-integrable exponential bound;
this applies even before imposing nonnegative physical intervals. -/
theorem norm_evaluate_le (m : ℕ) (j : Majorana.FourSet m → ℝ)
    (L : List (Factor (Majorana.Basis m))) :
    ‖CStarMatrix.ofMatrix (evaluate (Majorana.hamiltonian m j) L)‖ ≤
      historySize L * Real.exp (historyTime L * (∑ I, |j I|) / 4) := by
  induction L with
  | nil =>
    change ‖(1 : CStarMatrix (Majorana.Basis m) (Majorana.Basis m) ℂ)‖ ≤ 1 * Real.exp (0 * (∑ I, |j I|) / 4)
    simp
  | cons f L ih =>
    change ‖CStarMatrix.ofMatrix (evalFactor (Majorana.hamiltonian m j) f) *
      CStarMatrix.ofMatrix (evaluate (Majorana.hamiltonian m j) L)‖ ≤ _
    apply (norm_mul_le _ _).trans
    apply (mul_le_mul (norm_evalFactor_le m j f) ih (norm_nonneg _)
      (mul_nonneg (factorSize_nonnegative f) (Real.exp_pos _).le)).trans
    apply le_of_eq
    simp only [historySize, historyTime, List.map_cons, List.prod_cons, List.sum_cons]
    rw [show (factorTime f + (List.map factorTime L).sum) * (∑ I, |j I|) / 4 =
      factorTime f * (∑ I, |j I|) / 4 + (List.map factorTime L).sum * (∑ I, |j I|) / 4 by ring,
      Real.exp_add]
    ring

/-- The actual matrix exponential is continuous in the shared finite product topology. -/
theorem continuous_matrix_exp (m : ℕ) :
    Continuous (fun A : Matrix (Majorana.Basis m) (Majorana.Basis m) ℂ => NormedSpace.exp ℂ A) := by
  change Continuous (fun A : Matrix (Majorana.Basis m) (Majorana.Basis m) ℂ =>
    CStarMatrix.ofMatrixL.symm (NormedSpace.exp ℂ (CStarMatrix.ofMatrixL A)))
  exact CStarMatrix.ofMatrixL.symm.continuous.comp
    (NormedSpace.exp_continuous.comp CStarMatrix.ofMatrixL.continuous)

theorem continuous_evalFactor (m : ℕ) (f : Factor (Majorana.Basis m)) :
    Continuous (fun j => evalFactor (Majorana.hamiltonian m j) f) := by
  cases f with
  | heat r =>
    exact (continuous_matrix_exp m).comp ((Majorana.continuous_hamiltonian m).const_smul (-r))
  | insertion A => exact continuous_const

theorem continuous_evaluate (m : ℕ) (L : List (Factor (Majorana.Basis m))) :
    Continuous (fun j => evaluate (Majorana.hamiltonian m j) L) := by
  induction L with
  | nil => exact continuous_const
  | cons f L ih => exact (continuous_evalFactor m f).mul ih

/-- Every finite thermal-history trace is genuinely integrable under the
actual Gaussian SYK coupling law. -/
theorem trace_evaluate_integrable (m : ℕ) (lam : ℝ≥0)
    (L : List (Factor (Majorana.Basis m))) :
    MeasureTheory.Integrable
      (fun j => Matrix.trace (evaluate (Majorana.hamiltonian m j) L))
      (Microscopic.disorder m lam) := by
  have hg := (GaussianDisorder.integrable_exp_sum_abs (Majorana.FourSet m)
    (2 * m) lam (historyTime L / 4)).const_mul ((2 : ℝ) ^ m * historySize L)
  apply hg.mono'
  · exact (continuous_evaluate m L).matrix_trace.aestronglyMeasurable
  · filter_upwards [] with j
    apply (Majorana.norm_trace_le m _).trans
    calc
      _ ≤ (2 : ℝ) ^ m *
          (historySize L * Real.exp (historyTime L * (∑ I, |j I|) / 4)) :=
        mul_le_mul_of_nonneg_left (norm_evaluate_le m j L) (by positivity)
      _ = _ := by
        rw [show historyTime L * (∑ I, |j I|) / 4 = historyTime L / 4 * (∑ I, |j I|) by ring]
        ring

/-- The reflected polynomial numerator is an integrable finite thermal sum. -/
theorem trace_circleMatrix_integrable {ι : Type*} [Fintype ι]
    (m : ℕ) (lam : ℝ≥0) (c : ι → ℂ)
    (L : ι → List (Factor (Majorana.Basis m))) :
    MeasureTheory.Integrable
      (fun j => Matrix.trace (circleMatrix (Majorana.hamiltonian m j) c L))
      (Microscopic.disorder m lam) := by
  simp only [circleMatrix, Matrix.trace_sum, Matrix.trace_smul, smul_eq_mul]
  apply MeasureTheory.integrable_finset_sum
  intro i _
  apply MeasureTheory.integrable_finset_sum
  intro j _
  exact (trace_evaluate_integrable m lam (reflect (L i) ++ L j)).const_mul _

/-- The genuine annealed partition denominator is strictly positive. -/
theorem annealed_partition_positive (m : ℕ) (β : ℝ) (lam : ℝ≥0) :
    0 < ∫ j, (Majorana.partitionFunction m β j).re ∂(Microscopic.disorder m lam) := by
  rw [MeasureTheory.integral_pos_iff_support_of_nonneg
    (fun j => (Gibbs.syk_partition_re_pos m β j).le)
    (Microscopic.real_partitionFunction_integrable m β lam)]
  have hs : Function.support (fun j => (Majorana.partitionFunction m β j).re) = Set.univ := by
    ext j
    simp only [Function.mem_support, ne_eq, (Gibbs.syk_partition_re_pos m β j).ne',
      not_false_eq_true, Set.mem_univ]
  rw [hs]
  simp

/-- Annealed reflection value formed from actual disorder integrals. -/
def annealedValue {ι : Type*} [Fintype ι] (m : ℕ) (β : ℝ) (lam : ℝ≥0)
    (c : ι → ℂ) (L : ι → List (Factor (Majorana.Basis m))) : ℝ :=
  (∫ j, (Matrix.trace (circleMatrix (Majorana.hamiltonian m j) c L)).re
      ∂(Microscopic.disorder m lam)) /
    (∫ j, (Majorana.partitionFunction m β j).re ∂(Microscopic.disorder m lam))

/-- Gaussian-disorder averaging preserves the proved finite-dimensional
reflection positivity, with a positive, genuinely integrable normalization. -/
theorem annealedValue_nonnegative {ι : Type*} [Fintype ι]
    (m : ℕ) (β : ℝ) (lam : ℝ≥0) (c : ι → ℂ)
    (L : ι → List (Factor (Majorana.Basis m))) :
    0 ≤ annealedValue m β lam c L := by
  unfold annealedValue
  apply div_nonneg _ (annealed_partition_positive m β lam).le
  apply MeasureTheory.integral_nonneg
  intro j
  change 0 ≤ (Matrix.trace (circleMatrix (Majorana.hamiltonian m j) c L)).re
  rw [circleMatrix_eq_star_mul (Gibbs.syk_hamiltonian_isHermitian m j)]
  exact AntiCommuting.trace_re_nonneg (Matrix.posSemidef_conjTranspose_mul_self _)

end SYK.ThermalRP
