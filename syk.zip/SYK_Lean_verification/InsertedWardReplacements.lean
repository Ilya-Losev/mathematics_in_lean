import MixedIncrementBounds
import Mathlib.MeasureTheory.Integral.Prod

noncomputable section
open MeasureTheory Set Filter
open scoped Topology
namespace SYK.MixedIncrement
open WeightedKernelAlgebra

/-- Bounded measurable two-time expressions admit ordinary Fubini and
subtraction on the actual thermal square. -/
theorem double_integral_sub (β : ℝ) (hβ : 0 ≤ β) (F G : ℝ → ℝ → ℂ)
    (hF : Measurable (Function.uncurry F)) (hG : Measurable (Function.uncurry G))
    (B D : ℝ) (hb : ∀ u v, ‖F u v‖ ≤ B) (hd : ∀ u v, ‖G u v‖ ≤ D) :
    (∫ u in (0:ℝ)..β, ∫ v in (0:ℝ)..β, F u v) -
      (∫ u in (0:ℝ)..β, ∫ v in (0:ℝ)..β, G u v) =
    ∫ u in (0:ℝ)..β, ∫ v in (0:ℝ)..β, (F u v-G u v) := by
  let μ := volume.restrict (Ioc (0:ℝ) β)
  have hiF : Integrable (Function.uncurry F) (μ.prod μ) :=
    (integrable_const B).mono' hF.aestronglyMeasurable (Eventually.of_forall (fun p => hb p.1 p.2))
  have hiG : Integrable (Function.uncurry G) (μ.prod μ) :=
    (integrable_const D).mono' hG.aestronglyMeasurable (Eventually.of_forall (fun p => hd p.1 p.2))
  simp only [intervalIntegral.integral_of_le hβ]
  change (∫ u, ∫ v, F u v ∂μ ∂μ) - (∫ u, ∫ v, G u v ∂μ ∂μ) =
    ∫ u, ∫ v, (F u v-G u v) ∂μ ∂μ
  have heF := integral_prod _ hiF
  have heG := integral_prod _ hiG
  have heD := integral_prod _ (hiF.sub hiG)
  simp only [Function.uncurry_apply_pair, Pi.sub_apply] at heF heG heD
  rw [← heF, ← heG, ← integral_sub hiF hiG, heD]

/-- The coefficient norm gives a uniform bound for any fixed polynomial
insertion followed by four varying coordinates. -/
theorem coefficientNorm_coordinateProduct (b : ℝ) (hb : 0 < b) (p : List Endpoint) :
    coefficientNorm (fun _ => b) (coordinateProduct p) ≤ b^p.length := by
  induction p with
  | nil =>
      change coefficientNorm (fun _ => b) (MvPolynomial.monomial 0 1) ≤ b^0
      rw [coefficientNorm_monomial, monomialWeight_zero]
      norm_num
  | cons a p ih =>
      rw [coordinateProduct_cons]
      apply (coefficientNorm_mul_le (fun _ => b) (fun _ => hb) _ _).trans
      have hx : coefficientNorm (fun _ : Endpoint => b) (MvPolynomial.X a) = b := by
        change coefficientNorm (fun _ => b) (MvPolynomial.monomial (Finsupp.single a 1) 1)=b
        simp
      rw [hx, List.length_cons, pow_succ]
      simpa only [mul_comm] using mul_le_mul_of_nonneg_left ih hb.le

theorem inserted_four_bound (L : Polynomial →ₗ[ℂ] ℂ)
    (hL : ∀ P, ‖L P‖ ≤ coefficientNorm (fun _ => (1/2:ℝ)) P)
    (Q : Polynomial) (p : List Endpoint) (hp : p.length=4) :
    ‖L (Q*coordinateProduct p)‖ ≤ coefficientNorm (fun _ => (1/2:ℝ)) Q / 16 := by
  apply (hL _).trans
  apply (coefficientNorm_mul_le (fun _ => (1/2:ℝ)) (fun _ => by norm_num) _ _).trans
  have h := coefficientNorm_coordinateProduct (1/2) (by norm_num) p
  rw [hp] at h
  have hQ := coefficientNorm_nonneg (fun _ : Endpoint => (1/2:ℝ)) (fun _ => by norm_num) Q
  nlinarith

theorem covariance_double_difference_left (β : ℝ) (hβ : 0 ≤ β) (s s' : ℝ)
    (F : ℝ → ℝ → ℂ) (hF : Measurable (Function.uncurry F))
    (A : ℝ) (hA : ∀ u v, ‖F u v‖ ≤ A) :
    (∫ u in (0:ℝ)..β, ∫ v in (0:ℝ)..β, (Thermal.kernel β s u:ℂ)*F u v) -
      (∫ u in (0:ℝ)..β, ∫ v in (0:ℝ)..β, (Thermal.kernel β s' u:ℂ)*F u v) =
    ∫ u in (0:ℝ)..β, ∫ v in (0:ℝ)..β,
      ((Thermal.kernel β s u-Thermal.kernel β s' u):ℂ)*F u v := by
  have hm (s) : Measurable (fun p : ℝ×ℝ => (Thermal.kernel β s p.1:ℂ)*F p.1 p.2) :=
    (Complex.measurable_ofReal.comp ((Thermal.covariance_measurable β).comp
      (measurable_const.sub measurable_fst))).mul hF
  have hb (s u v) : ‖(Thermal.kernel β s u:ℂ)*F u v‖ ≤ (1/2:ℝ)*A := by
    rw [norm_mul, Complex.norm_real, Real.norm_eq_abs]
    exact mul_le_mul (Thermal.abs_covariance_le β _) (hA u v) (norm_nonneg _) (by norm_num)
  have h := double_integral_sub β hβ
    (fun u v => (Thermal.kernel β s u:ℂ)*F u v)
    (fun u v => (Thermal.kernel β s' u:ℂ)*F u v) (hm s) (hm s')
    ((1/2)*A) ((1/2)*A) (hb s) (hb s')
  simpa only [← sub_mul] using h

theorem covariance_double_difference_right (β : ℝ) (hβ : 0 ≤ β) (t t' : ℝ)
    (F : ℝ → ℝ → ℂ) (hF : Measurable (Function.uncurry F))
    (A : ℝ) (hA : ∀ u v, ‖F u v‖ ≤ A) :
    (∫ u in (0:ℝ)..β, ∫ v in (0:ℝ)..β, (Thermal.kernel β v t:ℂ)*F u v) -
      (∫ u in (0:ℝ)..β, ∫ v in (0:ℝ)..β, (Thermal.kernel β v t':ℂ)*F u v) =
    ∫ u in (0:ℝ)..β, ∫ v in (0:ℝ)..β,
      ((Thermal.kernel β v t-Thermal.kernel β v t'):ℂ)*F u v := by
  have hm (t) : Measurable (fun p : ℝ×ℝ => (Thermal.kernel β p.2 t:ℂ)*F p.1 p.2) :=
    (Complex.measurable_ofReal.comp ((Thermal.covariance_measurable β).comp
      (measurable_snd.sub measurable_const))).mul hF
  have hb (t u v) : ‖(Thermal.kernel β v t:ℂ)*F u v‖ ≤ (1/2:ℝ)*A := by
    rw [norm_mul, Complex.norm_real, Real.norm_eq_abs]
    exact mul_le_mul (Thermal.abs_covariance_le β _) (hA u v) (norm_nonneg _) (by norm_num)
  have h := double_integral_sub β hβ
    (fun u v => (Thermal.kernel β v t:ℂ)*F u v)
    (fun u v => (Thermal.kernel β v t':ℂ)*F u v) (hm t) (hm t')
    ((1/2)*A) ((1/2)*A) (hb t) (hb t')
  simpa only [← sub_mul] using h

/-- Genuine separate left/right inserted SD identities imply the precise
replacement identity used in the mixed-increment induction. All subtractions
under the integrals are justified by measurable bounded polynomial moments. -/
theorem replacement_of_inserted_ward (β lam : ℝ) (hβ : 0 ≤ β)
    (L : Polynomial →ₗ[ℂ] ℂ)
    (hbound : ∀ P, ‖L P‖ ≤ coefficientNorm (fun _ => (1/2:ℝ)) P)
    (hml : ∀ Q t, Measurable (fun p : ℝ×ℝ =>
      L (Q*coordinateProduct [(p.1,p.2),(p.1,p.2),(p.1,p.2),(p.2,t)])))
    (hmr : ∀ Q s, Measurable (fun p : ℝ×ℝ =>
      L (Q*coordinateProduct [(s,p.1),(p.1,p.2),(p.1,p.2),(p.1,p.2)])))
    (hleft : ∀ Q s t, L (Q*remainder β (s,t)) =
      (lam:ℂ)*(∫ u in (0:ℝ)..β, ∫ v in (0:ℝ)..β,
        (Thermal.kernel β s u:ℂ)*L (Q*coordinateProduct [(u,v),(u,v),(u,v),(v,t)])))
    (hright : ∀ Q s t, L (Q*remainder β (s,t)) =
      (lam:ℂ)*(∫ u in (0:ℝ)..β, ∫ v in (0:ℝ)..β,
        (Thermal.kernel β v t:ℂ)*L (Q*coordinateProduct [(s,u),(u,v),(u,v),(u,v)]))) :
    ReplacementIdentity β lam L := by
  intro Q pq
  have hl (s s' t : ℝ) : L (Q*(remainder β (s,t)-remainder β (s',t))) =
      (lam:ℂ)*(∫ u in (0:ℝ)..β, ∫ v in (0:ℝ)..β,
        ((Thermal.kernel β s u-Thermal.kernel β s' u):ℂ)*
          L (Q*coordinateProduct [(u,v),(u,v),(u,v),(v,t)])) := by
    rw [mul_sub, map_sub, hleft, hleft, ← mul_sub]
    congr 1
    exact covariance_double_difference_left β hβ s s' _ (hml Q t)
      (coefficientNorm (fun _ => (1/2:ℝ)) Q / 16)
      (fun u v => inserted_four_bound L hbound Q _ rfl)
  have hr (s t t' : ℝ) : L (Q*(remainder β (s,t)-remainder β (s,t'))) =
      (lam:ℂ)*(∫ u in (0:ℝ)..β, ∫ v in (0:ℝ)..β,
        ((Thermal.kernel β v t-Thermal.kernel β v t'):ℂ)*
          L (Q*coordinateProduct [(s,u),(u,v),(u,v),(u,v)])) := by
    rw [mul_sub, map_sub, hright, hright, ← mul_sub]
    congr 1
    exact covariance_double_difference_right β hβ t t' _ (hmr Q s)
      (coefficientNorm (fun _ => (1/2:ℝ)) Q / 16)
      (fun u v => inserted_four_bound L hbound Q _ rfl)
  have he : Q*increment β pq =
      Q*(remainder β (pq.1.1,pq.1.2)-remainder β (pq.2.1,pq.1.2)) +
      Q*(remainder β (pq.2.1,pq.1.2)-remainder β (pq.2.1,pq.2.2)) := by
    dsimp [increment]
    ring
  rw [he, map_add, hl, hr]
  rfl

end SYK.MixedIncrement
