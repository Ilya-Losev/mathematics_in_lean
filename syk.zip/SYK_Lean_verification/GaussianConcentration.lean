import PisierPath
import ProductGaussianMGF
import ProductGaussianRotation

/-!
# A genuine Gaussian exponential concentration bound for SYK

This implements the Pisier rotation argument with actual product Gaussian
measures. Conditional Gaussian MGFs supply both integrability and the numerical
bound; the deterministic rotation/FTC/Jensen step uses the concrete SYK gradient.
-/

set_option maxHeartbeats 800000
noncomputable section
open MeasureTheory ProbabilityTheory Set Filter
open scoped BigOperators Topology ComplexOrder NNReal
namespace SYK.GaussianConcentration
open Majorana GlobalGradient LogPartitionDifferential PisierPath

abbrev couplingLaw (m : ℕ) (v : ℝ≥0) := ProductGaussianMGF.law (FourSet m) v

def squaredBound (m : ℕ) (β : ℝ) : ℝ := β^2 * (2 * m : ℝ)^3 / 16

def momentBound (m : ℕ) (β : ℝ) (v : ℝ≥0) : ℝ :=
  Real.exp ((v : ℝ) * (Real.pi / 2)^2 * squaredBound m β / 2)

def responseExp (m : ℕ) (β : ℝ) (p : (FourSet m → ℝ) × (FourSet m → ℝ)) : ℝ :=
  Real.exp ((Real.pi / 2) * ∑ I, logGradient m β p.1 I * p.2 I)

theorem continuous_responseExp (m : ℕ) (β : ℝ) : Continuous (responseExp m β) := by
  have hG := (continuous_logGradient m β).comp
    (continuous_fst : Continuous (Prod.fst : (FourSet m → ℝ) × (FourSet m → ℝ) → _))
  unfold responseExp
  apply Real.continuous_exp.comp
  apply continuous_const.mul
  apply continuous_finset_sum
  intro I _
  exact ((continuous_apply I).comp hG).mul ((continuous_apply I).comp continuous_snd)

theorem responseExp_conditional_integrable (m : ℕ) (β : ℝ) (v : ℝ≥0) (x : FourSet m → ℝ) :
    Integrable (fun y => responseExp m β (x, y)) (couplingLaw m v) := by
  convert ProductGaussianMGF.integrable_exp_sum_linear (FourSet m) v
    (fun I => (Real.pi / 2) * logGradient m β x I) using 1
  funext y
  simp only [responseExp, Finset.mul_sum, mul_assoc]

theorem responseExp_conditional_bound (m : ℕ) (β : ℝ) (v : ℝ≥0) (x : FourSet m → ℝ) :
    (∫ y, responseExp m β (x, y) ∂couplingLaw m v) ≤ momentBound m β v :=
  ProductGaussianMGF.integral_exp_dot_le (FourSet m) v (Real.pi / 2)
    (squaredBound m β) (logGradient m β x) (logGradient_sq_sum_le m β x)

/-- Conditional Gaussian integration proves genuine joint integrability. -/
theorem responseExp_integrable (m : ℕ) (β : ℝ) (v : ℝ≥0) :
    Integrable (responseExp m β) ((couplingLaw m v).prod (couplingLaw m v)) := by
  have hc := continuous_responseExp m β
  apply (integrable_prod_iff hc.aestronglyMeasurable).mpr
  constructor
  · exact ae_of_all _ (responseExp_conditional_integrable m β v)
  · apply (integrable_const (momentBound m β v)).mono'
    · exact hc.norm.stronglyMeasurable.integral_prod_right'.aestronglyMeasurable
    · filter_upwards [] with x
      have hn (y) : ‖responseExp m β (x, y)‖ = responseExp m β (x, y) :=
        Real.norm_of_nonneg (le_of_lt (Real.exp_pos _))
      simp only [hn]
      have hnonneg : 0 ≤ ∫ y, responseExp m β (x, y) ∂couplingLaw m v :=
        integral_nonneg (fun y => (Real.exp_pos _).le)
      rw [Real.norm_of_nonneg hnonneg]
      exact responseExp_conditional_bound m β v x

theorem integral_responseExp_le (m : ℕ) (β : ℝ) (v : ℝ≥0) :
    (∫ p, responseExp m β p ∂(couplingLaw m v).prod (couplingLaw m v)) ≤ momentBound m β v := by
  rw [integral_prod _ (responseExp_integrable m β v)]
  have hi := integral_mono (responseExp_integrable m β v).integral_prod_left
    (integrable_const (momentBound m β v)) (responseExp_conditional_bound m β v)
  simpa only [integral_const, measureReal_univ_eq_one, one_smul] using hi

/-- Exponentiated response at a rotated pair. -/
def rotatedResponseExp (m : ℕ) (β t : ℝ)
    (p : (FourSet m → ℝ) × (FourSet m → ℝ)) : ℝ :=
  responseExp m β (GaussianRotation.rotateArray (Real.pi / 2 * t) p)

theorem rotatedResponseExp_eq (m : ℕ) (β t : ℝ) (x y : FourSet m → ℝ) :
    rotatedResponseExp m β t (x, y) = Real.exp (rotationResponse m β x y t) := rfl

theorem continuous_rotatedResponseExp (m : ℕ) (β : ℝ) :
    Continuous (fun q : ℝ × ((FourSet m → ℝ) × (FourSet m → ℝ)) =>
      rotatedResponseExp m β q.1 q.2) := by
  apply (continuous_responseExp m β).comp
  unfold GaussianRotation.rotateArray
  fun_prop

theorem rotatedResponseExp_integrable (m : ℕ) (β : ℝ) (v : ℝ≥0) (t : ℝ) :
    Integrable (rotatedResponseExp m β t) ((couplingLaw m v).prod (couplingLaw m v)) := by
  exact ((GaussianRotation.array_measurePreserving v (Real.pi / 2 * t)).integrable_comp
    (continuous_responseExp m β).aestronglyMeasurable).mpr (responseExp_integrable m β v)

/-- Rotational invariance removes the interpolation parameter from the expectation. -/
theorem integral_rotatedResponseExp (m : ℕ) (β : ℝ) (v : ℝ≥0) (t : ℝ) :
    (∫ p, rotatedResponseExp m β t p ∂(couplingLaw m v).prod (couplingLaw m v)) =
      ∫ p, responseExp m β p ∂(couplingLaw m v).prod (couplingLaw m v) := by
  have hp : MeasurePreserving (GaussianRotation.rotateArray (ι := FourSet m) (Real.pi / 2 * t))
      ((couplingLaw m v).prod (couplingLaw m v)) ((couplingLaw m v).prod (couplingLaw m v)) :=
    GaussianRotation.array_measurePreserving (ι := FourSet m) v (Real.pi / 2 * t)
  have h := integral_map hp.measurable.aemeasurable
    (show AEStronglyMeasurable (responseExp m β) (Measure.map
      (GaussianRotation.rotateArray (Real.pi / 2 * t)) ((couplingLaw m v).prod (couplingLaw m v))) by
      rw [hp.map_eq]
      exact (continuous_responseExp m β).aestronglyMeasurable)
  rw [hp.map_eq] at h
  exact h.symm

/-- The full interpolation integral is absolutely integrable; the use of
Fubini below therefore does not hide an exchange-of-integrals assumption. -/
theorem rotatedResponseExp_joint_integrable (m : ℕ) (β : ℝ) (v : ℝ≥0) :
    Integrable (fun q : ℝ × ((FourSet m → ℝ) × (FourSet m → ℝ)) =>
      rotatedResponseExp m β q.1 q.2)
      (unitInterval.prod ((couplingLaw m v).prod (couplingLaw m v))) := by
  apply (integrable_prod_iff (continuous_rotatedResponseExp m β).aestronglyMeasurable).mpr
  constructor
  · exact ae_of_all _ (rotatedResponseExp_integrable m β v)
  · have hn (t : ℝ) (p) : ‖rotatedResponseExp m β t p‖ = rotatedResponseExp m β t p :=
      Real.norm_of_nonneg (le_of_lt (Real.exp_pos _))
    simp only [hn, integral_rotatedResponseExp]
    exact integrable_const _

/-- Exponential concentration for the difference of two independent actual
SYK log partition functions, with no concentration theorem assumed. -/
theorem integral_exp_logPartition_difference_le (m : ℕ) (β : ℝ) (v : ℝ≥0) :
    (∫ p : (FourSet m → ℝ) × (FourSet m → ℝ),
      Real.exp (logPartition m β p.2 - logPartition m β p.1)
      ∂(couplingLaw m v).prod (couplingLaw m v)) ≤ momentBound m β v := by
  have hj := rotatedResponseExp_joint_integrable m β v
  have hf : Continuous (logPartition m β) :=
    continuous_iff_continuousAt.mpr (fun x => (differentiableAt_logPartition m β x).continuousAt)
  have hpoint (p : (FourSet m → ℝ) × (FourSet m → ℝ)) :
      Real.exp (logPartition m β p.2 - logPartition m β p.1) ≤
        ∫ t, rotatedResponseExp m β t p ∂unitInterval :=
    exp_logPartition_sub_le m β p.1 p.2
  have hfi : Integrable (fun p : (FourSet m → ℝ) × (FourSet m → ℝ) =>
      Real.exp (logPartition m β p.2 - logPartition m β p.1))
      ((couplingLaw m v).prod (couplingLaw m v)) := by
    apply hj.integral_prod_right.mono'
    · exact (Real.continuous_exp.comp ((hf.comp continuous_snd).sub (hf.comp continuous_fst))).aestronglyMeasurable
    · filter_upwards [] with p
      simpa only [Real.norm_eq_abs, abs_of_pos (Real.exp_pos _)] using hpoint p
  have hmono := integral_mono hfi hj.integral_prod_right hpoint
  have hswap := integral_integral_swap (μ := unitInterval)
    (ν := (couplingLaw m v).prod (couplingLaw m v))
    (f := fun t p => rotatedResponseExp m β t p) hj
  rw [← hswap] at hmono
  simp only [integral_rotatedResponseExp, integral_const, measureReal_univ_eq_one, one_smul] at hmono
  exact hmono.trans (integral_responseExp_le m β v)

end SYK.GaussianConcentration
