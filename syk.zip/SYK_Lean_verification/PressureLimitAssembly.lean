import FourthMomentIntegral
import Pressure
import PressureGap

/-!
# Concrete dominated-pressure-limit assembly

This intermediate theorem consumes the microscopic quartic response identity
and actual fourth-moment convergence. It discharges the remaining continuity,
normalization, measurability, domination, time-translation and quenched-gap
obligations using the proved concrete model theorems. The operator/Wick
correspondence must still supply the response identity before this theorem is
used for the final continuum claim.
-/
noncomputable section
open MeasureTheory Set Filter
open scoped NNReal Topology
namespace SYK.PressureLimitAssembly
open FourthMomentIntegral

/-- Domination and all scalar hypotheses are instantiated with the actual
model; only the two explicitly identified microscopic limit bridges remain. -/
theorem annealed_limit_from_quartic_response {β : ℝ} (hβ : 0 < β)
    (g : ℝ≥0 → ℝ → ℝ) (hg : ∀ l, Continuum.PhysicalSolution β l (g l))
    (hresponse : ∀ d : ℕ, 0 < d → ∀ l : ℝ, 0 < l →
      HasDerivAt (fun s => Microscopic.annealedPressure d β s.toNNReal)
        (fourthIntegral d β l.toNNReal) l)
    (hfactor : ∀ l : ℝ≥0, ∀ᵐ p ∂timeMeasure β,
      Tendsto (fun d : ℕ => fourthMoment d β l p) atTop (𝓝 ((g l (p.1-p.2))^4)))
    (lam : ℝ≥0) :
    Tendsto (fun d : ℕ => Microscopic.annealedPressure d β lam) atTop
      (𝓝 (Continuum.couplingPressure β g lam)) := by
  have hc (n : ℕ) : Continuous (fun l : ℝ => Microscopic.annealedPressure (n+1) β l.toNNReal) :=
    (AnnealedDifferentiation.continuous_annealedPressure (n+1) β).comp continuous_real_toNNReal
  have hf (l : ℝ) : Tendsto (fun n : ℕ => fourthIntegral (n+1) β l.toNNReal) atTop
      (𝓝 (β/8 * Continuum.quarticIntegral β (g l.toNNReal))) := by
    apply fourthIntegral_tendsto hβ l.toNNReal (fun n => n+1) (fun n => Nat.succ_pos n) _ (hg _)
    filter_upwards [hfactor l.toNNReal] with p hp
    exact hp.comp (tendsto_add_atTop_nat 1)
  have h := SYK.pressure_limit_of_dominated_derivatives
    (fun n l => Microscopic.annealedPressure (n+1) β l.toNNReal)
    (fun n l => fourthIntegral (n+1) β l.toNNReal)
    (fun l => β/8 * Continuum.quarticIntegral β (g l.toNNReal))
    (fun _ => β^2/128) (Real.log 2/2) (lam : ℝ) lam.coe_nonneg
    (fun n => (hc n).continuousOn)
    (fun n l hl => hresponse (n+1) (by omega) l hl.1)
    (fun n => by simpa using Microscopic.annealedPressure_free (n+1) (by omega) β)
    (fun n => ((measurable_fourthIntegral (n+1) β).comp
      continuous_real_toNNReal.measurable).aestronglyMeasurable)
    (integrable_const (β^2/128))
    (fun n => ae_of_all _ fun l => by
      simpa only [Real.norm_eq_abs] using fourthIntegral_bound (n+1) (by omega) hβ l.toNNReal)
    (ae_of_all _ hf)
  have he : Real.log 2/2 + ∫ l in (0 : ℝ)..(lam : ℝ),
      β/8 * Continuum.quarticIntegral β (g l.toNNReal) = Continuum.couplingPressure β g lam := by
    rw [intervalIntegral.integral_const_mul]
    rfl
  rw [he] at h
  simp only [Real.toNNReal_coe] at h
  exact (tendsto_add_atTop_iff_nat 1).mp h

/-- Once the genuine annealed limit is obtained, the independently proved
microscopic pressure gap supplies the quenched limit with the same value. -/
theorem pressure_convergence_from_quartic_response {β : ℝ} (hβ : 0 < β)
    (g : ℝ≥0 → ℝ → ℝ) (hg : ∀ l, Continuum.PhysicalSolution β l (g l))
    (hresponse : ∀ d : ℕ, 0 < d → ∀ l : ℝ, 0 < l →
      HasDerivAt (fun s => Microscopic.annealedPressure d β s.toNNReal)
        (fourthIntegral d β l.toNNReal) l)
    (hfactor : ∀ l : ℝ≥0, ∀ᵐ p ∂timeMeasure β,
      Tendsto (fun d : ℕ => fourthMoment d β l p) atTop (𝓝 ((g l (p.1-p.2))^4)))
    (lam : ℝ≥0) :
    Continuum.PressureConvergence β lam (Continuum.couplingPressure β g lam) := by
  have ha := annealed_limit_from_quartic_response hβ g hg hresponse hfactor lam
  exact ⟨ha, PressureGap.quenched_limit_of_annealed_limit β lam _ ha⟩

end SYK.PressureLimitAssembly
