import KernelAnalyticity
import HalfGeneration
import Mathlib.Analysis.Analytic.Constructions
import Mathlib.Analysis.Calculus.FDeriv.Analytic
import Mathlib.Analysis.Calculus.InverseFunctionTheorem.FDeriv
import Mathlib.MeasureTheory.Integral.IntervalIntegral.FundThmCalculus
import Mathlib.MeasureTheory.Integral.DominatedConvergence
import Mathlib.Topology.ContinuousMap.Compact
import Mathlib.Tactic

/-!
# Analytic fixed-point branches for the path-space ODE construction

This module develops the analytic inverse-function route to polynomial ODE
regularity. The fixed-point branch below is to be instantiated with the
Volterra integral of the polynomial vector field on a Banach path space.
-/

noncomputable section

namespace SYK

open Filter Set
open scoped Topology

variable {E : Type*} [NormedAddCommGroup E] [NormedSpace ℂ E] [CompleteSpace E]

/-- A local analytic solution of `y = z • K y`, constructed by the analytic
inverse function theorem. No analyticity assumption is made about the unknown
solution branch. -/
theorem exists_analytic_fixedPoint_branch
    (K : E → E) (hK : AnalyticAt ℂ K 0) :
    ∃ y : ℂ → E, AnalyticAt ℂ y 0 ∧ y 0 = 0 ∧
      (∀ᶠ z in 𝓝 (0 : ℂ), y z = z • K (y z)) ∧
      ∀ᶠ p in 𝓝 (0 : ℂ × E), p.2 = p.1 • K p.2 → p.2 = y p.1 := by
  let Φ : ℂ × E → ℂ × E := fun p => (p.1, p.2 - p.1 • (K p.2 - K 0))
  have hΦ : AnalyticAt ℂ Φ 0 := by
    exact analyticAt_fst.prod (analyticAt_snd.sub
      (analyticAt_fst.fun_smul ((hK.comp_of_eq (analyticAt_snd : AnalyticAt ℂ (Prod.snd : ℂ × E → E) 0) rfl).sub analyticAt_const)))
  have hD : HasFDerivAt Φ (ContinuousLinearMap.id ℂ (ℂ × E)) 0 := by
    have h1 := hasFDerivAt_fst (𝕜 := ℂ) (E := ℂ) (F := E) (p := (0 : ℂ × E))
    have h2 := hasFDerivAt_snd (𝕜 := ℂ) (E := ℂ) (F := E) (p := (0 : ℂ × E))
    have h3 := (hK.differentiableAt.hasFDerivAt.comp 0 h2).sub_const (K 0)
    have h4 := h1.prodMk (h2.sub (h1.smul h3))
    convert h4 using 1 <;> (try ext p) <;> simp [Φ]
  have hS : HasStrictFDerivAt Φ
      (ContinuousLinearEquiv.refl ℂ (ℂ × E) : (ℂ × E) →L[ℂ] (ℂ × E)) 0 := by
    simpa only [hD.fderiv] using hΦ.hasStrictFDerivAt
  let e := hS.toPartialHomeomorph Φ
  have hzero : Φ 0 = 0 := by simp [Φ]
  have he0 : (0 : ℂ × E) ∈ e.source := hS.mem_toPartialHomeomorph_source
  have hinv : AnalyticAt ℂ e.symm 0 := by
    have hd : fderiv ℂ (e : (ℂ × E) → ℂ × E) 0 =
        (ContinuousLinearEquiv.refl ℂ (ℂ × E) : (ℂ × E) →L[ℂ] (ℂ × E)) := hD.fderiv
    have hi := e.analyticAt_symm' he0 hΦ hd
    change AnalyticAt ℂ e.symm (Φ 0) at hi
    simpa only [hzero] using hi
  let j : ℂ → ℂ × E := fun z => (z, z • K 0)
  have hj : AnalyticAt ℂ j 0 :=
    analyticAt_id.prod (analyticAt_id.fun_smul analyticAt_const)
  have hj0 : j 0 = 0 := by simp [j]
  let y : ℂ → E := fun z => (e.symm (j z)).2
  have hy : AnalyticAt ℂ y 0 := by
    exact analyticAt_snd.comp (hinv.comp_of_eq hj hj0)
  have hy0 : y 0 = 0 := by
    have h := e.left_inv he0
    change e.symm (Φ 0) = 0 at h
    simp only [hzero] at h
    simpa [y, hj0] using congrArg Prod.snd h
  refine ⟨y, hy, hy0, ?_, ?_⟩
  ·
    have hev : ∀ᶠ p in 𝓝 (0 : ℂ × E), Φ (e.symm p) = p := by
      have h := e.eventually_right_inverse' he0
      change ∀ᶠ p in 𝓝 (Φ 0), Φ (e.symm p) = p at h
      simpa only [hzero] using h
    have hjt : Tendsto j (𝓝 (0 : ℂ)) (𝓝 (0 : ℂ × E)) := by
      simpa only [hj0] using hj.continuousAt.tendsto
    have hz : ∀ᶠ z in 𝓝 (0 : ℂ), Φ (e.symm (j z)) = j z := hjt.eventually hev
    filter_upwards [hz] with z hz
    have hfirst := congrArg Prod.fst hz
    have hsecond := congrArg Prod.snd hz
    change (e.symm (j z)).1 = z at hfirst
    change y z - (e.symm (j z)).1 • (K (y z) - K 0) = z • K 0 at hsecond
    rw [hfirst, smul_sub] at hsecond
    apply sub_eq_zero.mp
    calc
      y z - z • K (y z) = (y z - (z • K (y z) - z • K 0)) - z • K 0 := by abel
      _ = 0 := sub_eq_zero.mpr hsecond
  · have hsource : e.source ∈ 𝓝 (0 : ℂ × E) := e.open_source.mem_nhds he0
    filter_upwards [hsource] with p hp hpeq
    have heq : Φ p = j p.1 := by
      ext
      · rfl
      · change p.2 - p.1 • (K p.2 - K 0) = p.1 • K 0
        rw [smul_sub]
        calc
          p.2 - (p.1 • K p.2 - p.1 • K 0) = (p.2 - p.1 • K p.2) + p.1 • K 0 := by abel
          _ = p.1 • K 0 := by rw [sub_eq_zero.mpr hpeq, zero_add]
    have hleft := e.left_inv hp
    change e.symm (Φ p) = p at hleft
    rw [heq] at hleft
    exact (congrArg Prod.snd hleft).symm


/-- A continuous real branch satisfying an analytic implicit fixed-point
identity is automatically real analytic. Local uniqueness is supplied by the
inverse theorem, rather than assumed for the branch. -/
theorem analyticAt_of_scaled_fixedPoint
    [NormedSpace ℝ E] [IsScalarTower ℝ ℂ E]
    (K : E → E) (hK : AnalyticAt ℂ K 0) (q : ℝ → E)
    (hq : ContinuousAt q 0) (hq0 : q 0 = 0)
    (heq : ∀ᶠ u in 𝓝 (0 : ℝ), q u = (u : ℂ) • K (q u)) :
    AnalyticAt ℝ q 0 := by
  obtain ⟨y, hy, _, _, huniq⟩ := exists_analytic_fixedPoint_branch K hK
  have hyR : AnalyticAt ℝ y (0 : ℂ) := hy.restrictScalars
  have hcomp : AnalyticAt ℝ (fun u : ℝ => y (u : ℂ)) 0 :=
    hyR.comp_of_eq' (Complex.ofRealCLM.analyticAt 0) (by simp)
  have ht : Tendsto (fun u : ℝ => ((u : ℂ), q u))
      (𝓝 (0 : ℝ)) (𝓝 (0 : ℂ × E)) := by
    simpa only [Complex.ofReal_zero, hq0] using
      (Complex.continuous_ofReal.continuousAt.prodMk hq).tendsto
  apply hcomp.congr
  filter_upwards [ht.eventually huniq, heq] with u hu hequ
  exact (hu hequ).symm

/-- The fixed real interval used for analytic dependence on scaled time. -/
abbrev ODEInterval := Set.Icc (0 : ℝ) 1

section Volterra

variable [NormedSpace ℝ E] [IsScalarTower ℝ ℂ E]

/-- Extend a continuous path constantly outside the unit interval. -/
def extendODEPath (f : C(ODEInterval, E)) (t : ℝ) : E :=
  f (Set.projIcc 0 1 (by norm_num) t)

omit [NormedSpace ℂ E] [CompleteSpace E] [NormedSpace ℝ E] [IsScalarTower ℝ ℂ E] in
theorem continuous_extendODEPath (f : C(ODEInterval, E)) :
    Continuous (extendODEPath f) :=
  f.continuous.comp continuous_projIcc

/-- The Volterra integral on the unit interval, as a continuous path. -/
noncomputable def volterraPath (f : C(ODEInterval, E)) : C(ODEInterval, E) where
  toFun t := ∫ s in (0 : ℝ)..(t : ℝ), extendODEPath f s
  continuous_toFun :=
    (intervalIntegral.continuous_primitive
      (fun a b => (continuous_extendODEPath f).intervalIntegrable a b) 0).comp
      continuous_subtype_val

theorem norm_volterraPath_le (f : C(ODEInterval, E)) : ‖volterraPath f‖ ≤ ‖f‖ := by
  apply (ContinuousMap.norm_le _ (norm_nonneg _)).mpr
  intro t
  change ‖∫ s in (0 : ℝ)..(t : ℝ), extendODEPath f s‖ ≤ ‖f‖
  calc
    _ ≤ ‖f‖ * |(t : ℝ) - 0| :=
      intervalIntegral.norm_integral_le_of_norm_le_const (fun s _ => f.norm_coe_le_norm _)
    _ ≤ ‖f‖ * 1 := by
      gcongr
      simpa only [sub_zero, abs_of_nonneg t.property.1] using t.property.2
    _ = ‖f‖ := mul_one _

/-- The bounded complex-linear Volterra operator. -/
noncomputable def volterraCLM : C(ODEInterval, E) →L[ℂ] C(ODEInterval, E) :=
  LinearMap.mkContinuous
    { toFun := volterraPath
      map_add' := by
        intro f g
        ext t
        change (∫ s in (0 : ℝ)..(t : ℝ), extendODEPath (f + g) s) = _
        exact intervalIntegral.integral_add
          ((continuous_extendODEPath f).intervalIntegrable _ _)
          ((continuous_extendODEPath g).intervalIntegrable _ _)
      map_smul' := by
        intro c f
        ext t
        exact intervalIntegral.integral_smul c (extendODEPath f) }
    1 (fun f => by simpa only [one_mul] using norm_volterraPath_le f)

@[simp] theorem volterraCLM_apply (f : C(ODEInterval, E)) (t : ODEInterval) :
    volterraCLM f t = ∫ s in (0 : ℝ)..(t : ℝ), extendODEPath f s := rfl

end Volterra


/-- Pointwise application of a bounded bilinear operation to two paths. -/
def pathBilinearMap (B : E →L[ℂ] E →L[ℂ] E)
    (f g : C(ODEInterval, E)) : C(ODEInterval, E) where
  toFun t := B (f t) (g t)
  continuous_toFun := (B.continuous.comp f.continuous).clm_apply g.continuous

/-- A bounded bilinear operation lifts to the Banach space of continuous paths. -/
noncomputable def pathBilinear (B : E →L[ℂ] E →L[ℂ] E) :
    C(ODEInterval, E) →L[ℂ] C(ODEInterval, E) →L[ℂ] C(ODEInterval, E) :=
  (LinearMap.mk₂ ℂ (pathBilinearMap B)
    (by intros; ext t; simp [pathBilinearMap, map_add])
    (by intros; ext t; simp [pathBilinearMap, map_smul])
    (by intros; ext t; simp [pathBilinearMap, map_add])
    (by intros; ext t; simp [pathBilinearMap, map_smul])).mkContinuous₂ ‖B‖ (by
      intro f g
      apply (ContinuousMap.norm_le _
        (mul_nonneg (mul_nonneg (norm_nonneg B) (norm_nonneg f)) (norm_nonneg g))).mpr
      intro t
      change ‖B (f t) (g t)‖ ≤ ‖B‖ * ‖f‖ * ‖g‖
      calc
        _ ≤ ‖B‖ * ‖f t‖ * ‖g t‖ := B.le_opNorm₂ _ _
        _ ≤ ‖B‖ * ‖f‖ * ‖g‖ := by
          gcongr
          · exact f.norm_coe_le_norm t
          · exact g.norm_coe_le_norm t)

omit [CompleteSpace E] in
@[simp] theorem pathBilinear_apply (B : E →L[ℂ] E →L[ℂ] E)
    (f g : C(ODEInterval, E)) (t : ODEInterval) :
    pathBilinear B f g t = B (f t) (g t) := rfl


section AnalyticODE

variable [NormedSpace ℝ E] [IsScalarTower ℝ ℂ E]

/-- Rescale a real trajectory to the fixed unit time interval. -/
def scaledODEPath (r : ℝ → E) (hc : Continuous r) (u : ℝ) : C(ODEInterval, E) where
  toFun t := r (u * (t : ℝ))
  continuous_toFun := hc.comp (continuous_const.mul continuous_subtype_val)

omit [NormedSpace ℂ E] [CompleteSpace E] [NormedSpace ℝ E] [IsScalarTower ℝ ℂ E] in
theorem continuous_scaledODEPath (r : ℝ → E) (hc : Continuous r) :
    Continuous (scaledODEPath r hc) := by
  apply ContinuousMap.continuous_of_continuous_uncurry
  exact hc.comp (continuous_fst.mul (continuous_subtype_val.comp continuous_snd))

/-- An ODE trajectory is analytic when its pointwise vector field lifts
analytically to the Banach space of continuous paths. The proof constructs an
analytic implicit branch and identifies the actual trajectory through its
integrated differential equation; it does not assume an analytic solution. -/
theorem real_ode_analyticAt_zero_of_path_lift
    (F : E → E) (hF : Continuous F)
    (P : C(ODEInterval, E) → C(ODEInterval, E))
    (hPval : ∀ f t, P f t = F (f t))
    (r : ℝ → E) (hr : ∀ t, HasDerivAt r (F (r t)) t)
    (hP : AnalyticAt ℂ P (ContinuousMap.const ODEInterval (r 0))) :
    AnalyticAt ℝ r 0 := by
  have hc : Continuous r := continuous_iff_continuousAt.mpr fun t => (hr t).continuousAt
  let c0 : C(ODEInterval, E) := ContinuousMap.const ODEInterval (r 0)
  let q : ℝ → C(ODEInterval, E) := fun u => scaledODEPath r hc u - c0
  let K : C(ODEInterval, E) → C(ODEInterval, E) :=
    fun y => volterraCLM (P (c0 + y))
  have hK : AnalyticAt ℂ K 0 := by
    have ha : AnalyticAt ℂ (fun y : C(ODEInterval, E) => c0 + y) 0 :=
      analyticAt_const.add analyticAt_id
    have hb := hP.comp_of_eq ha (by simp [c0])
    exact (volterraCLM.analyticAt _).comp hb
  have hq : ContinuousAt q 0 :=
    ((continuous_scaledODEPath r hc).sub continuous_const).continuousAt
  have hq0 : q 0 = 0 := by
    ext t
    simp [q, c0, scaledODEPath]
  have heq : ∀ u, q u = (u : ℂ) • K (q u) := by
    intro u
    have hsum : c0 + q u = scaledODEPath r hc u := by dsimp [q]; abel
    ext t
    change r (u * (t : ℝ)) - r 0 =
      (u : ℂ) • volterraCLM (P (c0 + q u)) t
    rw [hsum, volterraCLM_apply]
    have hi : (∫ s in (0 : ℝ)..(t : ℝ), extendODEPath (P (scaledODEPath r hc u)) s) =
        ∫ s in (0 : ℝ)..(t : ℝ), F (r (u * s)) := by
      apply intervalIntegral.integral_congr
      intro s hs
      rw [Set.uIcc_of_le t.property.1] at hs
      have hsI : s ∈ ODEInterval := ⟨hs.1, hs.2.trans t.property.2⟩
      unfold extendODEPath
      rw [hPval, Set.projIcc_of_mem _ hsI]
      rfl
    rw [hi]
    change r (u * (t : ℝ)) - r 0 =
      (algebraMap ℝ ℂ u) • (∫ s in (0 : ℝ)..(t : ℝ), F (r (u * s)))
    rw [IsScalarTower.algebraMap_smul ℂ]
    rw [intervalIntegral.smul_integral_comp_mul_left (f := fun v => F (r v)) u]
    simp only [mul_zero]
    exact (intervalIntegral.integral_eq_sub_of_hasDerivAt (fun s _ => hr s)
      ((hF.comp hc).intervalIntegrable _ _)).symm
  have hqa : AnalyticAt ℝ q 0 :=
    analyticAt_of_scaled_fixedPoint K hK q hq hq0 (Eventually.of_forall heq)
  let t1 : ODEInterval := ⟨1, by constructor <;> norm_num⟩
  have hev := ((ContinuousMap.evalCLM ℝ t1).analyticAt _).comp hqa
  have hresult := hev.add (analyticAt_const (v := r 0))
  change AnalyticAt ℝ (fun u => q u t1 + r 0) 0 at hresult
  simpa [q, c0, scaledODEPath, t1] using hresult

end AnalyticODE


section KernelODE

variable {A : Type*} [NormedRing A] [NormedAlgebra ℂ A] [CompleteSpace A]
  [NormedSpace ℝ A] [IsScalarTower ℝ ℂ A]

omit [IsScalarTower ℝ ℂ A] in
/-- Every real solution of the quartic kernel center-time ODE is real analytic.
This proves the ODE-to-analyticity bridge without an analytic-orbit hypothesis.
The kernel-space construction and the SD-to-ODE identities are separate inputs.
-/
theorem kernelCenterField_ode_analytic
    (conv : A →L[ℂ] A →L[ℂ] A) (C : A) (lam : ℂ)
    (r : ℝ → A)
    (hr : ∀ t, HasDerivAt r (kernelCenterField conv C lam (r t)) t) :
    AnalyticOnNhd ℝ r Set.univ := by
  intro u0 _
  let F := kernelCenterField conv C lam
  have hF : Continuous F := continuous_iff_continuousAt.mpr fun a =>
    (kernelCenterField_analyticAt conv C lam a).continuousAt
  let P : C(ODEInterval, A) → C(ODEInterval, A) :=
    kernelCenterField (pathBilinear conv) (ContinuousMap.const ODEInterval C) lam
  have hPval : ∀ f t, P f t = F (f t) := by
    intro f t
    simp [P, F, kernelCenterField, pathBilinear_apply]
  let rs : ℝ → A := fun t => r (u0 + t)
  have hrs : ∀ t, HasDerivAt rs (F (rs t)) t := by
    intro t
    simpa [rs, F] using (hr (u0 + t)).scomp t ((hasDerivAt_id t).const_add u0)
  have hP : AnalyticAt ℂ P (ContinuousMap.const ODEInterval (rs 0)) :=
    kernelCenterField_analyticAt _ _ _ _
  have ha := real_ode_analyticAt_zero_of_path_lift F hF P hPval rs hrs hP
  have hb : AnalyticAt ℝ (fun t : ℝ => t - u0) u0 :=
    analyticAt_id.sub analyticAt_const
  have hh := ha.comp_of_eq' hb (by simp)
  have heq : (fun t => rs (t - u0)) = r := by
    funext t
    dsimp [rs]
    congr 1
    ring
  rwa [heq] at hh


/-- Directly connect the proved ODE analyticity to the half-algebra continuation
step: any bounded linear observable of the trajectory, plus a fixed jump, stays
in a closed subspace once it does so on a nonempty open interval. -/
theorem kernelCenterField_eval_mem_of_open_seed
    {W : Type*} [NormedAddCommGroup W] [NormedSpace ℝ W]
    (conv : A →L[ℂ] A →L[ℂ] A) (C : A) (lam : ℂ)
    (r : ℝ → A)
    (hr : ∀ t, HasDerivAt r (kernelCenterField conv C lam (r t)) t)
    (B : Submodule ℝ W) [IsClosed (B : Set W)]
    (ev : A →L[ℝ] W) (c : W)
    (I : Set ℝ) (hI : IsOpen I) (hne : I.Nonempty)
    (hseed : ∀ u ∈ I, ev (r u) + c ∈ B) :
    ∀ u, ev (r u) + c ∈ B := by
  have ha := kernelCenterField_ode_analytic conv C lam r hr
  apply analytic_curve_mem_closed_submodule B (fun u => ev (r u) + c) _ I hI hne hseed
  intro u hu
  exact ((ev.analyticAt _).comp (ha u hu)).add analyticAt_const

end KernelODE

end SYK
