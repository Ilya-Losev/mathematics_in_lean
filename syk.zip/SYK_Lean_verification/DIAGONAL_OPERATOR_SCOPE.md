# Diagonal operator and determinant scope

`DiagonalFredholm.lean` is a checked operator construction. For any real
absolutely summable family a indexed by a decidable type, it constructs:

1. The actual complex Hilbert space ℓ² and its complete coordinate Hilbert basis.
2. Actual bounded coordinate functionals and rank-one projections.
3. The operator D = Σ aᵢ Pᵢ, with an operator-norm convergent series and proved
   coordinate action (Dx)ᵢ = aᵢ xᵢ. Real a gives a self-adjoint operator.
4. A `NuclearExpansion D`: actual vectors uᵢ and bounded linear functionals φᵢ,
   a proved summable sum of norm products, and an actual operator series
   `HasSum (fun i => φᵢ.smulRight uᵢ) D`. No nuclearity hypothesis is supplied.
5. The genuine finite coordinate-compression matrices of I + D. Their ordinary
   finite-dimensional matrix determinants are proved equal to the finite products.
6. Convergence of those determinants over the directed net of all finite subsets,
   and therefore along every cofinal finite-coordinate exhaustion.
7. When every 1 + aᵢ is positive, strict positivity of the limit and the
   absolutely convergent logarithmic formula from `RelativeLogSeries`.

`coordinateDeterminant` is defined from an operator alone by the limit of its
actual compression determinants, and its value for D is proved. It is totalized
outside convergence; the theorems provide convergence for the constructed D.
It is explicitly **not** introduced under the name of a general Fredholm
operator determinant.

## Physical integral-operator bridge

`FourierOperators.lean` transports the actual summable diagonal operator through
mathlib's complete Fourier Hilbert basis on the half-frequency-twisted circle
L² space. `physicalPerturbation_integral_action` proves that its action on every
bounded measurable real test kernel is exactly minus the literal nested
Lebesgue integral C*(Σ*h), where Σ=λg³. No convolution identity is assumed.
The same module constructs the actual time-domain rank-one expansion and proves
summability of its norm products, using `OnShellAction.sourceRatio_summable`.
It proves convergence of genuine finite Fourier-mode compression determinants,
strict positivity, the exact log identity, and cofinal-cutoff independence.

## Ordinary spectral Fredholm identification now checked

`SpectralFredholm.lean` defines `spectralDeterminant T` from the operator T itself:
the product over its real eigenspaces with their actual complex dimensions.
For the actual diagonal and physical operators the following are proved:

- Compactness by convergence of the genuine finite-rank operator series.
- Self-adjointness and exact exhaustion of the entire nonzero complex spectrum
  by the real diagonal values; no additional nonzero spectrum is omitted.
- Every nonzero eigenspace is actually finite-dimensional and has dimension
  equal to the finite coefficient-fiber cardinality.
- The maximal generalized eigenspace equals the ordinary eigenspace. Thus the
  dimensions are the actual algebraic multiplicities, with no Jordan chains.
- Absolute summability of all eigenvalues counted with those multiplicities.
- The operator-only spectral product is invariant under similarity, in
  particular under arbitrary unitary changes of basis. Its equality to the
  absolutely convergent diagonal product is proved by grouping equal values.

These facts justify the ordinary spectral definition of the Fredholm
determinant for this compact self-adjoint trace-class perturbation. This is
not a scalar product renamed without an operator identification.
`PhysicalFredholm.ordinary_determinant_eq_compression` proves equality with the
actual physical compression determinant, and
`couplingPressure_eq_ordinary_fredholm_action` gives the same-operator action
formula for every actual bounded physical family.

A general trace-norm completion or a Fredholm API for arbitrary nonnormal
operators is not constructed. The restricted spectral route above suffices for
this self-adjoint target. The interacting physical family, its sharp bound
and equality to the actual microscopic pressure limit are now instantiated
in `SYKMainTheorem.continuum_free_energy`; they are not supplied as premises
of that unconditional theorem.

## Complex action and whole-space uniqueness

`ComplexFourierOperatorAction` now extends the actual nested Lebesgue action
to every bounded measurable complex test, with the genuine half-frequency
L² representative proved almost everywhere. `ComplexPhysicalUniqueness`
constructs bounded tests equal to every genuine Fourier basis vector and
proves that this action determines a unique continuous operator on the whole
Hilbert space. Thus the physical operator identification is not limited to
a real-test formula or an assumed density statement.
