import InteractingMoments
import WardMoments

/-!
# All-endpoint free Weyl / exterior correspondence

The operator numerator constructed in InteractingMoments is identified with
our actual exterior Wick functional at zero Hamiltonian. The proof covers
arbitrarily many coincident-time blocks and repeated complete labels.
-/

noncomputable section
open scoped BigOperators

namespace SYK.FreeWeyl
open Interacting

/-- The actual exterior word at the specified flavor-time labels. -/
def exteriorWord {N : ℕ} {β : ℝ} {k : ℕ} (L : Fin k → ThermalWick.Label N β) :
    ExteriorAlgebra ℂ (ThermalWick.FieldSpace N β) :=
  ExteriorAlgebra.ιMulti ℂ k (fun i => Finsupp.single (L i) 1)

/-- With zero Hamiltonian every gap propagator is the identity. -/
theorem timeProduct_zero_hamiltonian {ν : Type*} [Fintype ν] [DecidableEq ν]
    {k : ℕ} (β : ℝ) (t : Fin k → ℝ) (A : Fin k → Matrix ν ν ℂ) :
    timeProduct 0 β t A = (List.ofFn A).prod := by
  induction k generalizing β with
  | zero => simp [Gibbs.weight]
  | succ k ih => simp [timeProduct_succ, ih, Gibbs.weight, List.ofFn_succ]

/-- Scalar multiplication commutes with the exact signed averaging operation. -/
theorem signedAverage_mul {ι : Type*} (S : Finset ι) (ε : ι → ℤˣ) (f : ι → ℂ) (c : ℂ) :
    c * signedAverage S ε f = signedAverage S ε (fun i => c * f i) := by
  unfold signedAverage
  rw [← mul_assoc, mul_comm c, mul_assoc, Finset.mul_sum]
  congr 1
  apply Finset.sum_congr rfl
  intro i hi
  rcases Int.units_eq_one_or (ε i) with h | h <;> simp [h]

/-- If each signed summand has the same value, normalized averaging preserves it. -/
theorem signedAverage_eq {ι : Type*} (S : Finset ι) (hS : S.Nonempty)
    (ε : ι → ℤˣ) (f : ι → ℂ) (c : ℂ) (h : ∀ i ∈ S, ε i • f i = c) :
    signedAverage S ε f = c := by
  unfold signedAverage
  rw [Finset.sum_congr rfl h, Finset.sum_const, nsmul_eq_mul, ← mul_assoc,
    inv_mul_cancel₀, one_mul]
  exact_mod_cast Finset.card_ne_zero.mpr hS

/-- At arbitrary endpoint coincidences, the actual free operator Weyl numerator
is exactly the exterior Wick expectation, including all fermionic signs. -/
theorem free_weyl_eq_expectation (d : ℕ) {β : ℝ} (hβ : 0 < β) {k : ℕ}
    (hk : Even k) (L : Fin k → ThermalWick.Label (2*d) β) :
    ((2 : ℂ)^d)⁻¹ * weylNumerator (0 : Matrix (Majorana.Basis d) (Majorana.Basis d) ℂ) β
      (fun i => (L i).2.val) (fun i => Majorana.chiFin d (L i).1) =
      ThermalWick.expectation (2*d) β (exteriorWord L) := by
  classical
  by_cases hinj : Function.Injective L
  · unfold weylNumerator
    rw [signedAverage_mul]
    apply signedAverage_eq _ (sortingPerms_nonempty _)
    intro σ hσ
    have hord : (List.ofFn (fun i => L (σ i))).Pairwise (fun p q =>
        q.2.val < p.2.val ∨ p.1 ≠ q.1) := by
      apply List.pairwise_ofFn.mpr
      intro i j hij
      have htime := (mem_sortingPerms _ σ).mp hσ hij.le
      dsimp [Function.comp_def] at htime
      rcases lt_or_eq_of_le htime with hlt | heq
      · exact Or.inl hlt
      · right
        intro hflavor
        apply (ne_of_lt hij) (σ.injective (hinj ?_))
        apply Prod.ext hflavor
        apply Subtype.ext
        exact heq.symm
    have htrace := FreeWick.thermal_trace_of_ordered_equal_flavors d β hβ
      (List.ofFn (fun i => L (σ i))) (by simpa using hk) hord
    have hperm : exteriorWord (fun i => L (σ i)) = Equiv.Perm.sign σ • exteriorWord L :=
      (ExteriorAlgebra.ιMulti ℂ k).map_perm (fun i => Finsupp.single (L i) 1) σ
    rw [FreeWick.word_ofFn, FreeWick.word_ofFn] at htrace
    change Majorana.normalizedTrace d (List.ofFn (fun i => Majorana.chiFin d (L (σ i)).1)).prod =
      ThermalWick.expectation (2*d) β (exteriorWord (fun i => L (σ i))) at htrace
    rw [hperm] at htrace
    simp only [Function.comp_def, timeProduct_zero_hamiltonian]
    rcases Int.units_eq_one_or (Equiv.Perm.sign σ) with hsign | hsign
    · simpa [hsign, Majorana.normalizedTrace, div_eq_mul_inv, mul_comm] using htrace
    · simpa [hsign, Majorana.normalizedTrace, div_eq_mul_inv, mul_comm, ThermalWick.expectation]
        using congrArg Neg.neg htrace
  · simp only [Function.Injective, not_forall, _root_.not_imp] at hinj
    obtain ⟨i, j, hij, hne⟩ := hinj
    rw [weylNumerator_eq_zero_of_repeat _ _ _ _ i j hne
      (congrArg (fun p : ThermalWick.Label (2*d) β => p.2.val) hij)
      (congrArg (fun p : ThermalWick.Label (2*d) β => Majorana.chiFin d p.1) hij), mul_zero]
    have hw : exteriorWord L = 0 := by
      exact (ExteriorAlgebra.ιMulti ℂ k).map_eq_zero_of_eq
        (fun r => Finsupp.single (L r) (1 : ℂ)) (i := i) (j := j)
        (congrArg (fun p => Finsupp.single p (1 : ℂ)) hij) hne
    rw [hw]
    simp [ThermalWick.expectation]



/-- Dimension-free bound for the actual exterior Wick expectation of every
finite even field word, with arbitrary coincident endpoints. -/
theorem expectation_exteriorWord_bound (d : ℕ) {β : ℝ} (hβ : 0 < β) {k : ℕ}
    (hk : Even k) (L : Fin k → ThermalWick.Label (2*d) β) :
    ‖ThermalWick.expectation (2*d) β (exteriorWord L)‖ ≤ ((Real.sqrt 2)⁻¹)^k := by
  rw [← free_weyl_eq_expectation d hβ hk L, norm_mul, norm_inv, norm_pow]
  norm_num only [Complex.norm_ofNat]
  have h := weylNumerator_bound (Matrix.isHermitian_zero :
      (0 : Matrix (Majorana.Basis d) (Majorana.Basis d) ℂ).IsHermitian) hβ
    (fun i => (L i).2.val) (fun i => ⟨(L i).2.property.1, (L i).2.property.2.le⟩)
    (fun i => Majorana.chiFin d (L i).1)
  have hp : Gibbs.partition β (0 : Matrix (Majorana.Basis d) (Majorana.Basis d) ℂ) =
      (2 : ℝ)^d := by simp [Gibbs.partition, Gibbs.weight, Matrix.trace_one, ← Complex.ofReal_ofNat, ← Complex.ofReal_pow]
  simp only [hp, ThermalBound.opNorm, Majorana.chiFin, Majorana.norm_chi,
    Finset.prod_const, Finset.card_univ, Fintype.card_fin] at h
  calc
    _ ≤ ((2 : ℝ)^d)⁻¹ * ((2 : ℝ)^d * ((Real.sqrt 2)⁻¹)^k) :=
      mul_le_mul_of_nonneg_left h (by positivity)
    _ = _ := by rw [← mul_assoc, inv_mul_cancel₀ (by positivity), one_mul]

/-- List form of the same bound, useful for integrated interaction vertices. -/
theorem expectation_word_bound (d : ℕ) {β : ℝ} (hβ : 0 < β)
    (L : List (ThermalWick.Label (2*d) β)) (hk : Even L.length) :
    ‖ThermalWick.expectation (2*d) β
      (FreeWick.word (fun p => ThermalWick.field p.1 p.2) L)‖ ≤ ((Real.sqrt 2)⁻¹)^L.length := by
  have h := expectation_exteriorWord_bound d hβ hk L.get
  change ‖ThermalWick.expectation (2*d) β
    (List.ofFn (fun i => ThermalWick.field (L.get i).1 (L.get i).2)).prod‖ ≤ _ at h
  rw [← FreeWick.word_ofFn (fun p : ThermalWick.Label (2*d) β => ThermalWick.field p.1 p.2) L.get,
    List.ofFn_get] at h
  exact h

/-- The free moment bound persists with an arbitrary even external field word.
It is proved by the actual finite flavor expansion of the collective symbols. -/
theorem expectation_word_collective_bound (d : ℕ) (hd : 0 < d) {β : ℝ} (hβ : 0 < β)
    (ps : List (ThermalWick.Time β × ThermalWick.Time β)) :
    ∀ (L : List (ThermalWick.Label (2*d) β)), Even L.length →
    ‖ThermalWick.expectation (2*d) β
      (FreeWick.word (fun p => ThermalWick.field p.1 p.2) L *
        Ward.collectiveMonomial (N := 2*d) ps)‖ ≤
      ((Real.sqrt 2)⁻¹)^L.length * (1/2 : ℝ)^ps.length := by
  induction ps with
  | nil => intro L hL; simpa [Ward.collectiveMonomial] using expectation_word_bound d hβ L hL
  | cons p ps ih =>
    intro L hL
    have hN : ((2*d : ℕ) : ℝ) ≠ 0 := by exact_mod_cast (show 2*d ≠ 0 by omega)
    have hs (i : Fin (2*d)) :
        ‖ThermalWick.expectation (2*d) β
          (FreeWick.word (fun p => ThermalWick.field p.1 p.2) L *
            (ThermalWick.field i p.1 * ThermalWick.field i p.2) *
              Ward.collectiveMonomial (N := 2*d) ps)‖ ≤
        ((Real.sqrt 2)⁻¹)^L.length * (1/2 : ℝ)^(ps.length+1) := by
      have he : Even (L ++ ([(i,p.1), (i,p.2)] : List (ThermalWick.Label (2*d) β))).length := by
        simpa only [List.length_append, List.length_cons, List.length_nil] using hL.add (by decide : Even 2)
      have h := ih (L ++ ([(i,p.1), (i,p.2)] : List (ThermalWick.Label (2*d) β))) he
      have hp : ((Real.sqrt 2)⁻¹ : ℝ)^2 = 1/2 := by
        rw [inv_pow, Real.sq_sqrt (by norm_num)]; norm_num
      convert h using 1
      · simp only [FreeWick.word_append, FreeWick.word_cons, FreeWick.word_nil, mul_one, mul_assoc]
      · simp only [List.length_append, List.length_cons, List.length_nil, Nat.reduceAdd, pow_add, hp]
        rw [pow_succ]
        ring
    change ‖ThermalWick.expectation (2*d) β
      (FreeWick.word (fun p => ThermalWick.field p.1 p.2) L *
        (ThermalWick.collective (2*d) β p.1 p.2 * Ward.collectiveMonomial ps))‖ ≤ _
    simp only [ThermalWick.collective, mul_smul_comm, smul_mul_assoc,
      Finset.sum_mul, Finset.mul_sum, ThermalWick.expectation, map_smul, map_sum, norm_smul,
      Complex.norm_natCast, norm_inv]
    calc
      _ ≤ ((2*d : ℕ) : ℝ)⁻¹ * ∑ i : Fin (2*d),
          ‖(ThermalWick.covariance (2*d) β).expectation
            (FreeWick.word (fun p => ThermalWick.field p.1 p.2) L *
              (ThermalWick.field i p.1 * ThermalWick.field i p.2 * Ward.collectiveMonomial ps))‖ :=
        mul_le_mul_of_nonneg_left (norm_sum_le _ _) (by positivity)
      _ ≤ ((2*d : ℕ) : ℝ)⁻¹ * ∑ _i : Fin (2*d),
          (((Real.sqrt 2)⁻¹)^L.length * (1/2 : ℝ)^(ps.length+1)) := by
        apply mul_le_mul_of_nonneg_left _ (by positivity)
        exact Finset.sum_le_sum (fun i _ => by simpa only [mul_assoc] using hs i)
      _ = _ := by
        simp only [Finset.sum_const, Finset.card_univ, Fintype.card_fin, nsmul_eq_mul, List.length_cons]
        rw [← mul_assoc, inv_mul_cancel₀ hN, one_mul]

/-- The paper's free collective monomial bound, derived from the CAR operator
model and exact exterior correspondence at all endpoint configurations. -/
theorem expectation_collectiveMonomial_bound (d : ℕ) (hd : 0 < d) {β : ℝ} (hβ : 0 < β)
    (ps : List (ThermalWick.Time β × ThermalWick.Time β)) :
    ‖ThermalWick.expectation (2*d) β (Ward.collectiveMonomial (N := 2*d) ps)‖ ≤
      (1/2 : ℝ)^ps.length := by
  simpa using expectation_word_collective_bound d hd hβ ps [] (by simp)

end SYK.FreeWeyl
