import GaussianIntegrationByParts
import ProductGaussianMGF
import Mathlib.Probability.Moments.IntegrableExpMul

/-!
# Actual Gaussian moments and coefficientwise exponential averaging

All scalar coefficients below are genuine integrals against the exact centered
Gaussian law, including zero variance. The moment recurrence follows from the
proved integration-by-parts theorem; no Wick or Gaussian-moment axiom is used.
-/

set_option maxHeartbeats 1000000
noncomputable section
open MeasureTheory ProbabilityTheory
open scoped BigOperators NNReal
namespace SYK.GaussianCoefficient

/-- Every Gaussian monomial is integrable. -/
theorem integrable_pow (v : ℝ≥0) (n : ℕ) :
    Integrable (fun x : ℝ => x^n) (gaussianReal 0 v) := by
  exact integrable_pow_of_integrable_exp_mul (X := id) (t := (1 : ℝ)) (by norm_num)
    (GaussianDisorder.integrable_exp_linear v 1)
    (GaussianDisorder.integrable_exp_linear v (-1)) n

/-- Actual moments, rather than a recursively specified expectation. -/
def moment (v : ℝ≥0) (n : ℕ) : ℝ := ∫ x, x^n ∂gaussianReal 0 v

@[simp] theorem moment_zero (v : ℝ≥0) : moment v 0 = 1 := by simp [moment]

@[simp] theorem moment_one (v : ℝ≥0) : moment v 1 = 0 := by
  have h := GaussianIBP.centered_stein_identity_all v (fun _ => 1) (fun _ => 0)
    (fun x => hasDerivAt_const x (1 : ℝ)) (integrable_const 1) (integrable_const 0)
    (by simpa using integrable_pow v 1)
  simpa [moment] using h

/-- The full Gaussian moment recursion, proved by actual integration by parts. -/
theorem moment_add_two (v : ℝ≥0) (n : ℕ) :
    moment v (n+2) = (v : ℝ) * (n+1) * moment v n := by
  have h := GaussianIBP.centered_stein_identity_all v
    (fun x => x^(n+1)) (fun x => (n+1 : ℝ) * x^n)
    (fun x => by simpa using hasDerivAt_pow (n+1) x)
    (integrable_pow v (n+1)) ((integrable_pow v n).const_mul (n+1))
    (by simpa only [← pow_succ'] using integrable_pow v (n+2))
  simpa only [← pow_succ', integral_const_mul, moment, mul_assoc] using h

/-- Odd moments vanish, also for the zero-variance Dirac law. -/
theorem moment_odd (v : ℝ≥0) (k : ℕ) : moment v (2*k+1) = 0 := by
  induction k with
  | zero => simp
  | succ k ih =>
    rw [show 2*(k+1)+1 = (2*k+1)+2 by omega, moment_add_two, ih, mul_zero]

/-- The exact even moment in factorial normalization. -/
theorem moment_even (v : ℝ≥0) (k : ℕ) :
    moment v (2*k) = ((2*k).factorial : ℝ) / ((2 : ℝ)^k * (k.factorial : ℝ)) * (v : ℝ)^k := by
  induction k with
  | zero => simp
  | succ k ih =>
    rw [show 2*(k+1) = 2*k+2 by omega, moment_add_two, ih]
    rw [show 2*k+2 = (2*k+1)+1 by omega, Nat.factorial_succ, Nat.factorial_succ,
      Nat.factorial_succ]
    push_cast
    rw [pow_succ, pow_succ]
    have hk : (k.factorial : ℝ) ≠ 0 := by positivity
    have htwo : (2 : ℝ)^k ≠ 0 := by positivity
    field_simp
    ring

/-- The factorial-normalized even coefficient of the Gaussian exponential. -/
theorem moment_even_div_factorial (v : ℝ≥0) (k : ℕ) :
    moment v (2*k) / ((2*k).factorial : ℝ) = ((v : ℝ)/2)^k / (k.factorial : ℝ) := by
  rw [moment_even, div_pow]
  field_simp
  ring

variable (ι : Type*) [Fintype ι]

/-- Every monomial under the actual independent product law is integrable. -/
theorem integrable_monomial (v : ℝ≥0) (n : ι → ℕ) :
    Integrable (fun j : ι → ℝ => ∏ i, (j i)^(n i)) (ProductGaussianMGF.law ι v) := by
  letI : MeasureSpace ℝ := ⟨gaussianReal 0 v⟩
  haveI : IsProbabilityMeasure (volume : Measure ℝ) :=
    inferInstanceAs (IsProbabilityMeasure (gaussianReal 0 v))
  exact Integrable.fintype_prod (fun i => integrable_pow v (n i))

/-- Exact product monomial integral, proved by product integration. -/
theorem integral_monomial (v : ℝ≥0) (n : ι → ℕ) :
    (∫ j, (∏ i, (j i)^(n i)) ∂ProductGaussianMGF.law ι v) = ∏ i, moment v (n i) := by
  letI : MeasureSpace ℝ := ⟨gaussianReal 0 v⟩
  haveI : IsProbabilityMeasure (volume : Measure ℝ) :=
    inferInstanceAs (IsProbabilityMeasure (gaussianReal 0 v))
  exact integral_fintype_prod_eq_prod ι (fun i (x : ℝ) => x^(n i))

/-- One odd coordinate kills the full product monomial. -/
theorem integral_monomial_odd (v : ℝ≥0) (n : ι → ℕ)
    (i : ι) (k : ℕ) (hi : n i = 2*k+1) :
    (∫ j, (∏ i, (j i)^(n i)) ∂ProductGaussianMGF.law ι v) = 0 := by
  classical
  rw [integral_monomial]
  exact Finset.prod_eq_zero (Finset.mem_univ i) (by rw [hi, moment_odd])

/-- Factorial coefficients factor independently in every Gaussian coordinate. -/
theorem integral_even_monomial_coefficient (v : ℝ≥0) (k : ι → ℕ) :
    (∫ j, (∏ i, (j i)^(2*k i)) ∂ProductGaussianMGF.law ι v) /
        (∏ i, ((2*k i).factorial : ℝ)) =
      ∏ i, ((v : ℝ)/2)^(k i) / ((k i).factorial : ℝ) := by
  rw [integral_monomial, ← Finset.prod_div_distrib]
  exact Finset.prod_congr rfl (fun i _ => moment_even_div_factorial v (k i))

end SYK.GaussianCoefficient
