import ContinuumWickWard

noncomputable section
open MeasureTheory
namespace SYK.ContinuumWickSeries
open ThermalWick Ward

def contactValue {β : ℝ} (F : List (Time β × Time β) → ℂ) (s t : Time β) :
    List (Time β × Time β) → List (Time β × Time β) → ℂ
  | [], _ => 0
  | p::ps, qs => (Thermal.kernel β s.val p.1.val:ℂ)*F ((p.2,t)::(ps++qs)) -
      (Thermal.kernel β s.val p.2.val:ℂ)*F ((p.1,t)::(ps++qs)) +
      contactValue F s t ps (p::qs)

/-- Evaluating the exact exterior contact produces a finite recursion of genuine
collective moments, including repeated endpoints and empty insertions. -/
theorem expectation_contact_monomial {N : ℕ} {β : ℝ} (s t : Time β)
    (ps qs : List (Time β × Time β)) :
    expectation N β (contactPolynomial s t ps*collectiveMonomial qs) =
      contactValue (fun l => expectation N β (collectiveMonomial l)) s t ps qs := by
  induction ps generalizing qs with
  | nil => simp [contactPolynomial,contactValue]
  | cons p ps ih =>
    have hcomm := even_commutes (collective N β p.1 p.2)
      (contactPolynomial s t ps) (collective_even N β p.1 p.2)
    simp only [contactPolynomial,add_mul,sub_mul,smul_mul_assoc,map_add,map_sub,map_smul,smul_eq_mul,
      contactValue]
    have htail : expectation N β
        (collective N β p.1 p.2*contactPolynomial s t ps*collectiveMonomial qs) =
        contactValue (fun l => expectation N β (collectiveMonomial l)) s t ps (p::qs) := by
      rw [hcomm,mul_assoc]
      exact ih (p::qs)
    rw [htail]
    congr 2 <;> congr 1 <;> simp [collectiveMonomial,List.map_append,List.prod_append,mul_assoc]

/-- A finite contact expansion preserves measurability. -/
theorem contactValue_measurable {β : ℝ} {Ω : Type*} [MeasurableSpace Ω]
    (F : Ω → List (Time β × Time β) → ℂ) (hF : ∀ l, Measurable (fun x => F x l))
    (s t : Time β) (ps qs : List (Time β × Time β)) :
    Measurable (fun x => contactValue (F x) s t ps qs) := by
  induction ps generalizing qs with
  | nil => exact measurable_const
  | cons p ps ih =>
    exact ((hF _).const_mul _ |>.sub ((hF _).const_mul _)).add (ih _)

/-- Exact scalar bound for the finite contact expansion. -/
theorem contactValue_bound {β : ℝ} (F : List (Time β × Time β) → ℂ)
    (B : ℝ) (_hB : 0 ≤ B) (hF : ∀ l, ‖F l‖ ≤ B*(1/2:ℝ)^l.length)
    (s t : Time β) (ps qs : List (Time β × Time β)) :
    ‖contactValue F s t ps qs‖ ≤ (ps.length:ℝ)*B*(1/2:ℝ)^(ps.length+qs.length) := by
  have hc (u : Time β) : ‖(Thermal.kernel β s.val u.val:ℂ)‖ ≤ 1/2 := by
    simpa only [Complex.norm_real,Real.norm_eq_abs] using Thermal.abs_covariance_le β (s.val-u.val)
  induction ps generalizing qs with
  | nil => simp [contactValue]
  | cons p ps ih =>
    apply (norm_add_le _ _).trans
    apply (add_le_add ((norm_sub_le _ _).trans (add_le_add
      ((norm_mul_le _ _).trans (mul_le_mul (hc p.1) (hF _) (norm_nonneg _) (by norm_num)))
      ((norm_mul_le _ _).trans (mul_le_mul (hc p.2) (hF _) (norm_nonneg _) (by norm_num))))) (ih (p::qs))).trans
    simp only [List.length_cons,List.length_append,Nat.cast_add,Nat.cast_one]
    rw [show ps.length+(qs.length+1)=ps.length+qs.length+1 by omega]
    rw [show ps.length+1+qs.length=ps.length+qs.length+1 by omega]
    rw [pow_succ]
    ring_nf
    exact le_rfl

theorem contactValue_integrable {β : ℝ} {Ω : Type*} [MeasurableSpace Ω]
    (μ : Measure Ω) (F : Ω → List (Time β × Time β) → ℂ)
    (hF : ∀ l, Integrable (fun x => F x l) μ)
    (s t : Time β) (ps qs : List (Time β × Time β)) :
    Integrable (fun x => contactValue (F x) s t ps qs) μ := by
  induction ps generalizing qs with
  | nil => simp only [contactValue]; exact integrable_zero _ _ _
  | cons p ps ih => exact (((hF _).const_mul _).sub ((hF _).const_mul _)).add (ih _)

theorem integral_contactValue {β : ℝ} {Ω : Type*} [MeasurableSpace Ω]
    (μ : Measure Ω) (F : Ω → List (Time β × Time β) → ℂ)
    (hF : ∀ l, Integrable (fun x => F x l) μ)
    (s t : Time β) (ps qs : List (Time β × Time β)) :
    (∫ x, contactValue (F x) s t ps qs ∂μ) =
      contactValue (fun l => ∫ x, F x l ∂μ) s t ps qs := by
  induction ps generalizing qs with
  | nil => simp [contactValue]
  | cons p ps ih =>
    simp only [contactValue]
    have hA := (hF ((p.2,t)::(ps++qs))).const_mul (Thermal.kernel β s.val p.1.val:ℂ)
    have hB := (hF ((p.1,t)::(ps++qs))).const_mul (Thermal.kernel β s.val p.2.val:ℂ)
    have hAB := hA.sub hB
    simp only [Pi.sub_apply] at hAB
    erw [integral_add hAB (contactValue_integrable μ F hF s t ps (p::qs)),
      integral_sub hA hB,integral_const_mul,integral_const_mul,ih]

theorem contactValue_hasSum {β : ℝ} {ι : Type*}
    (F : ι → List (Time β × Time β) → ℂ) (S : List (Time β × Time β) → ℂ)
    (hF : ∀ l, HasSum (fun i => F i l) (S l))
    (s t : Time β) (ps qs : List (Time β × Time β)) :
    HasSum (fun i => contactValue (F i) s t ps qs) (contactValue S s t ps qs) := by
  induction ps generalizing qs with
  | nil => simp only [contactValue]; exact hasSum_zero
  | cons p ps ih => exact (((hF _).mul_left _).sub ((hF _).mul_left _)).add (ih _)

end SYK.ContinuumWickSeries
