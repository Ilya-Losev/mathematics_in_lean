import ContinuumSYKCorollaries
import MomentRepresentationIndependence
import AbstractRepresentationTransport

/-!
# Full realization scope of the continuum SYK conclusions

The moment addendum transfers to every matrix CAR realization. Its all-real
version uses the explicit signed half-open reduction before Weyl evaluation.
The pressure and free-energy theorem also transfers to actual continuous
operators on arbitrary finite-dimensional complex normed spaces, hence in
particular to the manuscript's abstract Hilbert spaces. No basis or unitary
equivalence is an input to these corollaries.
-/
noncomputable section
open MeasureTheory Filter Set
open scoped Topology BigOperators NNReal
namespace SYK.ContinuumSYKMain
open Continuum ThermalEndpointLift ThermalMomentTransport WeightedKernelAlgebra
variable (β : ℝ) [Fact (0 < β)]

/-- The actual arbitrary-realization thermal extension reduces labels before
Weyl evaluation and retains the exact antiperiodic winding sign. -/
def thermalCollectiveMoment {κ : Type*} [Fintype κ] [DecidableEq κ]
    (d : ℕ) (x : Fin (2*d) → Matrix κ κ ℂ) (lam : ℝ≥0)
    {k : ℕ} (p : Fin k → Endpoint) : ℂ :=
  (∏ i, pairSign β Fact.out (p i)) *
    MomentRepresentationIndependence.collectiveMoment d x β lam
      (fun i => ((representative β Fact.out (p i).1).val,
        (representative β Fact.out (p i).2).val))

section Matrix
variable {κ : ℕ → Type*} [∀ d, Fintype (κ d)] [∀ d, DecidableEq (κ d)]
  (x : ∀ d, Fin (2*d) → Matrix (κ d) (κ d) ℂ)
  (hx : ∀ d, 2 ≤ d → ∀ i j, x d i*x d j+x d j*x d i =
    FreeWick.flavorDelta i j • (1 : Matrix (κ d) (κ d) ℂ))
  (hcard : ∀ d, 2 ≤ d → Fintype.card (κ d) = 2^d)
include hx hcard

/-- Uniform convergence of the literal generic-realization raw moments on all
primary endpoint configurations, including arbitrary endpoint coincidences. -/
theorem MainConclusion.arbitrary_primary_moments {g : ℝ≥0 → ℝ → ℝ}
    (h : MainConclusion β g) (lam : ℝ≥0) (k : ℕ) :
    TendstoUniformly
      (fun d (p : Fin k → Ico (0:ℝ) β × Ico (0:ℝ) β) =>
        MomentRepresentationIndependence.collectiveMoment d (x d) β lam
          (fun i => ((p i).1.val,(p i).2.val)))
      (fun p => ∏ i, (g lam ((p i).1.val-(p i).2.val) : ℂ)) atTop := by
  have he : (fun d (p : Fin k → Ico (0:ℝ) β × Ico (0:ℝ) β) =>
      MomentRepresentationIndependence.collectiveMoment d (x d) β lam
        (fun i => ((p i).1.val,(p i).2.val))) =ᶠ[atTop]
      (fun d p => Interacting.collectiveMoment d β lam
        (fun i => ((p i).1.val,(p i).2.val))) := by
    filter_upwards [eventually_ge_atTop 2] with d hd
    funext p
    exact MomentRepresentationIndependence.collectiveMoment_eq d (x d) (hx d hd)
      (hcard d hd) β lam _
  exact (tendstoUniformly_congr he).mpr ((h.moments lam).primary k)

/-- Uniform all-real moment convergence for every CAR realization, with the
same actual midpoint-corrected thermal extension as the canonical theorem. -/
theorem MainConclusion.arbitrary_thermal_moments {g : ℝ≥0 → ℝ → ℝ}
    (h : MainConclusion β g) (lam : ℝ≥0) (k : ℕ) :
    TendstoUniformly (fun d (p : Fin k → Endpoint) => thermalCollectiveMoment β d (x d) lam p)
      (fun p => ∏ i, (g lam ((p i).1-(p i).2) : ℂ)) atTop := by
  have he : (fun d (p : Fin k → Endpoint) => thermalCollectiveMoment β d (x d) lam p)
      =ᶠ[atTop] (fun d p => actualThermalPolynomial β Fact.out d lam
        (∏ i, MvPolynomial.X (p i))) := by
    filter_upwards [eventually_ge_atTop 2] with d hd
    funext p
    rw [actualThermalPolynomial_tuple]
    unfold thermalCollectiveMoment
    rw [MomentRepresentationIndependence.collectiveMoment_eq d (x d) (hx d hd) (hcard d hd)]
  exact (tendstoUniformly_congr he).mpr ((h.moments lam).thermal k)
end Matrix

section Abstract
variable {E : ℕ → Type*} [∀ d, NormedAddCommGroup (E d)] [∀ d, NormedSpace ℂ (E d)]
  [∀ d, FiniteDimensional ℂ (E d)]
  (x : ∀ d, Fin (2*d) → E d →L[ℂ] E d)
  (hx : ∀ d, 2 ≤ d → ∀ i j, x d i*x d j+x d j*x d i =
    FreeWick.flavorDelta i j • (1 : E d →L[ℂ] E d))
  (hdim : ∀ d, 2 ≤ d → Module.finrank ℂ (E d) = 2^d)
include hx hdim

/-- Both actual pressures for arbitrary abstract finite-dimensional spaces,
using the genuine basis-free ordinary trace of the operator exponential.
Every finite-dimensional Hilbert realization in the manuscript is included. -/
theorem MainConclusion.abstract_pressures {g : ℝ≥0 → ℝ → ℝ}
    (h : MainConclusion β g) (J : ℝ) :
    Tendsto (fun d => AbstractRepresentation.annealedPressure d (x d) β (couplingOfJ J))
      atTop (𝓝 (couplingPressure β g (couplingOfJ J))) ∧
    Tendsto (fun d => AbstractRepresentation.quenchedPressure d (x d) β (couplingOfJ J))
      atTop (𝓝 (couplingPressure β g (couplingOfJ J))) := by
  have ha : (fun d => AbstractRepresentation.annealedPressure d (x d) β (couplingOfJ J))
      =ᶠ[atTop] (fun d => Microscopic.annealedPressure d β (couplingOfJ J)) := by
    filter_upwards [eventually_ge_atTop 2] with d hd
    exact AbstractRepresentation.annealedPressure_eq d (x d) (hx d hd) (hdim d hd) β _
  have hq : (fun d => AbstractRepresentation.quenchedPressure d (x d) β (couplingOfJ J))
      =ᶠ[atTop] (fun d => Microscopic.quenchedPressure d β (couplingOfJ J)) := by
    filter_upwards [eventually_ge_atTop 2] with d hd
    exact AbstractRepresentation.quenchedPressure_eq d (x d) (hx d hd) (hdim d hd) β _
  exact ⟨(h.pressure _).1.congr' ha.symm, (h.pressure _).2.congr' hq.symm⟩

/-- Actual basis-free free energies, with the exact sign and normalization per
Majorana. No assumptions on the irrelevant sizes N<4 are required. -/
theorem MainConclusion.abstract_freeEnergy {g : ℝ≥0 → ℝ → ℝ}
    (h : MainConclusion β g) (J : ℝ) :
    Tendsto (fun d => -AbstractRepresentation.annealedPressure d (x d) β (couplingOfJ J)/β)
      atTop (𝓝 (couplingFreeEnergy β g J)) ∧
    Tendsto (fun d => -AbstractRepresentation.quenchedPressure d (x d) β (couplingOfJ J)/β)
      atTop (𝓝 (couplingFreeEnergy β g J)) := by
  have hp := h.abstract_pressures β x hx hdim J
  exact ⟨hp.1.neg.div_const β, hp.2.neg.div_const β⟩
end Abstract

end SYK.ContinuumSYKMain
