import FiniteWardRegularity
import Mathlib.Algebra.MvPolynomial.Derivation

/-! Exact all-real polynomial contact derivation and its sharp centered bounds. -/
noncomputable section
open scoped BigOperators
namespace SYK.RealWardContacts
open WeightedKernelAlgebra MixedIncrement MvPolynomial

def contactGenerator (β s t : ℝ) (p : Endpoint) : Polynomial :=
  (Thermal.kernel β s p.1:ℂ) • X (p.2,t) -
    (Thermal.kernel β s p.2:ℂ) • X (p.1,t)

def contact (β s t : ℝ) : Derivation ℂ Polynomial Polynomial :=
  MvPolynomial.mkDerivation ℂ (contactGenerator β s t)

@[simp] theorem contact_X (β s t : ℝ) (p : Endpoint) :
    contact β s t (X p)=contactGenerator β s t p := by
  exact MvPolynomial.mkDerivation_X ..

@[simp] theorem contact_C (β s t : ℝ) (z : ℂ) : contact β s t (C z)=0 := by
  exact Derivation.map_algebraMap _ z

@[simp] theorem contact_remainder (β s t : ℝ) (p : Endpoint) :
    contact β s t (remainder β p)=contactGenerator β s t p := by
  simp [MixedIncrement.remainder]

theorem contact_coordinateProduct (β s t : ℝ) (p : Endpoint) (ps : List Endpoint) :
    contact β s t (coordinateProduct (p::ps)) =
      contactGenerator β s t p * coordinateProduct ps +
        X p * contact β s t (coordinateProduct ps) := by
  simp only [coordinateProduct,List.map_cons,List.prod_cons,Derivation.leibniz,smul_eq_mul]
  rw [contact_X]
  ring

theorem coefficientNorm_X (p : Endpoint) :
    coefficientNorm (fun _ : Endpoint => (1/2:ℝ)) (X p) = 1/2 := by
  change coefficientNorm (fun _ : Endpoint => (1/2:ℝ)) (monomial (Finsupp.single p 1) (1:ℂ)) = 1/2
  rw [coefficientNorm_monomial,monomialWeight_single]
  norm_num

theorem coefficientNorm_contactGenerator_le (β s t : ℝ) (p : Endpoint) :
    coefficientNorm (fun _ : Endpoint => (1/2:ℝ)) (contactGenerator β s t p) ≤ 1/2 := by
  have hc (u : ℝ) : ‖(Thermal.kernel β s u:ℂ)‖ ≤ 1/2 := by
    simpa only [Complex.norm_real,Real.norm_eq_abs] using Thermal.abs_covariance_le β (s-u)
  unfold contactGenerator
  rw [sub_eq_add_neg]
  apply (coefficientNorm_add_le _ (fun _ => by norm_num) _ _).trans
  rw [coefficientNorm_neg,coefficientNorm_smul,coefficientNorm_smul,coefficientNorm_X,coefficientNorm_X]
  nlinarith [hc p.1,hc p.2]

/-- Every centered factor contributes two Wick contacts, independently of time seams. -/
theorem coefficientNorm_contact_remainderProduct_le (β s t : ℝ) (ps : List Endpoint) :
    coefficientNorm (fun _ : Endpoint => (1/2:ℝ)) (contact β s t (remainderProduct β ps)) ≤
      (ps.length:ℝ)/2 := by
  induction ps with
  | nil => simp [contact]
  | cons p ps ih =>
    rw [remainderProduct_cons,Derivation.leibniz]
    simp only [smul_eq_mul,contact_remainder]
    apply (coefficientNorm_add_le _ (fun _ => by norm_num) _ _).trans
    have h1 := coefficientNorm_mul_le (fun _ : Endpoint => (1/2:ℝ)) (fun _ => by norm_num)
      (remainder β p) (contact β s t (remainderProduct β ps))
    have h2 := coefficientNorm_mul_le (fun _ : Endpoint => (1/2:ℝ)) (fun _ => by norm_num)
      (remainderProduct β ps) (contactGenerator β s t p)
    have hn := coefficientNorm_nonneg (fun _ : Endpoint => (1/2:ℝ)) (fun _ => by norm_num)
      (contact β s t (remainderProduct β ps))
    have hA := h1.trans (mul_le_mul (coefficientNorm_remainder_le β p) ih hn zero_le_one)
    have hB := h2.trans (mul_le_mul (coefficientNorm_remainderProduct_le β ps)
      (coefficientNorm_contactGenerator_le β s t p)
      (coefficientNorm_nonneg _ (fun _ => by norm_num) _) zero_le_one)
    simp only [List.length_cons,Nat.cast_add,Nat.cast_one]
    linarith

/-- Literal inverse-N contact estimate for any coefficient-bounded polynomial functional. -/
theorem centered_contact_bound (β s t : ℝ) (d : ℕ) (hd : 0 < d)
    (L : Polynomial →ₗ[ℂ] ℂ)
    (hL : ∀ Q, ‖L Q‖ ≤ coefficientNorm (fun _ : Endpoint => (1/2:ℝ)) Q)
    (ps : List Endpoint) :
    ‖((2*d:ℕ):ℂ)⁻¹ * L (contact β s t (remainderProduct β ps))‖ ≤
      (ps.length:ℝ)/(4*d) := by
  rw [norm_mul,norm_inv,Complex.norm_natCast]
  have h := mul_le_mul_of_nonneg_left
    ((hL _).trans (coefficientNorm_contact_remainderProduct_le β s t ps))
    (inv_nonneg.mpr (Nat.cast_nonneg (2*d): (0:ℝ) ≤ (2*d:ℕ)))
  apply h.trans_eq
  have hdR : (d:ℝ) ≠ 0 := by exact_mod_cast hd.ne'
  push_cast
  field_simp [hdR]
  ring_nf
  simp

end SYK.RealWardContacts
