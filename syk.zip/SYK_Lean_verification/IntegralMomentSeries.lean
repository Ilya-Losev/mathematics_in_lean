import ExponentialMomentSeries
import Mathlib.MeasureTheory.Integral.DominatedConvergence

/-! # Interchanging thermal time integrals and the interacting scalar series -/
noncomputable section
open MeasureTheory Set
open scoped Topology
namespace SYK.ExponentialMomentSeries

variable {Ω : Type*} [MeasurableSpace Ω] (μ : Measure Ω) [IsFiniteMeasure μ]

/-- Pointwise scalar majorant underlying the factorial-series interchange. -/
theorem norm_term_le (a : ℕ → ℂ) (K R : ℝ)
    (ha : ∀ n, ‖a n‖ ≤ K*R^n) (l : ℝ) (n : ℕ) :
    ‖term a l n‖ ≤ K*((|l| * R)^n / (n.factorial : ℝ)) := by
  simp only [term, norm_smul, Real.norm_eq_abs, abs_div, abs_pow, Nat.abs_cast]
  calc
    _ ≤ (|l|^n / (n.factorial : ℝ)) * (K*R^n) := by gcongr; exact ha n
    _ = _ := by rw [mul_pow]; ring

/-- Every time-dependent coefficient is integrated as an actual Bochner
function under the explicit finite-measure coefficient bound. -/
theorem integrable_term_parameter (b : Ω → ℕ → ℂ) (K R : ℝ)
    (hmeas : ∀ n, AEStronglyMeasurable (fun x => b x n) μ)
    (hb : ∀ x n, ‖b x n‖ ≤ K*R^n) (l : ℝ) (n : ℕ) :
    Integrable (fun x => term (b x) l n) μ := by
  apply (integrable_const (K*((|l| * R)^n / (n.factorial : ℝ)))).mono'
  · exact (hmeas n).const_smul _
  · exact ae_of_all _ (fun x => norm_term_le (b x) K R (hb x) l n)

/-- The integral norms of all series terms are summable, so Fubini is
available without an assumed summation/interchange property. -/
theorem summable_integral_norm_term (b : Ω → ℕ → ℂ) (K R : ℝ)
    (hmeas : ∀ n, AEStronglyMeasurable (fun x => b x n) μ)
    (hb : ∀ x n, ‖b x n‖ ≤ K*R^n) (l : ℝ) :
    Summable (fun n => ∫ x, ‖term (b x) l n‖ ∂μ) := by
  apply Summable.of_nonneg_of_le (fun n => integral_nonneg (fun x => norm_nonneg _)) _
    ((Real.summable_pow_div_factorial (|l| * R)).mul_left (μ.real univ*K))
  intro n
  have h := integral_mono (integrable_term_parameter μ b K R hmeas hb l n).norm
    (integrable_const (K*((|l| * R)^n / (n.factorial : ℝ))))
    (fun x => norm_term_le (b x) K R (hb x) l n)
  simpa only [integral_const, smul_eq_mul, mul_assoc] using h

/-- The integral of the entire interacting series equals the entire series
of integrated coefficients. -/
theorem integral_value (b : Ω → ℕ → ℂ) (K R : ℝ)
    (hmeas : ∀ n, AEStronglyMeasurable (fun x => b x n) μ)
    (hb : ∀ x n, ‖b x n‖ ≤ K*R^n) (l : ℝ) :
    (∫ x, value (b x) l ∂μ) = value (fun n => ∫ x, b x n ∂μ) l := by
  have h := hasSum_integral_of_summable_integral_norm
    (integrable_term_parameter μ b K R hmeas hb l)
    (summable_integral_norm_term μ b K R hmeas hb l)
  simpa only [value, term, integral_smul] using h.tsum_eq.symm

/-- An integrated coefficient insertion recurrence gives the true derivative
with the insertion integrated after summation. -/
theorem hasDerivAt_value_integrated_insertion (a : ℕ → ℂ) (b : Ω → ℕ → ℂ)
    (Ka Kb R c : ℝ) (hKa : 0 ≤ Ka) (hR : 0 ≤ R)
    (ha : ∀ n, ‖a n‖ ≤ Ka*R^n)
    (hmeas : ∀ n, AEStronglyMeasurable (fun x => b x n) μ)
    (hb : ∀ x n, ‖b x n‖ ≤ Kb*R^n)
    (hinsert : ∀ n, a (n+1) = c • ∫ x, b x n ∂μ) (l : ℝ) :
    HasDerivAt (value a) (c • ∫ x, value (b x) l ∂μ) l := by
  rw [integral_value μ b Kb R hmeas hb l]
  exact hasDerivAt_value_insertion a (fun n => ∫ x, b x n ∂μ) Ka R c hKa hR ha hinsert l

end SYK.ExponentialMomentSeries
