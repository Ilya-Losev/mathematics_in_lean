import WeightedKernelAlgebra
import ThermalCovariance
import Mathlib.Algebra.Order.ToIntervalMod
import Mathlib.Algebra.Ring.Periodic
import Mathlib.Algebra.MvPolynomial.Rename

/-!
# Signed all-real thermal endpoint lift

Endpoints are reduced to [0,β) BEFORE applying a Weyl-ordered moment. This is
essential at the thermal seam: raw distinct labels β and 0 are not an
equal-time Weyl block. The construction below never identifies those raw
moments without proof. It defines the midpoint-consistent thermal family.
-/

noncomputable section
namespace SYK.ThermalEndpointLift
open SYK.WeightedKernelAlgebra
open scoped BigOperators
open Set Function

abbrev FundamentalTime (β : ℝ) := Icc (0 : ℝ) β
abbrev FundamentalPair (β : ℝ) := FundamentalTime β × FundamentalTime β
abbrev FundamentalPolynomial (β : ℝ) := MvPolynomial (FundamentalPair β) ℂ
abbrev RealPolynomial := MvPolynomial Endpoint ℂ

variable (β : ℝ) (hβ : 0 < β)

/-- The representative always lies in [0,β), but is embedded in the compact
closed interval used by the uniform moment extraction. -/
def representative (t : ℝ) : FundamentalTime β :=
  ⟨toIcoMod hβ 0 t, (toIcoMod_mem_Ico' hβ t).1, (toIcoMod_mem_Ico' hβ t).2.le⟩

def periodNumber (t : ℝ) : ℤ := toIcoDiv hβ 0 t

/-- The fermionic sign contributed by crossing an integer number of periods. -/
def endpointSign (t : ℝ) : ℂ := ((periodNumber β hβ t).negOnePow : ℤ)

@[simp] theorem norm_endpointSign (t : ℝ) : ‖endpointSign β hβ t‖ = 1 := by
  rcases Int.units_eq_one_or ((periodNumber β hβ t).negOnePow) with h | h <;>
    simp [endpointSign, h]

@[simp] theorem endpointSign_sq (t : ℝ) : endpointSign β hβ t * endpointSign β hβ t = 1 := by
  rcases Int.units_eq_one_or ((periodNumber β hβ t).negOnePow) with h | h <;>
    simp [endpointSign, h]

@[simp] theorem representative_add_period (t : ℝ) :
    representative β hβ (t+β) = representative β hβ t := by
  apply Subtype.ext
  exact toIcoMod_add_right hβ 0 t

@[simp] theorem endpointSign_add_period (t : ℝ) :
    endpointSign β hβ (t+β) = -endpointSign β hβ t := by
  simp only [endpointSign, periodNumber, toIcoDiv_add_right, Int.negOnePow_succ,
    Units.val_neg, Int.cast_neg]

@[simp] theorem representative_zero : (representative β hβ 0 : ℝ) = 0 :=
  toIcoMod_apply_left hβ 0

@[simp] theorem endpointSign_zero : endpointSign β hβ 0 = 1 := by
  simp [endpointSign, periodNumber, toIcoDiv_apply_left]

@[simp] theorem representative_period : representative β hβ β = representative β hβ 0 := by
  simpa using representative_add_period β hβ 0

@[simp] theorem endpointSign_period : endpointSign β hβ β = -1 := by
  simpa using endpointSign_add_period β hβ 0

/-- Within the primary half-open thermal interval, no endpoint is changed. -/
theorem representative_of_mem {t : ℝ} (ht : t ∈ Ico 0 β) :
    (representative β hβ t : ℝ) = t := by
  exact (toIcoMod_eq_self hβ).mpr (by simpa using ht)

theorem endpointSign_of_mem {t : ℝ} (ht : t ∈ Ico 0 β) : endpointSign β hβ t = 1 := by
  have hn : toIcoDiv hβ 0 t = 0 :=
    toIcoDiv_eq_of_sub_zsmul_mem_Ico hβ (by simpa using ht)
  simp [endpointSign, periodNumber, hn]

/-- Reduction of a genuinely antiperiodic function, with no seam exception. -/
theorem antiperiodic_reduce (f : ℝ → ℂ) (hf : Antiperiodic f β) (t : ℝ) :
    f t = endpointSign β hβ t * f (representative β hβ t) := by
  have hh := hf.add_zsmul_eq (x := (representative β hβ t : ℝ)) (periodNumber β hβ t)
  rw [show (representative β hβ t : ℝ) + periodNumber β hβ t • β = t from
    toIcoMod_add_toIcoDiv_zsmul hβ 0 t] at hh
  simpa only [endpointSign, zsmul_eq_mul] using hh

def representativePair (p : Endpoint) : FundamentalPair β :=
  (representative β hβ p.1, representative β hβ p.2)

def pairSign (p : Endpoint) : ℂ := endpointSign β hβ p.1 * endpointSign β hβ p.2

@[simp] theorem norm_pairSign (p : Endpoint) : ‖pairSign β hβ p‖ = 1 := by
  simp [pairSign, norm_mul]

/-- Signed coordinate substitution. In particular (β,0) is sent to minus the
same equal-time diagonal variable as (0,0), not to a raw distinct-time word. -/
def liftedVariable (p : Endpoint) : FundamentalPolynomial β :=
  pairSign β hβ p • MvPolynomial.X (representativePair β hβ p)

/-- Algebraic transport from all real labels into the original compact cube. -/
def polynomialReduction : RealPolynomial →ₐ[ℂ] FundamentalPolynomial β :=
  MvPolynomial.aeval (liftedVariable β hβ)

@[simp] theorem polynomialReduction_X (p : Endpoint) :
    polynomialReduction β hβ (MvPolynomial.X p) = liftedVariable β hβ p := MvPolynomial.aeval_X _ _

/-- Transport any compact-cube moment functional. No compatibility of raw
boundary values is assumed by this definition. -/
def liftFunctional (L : FundamentalPolynomial β →ₗ[ℂ] ℂ) : RealPolynomial →ₗ[ℂ] ℂ :=
  L.comp (polynomialReduction β hβ).toLinearMap

@[simp] theorem liftFunctional_apply (L : FundamentalPolynomial β →ₗ[ℂ] ℂ) (P : RealPolynomial) :
    liftFunctional β hβ L P = L (polynomialReduction β hβ P) := rfl

@[simp] theorem liftFunctional_one (L : FundamentalPolynomial β →ₗ[ℂ] ℂ) :
    liftFunctional β hβ L 1 = L 1 := by simp [liftFunctional]

/-- The corrected cube functional reduces boundary labels before evaluating the
original functional. It is the family to which compactness should be applied. -/
def cubeReduction : FundamentalPolynomial β →ₐ[ℂ] FundamentalPolynomial β :=
  MvPolynomial.aeval (fun p => liftedVariable β hβ (p.1.val,p.2.val))

def correctedCubeFunctional (L : FundamentalPolynomial β →ₗ[ℂ] ℂ) : FundamentalPolynomial β →ₗ[ℂ] ℂ :=
  L.comp (cubeReduction β hβ).toLinearMap

@[simp] theorem correctedCubeFunctional_one (L : FundamentalPolynomial β →ₗ[ℂ] ℂ) :
    correctedCubeFunctional β hβ L 1 = L 1 := by simp [correctedCubeFunctional]

/-- Exact separate antiperiodicity holds already as a polynomial identity. -/
theorem liftedVariable_antiperiodic_left (s t : ℝ) :
    liftedVariable β hβ (s+β,t) = -liftedVariable β hβ (s,t) := by
  simp [liftedVariable, pairSign, representativePair, neg_smul]

theorem liftedVariable_antiperiodic_right (s t : ℝ) :
    liftedVariable β hβ (s,t+β) = -liftedVariable β hβ (s,t) := by
  simp [liftedVariable, pairSign, representativePair, neg_smul]

/-- Every polynomial insertion retains the exact left thermal sign. -/
theorem liftFunctional_antiperiodic_left (L : FundamentalPolynomial β →ₗ[ℂ] ℂ)
    (P : RealPolynomial) (s t : ℝ) :
    liftFunctional β hβ L (P * MvPolynomial.X (s+β,t)) =
      -liftFunctional β hβ L (P * MvPolynomial.X (s,t)) := by
  simp only [liftFunctional_apply, map_mul, polynomialReduction_X,
    liftedVariable_antiperiodic_left, mul_neg, map_neg]

theorem liftFunctional_antiperiodic_right (L : FundamentalPolynomial β →ₗ[ℂ] ℂ)
    (P : RealPolynomial) (s t : ℝ) :
    liftFunctional β hβ L (P * MvPolynomial.X (s,t+β)) =
      -liftFunctional β hβ L (P * MvPolynomial.X (s,t)) := by
  simp only [liftFunctional_apply, map_mul, polynomialReduction_X,
    liftedVariable_antiperiodic_right, mul_neg, map_neg]

/-- The weighted coefficient norm controls evaluation in any normed algebra
whose generator values satisfy the assigned bounds. -/
theorem weighted_aeval_bound {ι A : Type*} [NormedCommRing A] [NormedAlgebra ℂ A] [NormOneClass A]
    (w : Weights ι) (f : ι → A) (hf : ∀ i, ‖f i‖ ≤ w.value i) (P : MvPolynomial ι ℂ) :
    ‖MvPolynomial.aeval f P‖ ≤ coefficientNorm w.value P := by
  classical
  have hmon (d : ι →₀ ℕ) (c : ℂ) :
      ‖MvPolynomial.aeval f (MvPolynomial.monomial d c)‖ ≤ ‖c‖ * monomialWeight w.value d := by
    rw [MvPolynomial.aeval_monomial]
    calc
      _ ≤ ‖algebraMap ℂ A c‖ * ‖d.prod (fun i n => f i ^ n)‖ := norm_mul_le _ _
      _ ≤ ‖c‖ * monomialWeight w.value d := by
        rw [norm_algebraMap, norm_one, mul_one]
        apply mul_le_mul_of_nonneg_left _ (norm_nonneg _)
        change ‖∏ i ∈ d.support, f i ^ d i‖ ≤ ∏ i ∈ d.support, w.value i ^ d i
        apply (Finset.norm_prod_le d.support (fun i => f i ^ d i)).trans
        apply Finset.prod_le_prod (fun i _ => norm_nonneg _)
        intro i hi
        calc
          _ ≤ ‖f i‖ ^ d i := norm_pow_le _ _
          _ ≤ w.value i ^ d i := by gcongr; exact hf i
  conv_lhs => rw [P.as_sum]
  rw [map_sum]
  exact (norm_sum_le _ _).trans (Finset.sum_le_sum fun d _ => hmon d (MvPolynomial.coeff d P))

/-- Constant bilocal weights on any endpoint index type. -/
def constantWeights (ι : Type*) (b : ℝ) (hb : 0 < b) : Weights ι := ⟨fun _ => b, fun _ => hb⟩

/-- Fermionic signs do not change the assigned size of a coordinate generator. -/
theorem coefficientNorm_liftedVariable (b : ℝ) (hb : 0 < b) (p : Endpoint) :
    coefficientNorm (fun _ : FundamentalPair β => b) (liftedVariable β hβ p) = b := by
  rw [liftedVariable, coefficientNorm_smul, norm_pairSign, one_mul]
  exact WeightedPolynomial.norm_X (constantWeights (FundamentalPair β) b hb) _

/-- Signed endpoint reduction is contractive for the sharp coefficient norm,
including the cases where several real labels reduce to the same coordinate. -/
theorem polynomialReduction_bound (b : ℝ) (hb : 0 < b) (P : RealPolynomial) :
    coefficientNorm (fun _ : FundamentalPair β => b) (polynomialReduction β hβ P) ≤
      coefficientNorm (fun _ : Endpoint => b) P := by
  let w := constantWeights (FundamentalPair β) b hb
  exact weighted_aeval_bound (constantWeights Endpoint b hb)
    (fun p => WeightedPolynomial.ofPolynomial w (liftedVariable β hβ p))
    (fun p => (coefficientNorm_liftedVariable β hβ b hb p).le) P

/-- The corrected compact cube functional has precisely the original sharp
coefficient bound, not a larger seam-dependent constant. -/
theorem cubeReduction_bound (b : ℝ) (hb : 0 < b) (P : FundamentalPolynomial β) :
    coefficientNorm (fun _ : FundamentalPair β => b) (cubeReduction β hβ P) ≤
      coefficientNorm (fun _ : FundamentalPair β => b) P := by
  let w := constantWeights (FundamentalPair β) b hb
  exact weighted_aeval_bound w
    (fun p => WeightedPolynomial.ofPolynomial w (liftedVariable β hβ (p.1.val,p.2.val)))
    (fun p => (coefficientNorm_liftedVariable β hβ b hb (p.1.val,p.2.val)).le) P

theorem liftFunctional_bound (b : ℝ) (hb : 0 < b)
    (L : FundamentalPolynomial β →ₗ[ℂ] ℂ)
    (hL : ∀ P, ‖L P‖ ≤ coefficientNorm (fun _ : FundamentalPair β => b) P) (P : RealPolynomial) :
    ‖liftFunctional β hβ L P‖ ≤ coefficientNorm (fun _ : Endpoint => b) P :=
  (hL _).trans (polynomialReduction_bound β hβ b hb P)

theorem correctedCubeFunctional_bound (b : ℝ) (hb : 0 < b)
    (L : FundamentalPolynomial β →ₗ[ℂ] ℂ)
    (hL : ∀ P, ‖L P‖ ≤ coefficientNorm (fun _ : FundamentalPair β => b) P)
    (P : FundamentalPolynomial β) :
    ‖correctedCubeFunctional β hβ L P‖ ≤ coefficientNorm (fun _ : FundamentalPair β => b) P :=
  (hL _).trans (cubeReduction_bound β hβ b hb P)

/-- Separate antiperiodicity determines all endpoint lifts from the primary
square. This applies in particular to the midpoint-prescribed free covariance. -/
theorem kernel_reduce (f : Endpoint → ℂ)
    (hleft : ∀ t, Antiperiodic (fun s => f (s,t)) β)
    (hright : ∀ s, Antiperiodic (fun t => f (s,t)) β) (p : Endpoint) :
    f p = pairSign β hβ p * f ((representative β hβ p.1).val, (representative β hβ p.2).val) := by
  rw [antiperiodic_reduce β hβ (fun s => f (s,p.2)) (hleft p.2) p.1,
    antiperiodic_reduce β hβ (fun t => f ((representative β hβ p.1).val,t))
      (hright _) p.2]
  exact (mul_assoc _ _ _).symm

/-- The free covariance is transported exactly, including zero at every
coincident thermal endpoint. -/
theorem freeCovariance_reduce (p : Endpoint) :
    (Thermal.kernel β p.1 p.2 : ℂ) = pairSign β hβ p *
      (Thermal.kernel β (representative β hβ p.1) (representative β hβ p.2) : ℂ) := by
  apply kernel_reduce β hβ (fun p => (Thermal.kernel β p.1 p.2 : ℂ))
  · intro t s
    change (Thermal.covariance β ((s+β)-t) : ℂ) = -(Thermal.covariance β (s-t) : ℂ)
    rw [show (s+β)-t = (s-t)+β by ring, Thermal.covariance_antiperiodic β hβ.ne', Complex.ofReal_neg]
  · intro s t
    change (Thermal.kernel β s (t+β) : ℂ) = -(Thermal.kernel β s t : ℂ)
    rw [Thermal.kernel_skew β (t+β) s]
    simp only [Thermal.kernel, Complex.ofReal_neg]
    change -(Thermal.covariance β ((t+β)-s) : ℂ) = -(Thermal.covariance β (s-t) : ℂ)
    rw [show (t+β)-s = (t-s)+β by ring, Thermal.covariance_antiperiodic β hβ.ne', Complex.ofReal_neg, neg_neg]
    simpa only [Thermal.kernel, Complex.ofReal_neg] using
      congrArg Complex.ofReal (Thermal.kernel_skew β s t)

/-- Actual remainder polynomials on the compact and all-real label sets. -/
def compactRemainder (p : FundamentalPair β) : FundamentalPolynomial β :=
  MvPolynomial.X p - MvPolynomial.C (Thermal.kernel β p.1 p.2 : ℂ)

def realRemainder (p : Endpoint) : RealPolynomial :=
  MvPolynomial.X p - MvPolynomial.C (Thermal.kernel β p.1 p.2 : ℂ)

/-- Centering commutes with signed reduction exactly. This equality, not a
replacement of G by a continuous kernel, transports every mixed insertion. -/
theorem polynomialReduction_remainder (p : Endpoint) :
    polynomialReduction β hβ (realRemainder β p) =
      pairSign β hβ p • compactRemainder β (representativePair β hβ p) := by
  simp only [realRemainder, map_sub, polynomialReduction_X, ← MvPolynomial.algebraMap_eq,
    AlgHom.commutes, liftedVariable, compactRemainder, smul_sub]
  rw [freeCovariance_reduce β hβ p]
  congr 1
  simp only [Algebra.smul_def, map_mul]
  rfl

/-- Exact transport formula for a product of centered increments and arbitrary
coordinate insertions. No stronger mixed bound is inferred from plain bounds. -/
theorem polynomialReduction_mixed {m k : ℕ} (x : Fin m → Endpoint)
    (p q : Fin k → Endpoint) :
    polynomialReduction β hβ
      ((∏ i, MvPolynomial.X (x i)) * ∏ j, (realRemainder β (p j) - realRemainder β (q j))) =
      (∏ i, liftedVariable β hβ (x i)) *
        ∏ j, (pairSign β hβ (p j) • compactRemainder β (representativePair β hβ (p j)) -
          pairSign β hβ (q j) • compactRemainder β (representativePair β hβ (q j))) := by
  simp only [map_mul, map_prod, map_sub, polynomialReduction_X, polynomialReduction_remainder]

/-- Interior coordinate polynomials are unchanged by the thermal correction. -/
theorem liftedVariable_of_mem (p : FundamentalPair β)
    (hp : p.1.val < β ∧ p.2.val < β) : liftedVariable β hβ (p.1.val,p.2.val) = MvPolynomial.X p := by
  have h1 : p.1.val ∈ Ico 0 β := ⟨p.1.property.1, hp.1⟩
  have h2 : p.2.val ∈ Ico 0 β := ⟨p.2.property.1, hp.2⟩
  have hreps : representativePair β hβ (p.1.val,p.2.val) = p := by
    apply Prod.ext <;> apply Subtype.ext
    · exact representative_of_mem β hβ h1
    · exact representative_of_mem β hβ h2
  simp only [liftedVariable, pairSign, endpointSign_of_mem β hβ h1,
    endpointSign_of_mem β hβ h2, one_mul, one_smul, hreps]

/-- Any finite polynomial whose labels lie in [0,β) retains its exact value.
The positive and reflected half-time algebras are special cases. -/
theorem cubeReduction_rename {ι : Type*} (e : ι → FundamentalPair β)
    (he : ∀ i, (e i).1.val < β ∧ (e i).2.val < β) (P : MvPolynomial ι ℂ) :
    cubeReduction β hβ (MvPolynomial.rename e P) = MvPolynomial.rename e P := by
  have hh : (cubeReduction β hβ).comp (MvPolynomial.rename e) = MvPolynomial.rename e := by
    apply MvPolynomial.algHom_ext
    intro i
    simp only [AlgHom.comp_apply, MvPolynomial.rename_X, cubeReduction, MvPolynomial.aeval_X]
    change liftedVariable β hβ ((e i).1.val,(e i).2.val) = MvPolynomial.X (e i)
    exact liftedVariable_of_mem β hβ (e i) (he i)
  exact AlgHom.congr_fun hh P

/-- The reduction of an arbitrary real polynomial already has primary-interval
labels, so a second thermal reduction does nothing. -/
theorem cubeReduction_polynomialReduction (P : RealPolynomial) :
    cubeReduction β hβ (polynomialReduction β hβ P) = polynomialReduction β hβ P := by
  have hh : (cubeReduction β hβ).comp (polynomialReduction β hβ) = polynomialReduction β hβ := by
    apply MvPolynomial.algHom_ext
    intro p
    simp only [AlgHom.comp_apply, polynomialReduction_X, liftedVariable, map_smul]
    simp only [cubeReduction, MvPolynomial.aeval_X]
    change pairSign β hβ p • liftedVariable β hβ
      ((representative β hβ p.1).val,(representative β hβ p.2).val) = _
    apply congrArg (fun Q => pairSign β hβ p • Q)
    exact liftedVariable_of_mem β hβ (representativePair β hβ p)
      ⟨(toIcoMod_mem_Ico' hβ p.1).2, (toIcoMod_mem_Ico' hβ p.2).2⟩
  exact AlgHom.congr_fun hh P

/-- Correcting the cube before or after all-real transport gives exactly the
same moment functional. This links the corrected compactness family to real labels. -/
theorem liftFunctional_corrected (L : FundamentalPolynomial β →ₗ[ℂ] ℂ) (P : RealPolynomial) :
    liftFunctional β hβ (correctedCubeFunctional β hβ L) P = liftFunctional β hβ L P := by
  change L (cubeReduction β hβ (polynomialReduction β hβ P)) = _
  rw [cubeReduction_polynomialReduction]
  rfl

/-- A full tuple moment acquires the product of its endpoint winding signs. -/
theorem liftFunctional_tuple (L : FundamentalPolynomial β →ₗ[ℂ] ℂ) {k : ℕ}
    (p : Fin k → Endpoint) :
    liftFunctional β hβ L (∏ i, MvPolynomial.X (p i)) =
      (∏ i, pairSign β hβ (p i)) * L (∏ i, MvPolynomial.X (representativePair β hβ (p i))) := by
  simp only [liftFunctional_apply, map_prod, polynomialReduction_X, liftedVariable,
    Algebra.smul_def]
  rw [Finset.prod_mul_distrib, ← map_prod]
  rw [← Algebra.smul_def, map_smul, smul_eq_mul]

/-- Every fixed all-real polynomial converges once the corrected compact-cube
polynomials converge; no countability assumption on the real labels is made. -/
theorem liftFunctional_tendsto {α : Type*} {l : Filter α}
    (L : α → FundamentalPolynomial β →ₗ[ℂ] ℂ) (Llim : FundamentalPolynomial β →ₗ[ℂ] ℂ)
    (hL : ∀ P, Filter.Tendsto (fun n => correctedCubeFunctional β hβ (L n) P) l (nhds (Llim P)))
    (P : RealPolynomial) :
    Filter.Tendsto (fun n => liftFunctional β hβ (L n) P) l (nhds (liftFunctional β hβ Llim P)) := by
  simpa only [← liftFunctional_apply, liftFunctional_corrected] using hL (polynomialReduction β hβ P)

/-- Equal real endpoints reduce to the same compact diagonal. Thus diagonal
Weyl vanishing transports to every thermal seam. -/
theorem liftFunctional_diagonal (L : FundamentalPolynomial β →ₗ[ℂ] ℂ)
    (hdiag : ∀ (P : FundamentalPolynomial β) (t : FundamentalTime β),
      L (P * MvPolynomial.X (t,t)) = 0) (P : RealPolynomial) (t : ℝ) :
    liftFunctional β hβ L (P * MvPolynomial.X (t,t)) = 0 := by
  simp only [liftFunctional_apply, map_mul, polynomialReduction_X, liftedVariable,
    mul_smul_comm, map_smul]
  change pairSign β hβ (t,t) • L ((polynomialReduction β hβ) P *
    MvPolynomial.X (representative β hβ t, representative β hβ t)) = 0
  rw [hdiag, smul_zero]

/-- The previously problematic pair (β,0) vanishes with every insertion, by
signed reduction and equal-time diagonal vanishing. -/
theorem liftFunctional_seam_diagonal (L : FundamentalPolynomial β →ₗ[ℂ] ℂ)
    (hdiag : ∀ (P : FundamentalPolynomial β) (t : FundamentalTime β),
      L (P * MvPolynomial.X (t,t)) = 0) (P : RealPolynomial) :
    liftFunctional β hβ L (P * MvPolynomial.X (β,0)) = 0 := by
  simpa only [zero_add, liftFunctional_diagonal β hβ L hdiag, neg_zero] using
    liftFunctional_antiperiodic_left β hβ L P 0 0

/-- Skewness with arbitrary insertion is transported, including every winding
and every coincidence of reduced endpoint labels. -/
theorem liftFunctional_skew (L : FundamentalPolynomial β →ₗ[ℂ] ℂ)
    (hskew : ∀ (P : FundamentalPolynomial β) (p : FundamentalPair β),
      L (P * MvPolynomial.X (p.2,p.1)) = -L (P * MvPolynomial.X p))
    (P : RealPolynomial) (s t : ℝ) :
    liftFunctional β hβ L (P * MvPolynomial.X (t,s)) =
      -liftFunctional β hβ L (P * MvPolynomial.X (s,t)) := by
  simp only [liftFunctional_apply, map_mul, polynomialReduction_X, liftedVariable,
    mul_smul_comm, map_smul]
  change (endpointSign β hβ t * endpointSign β hβ s) •
      L ((polynomialReduction β hβ) P * MvPolynomial.X (representative β hβ t, representative β hβ s)) =
    -((endpointSign β hβ s * endpointSign β hβ t) •
      L ((polynomialReduction β hβ) P * MvPolynomial.X (representative β hβ s, representative β hβ t)))
  rw [hskew _ (representative β hβ s,representative β hβ t), smul_neg, mul_comm]

/-- Arbitrary polynomial tests supported away from the upper seam, including
the positive and reflected half-time tests, retain their values exactly. -/
theorem correctedCubeFunctional_rename {ι : Type*} (L : FundamentalPolynomial β →ₗ[ℂ] ℂ)
    (e : ι → FundamentalPair β) (he : ∀ i, (e i).1.val < β ∧ (e i).2.val < β)
    (P : MvPolynomial ι ℂ) :
    correctedCubeFunctional β hβ L (MvPolynomial.rename e P) = L (MvPolynomial.rename e P) := by
  change L (cubeReduction β hβ (MvPolynomial.rename e P)) = _
  rw [cubeReduction_rename β hβ e he]

end SYK.ThermalEndpointLift
