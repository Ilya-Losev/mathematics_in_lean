import ThermalWeightedState
import KernelFinalActions

/-!
# Descending actual limiting moments through the Bochner SD ideal

Continuous linearity commutes the constructed regularity state through the
actual iterated convolution integrals. Thus the scalar inserted Ward identities
annihilate the complete second closed ideal and construct the final state.
-/

noncomputable section
namespace SYK.ThermalResidualState
open SYK.WeightedKernelAlgebra SYK.ThermalEndpointLift SYK.ThermalMomentTransport
open SYK.MomentLimit SYK.MomentCompactness SYK.MixedIncrement SYK.ThermalWeightedState
open SYK.KernelResidualAlgebra SYK.KernelCoordinateGeneration SYK.KernelFinalActions
open MeasureTheory Filter Set
open scoped BigOperators Topology NNReal

private theorem halfPositive : (0 : ℝ) < 1/2 := by norm_num

section LinearConvolution
variable {A : Type*} [NormedCommRing A] [NormedAlgebra ℂ A] [CompleteSpace A]
  [NormOneClass A]

theorem clm_inserted_convolution (β : ℝ) (hβ : 0 ≤ β) (L : A →L[ℂ] ℂ)
    (a : A) (f g : KernelSpace A) (p : Endpoint) :
    L (a * kernelConvolution β hβ f g p) =
      ∫ u in (0:ℝ)..β, L (a * (f (p.1,u) * g (u,p.2))) := by
  let La : A →L[ℂ] ℂ := L.comp (ContinuousLinearMap.mul ℂ A a)
  exact (La.intervalIntegral_comp_comm (kernelProduct_intervalIntegrable β f g p)).symm

/-- The actual triple convolution, evaluated by a state with an arbitrary
algebra insertion, is the double scalar Ward integral. -/
theorem clm_inserted_triple (β : ℝ) (hβ : 0 ≤ β) (L : A →L[ℂ] ℂ)
    (a : A) (f g h : KernelSpace A) (p : Endpoint) :
    L (a * kernelConvolution β hβ (kernelConvolution β hβ f g) h p) =
      ∫ u in (0:ℝ)..β, ∫ v in (0:ℝ)..β,
        L (a * (f (p.1,u) * (g (u,v) * h (v,p.2)))) := by
  rw [kernelConvolution_assoc, clm_inserted_convolution]
  apply intervalIntegral.integral_congr
  intro u _
  dsimp only
  rw [← mul_assoc, clm_inserted_convolution]
  apply intervalIntegral.integral_congr
  intro v _
  dsimp only
  rw [mul_assoc]
end LinearConvolution

variable (β : ℝ) (hβ : 0 < β) (lam : ℝ≥0) (d : ℕ → ℕ) (hd : ∀ n, 0 < d n)
  (g : ∀ k, EndpointCube β k → ℂ)
  (hg : ∀ k, TendstoUniformly
    (fun n => functionalCenteredMoment (actualCorrectedPolynomial β hβ (d n) lam)) (g k) atTop)
  (K : ℝ) (hK : 0 < K) (hKlarge : (lam : ℝ)*β*(1/2:ℝ)^4 ≤ K)
  (hrep : ReplacementIdentity β (lam : ℝ) (polynomialState β hβ g))

abbrev Algebra := FirstAlgebra (1/2) K halfPositive hK β
abbrev state : Algebra β K hK →L[ℂ] ℂ := regularityState β hβ lam d hd g hg K hK hKlarge hrep
abbrev polyMap := polynomialMap (1/2) K halfPositive hK (thermalCovariance β) (symmetryRelations β)

def realPolynomialMap : RealPolynomial →ₐ[ℂ] Algebra β K hK :=
  (polyMap β K hK).comp (MvPolynomial.rename Sum.inl)

@[simp] theorem substitutePolynomial_rename (P : RealPolynomial) :
    substitutePolynomial β (MvPolynomial.rename Sum.inl P) = P := by
  have h : (substitutePolynomial β).comp (MvPolynomial.rename Sum.inl) = AlgHom.id ℂ RealPolynomial := by
    ext p
    simp
  exact AlgHom.congr_fun h P

@[simp] theorem realPolynomialMap_X (p : Endpoint) :
    realPolynomialMap β K hK (MvPolynomial.X p) =
      coordinate (1/2) K halfPositive hK (thermalCovariance β) (symmetryRelations β) p := by
  simp [realPolynomialMap, polyMap]

theorem state_inserted_real (P : MvPolynomial KernelIndex ℂ) (Q : RealPolynomial) :
    state β hβ lam d hd g hg K hK hKlarge hrep
      (polyMap β K hK P * realPolynomialMap β K hK Q) =
        polynomialState β hβ g (substitutePolynomial β P * Q) := by
  have h := regularityState_polynomial β hβ lam d hd g hg K hK hKlarge hrep
    (P * MvPolynomial.rename Sum.inl Q)
  simpa only [map_mul, substitutePolynomial_rename] using h


variable [Nontrivial (Algebra β K hK)]

@[simp] theorem G_apply (p : Endpoint) :
    G (1/2) K halfPositive hK β p =
      coordinate (1/2) K halfPositive hK (thermalCovariance β) (symmetryRelations β) p := rfl

/-- The centered coordinate is evaluated literally as G minus the fixed
scalar covariance; no multiplicativity of the moment state is used. -/
theorem state_inserted_remainder (P : MvPolynomial KernelIndex ℂ) (p : Endpoint) :
    state β hβ lam d hd g hg K hK hKlarge hrep
      (polyMap β K hK P * (G (1/2) K halfPositive hK β p - C (1/2) K halfPositive hK β p)) =
        polynomialState β hβ g (substitutePolynomial β P * SYK.MixedIncrement.remainder β p) := by
  have h := state_inserted_real β hβ lam d hd g hg K hK hKlarge hrep P (SYK.MixedIncrement.remainder β p)
  simpa only [SYK.MixedIncrement.remainder, map_sub, realPolynomialMap_X,
    ← MvPolynomial.algebraMap_eq, AlgHom.commutes, G_apply, C, scalarKernel_apply,
    thermalCovariance] using h

theorem state_inserted_left_triple (P : MvPolynomial KernelIndex ℂ) (p : Endpoint) :
    state β hβ lam d hd g hg K hK hKlarge hrep
      (polyMap β K hK P * kernelConvolution β hβ.le
        (kernelConvolution β hβ.le (C (1/2) K halfPositive hK β) ((G (1/2) K halfPositive hK β)^3))
        (G (1/2) K halfPositive hK β) p) =
      ∫ u in (0:ℝ)..β, ∫ v in (0:ℝ)..β, (Thermal.kernel β p.1 u : ℂ) *
        polynomialState β hβ g
          (substitutePolynomial β P * coordinateProduct [(u,v),(u,v),(u,v),(v,p.2)]) := by
  rw [clm_inserted_triple]
  apply intervalIntegral.integral_congr
  intro u _
  apply intervalIntegral.integral_congr
  intro v _
  simp only [C_eq_free, freeThermalKernel_apply, smul_mul_assoc, one_mul,
    mul_smul_comm, map_smul, smul_eq_mul, kernel_pow_apply, G_apply]
  congr 1
  have h := state_inserted_real β hβ lam d hd g hg K hK hKlarge hrep P
    (MvPolynomial.X (u,v)^3 * MvPolynomial.X (v,p.2))
  simpa only [map_mul, map_pow, realPolynomialMap_X, coordinateProduct,
    List.map_cons, List.map_nil, List.prod_cons, List.prod_nil, pow_succ,
    pow_zero, map_one, one_mul, mul_one, mul_assoc] using h

theorem state_inserted_right_triple (P : MvPolynomial KernelIndex ℂ) (p : Endpoint) :
    state β hβ lam d hd g hg K hK hKlarge hrep
      (polyMap β K hK P * kernelConvolution β hβ.le
        (kernelConvolution β hβ.le (G (1/2) K halfPositive hK β) ((G (1/2) K halfPositive hK β)^3))
        (C (1/2) K halfPositive hK β) p) =
      ∫ u in (0:ℝ)..β, ∫ v in (0:ℝ)..β, (Thermal.kernel β v p.2 : ℂ) *
        polynomialState β hβ g
          (substitutePolynomial β P * coordinateProduct [(p.1,u),(u,v),(u,v),(u,v)]) := by
  rw [clm_inserted_triple]
  apply intervalIntegral.integral_congr
  intro u _
  apply intervalIntegral.integral_congr
  intro v _
  simp only [C_eq_free, freeThermalKernel_apply, mul_smul_comm, mul_one,
    map_smul, smul_eq_mul, kernel_pow_apply, G_apply]
  congr 1
  have h := state_inserted_real β hβ lam d hd g hg K hK hKlarge hrep P
    (MvPolynomial.X (p.1,u) * MvPolynomial.X (u,v)^3)
  simpa only [map_mul, map_pow, realPolynomialMap_X, coordinateProduct,
    List.map_cons, List.map_nil, List.prod_cons, List.prod_nil, pow_succ,
    pow_zero, map_one, one_mul, mul_one, mul_assoc] using h


/-- The scalar left inserted limiting Ward equation, with its actual
four-coordinate moment and thermal integration domain. -/
def LeftWard (β lam : ℝ) (L : RealPolynomial →ₗ[ℂ] ℂ) : Prop :=
  ∀ Q s t, L (Q*SYK.MixedIncrement.remainder β (s,t)) =
    (lam:ℂ)*(∫ u in (0:ℝ)..β, ∫ v in (0:ℝ)..β,
      (Thermal.kernel β s u:ℂ)*L (Q*coordinateProduct [(u,v),(u,v),(u,v),(v,t)]))

/-- The independent right inserted limiting Ward equation. -/
def RightWard (β lam : ℝ) (L : RealPolynomial →ₗ[ℂ] ℂ) : Prop :=
  ∀ Q s t, L (Q*SYK.MixedIncrement.remainder β (s,t)) =
    (lam:ℂ)*(∫ u in (0:ℝ)..β, ∫ v in (0:ℝ)..β,
      (Thermal.kernel β v t:ℂ)*L (Q*coordinateProduct [(s,u),(u,v),(u,v),(u,v)]))

variable (hleft : LeftWard β (lam : ℝ) (polynomialState β hβ g))
  (hright : RightWard β (lam : ℝ) (polynomialState β hβ g))

include hleft hright in
/-- The scalar inserted Ward equations annihilate both actual algebra-valued
Bochner residuals with every dense mixed-polynomial insertion. -/
theorem state_inserted_residuals (P : MvPolynomial KernelIndex ℂ) (i : Bool × Endpoint) :
    state β hβ lam d hd g hg K hK hKlarge hrep
      (polyMap β K hK P * residuals (1/2) K halfPositive hK β hβ.le (lam : ℝ) i) = 0 := by
  rcases i with ⟨b,p⟩
  cases b with
  | false =>
    rw [residuals_false]
    simp only [rightResidual, kernel_sub_apply, kernel_smul_apply]
    rw [mul_sub, mul_smul_comm, map_sub, map_smul,
      state_inserted_remainder, state_inserted_right_triple]
    simpa only [smul_eq_mul] using sub_eq_zero.mpr (hright (substitutePolynomial β P) p.1 p.2)
  | true =>
    rw [residuals_true]
    simp only [leftResidual, kernel_sub_apply, kernel_smul_apply]
    rw [mul_sub, mul_smul_comm, map_sub, map_smul,
      state_inserted_remainder, state_inserted_left_triple]
    simpa only [smul_eq_mul] using sub_eq_zero.mpr (hleft (substitutePolynomial β P) p.1 p.2)

include hleft hright in
/-- Density supplies arbitrary completed-algebra insertions into the actual
residual tests, so the whole closed ideal is annihilated. -/
theorem state_annihilates_residuals : ∀ a i,
    state β hβ lam d hd g hg K hK hKlarge hrep
      (a * residuals (1/2) K halfPositive hK β hβ.le (lam : ℝ) i) = 0 :=
  ResidualQuotient.inserted_of_dense _ (polyMap β K hK)
    (firstQuotient_polynomials_dense _ _) _
    (state_inserted_residuals β hβ lam d hd g hg K hK hKlarge hrep hleft hright)

/-- The actual limiting state on the final double quotient. -/
def finalState : FinalAlgebra (1/2) K halfPositive hK β hβ (lam : ℝ) →L[ℂ] ℂ :=
  ResidualQuotient.descendFunctional _ (state β hβ lam d hd g hg K hK hKlarge hrep)
    (state_annihilates_residuals β hβ lam d hd g hg K hK hKlarge hrep hleft hright)
    (regularityState_bound β hβ lam d hd g hg K hK hKlarge hrep)

@[simp] theorem finalState_mk (a : Algebra β K hK) :
    finalState β hβ lam d hd g hg K hK hKlarge hrep hleft hright (ResidualQuotient.mk _ a) =
      state β hβ lam d hd g hg K hK hKlarge hrep a := rfl

@[simp] theorem finalState_one :
    finalState β hβ lam d hd g hg K hK hKlarge hrep hleft hright 1 = 1 :=
  regularityState_one β hβ lam d hd g hg K hK hKlarge hrep

include hd hg hKlarge hrep hleft hright in
/-- The microscopic normalization proves the second quotient is nonzero. -/
theorem finalAlgebra_nontrivial : Nontrivial (FinalAlgebra (1/2) K halfPositive hK β hβ (lam : ℝ)) :=
  ResidualQuotient.nontrivial_of_normalized _ (state β hβ lam d hd g hg K hK hKlarge hrep)
    (state_annihilates_residuals β hβ lam d hd g hg K hK hKlarge hrep hleft hright)
    (regularityState_bound β hβ lam d hd g hg K hK hKlarge hrep)
    (regularityState_one β hβ lam d hd g hg K hK hKlarge hrep)

theorem finalState_bound (a : FinalAlgebra (1/2) K halfPositive hK β hβ (lam : ℝ)) :
    ‖finalState β hβ lam d hd g hg K hK hKlarge hrep hleft hright a‖ ≤ ‖a‖ :=
  ResidualQuotient.descendLinear_bound _ _
    (state_annihilates_residuals β hβ lam d hd g hg K hK hKlarge hrep hleft hright)
    (regularityState_bound β hβ lam d hd g hg K hK hKlarge hrep) a

/-- Exact preservation of every limiting polynomial moment through both
closed-ideal quotients. -/
theorem finalState_polynomial (P : MvPolynomial KernelIndex ℂ) :
    finalState β hβ lam d hd g hg K hK hKlarge hrep hleft hright
      (ResidualQuotient.mk _ (polyMap β K hK P)) =
        polynomialState β hβ g (substitutePolynomial β P) :=
  regularityState_polynomial β hβ lam d hd g hg K hK hKlarge hrep P


/-- Pointwise final bilocal classes, exactly the values of the final kernel. -/
def finalCoordinate (p : Endpoint) : FinalAlgebra (1/2) K halfPositive hK β hβ (lam : ℝ) :=
  ResidualQuotient.mk _ (coordinate (1/2) K halfPositive hK (thermalCovariance β) (symmetryRelations β) p)

theorem finalState_tuple {k : ℕ} (p : Fin k → Endpoint) :
    finalState β hβ lam d hd g hg K hK hKlarge hrep hleft hright
      (∏ i, finalCoordinate β hβ lam K hK (p i)) =
        polynomialState β hβ g (∏ i, MvPolynomial.X (p i)) := by
  unfold finalCoordinate
  rw [← map_prod, finalState_mk]
  exact regularityState_tuple β hβ lam d hd g hg K hK hKlarge hrep p

/-- The actual finite-size thermal moments converge uniformly, for all real
endpoint tuples, to the constructed continuous state on the final quotient. -/
theorem actual_moments_to_finalState (k : ℕ) :
    TendstoUniformly
      (fun n (p : Fin k → Endpoint) => actualThermalPolynomial β hβ (d n) lam (∏ i, MvPolynomial.X (p i)))
      (fun p => finalState β hβ lam d hd g hg K hK hKlarge hrep hleft hright
        (∏ i, finalCoordinate β hβ lam K hK (p i))) atTop := by
  simpa only [finalState_tuple] using actualThermal_moments_tendstoUniformly β hβ lam d g hg k

end SYK.ThermalResidualState
