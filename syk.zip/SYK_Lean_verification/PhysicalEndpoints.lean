import PhysicalRegularity

noncomputable section
open Set Filter
open scoped Topology NNReal
namespace SYK.Continuum

/-- The prescribed midpoint and the SD regularity recover the actual jump
normalization as a right limit. -/
theorem physical_right_endpoint (β : ℝ) (hβ : 0 < β) (lam : ℝ≥0)
    (g : ℝ → ℝ) (hg : PhysicalSolution β lam g) :
    Tendsto g (𝓝[>] (0:ℝ)) (𝓝 (1/2:ℝ)) := by
  obtain ⟨B,hb⟩ := hg.2.1
  have hc := (physical_centered_lipschitz β hβ lam g hg B hb).continuous.continuousAt (x := 0)
  have hz : g 0 - Thermal.covariance β 0 = 0 := by
    simp [hg.2.2.2.1, Thermal.covariance, Thermal.halfSign]
  have hc' := hc.tendsto
  rw [hz] at hc'
  have he : g =ᶠ[𝓝[>] (0:ℝ)] (fun t => (g t-Thermal.covariance β t)+(1/2:ℝ)) := by
    filter_upwards [self_mem_nhdsWithin, (eventually_lt_nhds hβ).filter_mono nhdsWithin_le_nhds]
      with t ht htβ
    rw [Thermal.covariance_on_interval β hβ t ht htβ]
    ring
  have h := hc'.mono_left (nhdsWithin_le_nhds (s := Ioi (0:ℝ)))
  have hh := h.add_const (1/2:ℝ)
  simp only [zero_add] at hh
  exact hh.congr' he.symm

/-- The opposite one-sided endpoint has the same normalization. -/
theorem physical_left_endpoint (β : ℝ) (hβ : 0 < β) (lam : ℝ≥0)
    (g : ℝ → ℝ) (hg : PhysicalSolution β lam g) :
    Tendsto g (𝓝[<] β) (𝓝 (1/2:ℝ)) := by
  obtain ⟨B,hb⟩ := hg.2.1
  have hc := (physical_centered_lipschitz β hβ lam g hg B hb).continuous.continuousAt
    (x := β)
  have hgz : g β = 0 := by simpa [hg.2.2.2.1] using hg.2.2.1 0
  have hcz : Thermal.covariance β β = 0 := by
    simpa [Thermal.covariance, Thermal.halfSign] using
      Thermal.covariance_antiperiodic β hβ.ne' 0
  have hz : g β - Thermal.covariance β β = 0 := by rw [hgz,hcz]; ring
  have hc' := hc.tendsto
  rw [hz] at hc'
  have he : g =ᶠ[𝓝[<] β] (fun t => (g t-Thermal.covariance β t)+(1/2:ℝ)) := by
    filter_upwards [self_mem_nhdsWithin, (eventually_gt_nhds hβ).filter_mono nhdsWithin_le_nhds]
      with t ht ht0
    rw [Thermal.covariance_on_interval β hβ t ht0 ht]
    ring
  have h := hc'.mono_left (nhdsWithin_le_nhds (s := Iio β))
  have hh := h.add_const (1/2:ℝ)
  simp only [zero_add] at hh
  exact hh.congr' he.symm

end SYK.Continuum
