import ThermalCovariance
import MicroscopicPressure
import Mathlib.MeasureTheory.Integral.IntervalIntegral.Basic

/-!
# Concrete continuum objects

These definitions fix the continuum conventions of the supplied manuscript.
In particular convolution is a genuine Lebesgue integral, the Fourier transform
has the positive exponential convention, and the pressure is normalized per
Majorana. They do not postulate a solution or a large-N limit.
-/

noncomputable section
open MeasureTheory Set Filter
open scoped NNReal Topology
namespace SYK.Continuum

abbrev Kernel := ℝ → ℝ → ℝ

def stationaryKernel (g : ℝ → ℝ) : Kernel := fun s t => g (s - t)

def convolution (β : ℝ) (K L : Kernel) : Kernel :=
  fun s t => ∫ u in (0 : ℝ)..β, K s u * L u t

def cube (K : Kernel) : Kernel := fun s t => (K s t)^3

/-- The integrated continuum SD equation, with the prescribed jump values. -/
def SDEquation (β : ℝ) (lam : ℝ≥0) (g : ℝ → ℝ) : Prop :=
  ∀ s t, stationaryKernel g s t = Thermal.kernel β s t + (lam : ℝ) *
    convolution β (convolution β (Thermal.kernel β) (cube (stationaryKernel g)))
      (stationaryKernel g) s t

def frequency (β : ℝ) (n : ℕ) : ℝ := (2 * (n : ℝ) + 1) * Real.pi / β

def fourier (β : ℝ) (g : ℝ → ℝ) (ω : ℝ) : ℂ :=
  ∫ t in (0 : ℝ)..β, Complex.exp (Complex.I * (ω * t)) * (g t : ℂ)

/-- The physical class before deriving the sharper bound |g| ≤ 1/2. -/
def PhysicalSolution (β : ℝ) (lam : ℝ≥0) (g : ℝ → ℝ) : Prop :=
  Measurable g ∧
  (∃ B : ℝ, ∀ t, |g t| ≤ B) ∧
  (∀ t, g (t + β) = -g t) ∧
  g 0 = 0 ∧
  (∀ t, g (β - t) = g t) ∧
  (∀ n : ℕ, ∃ x : ℝ, 0 < x ∧ fourier β g (frequency β n) = Complex.I * x) ∧
  SDEquation β lam g

/-- The pressure value predicted by a family of continuum solutions. -/
def couplingPressure (β : ℝ) (g : ℝ≥0 → ℝ → ℝ) (lam : ℝ≥0) : ℝ :=
  Real.log 2 / 2 + β / 8 *
    ∫ l in (0 : ℝ)..(lam : ℝ), ∫ t in (0 : ℝ)..β, (g (Real.toNNReal l) t)^4

/-- Convergence is along the actual even flavor counts N=2m. -/
def PressureConvergence (β : ℝ) (lam : ℝ≥0) (p : ℝ) : Prop :=
  Tendsto (fun m : ℕ => Microscopic.annealedPressure m β lam) atTop (𝓝 p) ∧
  Tendsto (fun m : ℕ => Microscopic.quenchedPressure m β lam) atTop (𝓝 p)

/-- At zero coupling the actual integrated equation forces the free covariance. -/
theorem sd_zero_iff (β : ℝ) (g : ℝ → ℝ) :
    SDEquation β 0 g ↔ g = Thermal.covariance β := by
  constructor
  · intro h
    funext s
    simpa [SDEquation, stationaryKernel, Thermal.kernel] using h s 0
  · rintro rfl
    intro s t
    simp [stationaryKernel, Thermal.kernel]

end SYK.Continuum
