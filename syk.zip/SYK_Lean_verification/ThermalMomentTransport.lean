import ThermalEndpointLift
import MomentLimitHierarchy
import Mathlib.MeasureTheory.Function.Floor

/-!
# Actual seam-corrected thermal moments and their all-real limits

The correction is performed before the existing microscopic Weyl functional
is evaluated. Its sharp coefficient bound and normalization are proved from
those of the actual finite-size moments. Compactness uses an explicit
vanishing-contact modulus of this corrected family.
-/

noncomputable section
namespace SYK.ThermalMomentTransport
open SYK.WeightedKernelAlgebra SYK.ThermalEndpointLift SYK.MomentLimit SYK.MomentCompactness
open MeasureTheory Filter Set
open scoped BigOperators Topology NNReal

variable (β : ℝ) (hβ : 0 < β)

/-- Actual microscopic polynomial moments with all real endpoint labels,
reduced before sorting and antisymmetrization. -/
def actualThermalPolynomial (d : ℕ) (lam : ℝ≥0) : RealPolynomial →ₗ[ℂ] ℂ :=
  liftFunctional β hβ (actualPolynomial d β lam)

/-- The actual compact-cube family corrected at its thermal seam. -/
def actualCorrectedPolynomial (d : ℕ) (lam : ℝ≥0) : CoordinatePolynomial β →ₗ[ℂ] ℂ :=
  correctedCubeFunctional β hβ (actualPolynomial d β lam)

@[simp] theorem actualThermalPolynomial_one (d : ℕ) (lam : ℝ≥0) :
    actualThermalPolynomial β hβ d lam 1 = 1 := by
  simp [actualThermalPolynomial]

@[simp] theorem actualCorrectedPolynomial_one (d : ℕ) (lam : ℝ≥0) :
    actualCorrectedPolynomial β hβ d lam 1 = 1 := by
  simp [actualCorrectedPolynomial]

theorem actualThermalPolynomial_bound (d : ℕ) (hd : 0 < d) (lam : ℝ≥0) (P : RealPolynomial) :
    ‖actualThermalPolynomial β hβ d lam P‖ ≤ coefficientNorm (fun _ : Endpoint => 1/2) P :=
  liftFunctional_bound β hβ (1/2) (by norm_num) _ (actualPolynomial_bound d hd hβ lam) P

theorem actualCorrectedPolynomial_bound (d : ℕ) (hd : 0 < d) (lam : ℝ≥0) (P : CoordinatePolynomial β) :
    ‖actualCorrectedPolynomial β hβ d lam P‖ ≤ coefficientNorm (fun _ => 1/2) P :=
  correctedCubeFunctional_bound β hβ (1/2) (by norm_num) _ (actualPolynomial_bound d hd hβ lam) P

/-- Formula in terms of the actual finite-dimensional, flavor-averaged Weyl
moment; winding signs are applied to every occurrence. -/
theorem actualThermalPolynomial_tuple (d : ℕ) (lam : ℝ≥0) {k : ℕ} (p : Fin k → Endpoint) :
    actualThermalPolynomial β hβ d lam (∏ i, MvPolynomial.X (p i)) =
      (∏ i, pairSign β hβ (p i)) * Interacting.collectiveMoment d β lam
        (fun i => ((representative β hβ (p i).1).val, (representative β hβ (p i).2).val)) := by
  rw [actualThermalPolynomial, liftFunctional_tuple, actualPolynomial_tuple_prod]
  rfl

/-- Winding numbers and representatives are measurable, despite the unavoidable
thermal seam discontinuities. -/
theorem periodNumber_measurable : Measurable (periodNumber β hβ) := by
  change Measurable (fun t => toIcoDiv hβ 0 t)
  simp only [toIcoDiv_eq_floor, sub_zero]
  exact (measurable_id.div_const β).floor

theorem representative_measurable : Measurable (representative β hβ) := by
  apply Measurable.subtype_mk
  change Measurable (fun t => toIcoMod hβ 0 t)
  simp only [toIcoMod_eq_fract_mul]
  exact (measurable_fract.comp (measurable_id.div_const β)).mul_const β

theorem endpointSign_measurable : Measurable (endpointSign β hβ) :=
  (measurable_of_countable (fun n : ℤ => ((n.negOnePow : ℤ) : ℂ))).comp (periodNumber_measurable β hβ)

theorem pairSign_measurable : Measurable (pairSign β hβ) :=
  ((endpointSign_measurable β hβ).comp measurable_fst).mul
    ((endpointSign_measurable β hβ).comp measurable_snd)

theorem representativePair_measurable : Measurable (representativePair β hβ) :=
  ((representative_measurable β hβ).comp measurable_fst).prodMk
    ((representative_measurable β hβ).comp measurable_snd)

/-- Actual thermal tuple moments are measurable on all real endpoint tuples,
including every collision and thermal seam. -/
theorem actualThermal_tuple_measurable (d : ℕ) (lam : ℝ≥0) (k : ℕ) :
    Measurable (fun p : Fin k → Endpoint => actualThermalPolynomial β hβ d lam (∏ i, MvPolynomial.X (p i))) := by
  simp only [actualThermalPolynomial_tuple]
  apply Measurable.mul
  · exact Finset.measurable_prod _ (fun i _ => (pairSign_measurable β hβ).comp (measurable_pi_apply i))
  · apply (SYK.MomentMeasurability.measurable_collectiveMoment d β lam k).comp
    apply measurable_pi_lambda
    intro i
    exact ((measurable_subtype_coe.comp (representative_measurable β hβ)).comp
      (measurable_pi_apply i).fst).prodMk
      ((measurable_subtype_coe.comp (representative_measurable β hβ)).comp
        (measurable_pi_apply i).snd)

/-- Pointwise all-real polynomial convergence follows from uniform compact
centered convergence of the corrected microscopic family. -/
theorem actualThermal_polynomial_tendsto (lam : ℝ≥0) (d : ℕ → ℕ)
    (g : ∀ k, EndpointCube β k → ℂ)
    (hg : ∀ k, TendstoUniformly
      (fun n => functionalCenteredMoment (actualCorrectedPolynomial β hβ (d n) lam)) (g k) atTop)
    (P : RealPolynomial) :
    Tendsto (fun n => actualThermalPolynomial β hβ (d n) lam P) atTop
      (𝓝 (liftFunctional β hβ (limitPolynomial β g) P)) :=
  liftFunctional_tendsto β hβ (fun n => actualPolynomial (d n) β lam) _
    (functional_polynomial_tendsto β (fun n => actualCorrectedPolynomial β hβ (d n) lam) g hg) P

/-- Uniform moment convergence extends from the compact cube to all real
endpoint tuples by bounded winding signs, without a new subsequence. -/
theorem actualThermal_moments_tendstoUniformly (lam : ℝ≥0) (d : ℕ → ℕ)
    (g : ∀ k, EndpointCube β k → ℂ)
    (hg : ∀ k, TendstoUniformly
      (fun n => functionalCenteredMoment (actualCorrectedPolynomial β hβ (d n) lam)) (g k) atTop)
    (k : ℕ) :
    TendstoUniformly
      (fun n (p : Fin k → Endpoint) => actualThermalPolynomial β hβ (d n) lam (∏ i, MvPolynomial.X (p i)))
      (fun p => liftFunctional β hβ (limitPolynomial β g) (∏ i, MvPolynomial.X (p i))) atTop := by
  have hc := (functional_moments_tendstoUniformly β
    (fun n => actualCorrectedPolynomial β hβ (d n) lam) g hg k).comp
    (fun p : Fin k → Endpoint => fun i => representativePair β hβ (p i))
  have hbnd : ∀ p : Fin k → Endpoint, ‖∏ i, pairSign β hβ (p i)‖ ≤ 1 := by
    intro p
    simpa only [norm_pairSign, Finset.prod_const_one] using
      Finset.norm_prod_le Finset.univ (fun i => pairSign β hβ (p i))
  have hm := uniform_bounded_mul (fun p : Fin k → Endpoint => ∏ i, pairSign β hβ (p i))
    1 zero_le_one hbnd hc
  simpa only [Function.comp_def, ← liftFunctional_tuple, actualCorrectedPolynomial, liftFunctional_corrected,
    actualThermalPolynomial] using hm

/-- One subsequence works simultaneously for all real finite tuples. The only
regularity input is the microscopic vanishing-defect modulus, applied after
thermal seam correction. -/
theorem exists_actual_thermal_limit (lam : ℝ≥0) (d : ℕ → ℕ) (hd : ∀ n, 0 < d n)
    (K : ℕ → ℝ) (hK : ∀ k, 0 ≤ K k) (ε : ℕ → ℕ → ℝ)
    (hε : ∀ k, Tendsto (ε k) atTop (𝓝 0))
    (hmod : ∀ k n (p q : EndpointCube β k),
      ‖functionalCenteredMoment (actualCorrectedPolynomial β hβ (d n) lam) p -
        functionalCenteredMoment (actualCorrectedPolynomial β hβ (d n) lam) q‖ ≤
        K k * dist p q + ε k n) :
    ∃ (φ : ℕ → ℕ) (g : ∀ k, EndpointCube β k → ℂ), StrictMono φ ∧
      (∀ k, TendstoUniformly
        (fun n => functionalCenteredMoment (actualCorrectedPolynomial β hβ (d (φ n)) lam)) (g k) atTop) ∧
      (∀ k, LipschitzWith ⟨K k, hK k⟩ (g k)) ∧ (∀ k p, ‖g k p‖ ≤ 1) ∧
      (∀ P, Tendsto (fun n => actualThermalPolynomial β hβ (d (φ n)) lam P) atTop
        (𝓝 (liftFunctional β hβ (limitPolynomial β g) P))) ∧
      (∀ k, TendstoUniformly
        (fun n (p : Fin k → Endpoint) => actualThermalPolynomial β hβ (d (φ n)) lam (∏ i, MvPolynomial.X (p i)))
        (fun p => liftFunctional β hβ (limitPolynomial β g) (∏ i, MvPolynomial.X (p i))) atTop) ∧
      liftFunctional β hβ (limitPolynomial β g) 1 = 1 ∧
      (∀ P, ‖liftFunctional β hβ (limitPolynomial β g) P‖ ≤ coefficientNorm (fun _ => 1/2) P) := by
  obtain ⟨φ, g, hφ, hg, hLip, hB, _hL, hunit, hbound⟩ := functional_centered_subsequence hβ.le
    (fun n => actualCorrectedPolynomial β hβ (d n) lam)
    (fun n => actualCorrectedPolynomial_one β hβ (d n) lam)
    (fun n => actualCorrectedPolynomial_bound β hβ (d n) (hd n) lam)
    K hK ε hε hmod
  exact ⟨φ, g, hφ, hg, hLip, hB,
    actualThermal_polynomial_tendsto β hβ lam (d ∘ φ) g hg,
    actualThermal_moments_tendstoUniformly β hβ lam (d ∘ φ) g hg,
    by simpa only [liftFunctional_apply, map_one] using hunit,
    liftFunctional_bound β hβ (1/2) (by norm_num) _ hbound⟩


/-- Microscopic skewness holds with every polynomial insertion, rather than
only for an isolated coordinate. -/
theorem actualPolynomial_inserted_skew (d : ℕ) (lam : ℝ≥0)
    (P : CoordinatePolynomial β) (p : EndpointPair β) :
    actualPolynomial d β lam (P * MvPolynomial.X p.swap) =
      -actualPolynomial d β lam (P * MvPolynomial.X p) := by
  induction P using MvPolynomial.induction_on' with
  | monomial e c =>
    have h := actualPolynomial_tuple_flip d β lam (Fin.cons p (monomialTuple e)) 0
    simp only [Fin.cons_zero, Fin.update_cons_zero, Fin.prod_univ_succ,
      Fin.cons_succ] at h
    have hc : MvPolynomial.monomial e c = c • MvPolynomial.monomial e (1 : ℂ) := by rw [MvPolynomial.smul_monomial]; simp only [smul_eq_mul, mul_one]
    rw [hc, monomial_eq_tuple_prod, smul_mul_assoc, map_smul, smul_mul_assoc, map_smul]
    simpa only [mul_comm, smul_neg] using congrArg (fun z : ℂ => c • z) h
  | add P Q hP hQ => simp only [add_mul, map_add, hP, hQ, neg_add]

/-- Equal microscopic endpoints vanish with arbitrary polynomial insertion. -/
theorem actualPolynomial_inserted_diagonal (d : ℕ) (lam : ℝ≥0)
    (P : CoordinatePolynomial β) (t : Icc (0 : ℝ) β) :
    actualPolynomial d β lam (P * MvPolynomial.X (t,t)) = 0 :=
  CharZero.eq_neg_self_iff.mp (actualPolynomial_inserted_skew β d lam P (t,t))

theorem actualThermal_inserted_skew (d : ℕ) (lam : ℝ≥0) (P : RealPolynomial) (s t : ℝ) :
    actualThermalPolynomial β hβ d lam (P * MvPolynomial.X (t,s)) =
      -actualThermalPolynomial β hβ d lam (P * MvPolynomial.X (s,t)) :=
  liftFunctional_skew β hβ _ (actualPolynomial_inserted_skew β d lam) P s t

theorem actualThermal_inserted_diagonal (d : ℕ) (lam : ℝ≥0) (P : RealPolynomial) (t : ℝ) :
    actualThermalPolynomial β hβ d lam (P * MvPolynomial.X (t,t)) = 0 :=
  liftFunctional_diagonal β hβ _ (actualPolynomial_inserted_diagonal β d lam) P t

/-- The signed representative construction repairs the raw (β,0) seam
already at finite size, before the large-size limit is taken. -/
theorem actualThermal_inserted_seam_diagonal (d : ℕ) (lam : ℝ≥0) (P : RealPolynomial) :
    actualThermalPolynomial β hβ d lam (P * MvPolynomial.X (β,0)) = 0 :=
  liftFunctional_seam_diagonal β hβ _ (actualPolynomial_inserted_diagonal β d lam) P

/-- Arbitrary fixed polynomial insertions preserve actual thermal
measurability, including all collisions and thermal seam labels. -/
theorem actualThermal_inserted_measurable {Ω : Type*} [MeasurableSpace Ω]
    (d : ℕ) (lam : ℝ≥0) (P : RealPolynomial) {k : ℕ}
    (p : Ω → Fin k → Endpoint) (hp : ∀ i, Measurable (fun x => p x i)) :
    Measurable (fun x => actualThermalPolynomial β hβ d lam (P * ∏ i, MvPolynomial.X (p x i))) := by
  induction P using MvPolynomial.induction_on generalizing k with
  | C c =>
    simp only [MvPolynomial.C_mul', map_smul, smul_eq_mul]
    exact ((actualThermal_tuple_measurable β hβ d lam k).comp (measurable_pi_lambda _ hp)).const_mul c
  | add P Q hP hQ =>
    simpa only [add_mul, map_add] using (hP p hp).add (hQ p hp)
  | mul_X P a hP =>
    have h := hP (fun x => Fin.cons a (p x)) (by
      intro i
      refine Fin.cases ?_ (fun i => ?_) i
      · exact measurable_const
      · exact hp i)
    simpa only [Fin.prod_univ_succ, Fin.cons_zero, Fin.cons_succ, mul_assoc] using h


section LimitTransport
variable (lam : ℝ≥0) (d : ℕ → ℕ) (g : ∀ k, EndpointCube β k → ℂ)
variable (hg : ∀ k, TendstoUniformly
  (fun n => functionalCenteredMoment (actualCorrectedPolynomial β hβ (d n) lam)) (g k) atTop)
include hg

/-- Every exact finite polynomial equality passes to the all-real limit;
this applies, in particular, to proven microscopic symmetry tests. -/
theorem thermalLimit_eq (P Q : RealPolynomial)
    (hPQ : ∀ n, actualThermalPolynomial β hβ (d n) lam P = actualThermalPolynomial β hβ (d n) lam Q) :
    liftFunctional β hβ (limitPolynomial β g) P = liftFunctional β hβ (limitPolynomial β g) Q := by
  exact tendsto_nhds_unique (actualThermal_polynomial_tendsto β hβ lam d g hg P)
    ((actualThermal_polynomial_tendsto β hβ lam d g hg Q).congr (fun n => (hPQ n).symm))

/-- The limiting state kills any family of inserted relations that is
proved at finite size. No insertion test is dropped at this passage. -/
theorem thermalLimit_inserted_relations {J : Type*} (r : J → RealPolynomial)
    (hr : ∀ n P j, actualThermalPolynomial β hβ (d n) lam (P * r j) = 0) :
    ∀ P j, liftFunctional β hβ (limitPolynomial β g) (P * r j) = 0 := by
  intro P j
  exact tendsto_nhds_unique (actualThermal_polynomial_tendsto β hβ lam d g hg (P * r j))
    (by simpa only [hr] using (tendsto_const_nhds : Tendsto (fun _ : ℕ => (0 : ℂ)) atTop (𝓝 0)))

/-- Finite reflection-positivity tests remain nonnegative in the actual
all-real limiting functional. The finite positivity proof remains explicit. -/
theorem thermalLimit_nonnegative (P : RealPolynomial)
    (hP : ∀ n, 0 ≤ (actualThermalPolynomial β hβ (d n) lam P).re) :
    0 ≤ (liftFunctional β hβ (limitPolynomial β g) P).re := by
  exact le_of_tendsto_of_tendsto tendsto_const_nhds
    (Complex.continuous_re.tendsto _ |>.comp (actualThermal_polynomial_tendsto β hβ lam d g hg P))
    (Eventually.of_forall hP)

theorem thermalLimit_real (P : RealPolynomial)
    (hP : ∀ n, (actualThermalPolynomial β hβ (d n) lam P).im = 0) :
    (liftFunctional β hβ (limitPolynomial β g) P).im = 0 := by
  exact tendsto_nhds_unique
    (Complex.continuous_im.tendsto _ |>.comp (actualThermal_polynomial_tendsto β hβ lam d g hg P))
    (by simpa only [Function.comp_def, hP] using (tendsto_const_nhds : Tendsto (fun _ : ℕ => (0 : ℝ)) atTop (𝓝 0)))

/-- Polynomial-inserted limiting tuple moments are measurable on arbitrary
measurable parameter spaces, by the actual finite-size measurable formulas. -/
theorem thermalLimit_inserted_measurable {Ω : Type*} [MeasurableSpace Ω]
    (P : RealPolynomial) {k : ℕ} (p : Ω → Fin k → Endpoint)
    (hp : ∀ i, Measurable (fun x => p x i)) :
    Measurable (fun x => liftFunctional β hβ (limitPolynomial β g) (P * ∏ i, MvPolynomial.X (p x i))) := by
  apply measurable_of_tendsto_metrizable (fun n => actualThermal_inserted_measurable β hβ (d n) lam P p hp)
  apply tendsto_pi_nhds.mpr
  intro x
  exact actualThermal_polynomial_tendsto β hβ lam d g hg _

/-- Dominated convergence for all-real actual polynomial moments. The sharp
finite-size majorant is proved, leaving only an explicit integrable coefficient
majorant and measurable dependence for the chosen integral test. -/
theorem actualThermal_integral_tendsto {Ω : Type*} [MeasurableSpace Ω] (μ : Measure Ω)
    (hd : ∀ n, 0 < d n) (Q : Ω → RealPolynomial) (b : Ω → ℝ) (hb : Integrable b μ)
    (hQb : ∀ x, coefficientNorm (fun _ => 1/2) (Q x) ≤ b x)
    (hMeas : ∀ n, AEStronglyMeasurable (fun x => actualThermalPolynomial β hβ (d n) lam (Q x)) μ) :
    Tendsto (fun n => ∫ x, actualThermalPolynomial β hβ (d n) lam (Q x) ∂μ) atTop
      (𝓝 (∫ x, liftFunctional β hβ (limitPolynomial β g) (Q x) ∂μ)) := by
  apply tendsto_integral_of_dominated_convergence b hMeas hb
  · intro n
    exact Eventually.of_forall (fun x => (actualThermalPolynomial_bound β hβ (d n) (hd n) lam (Q x)).trans (hQb x))
  · exact Eventually.of_forall (fun x => actualThermal_polynomial_tendsto β hβ lam d g hg (Q x))

/-- Any actual finite-size inserted Ward identity with an inverse-dimension
contact error becomes an exact all-real limiting inserted integral identity. -/
theorem actualThermal_ward_limit {Ω : Type*} [MeasurableSpace Ω] (μ : Measure Ω)
    (hd : ∀ n, 0 < d n) (hd_top : Tendsto d atTop atTop)
    (P : RealPolynomial) (Q : Ω → RealPolynomial) (b : Ω → ℝ) (hb : Integrable b μ)
    (hQb : ∀ x, coefficientNorm (fun _ => 1/2) (Q x) ≤ b x)
    (hMeas : ∀ n, AEStronglyMeasurable (fun x => actualThermalPolynomial β hβ (d n) lam (Q x)) μ)
    (c : ℂ) (E : ℕ → ℂ) (A : ℝ) (hE : ∀ n, ‖E n‖ ≤ A / (d n : ℝ))
    (hWard : ∀ n, actualThermalPolynomial β hβ (d n) lam P =
      c * (∫ x, actualThermalPolynomial β hβ (d n) lam (Q x) ∂μ) + E n) :
    liftFunctional β hβ (limitPolynomial β g) P =
      c * ∫ x, liftFunctional β hβ (limitPolynomial β g) (Q x) ∂μ := by
  have hright := ((tendsto_const_nhds (x := c)).mul
    (actualThermal_integral_tendsto β hβ lam d g hg μ hd Q b hb hQb hMeas)).add
      (contact_error_tendsto d hd_top A E hE)
  simp only [add_zero] at hright
  exact tendsto_nhds_unique (actualThermal_polynomial_tendsto β hβ lam d g hg P)
    (hright.congr (fun n => (hWard n).symm))


@[simp] theorem thermalLimit_one : liftFunctional β hβ (limitPolynomial β g) 1 = 1 := by
  exact tendsto_nhds_unique (actualThermal_polynomial_tendsto β hβ lam d g hg 1)
    (by simpa only [actualThermalPolynomial_one] using
      (tendsto_const_nhds : Tendsto (fun _ : ℕ => (1 : ℂ)) atTop (𝓝 1)))

theorem thermalLimit_bound (hd : ∀ n, 0 < d n) (P : RealPolynomial) :
    ‖liftFunctional β hβ (limitPolynomial β g) P‖ ≤ coefficientNorm (fun _ => 1/2) P := by
  exact le_of_tendsto (actualThermal_polynomial_tendsto β hβ lam d g hg P |>.norm)
    (Eventually.of_forall (fun n => actualThermalPolynomial_bound β hβ (d n) (hd n) lam P))

/-- Actual microscopic skewness survives thermal reduction and compactness
with every real-label polynomial insertion. -/
theorem thermalLimit_inserted_skew (P : RealPolynomial) (s t : ℝ) :
    liftFunctional β hβ (limitPolynomial β g) (P * MvPolynomial.X (t,s)) =
      -liftFunctional β hβ (limitPolynomial β g) (P * MvPolynomial.X (s,t)) := by
  simpa only [map_neg] using thermalLimit_eq β hβ lam d g hg
    (P * MvPolynomial.X (t,s)) (-(P * MvPolynomial.X (s,t)))
    (fun n => by simpa only [map_neg] using actualThermal_inserted_skew β hβ (d n) lam P s t)

theorem thermalLimit_inserted_diagonal (P : RealPolynomial) (t : ℝ) :
    liftFunctional β hβ (limitPolynomial β g) (P * MvPolynomial.X (t,t)) = 0 := by
  exact thermalLimit_inserted_relations β hβ lam d g hg
    (fun t => MvPolynomial.X (t,t))
    (fun n => actualThermal_inserted_diagonal β hβ (d n) lam) P t

theorem thermalLimit_inserted_seam_diagonal (P : RealPolynomial) :
    liftFunctional β hβ (limitPolynomial β g) (P * MvPolynomial.X (β,0)) = 0 := by
  exact tendsto_nhds_unique (actualThermal_polynomial_tendsto β hβ lam d g hg _)
    (by simpa only [actualThermal_inserted_seam_diagonal] using
      (tendsto_const_nhds : Tendsto (fun _ : ℕ => (0 : ℂ)) atTop (𝓝 0)))

end LimitTransport

end SYK.ThermalMomentTransport


