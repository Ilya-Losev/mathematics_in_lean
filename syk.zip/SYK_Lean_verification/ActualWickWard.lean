import FundamentalMomentIntegrability
import SignedWardInterval
import ActualFiniteWardControl
import WickGaussianRegrouping

/-! Assemble exact microscopic Ward control from the two genuine Wick identities. -/
noncomputable section
open MeasureTheory
open scoped NNReal
namespace SYK.ActualWickWard
open ThermalWick WickVertexIntegrals ContinuumWickSeries SignedWardReduction

/-- This intermediate bridge exposes exactly the two remaining microscopic
identities: actual inserted-series identification and the derived numerator
Ward identity. Every polynomial, normalization, seam, and integral step is
proved here rather than passed as a further premise. -/
theorem exact_left_of_wick_identities (d : ℕ) (hd : 0<d) (β : ℝ) (hβ : 0<β) (lam : ℝ≥0)
    (hMoment : ∀ ps : List (Time β×Time β), normalizedMoment d β hβ ps (lam:ℝ) =
      Interacting.collectiveMoment d β lam (fun i=>((ps.get i).1.val,(ps.get i).2.val)))
    (hWard : ∀ (ps : List (Time β×Time β)) (s t : Time β),
      numerator d β hβ ((s,t)::ps) (lam:ℝ) =
        (Thermal.kernel β s.val t.val:ℂ)*numerator d β hβ ps (lam:ℝ)+
        (((2*d:ℕ):ℂ)⁻¹)*contactValue (fun l=>numerator d β hβ l (lam:ℝ)) s t ps []+
        (lam:ℂ)*(∫ x, (Thermal.kernel β s.val (timeRepresentative β hβ x.1).val:ℂ)*
          numerator d β hβ (ps++FundamentalWardBridge.interactionPairs β hβ t x) (lam:ℝ) ∂pairMeasure β)) :
    ActualFiniteWardControl.ExactLeftWard β hβ lam d := by
  have hz : numerator d β hβ [] (lam:ℝ)≠0 := by
    intro he
    have hp := WickGaussianRegrouping.numerator_empty_re_pos d hd hβ lam
    rw [he] at hp
    exact (lt_irrefl 0 hp)
  have hF (ps) : actualFundamental β d lam (FundamentalWardContacts.coordinateProduct ps)=
      numerator d β hβ ps (lam:ℝ)/numerator d β hβ [] (lam:ℝ) := by
    rw [actualFundamental_list,← hMoment]
    rfl
  have hFund (Q : TimePolynomial β) (s t : Time β) :=
    FundamentalWardBridge.polynomial_ward_of_numerator β hβ (actualFundamental β d lam)
      (fun ps=>numerator d β hβ ps (lam:ℝ)) hz hF (((2*d:ℕ):ℂ)⁻¹) (lam:ℂ) s t
      (FundamentalMomentIntegrability.actualFundamental_ward_integrable β hβ d hd lam s t)
      (fun ps=>hWard ps s t) Q
  intro Q s t
  have h := actualWard_interval_of_fundamental β hβ d hd lam hFund Q s t
  unfold ThermalWardLimit.leftResidual
  rw [h]
  ring

end SYK.ActualWickWard
