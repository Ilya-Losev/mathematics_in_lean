import WickVertexIntegrals
import GaussianSymbolAverage

/-!
# Actual partition coefficients and integrated exterior Wick vertices

This file identifies the uninserted operator partition coefficients with
actual scalar Wick time integrals before applying Gaussian averaging.
-/
noncomputable section
open scoped BigOperators NNReal ComplexOrder
open MeasureTheory Set
namespace SYK.PartitionWick
open DuhamelHistory DuhamelVertex WickVertexIntegrals ThermalWick
open OrderedSimplexIntegral OrderedCubePartition

/-- The actual linear disorder polynomial, on the same four-set index type
as the concrete Hamiltonian. -/
def disorderPolynomial (d : ℕ) (j : Majorana.FourSet d → ℝ) :
    MvPolynomial (Majorana.FourSet d) ℂ := ∑ I, (j I : ℂ) • MvPolynomial.X I

/-- Its degree-k integrated coefficient expands into the genuine finite
sum of disorder monomials and scalar time integrals. -/
theorem functional_power_eq_sum (d : ℕ) {β : ℝ} (hβ : 0 < β)
    (L : List (Label (2*d) β)) (j : Majorana.FourSet d → ℝ) (k : ℕ) :
    vertexFunctional d hβ L ((disorderPolynomial d j)^k) =
      ∑ I : Fin k → Majorana.FourSet d,
        (∏ i, (j (I i) : ℂ)) * vertexMoment d hβ L I := by
  rw [disorderPolynomial, sum_pow_ordered, map_sum]
  apply Finset.sum_congr rfl
  intro I _
  rw [orderedProduct_smul, map_smul, smul_eq_mul]
  congr 1
  simpa only [orderedProduct, List.prod_ofFn] using vertexFunctional_product d hβ L I

/-- The scalar continuum coefficient with every actual quartic disorder
label summed, before integration and exponential normalization. -/
def weightedVertexIntegrand (d : ℕ) {β : ℝ} (hβ : 0 < β)
    (L : List (Label (2*d) β)) (j : Majorana.FourSet d → ℝ) (k : ℕ)
    (u : Fin k → ℝ) : ℂ :=
  ∑ I : Fin k → Majorana.FourSet d,
    (∏ i, (j (I i) : ℂ)) * vertexIntegrand d hβ L I u

/-- Finite flavor expansion commutes with the actual scalar time integral. -/
theorem functional_power_eq_integral (d : ℕ) {β : ℝ} (hβ : 0 < β)
    (L : List (Label (2*d) β)) (hL : Even L.length)
    (j : Majorana.FourSet d → ℝ) (k : ℕ) :
    vertexFunctional d hβ L ((disorderPolynomial d j)^k) =
      ∫ u in timeCube k 0 β, weightedVertexIntegrand d hβ L j k u := by
  rw [functional_power_eq_sum]
  unfold weightedVertexIntegrand vertexMoment
  rw [integral_finset_sum]
  · apply Finset.sum_congr rfl
    intro I _
    exact (integral_const_mul _ _).symm
  · intro I _
    exact (vertexIntegrand_integrable d hβ L hL I).const_mul _

theorem weightedVertexIntegrand_integrable (d : ℕ) {β : ℝ} (hβ : 0 < β)
    (L : List (Label (2*d) β)) (hL : Even L.length)
    (j : Majorana.FourSet d → ℝ) (k : ℕ) :
    IntegrableOn (weightedVertexIntegrand d hβ L j k) (timeCube k 0 β) := by
  apply integrable_finset_sum
  intro I _
  exact (vertexIntegrand_integrable d hβ L hL I).const_mul _

/-- The complete vertex-label sum is symmetric in the time coordinates,
with its symmetry derived from the true even exterior vertices. -/
theorem weightedVertexIntegrand_symmetric (d : ℕ) {β : ℝ} (hβ : 0 < β)
    (L : List (Label (2*d) β)) (j : Majorana.FourSet d → ℝ) (k : ℕ)
    (σ : Equiv.Perm (Fin k)) (u : Fin k → ℝ) :
    weightedVertexIntegrand d hβ L j k (u ∘ σ) = weightedVertexIntegrand d hβ L j k u := by
  unfold weightedVertexIntegrand
  rw [← Equiv.sum_comp (Equiv.arrowCongr σ.symm (Equiv.refl (Majorana.FourSet d)))]
  apply Finset.sum_congr rfl
  intro I _
  have hp : (∏ i, (j (I (σ i)) : ℂ)) = ∏ i, (j (I i) : ℂ) :=
    Equiv.prod_comp σ (fun i => (j (I i) : ℂ))
  change (∏ i, (j (I (σ i)) : ℂ)) * vertexIntegrand d hβ L (I ∘ σ) (u ∘ σ) =
    (∏ i, (j (I i) : ℂ)) * vertexIntegrand d hβ L I u
  rw [hp, vertexIntegrand_permutation]
  simp [Function.comp_assoc]

/-- On the genuine open ordered simplex, the complete uninserted Wick
vertex integrand is exactly the normalized trace of the Hamiltonian power. -/
theorem weightedVertexIntegrand_ordered (d : ℕ) {β : ℝ} (hβ : 0 < β)
    (j : Majorana.FourSet d → ℝ) (k : ℕ) (u : Fin k → ℝ)
    (hu : u ∈ strictOrderedSimplex k 0 β) :
    weightedVertexIntegrand d hβ [] j k u =
      Majorana.normalizedTrace d ((-Majorana.hamiltonian d j)^k) := by
  have ht (i : Fin k) : (timeRepresentative β hβ (u i)).val = u i :=
    timeRepresentative_of_mem hβ ⟨(hu.1 i).le, hu.2.1 i⟩
  have ho : StrictAnti (fun i => (timeRepresentative β hβ (u i)).val) := by
    simpa only [ht] using hu.2.2
  have hw (I : Fin k → Majorana.FourSet d) : vertexIntegrand d hβ [] I u =
      Majorana.normalizedTrace d (orderedProduct (fun i => Majorana.quartic d (I i))) := by
    simpa only [vertexIntegrand, FreeWick.word_nil, one_mul] using
      (ordered_vertex_trace_eq_wick d hβ I (fun i => timeRepresentative β hβ (u i)) ho).symm
  simp only [weightedVertexIntegrand, hw]
  rw [neg_hamiltonian_pow]
  simp_rw [← FreeWick.normalizedTraceMap_apply]
  rw [map_sum]
  simp only [map_smul, smul_eq_mul, FreeWick.normalizedTraceMap_apply]

/-- The actual integrated uninserted Wick coefficient equals the genuine
operator coefficient, with the full beta scaling and no continuum identity
assumed as a hypothesis. -/
theorem functional_power_eq_trace (d : ℕ) {β : ℝ} (hβ : 0 < β)
    (j : Majorana.FourSet d → ℝ) (k : ℕ) :
    vertexFunctional d hβ [] ((disorderPolynomial d j)^k) =
      (β^k : ℝ) • Majorana.normalizedTrace d ((-Majorana.hamiltonian d j)^k) := by
  rw [functional_power_eq_integral d hβ [] (by simp)]
  rw [integral_cube_eq_factorial_smul_ordered 0 β _
    (weightedVertexIntegrand_integrable d hβ [] (by simp) j k)
    (weightedVertexIntegrand_symmetric d hβ [] j k)]
  rw [← setIntegral_congr_set (strictOrderedSimplex_ae_eq k 0 β)]
  rw [setIntegral_congr_fun (OrderedCubePartition.strictOrderedSimplex_measurable k 0 β)
    (fun u hu => weightedVertexIntegrand_ordered d hβ j k u hu)]
  rw [integral_strictOrderedSimplex_const k 0 β hβ.le, sub_zero]
  rw [nsmul_eq_mul]
  have hk : (k.factorial : ℝ) ≠ 0 := by exact_mod_cast k.factorial_ne_zero
  simp only [RCLike.real_smul_eq_coe_smul (K := ℂ), smul_eq_mul]
  push_cast
  field_simp

/-- The true factorial-normalized uninserted Wick coefficient. -/
def partitionCoefficient (d : ℕ) {β : ℝ} (hβ : 0 < β)
    (j : Majorana.FourSet d → ℝ) (k : ℕ) : ℂ :=
  (k.factorial : ℂ)⁻¹ * vertexFunctional d hβ [] ((disorderPolynomial d j)^k)

/-- This integrated Wick coefficient is precisely the coefficient of the
single genuine thermal gap, not merely a formal series coefficient. -/
theorem partitionCoefficient_eq_gapCoefficient (d : ℕ) {β : ℝ} (hβ : 0 < β)
    (j : Majorana.FourSet d → ℝ) (k : ℕ) :
    partitionCoefficient d hβ j k =
      gapCoefficient d (Majorana.hamiltonian d j) (fun _ : Fin 1 => β)
        (fun _ => 1) (fun _ => k) := by
  rw [partitionCoefficient, functional_power_eq_trace]
  unfold gapCoefficient
  simp only [orderedProduct, List.ofFn_succ, List.ofFn_zero, List.prod_cons,
    List.prod_nil, mul_one]
  have h1 : CStarMatrix.ofMatrix (1 : Matrix (Majorana.Basis d) (Majorana.Basis d) ℂ) = 1 :=
    (CStarMatrix.ofMatrixRingEquiv (n := Majorana.Basis d) (A := ℂ)).map_one
  rw [h1, mul_one]
  change _ = normalizedTraceCLM d (expCoefficient
    (-(β : ℂ) • CStarMatrix.ofMatrix (Majorana.hamiltonian d j)) k)
  unfold expCoefficient
  rw [map_smul]
  have he : (-(β : ℂ)) • CStarMatrix.ofMatrix (Majorana.hamiltonian d j) =
      (β : ℂ) • CStarMatrix.ofMatrix (-Majorana.hamiltonian d j) := by
    have hn : CStarMatrix.ofMatrix (-Majorana.hamiltonian d j) =
        -CStarMatrix.ofMatrix (Majorana.hamiltonian d j) :=
      (CStarMatrix.ofMatrixRingEquiv (n := Majorana.Basis d) (A := ℂ)).map_neg _
    rw [hn, neg_smul, smul_neg]
  rw [he, smul_pow, map_smul]
  change _ = (k.factorial : ℂ)⁻¹ • ((β : ℂ)^k •
    normalizedTraceCLM d (CStarMatrix.ofMatrix ((-Majorana.hamiltonian d j)^k)))
  rw [normalizedTraceCLM_ofMatrix]
  simp only [RCLike.real_smul_eq_coe_smul (K := ℂ), Complex.ofReal_pow, smul_eq_mul]
  push_cast
  rfl

/-- The actual normalized partition function is the sum of the numerical
continuum Wick coefficients, before disorder averaging. -/
theorem hasSum_partitionCoefficient (d : ℕ) {β : ℝ} (hβ : 0 < β)
    (j : Majorana.FourSet d → ℝ) :
    HasSum (partitionCoefficient d hβ j)
      (Majorana.normalizedTrace d (Gibbs.weight β (Majorana.hamiltonian d j))) := by
  have h := (Equiv.funUnique (Fin 1) ℕ).symm.hasSum_iff.mpr
    (hasSum_gapCoefficient d (Majorana.hamiltonian d j) (fun _ : Fin 1 => β) (fun _ => 1))
  have he (k : ℕ) : (Equiv.funUnique (Fin 1) ℕ).symm k = (fun _ => k) := by
    ext i
    simp only [Equiv.funUnique_symm_apply, uniqueElim_const]
  simpa only [Function.comp_def, he, List.ofFn_succ, List.ofFn_zero, List.prod_cons,
    List.prod_nil, mul_one, ← partitionCoefficient_eq_gapCoefficient d hβ j] using h

/-- The actual Gaussian averaged normalized partition function is the sum
of actual Gaussian averaged continuum Wick coefficients. The Gaussian
Fubini step is inherited from the already proved absolute gap expansion. -/
theorem hasSum_integral_partitionCoefficient (d : ℕ) {β : ℝ} (hβ : 0 < β) (lam : ℝ≥0) :
    HasSum (fun k => ∫ j, partitionCoefficient d hβ j k ∂Microscopic.disorder d lam)
      (∫ j, Majorana.normalizedTrace d (Gibbs.weight β (Majorana.hamiltonian d j))
        ∂Microscopic.disorder d lam) := by
  have h := (Equiv.funUnique (Fin 1) ℕ).symm.hasSum_iff.mpr
    (hasSum_integral_gapCoefficient d lam (fun _ : Fin 1 => β) (fun _ => hβ.le) (fun _ => 1))
  have he (k : ℕ) : (Equiv.funUnique (Fin 1) ℕ).symm k = (fun _ => k) := by
    ext i
    simp only [Equiv.funUnique_symm_apply, uniqueElim_const]
  simpa only [Function.comp_def, he, List.ofFn_succ, List.ofFn_zero, List.prod_cons,
    List.prod_nil, mul_one, ← partitionCoefficient_eq_gapCoefficient d hβ] using h

/-- The exact Gaussian quadratic symbol before quartic collective regrouping. -/
def quadraticPolynomial (d : ℕ) (lam : ℝ≥0) : MvPolynomial (Majorana.FourSet d) ℂ :=
  (3 * (lam : ℝ) / ((2*d : ℕ) : ℝ)^3) • ∑ I, (MvPolynomial.X I)^2

/-- The actual integrated Wick series after Gaussian averaging. -/
def averagedWickCoefficient (d : ℕ) {β : ℝ} (hβ : 0 < β) (lam : ℝ≥0) (k : ℕ) : ℂ :=
  (k.factorial : ℂ)⁻¹ * vertexFunctional d hβ [] ((quadraticPolynomial d lam)^k)

theorem disorderPolynomial_real (d : ℕ) (j : Majorana.FourSet d → ℝ) :
    disorderPolynomial d j = ∑ I, j I • (MvPolynomial.X I : MvPolynomial (Majorana.FourSet d) ℂ) := by
  simp only [disorderPolynomial, RCLike.real_smul_eq_coe_smul (K := ℂ)]
  rfl

/-- Complex factorial multiplication agrees with the real scalar
normalization used in the independently proved Gaussian coefficient theorem. -/
theorem factorial_mul_eq_real_smul (k : ℕ) (z : ℂ) :
    (k.factorial : ℂ)⁻¹ * z = (1 / (k.factorial : ℝ)) • z := by
  simp only [RCLike.real_smul_eq_coe_smul (K := ℂ), smul_eq_mul]
  push_cast
  simp

/-- All odd coefficients vanish under the genuine product Gaussian disorder. -/
theorem integral_partitionCoefficient_odd (d : ℕ) {β : ℝ} (hβ : 0 < β)
    (lam : ℝ≥0) (k : ℕ) :
    (∫ j, partitionCoefficient d hβ j (2*k+1) ∂Microscopic.disorder d lam) = 0 := by
  classical
  unfold partitionCoefficient
  rw [integral_const_mul]
  have h := GaussianCoefficient.integral_linearSymbol_odd
    (MvPolynomial (Majorana.FourSet d) ℂ) (GaussianDisorder.variance (2*d) lam)
    MvPolynomial.X ((vertexFunctional d hβ []).restrictScalars ℝ) k
  change (∫ j, vertexFunctional d hβ []
    ((∑ I, j I • (MvPolynomial.X I : MvPolynomial (Majorana.FourSet d) ℂ))^(2*k+1))
    ∂Microscopic.disorder d lam) = 0 at h
  simp_rw [disorderPolynomial_real]
  rw [h, mul_zero]

/-- Every even coefficient is exactly its Gaussian quadratic-exponential
coefficient, with the microscopic variance 6 lambda / N cubed. -/
theorem integral_partitionCoefficient_even (d : ℕ) {β : ℝ} (hβ : 0 < β)
    (lam : ℝ≥0) (k : ℕ) :
    (∫ j, partitionCoefficient d hβ j (2*k) ∂Microscopic.disorder d lam) =
      averagedWickCoefficient d hβ lam k := by
  classical
  unfold partitionCoefficient averagedWickCoefficient
  rw [integral_const_mul]
  rw [factorial_mul_eq_real_smul, factorial_mul_eq_real_smul]
  simp_rw [disorderPolynomial_real]
  exact GaussianCoefficient.disorder_polynomial_coefficient (2*d) lam (vertexFunctional d hβ []) k

/-- The complete Gaussian-averaged exterior Wick series is the genuine
normalized annealed partition function. This includes the zero coupling and
every finite flavor number; absolute convergence and all exchanges are proved. -/
theorem hasSum_averagedWickCoefficient (d : ℕ) {β : ℝ} (hβ : 0 < β) (lam : ℝ≥0) :
    HasSum (averagedWickCoefficient d hβ lam)
      (∫ j, Majorana.normalizedTrace d (Gibbs.weight β (Majorana.hamiltonian d j))
        ∂Microscopic.disorder d lam) := by
  let f := fun k => ∫ j, partitionCoefficient d hβ j k ∂Microscopic.disorder d lam
  have hf : HasSum f _ := hasSum_integral_partitionCoefficient d hβ lam
  have hinj : Function.Injective (fun k : ℕ => 2*k) := by intro a b h; dsimp at h; omega
  have he := hf.summable.comp_injective hinj
  have ho : HasSum (fun k => f (2*k+1)) 0 := by
    simpa only [f, integral_partitionCoefficient_odd] using
      (hasSum_zero : HasSum (fun _ : ℕ => (0 : ℂ)) 0)
  have hall := he.hasSum.even_add_odd ho
  have heq := hall.unique hf
  simp only [add_zero] at heq
  have hs := he.hasSum
  rw [heq] at hs
  simpa only [f, Function.comp_def, integral_partitionCoefficient_even] using hs

/-- Exact identification of the numerical Gaussian Wick denominator with
the normalized, strictly positive, ordinary annealed partition function. -/
theorem averagedWick_sum_eq_partition (d : ℕ) {β : ℝ} (hβ : 0 < β) (lam : ℝ≥0) :
    (∑' k, averagedWickCoefficient d hβ lam k) =
      ((∫ j, (Majorana.partitionFunction d β j).re ∂Microscopic.disorder d lam : ℝ) : ℂ) /
        (2 : ℂ)^d := by
  rw [(hasSum_averagedWickCoefficient d hβ lam).tsum_eq]
  simp_rw [Majorana.normalizedTrace, Gibbs.weight_trace_real (Majorana.hamiltonian_star d _)]
  simp only [div_eq_mul_inv]
  rw [integral_mul_const, integral_complex_ofReal]
  rfl

/-- The actual continuum Wick denominator cannot vanish. Positivity is
proved through the genuine Gibbs partition, rather than postulated for a
formal Grassmann integral. -/
theorem averagedWick_sum_re_pos (d : ℕ) {β : ℝ} (hβ : 0 < β) (lam : ℝ≥0) :
    0 < (∑' k, averagedWickCoefficient d hβ lam k).re := by
  rw [averagedWick_sum_eq_partition]
  have he : (2 : ℂ)^d = (((2 : ℝ)^d : ℝ) : ℂ) := by push_cast; rfl
  rw [he, ← Complex.ofReal_div, Complex.ofReal_re]
  exact div_pos (ThermalRP.annealed_partition_positive d β lam) (by positivity)

theorem averagedWick_sum_ne_zero (d : ℕ) {β : ℝ} (hβ : 0 < β) (lam : ℝ≥0) :
    (∑' k, averagedWickCoefficient d hβ lam k) ≠ 0 := by
  intro h
  have hp := averagedWick_sum_re_pos d hβ lam
  rw [h] at hp
  exact lt_irrefl 0 hp

end SYK.PartitionWick
