import GaussianIntegrationByParts
import GaussianScaling
import Mathlib.Analysis.SpecialFunctions.Sqrt
import Mathlib.Analysis.Calculus.ParametricIntegral

/-!
# Differentiation of the actual disorder-averaged partition function

The amplitude parameter multiplies the genuine Gaussian coupling vector.
All differentiation under the integral is justified by explicit operator-norm
bounds and Gaussian exponential integrability. No pressure response identity
is assumed.
-/

set_option maxHeartbeats 300000

noncomputable section
open MeasureTheory ProbabilityTheory Filter
open scoped NNReal Topology BigOperators ComplexOrder

namespace SYK.AnnealedDifferentiation
open Majorana GaussianIBP

/-- Actual finite-volume partition function at scaled couplings. -/
def scaledPartition (m : ℕ) (β a : ℝ) (j : FourSet m → ℝ) : ℝ :=
  (partitionFunction m β (fun I => a * j I)).re

/-- Its actual first response, with the Gibbs weight left unnormalized. -/
def amplitudeResponse (m : ℕ) (β a : ℝ) (j : FourSet m → ℝ) : ℝ :=
  β * ∑ I, j I * thermalInsertion m β (fun I => a * j I) (quartic m I)

theorem sum_abs_scale (m : ℕ) (a : ℝ) (j : FourSet m → ℝ) :
    (∑ I, |a * j I|) = |a| * ∑ I, |j I| := by
  simp only [abs_mul, Finset.mul_sum]

theorem continuous_scaledPartition (m : ℕ) (β a : ℝ) :
    Continuous (scaledPartition m β a) := by
  have hs : Continuous (fun j : FourSet m → ℝ => (fun I => a * j I)) := by fun_prop
  have hp : Continuous (fun j : FourSet m → ℝ => (β, fun I => a * j I)) :=
    continuous_const.prodMk hs
  have hZ := (continuous_partitionFunction m).comp hp
  have hR := Complex.continuous_re.comp hZ
  exact hR

theorem continuous_amplitudeResponse (m : ℕ) (β a : ℝ) :
    Continuous (amplitudeResponse m β a) := by
  unfold amplitudeResponse
  apply continuous_const.mul
  apply continuous_finset_sum
  intro I _
  exact (continuous_apply I).mul
    ((continuous_thermalInsertion m β (quartic m I)).comp (by fun_prop))

theorem hasDerivAt_scaledPartition (m : ℕ) (β a : ℝ) (j : FourSet m → ℝ) :
    HasDerivAt (fun s => scaledPartition m β s j) (amplitudeResponse m β a j) a := by
  simpa only [scaledPartition, amplitudeResponse, zero_add]
    using hasDerivAt_syk_partition_direction_at m β (fun _ => 0) j a

theorem abs_scaledPartition_le (m : ℕ) (β a : ℝ) (j : FourSet m → ℝ) :
    |scaledPartition m β a j| ≤
      (2 : ℝ)^m * Real.exp ((|β| * |a| / 4) * ∑ I, |j I|) := by
  refine (Complex.abs_re_le_norm _).trans ((norm_partitionFunction_le m β _).trans_eq ?_)
  rw [sum_abs_scale]
  congr 2
  ring

theorem scaledPartition_integrable (m : ℕ) (β a : ℝ) (lam : ℝ≥0) :
    Integrable (scaledPartition m β a) (Microscopic.disorder m lam) := by
  have hg := (GaussianDisorder.integrable_exp_sum_abs (FourSet m)
    (2 * m) lam (|β| * |a| / 4)).const_mul ((2 : ℝ)^m)
  apply hg.mono' (continuous_scaledPartition m β a).aestronglyMeasurable
  filter_upwards [] with j
  exact abs_scaledPartition_le m β a j

/-- The explicit first-response majorant has only one polynomial factor. -/
theorem abs_amplitudeResponse_le (m : ℕ) (β a : ℝ) (j : FourSet m → ℝ) :
    |amplitudeResponse m β a j| ≤
      ((2 : ℝ)^m * (|β| / 4)) * (∑ I, |j I|) *
        Real.exp ((|β| * |a| / 4) * ∑ I, |j I|) := by
  unfold amplitudeResponse
  rw [abs_mul]
  calc
    _ ≤ |β| * ∑ I, |j I * thermalInsertion m β (fun I => a * j I) (quartic m I)| :=
      mul_le_mul_of_nonneg_left (Finset.abs_sum_le_sum_abs _ _) (abs_nonneg β)
    _ ≤ |β| * ∑ I, |j I| * ((2 : ℝ)^m * (1 / 4) *
        Real.exp ((|β| * |a| / 4) * ∑ I, |j I|)) := by
      apply mul_le_mul_of_nonneg_left _ (abs_nonneg β)
      apply Finset.sum_le_sum
      intro I _
      rw [abs_mul]
      apply mul_le_mul_of_nonneg_left _ (abs_nonneg _)
      convert abs_thermalInsertion_le m β (fun I => a * j I) (quartic m I) using 1
      rw [norm_quartic, sum_abs_scale]
      congr 2
      ring
    _ = _ := by rw [← Finset.sum_mul]; ring

/-- On a fixed amplitude neighborhood the response has a single Gaussian
exponential majorant, independent of the varying amplitude. -/
theorem amplitudeResponse_local_bound (m : ℕ) (β a₀ : ℝ)
    (j : FourSet m → ℝ) (a : ℝ) (ha : a ∈ Metric.ball a₀ 1) :
    ‖amplitudeResponse m β a j‖ ≤
      ((2 : ℝ)^m * (|β| / 4)) *
        Real.exp ((|β| * (|a₀| + 1) / 4 + 1) * ∑ I, |j I|) := by
  have hs : 0 ≤ ∑ I, |j I| := Finset.sum_nonneg (fun _ _ => abs_nonneg _)
  have ha' : |a| ≤ |a₀| + 1 := by
    have hd : |a - a₀| < 1 := by simpa only [Metric.mem_ball, Real.dist_eq] using ha
    have ht := abs_add_le (a - a₀) a₀
    simp only [sub_add_cancel] at ht
    linarith
  have hc : 0 ≤ (2 : ℝ)^m * (|β| / 4) := by positivity
  have hcoef : (|β| * |a| / 4) * (∑ I, |j I|) ≤
      (|β| * (|a₀| + 1) / 4) * (∑ I, |j I|) := by
    apply mul_le_mul_of_nonneg_right _ hs
    exact div_le_div_of_nonneg_right (mul_le_mul_of_nonneg_left ha' (abs_nonneg β)) (by norm_num)
  have hpoly : (∑ I, |j I|) ≤ Real.exp (∑ I, |j I|) := by
    linarith [Real.add_one_le_exp (∑ I, |j I|)]
  rw [Real.norm_eq_abs]
  refine (abs_amplitudeResponse_le m β a j).trans ?_
  calc
    _ ≤ ((2 : ℝ)^m * (|β| / 4)) * Real.exp (∑ I, |j I|) *
        Real.exp ((|β| * (|a₀| + 1) / 4) * ∑ I, |j I|) := by
      apply mul_le_mul
      · exact mul_le_mul_of_nonneg_left hpoly hc
      · exact Real.exp_le_exp.mpr hcoef
      · positivity
      · positivity
    _ = _ := by rw [mul_assoc, ← Real.exp_add]; congr 2; ring

/-- The disorder-averaged partition function for an arbitrary fixed variance. -/
def averagedPartition (m : ℕ) (β : ℝ) (lam : ℝ≥0) (a : ℝ) : ℝ :=
  ∫ j, scaledPartition m β a j ∂Microscopic.disorder m lam

/-- Differentiation under the actual finite-dimensional Gaussian integral. -/
theorem hasDerivAt_averagedPartition (m : ℕ) (β : ℝ) (lam : ℝ≥0) (a : ℝ) :
    HasDerivAt (averagedPartition m β lam)
      (∫ j, amplitudeResponse m β a j ∂Microscopic.disorder m lam) a := by
  let bound : (FourSet m → ℝ) → ℝ := fun j =>
    ((2 : ℝ)^m * (|β| / 4)) *
      Real.exp ((|β| * (|a| + 1) / 4 + 1) * ∑ I, |j I|)
  have hb : Integrable bound (Microscopic.disorder m lam) :=
    (GaussianDisorder.integrable_exp_sum_abs (FourSet m) (2 * m) lam
      (|β| * (|a| + 1) / 4 + 1)).const_mul _
  apply (hasDerivAt_integral_of_dominated_loc_of_deriv_le
    (μ := Microscopic.disorder m lam) (ε := (1 : ℝ)) (F := scaledPartition m β)
    (F' := amplitudeResponse m β) (bound := bound) (by norm_num)
    (Eventually.of_forall fun s => (continuous_scaledPartition m β s).aestronglyMeasurable)
    (scaledPartition_integrable m β a lam)
    (continuous_amplitudeResponse m β a).aestronglyMeasurable
    (ae_of_all _ (fun j s hs => amplitudeResponse_local_bound m β a j s hs)) hb
    (ae_of_all _ (fun j s _ => hasDerivAt_scaledPartition m β s j))).2


/-- The averaged partition function is strictly positive at every real amplitude. -/
theorem averagedPartition_pos (m : ℕ) (β : ℝ) (lam : ℝ≥0) (a : ℝ) :
    0 < averagedPartition m β lam a := by
  unfold averagedPartition
  have hn : ∀ j, 0 ≤ scaledPartition m β a j := fun j => (Gibbs.syk_partition_re_pos m β _).le
  rw [integral_pos_iff_support_of_nonneg hn (scaledPartition_integrable m β a lam)]
  have hs : Function.support (scaledPartition m β a) = Set.univ := by
    ext j
    simp only [Function.mem_support, Set.mem_univ, iff_true]
    exact (Gibbs.syk_partition_re_pos m β _).ne'
  simp [hs]

/-- The pressure along the actual amplitude family. -/
def amplitudePressure (m : ℕ) (β : ℝ) (lam : ℝ≥0) (a : ℝ) : ℝ :=
  Real.log (averagedPartition m β lam a) / (2 * m)

theorem hasDerivAt_amplitudePressure (m : ℕ) (β : ℝ) (lam : ℝ≥0) (a : ℝ) :
    HasDerivAt (amplitudePressure m β lam)
      (((∫ j, amplitudeResponse m β a j ∂Microscopic.disorder m lam) /
        averagedPartition m β lam a) / (2 * m)) a := by
  exact ((hasDerivAt_averagedPartition m β lam a).log
    (averagedPartition_pos m β lam a).ne').div_const _

/-- Gaussian scaling identifies the amplitude integral with the exact variance
parameter in the microscopic pressure definition, also at variance zero. -/
theorem averagedPartition_sqrt_eq (m : ℕ) (β : ℝ) (lam : ℝ≥0) :
    averagedPartition m β 1 (Real.sqrt (lam : ℝ)) =
      ∫ j, (partitionFunction m β j).re ∂Microscopic.disorder m lam := by
  rw [← Microscopic.disorder_scale m lam]
  symm
  apply integral_map
  · exact (by fun_prop : Measurable (fun j : FourSet m → ℝ =>
      (fun I => Real.sqrt (lam : ℝ) * j I))).aemeasurable
  · have hc : Continuous (fun j : FourSet m → ℝ => (partitionFunction m β j).re) := by
      have hp : Continuous (fun j : FourSet m → ℝ => (β, j)) := continuous_const.prodMk continuous_id
      have hZ := (continuous_partitionFunction m).comp hp
      have hR := Complex.continuous_re.comp hZ
      exact hR
    exact hc.aestronglyMeasurable

/-- Exact identification of the amplitude pressure with the microscopic one. -/
theorem amplitudePressure_sqrt_eq (m : ℕ) (β : ℝ) (lam : ℝ≥0) :
    amplitudePressure m β 1 (Real.sqrt (lam : ℝ)) = Microscopic.annealedPressure m β lam := by
  unfold amplitudePressure Microscopic.annealedPressure GaussianDisorder.annealedPressure
  rw [averagedPartition_sqrt_eq]
  simp only [Nat.cast_mul, Nat.cast_ofNat]
  rfl

/-- The actual finite-N annealed pressure is continuous on all nonnegative
couplings. In particular this proves continuity at the free endpoint λ=0. -/
theorem continuous_annealedPressure (m : ℕ) (β : ℝ) :
    Continuous (fun lam : ℝ≥0 => Microscopic.annealedPressure m β lam) := by
  have ha : Continuous (amplitudePressure m β 1) :=
    continuous_iff_continuousAt.mpr (fun a => (hasDerivAt_amplitudePressure m β 1 a).continuousAt)
  have h := ha.comp (Real.continuous_sqrt.comp NNReal.continuous_coe)
  simpa only [Function.comp_def, amplitudePressure_sqrt_eq] using h

/-- A genuine derivative in the positive variance parameter. The RHS is the
proved first microscopic response, not an assumed limiting pressure formula.
Reducing it to the paper's time-ordered quartic expression additionally needs
the second-response/Duhamel insertion identity. -/
theorem hasDerivAt_annealedPressure_pos (m : ℕ) (β lam : ℝ) (hlam : 0 < lam) :
    HasDerivAt (fun s : ℝ => Microscopic.annealedPressure m β s.toNNReal)
      ((((∫ j, amplitudeResponse m β (Real.sqrt lam) j ∂Microscopic.disorder m 1) /
          averagedPartition m β 1 (Real.sqrt lam)) / (2 * m)) *
            (1 / (2 * Real.sqrt lam))) lam := by
  have h := (hasDerivAt_amplitudePressure m β 1 (Real.sqrt lam)).comp lam
    (Real.hasDerivAt_sqrt (ne_of_gt hlam))
  have heq (s : ℝ) : amplitudePressure m β 1 (Real.sqrt s) =
      Microscopic.annealedPressure m β s.toNNReal := by
    have hs : Real.sqrt ((s.toNNReal : ℝ≥0) : ℝ) = Real.sqrt s := by
      simp only [Real.sqrt, Real.toNNReal_coe]
    simpa only [hs] using amplitudePressure_sqrt_eq m β s.toNNReal
  simpa only [Function.comp_def, heq] using h


/-- The continuous endpoint is the exact free pressure, with no limiting
integral or exchange-of-limits hypothesis. -/
theorem tendsto_annealedPressure_zero (m : ℕ) (hm : 0 < m) (β : ℝ) :
    Tendsto (fun lam : ℝ≥0 => Microscopic.annealedPressure m β lam)
      (𝓝 0) (𝓝 (Real.log 2 / 2)) := by
  rw [← Microscopic.annealedPressure_free m hm β]
  exact (continuous_annealedPressure m β).continuousAt

end SYK.AnnealedDifferentiation


