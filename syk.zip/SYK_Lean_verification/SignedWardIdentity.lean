import SignedWardReduction
import FundamentalWardBridge

/-! # Exact signed extension of fundamental Ward identities

The four interaction-field winding signs cancel pointwise. Therefore no seam
exception, endpoint invariance premise or almost-everywhere alteration of an
external endpoint is used in extending the finite Ward equation.
-/
noncomputable section
open scoped BigOperators NNReal
open MeasureTheory
namespace SYK.SignedWardReduction
open ThermalWick WickVertexIntegrals ThermalEndpointLift WeightedKernelAlgebra MvPolynomial

variable (β : ℝ) (hβ : 0<β)

/-- The literal scalar-kernel-valued interaction polynomial on the real line. -/
def realInteraction (s t : ℝ) (p : ℝ×ℝ) : RealPolynomial :=
  (Thermal.kernel β s p.1:ℂ) •
    MixedIncrement.coordinateProduct [(p.1,p.2),(p.1,p.2),(p.1,p.2),(p.2,t)]

/-- The same density with actual half-open field labels in the fundamental algebra. -/
abbrev fundamentalInteraction (s t : Time β) (p : ℝ×ℝ) : TimePolynomial β :=
  FundamentalWardBridge.interactionPolynomial β hβ s t p

/-- Four appearances of every internal endpoint remove all winding signs,
leaving exactly the distinguished external pair sign. -/
theorem reduction_interaction (s t : ℝ) (p : ℝ×ℝ) :
    reduction β hβ (realInteraction β s t p) =
      pairSign β hβ (s,t) • fundamentalInteraction β hβ
        (timeRepresentative β hβ s) (timeRepresentative β hβ t) p := by
  simp only [realInteraction,fundamentalInteraction,FundamentalWardBridge.interactionPolynomial,
    FundamentalWardBridge.interactionPairs,List.replicate_succ,List.replicate_zero,
    List.cons_append,List.nil_append,MixedIncrement.coordinateProduct,
    FundamentalWardContacts.coordinateProduct,List.map_cons,List.map_nil,List.prod_cons,
    List.prod_nil,mul_one,map_smul,map_mul,reduction_X,smul_mul_assoc,mul_smul_comm,smul_smul]
  rw [covariance_reduce β hβ s p.1]
  simp only [timePair,pairSign]
  congr 1
  calc
    _ = (endpointSign β hβ s * endpointSign β hβ t *
        (Thermal.kernel β (timeRepresentative β hβ s).val (timeRepresentative β hβ p.1).val:ℂ)) *
        ((endpointSign β hβ p.1 * endpointSign β hβ p.1) *
          (endpointSign β hβ p.1 * endpointSign β hβ p.1)) *
        ((endpointSign β hβ p.2 * endpointSign β hβ p.2) *
          (endpointSign β hβ p.2 * endpointSign β hβ p.2)) := by ring
    _ = _ := by simp only [endpointSign_sq,mul_one]

/-- Exact inserted interaction reduction for an arbitrary linear functional. -/
theorem inserted_interaction_reduction (L : TimePolynomial β →ₗ[ℂ] ℂ)
    (Q : RealPolynomial) (s t : ℝ) (p : ℝ×ℝ) :
    L (reduction β hβ (Q*realInteraction β s t p)) =
      pairSign β hβ (s,t) * L (reduction β hβ Q * fundamentalInteraction β hβ
        (timeRepresentative β hβ s) (timeRepresentative β hβ t) p) := by
  rw [map_mul,reduction_interaction,mul_smul_comm,map_smul,smul_eq_mul]

/-- Fundamental Ward equations imply all-real Ward equations with exact
contacts. This is a proved algebraic/Bochner transport for any integration
measure, not an additional equation imposed on a limiting state. -/
theorem ward_of_fundamental (μ : Measure (ℝ×ℝ)) (L : TimePolynomial β →ₗ[ℂ] ℂ)
    (lam b : ℂ)
    (hward : ∀ (P : TimePolynomial β) (s t : Time β),
      L (P*(X (s,t)-C (Thermal.kernel β s.val t.val:ℂ))) =
        lam*(∫ p, L (P*fundamentalInteraction β hβ s t p) ∂μ) +
          b*L (FundamentalWardContacts.contact s t P))
    (Q : RealPolynomial) (s t : ℝ) :
    L (reduction β hβ (Q*MixedIncrement.remainder β (s,t))) =
      lam*(∫ p, L (reduction β hβ (Q*realInteraction β s t p)) ∂μ) +
        b*L (reduction β hβ (RealWardContacts.contact β s t Q)) := by
  rw [map_mul,reduction_remainder,mul_smul_comm,map_smul,smul_eq_mul]
  simp only [timePair]
  rw [hward]
  simp_rw [inserted_interaction_reduction β hβ L Q s t]
  rw [integral_const_mul,reduction_contact,map_smul,smul_eq_mul]
  ring

/-- The exact finite microscopic all-real Ward equation, assuming only its
fundamental-domain microscopic equation. Every centered insertion is included. -/
theorem actualWard_of_fundamental (μ : Measure (ℝ×ℝ)) (d : ℕ) (lam : ℝ≥0)
    (hward : ∀ (P : TimePolynomial β) (s t : Time β),
      actualFundamental β d lam (P*(X (s,t)-C (Thermal.kernel β s.val t.val:ℂ))) =
        (lam:ℂ)*(∫ p, actualFundamental β d lam (P*fundamentalInteraction β hβ s t p) ∂μ) +
          (((2*d:ℕ):ℂ)⁻¹)*actualFundamental β d lam (FundamentalWardContacts.contact s t P))
    (Q : RealPolynomial) (s t : ℝ) :
    ThermalMomentTransport.actualThermalPolynomial β hβ d lam (Q*MixedIncrement.remainder β (s,t)) =
      (lam:ℂ)*(∫ p, (Thermal.kernel β s p.1:ℂ)*
        ThermalMomentTransport.actualThermalPolynomial β hβ d lam
          (Q*MixedIncrement.coordinateProduct [(p.1,p.2),(p.1,p.2),(p.1,p.2),(p.2,t)]) ∂μ) +
        (((2*d:ℕ):ℂ)⁻¹)*ThermalMomentTransport.actualThermalPolynomial β hβ d lam
          (RealWardContacts.contact β s t Q) := by
  have h := ward_of_fundamental β hβ μ (actualFundamental β d lam) (lam:ℂ) (((2*d:ℕ):ℂ)⁻¹)
    hward Q s t
  simp only [← actualThermal_eq_reduction,realInteraction,mul_smul_comm,map_smul,smul_eq_mul] at h
  exact h

end SYK.SignedWardReduction
