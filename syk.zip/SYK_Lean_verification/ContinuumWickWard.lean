import ContinuumWickSeries

/-!
# Inserted Ward identities for the genuine continuum coefficient integrals

The polynomial identities come from exterior contraction. They are integrated
and summed only after the scalar coefficient bounds have been proved.
-/
set_option maxHeartbeats 1200000
noncomputable section
open MeasureTheory Set Filter
open scoped Topology BigOperators
namespace SYK.ContinuumWickSeries
open ThermalWick Ward WickVertexIntegrals

/-- Flavor-averaging the genuine free Wick identity gives its exact partner
contraction, before any interaction or time integration. -/
theorem expectation_collective_mul {N : ℕ} (hN : 0 < N) {β : ℝ}
    (s t : Time β) (P : FieldAlgebra N β) :
    expectation N β (collective N β s t*P) =
      (Thermal.kernel β s.val t.val:ℂ)*expectation N β P -
        ((N:ℂ)⁻¹)*expectation N β (partnerContraction s t P) := by
  have hNC : (N:ℂ) ≠ 0 := by exact_mod_cast hN.ne'
  have hi (i : Fin N) : expectation N β (field i s*(field i t*P)) =
      (Thermal.kernel β s.val t.val:ℂ)*expectation N β P -
        expectation N β (field i t*(covariance N β).contraction (Finsupp.single (i,s) 1) P) := by
    simpa only [covariance_single,ite_true] using
      (covariance N β).expectation_two_inserted (Finsupp.single (i,s) 1)
        (Finsupp.single (i,t) 1) P
  simp only [collective,smul_mul_assoc,Finset.sum_mul,map_smul,map_sum,smul_eq_mul,mul_assoc]
  simp_rw [hi]
  simp only [Finset.sum_sub_distrib,Finset.sum_const,Finset.card_univ,Fintype.card_fin,nsmul_eq_mul,
    partnerContraction,map_sum]
  field_simp
  ring

/-- Collective monomials have even parity, including the empty insertion. -/
theorem collectiveMonomial_even {N : ℕ} {β : ℝ} (ps : List (Time β × Time β)) :
    CliffordAlgebra.involute (collectiveMonomial (N := N) ps)=collectiveMonomial ps := by
  simp only [collectiveMonomial,map_list_prod,List.map_map]
  congr 1
  apply List.map_congr_left
  intro p hp
  exact collective_even N β p.1 p.2

/-- The finite inserted Ward split retains every insertion contact exactly. -/
theorem expectation_inserted_ward {N : ℕ} (hN : 0 < N) {β : ℝ}
    (s t : Time β) (ps : List (Time β × Time β)) (V : FieldAlgebra N β) :
    expectation N β (collective N β s t*(collectiveMonomial ps*V)) =
      (Thermal.kernel β s.val t.val:ℂ)*expectation N β (collectiveMonomial ps*V) +
      ((N:ℂ)⁻¹)*expectation N β (contactPolynomial s t ps*V) -
      ((N:ℂ)⁻¹)*expectation N β (collectiveMonomial ps*partnerContraction s t V) := by
  rw [expectation_collective_mul hN,partnerContraction_even_mul s t _ _ (collectiveMonomial_even ps),
    map_add]
  have he : expectation N β (partnerContraction s t (collectiveMonomial ps)*V) =
      -expectation N β (contactPolynomial s t ps*V) := by
    have hp := partnerContraction_monomial (N := N) s t ps
    rw [← hp,neg_mul,map_neg,neg_neg]
  rw [he]
  ring

def normalizedPartner {N : ℕ} {β : ℝ} (s t : Time β) (P : FieldAlgebra N β) : FieldAlgebra N β :=
  -((N:ℂ)⁻¹) • partnerContraction s t P

@[simp] theorem normalizedPartner_one {N : ℕ} {β : ℝ} (s t : Time β) :
    normalizedPartner (N := N) s t 1=0 := by
  simp [normalizedPartner,partnerContraction]

theorem normalizedPartner_even_mul {N : ℕ} {β : ℝ} (s t : Time β)
    (P Q : FieldAlgebra N β) (hP : CliffordAlgebra.involute P=P) :
    normalizedPartner s t (P*Q)=normalizedPartner s t P*Q+P*normalizedPartner s t Q := by
  simp only [normalizedPartner,partnerContraction_even_mul s t P Q hP,smul_add,
    smul_mul_assoc,mul_smul_comm]

/-- The full interaction derivative is a finite sum of marked vertices.
This identity does not use any commutativity of the ambient field algebra. -/
theorem normalizedPartner_product {N : ℕ} {β : ℝ} (s t : Time β) {n : ℕ}
    (V : Fin n → FieldAlgebra N β) (hV : ∀ i, CliffordAlgebra.involute (V i)=V i) :
    normalizedPartner s t (DuhamelHistory.orderedProduct V) =
      ∑ i : Fin n, DuhamelHistory.orderedProduct
        (Function.update V i (normalizedPartner s t (V i))) := by
  classical
  induction n with
  | zero => simp
  | succ n ih =>
    have h0 : DuhamelHistory.orderedProduct (Function.update V 0 (normalizedPartner s t (V 0))) =
        normalizedPartner s t (V 0)*DuhamelHistory.orderedProduct (fun i => V i.succ) := by
      rw [DuhamelHistory.orderedProduct_succ,Function.update_self]
      congr 1
    have hs (j : Fin n) : DuhamelHistory.orderedProduct
        (Function.update V j.succ (normalizedPartner s t (V j.succ))) =
        V 0*DuhamelHistory.orderedProduct
          (Function.update (fun i => V i.succ) j (normalizedPartner s t (V j.succ))) := by
      rw [DuhamelHistory.orderedProduct_succ,Function.update_of_ne (Fin.succ_ne_zero j).symm]
      congr 1
      apply congrArg DuhamelHistory.orderedProduct
      funext i
      by_cases he : i=j
      · subst i; simp
      · simp [Function.update_of_ne he,Function.update_of_ne (fun h => he (Fin.succ_inj.mp h))]
    rw [DuhamelHistory.orderedProduct_succ,normalizedPartner_even_mul s t _ _ (hV 0),
      ih (fun i => V i.succ) (fun i => hV i.succ),Fin.sum_univ_succ,h0]
    simp_rw [hs]
    rw [Finset.mul_sum]

end SYK.ContinuumWickSeries
