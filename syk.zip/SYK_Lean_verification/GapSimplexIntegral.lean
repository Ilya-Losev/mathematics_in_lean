import OrderedSimplexIntegral

/-!
# Gapwise matrix coefficients as actual time integrals

A multi-index specifies a genuine ordered simplex in each thermal gap.
Their product measure produces exactly the factorial-normalized exponential
coefficients, with arbitrary noncommuting matrices between the gaps.
-/

noncomputable section
open scoped BigOperators
open MeasureTheory MeasureTheory.Measure Set
open SYK.OrderedSimplexIntegral

namespace SYK.GapSimplexIntegral

/-- Independently ordered interaction times in each fixed thermal gap. -/
def gapSimplex {ι : Type*} [Fintype ι] (r : ι → ℕ) (a b : ι → ℝ) :
    Set ((i : ι) → Fin (r i) → ℝ) :=
  univ.pi (fun i => orderedSimplex (r i) (a i) (b i))

theorem gapSimplex_measurable {ι : Type*} [Fintype ι]
    (r : ι → ℕ) (a b : ι → ℝ) : MeasurableSet (gapSimplex r a b) :=
  MeasurableSet.univ_pi (fun i => orderedSimplex_measurable (r i) (a i) (b i))

theorem gapSimplex_compact {ι : Type*} [Fintype ι]
    (r : ι → ℕ) (a b : ι → ℝ) : IsCompact (gapSimplex r a b) :=
  isCompact_univ_pi (fun i => orderedSimplex_compact (r i) (a i) (b i))

/-- Exact product-simplex volume, including empty or zero-width gaps. -/
theorem gapSimplex_volume_real {ι : Type*} [Fintype ι]
    (r : ι → ℕ) (a b : ι → ℝ) (hab : ∀ i, a i ≤ b i) :
    volume.real (gapSimplex r a b) = ∏ i, (b i-a i)^(r i) / (r i).factorial := by
  rw [measureReal_def, gapSimplex, volume_pi_pi, ENNReal.toReal_prod]
  exact Finset.prod_congr rfl (fun i _ => orderedSimplex_volume_real (r i) (a i) (b i) (hab i))

theorem integral_gapSimplex_const {ι : Type*} [Fintype ι]
    {E : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E] [CompleteSpace E]
    (r : ι → ℕ) (a b : ι → ℝ) (hab : ∀ i, a i ≤ b i) (v : E) :
    ∫ _u in gapSimplex r a b, v = (∏ i, (b i-a i)^(r i) / (r i).factorial) • v := by
  rw [setIntegral_const, gapSimplex_volume_real r a b hab]

/-- Central scalar coefficients can be extracted from a finite ordered
product without assuming that its matrix factors commute. -/
theorem ofFn_prod_smul {R A : Type*} [CommSemiring R] [Semiring A] [Algebra R A]
    {k : ℕ} (c : Fin k → R) (V : Fin k → A) :
    (List.ofFn (fun i => c i • V i)).prod = (∏ i, c i) • (List.ofFn V).prod := by
  induction k with
  | zero => simp
  | succ k ih =>
      simp only [List.ofFn_succ, List.prod_cons, Fin.prod_univ_succ]
      rw [ih, smul_mul_smul_comm]

section Histories
variable {A : Type*} [NormedRing A] [NormedAlgebra ℂ A]
    [NormedSpace ℝ A] [CompleteSpace A]

/-- Exact multiple-gap coefficient identity for constant, potentially
noncommuting interactions and arbitrary fixed interspersed insertions. -/
theorem integral_gap_history {k : ℕ} (r : Fin k → ℕ) (a b : Fin k → ℝ)
    (hab : ∀ i, a i ≤ b i) (H U : Fin k → A) :
    ∫ _u in gapSimplex r a b, (List.ofFn (fun i => (H i)^(r i) * U i)).prod =
      (List.ofFn (fun i => ((r i).factorial : ℂ)⁻¹ •
        ((((b i-a i : ℝ) : ℂ) • H i)^(r i)) * U i)).prod := by
  rw [integral_gapSimplex_const r a b hab,
    RCLike.real_smul_eq_coe_smul (K := ℂ)]
  have hi (i : Fin k) :
      ((r i).factorial : ℂ)⁻¹ • ((((b i-a i : ℝ) : ℂ) • H i)^(r i)) * U i =
      (((b i-a i)^(r i) / (r i).factorial : ℝ) : ℂ) • ((H i)^(r i) * U i) := by
    rw [smul_pow, smul_smul, smul_mul_assoc]
    congr 1
    push_cast
    ring
  simp_rw [hi]
  rw [ofFn_prod_smul]
  congr 1
  push_cast
  rfl

/-- The same identity directly for scalar observables such as the normalized
matrix trace. The functional need not be multiplicative. -/
theorem integral_gap_history_observable {k : ℕ} (r : Fin k → ℕ) (a b : Fin k → ℝ)
    (hab : ∀ i, a i ≤ b i) (H U : Fin k → A) (φ : A →L[ℂ] ℂ) :
    ∫ _u in gapSimplex r a b, φ ((List.ofFn (fun i => (H i)^(r i) * U i)).prod) =
      φ ((List.ofFn (fun i => ((r i).factorial : ℂ)⁻¹ •
        ((((b i-a i : ℝ) : ℂ) • H i)^(r i)) * U i)).prod) := by
  have h := congrArg φ (integral_gap_history r a b hab H U)
  rw [integral_gapSimplex_const r a b hab,
    RCLike.real_smul_eq_coe_smul (K := ℂ), map_smul] at h
  rw [integral_gapSimplex_const r a b hab,
    RCLike.real_smul_eq_coe_smul (K := ℂ)]
  exact h

end Histories
end SYK.GapSimplexIntegral
