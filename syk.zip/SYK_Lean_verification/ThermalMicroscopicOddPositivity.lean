import ThermalMicroscopicPositivity
import OddPolynomialReflection

/-!
# Actual inserted odd positivity for all half polynomials

The product-index identity realizes the full inserted Hankel form as a finite
odd Weyl square. Signed thermal reduction is exact on these interior tests.
-/

noncomputable section
namespace SYK.ThermalMicroscopicOddPositivity
open SYK.WeightedKernelAlgebra SYK.ThermalEndpointLift SYK.ThermalMomentTransport
open SYK.MomentLimit SYK.MomentCompactness SYK.ThermalRPTransport
open SYK.PolynomialRP SYK.OddPolynomialRP SYK.ThermalMicroscopicPositivity
open MeasureTheory Filter Set
open scoped BigOperators Topology NNReal

/-- The full inserted odd form is a single finite odd Gram form, indexed by
the Cartesian product of polynomial monomials and Hankel coefficients. -/
theorem tuple_hankel_eq_odd_form {ι κ : Type*} [Fintype ι] [Fintype κ]
    (β : ℝ) (k : ι → ℕ) (c : ι → ℂ) (p : ∀ i, EndpointCube β (k i))
    (s : κ → Icc (0:ℝ) β) (b : κ → ℂ) :
    reflectedTuplePolynomial β k c p * tuplePolynomial β k c p *
      (∑ a, ∑ b', (star (b a)*b b') • MvPolynomial.X (crossEndpoint β (s a) (s b'))) =
    oddTupleForm β (fun i : ι×κ => k i.1) (fun i => c i.1*b i.2)
      (fun i => p i.1) (fun i => s i.2) := by
  classical
  simp only [reflectedTuplePolynomial, tuplePolynomial, oddTupleForm, Fintype.sum_prod_type,
    Finset.sum_mul, Finset.mul_sum, smul_mul_assoc, mul_smul_comm, Finset.smul_sum, smul_smul, star_mul]
  conv_lhs =>
    enter [2, a, 2, b']
    rw [Finset.sum_comm]
  conv_lhs =>
    enter [2, a]
    rw [Finset.sum_comm]
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro i _
  apply Finset.sum_congr rfl
  intro a _
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro j _
  apply Finset.sum_congr rfl
  intro b' _
  simp only [Algebra.smul_def, map_mul]
  ring

variable (β : ℝ) (hβ : 0 < β)

def compactHalfTime (x : Ioo (0:ℝ) (β/2)) : Icc (0:ℝ) β :=
  ⟨x.val, x.property.1.le, by linarith [x.property.2]⟩

/-- Actual finite-size inserted odd reflection positivity, for arbitrary
half-polynomial insertions and arbitrary finite Hankel vectors. -/
theorem actualThermal_half_odd_nonnegative (d : ℕ) (lam : ℝ≥0)
    (P : MvPolynomial (HalfPair β) ℂ) (m : ℕ)
    (x : Fin m → Ioo (0:ℝ) (β/2)) (b : Fin m → ℂ) :
    0 ≤ (actualThermalPolynomial β hβ d lam
      (reflectPolynomial β (halfPolynomial β P) * halfPolynomial β P *
        hankelPolynomial β (fun i => x i) b)).re := by
  classical
  let k : P.support → ℕ := fun e => (monomialList e.val).length
  let c : P.support → ℂ := fun e => MvPolynomial.coeff e.val P
  let p : ∀ e : P.support, EndpointCube β (k e) :=
    fun e r => compactHalfPair β hβ (monomialTuple e.val r)
  have hp : ∀ e r, (p e r).1.val < β/2 ∧ (p e r).2.val < β/2 := by
    intro e r
    exact ⟨(monomialTuple e.val r).1.property.2, (monomialTuple e.val r).2.property.2⟩
  have he : MvPolynomial.rename (compactHalfPair β hβ) P = tuplePolynomial β k c p := by
    conv_lhs => rw [polynomial_tuple_expansion P]
    simp only [map_sum, map_smul, map_prod, MvPolynomial.rename_X, tuplePolynomial, k, c, p]
  rw [actualThermal_odd_test_eq, he, compactReflection_tuple]
  change 0 ≤ (actualPolynomial d β lam
    (reflectedTuplePolynomial β k c p * tuplePolynomial β k c p *
      (∑ a, ∑ b', (star (b a)*b b') •
        MvPolynomial.X (crossEndpoint β (compactHalfTime β hβ (x a)) (compactHalfTime β hβ (x b')))))).re
  rw [tuple_hankel_eq_odd_form]
  apply actualPolynomial_odd_nonnegative
  · intro i r
    exact hp i.1 r
  · intro i
    exact (x i.2).property.2

end SYK.ThermalMicroscopicOddPositivity
