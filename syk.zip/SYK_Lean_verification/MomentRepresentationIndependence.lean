import RepresentationIndependence
import DuhamelVertexExpansion

/-!
# Representation independence of interacting collective moments

Even CAR word trace identities extend through genuine interspersed exponential
histories by their absolutely convergent power series. Finite Weyl and flavor
averaging, Gaussian integration, and partition normalization then preserve the
identity, including every equal-time coincidence.
-/
noncomputable section
open scoped BigOperators NNReal ComplexOrder
open MeasureTheory
namespace SYK.MomentRepresentationIndependence
open FreeWick RepresentationIndependence DuhamelHistory DuhamelVertex

section Algebra
variable {ι κ A B : Type*} [Fintype κ]
  [Ring A] [Algebra ℂ A] [Ring B] [Algebra ℂ B]

/-- Products of arbitrary even-Hamiltonian powers and arbitrary insertion
words have universal trace whenever the total insertion degree is even. -/
theorem power_history_trace_eq
    (x : ι → A) (y : ι → B) (w : κ → List ι) (hw : ∀ i, Even (w i).length)
    (τ : A →ₗ[ℂ] ℂ) (σ : B →ₗ[ℂ] ℂ)
    (he : ∀ L, Even L.length → τ (word x L) = σ (word y L))
    {k : ℕ} (a : Fin k → κ → ℂ) (n : Fin k → ℕ) (V : Fin k → List ι)
    (P : List ι) (hP : Even (P.length + ∑ i, (V i).length)) :
    τ (word x P * orderedProduct (fun i => (evenHamiltonian x w (a i))^(n i) * word x (V i))) =
    σ (word y P * orderedProduct (fun i => (evenHamiltonian y w (a i))^(n i) * word y (V i))) := by
  induction k generalizing P with
  | zero => simpa only [orderedProduct_zero, mul_one, Finset.univ_eq_empty,
      Finset.sum_empty, add_zero] using he P (by simpa using hP)
  | succ k ih =>
    simp only [orderedProduct_succ]
    have main : ∀ r : ℕ, ∀ P : List ι,
        Even (P.length + (V 0).length + ∑ i : Fin k, (V i.succ).length) →
        τ (word x P * ((evenHamiltonian x w (a 0))^r * word x (V 0) *
          orderedProduct (fun i : Fin k => (evenHamiltonian x w (a i.succ))^(n i.succ) * word x (V i.succ)))) =
        σ (word y P * ((evenHamiltonian y w (a 0))^r * word y (V 0) *
          orderedProduct (fun i : Fin k => (evenHamiltonian y w (a i.succ))^(n i.succ) * word y (V i.succ)))) := by
      intro r
      induction r with
      | zero =>
        intro P hp
        simpa only [pow_zero, one_mul, ← mul_assoc, ← word_append] using
          ih (fun i => a i.succ) (fun i => n i.succ) (fun i => V i.succ)
            (P ++ V 0) (by simpa only [List.length_append] using hp)
      | succ r ihr =>
        intro P hp
        simp only [pow_succ', evenHamiltonian, Finset.sum_mul, Finset.mul_sum,
          smul_mul_assoc, mul_smul_comm, map_sum, map_smul]
        apply Finset.sum_congr rfl
        intro i _
        congr 1
        have hp' : Even ((P ++ w i).length + (V 0).length +
            ∑ j : Fin k, (V j.succ).length) := by
          convert hp.add (hw i) using 1
          simp only [List.length_append]
          omega
        simpa only [word_append, mul_assoc, evenHamiltonian] using ihr (P ++ w i) hp'
    exact main (n 0) P (by simpa only [Fin.sum_univ_succ, ← add_assoc] using hP)
end Algebra

section Exponential
variable {ι κ A B : Type*} [Fintype κ]
  [NormedRing A] [NormedAlgebra ℂ A] [NormOneClass A] [CompleteSpace A]
  [NormedRing B] [NormedAlgebra ℂ B] [NormOneClass B] [CompleteSpace B]

/-- The actual simultaneous exponential series upgrades universal even-word
traces to the full interspersed exponential thermal histories. -/
theorem exponential_history_trace_eq
    (x : ι → A) (y : ι → B) (w : κ → List ι) (hw : ∀ i, Even (w i).length)
    (τ : A →L[ℂ] ℂ) (σ : B →L[ℂ] ℂ)
    (he : ∀ L, Even L.length → τ (word x L) = σ (word y L))
    {k : ℕ} (a : Fin k → κ → ℂ) (V : Fin k → List ι)
    (hV : Even (∑ i, (V i).length)) :
    τ (orderedProduct (fun i => NormedSpace.exp ℂ (evenHamiltonian x w (a i)) * word x (V i))) =
    σ (orderedProduct (fun i => NormedSpace.exp ℂ (evenHamiltonian y w (a i)) * word y (V i))) := by
  have hx := (hasSum_exponential_history (fun i => evenHamiltonian x w (a i))
    (fun i => word x (V i))).mapL τ
  have hy := (hasSum_exponential_history (fun i => evenHamiltonian y w (a i))
    (fun i => word y (V i))).mapL σ
  have hc (r : Fin k → ℕ) :
      τ (orderedProduct (fun i => expCoefficient (evenHamiltonian x w (a i)) (r i) * word x (V i))) =
      σ (orderedProduct (fun i => expCoefficient (evenHamiltonian y w (a i)) (r i) * word y (V i))) := by
    simp only [expCoefficient, smul_mul_assoc, orderedProduct_smul, map_smul]
    congr 1
    simpa only [word_nil, one_mul] using power_history_trace_eq x y w hw
      τ.toLinearMap σ.toLinearMap he a r V [] (by simpa using hV)
  simp only [hc] at hx
  exact hx.unique hy
end Exponential

section Matrix
variable {ν : Type*} [Fintype ν] [DecidableEq ν]

/-- The universal even-word identity for ordinary traces in the manuscript's
fixed dimension, for the supplied CAR matrices and the concrete Pauli family. -/
theorem matrix_even_word_trace_eq (d : ℕ) (x : Fin (2*d) → Matrix ν ν ℂ)
    (hx : ∀ i j, x i*x j+x j*x i = flavorDelta i j • (1:Matrix ν ν ℂ))
    (hcard : Fintype.card ν = 2^d) (L : List (Fin (2*d))) (hL : Even L.length) :
    Matrix.trace (word x L) = Matrix.trace (word (Majorana.chiFin d) L) := by
  have hy : ∀ i j, Majorana.chiFin d i * Majorana.chiFin d j +
      Majorana.chiFin d j * Majorana.chiFin d i = flavorDelta i j •
        (1:Matrix (Majorana.Basis d) (Majorana.Basis d) ℂ) := by
    intro i j
    rw [Majorana.chiFin_car]
    by_cases h : i=j <;> simp [flavorDelta,h]
  exact even_word_trace_eq x (Majorana.chiFin d) flavorDelta hx hy
    (Matrix.traceLinearMap ν ℂ ℂ) (Matrix.traceLinearMap (Majorana.Basis d) ℂ ℂ)
    (fun u v => Matrix.trace_mul_comm u v) (fun u v => Matrix.trace_mul_comm u v)
    (by simp [Matrix.trace_one,hcard]) L hL

/-- Full exponential histories of the actual quartic Hamiltonian are
representation independent, with arbitrary real gaps and total even degree. -/
theorem matrix_history_trace_eq (d : ℕ) (x : Fin (2*d) → Matrix ν ν ℂ)
    (hx : ∀ i j, x i*x j+x j*x i = flavorDelta i j • (1:Matrix ν ν ℂ))
    (hcard : Fintype.card ν = 2^d) (j : Majorana.FourSet d → ℝ)
    {k : ℕ} (t : Fin k → ℝ) (V : Fin k → List (Fin (2*d)))
    (hV : Even (∑ i, (V i).length)) :
    Matrix.trace (orderedProduct (fun i => Gibbs.weight (t i) (hamiltonian d x j) * word x (V i))) =
    Matrix.trace (orderedProduct (fun i => Gibbs.weight (t i) (Majorana.hamiltonian d j) *
      word (Majorana.chiFin d) (V i))) := by
  letI : Nonempty ν := Fintype.card_pos_iff.mp (by rw [hcard]; positivity)
  let τ : CStarMatrix ν ν ℂ →L[ℂ] ℂ :=
    (Matrix.traceLinearMap ν ℂ ℂ).toContinuousLinearMap.comp
      CStarMatrix.ofMatrixL.symm.toContinuousLinearMap
  let σ : CStarMatrix (Majorana.Basis d) (Majorana.Basis d) ℂ →L[ℂ] ℂ :=
    (Matrix.traceLinearMap (Majorana.Basis d) ℂ ℂ).toContinuousLinearMap.comp
      CStarMatrix.ofMatrixL.symm.toContinuousLinearMap
  have he (L : List (Fin (2*d))) (hL : Even L.length) :
      τ (word (fun i => CStarMatrix.ofMatrix (x i)) L) =
        σ (word (fun i => CStarMatrix.ofMatrix (Majorana.chiFin d i)) L) :=
    matrix_even_word_trace_eq d x hx hcard L hL
  have hh := exponential_history_trace_eq
    (fun i => CStarMatrix.ofMatrix (x i))
    (fun i => CStarMatrix.ofMatrix (Majorana.chiFin d i))
    (quarticWord d) (quarticWord_even d) τ σ he
    (fun i I => (t i*j I : ℝ)) V hV
  change Matrix.trace (orderedProduct (fun i => NormedSpace.exp ℂ
      (evenHamiltonian x (quarticWord d) (fun I => (t i*j I : ℝ))) * word x (V i))) =
    Matrix.trace (orderedProduct (fun i => NormedSpace.exp ℂ
      (evenHamiltonian (Majorana.chiFin d) (quarticWord d) (fun I => (t i*j I : ℝ))) *
        word (Majorana.chiFin d) (V i))) at hh
  simpa only [← boltzmann_eq_evenHamiltonian, hamiltonian_canonical, Gibbs.weight] using hh

/-- An ordered thermal Majorana history has the same ordinary trace in every
CAR realization of dimension 2^d. No order or distinctness hypothesis is used. -/
theorem timeProduct_trace_eq (d : ℕ) (x : Fin (2*d) → Matrix ν ν ℂ)
    (hx : ∀ i j, x i*x j+x j*x i = flavorDelta i j • (1:Matrix ν ν ℂ))
    (hcard : Fintype.card ν = 2^d) (j : Majorana.FourSet d → ℝ)
    (β : ℝ) {k : ℕ} (t : Fin k → ℝ) (f : Fin k → Fin (2*d)) (hk : Even k) :
    Matrix.trace (Interacting.timeProduct (hamiltonian d x j) β t (x ∘ f)) =
      Matrix.trace (Interacting.timeProduct (Majorana.hamiltonian d j) β t (Majorana.chiFin d ∘ f)) := by
  let V : Fin (k+1) → List (Fin (2*d)) := Fin.snoc (fun i => [f i]) []
  have hV : Even (∑ i, (V i).length) := by
    simpa only [Fin.sum_univ_castSucc, V, Fin.snoc_castSucc, Fin.snoc_last,
      List.length_singleton, List.length_nil, add_zero, Finset.sum_const,
      Finset.card_univ, Fintype.card_fin, smul_eq_mul, mul_one] using hk
  have hword (y : Fin (2*d) → Matrix ν ν ℂ) :
      (fun i => word y (V i)) = Fin.snoc (y ∘ f) 1 := by
    funext i
    refine Fin.lastCases ?_ (fun r => ?_) i <;> simp [V, Function.comp_def]
  have hword' : (fun i => word (Majorana.chiFin d) (V i)) =
      Fin.snoc (Majorana.chiFin d ∘ f) 1 := by
    funext i
    refine Fin.lastCases ?_ (fun r => ?_) i <;> simp [V, Function.comp_def]
  have hh := matrix_history_trace_eq d x hx hcard j (Interacting.gaps k β t) V hV
  simp only [Interacting.timeProduct_eq_gaps]
  change Matrix.trace (orderedProduct _) = Matrix.trace (orderedProduct _)
  simpa only [congrFun (hword x), congrFun hword'] using hh

/-- Full signed Weyl antisymmetrization preserves the universal thermal
trace identity. In particular all tied-time sorting permutations are kept. -/
theorem weylNumerator_eq (d : ℕ) (x : Fin (2*d) → Matrix ν ν ℂ)
    (hx : ∀ i j, x i*x j+x j*x i = flavorDelta i j • (1:Matrix ν ν ℂ))
    (hcard : Fintype.card ν = 2^d) (j : Majorana.FourSet d → ℝ)
    (β : ℝ) {k : ℕ} (t : Fin k → ℝ) (f : Fin k → Fin (2*d)) (hk : Even k) :
    Interacting.weylNumerator (hamiltonian d x j) β t (x ∘ f) =
      Interacting.weylNumerator (Majorana.hamiltonian d j) β t (Majorana.chiFin d ∘ f) := by
  unfold Interacting.weylNumerator Interacting.signedAverage
  congr 1
  apply Finset.sum_congr rfl
  intro σ _
  congr 1
  exact timeProduct_trace_eq d x hx hcard j β (t ∘ σ) (f ∘ σ) hk

/-- Literal finite flavor average using the supplied CAR matrices. -/
def collectiveNumerator (d : ℕ) (x : Fin (2*d) → Matrix ν ν ℂ)
    (β : ℝ) (j : Majorana.FourSet d → ℝ) {k : ℕ} (p : Fin k → ℝ × ℝ) : ℂ :=
  (((2*d : ℕ) : ℂ)^k)⁻¹ * ∑ f : Fin k → Fin (2*d),
    Interacting.weylNumerator (hamiltonian d x j) β (Interacting.pairTimes p)
      (fun i => x (Interacting.pairFlavors f i))

/-- Exact pointwise equality of the actual collective numerators before any
Gaussian averaging or partition normalization. -/
theorem collectiveNumerator_eq (d : ℕ) (x : Fin (2*d) → Matrix ν ν ℂ)
    (hx : ∀ i j, x i*x j+x j*x i = flavorDelta i j • (1:Matrix ν ν ℂ))
    (hcard : Fintype.card ν = 2^d) (β : ℝ) (j : Majorana.FourSet d → ℝ)
    {k : ℕ} (p : Fin k → ℝ × ℝ) :
    collectiveNumerator d x β j p =
      Interacting.collectiveNumerator d (Majorana.hamiltonian d j) β p := by
  unfold collectiveNumerator Interacting.collectiveNumerator
  congr 1
  apply Finset.sum_congr rfl
  intro f _
  exact weylNumerator_eq d x hx hcard j β (Interacting.pairTimes p)
    (Interacting.pairFlavors f) (Even.mul_left (by decide : Even 2) k)

/-- Integrability of generic-representation moments is inherited from the
proved actual Gaussian domination of the identical canonical numerators. -/
theorem collectiveNumerator_integrable (d : ℕ) (x : Fin (2*d) → Matrix ν ν ℂ)
    (hx : ∀ i j, x i*x j+x j*x i = flavorDelta i j • (1:Matrix ν ν ℂ))
    (hcard : Fintype.card ν = 2^d) (β : ℝ) (lam : ℝ≥0)
    {k : ℕ} (p : Fin k → ℝ × ℝ) :
    Integrable (fun j => collectiveNumerator d x β j p) (Microscopic.disorder d lam) := by
  simp only [collectiveNumerator_eq d x hx hcard]
  exact Interacting.collectiveNumerator_integrable d β lam p

/-- The supplied representation's actual annealed collective moment:
ordinary Gaussian-averaged numerator divided by its own ordinary E Z. -/
def collectiveMoment (d : ℕ) (x : Fin (2*d) → Matrix ν ν ℂ)
    (β : ℝ) (lam : ℝ≥0) {k : ℕ} (p : Fin k → ℝ × ℝ) : ℂ :=
  ((∫ j, (partitionFunction d x β j).re ∂Microscopic.disorder d lam : ℝ) : ℂ)⁻¹ *
    ∫ j, collectiveNumerator d x β j p ∂Microscopic.disorder d lam

/-- Actual interacting collective moments are representation independent
at every finite size and every endpoint configuration, including collisions. -/
theorem collectiveMoment_eq (d : ℕ) (x : Fin (2*d) → Matrix ν ν ℂ)
    (hx : ∀ i j, x i*x j+x j*x i = flavorDelta i j • (1:Matrix ν ν ℂ))
    (hcard : Fintype.card ν = 2^d) (β : ℝ) (lam : ℝ≥0)
    {k : ℕ} (p : Fin k → ℝ × ℝ) :
    collectiveMoment d x β lam p = Interacting.collectiveMoment d β lam p := by
  unfold collectiveMoment Interacting.collectiveMoment
  simp only [partitionFunction_eq d x hx hcard, collectiveNumerator_eq d x hx hcard]

/-- The sharp microscopic bound therefore holds for every supplied CAR
family, without a norm bound or selfadjointness hypothesis on that family. -/
theorem collectiveMoment_bound (d : ℕ) (hd : 0 < d)
    (x : Fin (2*d) → Matrix ν ν ℂ)
    (hx : ∀ i j, x i*x j+x j*x i = flavorDelta i j • (1:Matrix ν ν ℂ))
    (hcard : Fintype.card ν = 2^d) {β : ℝ} (hβ : 0 < β) (lam : ℝ≥0)
    {k : ℕ} (p : Fin k → ℝ × ℝ)
    (hp : ∀ i, p i ∈ Set.Icc 0 β ×ˢ Set.Icc 0 β) :
    ‖collectiveMoment d x β lam p‖ ≤ (1/2 : ℝ)^k := by
  rw [collectiveMoment_eq d x hx hcard]
  exact Interacting.collectiveMoment_bound d hd hβ lam p hp
end Matrix

/-- Every actual uniform moment convergence result transfers to arbitrary
sequences of CAR realizations of dimension 2^d. The endpoint domain is left
explicit, so this does not silently change the midpoint seam convention. -/
theorem moment_convergence_transfer {ν : ℕ → Type*}
    [∀ d, Fintype (ν d)] [∀ d, DecidableEq (ν d)]
    (x : ∀ d, Fin (2*d) → Matrix (ν d) (ν d) ℂ)
    (hx : ∀ d i j, x d i*x d j+x d j*x d i = flavorDelta i j • (1:Matrix (ν d) (ν d) ℂ))
    (hcard : ∀ d, Fintype.card (ν d) = 2^d) (β : ℝ) (lam : ℝ≥0)
    {Ω : Type*} {k : ℕ} (p : Ω → Fin k → ℝ × ℝ) (G : Ω → ℂ)
    (hconv : TendstoUniformly (fun d u => Interacting.collectiveMoment d β lam (p u)) G Filter.atTop) :
    TendstoUniformly (fun d u => collectiveMoment d (x d) β lam (p u)) G Filter.atTop := by
  simpa only [collectiveMoment_eq _ _ (hx _) (hcard _)] using hconv

end SYK.MomentRepresentationIndependence
