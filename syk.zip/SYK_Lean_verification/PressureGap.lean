import GaussianConcentration
import PressureJensen
import Mathlib.Analysis.SpecificLimits.Basic

/-!
# Vanishing actual annealed–quenched pressure gap

The exponential concentration estimate is proved by Gaussian rotation in the
imported files, not assumed. Here Jensen, the exact microscopic pressure
normalizations, and the exact variance yield an explicit O(1/N) gap.
-/

set_option maxHeartbeats 800000
noncomputable section
open MeasureTheory ProbabilityTheory Filter
open scoped BigOperators Topology ComplexOrder NNReal
namespace SYK.PressureGap
open Majorana LogPartitionDifferential GaussianConcentration

/-- The reciprocal partition function is genuinely disorder integrable. -/
theorem exp_neg_logPartition_integrable (m : ℕ) (β : ℝ) (lam : ℝ≥0) :
    Integrable (fun j => Real.exp (-logPartition m β j)) (Microscopic.disorder m lam) := by
  have hf : Continuous (logPartition m β) :=
    continuous_iff_continuousAt.mpr (fun j => (differentiableAt_logPartition m β j).continuousAt)
  have h := (GaussianDisorder.integrable_exp_sum_abs (FourSet m) (2 * m) lam (|β| / 4)).const_mul
    (Real.exp ((m : ℝ) * Real.log 2))
  apply h.mono' (Real.continuous_exp.comp hf.neg).aestronglyMeasurable
  filter_upwards [] with j
  simp only [Function.comp_def]
  rw [Real.norm_eq_abs, abs_of_pos (Real.exp_pos _), ← Real.exp_add]
  apply Real.exp_le_exp.mpr
  have hb := Gibbs.abs_log_syk_partition_le m β j
  have hneg := neg_le_abs (logPartition m β j)
  change -logPartition m β j ≤ (m : ℝ) * Real.log 2 + |β| / 4 * (∑ I, |j I|)
  change |logPartition m β j| ≤ _ at hb
  nlinarith

/-- The actual exponential two-copy moment factors into Z and reciprocal Z. -/
theorem exponential_difference_factorization (m : ℕ) (β : ℝ) (lam : ℝ≥0) :
    (∫ p : (FourSet m → ℝ) × (FourSet m → ℝ),
      Real.exp (logPartition m β p.2 - logPartition m β p.1)
        ∂(Microscopic.disorder m lam).prod (Microscopic.disorder m lam)) =
      (∫ j, Real.exp (-logPartition m β j) ∂Microscopic.disorder m lam) *
      (∫ j, (partitionFunction m β j).re ∂Microscopic.disorder m lam) := by
  have he (p : (FourSet m → ℝ) × (FourSet m → ℝ)) :
      Real.exp (logPartition m β p.2 - logPartition m β p.1) =
      Real.exp (-logPartition m β p.1) * (partitionFunction m β p.2).re := by
    rw [sub_eq_add_neg, Real.exp_add, logPartition, Real.exp_log (Gibbs.syk_partition_re_pos m β p.2)]
    ring
  simp_rw [he]
  exact integral_prod_mul (μ := Microscopic.disorder m lam) (ν := Microscopic.disorder m lam)
    (fun j => Real.exp (-logPartition m β j)) (fun j => (partitionFunction m β j).re)

/-- A pressure-gap bound directly from the exact finite-N Gaussian law. -/
theorem annealed_sub_quenched_le_variance_bound (m : ℕ) (β : ℝ) (lam : ℝ≥0) :
    Microscopic.annealedPressure m β lam - Microscopic.quenchedPressure m β lam ≤
      ((GaussianDisorder.variance (2 * m) lam : ℝ) * (Real.pi / 2)^2 * squaredBound m β / 2) /
        (2 * m) := by
  let a := ∫ j, (partitionFunction m β j).re ∂Microscopic.disorder m lam
  let q := ∫ j, logPartition m β j ∂Microscopic.disorder m lam
  let b := ∫ j, Real.exp (-logPartition m β j) ∂Microscopic.disorder m lam
  have ha : 0 < a := Microscopic.annealed_partition_pos m β lam
  have hf : Integrable (logPartition m β) (Microscopic.disorder m lam) :=
    Microscopic.log_partitionFunction_integrable m β lam
  have hn := exp_neg_logPartition_integrable m β lam
  have hJ := convexOn_exp.map_integral_le Real.continuous_exp.continuousOn
    isClosed_univ (ae_of_all (Microscopic.disorder m lam) (fun _ => Set.mem_univ _)) hf.neg hn
  have hJ' : Real.exp (-q) ≤ b := by simpa only [Pi.neg_apply, integral_neg] using hJ
  have hC := integral_exp_logPartition_difference_le m β (GaussianDisorder.variance (2 * m) lam)
  change (∫ p : (FourSet m → ℝ) × (FourSet m → ℝ),
      Real.exp (logPartition m β p.2 - logPartition m β p.1)
        ∂(Microscopic.disorder m lam).prod (Microscopic.disorder m lam)) ≤ _ at hC
  rw [exponential_difference_factorization] at hC
  have hprod := (mul_le_mul_of_nonneg_right hJ' ha.le).trans hC
  have hexp : Real.exp (Real.log a - q) ≤
      Real.exp ((GaussianDisorder.variance (2 * m) lam : ℝ) *
        (Real.pi / 2)^2 * squaredBound m β / 2) := by
    simpa only [sub_eq_add_neg, Real.exp_add, Real.exp_log ha, mul_comm, momentBound] using hprod
  have hgap := Real.exp_le_exp.mp hexp
  have hdiv := div_le_div_of_nonneg_right hgap (show (0 : ℝ) ≤ 2 * m by positivity)
  unfold Microscopic.annealedPressure Microscopic.quenchedPressure
    GaussianDisorder.annealedPressure GaussianDisorder.quenchedPressure
  simp only [Nat.cast_mul, Nat.cast_ofNat]
  rw [← sub_div]
  exact hdiv

/-- A fully concrete O(1/N) annealed–quenched comparison. The numerical constant
is deliberately nonsharp; its N-independence follows from anticommutation. -/
theorem annealed_sub_quenched_le (m : ℕ) (hm : 0 < m) (β : ℝ) (lam : ℝ≥0) :
    Microscopic.annealedPressure m β lam - Microscopic.quenchedPressure m β lam ≤
      3 * Real.pi^2 * β^2 * (lam : ℝ) / (128 * m) := by
  refine (annealed_sub_quenched_le_variance_bound m β lam).trans_eq ?_
  have hm' : (m : ℝ) ≠ 0 := Nat.cast_ne_zero.mpr (Nat.ne_of_gt hm)
  simp only [GaussianDisorder.variance, NNReal.coe_div, NNReal.coe_mul,
    NNReal.coe_pow, NNReal.coe_natCast, NNReal.coe_ofNat, Nat.cast_mul, Nat.cast_ofNat,
    squaredBound]
  field_simp [hm']
  ring

/-- The actual microscopic pressure gap tends to zero for every fixed real
inverse temperature and nonnegative coupling variance. -/
theorem tendsto_annealed_sub_quenched_zero (β : ℝ) (lam : ℝ≥0) :
    Tendsto (fun m : ℕ => Microscopic.annealedPressure m β lam -
      Microscopic.quenchedPressure m β lam) atTop (𝓝 0) := by
  apply squeeze_zero'
    (Eventually.of_forall (fun m => sub_nonneg.mpr
      (Microscopic.quenchedPressure_le_annealedPressure m β lam)))
    (Filter.eventually_atTop.mpr ⟨1, fun m hm => annealed_sub_quenched_le m (by omega) β lam⟩)
  have h := tendsto_const_div_atTop_nhds_zero_nat
    (3 * Real.pi^2 * β^2 * (lam : ℝ) / 128)
  convert h using 1
  funext m
  ring


/-- Any proved actual annealed thermodynamic limit is also the quenched limit.
The input is an annealed limit, while the vanishing comparison gap is proved
above from the concrete model. -/
theorem quenched_limit_of_annealed_limit (β : ℝ) (lam : ℝ≥0) (p : ℝ)
    (ha : Tendsto (fun m : ℕ => Microscopic.annealedPressure m β lam) atTop (𝓝 p)) :
    Tendsto (fun m : ℕ => Microscopic.quenchedPressure m β lam) atTop (𝓝 p) := by
  have h := ha.sub (tendsto_annealed_sub_quenched_zero β lam)
  simpa only [sub_zero, sub_sub_cancel] using h

end SYK.PressureGap

