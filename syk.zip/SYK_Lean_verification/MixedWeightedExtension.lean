import InsertedWardReplacements
import Mathlib.Data.Finsupp.Multiset

noncomputable section
open scoped BigOperators
namespace SYK.MixedIncrement
open WeightedKernelAlgebra MvPolynomial

def substituteGenerator (β : ℝ) : KernelIndex → Polynomial
  | .inl p => X p
  | .inr pq => increment β pq.val

def substitutePolynomial (β : ℝ) : MvPolynomial KernelIndex ℂ →ₐ[ℂ] Polynomial :=
  aeval (substituteGenerator β)

def coordinatePart : List KernelIndex → List Endpoint
  | [] => []
  | .inl p :: l => p :: coordinatePart l
  | .inr _ :: l => coordinatePart l

def incrementPart : List KernelIndex → List (Endpoint × Endpoint)
  | [] => []
  | .inl _ :: l => incrementPart l
  | .inr pq :: l => pq.val :: incrementPart l

theorem substituted_list_split (β : ℝ) (l : List KernelIndex) :
    (l.map (substituteGenerator β)).prod =
      coordinateProduct (coordinatePart l)*incrementProduct β (incrementPart l) := by
  induction l with
  | nil => simp [coordinatePart,incrementPart]
  | cons a l ih =>
    cases a with
    | inl p => simp [coordinatePart,incrementPart,substituteGenerator,ih,mul_assoc]
    | inr pq => simp [coordinatePart,incrementPart,substituteGenerator,ih]; ring

theorem list_weights_split (b K : ℝ) (hb : 0 < b) (hK : 0 < K) (l : List KernelIndex) :
    (l.map (kernelWeights b K hb hK).value).prod =
      b^(coordinatePart l).length *
        ((incrementPart l).map (fun pq => K*endpointDistance pq.1 pq.2)).prod := by
  induction l with
  | nil => simp [coordinatePart,incrementPart]
  | cons a l ih =>
    cases a with
    | inl p =>
      simp only [List.map_cons,List.prod_cons,coordinatePart,incrementPart,List.length_cons]
      rw [ih]
      change b*(b^(coordinatePart l).length * _) = _
      rw [pow_succ]
      ring
    | inr pq =>
      simp only [List.map_cons,List.prod_cons,coordinatePart,incrementPart]
      rw [ih]
      change (K*endpointDistance pq.val.1 pq.val.2)*(b^(coordinatePart l).length * _) = _
      ring

theorem distance_product_mono (q : List (Endpoint × Endpoint)) (K D : ℝ)
    (hK : 0 ≤ K) (hKD : K ≤ D) :
    (q.map (fun pq => K*endpointDistance pq.1 pq.2)).prod ≤
      (q.map (fun pq => D*endpointDistance pq.1 pq.2)).prod := by
  have hn (l : List (Endpoint × Endpoint)) (E : ℝ) (hE : 0 ≤ E) :
      0 ≤ (l.map (fun pq => E*endpointDistance pq.1 pq.2)).prod := by
    induction l with
    | nil => simp
    | cons p l ih =>
      simp only [List.map_cons,List.prod_cons]
      exact mul_nonneg (mul_nonneg hE (add_nonneg (abs_nonneg _) (abs_nonneg _))) ih
  induction q with
  | nil => simp
  | cons p q ih =>
    simp only [List.map_cons,List.prod_cons]
    exact mul_le_mul
      (mul_le_mul_of_nonneg_right hKD (add_nonneg (abs_nonneg _) (abs_nonneg _))) ih
      (hn q K hK) (mul_nonneg (hK.trans hKD) (add_nonneg (abs_nonneg _) (abs_nonneg _)))

/-- A single bound for every word in both coordinate and increment generators. -/
theorem mixed_kernel_list_bound (β lam b K : ℝ) (hβ : 0 < β) (hlam : 0 ≤ lam)
    (hb : 0 < b) (hK : 0 < K) (hKlarge : lam*β*b^4 ≤ K)
    (L : Polynomial →ₗ[ℂ] ℂ) (hrep : ReplacementIdentity β lam L)
    (hplain : ∀ p : List Endpoint, ‖L (coordinateProduct p)‖ ≤ b^p.length)
    (l : List KernelIndex) :
    ‖L ((l.map (substituteGenerator β)).prod)‖ ≤
      (l.map (kernelWeights b K hb hK).value).prod := by
  rw [substituted_list_split,list_weights_split]
  exact (mixed_product_bound β lam b hβ hlam hb.le L hrep hplain _ _).trans
    (mul_le_mul_of_nonneg_left (distance_product_mono _ _ _ (by positivity) hKlarge)
      (pow_nonneg hb.le _))

/-- Multiset enumeration computes every multiplicative monomial weight exactly. -/
theorem list_product_multiplicities {ι A : Type*} [CommMonoid A]
    (e : ι →₀ ℕ) (f : ι → A) :
    (e.toMultiset.toList.map f).prod = e.prod (fun i n => (f i)^n) := by
  classical
  rw [← Multiset.prod_coe, ← Multiset.map_coe, Multiset.coe_toList]
  induction e using Finsupp.induction with
  | zero => simp
  | @single_add a n e ha hn ih =>
    rw [Finsupp.toMultiset_add, Multiset.map_add, Multiset.prod_add, ih,
      Finsupp.toMultiset_single, ← Multiset.coe_mapAddMonoidHom,
      (Multiset.mapAddMonoidHom _).map_nsmul, Multiset.prod_nsmul,
      Finsupp.prod_add_index' (fun _ => pow_zero _) (fun _ => pow_add _)]
    simp

/-- The formal increment substitution has the proved weighted monomial bound,
so the existing completion construction applies to this concrete functional. -/
theorem substituted_monomial_bound (β lam b K : ℝ) (hβ : 0 < β) (hlam : 0 ≤ lam)
    (hb : 0 < b) (hK : 0 < K) (hKlarge : lam*β*b^4 ≤ K)
    (L : Polynomial →ₗ[ℂ] ℂ) (hrep : ReplacementIdentity β lam L)
    (hplain : ∀ p : List Endpoint, ‖L (coordinateProduct p)‖ ≤ b^p.length)
    (e : KernelIndex →₀ ℕ) :
    ‖L (substitutePolynomial β (monomial e 1))‖ ≤
      monomialWeight (kernelWeights b K hb hK).value e := by
  have he : substitutePolynomial β (monomial e 1) =
      (e.toMultiset.toList.map (substituteGenerator β)).prod := by
    rw [list_product_multiplicities, monomial_eq, map_one, one_mul]
    simp only [Finsupp.prod, map_prod, map_pow, substitutePolynomial, aeval_X]
  rw [he]
  convert mixed_kernel_list_bound β lam b K hβ hlam hb hK hKlarge L hrep hplain
    e.toMultiset.toList using 1
  exact (list_product_multiplicities e (kernelWeights b K hb hK).value).symm

@[simp] theorem substitutePolynomial_coordinate (β : ℝ) (p : Endpoint) :
    substitutePolynomial β (X (.inl p)) = X p := by
  simp [substitutePolynomial, substituteGenerator]

@[simp] theorem substitutePolynomial_increment (β : ℝ) (pq : IncrementIndex) :
    substitutePolynomial β (X (.inr pq)) = increment β pq.val := by
  simp [substitutePolynomial, substituteGenerator]

/-- Formal increment relations vanish under the literal G−C substitution. -/
theorem substituted_increment_relation {J : Type*} (β : ℝ)
    (extra : J → MvPolynomial KernelIndex ℂ) (pq : IncrementIndex) :
    substitutePolynomial β (kernelRelations
      (fun p => (Thermal.kernel β p.1 p.2:ℂ)) extra (.inl pq)) = 0 := by
  simp only [kernelRelations, map_sub, map_add, substitutePolynomial_increment,
    substitutePolynomial_coordinate]
  simp only [substitutePolynomial, aeval_C, MvPolynomial.algebraMap_eq, increment, remainder]
  ring

/-- Moment assignment on mixed monomials, obtained from the actual limiting
coordinate functional rather than introduced as a new abstract state. -/
def substitutedMoment (β : ℝ) (L : Polynomial →ₗ[ℂ] ℂ) (e : KernelIndex →₀ ℕ) : ℂ :=
  L (substitutePolynomial β (monomial e 1))

theorem substitutedMoment_zero (β : ℝ) (L : Polynomial →ₗ[ℂ] ℂ) (hL : L 1=1) :
    substitutedMoment β L 0 = 1 := by
  simpa [substitutedMoment] using hL

/-- The weighted polynomial functional is exactly the substitution of the
limiting coordinate functional, on every polynomial. -/
theorem momentLinear_substitution (β : ℝ) (L : Polynomial →ₗ[ℂ] ℂ)
    (w : Weights KernelIndex) (P : MvPolynomial KernelIndex ℂ) :
    WeightedPolynomial.momentLinear w (substitutedMoment β L)
      (WeightedPolynomial.ofPolynomial w P) = L (substitutePolynomial β P) := by
  induction P using MvPolynomial.induction_on' with
  | add P Q hP hQ =>
      change WeightedPolynomial.momentLinear w (substitutedMoment β L)
        (WeightedPolynomial.ofPolynomial w P + WeightedPolynomial.ofPolynomial w Q) = _
      rw [map_add,hP,hQ,map_add,map_add]
  | monomial e c =>
      change Finsupp.linearCombination ℂ (substitutedMoment β L) (Finsupp.single e c) = _
      rw [Finsupp.linearCombination_single]
      have he : monomial e c = c • monomial e (1:ℂ) := by simp [smul_monomial]
      rw [he, map_smul, map_smul]
      rfl

end SYK.MixedIncrement
