import InteractingMoments

/-! # Endpoint measurability of the actual microscopic moments

Finite-N continuity at collisions is not asserted. The finite sorting
indicators are Borel measurable, and so are the actual Gaussian-integrated
collective moments.
-/
noncomputable section
open scoped BigOperators NNReal
open MeasureTheory

namespace SYK.MomentMeasurability
open Interacting

local instance (d : ℕ) : SecondCountableTopology (Matrix (Majorana.Basis d) (Majorana.Basis d) ℂ) :=
  inferInstanceAs (SecondCountableTopology (Majorana.Basis d → Majorana.Basis d → ℂ))
local instance (d : ℕ) : MeasurableSpace (Matrix (Majorana.Basis d) (Majorana.Basis d) ℂ) := borel _
local instance (d : ℕ) : BorelSpace (Matrix (Majorana.Basis d) (Majorana.Basis d) ℂ) := ⟨rfl⟩

/-- Actual transfer products are jointly measurable in Hamiltonian, boundary,
all times, and all insertion matrices. -/
theorem measurable_timeProduct {X : Type*} [MeasurableSpace X] (d : ℕ) {k : ℕ}
    (H : X → Matrix (Majorana.Basis d) (Majorana.Basis d) ℂ) (a : X → ℝ)
    (t : X → Fin k → ℝ) (A : X → Fin k → Matrix (Majorana.Basis d) (Majorana.Basis d) ℂ)
    (hH : Measurable H) (ha : Measurable a) (ht : ∀ i, Measurable (fun x => t x i))
    (hA : ∀ i, Measurable (fun x => A x i)) :
    Measurable (fun x => timeProduct (H x) (a x) (t x) (A x)) := by
  induction k generalizing a with
  | zero =>
    simp only [timeProduct_zero, Gibbs.weight]
    exact (ThermalRP.continuous_matrix_exp d).measurable.comp (ha.neg.smul hH)
  | succ k ih =>
    simp only [timeProduct_succ, Gibbs.weight]
    apply Measurable.mul
    · exact (ThermalRP.continuous_matrix_exp d).measurable.comp ((ha.sub (ht 0)).neg.smul hH)
    · exact (hA 0).mul (ih (fun x => t x 0) (fun x i => t x i.succ)
        (fun x i => A x i.succ) (ht 0) (fun i => ht i.succ) (fun i => hA i.succ))

/-- Every sorting condition is a finite family of Borel inequalities. -/
theorem measurableSet_antitone {X : Type*} [MeasurableSpace X] {k : ℕ}
    (t : X → Fin k → ℝ) (ht : ∀ i, Measurable (fun x => t x i)) :
    MeasurableSet {x | Antitone (t x)} := by
  simp only [Antitone, Set.setOf_forall]
  apply MeasurableSet.iInter
  intro i
  apply MeasurableSet.iInter
  intro j
  apply MeasurableSet.iInter
  intro hij
  exact measurableSet_le (ht j) (ht i)

/-- The exact number of time-sorting permutations is a measurable function. -/
theorem measurable_sorting_count {X : Type*} [MeasurableSpace X] {k : ℕ}
    (t : X → Fin k → ℝ) (ht : ∀ i, Measurable (fun x => t x i)) :
    Measurable (fun x => ((sortingPerms (t x)).card : ℂ)) := by
  classical
  simp only [sortingPerms, ← Finset.sum_boole]
  apply Finset.measurable_sum
  intro σ _
  apply Measurable.ite _ measurable_const measurable_const
  exact measurableSet_antitone (fun x => t x ∘ σ) (fun i => ht (σ i))

/-- The complete all-collision Weyl numerator is jointly measurable. -/
theorem measurable_weylNumerator {X : Type*} [MeasurableSpace X] (d : ℕ) {k : ℕ}
    (H : X → Matrix (Majorana.Basis d) (Majorana.Basis d) ℂ) (a : X → ℝ)
    (t : X → Fin k → ℝ) (A : X → Fin k → Matrix (Majorana.Basis d) (Majorana.Basis d) ℂ)
    (hH : Measurable H) (ha : Measurable a) (ht : ∀ i, Measurable (fun x => t x i))
    (hA : ∀ i, Measurable (fun x => A x i)) :
    Measurable (fun x => weylNumerator (H x) (a x) (t x) (A x)) := by
  classical
  unfold weylNumerator signedAverage
  apply Measurable.mul (measurable_sorting_count t ht).inv
  simp only [sortingPerms, Finset.sum_filter]
  apply Finset.measurable_sum
  intro σ _
  apply Measurable.ite (measurableSet_antitone (fun x => t x ∘ σ) (fun i => ht (σ i))) _ measurable_const
  have hprod := measurable_timeProduct d H a (fun x => t x ∘ σ) (fun x => A x ∘ σ)
    hH ha (fun i => ht (σ i)) (fun i => hA (σ i))
  have htrace : Measurable (fun x => Matrix.trace (timeProduct (H x) (a x) (t x ∘ σ) (A x ∘ σ))) :=
    (continuous_id.matrix_trace).measurable.comp hprod
  rcases Int.units_eq_one_or (Equiv.Perm.sign σ) with h | h
  · simpa only [h, one_smul] using htrace
  · simpa only [h, Units.smul_def, Units.val_neg, Units.val_one, neg_one_zsmul, Pi.neg_apply]
      using htrace.neg

/-- The exact collective numerator is jointly measurable in endpoints and couplings. -/
theorem measurable_collectiveNumerator (d : ℕ) (β : ℝ) (m : ℕ) :
    Measurable (fun x : (Fin m → ℝ × ℝ) × (Majorana.FourSet d → ℝ) =>
      collectiveNumerator d (Majorana.hamiltonian d x.2) β x.1) := by
  unfold collectiveNumerator
  apply Measurable.const_mul
  apply Finset.measurable_sum
  intro f _
  apply measurable_weylNumerator d
  · exact (Majorana.continuous_hamiltonian d).measurable.comp measurable_snd
  · exact measurable_const
  · intro i
    unfold pairTimes
    split_ifs
    · exact measurable_fst.comp ((measurable_pi_apply i.divNat).comp measurable_fst)
    · exact measurable_snd.comp ((measurable_pi_apply i.divNat).comp measurable_fst)
  · intro i; exact measurable_const

/-- Gaussian integration preserves actual endpoint measurability, without
assuming finite-N continuity at collision surfaces. -/
theorem measurable_collectiveMoment (d : ℕ) (β : ℝ) (lam : ℝ≥0) (m : ℕ) :
    Measurable (fun p : Fin m → ℝ × ℝ => collectiveMoment d β lam p) := by
  unfold collectiveMoment
  apply Measurable.const_mul
  exact (measurable_collectiveNumerator d β m).stronglyMeasurable.integral_prod_right.measurable

end SYK.MomentMeasurability
