import FreeWickTrace
import FinalModelConventions

/-!
# Representation independence of the actual microscopic pressure

Normalized even word traces are determined by CAR and cyclicity alone. This
file derives equality of Hamiltonian power traces and ordinary exponential
traces for any CAR family in dimension 2^d. No unitary equivalence or
irreducibility conclusion is assumed.
-/
noncomputable section
open scoped BigOperators NNReal ComplexOrder
open MeasureTheory
namespace SYK.RepresentationIndependence
open FreeWick

section Algebra
variable {ι A B : Type*} [Ring A] [Algebra ℂ A] [Ring B] [Algebra ℂ B]

theorem even_word_trace_eq (x : ι → A) (y : ι → B) (c : ι → ι → ℂ)
    (hx : ∀ a b, x a*x b+x b*x a = c a b • (1:A))
    (hy : ∀ a b, y a*y b+y b*y a = c a b • (1:B))
    (τ : A →ₗ[ℂ] ℂ) (σ : B →ₗ[ℂ] ℂ)
    (hτ : ∀ u v, τ (u*v) = τ (v*u)) (hσ : ∀ u v, σ (u*v) = σ (v*u))
    (hunit : τ 1 = σ 1) (L : List ι) (hL : Even L.length) :
    τ (word x L) = σ (word y L) := by
  have main : ∀ k : ℕ, ∀ L : List ι, L.length = k → Even L.length →
      τ (word x L) = σ (word y L) := by
    intro k
    induction k using Nat.strong_induction_on with
    | h k ih =>
      intro L hlen heven
      cases L with
      | nil => simpa using hunit
      | cons a L =>
        have hodd : Odd L.length := by
          simpa only [List.length_cons, Nat.even_add_one, Nat.not_even_iff_odd] using heven
        rw [cyclic_wick_recursion x c hx τ hτ a L hodd,
          cyclic_wick_recursion y c hy σ hσ a L hodd]
        congr 1
        apply congrArg List.sum
        apply List.map_congr_left
        intro t ht
        congr 1
        have hshort := contractionTerms_length c a L t ht
        apply ih t.2.length (by simp only [List.length_cons] at hlen; omega) t.2 rfl
        rw [Nat.even_iff]
        have hp := Nat.odd_iff.mp hodd
        omega
  exact main L.length L rfl hL

/-- A finite even-word Hamiltonian with literal scalar coefficients. -/
def evenHamiltonian {κ : Type*} [Fintype κ] (x : ι → A)
    (w : κ → List ι) (a : κ → ℂ) : A := ∑ i, a i • word x (w i)

theorem evenHamiltonian_pow_word_trace_eq {κ : Type*} [Fintype κ]
    (x : ι → A) (y : ι → B) (w : κ → List ι) (a : κ → ℂ)
    (hw : ∀ i, Even (w i).length)
    (τ : A →ₗ[ℂ] ℂ) (σ : B →ₗ[ℂ] ℂ)
    (he : ∀ L, Even L.length → τ (word x L) = σ (word y L))
    (n : ℕ) (L : List ι) (hL : Even L.length) :
    τ ((evenHamiltonian x w a)^n * word x L) =
      σ ((evenHamiltonian y w a)^n * word y L) := by
  induction n generalizing L with
  | zero => simpa using he L hL
  | succ n ih =>
    simp only [pow_succ, evenHamiltonian, Finset.mul_sum, Finset.sum_mul,
      mul_smul_comm, smul_mul_assoc, map_sum, map_smul]
    apply Finset.sum_congr rfl
    intro i _
    congr 1
    simpa only [word_append, mul_assoc] using ih ((w i)++L)
      (by simpa using (hw i).add hL)
end Algebra

section Matrix
variable {κ : Type*} [Fintype κ] [DecidableEq κ]

def quarticWord (d : ℕ) (I : Majorana.FourSet d) : List (Fin (2*d)) :=
  [Majorana.fourIndex d I 0, Majorana.fourIndex d I 1,
   Majorana.fourIndex d I 2, Majorana.fourIndex d I 3]

@[simp] theorem quarticWord_even (d : ℕ) (I : Majorana.FourSet d) :
    Even (quarticWord d I).length := by exact ⟨2,rfl⟩

/-- The same ordered quartic Hamiltonian for an arbitrary matrix CAR family. -/
def hamiltonian (d : ℕ) (x : Fin (2*d) → Matrix κ κ ℂ)
    (j : Majorana.FourSet d → ℝ) : Matrix κ κ ℂ :=
  -∑ I, j I • word x (quarticWord d I)

/-- Literal ordinary trace of the exponential, for the supplied family. -/
def partitionFunction (d : ℕ) (x : Fin (2*d) → Matrix κ κ ℂ)
    (β : ℝ) (j : Majorana.FourSet d → ℝ) : ℂ :=
  Matrix.trace (NormedSpace.exp ℂ ((-β) • hamiltonian d x j))

theorem hamiltonian_canonical (d : ℕ) (j : Majorana.FourSet d → ℝ) :
    hamiltonian d (Majorana.chiFin d) j = Majorana.hamiltonian d j := by
  simp only [hamiltonian, Majorana.hamiltonian, quarticWord, word_cons, word_nil,
    mul_one, Majorana.quartic, mul_assoc]

theorem boltzmann_eq_evenHamiltonian (d : ℕ) (x : Fin (2*d) → Matrix κ κ ℂ)
    (β : ℝ) (j : Majorana.FourSet d → ℝ) :
    (-β) • hamiltonian d x j =
      evenHamiltonian x (quarticWord d) (fun I => (β * j I : ℝ)) := by
  simp only [hamiltonian, evenHamiltonian, smul_neg, Finset.smul_sum, smul_smul,
    neg_mul, neg_smul, Finset.sum_neg_distrib, neg_neg]
  apply Finset.sum_congr rfl
  intro I _
  exact (Complex.coe_smul (β*j I) _).symm

theorem trace_power_eq (d : ℕ) (x : Fin (2*d) → Matrix κ κ ℂ)
    (hx : ∀ i j, x i*x j+x j*x i = flavorDelta i j • (1:Matrix κ κ ℂ))
    (hcard : Fintype.card κ = 2^d) (β : ℝ) (j : Majorana.FourSet d → ℝ) (n : ℕ) :
    Matrix.trace (((-β) • hamiltonian d x j)^n) =
      Matrix.trace (((-β) • Majorana.hamiltonian d j)^n) := by
  let τ := Matrix.traceLinearMap κ ℂ ℂ
  let σ := Matrix.traceLinearMap (Majorana.Basis d) ℂ ℂ
  have hy : ∀ i j, Majorana.chiFin d i * Majorana.chiFin d j +
      Majorana.chiFin d j * Majorana.chiFin d i = flavorDelta i j •
        (1:Matrix (Majorana.Basis d) (Majorana.Basis d) ℂ) := by
    intro i j
    rw [Majorana.chiFin_car]
    by_cases h : i=j <;> simp [flavorDelta,h]
  have he := even_word_trace_eq x (Majorana.chiFin d) flavorDelta hx hy τ σ
    (fun u v => Matrix.trace_mul_comm u v) (fun u v => Matrix.trace_mul_comm u v)
    (by simp [τ,σ,Matrix.trace_one,hcard])
  have h := evenHamiltonian_pow_word_trace_eq x (Majorana.chiFin d) (quarticWord d)
    (fun I => (β*j I : ℝ)) (quarticWord_even d) τ σ he n [] (by simp)
  simpa only [word_nil,mul_one,← boltzmann_eq_evenHamiltonian,hamiltonian_canonical] using h

theorem partitionFunction_eq (d : ℕ) (x : Fin (2*d) → Matrix κ κ ℂ)
    (hx : ∀ i j, x i*x j+x j*x i = flavorDelta i j • (1:Matrix κ κ ℂ))
    (hcard : Fintype.card κ = 2^d) (β : ℝ) (j : Majorana.FourSet d → ℝ) :
    partitionFunction d x β j = Majorana.partitionFunction d β j := by
  let τ : CStarMatrix κ κ ℂ →L[ℂ] ℂ :=
    (Matrix.traceLinearMap κ ℂ ℂ).toContinuousLinearMap.comp
      CStarMatrix.ofMatrixL.symm.toContinuousLinearMap
  let σ : CStarMatrix (Majorana.Basis d) (Majorana.Basis d) ℂ →L[ℂ] ℂ :=
    (Matrix.traceLinearMap (Majorana.Basis d) ℂ ℂ).toContinuousLinearMap.comp
      CStarMatrix.ofMatrixL.symm.toContinuousLinearMap
  have ha := (NormedSpace.exp_series_hasSum_exp' (𝕂:=ℂ)
    (CStarMatrix.ofMatrix ((-β) • hamiltonian d x j))).mapL τ
  have hb := (NormedSpace.exp_series_hasSum_exp' (𝕂:=ℂ)
    (CStarMatrix.ofMatrix ((-β) • Majorana.hamiltonian d j))).mapL σ
  have he : (fun n : ℕ => τ ((n.factorial:ℂ)⁻¹ • ((CStarMatrix.ofMatrix ((-β) • hamiltonian d x j))^n))) =
      (fun n : ℕ => σ ((n.factorial:ℂ)⁻¹ • ((CStarMatrix.ofMatrix ((-β) • Majorana.hamiltonian d j))^n))) := by
    funext n
    simp only [map_smul]
    congr 1
    exact trace_power_eq d x hx hcard β j n
  rw [he] at ha
  exact ha.unique hb
/-- Actual annealed disorder pressure for the supplied CAR representation. -/
def annealedPressure (d : ℕ) (x : Fin (2*d) → Matrix κ κ ℂ)
    (β : ℝ) (lam : ℝ≥0) : ℝ :=
  GaussianDisorder.annealedPressure (Majorana.FourSet d) (2*d) lam
    (fun j => (partitionFunction d x β j).re)

/-- Actual quenched disorder pressure for the supplied CAR representation. -/
def quenchedPressure (d : ℕ) (x : Fin (2*d) → Matrix κ κ ℂ)
    (β : ℝ) (lam : ℝ≥0) : ℝ :=
  GaussianDisorder.quenchedPressure (Majorana.FourSet d) (2*d) lam
    (fun j => (partitionFunction d x β j).re)

theorem annealedPressure_eq (d : ℕ) (x : Fin (2*d) → Matrix κ κ ℂ)
    (hx : ∀ i j, x i*x j+x j*x i = flavorDelta i j • (1:Matrix κ κ ℂ))
    (hcard : Fintype.card κ = 2^d) (β : ℝ) (lam : ℝ≥0) :
    annealedPressure d x β lam = Microscopic.annealedPressure d β lam := by
  unfold annealedPressure Microscopic.annealedPressure
  simp only [partitionFunction_eq d x hx hcard]

theorem quenchedPressure_eq (d : ℕ) (x : Fin (2*d) → Matrix κ κ ℂ)
    (hx : ∀ i j, x i*x j+x j*x i = flavorDelta i j • (1:Matrix κ κ ℂ))
    (hcard : Fintype.card κ = 2^d) (β : ℝ) (lam : ℝ≥0) :
    quenchedPressure d x β lam = Microscopic.quenchedPressure d β lam := by
  unfold quenchedPressure Microscopic.quenchedPressure
  simp only [partitionFunction_eq d x hx hcard]
end Matrix

/-- The same continuum pressure limit holds for every sequence of actual CAR
representations of dimension 2^d. Even selfadjointness and irreducibility are
unnecessary for this trace identity, so in particular all manuscript families
are covered without a representation-equivalence assumption. -/
theorem pressure_convergence_transfer {κ : ℕ → Type*}
    [∀ d, Fintype (κ d)] [∀ d, DecidableEq (κ d)]
    (x : ∀ d, Fin (2*d) → Matrix (κ d) (κ d) ℂ)
    (hx : ∀ d i j, x d i*x d j+x d j*x d i = flavorDelta i j • (1:Matrix (κ d) (κ d) ℂ))
    (hcard : ∀ d, Fintype.card (κ d) = 2^d) (β : ℝ) (lam : ℝ≥0) (p : ℝ)
    (hp : Continuum.PressureConvergence β lam p) :
    Filter.Tendsto (fun d => annealedPressure d (x d) β lam) Filter.atTop (nhds p) ∧
      Filter.Tendsto (fun d => quenchedPressure d (x d) β lam) Filter.atTop (nhds p) := by
  simp only [annealedPressure_eq _ _ (hx _) (hcard _),
    quenchedPressure_eq _ _ (hx _) (hcard _)]
  exact hp

end SYK.RepresentationIndependence
