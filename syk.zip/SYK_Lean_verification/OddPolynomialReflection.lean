import OddWeylReflection
import PolynomialReflectionPositivity

/-! # Inserted odd positivity of actual collective polynomials

An extra shared Majorana flavor is summed only after constructing the odd
half-history. This identifies the inserted cross-reflection bilocal exactly,
and proves the full finite odd reflection form is positive and real.
-/
noncomputable section
open scoped BigOperators ComplexOrder NNReal
open MeasureTheory
namespace SYK.OddPolynomialRP
open MomentLimit MomentCompactness BilocalReflection PolynomialRP OddWeylReflection

/-- The cross-reflection endpoint pair carried by the two extra odd fields. -/
def crossEndpoint (β : ℝ) (s t : Set.Icc (0:ℝ) β) : EndpointPair β :=
  (⟨β-s.val, by constructor <;> linarith [s.property.1,s.property.2]⟩,t)

/-- The complete collective odd reflection polynomial, with arbitrary
finite half-histories and possibly different degrees. -/
def oddTupleForm {ι : Type*} [Fintype ι] (β : ℝ) (k : ι → ℕ) (c : ι → ℂ)
    (p : ∀ i, EndpointCube β (k i)) (s : ι → Set.Icc (0:ℝ) β) : CoordinatePolynomial β :=
  ∑ i, ∑ j, (star (c i)*c j) •
    ((∏ r, MvPolynomial.X (reflectEndpoint β (p i r))) *
      MvPolynomial.X (crossEndpoint β (s i) (s j)) * (∏ r, MvPolynomial.X (p j r)))

/-- Exact microscopic evaluation of a single odd reflection product. -/
theorem actualPolynomial_odd_product (d : ℕ) (β : ℝ) (lam : ℝ≥0) {m n : ℕ}
    (p : EndpointCube β m) (q : EndpointCube β n) (s t : Set.Icc (0:ℝ) β) :
    actualPolynomial d β lam
      ((∏ r, MvPolynomial.X (reflectEndpoint β (p r))) *
        MvPolynomial.X (crossEndpoint β s t) * (∏ r, MvPolynomial.X (q r))) =
      Interacting.collectiveMoment d β lam
        (Fin.append (fun r => reflectPair β (endpointValues p r.rev))
          (Fin.cons (β-s.val,t.val) (endpointValues q))) := by
  have h := actualPolynomial_reflected_product d β lam p (Fin.cons (crossEndpoint β s t) q)
  simp only [Fin.prod_univ_succ, Fin.cons_zero, Fin.cons_succ] at h
  have hq : endpointValues (Fin.cons (crossEndpoint β s t) q) =
      Fin.cons (β-s.val,t.val) (endpointValues q) := by
    funext i
    refine Fin.cases ?_ (fun _ => ?_) i <;>
      simp only [endpointValues, Fin.cons_zero, Fin.cons_succ, crossEndpoint]
  rw [mul_assoc, h, hq]

/-- The odd reflection polynomial expands into the actual annealed moments. -/
theorem actualPolynomial_odd_form_sum {ι : Type*} [Fintype ι]
    (d : ℕ) (β : ℝ) (lam : ℝ≥0) (k : ι → ℕ) (c : ι → ℂ)
    (p : ∀ i, EndpointCube β (k i)) (s : ι → Set.Icc (0:ℝ) β) :
    actualPolynomial d β lam (oddTupleForm β k c p s) =
      ∑ i, ∑ j, (star (c i)*c j) * Interacting.collectiveMoment d β lam
        (Fin.append (fun r => reflectPair β (endpointValues (p i) r.rev))
          (Fin.cons (β-(s i).val,(s j).val) (endpointValues (p j)))) := by
  simp only [oddTupleForm, map_sum, map_smul, smul_eq_mul, actualPolynomial_odd_product]

/-- The common-flavor average of actual odd matrix star-squares. -/
def oddSquareTrace {ι : Type*} [Fintype ι] (d : ℕ) (β : ℝ)
    (k : ι → ℕ) (c : ι → ℂ) (p : ∀ i, EndpointCube β (k i))
    (s : ι → Set.Icc (0:ℝ) β) (j : Majorana.FourSet d → ℝ) : ℂ :=
  (∑ v : Fin (2*d), Matrix.trace
    (star (oddAmplitude d (Majorana.hamiltonian d j) (β/2) k c
      (fun i => endpointValues (p i)) (fun i => (s i).val) v) *
    oddAmplitude d (Majorana.hamiltonian d j) (β/2) k c
      (fun i => endpointValues (p i)) (fun i => (s i).val) v)) / (((2*d : ℕ):ℝ):ℂ)

theorem oddSquareTrace_eq_sum {ι : Type*} [Fintype ι] (d : ℕ) (β : ℝ)
    (k : ι → ℕ) (c : ι → ℂ) (p : ∀ i, EndpointCube β (k i))
    (s : ι → Set.Icc (0:ℝ) β)
    (hp : ∀ i r, (p i r).1.val<β/2 ∧ (p i r).2.val<β/2)
    (hs : ∀ i, (s i).val<β/2) (j : Majorana.FourSet d → ℝ) :
    oddSquareTrace d β k c p s j =
      ∑ i, ∑ l, (star (c i)*c l) * Interacting.collectiveNumerator d
        (Majorana.hamiltonian d j) β
        (Fin.append (fun r => reflectPair β (endpointValues (p i) r.rev))
          (Fin.cons (β-(s i).val,(s l).val) (endpointValues (p l)))) := by
  have h := odd_numerator_reflected_sum d (Majorana.hamiltonian_star d j)
    (β/2) k c (fun i => endpointValues (p i)) (fun i => (s i).val) hp hs
  rw [show 2*(β/2)=β by ring] at h
  simpa only [oddSquareTrace, Complex.ofReal_natCast, div_eq_mul_inv, mul_comm] using h.symm

/-- Genuine Gaussian integrability of the shared-flavor star-square. -/
theorem oddSquareTrace_integrable {ι : Type*} [Fintype ι] (d : ℕ) (β : ℝ) (lam : ℝ≥0)
    (k : ι → ℕ) (c : ι → ℂ) (p : ∀ i, EndpointCube β (k i))
    (s : ι → Set.Icc (0:ℝ) β)
    (hp : ∀ i r, (p i r).1.val<β/2 ∧ (p i r).2.val<β/2)
    (hs : ∀ i, (s i).val<β/2) :
    Integrable (oddSquareTrace d β k c p s) (Microscopic.disorder d lam) := by
  simp only [funext (oddSquareTrace_eq_sum d β k c p s hp hs)]
  apply integrable_finset_sum
  intro i _
  apply integrable_finset_sum
  intro l _
  exact (Interacting.collectiveNumerator_integrable d β lam _).const_mul _

/-- Exact normalized operator-integral formula for the inserted odd form. -/
theorem actualPolynomial_odd_eq_integral {ι : Type*} [Fintype ι]
    (d : ℕ) (β : ℝ) (lam : ℝ≥0) (k : ι → ℕ) (c : ι → ℂ)
    (p : ∀ i, EndpointCube β (k i)) (s : ι → Set.Icc (0:ℝ) β)
    (hp : ∀ i r, (p i r).1.val<β/2 ∧ (p i r).2.val<β/2)
    (hs : ∀ i, (s i).val<β/2) :
    actualPolynomial d β lam (oddTupleForm β k c p s) =
      (∫ j, oddSquareTrace d β k c p s j ∂Microscopic.disorder d lam) /
        ((∫ j, (Majorana.partitionFunction d β j).re ∂Microscopic.disorder d lam : ℝ):ℂ) := by
  rw [actualPolynomial_odd_form_sum]
  simp only [Interacting.collectiveMoment, div_eq_mul_inv, mul_comm _ (_⁻¹)]
  simp_rw [mul_left_comm (star (c _) * c _)]
  simp only [← Finset.mul_sum]
  congr 1
  simp_rw [oddSquareTrace_eq_sum d β k c p s hp hs]
  rw [integral_finset_sum _ (fun i _ => integrable_finset_sum _
    (fun l _ => (Interacting.collectiveNumerator_integrable d β lam _).const_mul _))]
  apply Finset.sum_congr rfl
  intro i _
  rw [integral_finset_sum _ (fun l _ =>
    (Interacting.collectiveNumerator_integrable d β lam _).const_mul _)]
  simp only [integral_const_mul]

/-- Each fixed-disorder odd form is positive because each summand is an
ordinary matrix trace square, with its actual nonnegative flavor weight. -/
theorem oddSquareTrace_nonnegative {ι : Type*} [Fintype ι] (d : ℕ) (β : ℝ)
    (k : ι → ℕ) (c : ι → ℂ) (p : ∀ i, EndpointCube β (k i))
    (s : ι → Set.Icc (0:ℝ) β) (j : Majorana.FourSet d → ℝ) :
    0 ≤ (oddSquareTrace d β k c p s j).re := by
  unfold oddSquareTrace
  rw [Complex.div_ofReal_re, Complex.re_sum]
  apply div_nonneg _ (Nat.cast_nonneg _)
  apply Finset.sum_nonneg
  intro v _
  exact AntiCommuting.trace_re_nonneg (Matrix.posSemidef_conjTranspose_mul_self _)

 theorem oddSquareTrace_im_zero {ι : Type*} [Fintype ι] (d : ℕ) (β : ℝ)
    (k : ι → ℕ) (c : ι → ℂ) (p : ∀ i, EndpointCube β (k i))
    (s : ι → Set.Icc (0:ℝ) β) (j : Majorana.FourSet d → ℝ) :
    (oddSquareTrace d β k c p s j).im = 0 := by
  unfold oddSquareTrace
  rw [Complex.div_ofReal_im, Complex.im_sum]
  have hh (v : Fin (2*d)) :
      (Matrix.trace (star (oddAmplitude d (Majorana.hamiltonian d j) (β/2) k c
        (fun i => endpointValues (p i)) (fun i => (s i).val) v) *
          oddAmplitude d (Majorana.hamiltonian d j) (β/2) k c
        (fun i => endpointValues (p i)) (fun i => (s i).val) v)).im = 0 :=
    Gibbs.trace_im_eq_zero (Matrix.posSemidef_conjTranspose_mul_self _).isHermitian
  simp only [hh, Finset.sum_const_zero, zero_div]

/-- Actual finite-N inserted odd reflection positivity. -/
theorem actualPolynomial_odd_nonnegative {ι : Type*} [Fintype ι]
    (d : ℕ) (β : ℝ) (lam : ℝ≥0) (k : ι → ℕ) (c : ι → ℂ)
    (p : ∀ i, EndpointCube β (k i)) (s : ι → Set.Icc (0:ℝ) β)
    (hp : ∀ i r, (p i r).1.val<β/2 ∧ (p i r).2.val<β/2)
    (hs : ∀ i, (s i).val<β/2) :
    0 ≤ (actualPolynomial d β lam (oddTupleForm β k c p s)).re := by
  have hre : (∫ j, (oddSquareTrace d β k c p s j).re ∂Microscopic.disorder d lam) =
      (∫ j, oddSquareTrace d β k c p s j ∂Microscopic.disorder d lam).re :=
    integral_re (oddSquareTrace_integrable d β lam k c p s hp hs)
  rw [actualPolynomial_odd_eq_integral d β lam k c p s hp hs, Complex.div_ofReal_re, ← hre]
  exact div_nonneg (integral_nonneg (oddSquareTrace_nonnegative d β k c p s))
    (ThermalRP.annealed_partition_positive d β lam).le

/-- Actual finite-N inserted odd reflection reality. -/
theorem actualPolynomial_odd_im_zero {ι : Type*} [Fintype ι]
    (d : ℕ) (β : ℝ) (lam : ℝ≥0) (k : ι → ℕ) (c : ι → ℂ)
    (p : ∀ i, EndpointCube β (k i)) (s : ι → Set.Icc (0:ℝ) β)
    (hp : ∀ i r, (p i r).1.val<β/2 ∧ (p i r).2.val<β/2)
    (hs : ∀ i, (s i).val<β/2) :
    (actualPolynomial d β lam (oddTupleForm β k c p s)).im = 0 := by
  have him : (∫ j, (oddSquareTrace d β k c p s j).im ∂Microscopic.disorder d lam) =
      (∫ j, oddSquareTrace d β k c p s j ∂Microscopic.disorder d lam).im :=
    integral_im (oddSquareTrace_integrable d β lam k c p s hp hs)
  rw [actualPolynomial_odd_eq_integral d β lam k c p s hp hs, Complex.div_ofReal_im, ← him]
  simp only [oddSquareTrace_im_zero, integral_zero, zero_div]

end SYK.OddPolynomialRP
