import KernelSpace
import Mathlib.MeasureTheory.Integral.IntervalIntegral.Periodic

/-!
# From pointwise Schwinger–Dyson derivatives to a sup-norm ODE

All kernels retain their actual endpoint values. Fubini and bounded evaluation
are used to pass between actual interval integrals and the Banach kernel space.
-/

noncomputable section

namespace SYK

open MeasureTheory Filter Set
open scoped Topology

variable {A : Type*} [NormedRing A] [NormedAlgebra ℂ A] [NormOneClass A]
  [NormedSpace ℝ A] [IsScalarTower ℝ ℂ A] [CompleteSpace A]

/-- A norm-continuous candidate derivative and derivatives at every endpoint
pair suffice to recover the genuine sup-norm derivative. The proof uses the
Banach-valued primitive and bounded point evaluations, not an a.e. quotient. -/
theorem kernel_hasDerivAt_of_pointwise
    (f q : ℝ → KernelSpace A) (hq : Continuous q)
    (hderiv : ∀ t p, HasDerivAt (fun u => f u p) (q t p) t) :
    ∀ t, HasDerivAt f (q t) t := by
  have hprimitive : ∀ t, f t = f 0 + ∫ u in (0 : ℝ)..t, q u := by
    intro t
    apply KernelSpace.ext
    intro p
    have hi := (kernelEvalCLM (A := A) p).intervalIntegral_comp_comm
      (hq.intervalIntegrable (μ := volume) (a := 0) (b := t))
    have he := intervalIntegral.integral_eq_sub_of_hasDerivAt
      (fun u _ => hderiv u p)
      (((kernelEvalCLM (A := A) p).continuous.comp hq).intervalIntegrable (a := 0) (b := t))
    change (∫ u in (0 : ℝ)..t, q u p) = (∫ u in (0 : ℝ)..t, q u) p at hi
    change (∫ u in (0 : ℝ)..t, q u p) = f t p - f 0 p at he
    change f t p = f 0 p + (∫ u in (0 : ℝ)..t, q u) p
    rw [← hi, he]
    abel
  intro t
  have hd := (hq.integral_hasStrictDerivAt 0 t).hasDerivAt.const_add (f 0)
  convert hd using 1
  exact funext hprimitive

/-- Triple products are Bochner integrable on the finite square, including for
nonseparable coefficient algebras, because joint strong measurability and a
uniform norm bound are explicit. -/
theorem kernelTriple_integrable (β : ℝ) (f g h : KernelSpace A) (s t : ℝ) :
    Integrable (fun p : ℝ × ℝ => (f (s, p.1) * g (p.1, p.2)) * h (p.2, t))
      ((volume.restrict (Ioc 0 β)).prod (volume.restrict (Ioc 0 β))) := by
  have hm : StronglyMeasurable (fun p : ℝ × ℝ =>
      (f (s, p.1) * g (p.1, p.2)) * h (p.2, t)) :=
    (((KernelSpace.stronglyMeasurable f).comp_measurable
      (measurable_const.prodMk measurable_fst)).mul
      (KernelSpace.stronglyMeasurable g)).mul
      ((KernelSpace.stronglyMeasurable h).comp_measurable
        (measurable_snd.prodMk measurable_const))
  apply (integrable_const (‖f‖ * ‖g‖ * ‖h‖)).mono' hm.aestronglyMeasurable
  filter_upwards [] with p
  calc
    _ ≤ (‖f (s, p.1)‖ * ‖g (p.1, p.2)‖) * ‖h (p.2, t)‖ :=
      (norm_mul_le _ _).trans (mul_le_mul_of_nonneg_right (norm_mul_le _ _) (norm_nonneg _))
    _ ≤ ‖f‖ * ‖g‖ * ‖h‖ := by
      gcongr <;> exact kernel_norm_apply_le _ _

/-- Genuine interval-integral kernel composition is associative. This justifies
rewriting the manuscript's `(C * G³) * G` as `C * (G³ * G)`. -/
theorem kernelConvolution_assoc (β : ℝ) (hβ : 0 ≤ β)
    (f g h : KernelSpace A) :
    kernelConvolution β hβ (kernelConvolution β hβ f g) h =
      kernelConvolution β hβ f (kernelConvolution β hβ g h) := by
  apply KernelSpace.ext
  rintro ⟨s,t⟩
  simp only [kernelConvolution_apply]
  have hleft : ∀ v, (∫ u in (0 : ℝ)..β, f (s,u) * g (u,v)) * h (v,t) =
      ∫ u in (0 : ℝ)..β, (f (s,u) * g (u,v)) * h (v,t) := by
    intro v
    exact ((ContinuousLinearMap.mul ℂ A).flip (h (v,t))).intervalIntegral_comp_comm
      (kernelProduct_intervalIntegrable β f g (s,v)) |>.symm
  have hright : ∀ u, f (s,u) * (∫ v in (0 : ℝ)..β, g (u,v) * h (v,t)) =
      ∫ v in (0 : ℝ)..β, f (s,u) * (g (u,v) * h (v,t)) := by
    intro u
    exact ((ContinuousLinearMap.mul ℂ A) (f (s,u))).intervalIntegral_comp_comm
      (kernelProduct_intervalIntegrable β g h (u,t)) |>.symm
  simp_rw [hleft, hright, ← mul_assoc, intervalIntegral.integral_of_le hβ]
  exact (integral_integral_swap (kernelTriple_integrable β f g h s t)).symm

/-- Separate antiperiodicity is a pointwise property, including boundary values. -/
def KernelAntiperiodic (β : ℝ) (f : KernelSpace A) : Prop :=
  (∀ s t, f (s + β, t) = -f (s,t)) ∧ (∀ s t, f (s, t + β) = -f (s,t))

/-- Translating both external endpoints commutes with composition. The change
of internal interval is justified by periodicity of the product integrand. -/
theorem translateKernel_convolution (β : ℝ) (hβ : 0 ≤ β)
    (f g : KernelSpace A) (hf : KernelAntiperiodic β f)
    (hg : KernelAntiperiodic β g) (u : ℝ) :
    translateKernel u (kernelConvolution β hβ f g) =
      kernelConvolution β hβ (translateKernel u f) (translateKernel u g) := by
  apply KernelSpace.ext
  rintro ⟨s,t⟩
  change (∫ v in (0 : ℝ)..β, f (s+u,v) * g (v,t+u)) =
    ∫ v in (0 : ℝ)..β, f (s+u,v+u) * g (v+u,t+u)
  have hp : Function.Periodic (fun v => f (s+u,v) * g (v,t+u)) β := by
    intro v
    change f (s+u,v+β) * g (v+β,t+u) = f (s+u,v) * g (v,t+u)
    rw [hf.2, hg.1, neg_mul_neg]
  have hc := intervalIntegral.integral_comp_add_right
    (fun v => f (s+u,v) * g (v,t+u)) u (a := 0) (b := β)
  rw [hc]
  simpa only [zero_add, add_comm β u] using hp.intervalIntegral_add_eq 0 u

/-- Uniform boundedness makes every strongly measurable section Bochner
integrable on every finite interval. -/
theorem bounded_intervalIntegrable {F : ℝ → A} (hF : StronglyMeasurable F)
    {B : ℝ} (hB : ∀ v, ‖F v‖ ≤ B) (a b : ℝ) :
    IntervalIntegrable F volume a b :=
  (intervalIntegrable_const (c := B)).mono_fun' hF.aestronglyMeasurable
    (Eventually.of_forall hB)

/-- The jump kernel has the expected primitive, with the value at its single
jump point removed only inside the integral, never in kernel equality. -/
theorem halfSign_kernel_integral (U : KernelSpace A) (t a x b : ℝ)
    (hax : a ≤ x) (hxb : x ≤ b) :
    (∫ v in a..b, (Thermal.halfSign (x-v) : ℂ) • U (v,t)) =
      (∫ v in a..x, U (v,t)) - (1/2 : ℂ) • (∫ v in a..b, U (v,t)) := by
  have hm : StronglyMeasurable (fun v : ℝ => U (v,t)) :=
    (KernelSpace.stronglyMeasurable U).comp_measurable (measurable_id.prodMk measurable_const)
  have hi : ∀ a b : ℝ, IntervalIntegrable (fun v => U (v,t)) volume a b :=
    fun a b => bounded_intervalIntegrable hm (fun v => kernel_norm_apply_le U (v,t)) a b
  have hj : ∀ a b : ℝ, IntervalIntegrable
      (fun v => (Thermal.halfSign (x-v) : ℂ) • U (v,t)) volume a b := by
    intro a b
    apply bounded_intervalIntegrable
      ((Complex.continuous_ofReal.comp_stronglyMeasurable
        (Thermal.halfSign_measurable.comp (measurable_const.sub measurable_id)).stronglyMeasurable).smul hm)
      (B := (1/2) * ‖U‖) _ a b
    intro v
    rw [norm_smul, Complex.norm_real, Real.norm_eq_abs]
    exact mul_le_mul (Thermal.abs_halfSign_le _) (kernel_norm_apply_le U _)
      (norm_nonneg _) (by norm_num)
  have hlo : (∫ v in a..x, (Thermal.halfSign (x-v) : ℂ) • U (v,t)) =
      (1/2 : ℂ) • ∫ v in a..x, U (v,t) := by
    rw [← intervalIntegral.integral_smul]
    apply intervalIntegral.integral_congr_ae
    filter_upwards [(countable_singleton x).ae_not_mem volume] with v hv
    intro hmem
    rw [uIoc_of_le hax] at hmem
    have hvx : 0 < x-v := sub_pos.mpr (lt_of_le_of_ne hmem.2 hv)
    simp [Thermal.halfSign, hvx]
  have hhi : (∫ v in x..b, (Thermal.halfSign (x-v) : ℂ) • U (v,t)) =
      -(1/2 : ℂ) • ∫ v in x..b, U (v,t) := by
    rw [← intervalIntegral.integral_smul]
    apply intervalIntegral.integral_congr_ae
    filter_upwards [] with v
    intro hmem
    rw [uIoc_of_le hxb] at hmem
    have hvx : x-v < 0 := sub_neg.mpr hmem.1
    simp [Thermal.halfSign, hvx, not_lt_of_ge (le_of_lt hvx)]
  rw [← intervalIntegral.integral_add_adjacent_intervals (hj a x) (hj x b), hlo, hhi,
    ← intervalIntegral.integral_add_adjacent_intervals (hi a x) (hi x b)]
  module

/-- On an arbitrary translated fundamental interval the free convolution is an
ordinary primitive plus a fixed term. The upper endpoint is discarded only
under the integral; the resulting identity is pointwise in the external pair. -/
theorem freeThermalKernel_convolution_local (β : ℝ) (hβ : 0 < β)
    (U : KernelSpace A) (hU : ∀ s t, U (s+β,t) = -U (s,t))
    (a x t : ℝ) (hx : x ∈ Ioo a (a+β)) :
    kernelConvolution β hβ.le (freeThermalKernel β) U (x,t) =
      (∫ v in a..x, U (v,t)) - (1/2 : ℂ) • ∫ v in a..a+β, U (v,t) := by
  have hp : Function.Periodic
      (fun v => (Thermal.kernel β x v : ℂ) • U (v,t)) β := by
    intro v
    change (Thermal.kernel β x (v+β) : ℂ) • U (v+β,t) =
      (Thermal.kernel β x v : ℂ) • U (v,t)
    have hC : Thermal.kernel β x (v+β) = -Thermal.kernel β x v := by
      rw [Thermal.kernel_skew β (v+β) x]
      unfold Thermal.kernel
      rw [show (v+β)-x = (v-x)+β by ring, Thermal.covariance_antiperiodic β hβ.ne']
      rw [neg_neg]
      exact Thermal.kernel_skew β x v
    rw [hC, hU]
    simp
  calc
    _ = ∫ v in (0 : ℝ)..β, (Thermal.kernel β x v : ℂ) • U (v,t) := by
      simp only [kernelConvolution_apply, freeThermalKernel_apply, smul_mul_assoc, one_mul]
    _ = ∫ v in a..a+β, (Thermal.kernel β x v : ℂ) • U (v,t) := by
      simpa only [zero_add] using hp.intervalIntegral_add_eq 0 a
    _ = ∫ v in a..a+β, (Thermal.halfSign (x-v) : ℂ) • U (v,t) := by
      apply intervalIntegral.integral_congr_ae
      filter_upwards [(countable_singleton (a+β)).ae_not_mem volume] with v hv
      intro hmem
      rw [uIoc_of_le (by linarith : a ≤ a+β)] at hmem
      have hnorm := Thermal.kernel_on_fundamental β hβ (x-a) (v-a)
        ⟨by linarith [hx.1], by linarith [hx.2]⟩
        ⟨by linarith [hmem.1], by have hlt := lt_of_le_of_ne hmem.2 hv; linarith⟩
      have he : Thermal.kernel β x v = Thermal.halfSign (x-v) := by
        simpa only [Thermal.kernel, show (x-a)-(v-a) = x-v by ring] using hnorm
      rw [he]
    _ = _ := halfSign_kernel_integral U t a x (a+β) hx.1.le hx.2.le

/-- The derivative of the free convolution is valid at every real endpoint,
including integer multiples of β. No derivative is taken of the jump itself. -/
theorem freeThermalKernel_convolution_hasDerivAt (β : ℝ) (hβ : 0 < β)
    (U : KernelSpace A) (hU : ∀ s t, U (s+β,t) = -U (s,t))
    (hcont : Continuous (fun p : ℝ × ℝ => U p)) (s t : ℝ) :
    HasDerivAt (fun x => kernelConvolution β hβ.le (freeThermalKernel β) U (x,t))
      (U (s,t)) s := by
  let a := s-β/2
  have hs : s ∈ Ioo a (a+β) := by dsimp [a]; constructor <;> linarith
  have hc : Continuous (fun v : ℝ => U (v,t)) :=
    hcont.comp (continuous_id.prodMk continuous_const)
  have hd := (hc.integral_hasStrictDerivAt a s).hasDerivAt.sub_const
    ((1/2 : ℂ) • ∫ v in a..a+β, U (v,t))
  apply hd.congr_of_eventuallyEq
  filter_upwards [isOpen_Ioo.mem_nhds hs] with x hx
  exact freeThermalKernel_convolution_local β hβ U hU a x t hx

/-- Transposition preserves actual endpoint values and strong measurability. -/
def transposeKernel (f : KernelSpace A) : KernelSpace A :=
  kernelOfFunction (fun p => f (p.2,p.1))
    ((KernelSpace.stronglyMeasurable f).comp_measurable measurable_swap)
    ‖f‖ (fun p => kernel_norm_apply_le f _)

@[simp] theorem transposeKernel_apply (f : KernelSpace A) (s t : ℝ) :
    transposeKernel f (s,t) = f (t,s) := rfl

/-- Right convolution has the opposite endpoint derivative. The minus sign
comes from the skew free covariance, while scalar coefficients commute with A. -/
theorem convolution_freeThermalKernel_hasDerivAt (β : ℝ) (hβ : 0 < β)
    (V : KernelSpace A) (hV : ∀ s t, V (s,t+β) = -V (s,t))
    (hcont : Continuous (fun p : ℝ × ℝ => V p)) (s t : ℝ) :
    HasDerivAt (fun y => kernelConvolution β hβ.le V (freeThermalKernel β) (s,y))
      (-V (s,t)) t := by
  have ht : ∀ x y, transposeKernel V (x+β,y) = -transposeKernel V (x,y) :=
    fun x y => hV y x
  have hc : Continuous (fun p : ℝ × ℝ => transposeKernel V p) :=
    hcont.comp continuous_swap
  have hd := (freeThermalKernel_convolution_hasDerivAt β hβ (transposeKernel V) ht hc t s).neg
  convert hd using 1
  funext y
  simp only [kernelConvolution_apply, freeThermalKernel_apply, transposeKernel_apply,
    mul_smul_comm, mul_one, smul_mul_assoc, one_mul, ← intervalIntegral.integral_neg]
  apply intervalIntegral.integral_congr
  intro v _
  change (Thermal.kernel β v y : ℂ) • V (s,v) = -((Thermal.kernel β y v : ℂ) • V (s,v))
  rw [Thermal.kernel_skew β y v]
  simp

/-- An endpoint-Lipschitz derivative bounds the mixed rectangle increment
quadratically. This supplies the uniform error needed to add partial derivatives. -/
theorem rectangle_increment_norm_le
    (R V : ℝ × ℝ → A) (hV : Continuous V)
    (hderiv : ∀ s t, HasDerivAt (fun y => R (s,y)) (V (s,t)) t)
    (L : ℝ) (hLip : ∀ s s' t, ‖V (s,t)-V (s',t)‖ ≤ L*|s-s'|)
    (s t h : ℝ) :
    ‖R (s+h,t+h)-R (s+h,t)-R (s,t+h)+R (s,t)‖ ≤ L*‖h‖^2 := by
  have hc : ∀ s, Continuous (fun y => V (s,y)) :=
    fun s => hV.comp (continuous_const.prodMk continuous_id)
  have hi : ∀ s, (∫ y in t..t+h, V (s,y)) = R (s,t+h)-R (s,t) :=
    fun s => intervalIntegral.integral_eq_sub_of_hasDerivAt
      (fun y _ => hderiv s y) ((hc s).intervalIntegrable (a := t) (b := t+h))
  have he : R (s+h,t+h)-R (s+h,t)-R (s,t+h)+R (s,t) =
      ∫ y in t..t+h, (V (s+h,y)-V (s,y)) := by
    rw [intervalIntegral.integral_sub ((hc (s+h)).intervalIntegrable (a := t) (b := t+h))
      ((hc s).intervalIntegrable (a := t) (b := t+h)), hi, hi]
    abel
  rw [he]
  calc
    _ ≤ (L*|h|)*|(t+h)-t| := intervalIntegral.norm_integral_le_of_norm_le_const
      (fun y _ => by simpa only [add_sub_cancel_left] using hLip (s+h) s y)
    _ = L*‖h‖^2 := by rw [add_sub_cancel_left, Real.norm_eq_abs]; ring

/-- Joint center differentiation follows from the actual slice derivatives and
an endpoint Lipschitz bound; a joint Fréchet derivative is not assumed. -/
theorem diagonal_hasDerivAt_of_partials
    (R U V : ℝ × ℝ → A) (hV : Continuous V)
    (hfirst : ∀ s t, HasDerivAt (fun x => R (x,t)) (U (s,t)) s)
    (hsecond : ∀ s t, HasDerivAt (fun y => R (s,y)) (V (s,t)) t)
    (L : ℝ) (hLip : ∀ s s' t, ‖V (s,t)-V (s',t)‖ ≤ L*|s-s'|)
    (s t u : ℝ) :
    HasDerivAt (fun v => R (s+v,t+v)) (U (s+u,t+u)+V (s+u,t+u)) u := by
  have herr : (fun h : ℝ => R ((s+u)+h,(t+u)+h)-R ((s+u)+h,t+u)-
      R (s+u,(t+u)+h)+R (s+u,t+u)) =O[𝓝 0] (fun h : ℝ => ‖h‖^2) :=
    Asymptotics.IsBigO.of_bound L (Eventually.of_forall fun h => by
      simpa only [Real.norm_eq_abs, abs_pow, abs_abs] using
        rectangle_increment_norm_le R V hV hsecond L hLip (s+u) (t+u) h)
  have he := herr.trans_isLittleO (Asymptotics.isLittleO_norm_pow_id (by norm_num : 1<2))
  have hf := hasDerivAt_iff_isLittleO_nhds_zero.mp (hfirst (s+u) (t+u))
  have hs := hasDerivAt_iff_isLittleO_nhds_zero.mp (hsecond (s+u) (t+u))
  apply hasDerivAt_iff_isLittleO_nhds_zero.mpr
  convert (hf.add hs).add he using 1
  ext h
  simp only [Pi.add_apply, smul_add, ← add_assoc]
  abel

@[simp] theorem kernel_pow_apply (f : KernelSpace A) (n : ℕ) (p : ℝ × ℝ) :
    (f^n) p = (f p)^n := by
  induction n with
  | zero => rfl
  | succ n ih => simp only [pow_succ, kernel_mul_apply, ih]

@[simp] theorem translateKernel_add (u : ℝ) (f g : KernelSpace A) :
    translateKernel u (f+g) = translateKernel u f + translateKernel u g := by
  ext p; rfl

@[simp] theorem translateKernel_pow (u : ℝ) (f : KernelSpace A) (n : ℕ) :
    translateKernel u (f^n) = (translateKernel u f)^n := by
  ext p
  rcases p with ⟨s,t⟩
  simp only [translateKernel_apply, kernel_pow_apply]

theorem KernelAntiperiodic.cube {β : ℝ} {f : KernelSpace A}
    (hf : KernelAntiperiodic β f) : KernelAntiperiodic β (f^3) := by
  constructor <;> intro s t
  · change (f (s+β,t))^3 = -(f (s,t))^3
    rw [hf.1]
    simp only [pow_succ, pow_zero, one_mul, neg_mul, mul_neg, neg_neg]
  · change (f (s,t+β))^3 = -(f (s,t))^3
    rw [hf.2]
    simp only [pow_succ, pow_zero, one_mul, neg_mul, mul_neg, neg_neg]

theorem KernelAntiperiodic.convolution {β : ℝ} (hβ : 0 ≤ β) {f g : KernelSpace A}
    (hf : KernelAntiperiodic β f) (hg : KernelAntiperiodic β g) :
    KernelAntiperiodic β (kernelConvolution β hβ f g) := by
  constructor <;> intro s t
  · simp only [kernelConvolution_apply, hf.1, neg_mul, intervalIntegral.integral_neg]
  · simp only [kernelConvolution_apply, hg.2, mul_neg, intervalIntegral.integral_neg]

/-- The actual two-sided integrated SD identities, with left-associated
composition matching the continuum target definitions. -/
def TwoSidedIntegratedKernelSD (β : ℝ) (hβ : 0 ≤ β) (lam : ℂ)
    (R : KernelSpace A) : Prop :=
  let C := freeThermalKernel (A := A) β
  let G := C+R
  R = lam • kernelConvolution β hβ (kernelConvolution β hβ C (G^3)) G ∧
  R = lam • kernelConvolution β hβ (kernelConvolution β hβ G (G^3)) C

/-- The integrated identities imply both genuine endpoint derivatives after
the jump is removed; no derivative hypothesis is present in the inputs. -/
theorem integratedSD_endpoint_derivatives
    (β : ℝ) (hβ : 0 < β) (lam : ℂ) (R : KernelSpace A)
    (hSD : TwoSidedIntegratedKernelSD β hβ.le lam R)
    (hG : KernelAntiperiodic β (freeThermalKernel β+R))
    (hU : Continuous (fun p : ℝ × ℝ =>
      kernelConvolution β hβ.le ((freeThermalKernel β+R)^3) (freeThermalKernel β+R) p))
    (hV : Continuous (fun p : ℝ × ℝ =>
      kernelConvolution β hβ.le (freeThermalKernel β+R) ((freeThermalKernel β+R)^3) p)) :
    (∀ s t, HasDerivAt (fun x => R (x,t))
      (lam • kernelConvolution β hβ.le ((freeThermalKernel β+R)^3) (freeThermalKernel β+R) (s,t)) s) ∧
    (∀ s t, HasDerivAt (fun y => R (s,y))
      (-(lam • kernelConvolution β hβ.le (freeThermalKernel β+R) ((freeThermalKernel β+R)^3) (s,t))) t) := by
  let C := freeThermalKernel (A := A) β
  let G := C+R
  let U := kernelConvolution β hβ.le (G^3) G
  let V := kernelConvolution β hβ.le G (G^3)
  have hUa := hG.cube.convolution hβ.le hG
  have hVa := hG.convolution hβ.le hG.cube
  have hleft : R = lam • kernelConvolution β hβ.le C U := by
    simpa only [TwoSidedIntegratedKernelSD, kernelConvolution_assoc] using hSD.1
  have hright : R = lam • kernelConvolution β hβ.le V C := hSD.2
  constructor
  · intro s t
    have hd := (freeThermalKernel_convolution_hasDerivAt β hβ U hUa.1 hU s t).const_smul lam
    convert hd using 1
    funext x
    exact congrArg (fun f : KernelSpace A => f (x,t)) hleft
  · intro s t
    have hd := (convolution_freeThermalKernel_hasDerivAt β hβ V hVa.2 hV s t).const_smul lam
    simp only [smul_neg] at hd
    convert hd using 1
    funext y
    exact congrArg (fun f : KernelSpace A => f (s,y)) hright

/-- The actual two-sided integrated SD equations, endpoint Lipschitz regularity,
and convolution regularity yield the center-time ODE in genuine sup norm.
There is no assumed derivative or analyticity of the orbit. -/
theorem integratedSD_center_ode
    (β : ℝ) (hβ : 0 < β) (lam : ℂ) (R : KernelSpace A)
    (hSD : TwoSidedIntegratedKernelSD β hβ.le lam R)
    (hG : KernelAntiperiodic β (freeThermalKernel β+R))
    (K : ℝ) (hK : 0 ≤ K)
    (hR : ∀ s t s' t', ‖R (s,t)-R (s',t')‖ ≤ K*(|s-s'|+|t-t'|))
    (hU : Continuous (fun p : ℝ × ℝ =>
      kernelConvolution β hβ.le ((freeThermalKernel β+R)^3) (freeThermalKernel β+R) p))
    (hV : Continuous (fun p : ℝ × ℝ =>
      kernelConvolution β hβ.le (freeThermalKernel β+R) ((freeThermalKernel β+R)^3) p))
    (L : ℝ)
    (hVL : ∀ s s' t,
      ‖kernelConvolution β hβ.le (freeThermalKernel β+R) ((freeThermalKernel β+R)^3) (s,t) -
       kernelConvolution β hβ.le (freeThermalKernel β+R) ((freeThermalKernel β+R)^3) (s',t)‖ ≤ L*|s-s'|) :
    ∀ u, HasDerivAt (fun v => translateKernel v R)
      (kernelCenterField (A := KernelSpace A) (kernelConvolutionCLM (A := A) β hβ.le)
        (freeThermalKernel β) lam (translateKernel u R)) u := by
  let C := freeThermalKernel (A := A) β
  let G := C+R
  let U := kernelConvolution β hβ.le (G^3) G
  let V := kernelConvolution β hβ.le G (G^3)
  let F := kernelCenterField (A := KernelSpace A) (kernelConvolutionCLM (A := A) β hβ.le) C lam
  have hF : Continuous F := continuous_iff_continuousAt.mpr
    (fun r => (kernelCenterField_analyticAt (A := KernelSpace A) (kernelConvolutionCLM (A := A) β hβ.le) C lam r).continuousAt)
  have horbit := (translateKernel_lipschitz R K hK hR).continuous
  have hfield : ∀ u, F (translateKernel u R) = lam • (translateKernel u U-translateKernel u V) := by
    intro u
    have hshift : translateKernel u G = C+translateKernel u R := by simp [G,C]
    have heU := translateKernel_convolution β hβ.le (G^3) G hG.cube hG u
    have heV := translateKernel_convolution β hβ.le G (G^3) hG hG.cube u
    simp only [translateKernel_pow, hshift] at heU heV
    dsimp only [F, kernelCenterField]
    rw [kernelConvolutionCLM_apply_kernel, kernelConvolutionCLM_apply_kernel, ← heU, ← heV]
  have hpartials := integratedSD_endpoint_derivatives β hβ lam R hSD hG hU hV
  have hcontV : Continuous (fun p : ℝ × ℝ => -(lam • V p)) :=
    (continuous_const.smul hV).neg
  have hLipV : ∀ s s' t, ‖-(lam • V (s,t))- -(lam • V (s',t))‖ ≤ (‖lam‖*L)*|s-s'| := by
    intro s s' t
    calc
      _ = ‖lam • (V (s,t)-V (s',t))‖ := by rw [neg_sub_neg, norm_sub_rev, smul_sub]
      _ = ‖lam‖*‖V (s,t)-V (s',t)‖ := norm_smul _ _
      _ ≤ ‖lam‖*(L*|s-s'|) := mul_le_mul_of_nonneg_left (hVL s s' t) (norm_nonneg _)
      _ = (‖lam‖*L)*|s-s'| := by ring
  apply kernel_hasDerivAt_of_pointwise (fun v => translateKernel v R)
    (fun u => F (translateKernel u R)) (hF.comp horbit)
  intro u p
  rcases p with ⟨s,t⟩
  have hd := diagonal_hasDerivAt_of_partials (fun p => R p)
    (fun p => lam • U p) (fun p => -(lam • V p)) hcontV
    hpartials.1 hpartials.2 (‖lam‖*L) hLipV s t u
  rw [hfield]
  simp only [kernel_smul_apply, kernel_sub_apply, translateKernel_apply, smul_sub]
  simpa only [sub_eq_add_neg] using hd

/-- Analytic center-time orbits now follow from the integrated equations,
without assuming the ODE or analyticity as an input. -/
theorem integratedSD_center_analytic
    (β : ℝ) (hβ : 0 < β) (lam : ℂ) (R : KernelSpace A)
    (hSD : TwoSidedIntegratedKernelSD β hβ.le lam R)
    (hG : KernelAntiperiodic β (freeThermalKernel β+R))
    (K : ℝ) (hK : 0 ≤ K)
    (hR : ∀ s t s' t', ‖R (s,t)-R (s',t')‖ ≤ K*(|s-s'|+|t-t'|))
    (hU : Continuous (fun p : ℝ × ℝ =>
      kernelConvolution β hβ.le ((freeThermalKernel β+R)^3) (freeThermalKernel β+R) p))
    (hV : Continuous (fun p : ℝ × ℝ =>
      kernelConvolution β hβ.le (freeThermalKernel β+R) ((freeThermalKernel β+R)^3) p))
    (L : ℝ)
    (hVL : ∀ s s' t,
      ‖kernelConvolution β hβ.le (freeThermalKernel β+R) ((freeThermalKernel β+R)^3) (s,t) -
       kernelConvolution β hβ.le (freeThermalKernel β+R) ((freeThermalKernel β+R)^3) (s',t)‖ ≤ L*|s-s'|) :
    AnalyticOnNhd ℝ (fun u => translateKernel u R) Set.univ :=
  concreteKernel_ode_analytic β hβ.le (freeThermalKernel β) lam (fun u => translateKernel u R)
    (integratedSD_center_ode β hβ lam R hSD hG K hK hR hU hV L hVL)

end SYK
