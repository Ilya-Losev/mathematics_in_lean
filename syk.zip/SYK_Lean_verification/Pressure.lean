import Mathlib.Analysis.Calculus.MeanValue
import Mathlib.MeasureTheory.Integral.IntervalIntegral.FundThmCalculus
import Mathlib.MeasureTheory.Integral.DominatedConvergence

/-!
# The scalar pressure calculation in Section 10

These theorems verify the last calculus step of the SYK pressure argument.
They do not prove the finite-N Wick identity, the moment bounds, the convergence
of the fourth collective moment, or the annealed/quenched comparison. Those
model-specific inputs are explicitly represented by hypotheses below.

In particular, no claim about SYK is introduced as a Lean axiom.
-/

open Set Filter MeasureTheory
open scoped Topology

namespace SYK

/-- A pressure on the nonnegative coupling axis is uniquely determined by its
derivative on positive couplings and its value at the free model. Continuity at
the endpoint is essential: agreement of derivatives alone only fixes an
additive constant on the open half-line. -/
theorem pressure_unique
    (p q h : ℝ → ℝ)
    (hpcont : ContinuousOn p (Ici 0))
    (hqcont : ContinuousOn q (Ici 0))
    (hpderiv : ∀ x, 0 < x → HasDerivAt p (h x) x)
    (hqderiv : ∀ x, 0 < x → HasDerivAt q (h x) x)
    (hanchor : p 0 = q 0) :
    EqOn p q (Ici 0) := by
  obtain ⟨c, hc⟩ := isOpen_Ioi.exists_eq_add_of_deriv_eq
    isPreconnected_Ioi
    (fun x hx => (hpderiv x hx).differentiableAt.differentiableWithinAt)
    (fun x hx => (hqderiv x hx).differentiableAt.differentiableWithinAt)
    (fun x hx => (hpderiv x hx).deriv.trans (hqderiv x hx).deriv.symm)
  have hcclosed : EqOn p (fun x => q x + c) (Ici 0) :=
    hc.of_subset_closure hpcont (hqcont.add continuousOn_const)
      (fun x hx => (show 0 ≤ x from le_of_lt hx)) (by simpa only [closure_Ioi] using
        (Subset.rfl : Ici (0 : ℝ) ⊆ Ici 0))
  have hc0 := hcclosed (show (0 : ℝ) ∈ Ici 0 by simp)
  have hczero : c = 0 := left_eq_add.mp (hanchor.symm.trans hc0)
  simpa only [hczero, add_zero] using hcclosed

/-- Fundamental theorem of calculus with derivatives required only at interior
couplings. The derivative need not be defined or continuous at coupling zero. -/
theorem pressure_integral_formula
    (p h : ℝ → ℝ) (p0 x : ℝ)
    (hx : 0 ≤ x)
    (hcont : ContinuousOn p (Icc 0 x))
    (hderiv : ∀ t ∈ Ioo 0 x, HasDerivAt p (h t) t)
    (hint : IntervalIntegrable h volume 0 x)
    (hanchor : p 0 = p0) :
    p x = p0 + intervalIntegral h 0 x volume := by
  have hFTC := intervalIntegral.integral_eq_sub_of_hasDerivAt_of_le
    hx hcont hderiv hint
  rw [hanchor] at hFTC
  calc
    p x = (p x - p0) + p0 := (sub_add_cancel (p x) p0).symm
    _ = intervalIntegral h 0 x volume + p0 := by rw [hFTC]
    _ = p0 + intervalIntegral h 0 x volume := add_comm _ _

/-- The scalar dominated-convergence step of Section 10. Assuming the exact
finite-N derivative identity, the free anchor, an integrable common bound, and
almost-everywhere convergence of these derivatives, the pressures converge to
the integral of the limiting derivative.

For the draft, `hN n λ` is the double-time fourth-moment integral divided by 8,
`p0 = (Real.log 2) / 2`, and the bound is the constant `β^2 / 128`. The theorem
does not identify those functions with the microscopic SYK model.
-/
theorem pressure_limit_of_dominated_derivatives
    (pN hN : ℕ → ℝ → ℝ) (h bound : ℝ → ℝ) (p0 x : ℝ)
    (hx : 0 ≤ x)
    (hpcont : ∀ n, ContinuousOn (pN n) (Icc 0 x))
    (hpderiv : ∀ n t, t ∈ Ioo 0 x → HasDerivAt (pN n) (hN n t) t)
    (hanchor : ∀ n, pN n 0 = p0)
    (hmeas : ∀ n, AEStronglyMeasurable (hN n) (volume.restrict (Ioc 0 x)))
    (hboundInt : Integrable bound (volume.restrict (Ioc 0 x)))
    (hbound : ∀ n, ∀ᵐ t ∂volume.restrict (Ioc 0 x), ‖hN n t‖ ≤ bound t)
    (hlim : ∀ᵐ t ∂volume.restrict (Ioc 0 x),
      Tendsto (fun n => hN n t) atTop (𝓝 (h t))) :
    Tendsto (fun n => pN n x) atTop (𝓝 (p0 + intervalIntegral h 0 x volume)) := by
  have hint (n : ℕ) : IntervalIntegrable (hN n) volume 0 x :=
    (intervalIntegrable_iff_integrableOn_Ioc_of_le hx).mpr
      (hboundInt.mono' (hmeas n) (hbound n))
  have hformula (n : ℕ) : pN n x = p0 + intervalIntegral (hN n) 0 x volume :=
    pressure_integral_formula (pN n) (hN n) p0 x hx
      (hpcont n) (hpderiv n) (hint n) (hanchor n)
  have hDCT := tendsto_integral_of_dominated_convergence
    bound hmeas hboundInt hbound hlim
  have hDCTinterval :
      Tendsto (fun n => intervalIntegral (hN n) 0 x volume) atTop
        (𝓝 (intervalIntegral h 0 x volume)) := by
    simpa only [intervalIntegral.integral_of_le hx] using hDCT
  have hs := (tendsto_const_nhds (x := p0)).add hDCTinterval
  simpa only [← hformula] using hs

end SYK
