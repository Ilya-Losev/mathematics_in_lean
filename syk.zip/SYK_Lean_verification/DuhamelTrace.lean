import GibbsState
import Mathlib.Analysis.Calculus.SmoothSeries
import Mathlib.Analysis.Calculus.Deriv.Mul
import Mathlib.Analysis.SpecialFunctions.Exponential
import Mathlib.Analysis.Complex.RealDeriv
import Mathlib.Analysis.SpecialFunctions.Log.Deriv

/-!
# Differentiating the finite-dimensional trace exponential

The noncommutative power derivative is constructed explicitly. Cyclicity of
trace then collapses its terms, without assuming that the perturbation commutes
with the original matrix. The intended exponential derivative is obtained by
summable local bounds on these genuine finite polynomial derivatives.
-/

noncomputable section
open scoped BigOperators Topology ComplexOrder
open NormedSpace Set Filter

namespace SYK.DuhamelTrace

section Powers
variable {A : Type*} [NormedRing A] [NormedAlgebra ℂ A] [NormOneClass A]

/-- The Leibniz derivative of a noncommutative power. -/
def powerDerivative (a b : A) : ℕ → A
  | 0 => 0
  | n + 1 => powerDerivative a b n * a + a ^ n * b

omit [NormOneClass A] in
/-- This recurrence is the actual derivative of the affine matrix power. -/
theorem hasDerivAt_affine_pow (a b : A) (n : ℕ) (z : ℂ) :
    HasDerivAt (fun t : ℂ => (a + t • b) ^ n) (powerDerivative (a + z • b) b n) z := by
  have haff : HasDerivAt (fun t : ℂ => a + t • b) b z := by
    simpa using ((hasDerivAt_id z).smul_const b).const_add a
  induction n with
  | zero => simpa [powerDerivative] using hasDerivAt_const z (1 : A)
  | succ n ih =>
    simpa only [pow_succ, powerDerivative] using ih.mul haff

omit [NormedAlgebra ℂ A] in
/-- The derivative norm has the same factorial-compatible majorant as in the
commutative case, despite the different multiplication order of its terms. -/
theorem norm_powerDerivative_succ_le (a b : A) (n : ℕ) :
    ‖powerDerivative a b (n + 1)‖ ≤ (n + 1 : ℝ) * ‖a‖ ^ n * ‖b‖ := by
  induction n with
  | zero => simp [powerDerivative]
  | succ n ih =>
    simp only [powerDerivative]
    calc
      ‖powerDerivative a b (n + 1) * a + a ^ (n + 1) * b‖ ≤
          ‖powerDerivative a b (n + 1) * a‖ + ‖a ^ (n + 1) * b‖ := norm_add_le _ _
      _ ≤ ‖powerDerivative a b (n + 1)‖ * ‖a‖ + ‖a ^ (n + 1)‖ * ‖b‖ :=
        add_le_add (norm_mul_le _ _) (norm_mul_le _ _)
      _ ≤ ((n + 1 : ℝ) * ‖a‖ ^ n * ‖b‖) * ‖a‖ + ‖a‖ ^ (n + 1) * ‖b‖ := by
        gcongr
        exact norm_pow_le a (n + 1)
      _ = ((n + 1 : ℕ) + 1 : ℝ) * ‖a‖ ^ (n + 1) * ‖b‖ := by
        push_cast; rw [pow_succ]; ring

variable (φ : A →L[ℂ] ℂ) (hcyclic : ∀ a b : A, φ (a * b) = φ (b * a))
include hcyclic

omit [NormOneClass A] in
/-- Cyclicity is sufficient to collapse every noncommutative Leibniz term,
even after multiplying by an additional power. -/
theorem trace_powerDerivative_mul_pow (a b : A) (n k : ℕ) :
    φ (powerDerivative a b (n + 1) * a ^ k) =
      (n + 1 : ℂ) * φ (a ^ (n + k) * b) := by
  induction n generalizing k with
  | zero =>
    simpa [powerDerivative] using hcyclic b (a ^ k)
  | succ n ih =>
    rw [powerDerivative, add_mul, map_add]
    have hfirst : φ (powerDerivative a b (n + 1) * a * a ^ k) =
        (n + 1 : ℂ) * φ (a ^ (n + 1 + k) * b) := by
      rw [mul_assoc, ← pow_succ']
      simpa only [Nat.add_assoc, Nat.add_comm, Nat.add_left_comm] using ih (k + 1)
    have hsecond : φ (a ^ (n + 1) * b * a ^ k) = φ (a ^ (n + 1 + k) * b) := by
      rw [hcyclic (a ^ (n + 1) * b) (a ^ k), ← mul_assoc, ← pow_add,
        Nat.add_comm k (n + 1)]
    rw [hfirst, hsecond]
    push_cast
    ring

omit [NormOneClass A] in
/-- The trace polynomial derivative has the familiar compact expression,
proved here without a commutativity assumption on a and b. -/
theorem hasDerivAt_trace_affine_pow_succ (a b : A) (n : ℕ) (z : ℂ) :
    HasDerivAt (fun t : ℂ => φ ((a + t • b) ^ (n + 1)))
      ((n + 1 : ℂ) * φ ((a + z • b) ^ n * b)) z := by
  have h := φ.hasFDerivAt.comp_hasDerivAt z (hasDerivAt_affine_pow a b (n + 1) z)
  have heq := trace_powerDerivative_mul_pow φ hcyclic (a + z • b) b n 0
  simp only [pow_zero, mul_one, add_zero] at heq
  simpa only [heq, Function.comp_def] using h

variable [CompleteSpace A]

omit hcyclic [NormOneClass A] [CompleteSpace A] in
private theorem inv_factorial_succ_mul (n : ℕ) :
    ((n + 1).factorial : ℂ)⁻¹ * (n + 1 : ℂ) = (n.factorial : ℂ)⁻¹ := by
  rw [Nat.factorial_succ, Nat.cast_mul, mul_inv_rev, Nat.cast_add, Nat.cast_one, mul_assoc]
  have hn : (n + 1 : ℂ) ≠ 0 := by exact_mod_cast Nat.succ_ne_zero n
  rw [inv_mul_cancel₀ hn, mul_one]

omit [NormOneClass A] hcyclic in
/-- The tail of the trace exponential series, with its constant term removed. -/
theorem hasSum_trace_exp_tail (a : A) :
    HasSum (fun n : ℕ => ((n + 1).factorial : ℂ)⁻¹ * φ (a ^ (n + 1)))
      (φ (exp ℂ a) - φ 1) := by
  have h := (exp_series_hasSum_exp' (𝕂 := ℂ) a).mapL φ
  simp only [map_smul, smul_eq_mul] at h
  apply (hasSum_nat_add_iff (f := fun n : ℕ => (n.factorial : ℂ)⁻¹ * φ (a ^ n))
    (g := φ (exp ℂ a) - φ 1) 1).mpr
  simpa only [Finset.sum_range_one, Nat.factorial_zero, Nat.cast_one, inv_one,
    pow_zero, one_mul, sub_add_cancel] using h

omit [CompleteSpace A] [NormOneClass A] in
/-- The correctly differentiated exponential-series term. -/
theorem hasDerivAt_trace_exp_term (a b : A) (n : ℕ) (z : ℂ) :
    HasDerivAt
      (fun t : ℂ => ((n + 1).factorial : ℂ)⁻¹ * φ ((a + t • b) ^ (n + 1)))
      ((n.factorial : ℂ)⁻¹ * φ ((a + z • b) ^ n * b)) z := by
  have h := (hasDerivAt_trace_affine_pow_succ φ hcyclic a b n z).const_mul
    ((n + 1).factorial : ℂ)⁻¹
  simpa only [← mul_assoc, inv_factorial_succ_mul] using h

omit hcyclic [CompleteSpace A] in
/-- Absolute local factorial bound for the differentiated trace series. -/
theorem norm_trace_exp_derivative_term_le (a b : A) (n : ℕ) (z : ℂ)
    (hz : ‖z‖ ≤ 1) :
    ‖(n.factorial : ℂ)⁻¹ * φ ((a + z • b) ^ n * b)‖ ≤
      (‖φ‖ * ‖b‖) * ((n.factorial : ℝ)⁻¹ * (‖a‖ + ‖b‖) ^ n) := by
  have hM : ‖a + z • b‖ ≤ ‖a‖ + ‖b‖ := by
    calc
      ‖a + z • b‖ ≤ ‖a‖ + ‖z • b‖ := norm_add_le _ _
      _ = ‖a‖ + ‖z‖ * ‖b‖ := by rw [norm_smul]
      _ ≤ ‖a‖ + ‖b‖ := by nlinarith [norm_nonneg b]
  rw [norm_mul, norm_inv, Complex.norm_natCast]
  calc
    (n.factorial : ℝ)⁻¹ * ‖φ ((a + z • b) ^ n * b)‖ ≤
        (n.factorial : ℝ)⁻¹ * (‖φ‖ * ‖(a + z • b) ^ n * b‖) := by
      gcongr
      exact φ.le_opNorm _
    _ ≤ (n.factorial : ℝ)⁻¹ * (‖φ‖ * (‖(a + z • b) ^ n‖ * ‖b‖)) := by
      gcongr
      exact norm_mul_le _ _
    _ ≤ (n.factorial : ℝ)⁻¹ * (‖φ‖ * ((‖a‖ + ‖b‖) ^ n * ‖b‖)) := by
      gcongr
      exact (norm_pow_le _ _).trans (pow_le_pow_left₀ (norm_nonneg _) hM n)
    _ = _ := by ring

omit [NormOneClass A] hcyclic in
/-- The derivative series sums to the trace of exp(a) times the perturbation. -/
theorem hasSum_trace_exp_derivative (a b : A) :
    HasSum (fun n : ℕ => (n.factorial : ℂ)⁻¹ * φ (a ^ n * b)) (φ (exp ℂ a * b)) := by
  have h := ((exp_series_hasSum_exp' (𝕂 := ℂ) a).mul_right b).mapL φ
  simpa only [smul_mul_assoc, map_smul, smul_eq_mul] using h

/-- The noncommutative trace-exponential derivative. The cyclicity hypothesis
holds for the actual matrix trace; no commutation of a and b is required. -/
theorem hasDerivAt_trace_exp_affine_zero (a b : A) :
    HasDerivAt (fun t : ℂ => φ (exp ℂ (a + t • b))) (φ (exp ℂ a * b)) 0 := by
  let u : ℕ → ℝ := fun n => (‖φ‖ * ‖b‖) *
    ((n.factorial : ℝ)⁻¹ * (‖a‖ + ‖b‖) ^ n)
  have hu : Summable u := by
    have h := (exp_series_hasSum_exp' (𝕂 := ℝ) (‖a‖ + ‖b‖)).summable
    simp only [smul_eq_mul] at h
    exact h.mul_left (‖φ‖ * ‖b‖)
  have hd := hasDerivAt_tsum_of_isPreconnected hu Metric.isOpen_ball
    (convex_ball (0 : ℂ) 1).isPreconnected
    (fun n z _ => hasDerivAt_trace_exp_term φ hcyclic a b n z)
    (fun n z hz => norm_trace_exp_derivative_term_le φ a b n z
      (le_of_lt (by simpa using hz)))
    (by simp : (0 : ℂ) ∈ Metric.ball 0 1)
    (by simpa using (hasSum_trace_exp_tail φ a).summable)
    (by simp : (0 : ℂ) ∈ Metric.ball 0 1)
  have hf (z : ℂ) :
      (∑' n : ℕ, ((n + 1).factorial : ℂ)⁻¹ * φ ((a + z • b) ^ (n + 1))) =
      φ (exp ℂ (a + z • b)) - φ 1 := (hasSum_trace_exp_tail φ _).tsum_eq
  simp only [hf, zero_smul, add_zero,
    (hasSum_trace_exp_derivative φ a b).tsum_eq] at hd
  simpa only [sub_add_cancel] using hd.add_const (φ 1)

end Powers
section Matrices
open Majorana

/-- The ordinary matrix trace, with continuity derived in finite dimension. -/
def matrixTrace (m : ℕ) : CStarMatrix (Basis m) (Basis m) ℂ →L[ℂ] ℂ := by
  letI : FiniteDimensional ℂ (CStarMatrix (Basis m) (Basis m) ℂ) :=
    inferInstanceAs (FiniteDimensional ℂ (Matrix (Basis m) (Basis m) ℂ))
  exact ((Matrix.traceLinearMap (Basis m) ℂ ℂ).comp
    (CStarMatrix.ofMatrixₗ (R := ℂ)).symm.toLinearMap).toContinuousLinearMap

theorem matrixTrace_cyclic (m : ℕ) (a b : CStarMatrix (Basis m) (Basis m) ℂ) :
    matrixTrace m (a * b) = matrixTrace m (b * a) := Matrix.trace_mul_comm _ _

/-- The actual finite-dimensional trace-exponential derivative, with cyclicity
and continuity now established for the concrete matrix trace. -/
theorem hasDerivAt_matrix_trace_exp_affine_zero (m : ℕ)
    (a b : Matrix (Basis m) (Basis m) ℂ) :
    HasDerivAt (fun t : ℂ => Matrix.trace (exp ℂ (a + t • b)))
      (Matrix.trace (exp ℂ a * b)) 0 :=
  hasDerivAt_trace_exp_affine_zero (matrixTrace m) (matrixTrace_cyclic m)
    (CStarMatrix.ofMatrix a) (CStarMatrix.ofMatrix b)

/-- Restricting the parameter to the reals differentiates the real trace. -/
theorem hasDerivAt_matrix_trace_exp_affine_zero_real (m : ℕ)
    (a b : Matrix (Basis m) (Basis m) ℂ) :
    HasDerivAt (fun t : ℝ => (Matrix.trace (exp ℂ (a + t • b))).re)
      (Matrix.trace (exp ℂ a * b)).re 0 := by
  have h := (hasDerivAt_matrix_trace_exp_affine_zero m a b).real_of_complex
  simpa only [RCLike.real_smul_eq_coe_smul (K := ℂ)] using h

/-- A genuine Gibbs response formula for a finite Hermitian matrix, proved
from the differentiated matrix trace and its positive normalization. -/
theorem hasDerivAt_log_partition_affine_zero (m : ℕ)
    (H V : Matrix (Basis m) (Basis m) ℂ) (hH : H.IsHermitian) (β : ℝ) :
    HasDerivAt (fun t : ℝ => Real.log (Gibbs.partition β (H + t • V)))
      (-β * (Matrix.trace (Gibbs.density β H * V)).re) 0 := by
  have h := hasDerivAt_matrix_trace_exp_affine_zero_real m ((-β) • H) ((-β) • V)
  have heq (t : ℝ) : (-β) • H + t • ((-β) • V) = (-β) • (H + t • V) := by
    rw [smul_add, smul_smul, smul_smul, mul_comm t (-β)]
  simp only [heq] at h
  change HasDerivAt (fun t : ℝ => Gibbs.partition β (H + t • V))
    (Matrix.trace (Gibbs.weight β H * ((-β) • V))).re 0 at h
  have hlog := h.log (by simpa only [zero_smul, add_zero] using
    (ne_of_gt (Gibbs.partition_pos hH β)))
  have hd :
      (Matrix.trace (Gibbs.weight β H * ((-β) • V))).re / Gibbs.partition β H =
      -β * (Matrix.trace (Gibbs.density β H * V)).re := by
    simp only [Gibbs.density, mul_smul_comm, smul_mul_assoc, Matrix.trace_smul,
      Complex.real_smul, Complex.mul_re, Complex.ofReal_re, Complex.ofReal_im,
      zero_mul, sub_zero, div_eq_mul_inv]
    ring
  simpa only [zero_smul, add_zero, hd] using hlog

/-- The concrete Hamiltonian is affine in the actual disorder coordinates. -/
theorem hamiltonian_affine (m : ℕ) (j v : FourSet m → ℝ) (t : ℝ) :
    hamiltonian m (fun I => j I + t * v I) = hamiltonian m j + t • hamiltonian m v := by
  simp only [hamiltonian, add_smul, mul_smul, Finset.sum_add_distrib,
    ← Finset.smul_sum, smul_neg, neg_add_rev]
  abel

/-- The actual finite-N log partition function differentiated in an arbitrary
coupling direction. Both the Majorana Hamiltonian and its normalized Gibbs
expectations are the concrete definitions used in the microscopic model. -/
theorem hasDerivAt_syk_log_partition_direction (m : ℕ) (β : ℝ)
    (j v : FourSet m → ℝ) :
    HasDerivAt
      (fun t : ℝ => Real.log (partitionFunction m β (fun I => j I + t * v I)).re)
      (β * ∑ I, v I * (Matrix.trace (Gibbs.sykDensity m β j * quartic m I)).re) 0 := by
  have h := hasDerivAt_log_partition_affine_zero m (hamiltonian m j) (hamiltonian m v)
    (Gibbs.syk_hamiltonian_isHermitian m j) β
  have hf (t : ℝ) : Gibbs.partition β (hamiltonian m j + t • hamiltonian m v) =
      (partitionFunction m β (fun I => j I + t * v I)).re := by
    rw [← hamiltonian_affine]
    rfl
  have hd : -β * (Matrix.trace
      (Gibbs.density β (hamiltonian m j) * hamiltonian m v)).re =
      β * ∑ I, v I * (Matrix.trace (Gibbs.sykDensity m β j * quartic m I)).re := by
    simp only [Gibbs.sykDensity, hamiltonian, mul_neg, Matrix.mul_sum, Matrix.trace_neg,
      Matrix.trace_sum, mul_smul_comm, Matrix.trace_smul, Complex.neg_re, Complex.re_sum,
      Complex.real_smul, Complex.mul_re, Complex.ofReal_re, Complex.ofReal_im,
      zero_mul, sub_zero]
    ring
  simpa only [hf, hd] using h

/-- The same concrete response at any point of a coupling line. This form
can be used directly with one-dimensional mean-value estimates. -/
theorem hasDerivAt_syk_log_partition_direction_at (m : ℕ) (β : ℝ)
    (j v : FourSet m → ℝ) (t : ℝ) :
    HasDerivAt
      (fun s : ℝ => Real.log (partitionFunction m β (fun I => j I + s * v I)).re)
      (β * ∑ I, v I * (Matrix.trace
        (Gibbs.sykDensity m β (fun I => j I + t * v I) * quartic m I)).re) t := by
  have hzero := hasDerivAt_syk_log_partition_direction m β (fun I => j I + t * v I) v
  have hshift : HasDerivAt (fun s : ℝ => s - t) 1 t := (hasDerivAt_id t).sub_const t
  have hzero' : HasDerivAt
      (fun s : ℝ => Real.log (partitionFunction m β
        (fun I => (j I + t * v I) + s * v I)).re)
      (β * ∑ I, v I * (Matrix.trace
        (Gibbs.sykDensity m β (fun I => j I + t * v I) * quartic m I)).re) (t - t) := by
    simpa only [sub_self] using hzero
  have h := hzero'.comp (h := fun s : ℝ => s - t) t hshift
  have heq (s : ℝ) : (fun I => (j I + t * v I) + (s - t) * v I) =
      (fun I => j I + s * v I) := by
    funext I
    ring
  simpa only [Function.comp_def, heq, mul_one] using h

end Matrices

end SYK.DuhamelTrace
