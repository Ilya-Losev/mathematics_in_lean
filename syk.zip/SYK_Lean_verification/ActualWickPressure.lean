import WickGaussianRegrouping
import WickSeriesPressure

/-! The genuine continuum Wick denominator gives the actual microscopic pressure. -/
noncomputable section
open MeasureTheory Filter Set
open scoped Topology NNReal
namespace SYK.ActualWickPressure
open ContinuumWickSeries WickGaussianRegrouping

@[simp] theorem numerator_empty_im (d : ℕ) (hd : 0<d) {β : ℝ} (hβ : 0<β)
    (lam : ℝ≥0) : (numerator d β hβ [] (lam:ℝ)).im=0 := by
  rw [numerator_empty_eq_partition d hd hβ lam]
  norm_cast

/-- The free trace normalization is exactly log 2/2, so the series pressure
is the original ordinary-trace annealed pressure. -/
theorem seriesPressure_eq_annealedPressure (d : ℕ) (hd : 0<d) {β : ℝ} (hβ : 0<β)
    (lam : ℝ≥0) : seriesPressure d β hβ (lam:ℝ)=Microscopic.annealedPressure d β lam := by
  let Z := ∫ j, (Majorana.partitionFunction d β j).re ∂Microscopic.disorder d lam
  have hZ : 0<Z := ThermalRP.annealed_partition_positive d β lam
  have he : (numerator d β hβ [] (lam:ℝ)).re=Z/(2:ℝ)^d := by
    rw [numerator_empty_eq_partition d hd hβ lam]
    simp only [Z,← Complex.ofReal_ofNat,← Complex.ofReal_pow,← Complex.ofReal_div,Complex.ofReal_re]
  rw [seriesPressure,he,Real.log_div hZ.ne' (by positivity),Real.log_pow]
  change Real.log 2/2 + (Real.log Z-(d:ℝ)*Real.log 2)/(2*d:ℝ) =
    Real.log Z / ((2*d:ℕ):ℝ)
  have hdR : (d:ℝ)≠0 := by exact_mod_cast hd.ne'
  push_cast
  field_simp [hdR]
  ring

/-- The actual positive-coupling derivative follows from the entire Wick
series derivative and exact local identification, without differentiating an
unspecified limiting functional. -/
theorem hasDerivAt_annealedPressure_series (d : ℕ) (hd : 0<d) {β : ℝ} (hβ : 0<β)
    (lam : ℝ) (hlam : 0<lam) :
    HasDerivAt (fun l=>Microscopic.annealedPressure d β l.toNNReal)
      ((1/8:ℝ)*∫ p, (normalizedMoment d β hβ (quarticPairs β hβ p) lam).re ∂pairMeasure β) lam := by
  have hz := numerator_empty_re_pos d hd hβ lam.toNNReal
  have hi := numerator_empty_im d hd hβ lam.toNNReal
  simp only [Real.coe_toNNReal _ hlam.le] at hz hi
  have h := hasDerivAt_seriesPressure d hd β hβ lam hz hi
  apply h.congr_of_eventuallyEq
  filter_upwards [Ioi_mem_nhds hlam] with l hl
  have he := seriesPressure_eq_annealedPressure d hd hβ l.toNNReal
  simpa only [Real.coe_toNNReal _ hl.le] using he.symm

end SYK.ActualWickPressure
