import ThermalCovariance
import Mathlib.MeasureTheory.Integral.Bochner.Set
import Mathlib.MeasureTheory.Measure.Lebesgue.Basic

noncomputable section
open MeasureTheory Set
namespace SYK.Thermal

/-- Moving a midpoint jump changes the covariance only between its old and new locations. -/
theorem halfSign_difference_bound (a b x : ℝ) (hab : a ≤ b) :
    |halfSign (a - x) - halfSign (b - x)| ≤
      (Icc a b).indicator (fun _ : ℝ => (1 : ℝ)) x := by
  by_cases hx : x ∈ Icc a b
  · rw [indicator_of_mem hx]
    calc
      _ ≤ |halfSign (a - x)| + |halfSign (b - x)| := abs_sub _ _
      _ ≤ 1 / 2 + 1 / 2 := add_le_add (abs_halfSign_le _) (abs_halfSign_le _)
      _ = 1 := by norm_num
  · rw [indicator_of_not_mem hx]
    simp only [mem_Icc, not_and_or, not_le] at hx
    rcases hx with hx | hx
    · have ha : 0 < a - x := by linarith
      have hb : 0 < b - x := by linarith
      simp [halfSign, ha, hb]
    · have ha : a - x < 0 := by linarith
      have hb : b - x < 0 := by linarith
      simp [halfSign, ha, hb, not_lt_of_ge (le_of_lt ha), not_lt_of_ge (le_of_lt hb)]

theorem integrable_halfSign_difference (a b : ℝ) (hab : a ≤ b) :
    Integrable (fun x : ℝ => |halfSign (a - x) - halfSign (b - x)|) := by
  have hg : Integrable ((Icc a b).indicator (fun _ : ℝ => (1 : ℝ))) := by
    rw [integrable_indicator_iff measurableSet_Icc]
    exact integrableOn_const.mpr (Or.inr (by simp))
  apply hg.mono'
  · have hm : Measurable (fun x : ℝ => halfSign (a - x) - halfSign (b - x)) :=
      (halfSign_measurable.comp (measurable_const.sub measurable_id)).sub
        (halfSign_measurable.comp (measurable_const.sub measurable_id))
    exact (continuous_abs.measurable.comp hm).aestronglyMeasurable
  · filter_upwards [] with x
    simpa only [Real.norm_eq_abs, abs_abs] using halfSign_difference_bound a b x hab

/-- The global L¹ modulus underlying the endpoint regularity estimate. -/
theorem integral_halfSign_difference_le (a b : ℝ) (hab : a ≤ b) :
    (∫ x : ℝ, |halfSign (a - x) - halfSign (b - x)|) ≤ b - a := by
  have hg : Integrable ((Icc a b).indicator (fun _ : ℝ => (1 : ℝ))) := by
    rw [integrable_indicator_iff measurableSet_Icc]
    exact integrableOn_const.mpr (Or.inr (by simp))
  calc
    _ ≤ ∫ x : ℝ, (Icc a b).indicator (fun _ : ℝ => (1 : ℝ)) x :=
      integral_mono (integrable_halfSign_difference a b hab) hg
        (fun x => halfSign_difference_bound a b x hab)
    _ = b - a := by simp [integral_indicator, measurableSet_Icc, hab]

end SYK.Thermal
