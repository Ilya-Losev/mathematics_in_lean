import ThermalResidualState

/-!
# The right inserted Ward equation follows from the left one

Actual inserted skewness reverses each of the four bilocals. Bounded measurable
Fubini then exchanges the two genuine thermal integration variables.
-/

set_option maxHeartbeats 1200000

noncomputable section
namespace SYK.ThermalWardSymmetry
open SYK.WeightedKernelAlgebra SYK.ThermalEndpointLift SYK.ThermalMomentTransport
open SYK.MomentLimit SYK.MomentCompactness SYK.MixedIncrement SYK.ThermalWeightedState
open SYK.ThermalResidualState
open MeasureTheory Filter Set
open scoped BigOperators Topology NNReal

section PolynomialSkew
variable (L : RealPolynomial →ₗ[ℂ] ℂ)
  (hskew : ∀ Q s t, L (Q * MvPolynomial.X (t,s)) = -L (Q * MvPolynomial.X (s,t)))

include hskew in
/-- Reversing every bilocal contributes precisely one sign per occurrence. -/
theorem inserted_flip_product (p : List Endpoint) (Q : RealPolynomial) :
    L (Q * coordinateProduct (p.map Prod.swap)) =
      (-1 : ℂ)^p.length * L (Q * coordinateProduct p) := by
  induction p generalizing Q with
  | nil => simp
  | cons a p ih =>
    simp only [List.map_cons, coordinateProduct_cons, List.length_cons]
    calc
      _ = L ((Q * coordinateProduct (p.map Prod.swap)) * MvPolynomial.X a.swap) := by congr 1; ring
      _ = -L ((Q * coordinateProduct (p.map Prod.swap)) * MvPolynomial.X a) := hskew _ a.1 a.2
      _ = -L ((Q * MvPolynomial.X a) * coordinateProduct (p.map Prod.swap)) := by congr 2; ring
      _ = -((-1 : ℂ)^p.length * L ((Q * MvPolynomial.X a) * coordinateProduct p)) := by rw [ih]
      _ = (-1 : ℂ)^(p.length+1) * L (Q * (MvPolynomial.X a * coordinateProduct p)) := by
        rw [pow_succ, mul_assoc Q]
        ring

include hskew in
theorem inserted_reverse_four (Q : RealPolynomial) (s u v : ℝ) :
    L (Q * coordinateProduct [(u,v),(u,v),(u,v),(v,s)]) =
      L (Q * coordinateProduct [(s,v),(v,u),(v,u),(v,u)]) := by
  have h := inserted_flip_product L hskew [(u,v),(u,v),(u,v),(v,s)] Q
  norm_num only [List.length_cons, List.length_nil, pow_succ, pow_zero, mul_one,
    one_mul, neg_mul, mul_neg, neg_neg, List.map_cons, List.map_nil, Prod.swap_prod_mk] at h
  rw [← h]
  congr 1
  simp only [coordinateProduct_cons, coordinateProduct_nil]
  ring

include hskew in
theorem inserted_remainder_skew (β : ℝ) (Q : RealPolynomial) (s t : ℝ) :
    L (Q * SYK.MixedIncrement.remainder β (t,s)) =
      -L (Q * SYK.MixedIncrement.remainder β (s,t)) := by
  have hc (c : ℂ) : L (Q * MvPolynomial.C c) = c * L Q := by
    rw [mul_comm, MvPolynomial.C_mul', map_smul, smul_eq_mul]
  simp only [SYK.MixedIncrement.remainder, mul_sub, map_sub, hc]
  rw [hskew, Thermal.kernel_skew β s t, Complex.ofReal_neg]
  ring
end PolynomialSkew

variable (β : ℝ) (hβ : 0 < β) (lam : ℝ≥0) (d : ℕ → ℕ) (hd : ∀ n, 0 < d n)
  (g : ∀ k, EndpointCube β k → ℂ)
  (hg : ∀ k, TendstoUniformly
    (fun n => functionalCenteredMoment (actualCorrectedPolynomial β hβ (d n) lam)) (g k) atTop)

include hd hg in
/-- The actual limiting right inserted Ward identity requires no independent
microscopic premise once the left identity is known. -/
theorem rightWard_of_left
    (hleft : LeftWard β (lam : ℝ) (polynomialState β hβ g)) :
    RightWard β (lam : ℝ) (polynomialState β hβ g) := by
  let L : RealPolynomial →ₗ[ℂ] ℂ := polynomialState β hβ g
  have hLb : ∀ P, ‖L P‖ ≤ coefficientNorm (fun _ => (1/2:ℝ)) P :=
    thermalLimit_bound β hβ lam d g hg hd
  have hs : ∀ Q s t, L (Q * MvPolynomial.X (t,s)) = -L (Q * MvPolynomial.X (s,t)) :=
    thermalLimit_inserted_skew β hβ lam d g hg
  intro Q s t
  let F : ℝ → ℝ → ℂ := fun u v => (Thermal.kernel β v t : ℂ) *
    L (Q * coordinateProduct [(s,u),(u,v),(u,v),(u,v)])
  have hm : Measurable (Function.uncurry F) := by
    have hh := thermalLimit_inserted_measurable β hβ lam d g hg Q
      (fun p : ℝ×ℝ => ![(s,p.1),(p.1,p.2),(p.1,p.2),(p.1,p.2)]) (by
        intro i
        fin_cases i <;> dsimp <;> fun_prop)
    have hcoords : Measurable (fun p : ℝ×ℝ =>
        L (Q * coordinateProduct [(s,p.1),(p.1,p.2),(p.1,p.2),(p.1,p.2)])) := by
      simpa only [coordinateProduct, List.map_cons, List.map_nil, List.prod_cons,
        List.prod_nil, Fin.prod_univ_succ, Fin.prod_univ_zero, Fin.cons_zero,
        Fin.cons_succ, mul_one] using hh
    exact (Complex.measurable_ofReal.comp ((Thermal.covariance_measurable β).comp
      (measurable_snd.sub measurable_const))).mul hcoords
  have hb (u v : ℝ) : ‖F u v‖ ≤ (1/2 : ℝ) * (coefficientNorm (fun _ => (1/2:ℝ)) Q / 16) := by
    change ‖(Thermal.kernel β v t : ℂ) *
      L (Q * coordinateProduct [(s,u),(u,v),(u,v),(u,v)])‖ ≤ _
    rw [norm_mul, Complex.norm_real, Real.norm_eq_abs]
    exact mul_le_mul (Thermal.abs_covariance_le β _)
      (inserted_four_bound L hLb Q [(s,u),(u,v),(u,v),(u,v)] rfl)
      (norm_nonneg _) (by norm_num)
  let μ := volume.restrict (Ioc (0:ℝ) β)
  have hi : Integrable (Function.uncurry F) (μ.prod μ) :=
    (integrable_const ((1/2 : ℝ) * (coefficientNorm (fun _ => (1/2:ℝ)) Q / 16))).mono'
      hm.aestronglyMeasurable (Eventually.of_forall (fun p => hb p.1 p.2))
  have hswap : (∫ u in (0:ℝ)..β, ∫ v in (0:ℝ)..β, F v u) =
      ∫ u in (0:ℝ)..β, ∫ v in (0:ℝ)..β, F u v := by
    simp only [intervalIntegral.integral_of_le hβ.le]
    exact (integral_integral_swap hi).symm
  have hpoint (u v : ℝ) : (Thermal.kernel β t u : ℂ) *
      L (Q * coordinateProduct [(u,v),(u,v),(u,v),(v,s)]) = -(F v u) := by
    rw [inserted_reverse_four L hs, Thermal.kernel_skew β u t, Complex.ofReal_neg]
    simp only [F, neg_mul]
  have h := hleft Q t s
  rw [inserted_remainder_skew L hs β Q s t] at h
  change -L (Q * SYK.MixedIncrement.remainder β (s,t)) = (lam : ℂ) *
    (∫ u in (0:ℝ)..β, ∫ v in (0:ℝ)..β, (Thermal.kernel β t u : ℂ) *
      L (Q * coordinateProduct [(u,v),(u,v),(u,v),(v,s)])) at h
  simp only [hpoint, intervalIntegral.integral_neg] at h
  rw [hswap] at h
  change -L (Q * SYK.MixedIncrement.remainder β (s,t)) = (lam : ℂ) *
    -(∫ u in (0:ℝ)..β, ∫ v in (0:ℝ)..β, F u v) at h
  rw [mul_neg, neg_inj] at h
  exact h

end SYK.ThermalWardSymmetry
