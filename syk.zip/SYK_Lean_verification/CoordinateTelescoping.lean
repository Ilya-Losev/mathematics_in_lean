import Mathlib.Topology.MetricSpace.Pseudo.Pi
import Mathlib.Analysis.Normed.Module.Basic
import Mathlib.Algebra.BigOperators.Fin
import Mathlib.Tactic

noncomputable section
open scoped BigOperators
namespace SYK

/-- A coordinatewise Lipschitz estimate with a fixed defect telescopes to
all finite tuples, even when the function itself is discontinuous. -/
theorem coordinate_defect_sum_bound {A E : Type*} [PseudoMetricSpace A]
    [SeminormedAddCommGroup E] (n : ℕ) (F : (Fin n → A) → E) (K ε : ℝ)
    (hsingle : ∀ (p q : Fin n → A) (i : Fin n),
      (∀ j, j ≠ i → p j=q j) → ‖F p-F q‖ ≤ K*dist (p i) (q i)+ε)
    (p q : Fin n → A) :
    ‖F p-F q‖ ≤ K*(∑ i, dist (p i) (q i))+(n:ℝ)*ε := by
  induction n with
  | zero =>
    have hpq : p=q := funext (fun i => Fin.elim0 i)
    simp [hpq]
  | succ n ih =>
    let r : Fin (n+1) → A := Fin.cons (q 0) (fun i => p i.succ)
    have h₁ : ‖F p-F r‖ ≤ K*dist (p 0) (q 0)+ε := by
      have hx := hsingle p r 0 (by
        intro j hj
        obtain ⟨i,rfl⟩ := Fin.eq_succ_of_ne_zero hj
        simp [r])
      simpa [r] using hx
    let G := fun a : Fin n → A => F (Fin.cons (q 0) a)
    have hG : ∀ (a b : Fin n → A) (i : Fin n),
        (∀ j, j ≠ i → a j=b j) → ‖G a-G b‖ ≤ K*dist (a i) (b i)+ε := by
      intro a b i hab
      have hx := hsingle (Fin.cons (q 0) a) (Fin.cons (q 0) b) i.succ (by
        intro j
        refine Fin.cases ?_ (fun j => ?_) j
        · intro _; simp
        · intro hj
          simp only [Fin.cons_succ]
          exact hab j (fun he => hj (congrArg Fin.succ he)))
      simpa [G] using hx
    have h₂ := ih G hG (fun i => p i.succ) (fun i => q i.succ)
    have heq : Fin.cons (q 0) (fun i => q i.succ)=q := by ext i; exact Fin.cases rfl (fun _ => rfl) i
    change ‖F r-F (Fin.cons (q 0) (fun i => q i.succ))‖ ≤ _ at h₂
    rw [heq] at h₂
    have htri : ‖F p-F q‖ ≤ ‖F p-F r‖+‖F r-F q‖ := by
      simpa only [dist_eq_norm] using dist_triangle (F p) (F r) (F q)
    have ht := htri.trans (add_le_add h₁ h₂)
    rw [Fin.sum_univ_succ]
    push_cast
    nlinarith

/-- The same estimate in the actual supremum metric on endpoint tuples. -/
theorem coordinate_defect_max_bound {A E : Type*} [PseudoMetricSpace A]
    [SeminormedAddCommGroup E] (n : ℕ) (F : (Fin n → A) → E) (K ε : ℝ) (hK : 0 ≤ K)
    (hsingle : ∀ (p q : Fin n → A) (i : Fin n),
      (∀ j, j ≠ i → p j=q j) → ‖F p-F q‖ ≤ K*dist (p i) (q i)+ε)
    (p q : Fin n → A) :
    ‖F p-F q‖ ≤ (n:ℝ)*K*dist p q+(n:ℝ)*ε := by
  apply (coordinate_defect_sum_bound n F K ε hsingle p q).trans
  have hsum : (∑ i, dist (p i) (q i)) ≤ (n:ℝ)*dist p q := by
    simpa using Finset.sum_le_sum (fun i (_ : i ∈ (Finset.univ : Finset (Fin n))) => dist_le_pi_dist p q i)
  nlinarith [mul_le_mul_of_nonneg_left hsum hK]

end SYK
