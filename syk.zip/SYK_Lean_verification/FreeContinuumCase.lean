import FermionicFourier

/-!
The free-coupling base case is end-to-end: the concrete finite-dimensional
partition function, its Gaussian disorder law, and the prescribed continuum
Fourier class all enter the same theorem. The interacting theorem remains
separate and is not inferred from this base case.
-/
noncomputable section
open Filter
open scoped Topology NNReal
namespace SYK.Continuum

@[simp] theorem couplingPressure_zero (β : ℝ) (g : ℝ≥0 → ℝ → ℝ) :
    couplingPressure β g 0 = Real.log 2 / 2 := by
  simp [couplingPressure]

theorem free_pressure_convergence (β : ℝ) :
    PressureConvergence β 0 (Real.log 2 / 2) := by
  constructor
  · apply Filter.Tendsto.congr' (f₁ := fun _ : ℕ => Real.log 2 / 2)
      (f₂ := fun m => Microscopic.annealedPressure m β 0)
    · filter_upwards [eventually_ge_atTop 1] with m hm
      exact (Microscopic.annealedPressure_free m (by omega) β).symm
    · exact tendsto_const_nhds
  · apply Filter.Tendsto.congr' (f₁ := fun _ : ℕ => Real.log 2 / 2)
      (f₂ := fun m => Microscopic.quenchedPressure m β 0)
    · filter_upwards [eventually_ge_atTop 1] with m hm
      exact (Microscopic.quenchedPressure_free m (by omega) β).symm
    · exact tendsto_const_nhds

theorem free_continuum_case (β : ℝ) (hβ : 0 < β) :
    (∃! g : ℝ → ℝ, PhysicalSolution β 0 g) ∧
      PressureConvergence β 0 (Real.log 2 / 2) := by
  refine ⟨⟨Thermal.covariance β, free_physicalSolution β hβ, ?_⟩,
    free_pressure_convergence β⟩
  intro g hg
  exact physicalSolution_zero_unique β g hg

end SYK.Continuum
