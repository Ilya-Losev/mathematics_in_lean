import IntegralMomentSeries

/-! # Integrability of the fully summed interacting insertion series -/
noncomputable section
open MeasureTheory Filter Set
open scoped Topology BigOperators
namespace SYK.ExponentialMomentSeries
variable {Ω : Type*} [MeasurableSpace Ω] (μ : Measure Ω) [IsFiniteMeasure μ]

omit [IsFiniteMeasure μ] in
theorem aestronglyMeasurable_value (b : Ω → ℕ → ℂ) (K R : ℝ) (hK : 0 ≤ K) (hR : 0 ≤ R)
    (hmeas : ∀ n, AEStronglyMeasurable (fun x => b x n) μ)
    (hb : ∀ x n, ‖b x n‖ ≤ K*R^n) (l : ℝ) :
    AEStronglyMeasurable (fun x => value (b x) l) μ := by
  apply aestronglyMeasurable_of_tendsto_ae atTop
    (f := fun n x => ∑ k ∈ Finset.range n, term (b x) l k)
  · intro n
    exact Finset.aestronglyMeasurable_sum _ (fun k _ => (hmeas k).const_smul _)
  · exact ae_of_all _ (fun x => (summable_term (b x) K R hK hR (hb x) l).hasSum.tendsto_sum_nat)

/-- The summed function is dominated by a finite scalar exponential series,
so the time integral is a genuine integrable function, not a totalized fallback. -/
theorem integrable_value (b : Ω → ℕ → ℂ) (K R : ℝ) (hK : 0 ≤ K) (hR : 0 ≤ R)
    (hmeas : ∀ n, AEStronglyMeasurable (fun x => b x n) μ)
    (hb : ∀ x n, ‖b x n‖ ≤ K*R^n) (l : ℝ) :
    Integrable (fun x => value (b x) l) μ := by
  have hsum := (Real.summable_pow_div_factorial (|l| * R)).mul_left K
  apply (integrable_const (∑' n : ℕ, K*((|l| * R)^n / (n.factorial : ℝ)))).mono'
    (aestronglyMeasurable_value μ b K R hK hR hmeas hb l)
  apply ae_of_all
  intro x
  apply (norm_tsum_le_tsum_norm (summable_norm_term (b x) K R hK hR (hb x) l)).trans
  exact (summable_norm_term (b x) K R hK hR (hb x) l).tsum_le_tsum
    (norm_term_le (b x) K R (hb x) l) hsum

end SYK.ExponentialMomentSeries
