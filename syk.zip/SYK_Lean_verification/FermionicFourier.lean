import ContinuumDefinitions
import Mathlib.Analysis.SpecialFunctions.Integrals

/-! Exact free-covariance Fourier normalization, with the manuscript's sign. -/
noncomputable section
open MeasureTheory Set
open scoped Topology ComplexConjugate
namespace SYK.Continuum

theorem frequency_pos (β : ℝ) (hβ : 0 < β) (n : ℕ) : 0 < frequency β n := by
  unfold frequency
  positivity

theorem frequency_phase (β : ℝ) (hβ : 0 < β) (n : ℕ) :
    Complex.exp (Complex.I * (frequency β n : ℂ) * (β : ℂ)) = -1 := by
  have hb : (β : ℂ) ≠ 0 := Complex.ofReal_ne_zero.mpr hβ.ne'
  have he : Complex.I * (frequency β n : ℂ) * (β : ℂ) =
      (n : ℂ) * (2 * (Real.pi : ℂ) * Complex.I) + (Real.pi : ℂ) * Complex.I := by
    unfold frequency
    push_cast
    field_simp
    <;> ring
  rw [he, Complex.exp_add, Complex.exp_nat_mul_two_pi_mul_I, Complex.exp_pi_mul_I]
  simp

theorem free_fourier_general (β : ℝ) (hβ : 0 < β) (ω : ℝ) (hω : ω ≠ 0) :
    fourier β (Thermal.covariance β) ω =
      ((Complex.exp (Complex.I * (ω : ℂ) * (β : ℂ)) - 1) /
        (Complex.I * (ω : ℂ))) * (1 / 2 : ℂ) := by
  have hreplace : fourier β (Thermal.covariance β) ω =
      ∫ t in (0 : ℝ)..β, Complex.exp ((Complex.I * (ω : ℂ)) * t) * (1 / 2 : ℂ) := by
    apply intervalIntegral.integral_congr_ae
    have he : ∀ᵐ t : ℝ, t ≠ β := by simp [ae_iff]
    filter_upwards [he] with t ht hmem
    have hm : t ∈ Ioc (0 : ℝ) β := by
      simpa only [uIoc_of_le hβ.le] using hmem
    have hlt : t < β := lt_of_le_of_ne hm.2 ht
    rw [Thermal.covariance_on_interval β hβ t hm.1 hlt]
    push_cast
    ring_nf
  rw [hreplace, intervalIntegral.integral_mul_const]
  rw [integral_exp_mul_complex (mul_ne_zero Complex.I_ne_zero
    (Complex.ofReal_ne_zero.mpr hω))]
  simp

theorem free_fourier (β : ℝ) (hβ : 0 < β) (n : ℕ) :
    fourier β (Thermal.covariance β) (frequency β n) =
      Complex.I / (frequency β n : ℂ) := by
  rw [free_fourier_general β hβ _ (frequency_pos β hβ n).ne', frequency_phase β hβ n]
  have hw : (frequency β n : ℂ) ≠ 0 :=
    Complex.ofReal_ne_zero.mpr (frequency_pos β hβ n).ne'
  field_simp [hw]
  <;> ring_nf
  <;> simp [Complex.I_sq]

/-- At zero coupling the physical continuum solution is explicitly constructed. -/
theorem free_physicalSolution (β : ℝ) (hβ : 0 < β) :
    PhysicalSolution β 0 (Thermal.covariance β) := by
  refine ⟨Thermal.covariance_measurable β, ⟨1 / 2, ?_⟩, ?_,
    Thermal.covariance_zero β, ?_, ?_, (sd_zero_iff β _).mpr rfl⟩
  · intro t
    exact Thermal.abs_covariance_le β t
  · exact Thermal.covariance_antiperiodic β hβ.ne'
  · intro t
    have h := Thermal.covariance_antiperiodic β hβ.ne' (-t)
    rw [Thermal.covariance_neg] at h
    simpa [sub_eq_add_neg, add_comm] using h
  · intro n
    refine ⟨(frequency β n)⁻¹, inv_pos.mpr (frequency_pos β hβ n), ?_⟩
    rw [free_fourier β hβ n]
    simp [div_eq_mul_inv]

/-- Uniqueness at zero coupling uses the actual SD equation, not Fourier assumptions. -/
theorem physicalSolution_zero_unique (β : ℝ) (g : ℝ → ℝ)
    (hg : PhysicalSolution β 0 g) : g = Thermal.covariance β :=
  (sd_zero_iff β g).mp hg.2.2.2.2.2.2

/-- Reflection about the thermal midpoint forces purely imaginary fermionic coefficients. -/
theorem fourier_reflection (β : ℝ) (hβ : 0 < β) (g : ℝ → ℝ)
    (hsym : ∀ t, g (β - t) = g t) (n : ℕ) :
    fourier β g (frequency β n) = -conj (fourier β g (frequency β n)) := by
  let ω := frequency β n
  let f := fun t : ℝ => Complex.exp (Complex.I * (ω * t)) * (g t : ℂ)
  have hp (t : ℝ) : f (β - t) = -conj (f t) := by
    dsimp [f]
    rw [hsym]
    have he : Complex.I * ((ω * (β - t) : ℝ) : ℂ) =
        Complex.I * (ω : ℂ) * (β : ℂ) +
          conj (Complex.I * ((ω * t : ℝ) : ℂ)) := by
      simp only [Complex.ofReal_mul, Complex.ofReal_sub, map_mul,
        Complex.conj_I, Complex.conj_ofReal]
      ring
    simp only [Complex.ofReal_mul] at he
    rw [he, Complex.exp_add, frequency_phase β hβ n, Complex.exp_conj]
    simp
  have hreflect : (∫ t in (0 : ℝ)..β, f (β - t)) = ∫ t in (0 : ℝ)..β, f t := by
    simpa using intervalIntegral.integral_comp_sub_left f β (a := 0) (b := β)
  change (∫ t in (0 : ℝ)..β, f t) = -conj (∫ t in (0 : ℝ)..β, f t)
  calc
    _ = ∫ t in (0 : ℝ)..β, f (β - t) := hreflect.symm
    _ = ∫ t in (0 : ℝ)..β, -conj (f t) := by
      apply intervalIntegral.integral_congr
      intro t _
      exact hp t
    _ = -conj (∫ t in (0 : ℝ)..β, f t) := by
      rw [intervalIntegral.integral_neg]
      congr 1
      simp only [intervalIntegral, integral_conj, map_sub]

theorem fourier_re_zero (β : ℝ) (hβ : 0 < β) (g : ℝ → ℝ)
    (hsym : ∀ t, g (β - t) = g t) (n : ℕ) :
    (fourier β g (frequency β n)).re = 0 := by
  have h := congrArg Complex.re (fourier_reflection β hβ g hsym n)
  simp only [Complex.neg_re, Complex.conj_re] at h
  linarith

end SYK.Continuum
