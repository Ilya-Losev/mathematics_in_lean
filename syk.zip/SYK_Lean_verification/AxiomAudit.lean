import SYKLean

#print axioms SYK.ClosedIdeal.inserted_residuals_annihilate_span_with_insertion
#print axioms SYK.ClosedIdeal.inserted_residuals_annihilate_span
#print axioms SYK.ClosedIdeal.inserted_residuals_annihilate_closed_ideal
#print axioms SYK.ClosedIdeal.inserted_residuals_annihilate_closed_ideal_with_insertion
#print axioms SYK.ClosedIdeal.adding_closed_residual_preserves_expectation
#print axioms SYK.ClosedIdeal.quotient_representatives_have_equal_expectation
#print axioms SYK.shifts_into_half_circle
#print axioms SYK.analytic_curve_mem_closed_submodule
#print axioms SYK.every_generator_mem_of_analytic_orbits
#print axioms SYK.nonnegative_of_continuous_of_dense
#print axioms SYK.Translation.square_is_identity
#print axioms SYK.Translation.halving_action_is_trivial
#print axioms SYK.Translation.represented_observables_are_stationary
#print axioms SYK.Residuals.span_is_annihilated
#print axioms SYK.Residuals.quotientFunctional
#print axioms SYK.Residuals.quotientFunctional_preserves_values
#print axioms SYK.cubic_pairing_nonnegative
#print axioms SYK.coupled_cubic_pairing_nonnegative
#print axioms SYK.integral_cubic_pairing_nonnegative
#print axioms SYK.reciprocal_pairing_identity
#print axioms SYK.dyson_self_energy
#print axioms SYK.positive_of_nonnegative_dyson
#print axioms SYK.dyson_pairing_identity
#print axioms SYK.eq_of_reciprocal_pairing_nonnegative
#print axioms SYK.fourierEnergy_nonnegative
#print axioms SYK.coefficients_equal_of_two_signs
#print axioms SYK.coefficients_equal_of_parseval_and_dyson
#print axioms SYK.coefficients_equal_of_cubic_integral_comparison
#print axioms SYK.pressure_unique
#print axioms SYK.pressure_integral_formula
#print axioms SYK.pressure_limit_of_dominated_derivatives

#print axioms SYK.kernelCenterField_analyticAt
#print axioms SYK.kernelCenterField_analyticOnNhd
#print axioms SYK.norm_kernelCenterField_le
#print axioms SYK.norm_cube_sub_le
#print axioms SYK.norm_kernelCenterField_sub_le

#print axioms SYK.GaussianDisorder.law_isProbabilityMeasure
#print axioms SYK.GaussianDisorder.law_zero
#print axioms SYK.GaussianDisorder.integrable_exp_linear
#print axioms SYK.GaussianDisorder.integrable_exp_abs
#print axioms SYK.GaussianDisorder.integrable_exp_sum_abs
#print axioms SYK.GaussianDisorder.annealedPressure_zero
#print axioms SYK.GaussianDisorder.quenchedPressure_zero
#print axioms SYK.AntiCommuting.sum_square
#print axioms SYK.AntiCommuting.sum_state_sq_le_one
#print axioms SYK.AntiCommuting.densityState_positive
#print axioms SYK.AntiCommuting.density_sum_sq_le_one

#print axioms SYK.TranslationContraction.bounded_quadratic_sequence_le
#print axioms SYK.TranslationContraction.bounded_action_contractive
#print axioms SYK.TranslationContraction.bounded_action_preserves_null
#print axioms SYK.TranslationContraction.bounded_action_preserves
#print axioms SYK.TranslationContraction.reflection_cauchy_schwarz
#print axioms SYK.TranslationContraction.reflection_square_bound
#print axioms SYK.TranslationContraction.reflection_action_symmetric
#print axioms SYK.TranslationContraction.reflection_action_quadratic
#print axioms SYK.TranslationContraction.reflection_action_preserves_square
#print axioms SYK.TranslationContraction.reflection_action_preserves_seminorm
#print axioms SYK.TranslationContraction.reflection_translation_difference_null
#print axioms SYK.TranslationContraction.reflection_translation_class_stationary

#print axioms SYK.Thermal.covariance_zero
#print axioms SYK.Thermal.covariance_neg
#print axioms SYK.Thermal.covariance_antiperiodic
#print axioms SYK.Thermal.covariance_on_interval
#print axioms SYK.Thermal.abs_covariance_le
#print axioms SYK.Thermal.kernel_diagonal
#print axioms SYK.Thermal.kernel_skew
#print axioms SYK.Thermal.kernel_translation

#print axioms SYK.AntiCommuting.density_normalized_common_triple_bound

#print axioms SYK.Wick.Covariance.expectation_ι_mul
#print axioms SYK.Wick.Covariance.contraction_mul
#print axioms SYK.Wick.Covariance.expectation_ward_split
#print axioms SYK.Wick.Covariance.expectation_four
#print axioms SYK.Wick.Covariance.repeated_generator
#print axioms SYK.Wick.Covariance.expectation_radical_inserted
#print axioms SYK.Wick.flavor_collective_contraction
#print axioms SYK.Wick.covarianceOfKernel
#print axioms SYK.Wick.kernel_expectation_two

#print axioms SYK.AntiCommuting.perm_expectation_sq
#print axioms SYK.AntiCommuting.count_triples_in_fourset
#print axioms SYK.AntiCommuting.quartic_sum_bound_of_triple_bounds

#print axioms SYK.Majorana.chi_car
#print axioms SYK.Majorana.normalizedTrace_chi_mul
#print axioms SYK.Majorana.chiFin_car
#print axioms SYK.Majorana.quartic_star
#print axioms SYK.Majorana.norm_quartic
#print axioms SYK.Majorana.hamiltonian_star
#print axioms SYK.Majorana.norm_hamiltonian_le
#print axioms SYK.Majorana.partitionFunction_zero
#print axioms SYK.Majorana.pressure_zero

#print axioms SYK.Thermal.covariance_measurable
#print axioms SYK.Thermal.kernel_measurable

#print axioms SYK.Gibbs.exp_posDef
#print axioms SYK.Gibbs.density_posSemidef
#print axioms SYK.Gibbs.density_trace_one
#print axioms SYK.Gibbs.syk_partition_re_pos
#print axioms SYK.Gibbs.syk_partition_im_zero
#print axioms SYK.Gibbs.syk_common_triple_bound
#print axioms SYK.GNS.GNSHilbert.representationStarAlgHom
#print axioms SYK.GNS.GNSHilbert.norm_representation_le
#print axioms SYK.GNS.GNSHilbert.vector_state
#print axioms SYK.GNS.GNSHilbert.cyclic
#print axioms SYK.GNS.GNSHilbert.represented_observables_stationary

#print axioms SYK.ThermalWick.kernel_skew
#print axioms SYK.ThermalWick.expectation_two
#print axioms SYK.ThermalWick.contraction_collective
#print axioms SYK.ThermalWick.collective_diagonal
#print axioms SYK.ThermalWick.collective_even
#print axioms SYK.ThermalWick.collective_skew
#print axioms SYK.ThermalWick.expectation_collective
#print axioms SYK.ThermalWick.expectation_collective_square
#print axioms SYK.exists_analytic_fixedPoint_branch
#print axioms SYK.real_ode_analyticAt_zero_of_path_lift
#print axioms SYK.kernelCenterField_ode_analytic

#print axioms SYK.kernelCenterField_eval_mem_of_open_seed

#print axioms SYK.Majorana.norm_partitionFunction_le
#print axioms SYK.Majorana.continuous_partitionFunction

#print axioms SYK.Microscopic.partitionFunction_integrable
#print axioms SYK.Microscopic.real_partitionFunction_integrable
#print axioms SYK.Microscopic.annealedPressure_free
#print axioms SYK.Microscopic.quenchedPressure_free
#print axioms SYK.Thermal.halfSign_difference_bound
#print axioms SYK.Thermal.integrable_halfSign_difference
#print axioms SYK.Thermal.integral_halfSign_difference_le

#print axioms SYK.Gibbs.exp_neg_norm_le_trace_exp
#print axioms SYK.Gibbs.syk_partition_re_lower
#print axioms SYK.Gibbs.abs_log_syk_partition_le
#print axioms SYK.Gibbs.trace_exp_re_eq_sum
#print axioms SYK.Gibbs.eigenvalue_abs_le_norm

#print axioms SYK.Continuum.sd_zero_iff

#print axioms SYK.Microscopic.annealed_partition_pos
#print axioms SYK.Microscopic.coupling_size_integrable
#print axioms SYK.Microscopic.log_partitionFunction_integrable
#print axioms SYK.Microscopic.quenchedPressure_le_annealedPressure
#print axioms SYK.Spectral.gns_spectral_integral
#print axioms SYK.Spectral.gnsSpectralMeasure_isProbability
#print axioms SYK.Spectral.spectral_integral
#print axioms SYK.Spectral.spectralEvaluation_integral
#print axioms SYK.Spectral.spectral_value_stationary
#print axioms SYK.Spectral.spectral_value_real_of_reflected_translate

#print axioms SYK.FreeWick.majorana_wick_recursion
#print axioms SYK.FreeWick.ordered_thermal_trace
#print axioms SYK.FreeWick.weakly_ordered_thermal_trace
#print axioms SYK.FreeWick.weylBlock_eq_zero_of_repeat
#print axioms SYK.FreeWick.weyl_block_thermal_trace

#print axioms SYK.Continuum.frequency_phase
#print axioms SYK.Continuum.free_fourier
#print axioms SYK.Continuum.free_physicalSolution
#print axioms SYK.Continuum.fourier_reflection
#print axioms SYK.Continuum.fourier_re_zero
#print axioms SYK.Continuum.free_pressure_convergence
#print axioms SYK.Continuum.free_continuum_case

#print axioms SYK.DuhamelTrace.hasDerivAt_trace_exp_affine_zero
#print axioms SYK.DuhamelTrace.hasDerivAt_matrix_trace_exp_affine_zero
#print axioms SYK.DuhamelTrace.hasDerivAt_syk_log_partition_direction
#print axioms SYK.DuhamelTrace.hasDerivAt_syk_log_partition_direction_at
#print axioms SYK.Ward.contraction_pow_succ
#print axioms SYK.Ward.contraction_list_prod_sum
#print axioms SYK.Ward.truncated_exponential_ward
#print axioms SYK.Ward.nilpotent_exponential_ward
#print axioms SYK.Ward.exponential_ward_of_summable
#print axioms SYK.Ward.partnerContraction_contact_sign
#print axioms SYK.Ward.partnerContraction_monomial
#print axioms SYK.Ward.contraction_quarticDensity
#print axioms SYK.Ward.normalized_quartic_partner

#print axioms SYK.isClosed_strongKernelAlgebra
#print axioms SYK.freeThermalKernel_norm_le
#print axioms SYK.translateKernel_norm
#print axioms SYK.translateKernel_lipschitz
#print axioms SYK.kernelConvolutionValue_stronglyMeasurable
#print axioms SYK.kernelConvolutionCLM_norm_le
#print axioms SYK.concreteKernel_ode_analytic

#print axioms SYK.Continuum.fermionic_parseval
#print axioms SYK.Continuum.fermionic_fourier_zero_ae
#print axioms SYK.Continuum.fermionic_fourier_zero_on_interval
#print axioms SYK.Continuum.fourier_integrable
#print axioms SYK.Continuum.fermionic_fourier_injective_on_interval

#print axioms SYK.GaussianDisorder.law_scale
#print axioms SYK.Microscopic.disorder_scale

#print axioms SYK.WeightedKernelAlgebra.coefficientNorm_mul_le
#print axioms SYK.WeightedKernelAlgebra.WeightedAlgebra.momentFunctional_bound
#print axioms SYK.WeightedKernelAlgebra.RelationQuotient.nontrivial_of_normalized_moments
#print axioms SYK.WeightedKernelAlgebra.norm_remainder_sub_le
#print axioms SYK.WeightedKernelAlgebra.remainder_continuous

#print axioms SYK.ThermalRP.reflected_circle_eq_star_mul
#print axioms SYK.ThermalRP.weyl_reversal_is_star
#print axioms SYK.ThermalRP.reflected_bilocal_positive
#print axioms SYK.ThermalRP.trace_evaluate_integrable
#print axioms SYK.ThermalRP.annealedValue_nonnegative

#print axioms SYK.GaussianIBP.centered_stein_identity
#print axioms SYK.GaussianIBP.hasDerivAt_syk_partition_direction_at
#print axioms SYK.GaussianIBP.syk_partition_stein_variance

#print axioms SYK.Continuum.rectangle_shear
#print axioms SYK.Continuum.diagonal_exponential_integral
#print axioms SYK.Continuum.diagonal_fiber_integral
#print axioms SYK.Continuum.hankel_fourier_test_general
#print axioms SYK.Continuum.hankel_fourier_test

#print axioms SYK.Continuum.fourier_scalarConvolution
#print axioms SYK.Continuum.scalarConvolution_measurable
#print axioms SYK.Continuum.scalarConvolution_bound
#print axioms SYK.Continuum.scalarConvolution_antiperiodic
#print axioms SYK.Continuum.stationary_convolution

#print axioms SYK.integratedSD_endpoint_derivatives
#print axioms SYK.integratedSD_center_ode
#print axioms SYK.integratedSD_center_analytic

#print axioms SYK.AnnealedDifferentiation.hasDerivAt_averagedPartition
#print axioms SYK.AnnealedDifferentiation.continuous_annealedPressure
#print axioms SYK.AnnealedDifferentiation.hasDerivAt_annealedPressure_pos
#print axioms SYK.AnnealedDifferentiation.tendsto_annealedPressure_zero

#print axioms SYK.KernelResidualAlgebra.sdAlgebra_nontrivial
#print axioms SYK.KernelResidualAlgebra.final_left_sd
#print axioms SYK.KernelResidualAlgebra.final_right_sd
#print axioms SYK.KernelResidualAlgebra.norm_finalRemainder_sub_le
#print axioms SYK.KernelResidualAlgebra.finalCovariance_eq_free

#print axioms SYK.Continuum.fourier_sd
#print axioms SYK.Continuum.scalar_dyson
#print axioms SYK.Continuum.physical_scalar_dyson

#print axioms SYK.reflectKernel_norm_le
#print axioms SYK.reflectKernel_translate
#print axioms SYK.reflectKernel_convolution

#print axioms SYK.ThermalBound.norm_trace_positive_mul_le
#print axioms SYK.ThermalBound.heat_imag_unitary
#print axioms SYK.ThermalBound.admissible_convex
#print axioms SYK.ThermalBound.thermal_history_bound
#print axioms SYK.ThermalBound.matrix_history_bound
#print axioms SYK.ThermalBound.transfer_product_bound
#print axioms SYK.ThermalBound.normalized_history_bound
#print axioms SYK.ThermalBound.majorana_history_bound
#print axioms SYK.ThermalBound.majorana_even_history_bound

#print axioms SYK.ConvolutionRegularity.continuous_cube_G_convolution
#print axioms SYK.ConvolutionRegularity.continuous_G_cube_convolution
#print axioms SYK.ConvolutionRegularity.G_cube_convolution_left

#print axioms SYK.integratedSD_analytic_of_endpoint_lipschitz
#print axioms SYK.integratedSD_coordinate_orbit_analytic
#print axioms SYK.integratedSD_all_coordinates_mem_half_algebra

#print axioms SYK.GlobalGradient.quartic_expectation_sq_sum_le
#print axioms SYK.GlobalGradient.variance_mul_logGradient_sq_sum_le
#print axioms SYK.GlobalGradient.hasDerivAt_logPartition_line

#print axioms SYK.HankelPositivity.integral_nonnegative_of_finite_sums
#print axioms SYK.HankelPositivity.hankel_integral_nonnegative
#print axioms SYK.HankelPositivity.fermionic_sine_integral_nonnegative

#print axioms SYK.Continuum.physical_integer_signs
#print axioms SYK.Continuum.physical_integer_product_pos
#print axioms SYK.Continuum.physical_integer_dyson

#print axioms SYK.Continuum.physical_pairing_parseval
#print axioms SYK.Continuum.physical_fourier_coefficients_equal
#print axioms SYK.Continuum.physical_unique_ae
#print axioms SYK.Continuum.physical_unique

#print axioms SYK.KernelQuotientAnalyticity.thermalFinal_integratedSD
#print axioms SYK.KernelQuotientAnalyticity.thermalFinal_remainder_lipschitz
#print axioms SYK.KernelQuotientAnalyticity.thermalFinal_coordinate_analytic
#print axioms SYK.KernelQuotientAnalyticity.thermalFinal_all_coordinates_mem_half_algebra

#print axioms SYK.KernelCoordinateGeneration.closed_subalgebra_eq_top_of_coordinates
#print axioms SYK.KernelCoordinateGeneration.final_closed_subalgebra_eq_top
#print axioms SYK.KernelCoordinateGeneration.finalKernel_antiperiodic
#print axioms SYK.KernelCoordinateGeneration.finalKernel_skew
#print axioms SYK.KernelCoordinateGeneration.finalKernel_diagonal

#print axioms SYK.Continuum.fourier_im_sine
#print axioms SYK.Continuum.physical_of_hankel_sd
#print axioms SYK.Continuum.hankel_sd_unique

#print axioms SYK.LogPartitionDifferential.hasFDerivAt_logPartition
#print axioms SYK.LogPartitionDifferential.hasDerivAt_logPartition_curve
#print axioms SYK.LogPartitionDifferential.continuous_logGradient

#print axioms SYK.ProductGaussianMGF.integrable_exp_sum_linear
#print axioms SYK.ProductGaussianMGF.integral_exp_sum_linear
#print axioms SYK.ProductGaussianMGF.integrable_exp_pair_abs
#print axioms SYK.ProductGaussianMGF.integral_exp_dot_le

#print axioms SYK.GaussianRotation.pair_characteristic
#print axioms SYK.GaussianRotation.pair_measurePreserving
#print axioms SYK.GaussianRotation.array_measurePreserving
#print axioms SYK.GaussianRotation.hasDerivAt_rotateArray_first

#print axioms SYK.Interacting.collectiveMoment_bound
#print axioms SYK.Interacting.collectiveMoment_empty
#print axioms SYK.Interacting.collectiveNumerator_integrable
#print axioms SYK.Interacting.weylNumerator_bound
#print axioms SYK.Interacting.weylNumerator_integrable
#print axioms SYK.Interacting.weylNumerator_eq_zero_of_repeat
#print axioms SYK.Interacting.weylNumerator_constant
#print axioms SYK.Interacting.timeProduct_bound

#print axioms SYK.MomentCompactness.uniformCauchy_of_dense
#print axioms SYK.MomentCompactness.diagonal_uniform_subsequence
#print axioms SYK.MomentCompactness.uniform_subsequence
#print axioms SYK.MomentCompactness.complex_diagonal_uniform_subsequence
#print axioms SYK.MomentCompactness.endpoint_moment_subsequence

#print axioms SYK.ThermalHalfGeneration.coordinate_orbit_analytic
#print axioms SYK.ThermalHalfGeneration.closed_half_algebra_eq_top

#print axioms SYK.KernelAlgebraActions.coefficientNorm_rename
#print axioms SYK.KernelAlgebraActions.coefficientNorm_conjugate
#print axioms SYK.KernelAlgebraActions.quotientRingEquiv_isometry
#print axioms SYK.KernelAlgebraActions.translation_add
#print axioms SYK.KernelAlgebraActions.reflection_translation
#print axioms SYK.KernelAlgebraActions.completedMoment_invariant

#print axioms SYK.PisierPath.exp_logPartition_sub_le
#print axioms SYK.PisierPath.exp_sub_le_integral_exp_derivative

#print axioms SYK.Continuum.logAction_summable
#print axioms SYK.Continuum.relativeProduct_pos
#print axioms SYK.Continuum.log_relativeProduct
#print axioms SYK.Continuum.logAction_tangent
#print axioms SYK.Continuum.paired_product_log

#print axioms SYK.Continuum.fourier_tendsto_bounded
#print axioms SYK.Continuum.scalarConvolution_tendsto_bounded
#print axioms SYK.Continuum.physical_closed_bounded_pointwise

#print axioms SYK.KernelQuotientActions.translation_preserves_firstIdeal
#print axioms SYK.KernelQuotientActions.reflection_preserves_firstIdeal
#print axioms SYK.KernelQuotientActions.firstTranslation_isometry
#print axioms SYK.KernelQuotientActions.firstReflection_isometry
#print axioms SYK.KernelQuotientActions.firstTranslation_add
#print axioms SYK.KernelQuotientActions.firstReflection_translation

#print axioms SYK.GaussianConcentration.integral_exp_logPartition_difference_le

#print axioms SYK.FreeWeyl.free_weyl_eq_expectation
#print axioms SYK.FreeWeyl.expectation_exteriorWord_bound
#print axioms SYK.FreeWeyl.expectation_word_bound
#print axioms SYK.FreeWeyl.expectation_word_collective_bound
#print axioms SYK.FreeWeyl.expectation_collectiveMonomial_bound

#print axioms SYK.PressureGap.annealed_sub_quenched_le
#print axioms SYK.PressureGap.tendsto_annealed_sub_quenched_zero
#print axioms SYK.PressureGap.quenched_limit_of_annealed_limit

#print axioms SYK.Continuum.periodic_eq_representative
#print axioms SYK.Continuum.periodic_uniform_subsequence

#print axioms SYK.KernelSelection.positiveFunctionalOfDense
#print axioms SYK.KernelSelection.exists_physical_factorization

#print axioms SYK.MomentSymmetry.weylNumerator_relabel
#print axioms SYK.MomentSymmetry.pairPerm_sign
#print axioms SYK.MomentSymmetry.collectiveMoment_relabel
#print axioms SYK.MomentSymmetry.collectiveMoment_flip
#print axioms SYK.MomentSymmetry.collectiveMoment_diagonal
#print axioms SYK.MomentSymmetry.collectiveMoment_list_perm

#print axioms SYK.KernelFinalActions.translation_preserves_secondIdeal
#print axioms SYK.KernelFinalActions.reflection_preserves_secondIdeal
#print axioms SYK.KernelFinalActions.finalTranslation_isometry
#print axioms SYK.KernelFinalActions.finalReflection_isometry
#print axioms SYK.KernelFinalActions.finalReflection_translation
#print axioms SYK.KernelFinalActions.finalFunctional_invariant_of_polynomial

#print axioms SYK.Continuum.physical_centered_lipschitz

#print axioms SYK.Continuum.physical_uniform_tendsto_of_bound
#print axioms SYK.Continuum.physical_family_continuous
#print axioms SYK.Continuum.physical_quartic_integral_continuous

#print axioms SYK.KernelActionBridge.invariant_of_polynomial
#print axioms SYK.KernelActionBridge.actionData

#print axioms SYK.ThermalKernelSelection.halfPolynomialAlgebra_dense
#print axioms SYK.ThermalKernelSelection.limitingPositiveState
#print axioms SYK.ThermalKernelSelection.exists_physical_factorization

#print axioms SYK.MomentMeasurability.measurable_timeProduct
#print axioms SYK.MomentMeasurability.measurableSet_antitone
#print axioms SYK.MomentMeasurability.measurable_weylNumerator
#print axioms SYK.MomentMeasurability.measurable_collectiveNumerator
#print axioms SYK.MomentMeasurability.measurable_collectiveMoment

#print axioms SYK.DiagonalFredholm.diagonal_apply
#print axioms SYK.DiagonalFredholm.diagonalNuclearExpansion
#print axioms SYK.DiagonalFredholm.finiteRank_tendsto
#print axioms SYK.DiagonalFredholm.compression_determinant
#print axioms SYK.DiagonalFredholm.compression_determinants_tendsto
#print axioms SYK.DiagonalFredholm.positive_compression_limit
#print axioms SYK.DiagonalFredholm.diagonal_selfAdjoint
#print axioms SYK.DiagonalFredholm.coordinateDeterminant_diagonal
#print axioms SYK.DiagonalFredholm.compression_determinants_along_cofinal

#print axioms SYK.Continuum.physical_right_endpoint
#print axioms SYK.Continuum.physical_left_endpoint

#print axioms SYK.KernelConstructedSelection.exists_physical_factorization

#print axioms SYK.Continuum.sourceRatio_summable
#print axioms SYK.Continuum.sourceRatio_factor_pos
#print axioms SYK.Continuum.onShellLog_tangent
#print axioms SYK.Continuum.onShellAction_bounds

#print axioms SYK.NilpotentSymmetricSum.sum_pow_eq_factorial_mul_powersetCard
#print axioms SYK.NilpotentSymmetricSum.sum_fourth_eq_twentyfour_mul_subsets

#print axioms SYK.ThermalWick.quartic_regrouping
#print axioms SYK.ThermalWick.gaussian_quartic_coefficient

#print axioms SYK.MixedIncrement.replacement_bound
#print axioms SYK.MixedIncrement.mixed_product_bound

#print axioms SYK.Continuum.hasDerivAt_familyAction
#print axioms SYK.Continuum.couplingPressure_eq_onShellAction
#print axioms SYK.Continuum.couplingPressure_eq_relative_log_action

#print axioms SYK.FourierOperators.physicalPerturbation_integral_action
#print axioms SYK.FourierOperators.physical_nuclear_expansion
#print axioms SYK.FourierOperators.physical_compression_determinants
#print axioms SYK.FourierOperators.physicalDeterminant_pos
#print axioms SYK.FourierOperators.physicalDeterminant_log

#print axioms SYK.ThermalEndpointLift.polynomialReduction_mixed
#print axioms SYK.ThermalEndpointLift.liftFunctional_bound
#print axioms SYK.ThermalEndpointLift.liftFunctional_tendsto
#print axioms SYK.ThermalEndpointLift.liftFunctional_seam_diagonal

#print axioms SYK.MomentLimit.actualPolynomial_tuple_prod
#print axioms SYK.MomentLimit.functional_centered_subsequence
#print axioms SYK.MomentLimit.functional_ward_limit
#print axioms SYK.MomentLimit.functional_limit_inserted_relations

#print axioms SYK.FourierOperators.couplingPressure_eq_physical_operator_action

#print axioms SYK.OrderedSimplexIntegral.orderedSimplex_volume
#print axioms SYK.OrderedSimplexIntegral.strictOrderedSimplex_ae_eq
#print axioms SYK.OrderedSimplexIntegral.integral_constant_interaction

#print axioms SYK.GaussianCoefficient.moment_even
#print axioms SYK.GaussianCoefficient.moment_odd
#print axioms SYK.GaussianCoefficient.integral_even_monomial_coefficient
#print axioms SYK.GaussianCoefficient.integral_monomial_odd

#print axioms SYK.MixedIncrement.replacement_of_inserted_ward

#print axioms SYK.OrderedCubePartition.orderingRegion_union_ae_cube
#print axioms SYK.OrderedCubePartition.integral_cube_eq_sum_ordered
#print axioms SYK.OrderedCubePartition.integral_cube_eq_factorial_smul_ordered

#print axioms SYK.DuhamelHistory.hasSum_gapCoefficient
#print axioms SYK.DuhamelHistory.syk_tsum_norm_gapCoefficient_le
#print axioms SYK.DuhamelHistory.gapCoefficient_integrable
#print axioms SYK.DuhamelHistory.summable_integral_norm_gapCoefficient
#print axioms SYK.DuhamelHistory.hasSum_integral_gapCoefficient

#print axioms SYK.GapSimplexIntegral.gapSimplex_volume_real
#print axioms SYK.GapSimplexIntegral.integral_gap_history
#print axioms SYK.GapSimplexIntegral.integral_gap_history_observable

#print axioms SYK.MixedIncrement.momentLinear_substitution

#print axioms SYK.GaussianCoefficient.integral_exponential_coefficient
#print axioms SYK.GaussianCoefficient.integral_linearSymbol_odd
#print axioms SYK.GaussianCoefficient.disorder_polynomial_coefficient

#print axioms SYK.ThermalMomentTransport.exists_actual_thermal_limit
#print axioms SYK.ThermalMomentTransport.actualThermal_moments_tendstoUniformly
#print axioms SYK.ThermalMomentTransport.actualThermal_ward_limit
#print axioms SYK.ThermalMomentTransport.thermalLimit_bound

#print axioms SYK.WeylBlocks.sortingPerms_append
#print axioms SYK.WeylBlocks.trace_weylTransfer
#print axioms SYK.WeylBlocks.timeProduct_append
#print axioms SYK.WeylBlocks.weylTransfer_append

#print axioms SYK.GapAssignmentPartition.assignmentRegion_union_ae_cube
#print axioms SYK.GapAssignmentPartition.orderedAssignmentRegion_eq_empty_of_not_monotone
#print axioms SYK.GapAssignmentPartition.integral_simplex_eq_sum_monotone_assignments

#print axioms SYK.DuhamelVertex.hamiltonian_history_expansion
#print axioms SYK.DuhamelVertex.ordered_vertex_trace_eq_wick
#print axioms SYK.DuhamelVertex.gapCoefficient_eq_integral
#print axioms SYK.DuhamelVertex.wick_inserted_vertex_history_bound

#print axioms SYK.ThermalWeightedState.polynomialState_replacement
#print axioms SYK.ThermalWeightedState.regularityState_polynomial
#print axioms SYK.ThermalWeightedState.regularityAlgebra_nontrivial
#print axioms SYK.ThermalWeightedState.actual_moments_to_regularityState

#print axioms SYK.SymmetricMomentFunctional.functional_tuple_prod

#print axioms SYK.ExponentialMomentSeries.hasDerivAt_value
#print axioms SYK.ExponentialMomentSeries.hasDerivAt_log_real_value

#print axioms SYK.GapChamberCoordinates.blockCoordinates_measurePreserving
#print axioms SYK.GapChamberCoordinates.orderedAssignmentRegion_ae_blocks
#print axioms SYK.GapChamberCoordinates.integral_orderedAssignmentRegion_eq_blocks

#print axioms SYK.SpectralFredholm.diagonal_compact
#print axioms SYK.SpectralFredholm.nonzero_spectrum_iff
#print axioms SYK.SpectralFredholm.generalized_eigenspace_eq
#print axioms SYK.SpectralFredholm.spectral_absolute_sum
#print axioms SYK.SpectralFredholm.diagonal_spectralDeterminant
#print axioms SYK.SpectralFredholm.spectralDeterminant_conjugate

#print axioms SYK.PhysicalFredholm.physical_eigenspace_finite
#print axioms SYK.PhysicalFredholm.physical_nonzero_spectrum
#print axioms SYK.PhysicalFredholm.physical_no_jordan_chains
#print axioms SYK.PhysicalFredholm.physical_spectral_trace_class
#print axioms SYK.PhysicalFredholm.ordinary_determinant_eq_compression
#print axioms SYK.PhysicalFredholm.couplingPressure_eq_ordinary_fredholm_action

#print axioms SYK.WeylReflection.weylTransfer_reflected
#print axioms SYK.WeylReflection.weylTransfer_reflected_pair
#print axioms SYK.WeylReflection.weyl_numerator_reflected_nonnegative

#print axioms SYK.ThermalResidualState.clm_inserted_triple
#print axioms SYK.ThermalResidualState.state_inserted_residuals
#print axioms SYK.ThermalResidualState.finalAlgebra_nontrivial
#print axioms SYK.ThermalResidualState.finalState_polynomial
#print axioms SYK.ThermalResidualState.actual_moments_to_finalState

#print axioms SYK.GapCountCompositions.assignmentCounts_bijective
#print axioms SYK.GapCountCompositions.hasSum_group_by_total
#print axioms SYK.GapCountCompositions.integral_simplex_eq_sum_counts_of_chamber_constant

#print axioms SYK.WickVertexIntegrals.vertexIntegrand_integrable
#print axioms SYK.WickVertexIntegrals.vertexMoment_bound
#print axioms SYK.WickVertexIntegrals.vertexFunctional_product

#print axioms SYK.coordinate_defect_sum_bound
#print axioms SYK.coordinate_defect_max_bound

#print axioms SYK.MixedIncrement.finite_ward_left_modulus
#print axioms SYK.MixedIncrement.finite_centered_tuple_modulus

#print axioms SYK.BilocalReflection.collectiveTransfer_append
#print axioms SYK.BilocalReflection.collectiveTransfer_reflected
#print axioms SYK.BilocalReflection.collectiveNumerator_reflected_sum

#print axioms SYK.GapHistoryIntegration.integrableOn_of_chamber_constant
#print axioms SYK.GapHistoryIntegration.hasSum_ordered_integrals_of_gap_series
#print axioms SYK.GapHistoryIntegration.hasSum_matrix_history_integrals

#print axioms SYK.ExponentialMomentSeries.integral_value
#print axioms SYK.ExponentialMomentSeries.hasDerivAt_value_integrated_insertion

#print axioms SYK.ThermalRPTransport.halfPolynomial_representation
#print axioms SYK.ThermalRPTransport.finalState_half_nonnegative
#print axioms SYK.ThermalRPTransport.finalState_half_odd
#print axioms SYK.ThermalRPTransport.finalState_translation_tests

#print axioms SYK.PolynomialRP.actualPolynomial_reflected_eq_integral
#print axioms SYK.PolynomialRP.actualPolynomial_reflection_nonnegative
#print axioms SYK.PolynomialRP.actualPolynomial_reflection_im_zero

#print axioms SYK.FourthMomentIntegral.fourthIntegral_bound
#print axioms SYK.FourthMomentIntegral.measurable_fourthIntegral
#print axioms SYK.FourthMomentIntegral.fourthIntegral_tendsto
#print axioms SYK.FourthMomentIntegral.timeMeasure_eq_closed

#print axioms SYK.ContinuumWickSeries.numerator_norm_summable

#print axioms SYK.PartitionWick.hasSum_averagedWickCoefficient
#print axioms SYK.PartitionWick.averagedWick_sum_eq_partition
#print axioms SYK.PartitionWick.averagedWick_sum_re_pos

#print axioms SYK.ThermalMicroscopicPositivity.actualThermal_half_nonnegative
#print axioms SYK.ThermalMicroscopicPositivity.actualThermal_half_real
#print axioms SYK.ThermalMicroscopicPositivity.actualThermal_odd_test_eq

#print axioms SYK.ContinuumWickSeries.coefficient_succ_insertion
#print axioms SYK.ContinuumWickSeries.hasDerivAt_numerator_insertion

#print axioms SYK.PressureLimitAssembly.annealed_limit_from_quartic_response
#print axioms SYK.PressureLimitAssembly.pressure_convergence_from_quartic_response

#print axioms SYK.ThermalPairCube.integral_pairTimes

#print axioms SYK.OddWeylReflection.odd_pair_transfer
#print axioms SYK.OddWeylReflection.odd_collective_pair
#print axioms SYK.OddWeylReflection.odd_numerator_reflected_sum

#print axioms SYK.ContinuumWickSeries.integral_marked_sum_of_bound
#print axioms SYK.ContinuumWickSeries.integral_pair_swap

#print axioms SYK.ExponentialMomentSeries.integrable_value

#print axioms SYK.ThermalWardLimit.leftWard_of_finite
#print axioms SYK.ThermalWardLimit.rightWard_of_finite
#print axioms SYK.ThermalWardLimit.actual_centered_modulus

#print axioms SYK.WeylTranslation.weylNumerator_wrap
#print axioms SYK.WeylTranslation.thermalNumerator_translation
#print axioms SYK.WeylTranslation.actualThermalPolynomial_translation

#print axioms SYK.OddPolynomialRP.actualPolynomial_odd_eq_integral
#print axioms SYK.OddPolynomialRP.actualPolynomial_odd_nonnegative
#print axioms SYK.OddPolynomialRP.actualPolynomial_odd_im_zero

#print axioms SYK.Continuum.physical_integer_midpoint
#print axioms SYK.Continuum.physical_odd
#print axioms SYK.Continuum.freeEnergy_convergence_J

#print axioms SYK.ThermalWardSymmetry.rightWard_of_left

#print axioms SYK.ThermalMicroscopicOddPositivity.tuple_hankel_eq_odd_form
#print axioms SYK.ThermalMicroscopicOddPositivity.actualThermal_half_odd_nonnegative

#print axioms SYK.CollectiveMomentConvergence.exists_physical_actual_moment_limit

#print axioms SYK.ContinuumWickSeries.inserted_numerator_integrable
#print axioms SYK.ContinuumWickSeries.hasDerivAt_seriesPressure

#print axioms SYK.ContinuumWickSeries.expectation_collective_mul
#print axioms SYK.ContinuumWickSeries.expectation_inserted_ward
#print axioms SYK.ContinuumWickSeries.normalizedPartner_product

#print axioms SYK.WardInteraction.coefficientIntegrand_eq_quartic_product
#print axioms SYK.WardInteraction.normalized_partner_inserted_quartic
#print axioms SYK.WardInteraction.orderedProduct_even_update
#print axioms SYK.WardInteraction.markedIntegrand_eq

#print axioms SYK.InsertedWickSeries.fieldCoefficient_bound
#print axioms SYK.InsertedWickSeries.fieldNumerator_norm_summable

#print axioms SYK.FiniteWardSymmetry.rightResidual_eq_neg_left
#print axioms SYK.FiniteWardSymmetry.finiteWardControl_of_left

#print axioms SYK.RealWardContacts.contact_coordinateProduct
#print axioms SYK.RealWardContacts.centered_contact_bound

#print axioms SYK.ContinuumWickSeries.expectation_contact_monomial
#print axioms SYK.ContinuumWickSeries.contactValue_bound
#print axioms SYK.ContinuumWickSeries.contactValue_integrable
#print axioms SYK.ContinuumWickSeries.integral_contactValue
#print axioms SYK.ContinuumWickSeries.contactValue_hasSum

#print axioms SYK.ActualFiniteWardControl.finiteWardControl_of_exact_left

#print axioms SYK.MicroscopicMomentConvergence.finiteSelectionTests
#print axioms SYK.MicroscopicMomentConvergence.exists_physical_actual_moment_limit
#print axioms SYK.MicroscopicMomentConvergence.exists_physical_actual_moment_limit_of_left

#print axioms SYK.WickGaussianRegrouping.gaussian_fieldCoefficient_identity
#print axioms SYK.WickGaussianRegrouping.averagedWickCoefficient_eq_continuum_term
#print axioms SYK.WickGaussianRegrouping.numerator_empty_eq_partition
#print axioms SYK.WickGaussianRegrouping.numerator_empty_re_pos

#print axioms SYK.PolynomialWardExtension.linear_eq_of_list_products
#print axioms SYK.PolynomialWardExtension.ward_of_list_products

#print axioms SYK.FundamentalWardContacts.eval_contact_product
#print axioms SYK.FundamentalWardContacts.eval_contact

#print axioms SYK.WardInteraction.coefficientIntegrand_cubic_swap
#print axioms SYK.WardInteraction.marked_kernel_swap

#print axioms SYK.GapHistoryIntegrationAE.chamber_ae_constant
#print axioms SYK.GapHistoryIntegrationAE.integrableOn_of_chamber_constant
#print axioms SYK.GapHistoryIntegrationAE.integral_simplex_of_chamber_constant
#print axioms SYK.GapHistoryIntegrationAE.hasSum_ordered_integrals_of_gap_series

#print axioms SYK.SignedWardReduction.reduction_contact
#print axioms SYK.SignedWardReduction.reduction_remainder
#print axioms SYK.SignedWardReduction.actualThermal_eq_reduction
#print axioms SYK.SignedWardReduction.actualFundamental_tuple
#print axioms SYK.SignedWardReduction.actualFundamental_list

#print axioms SYK.ContinuumWickSeries.coefficient_parameter_measurable
#print axioms SYK.ContinuumWickSeries.integral_interaction_marked

#print axioms SYK.MicroscopicResponseBridge.hasDerivAt_annealedPressure_fourth

#print axioms SYK.ActualMomentLimit.exists_physical_actual_moment_limit
#print axioms SYK.ActualMomentLimit.ActualMomentLimits.polynomial
#print axioms SYK.ActualMomentLimit.ActualMomentLimits.fourth

#print axioms SYK.FieldDisorderSeries.summable_integral_norm_disorderCoefficient
#print axioms SYK.FieldDisorderSeries.fieldNumerator_eq_integral_disorderSeries

#print axioms SYK.ContinuumWickSeries.contactValue_div
#print axioms SYK.ContinuumWickSeries.normalized_ward_of_numerator

#print axioms SYK.FundamentalWardBridge.polynomial_ward_of_numerator

#print axioms SYK.SignedWardReduction.reduction_interaction
#print axioms SYK.SignedWardReduction.ward_of_fundamental
#print axioms SYK.SignedWardReduction.actualWard_of_fundamental

#print axioms SYK.ContinuumWickSeries.wardBranch_integrable
#print axioms SYK.ContinuumWickSeries.markedIntegrand_integrable
#print axioms SYK.ContinuumWickSeries.integral_marked_insertNth
#print axioms SYK.ContinuumWickSeries.integral_markedIntegrand

#print axioms SYK.CollectiveFieldExpansion.collectiveMonomial_expansion
#print axioms SYK.CollectiveFieldExpansion.numerator_eq_field_sum

#print axioms SYK.SignedWardReduction.actualWard_interval_of_fundamental
#print axioms SYK.SignedWardReduction.actual_interaction_integrable
#print axioms SYK.SignedWardReduction.pairIntegral_eq_interval

#print axioms SYK.RepresentationIndependence.even_word_trace_eq
#print axioms SYK.RepresentationIndependence.trace_power_eq
#print axioms SYK.RepresentationIndependence.partitionFunction_eq
#print axioms SYK.RepresentationIndependence.annealedPressure_eq
#print axioms SYK.RepresentationIndependence.quenchedPressure_eq
#print axioms SYK.RepresentationIndependence.pressure_convergence_transfer

#print axioms SYK.FundamentalMomentIntegrability.actualFundamental_inserted_integrable
#print axioms SYK.FundamentalMomentIntegrability.actualFundamental_ward_integrable

#print axioms SYK.ActualWickPressure.seriesPressure_eq_annealedPressure
#print axioms SYK.ActualWickPressure.hasDerivAt_annealedPressure_series

#print axioms SYK.ActualFourthResponse.ae_pair_representative
#print axioms SYK.ActualFourthResponse.fourthIntegral_eq_series
#print axioms SYK.ActualFourthResponse.hasDerivAt_annealedPressure

#print axioms SYK.ActualWickChamber.weightedVertexIntegrand_chamber

#print axioms SYK.ActualWickWard.exact_left_of_wick_identities

#print axioms SYK.InsertedWickSymmetry.fieldNumerator_permutation
#print axioms SYK.InsertedWickSymmetry.fieldNumerator_zero_of_repeat
#print axioms SYK.InsertedWickSymmetry.annealedWeyl_eq_average

#print axioms SYK.ActualWickPressure.numerator_empty_im

#print axioms SYK.ComplexFourierOperatorAction.complexCircleL2_coe
#print axioms SYK.ComplexFourierOperatorAction.complexCovarianceSource_split
#print axioms SYK.ComplexFourierOperatorAction.physicalPerturbation_complex_integral_action

#print axioms SYK.ActualCorrespondenceConsequences.fourth_of_list_correspondence
#print axioms SYK.ActualCorrespondenceConsequences.pressure_response_of_list_correspondence

#print axioms SYK.ComplexFourierOperatorAction.complexCircleL2_modeTest
#print axioms SYK.ComplexFourierOperatorAction.operator_eq_of_complex_tests
#print axioms SYK.ComplexFourierOperatorAction.physical_operator_unique

#print axioms SYK.ContinuumSYKMain.physicalConclusion
#print axioms SYK.ContinuumSYKMain.fredholmConclusion
#print axioms SYK.ContinuumSYKMain.exists_main_of_microscopic_identities
#print axioms SYK.ContinuumSYKMain.MainConclusion.operator_integral_action
#print axioms SYK.ContinuumSYKMain.MainConclusion.at_real_coupling
#print axioms SYK.ContinuumSYKMain.MainConclusion.arbitrary_representation

#print axioms SYK.ActualWickChamberSeries.boundaries_gap
#print axioms SYK.ActualWickChamberSeries.weightedVertexIntegrand_sorted_chamber
#print axioms SYK.ActualWickChamberSeries.disorderCoefficient_eq_ordered_integral
#print axioms SYK.ActualWickChamberSeries.hasSum_sorted_disorderCoefficient

#print axioms SYK.CollectiveWeylAverage.normalized_flavor_average
#print axioms SYK.CollectiveWeylAverage.normalized_flavor_average_ratio

#print axioms SYK.ContinuumSYKMain.MainConclusion.operator_complex_integral_action
#print axioms SYK.ContinuumSYKMain.MainConclusion.operator_unique
#print axioms SYK.ContinuumSYKMain.MainConclusion.family_unique
#print axioms SYK.ContinuumSYKMain.MainConclusion.arbitrary_representation_freeEnergy

#print axioms SYK.ContinuumWickSeries.coefficient_ward_succ
#print axioms SYK.ContinuumWickSeries.coefficient_ward_zero
#print axioms SYK.ContinuumWickSeries.wardBranch_hasSum_integral
#print axioms SYK.ContinuumWickSeries.ward_interaction_hasSum
#print axioms SYK.ContinuumWickSeries.numerator_ward

#print axioms SYK.ActualWickCorrespondence.fieldNumerator_eq_annealedWeyl
#print axioms SYK.ActualWickCorrespondence.numerator_eq_annealedCollective
#print axioms SYK.ActualWickCorrespondence.normalizedMoment_eq_collectiveMoment

#print axioms SYK.SYKMainTheorem.continuum_free_energy
#print axioms SYK.SYKMainTheorem.existsUnique_physical_solution

#print axioms SYK.ActualMicroscopicIdentities.exact_left_ward
#print axioms SYK.ActualMicroscopicIdentities.quartic_response
#print axioms SYK.ActualMicroscopicIdentities.finite_ward_control

#print axioms SYK.MomentRepresentationIndependence.timeProduct_trace_eq
#print axioms SYK.MomentRepresentationIndependence.weylNumerator_eq
#print axioms SYK.MomentRepresentationIndependence.collectiveNumerator_eq
#print axioms SYK.MomentRepresentationIndependence.collectiveNumerator_integrable
#print axioms SYK.MomentRepresentationIndependence.collectiveMoment_eq
#print axioms SYK.MomentRepresentationIndependence.collectiveMoment_bound
#print axioms SYK.MomentRepresentationIndependence.moment_convergence_transfer

#print axioms SYK.AbstractRepresentation.coordinates_trace
#print axioms SYK.AbstractRepresentation.coordinates_exp
#print axioms SYK.AbstractRepresentation.partitionFunction_eq_of_finrank
#print axioms SYK.AbstractRepresentation.annealedPressure_eq
#print axioms SYK.AbstractRepresentation.quenchedPressure_eq

#print axioms SYK.ContinuumSYKMain.MainConclusion.arbitrary_primary_moments
#print axioms SYK.ContinuumSYKMain.MainConclusion.arbitrary_thermal_moments
#print axioms SYK.ContinuumSYKMain.MainConclusion.abstract_pressures
#print axioms SYK.ContinuumSYKMain.MainConclusion.abstract_freeEnergy

#print axioms SYK.AbstractRepresentation.coordinates_timeProduct
#print axioms SYK.AbstractRepresentation.weylNumerator_coordinates
#print axioms SYK.AbstractRepresentation.collectiveNumerator_eq
#print axioms SYK.AbstractRepresentation.collectiveMoment_eq
#print axioms SYK.AbstractRepresentation.collectiveNumerator_integrable

#print axioms SYK.ContinuumSYKMain.MainConclusion.abstract_primary_moments
#print axioms SYK.ContinuumSYKMain.MainConclusion.abstract_thermal_moments
#print axioms SYK.ContinuumSYKMain.MainConclusion.abstract_realization
#print axioms SYK.SYKMainTheorem.continuum_free_energy_abstract
