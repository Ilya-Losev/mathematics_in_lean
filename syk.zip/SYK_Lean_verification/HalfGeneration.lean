import Mathlib.Analysis.Analytic.Uniqueness
import Mathlib.Analysis.Normed.Group.Quotient
import Mathlib.Tactic

/-!
# Section 7: analytic continuation into a closed subspace

This is the actual Banach-space quotient argument in Section 7.
Analyticity of the orbit is an explicit hypothesis. The SYK SD-to-ODE
calculation and the holomorphic Picard construction are not proved here.
-/

namespace SYK

open Set Filter Topology

/-- The geometric seed in Section 7: a pair with separation shorter than a
half-period fits in the open positive half-circle for a nonempty open interval
of simultaneous translations. Choosing suitable antiperiodic lifts is a
separate input; this theorem concerns the resulting real representatives.
-/
theorem shifts_into_half_circle (β s t : ℝ)
    (_hβ : 0 < β) (hsep : |s - t| < β / 2) :
    ∃ I : Set ℝ, IsOpen I ∧ I.Nonempty ∧
      ∀ u ∈ I, (0 < s + u ∧ s + u < β / 2) ∧
        (0 < t + u ∧ t + u < β / 2) := by
  have hgap : -min s t < β / 2 - max s t := by
    obtain ⟨hleft, hright⟩ := abs_lt.mp hsep
    by_cases hst : s ≤ t
    · simp only [min_eq_left hst, max_eq_right hst]
      linarith
    · have hts : t ≤ s := le_of_not_ge hst
      simp only [min_eq_right hts, max_eq_left hts]
      linarith
  refine ⟨Ioo (-min s t) (β / 2 - max s t), isOpen_Ioo,
    Set.nonempty_Ioo.mpr hgap, ?_⟩
  intro u hu
  obtain ⟨hlo, hhi⟩ := hu
  constructor <;> constructor
  · linarith [min_le_left s t]
  · linarith [le_max_left s t]
  · linarith [min_le_right s t]
  · linarith [le_max_right s t]

variable {E : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E]

/-- If a norm-analytic curve belongs to a closed linear subspace on an open,
nonempty interval (or open set), it belongs there at every real parameter.
The quotient is a genuine normed-space quotient; the subspace need not be an ideal.
-/
theorem analytic_curve_mem_closed_submodule
    (B : Submodule ℝ E) [IsClosed (B : Set E)]
    (f : ℝ → E) (hf : AnalyticOnNhd ℝ f Set.univ)
    (I : Set ℝ) (hI : IsOpen I) (hne : I.Nonempty)
    (hlocal : ∀ u ∈ I, f u ∈ B) :
    ∀ u, f u ∈ B := by
  let q : E →L[ℝ] E ⧸ B := B.mkQ.mkContinuous 1 (by
    intro x
    simpa using Submodule.Quotient.norm_mk_le B x)
  have hq : AnalyticOnNhd ℝ (q ∘ f) Set.univ := by
    intro u hu
    exact (q.analyticAt _).comp (hf u hu)
  obtain ⟨u₀, hu₀⟩ := hne
  have hzero : (q ∘ f) =ᶠ[𝓝 u₀] (0 : ℝ → E ⧸ B) := by
    filter_upwards [hI.mem_nhds hu₀] with u hu
    change (Submodule.Quotient.mk (f u) : E ⧸ B) = 0
    exact (Submodule.Quotient.mk_eq_zero B).mpr (hlocal u hu)
  have hglobal := hq.eqOn_zero_of_preconnected_of_eventuallyEq_zero
    isPreconnected_univ (Set.mem_univ u₀) hzero
  intro u
  have hz := hglobal (Set.mem_univ u)
  change (Submodule.Quotient.mk (f u) : E ⧸ B) = 0 at hz
  exact (Submodule.Quotient.mk_eq_zero B).mp hz

/-- Generator-wise form used in the half-algebra theorem. Each generator may
have a different open interval of parameters placing it inside the subspace.
No common interval for all generators is assumed.
-/
theorem every_generator_mem_of_analytic_orbits {Index : Type*}
    (B : Submodule ℝ E) [IsClosed (B : Set E)]
    (orbit : Index → ℝ → E)
    (hanalytic : ∀ p, AnalyticOnNhd ℝ (orbit p) Set.univ)
    (hseed : ∀ p, ∃ I : Set ℝ,
      IsOpen I ∧ I.Nonempty ∧ ∀ u ∈ I, orbit p u ∈ B) :
    ∀ p, orbit p 0 ∈ B := by
  intro p
  obtain ⟨I, hopen, hne, hlocal⟩ := hseed p
  exact analytic_curve_mem_closed_submodule B (orbit p)
    (hanalytic p) I hopen hne hlocal 0

/-- Abstract positivity-extension step at the start of Section 8.
The real-valued function Q represents a ↦ Re L(a* a). Continuity and density
are enough to extend its nonnegativity from the half-time observables.
-/
theorem nonnegative_of_continuous_of_dense
    {A : Type*} [TopologicalSpace A]
    (S : Set A) (hS : Dense S) (Q : A → ℝ) (hQ : Continuous Q)
    (hpositive : ∀ a ∈ S, 0 ≤ Q a) :
    ∀ a, 0 ≤ Q a := by
  have hclosed : IsClosed {a : A | 0 ≤ Q a} :=
    isClosed_Ici.preimage hQ
  have hsubset : S ⊆ {a : A | 0 ≤ Q a} := hpositive
  have hclosure := closure_minimal hsubset hclosed
  intro a
  exact hclosure (hS a)

end SYK
