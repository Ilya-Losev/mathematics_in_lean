import Mathlib.Topology.MetricSpace.PiNat
import Mathlib.Topology.MetricSpace.Cauchy
import Mathlib.Analysis.Complex.Basic
import Mathlib.Topology.Sequences

/-!
# Compactness with a vanishing contact defect

The finite-size functions need not be continuous. A common Lipschitz bound with
an additive defect tending to zero suffices for subsequential uniform
convergence on compact metric endpoint spaces. The limit has the original
Lipschitz constant. A single extraction works simultaneously for all degrees.

The proof extracts convergence on countably many dense samples in a compact
product, uses finite endpoint nets to prove uniform Cauchyness, and then uses
completeness. Thus neither finite-size continuity nor compactness of the
family of finite-size functions is assumed.
-/

noncomputable section
open Filter Set Topology Metric

namespace SYK.MomentCompactness

section UniformCauchy
variable {X Y : Type*} [MetricSpace X] [CompactSpace X] [MetricSpace Y]

/-- A finite net chosen from any dense sequence in a compact metric space. -/
theorem finite_dense_net (d : ℕ → X) (hd : DenseRange d) {δ : ℝ} (hδ : 0 < δ) :
    ∃ s : Finset ℕ, ∀ x : X, ∃ i ∈ s, dist x (d i) < δ := by
  obtain ⟨s, hs⟩ := isCompact_univ.elim_finite_subcover
    (fun i => ball (d i) δ) (fun _ => isOpen_ball) (by
      intro x _
      obtain ⟨i, hi⟩ := hd.exists_dist_lt x hδ
      exact mem_iUnion.mpr ⟨i, hi⟩)
  refine ⟨s, fun x => ?_⟩
  simpa only [mem_iUnion, mem_ball, exists_prop] using hs (mem_univ x)

/-- Vanishing contact errors and Cauchy convergence at dense sample points
imply uniform Cauchyness, even when every finite-size function has jumps. -/
theorem uniformCauchy_of_dense (f : ℕ → X → Y) (K : ℝ) (hK : 0 ≤ K)
    (ε : ℕ → ℝ) (hε : Tendsto ε atTop (𝓝 0))
    (hmod : ∀ n x y, dist (f n x) (f n y) ≤ K * dist x y + ε n)
    (d : ℕ → X) (hd : DenseRange d)
    (hpoint : ∀ i, CauchySeq (fun n => f n (d i))) :
    UniformCauchySeqOn f atTop univ := by
  classical
  apply Metric.uniformCauchySeqOn_iff.mpr
  intro η hη
  let δ := η / (8 * (K + 1))
  have hden : 0 < 8 * (K + 1) := by positivity
  have hδ : 0 < δ := div_pos hη hden
  have hKδ : K * δ ≤ η / 8 := by
    dsimp [δ]
    apply (le_div_iff₀ (by norm_num : (0 : ℝ) < 8)).mpr
    have heq : η / (8 * (K + 1)) * (8 * (K + 1)) = η := div_mul_cancel₀ η hden.ne'
    nlinarith [div_nonneg hη.le hden.le]
  obtain ⟨s, hs⟩ := finite_dense_net d hd hδ
  have hpoint' : ∀ i, ∃ N : ℕ, ∀ n ≥ N, ∀ m ≥ N,
      dist (f n (d i)) (f m (d i)) < η / 4 :=
    fun i => Metric.cauchySeq_iff.mp (hpoint i) (η / 4) (by positivity)
  choose N hN using hpoint'
  obtain ⟨Nε, hNε⟩ := eventually_atTop.mp (hε.eventually (gt_mem_nhds (show 0 < η / 8 by positivity)))
  refine ⟨max Nε (s.sup N), ?_⟩
  intro n hn m hm x _
  obtain ⟨i, hi, hxi⟩ := hs x
  have hnε : ε n < η / 8 := hNε n (le_trans (le_max_left _ _) hn)
  have hmε : ε m < η / 8 := hNε m (le_trans (le_max_left _ _) hm)
  have hni : N i ≤ n := le_trans (Finset.le_sup hi) (le_trans (le_max_right _ _) hn)
  have hmi : N i ≤ m := le_trans (Finset.le_sup hi) (le_trans (le_max_right _ _) hm)
  have hdist := hN i n hni m hmi
  have hnmod := hmod n x (d i)
  have hmmod := hmod m (d i) x
  rw [dist_comm (d i) x] at hmmod
  have hnear : K * dist x (d i) ≤ η / 8 :=
    (mul_le_mul_of_nonneg_left hxi.le hK).trans hKδ
  calc
    dist (f n x) (f m x) ≤
        dist (f n x) (f n (d i)) + dist (f n (d i)) (f m (d i)) +
          dist (f m (d i)) (f m x) := dist_triangle4 _ _ _ _
    _ < η := by linarith

/-- Completeness turns the preceding finite-net estimate into a genuine
uniform limit, without any continuity hypothesis on the approximating maps. -/
theorem exists_uniformLimit_of_dense [CompleteSpace Y]
    (f : ℕ → X → Y) (K : ℝ) (hK : 0 ≤ K)
    (ε : ℕ → ℝ) (hε : Tendsto ε atTop (𝓝 0))
    (hmod : ∀ n x y, dist (f n x) (f n y) ≤ K * dist x y + ε n)
    (d : ℕ → X) (hd : DenseRange d)
    (hpoint : ∀ i, CauchySeq (fun n => f n (d i))) :
    ∃ g : X → Y, TendstoUniformly f g atTop := by
  have hc := uniformCauchy_of_dense f K hK ε hε hmod d hd hpoint
  have hp : ∀ x : X, ∃ y : Y, Tendsto (fun n => f n x) atTop (𝓝 y) :=
    fun x => cauchySeq_tendsto_of_complete (hc.cauchySeq (mem_univ x))
  choose g hg using hp
  exact ⟨g, tendstoUniformlyOn_univ.mp
    (hc.tendstoUniformlyOn_of_tendsto (fun x _ => hg x))⟩

/-- The vanishing defect disappears in the limit, preserving the exact
Lipschitz constant. -/
theorem lipschitz_uniformLimit (f : ℕ → X → Y) (g : X → Y)
    (K : ℝ) (hK : 0 ≤ K) (ε : ℕ → ℝ) (hε : Tendsto ε atTop (𝓝 0))
    (hmod : ∀ n x y, dist (f n x) (f n y) ≤ K * dist x y + ε n)
    (hg : TendstoUniformly f g atTop) : LipschitzWith ⟨K, hK⟩ g := by
  apply LipschitzWith.of_dist_le_mul
  intro x y
  have hleft := (hg.tendsto_at x).dist (hg.tendsto_at y)
  have hright : Tendsto (fun n => K * dist x y + ε n) atTop (𝓝 (K * dist x y)) := by
    simpa only [add_zero] using tendsto_const_nhds.add hε
  exact le_of_tendsto_of_tendsto hleft hright (Eventually.of_forall (fun n => hmod n x y))

end UniformCauchy

section Diagonal
variable (X : ℕ → Type*) [∀ k, MetricSpace (X k)] [∀ k, CompactSpace (X k)]
    [∀ k, Nonempty (X k)]
variable {Y : Type*} [MetricSpace Y] [ProperSpace Y]

/-- One strictly increasing subsequence gives uniform convergence for every
member of a countable family of compact endpoint spaces. Only boundedness,
asymptotic Lipschitz control and vanishing defects are assumed. -/
theorem diagonal_uniform_subsequence
    (f : ∀ k, ℕ → X k → Y) (y₀ : Y) (B K : ℕ → ℝ)
    (hK : ∀ k, 0 ≤ K k) (ε : ℕ → ℕ → ℝ)
    (hε : ∀ k, Tendsto (ε k) atTop (𝓝 0))
    (hbound : ∀ k n x, dist (f k n x) y₀ ≤ B k)
    (hmod : ∀ k n x y, dist (f k n x) (f k n y) ≤ K k * dist x y + ε k n) :
    ∃ (φ : ℕ → ℕ) (g : ∀ k, X k → Y), StrictMono φ ∧
      (∀ k, TendstoUniformly (fun n => f k (φ n)) (g k) atTop) ∧
      (∀ k, LipschitzWith ⟨K k, hK k⟩ (g k)) ∧
      (∀ k x, dist (g k x) y₀ ≤ B k) := by
  classical
  let d : ∀ k, ℕ → X k := fun k => TopologicalSpace.denseSeq (X k)
  have hd : ∀ k, DenseRange (d k) := fun k => TopologicalSpace.denseRange_denseSeq (X k)
  let C : ℕ → Type _ := fun k => closedBall y₀ (B k)
  letI : ∀ k, CompactSpace (C k) := fun k =>
    isCompact_iff_compactSpace.mp (isCompact_closedBall y₀ (B k))
  let samples : ℕ → ∀ k, ℕ → C k :=
    fun n k i => ⟨f k n (d k i), hbound k n (d k i)⟩
  obtain ⟨a, φ, hφ, ha⟩ := CompactSpace.tendsto_subseq samples
  have hsample : ∀ k i, CauchySeq (fun n => f k (φ n) (d k i)) := by
    intro k i
    have hki := (tendsto_pi_nhds.mp (tendsto_pi_nhds.mp ha k) i)
    exact (continuous_subtype_val.tendsto (a k i) |>.comp hki).cauchySeq
  have hlimits : ∀ k, ∃ g : X k → Y,
      TendstoUniformly (fun n => f k (φ n)) g atTop := by
    intro k
    exact exists_uniformLimit_of_dense (fun n => f k (φ n)) (K k) (hK k)
      (fun n => ε k (φ n)) ((hε k).comp hφ.tendsto_atTop)
      (fun n => hmod k (φ n)) (d k) (hd k) (hsample k)
  choose g hg using hlimits
  refine ⟨φ, g, hφ, hg, ?_, ?_⟩
  · intro k
    exact lipschitz_uniformLimit (fun n => f k (φ n)) (g k) (K k) (hK k)
      (fun n => ε k (φ n)) ((hε k).comp hφ.tendsto_atTop)
      (fun n => hmod k (φ n)) (hg k)
  · intro k x
    exact le_of_tendsto ((hg k).tendsto_at x |>.dist tendsto_const_nhds)
      (Eventually.of_forall (fun n => hbound k (φ n) x))

end Diagonal
/-- The single-degree asymptotic Arzelà–Ascoli theorem. -/
theorem uniform_subsequence {X Y : Type*} [MetricSpace X] [CompactSpace X]
    [Nonempty X] [MetricSpace Y] [ProperSpace Y]
    (f : ℕ → X → Y) (y₀ : Y) (B K : ℝ) (hK : 0 ≤ K)
    (ε : ℕ → ℝ) (hε : Tendsto ε atTop (𝓝 0))
    (hbound : ∀ n x, dist (f n x) y₀ ≤ B)
    (hmod : ∀ n x y, dist (f n x) (f n y) ≤ K * dist x y + ε n) :
    ∃ (φ : ℕ → ℕ) (g : X → Y), StrictMono φ ∧
      TendstoUniformly (fun n => f (φ n)) g atTop ∧
      LipschitzWith ⟨K, hK⟩ g ∧ (∀ x, dist (g x) y₀ ≤ B) := by
  obtain ⟨φ, g, hφ, hg, hLip, hB⟩ := diagonal_uniform_subsequence
    (fun _ : ℕ => X) (fun _ => f) y₀ (fun _ => B) (fun _ => K)
    (fun _ => hK) (fun _ => ε) (fun _ => hε) (fun _ => hbound) (fun _ => hmod)
  exact ⟨φ, g 0, hφ, hg 0, hLip 0, hB 0⟩

/-- Complex scalar moments: the hypotheses are expressed with their usual
complex norm, and the conclusion uses a single subsequence for every degree. -/
theorem complex_diagonal_uniform_subsequence
    (X : ℕ → Type*) [∀ k, MetricSpace (X k)] [∀ k, CompactSpace (X k)]
    [∀ k, Nonempty (X k)] (f : ∀ k, ℕ → X k → ℂ) (B K : ℕ → ℝ)
    (hK : ∀ k, 0 ≤ K k) (ε : ℕ → ℕ → ℝ)
    (hε : ∀ k, Tendsto (ε k) atTop (𝓝 0))
    (hbound : ∀ k n x, ‖f k n x‖ ≤ B k)
    (hmod : ∀ k n x y, ‖f k n x - f k n y‖ ≤ K k * dist x y + ε k n) :
    ∃ (φ : ℕ → ℕ) (g : ∀ k, X k → ℂ), StrictMono φ ∧
      (∀ k, TendstoUniformly (fun n => f k (φ n)) (g k) atTop) ∧
      (∀ k, LipschitzWith ⟨K k, hK k⟩ (g k)) ∧
      (∀ k x, ‖g k x‖ ≤ B k) := by
  simpa only [dist_zero_right, dist_eq_norm, sub_zero] using diagonal_uniform_subsequence
    X f 0 B K hK ε hε (by simpa only [dist_zero_right] using hbound)
      (by simpa only [dist_eq_norm] using hmod)

/-- The compact, closed endpoint cube in degree `k`. Coincidence loci and both
ends of the thermal interval are included. -/
abbrev EndpointCube (β : ℝ) (k : ℕ) :=
  Fin k → (Icc (0 : ℝ) β) × (Icc (0 : ℝ) β)

/-- Forget the interval membership proofs to obtain the raw endpoint pairs
used in the actual interacting collective moments. -/
def endpointValues {β : ℝ} {k : ℕ} (p : EndpointCube β k) : Fin k → ℝ × ℝ :=
  fun i => ((p i).1.val, (p i).2.val)

@[simp] theorem endpointValues_dist {β : ℝ} {k : ℕ} (p q : EndpointCube β k) :
    dist (endpointValues p) (endpointValues q) = dist p q := rfl

theorem endpointValues_mem {β : ℝ} {k : ℕ} (p : EndpointCube β k) (i : Fin k) :
    (endpointValues p i).1 ∈ Icc (0 : ℝ) β ∧
      (endpointValues p i).2 ∈ Icc (0 : ℝ) β := ⟨(p i).1.property, (p i).2.property⟩

/-- The endpoint-cube version in the conventions of complex collective
moments. Bounds and contact-defect estimates are required only on the closed
thermal interval; the resulting compactness is derived here. -/
theorem endpoint_moment_subsequence (β : ℝ) (hβ : 0 ≤ β)
    (f : ∀ k, ℕ → (Fin k → ℝ × ℝ) → ℂ) (B K : ℕ → ℝ)
    (hK : ∀ k, 0 ≤ K k) (ε : ℕ → ℕ → ℝ)
    (hε : ∀ k, Tendsto (ε k) atTop (𝓝 0))
    (hbound : ∀ k n p, (∀ i, (p i).1 ∈ Icc (0 : ℝ) β ∧ (p i).2 ∈ Icc (0 : ℝ) β) →
      ‖f k n p‖ ≤ B k)
    (hmod : ∀ k n p q,
      (∀ i, (p i).1 ∈ Icc (0 : ℝ) β ∧ (p i).2 ∈ Icc (0 : ℝ) β) →
      (∀ i, (q i).1 ∈ Icc (0 : ℝ) β ∧ (q i).2 ∈ Icc (0 : ℝ) β) →
      ‖f k n p - f k n q‖ ≤ K k * dist p q + ε k n) :
    ∃ (φ : ℕ → ℕ) (g : ∀ k, EndpointCube β k → ℂ), StrictMono φ ∧
      (∀ k, TendstoUniformly (fun n p => f k (φ n) (endpointValues p)) (g k) atTop) ∧
      (∀ k, LipschitzWith ⟨K k, hK k⟩ (g k)) ∧
      (∀ k p, ‖g k p‖ ≤ B k) := by
  letI : Nonempty (Icc (0 : ℝ) β) := ⟨⟨0, le_refl _, hβ⟩⟩
  apply complex_diagonal_uniform_subsequence (EndpointCube β)
    (fun k n p => f k n (endpointValues p)) B K hK ε hε
  · intro k n p
    exact hbound k n (endpointValues p) (endpointValues_mem p)
  · intro k n p q
    simpa only [endpointValues_dist] using hmod k n (endpointValues p) (endpointValues q)
      (endpointValues_mem p) (endpointValues_mem q)

end SYK.MomentCompactness
