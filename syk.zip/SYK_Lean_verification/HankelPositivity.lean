import HankelFourierTest
import Mathlib.MeasureTheory.Integral.Pi

/-! From finite Gram positivity to integral positivity by independent sampling. -/
noncomputable section
open MeasureTheory Set
open scoped BigOperators ComplexConjugate
namespace SYK.HankelPositivity

variable {X ι : Type*} [MeasurableSpace X] [Fintype ι]
variable (μ : Measure X) [IsProbabilityMeasure μ]

/-- A coordinate of the actual finite product law has the prescribed law. -/
theorem pi_map_coordinate (i : ι) :
    (Measure.pi (fun _ : ι => μ)).map (fun x => x i) = μ := by
  classical
  ext s hs
  rw [Measure.map_apply (measurable_pi_apply i) hs]
  have he : (fun x : ι → X => x i) ⁻¹' s =
      Set.pi univ (fun j => if j = i then s else univ) := by
    ext x
    simp only [mem_preimage, mem_pi, mem_univ, true_implies]
    constructor
    · intro hx j; by_cases h : j = i <;> simp [h, hx]
    · intro hx; simpa using hx i
  rw [he, Measure.pi_pi]
  simp only [apply_ite, measure_univ]
  simp

/-- Two distinct coordinates have exactly the product law. -/
theorem pi_map_pair (i j : ι) (hij : i ≠ j) :
    (Measure.pi (fun _ : ι => μ)).map (fun x => (x i,x j)) = μ.prod μ := by
  classical
  apply (Measure.prod_eq fun s t hs ht => ?_).symm
  rw [Measure.map_apply ((measurable_pi_apply i).prodMk (measurable_pi_apply j)) (hs.prod ht)]
  have he : (fun x : ι → X => (x i,x j)) ⁻¹' (s ×ˢ t) =
      Set.pi univ (fun k => if k = i then s else if k = j then t else univ) := by
    ext x
    simp only [mem_preimage, mem_prod, mem_pi, mem_univ, true_implies]
    constructor
    · rintro ⟨hx,hy⟩ k
      by_cases hi : k = i
      · simpa [hi] using hx
      · by_cases hj : k = j <;> simp [hi,hj,hy,hij.symm]
    · intro hx
      exact ⟨by simpa using hx i, by simpa [hij.symm] using hx j⟩
  rw [he, Measure.pi_pi]
  have hterm (k : ι) : μ (if k = i then s else if k = j then t else univ) =
      (if k = i then μ s else 1) * (if k = j then μ t else 1) := by
    by_cases hi : k = i
    · subst k; simp [hij]
    · by_cases hj : k = j <;> simp [hi,hj,hij.symm]
  simp_rw [hterm]
  rw [Finset.prod_mul_distrib]
  simp

/-- Integration of a bounded measurable two-coordinate function. -/
theorem integral_pair (i j : ι) (hij : i ≠ j) (F : X × X → ℝ)
    (hF : Measurable F) :
    (∫ x : ι → X, F (x i,x j) ∂Measure.pi (fun _ : ι => μ)) =
      ∫ p, F p ∂μ.prod μ := by
  rw [← integral_map ((measurable_pi_apply i).prodMk (measurable_pi_apply j)).aemeasurable
    hF.aestronglyMeasurable, pi_map_pair μ i j hij]

theorem integral_diagonal (i : ι) (F : X × X → ℝ) (hF : Measurable F) :
    (∫ x : ι → X, F (x i,x i) ∂Measure.pi (fun _ : ι => μ)) =
      ∫ x, F (x,x) ∂μ := by
  have hm : Measurable (fun x => F (x,x)) := hF.comp (measurable_id.prodMk measurable_id)
  have h := integral_map (μ := Measure.pi (fun _ : ι => μ))
    (φ := fun x : ι → X => x i) (f := fun x : X => F (x,x))
    (measurable_pi_apply i).aemeasurable hm.aestronglyMeasurable
  rw [pi_map_coordinate μ i] at h
  exact h.symm

/-- A bounded measurable kernel whose every finite unweighted Gram sum is
nonnegative has nonnegative double integral. Independent samples make the
finite diagonal correction vanish; no continuity of the kernel is required. -/
theorem integral_nonnegative_of_finite_sums (F : X × X → ℝ)
    (hF : Measurable F) (B : ℝ) (hB : ∀ p, |F p| ≤ B)
    (hpos : ∀ (n : ℕ) (x : Fin n → X), 0 ≤ ∑ i, ∑ j, F (x i,x j)) :
    0 ≤ ∫ p, F p ∂μ.prod μ := by
  classical
  let D := ∫ x, F (x,x) ∂μ
  let I := ∫ p, F p ∂μ.prod μ
  have hi (n : ℕ) (i j : Fin n) :
      Integrable (fun x : Fin n → X => F (x i,x j)) (Measure.pi fun _ => μ) := by
    apply (integrable_const B).mono'
      (hF.comp ((measurable_pi_apply i).prodMk (measurable_pi_apply j))).aestronglyMeasurable
    filter_upwards [] with x
    exact hB (x i,x j)
  have he (n : ℕ) (i j : Fin n) :
      (∫ x : Fin n → X, F (x i,x j) ∂Measure.pi (fun _ => μ)) =
        I + if j = i then D-I else 0 := by
    by_cases h : j = i
    · subst j
      rw [integral_diagonal μ i F hF]
      simp [D]
    · rw [integral_pair μ i j (Ne.symm h) F hF]
      simp [h,I]
  have hineq (n : ℕ) : 0 ≤ (n : ℝ) * (D + ((n : ℝ)-1)*I) := by
    have h : 0 ≤ (∫ x : Fin n → X, ∑ i, ∑ j, F (x i,x j)
        ∂Measure.pi (fun _ : Fin n => μ)) := integral_nonneg (hpos n)
    rw [integral_finset_sum _ (fun i _ => integrable_finset_sum _ (fun j _ => hi n i j))] at h
    simp_rw [integral_finset_sum _ (fun j _ => hi n _ j), he n] at h
    simp only [Finset.sum_add_distrib, Finset.sum_ite_eq', Finset.mem_univ,
      if_true, Finset.sum_const, Finset.card_univ, Fintype.card_fin, nsmul_eq_mul] at h
    nlinarith
  change 0 ≤ I
  by_contra! hneg
  obtain ⟨n, hn⟩ := exists_nat_gt (D / (-I))
  have hn' : D < (n : ℝ) * (-I) := (div_lt_iff₀ (by linarith : 0 < -I)).mp hn
  have hh := hineq (n+1)
  have hn0 : 0 ≤ (n : ℝ) := Nat.cast_nonneg _
  push_cast at hh
  nlinarith

/-- The same positivity implication for any finite measure, by normalizing its
actual mass. The zero measure is handled separately. -/
theorem finite_measure_integral_nonnegative (ν : Measure X) [IsFiniteMeasure ν]
    (F : X × X → ℝ) (hF : Measurable F) (B : ℝ) (hB : ∀ p, |F p| ≤ B)
    (hpos : ∀ (n : ℕ) (x : Fin n → X), 0 ≤ ∑ i, ∑ j, F (x i,x j)) :
    0 ≤ ∫ x, ∫ y, F (x,y) ∂ν ∂ν := by
  by_cases hν : ν = 0
  · simp [hν]
  letI : NeZero ν := ⟨hν⟩
  let η := (ν univ)⁻¹ • ν
  have hi : Integrable F (η.prod η) := by
    apply (integrable_const B).mono' hF.aestronglyMeasurable
    filter_upwards [] with p; exact hB p
  have h := integral_nonnegative_of_finite_sums η F hF B hB hpos
  rw [integral_prod F hi] at h
  simp only [η, integral_smul_measure, smul_eq_mul, integral_const_mul] at h
  have hc : 0 < ((ν univ)⁻¹).toReal := ENNReal.toReal_pos
    (by simp [NeZero.ne (ν univ)]) (by simp [NeZero.ne (ν univ)])
  exact nonneg_of_mul_nonneg_right (nonneg_of_mul_nonneg_right h hc) hc

/-- Finite positivity on a measurable set controls its actual double integral. -/
theorem set_integral_nonnegative (ν : Measure X) [IsFiniteMeasure ν]
    (S : Set X) (hS : MeasurableSet S) (F : X × X → ℝ) (hF : Measurable F)
    (B : ℝ) (hB : ∀ p, |F p| ≤ B)
    (hpos : ∀ (n : ℕ) (x : Fin n → S),
      0 ≤ ∑ i, ∑ j, F ((x i : X),(x j : X))) :
    0 ≤ ∫ x in S, ∫ y in S, F (x,y) ∂ν ∂ν := by
  let ρ := ν.comap (Subtype.val : S → X)
  have hm : Measurable (fun p : S × S => F ((p.1 : X),(p.2 : X))) :=
    hF.comp ((measurable_subtype_coe.comp measurable_fst).prodMk
      (measurable_subtype_coe.comp measurable_snd))
  have h := finite_measure_integral_nonnegative ρ
    (fun p : S × S => F ((p.1 : X),(p.2 : X))) hm B (fun p => hB _) hpos
  have hinner (x : S) : (∫ y : S, F ((x : X),(y : X)) ∂ρ) =
      ∫ y in S, F ((x : X),y) ∂ν :=
    integral_subtype_comap hS (fun y => F ((x : X),y))
  simp_rw [hinner] at h
  change 0 ≤ ∫ x : S, (fun x : X => ∫ y in S, F (x,y) ∂ν) x ∂ν.comap Subtype.val at h
  have he := integral_subtype_comap (μ := ν) hS (fun x : X => ∫ y in S, F (x,y) ∂ν)
  exact he ▸ h

/-- The exponential test has nonnegative real double integral whenever all
finite Hankel matrices on the open half interval are positive semidefinite. -/
theorem hankel_integral_nonnegative (a ω : ℝ) (ha : 0 < a)
    (g : ℝ → ℝ) (hg : Measurable g) (B : ℝ) (hB : ∀ r, |g r| ≤ B)
    (hpos : ∀ (n : ℕ) (x : Fin n → Ioo (0 : ℝ) a) (c : Fin n → ℂ),
      0 ≤ (∑ i, ∑ j, conj (c i) * c j * (g ((x i : ℝ)+(x j : ℝ)) : ℂ)).re) :
    0 ≤ (∫ t in (0 : ℝ)..a, ∫ s in (0 : ℝ)..a,
      Complex.exp (Complex.I * (ω : ℂ) * (t-s)) * (g (s+t) : ℂ)).re := by
  let S := Ioo (0 : ℝ) a
  let F : ℝ × ℝ → ℂ := fun p =>
    Complex.exp (Complex.I * (ω : ℂ) * (p.1-p.2)) * (g (p.2+p.1) : ℂ)
  have hF : Measurable F := by dsimp [F]; fun_prop
  have hb (p : ℝ × ℝ) : ‖F p‖ ≤ B := by
    simpa [F, norm_mul, Complex.norm_exp] using hB (p.2+p.1)
  have hrb (p : ℝ × ℝ) : |(F p).re| ≤ B :=
    (Complex.abs_re_le_norm _).trans (hb p)
  have hfinite (n : ℕ) (x : Fin n → S) :
      0 ≤ ∑ i, ∑ j, (F ((x i : ℝ),(x j : ℝ))).re := by
    let c : Fin n → ℂ := fun i => Complex.exp (-Complex.I * (ω : ℂ) * (x i : ℝ))
    have he (i j : Fin n) : conj (c i) * c j *
        (g ((x i : ℝ)+(x j : ℝ)) : ℂ) = F ((x i : ℝ),(x j : ℝ)) := by
      dsimp [c,F]
      rw [← Complex.exp_conj, ← Complex.exp_add]
      simp only [map_mul, map_neg, Complex.conj_I, Complex.conj_ofReal, neg_neg]
      congr 2
      · ring
      · congr 1; ring
    have h := hpos n x c
    simp_rw [he, Complex.re_sum] at h
    exact h
  have h := set_integral_nonnegative (volume.restrict S) S measurableSet_Ioo
    (fun p => (F p).re) (Complex.continuous_re.measurable.comp hF) B hrb hfinite
  have hS : MeasurableSet S := measurableSet_Ioo
  simp only [Measure.restrict_restrict hS, inter_self] at h
  have hi : Integrable F ((volume.restrict S).prod (volume.restrict S)) := by
    apply (integrable_const B).mono' hF.aestronglyMeasurable
    filter_upwards [] with p; exact hb p
  have hreal : (∫ t in S, ∫ s in S, F (t,s)).re =
      ∫ t in S, ∫ s in S, (F (t,s)).re := by
    rw [← integral_prod F hi]
    have hre : (∫ p, (F p).re ∂(volume.restrict S).prod (volume.restrict S)) =
        (∫ p, F p ∂(volume.restrict S).prod (volume.restrict S)).re := integral_re hi
    rw [← hre]
    exact integral_prod _ hi.re
  rw [← hreal] at h
  have heq : (∫ t in (0 : ℝ)..a, ∫ s in (0 : ℝ)..a, F (t,s)) =
      ∫ t in S, ∫ s in S, F (t,s) := by
    simp_rw [intervalIntegral.integral_of_le ha.le, integral_Ioc_eq_integral_Ioo]
    rfl
  change 0 ≤ (∫ t in (0 : ℝ)..a, ∫ s in (0 : ℝ)..a, F (t,s)).re
  rw [heq]
  exact h

/-- Finite Hankel positivity forces the correctly signed sine integral at every
positive fermionic frequency. All endpoint exclusions are measure-zero. -/
theorem fermionic_sine_integral_nonnegative (β : ℝ) (hβ : 0 < β) (n : ℕ)
    (g : ℝ → ℝ) (hg : Measurable g) (B : ℝ) (hB : ∀ r, |g r| ≤ B)
    (hpos : ∀ (k : ℕ) (x : Fin k → Ioo (0 : ℝ) (β/2)) (c : Fin k → ℂ),
      0 ≤ (∑ i, ∑ j, conj (c i) * c j * (g ((x i : ℝ)+(x j : ℝ)) : ℂ)).re) :
    0 ≤ ∫ r in (0 : ℝ)..β, Real.sin (Continuum.frequency β n*r) * g r := by
  have h := hankel_integral_nonnegative (β/2) (Continuum.frequency β n)
    (by positivity) g hg B hB hpos
  rw [Continuum.hankel_fourier_test β hβ n g hg B hB] at h
  simp only [Complex.ofReal_re] at h
  exact nonneg_of_mul_nonneg_right h (one_div_pos.mpr (Continuum.frequency_pos β hβ n))

end SYK.HankelPositivity
