import Mathlib.Data.Finsupp.Multiset
import Mathlib.Algebra.MvPolynomial.Basic
import Mathlib.LinearAlgebra.Finsupp.LinearCombination
import Mathlib.Data.Fin.Tuple.Basic
import Mathlib.Analysis.Complex.Basic

/-! # The polynomial functional of permutation-invariant tuple moments

This module has no microscopic-model imports. A symmetric tuple family extends
canonically to a complex-linear polynomial functional, with exact recovery on
every coordinate product, including repeated coordinates and degree zero.
-/
noncomputable section
open scoped BigOperators
open MvPolynomial
namespace SYK.SymmetricMomentFunctional

/-- A fixed enumeration of a commutative monomial, including multiplicities. -/
def canonicalList {ι : Type*} (e : ι →₀ ℕ) : List ι := e.toMultiset.toList

@[simp] theorem canonicalList_zero {ι : Type*} : canonicalList (0 : ι →₀ ℕ) = [] := by
  simp [canonicalList]

@[simp] theorem canonicalList_length {ι : Type*} (e : ι →₀ ℕ) :
    (canonicalList e).length = e.sum (fun _ n => n) := by
  simp [canonicalList, Finsupp.card_toMultiset, Function.id_def]

/-- The canonical ordered tuple representing a commutative monomial. -/
def canonicalTuple {ι : Type*} (e : ι →₀ ℕ) : Fin (canonicalList e).length → ι :=
  (canonicalList e).get

/-- The product along the chosen enumeration is exactly the original
commutative monomial. No permutation invariance is assumed here. -/
theorem monomial_eq_tuple_prod {ι : Type*} (e : ι →₀ ℕ) :
    (MvPolynomial.monomial e (1 : ℂ)) =
      ∏ i, MvPolynomial.X (canonicalTuple e i) := by
  classical
  have hprod : ∀ e : ι →₀ ℕ,
      (e.toMultiset.map (MvPolynomial.X : ι → MvPolynomial ι ℂ)).prod =
        e.prod (fun i n => (MvPolynomial.X i : MvPolynomial ι ℂ)^n) := by
    intro e
    refine e.induction ?_ ?_
    · simp
    · intro a n e _ _ ih
      rw [Finsupp.toMultiset_add, Multiset.map_add, Multiset.prod_add, ih,
        Finsupp.toMultiset_single, ← Multiset.coe_mapAddMonoidHom,
        (Multiset.mapAddMonoidHom _).map_nsmul, Multiset.prod_nsmul,
        Finsupp.prod_add_index' (fun _ => pow_zero _) (fun _ => pow_add _)]
      simp
  rw [MvPolynomial.monomial_eq, map_one, one_mul, ← hprod]
  rw [← List.prod_ofFn, show List.ofFn (fun i => MvPolynomial.X (canonicalTuple e i)) =
      (canonicalList e).map MvPolynomial.X by
        rw [← Function.comp_def, ← List.map_ofFn]
        simp only [canonicalTuple, List.ofFn_get]]
  rw [← Multiset.prod_coe, ← Multiset.map_coe]
  simp only [canonicalList, Multiset.coe_toList]

theorem listPerm_get_equiv {α : Type*} {l r : List α} (h : l.Perm r) :
    ∃ e : Fin l.length ≃ Fin r.length, ∀ i, l.get i = r.get (e i) := by
  induction h with
  | nil => exact ⟨Equiv.refl _, fun i => Fin.elim0 i⟩
  | @cons a l r h ih =>
    obtain ⟨e, he⟩ := ih
    refine ⟨(finSuccEquiv l.length).trans (e.optionCongr.trans (finSuccEquiv r.length).symm), ?_⟩
    intro i
    refine Fin.cases ?_ (fun i => ?_) i
    · simp
    · simpa using he i
  | swap a b l =>
    refine ⟨Equiv.swap (0 : Fin (l.length+2)) (1 : Fin (l.length+2)), ?_⟩
    intro i
    refine Fin.cases ?_ (fun i => ?_) i
    · simp
    · refine Fin.cases ?_ (fun i => ?_) i
      · simp
      · have h0 : i.succ.succ ≠ (0 : Fin (l.length+2)) := Fin.succ_ne_zero _
        have h1 : i.succ.succ ≠ (1 : Fin (l.length+2)) := by
          intro h
          have hv := congrArg Fin.val h
          simp only [Fin.val_succ, Fin.val_one] at hv
          omega
        simp [Equiv.swap_apply_of_ne_of_ne h0 h1]
  | trans h₁ h₂ ih₁ ih₂ =>
    obtain ⟨e₁, he₁⟩ := ih₁
    obtain ⟨e₂, he₂⟩ := ih₂
    exact ⟨e₁.trans e₂, fun i => (he₁ i).trans (he₂ (e₁ i))⟩


variable {ι : Type*}
variable (M : ∀ n : ℕ, (Fin n → ι) → ℂ)
variable (hM : ∀ n (a : Fin n → ι) (σ : Equiv.Perm (Fin n)), M n (a ∘ σ) = M n a)

include hM in
/-- Permutation symmetry also handles enumerations with propositionally equal
lengths, without requiring a separately assumed coherence axiom. -/
theorem moment_eq_of_equiv {m n : ℕ} (a : Fin m → ι) (b : Fin n → ι)
    (e : Fin m ≃ Fin n) (he : ∀ i, a i = b (e i)) : M m a = M n b := by
  have hmn : m = n := by simpa using Fintype.card_congr e
  subst n
  rw [show a = b ∘ e from funext he]
  exact hM m b e

/-- A tuple-family value on an arbitrary finite list. -/
def listMoment (l : List ι) : ℂ := M l.length l.get

include hM in
theorem listMoment_perm {l r : List ι} (h : l.Perm r) :
    listMoment M l = listMoment M r := by
  obtain ⟨e,he⟩ := listPerm_get_equiv h
  exact moment_eq_of_equiv M hM l.get r.get e he

/-- Coefficientwise extension on the actual multivariate polynomial ring. -/
def functional : MvPolynomial ι ℂ →ₗ[ℂ] ℂ :=
  Finsupp.linearCombination ℂ (fun e => listMoment M (canonicalList e))

@[simp] theorem functional_monomial (e : ι →₀ ℕ) (c : ℂ) :
    functional M (MvPolynomial.monomial e c) = c * listMoment M (canonicalList e) :=
  Finsupp.linearCombination_single ..

/-- A canonical exponent list represents precisely its original multiset. -/
theorem canonicalList_perm [DecidableEq ι] (l : List ι) :
    (canonicalList (Multiset.toFinsupp (l : Multiset ι))).Perm l := by
  apply Multiset.coe_eq_coe.mp
  simp only [canonicalList, Multiset.coe_toList, Multiset.toFinsupp_toMultiset]

include hM in
/-- The canonical functional recovers any listed coordinate product. -/
theorem functional_list_prod (l : List ι) :
    functional M ((l.map MvPolynomial.X).prod) = listMoment M l := by
  classical
  let e := Multiset.toFinsupp (l : Multiset ι)
  have hp := canonicalList_perm l
  have he : MvPolynomial.monomial e (1 : ℂ) = (l.map MvPolynomial.X).prod := by
    rw [monomial_eq_tuple_prod, ← List.prod_ofFn]
    have hlist : List.ofFn (fun i => MvPolynomial.X (canonicalTuple e i)) =
        (canonicalList e).map (MvPolynomial.X : ι → MvPolynomial ι ℂ) := by
      rw [← Function.comp_def, ← List.map_ofFn]
      simp only [canonicalTuple, List.ofFn_get]
    rw [hlist]
    exact (hp.map MvPolynomial.X).prod_eq
  rw [← he, functional_monomial, one_mul]
  exact listMoment_perm M hM hp

include hM in
/-- Permutation invariance alone gives exact tuple-product evaluation. -/
theorem functional_tuple_prod {n : ℕ} (a : Fin n → ι) :
    functional M (∏ i, MvPolynomial.X (a i)) = M n a := by
  have h := functional_list_prod M hM (List.ofFn a)
  rw [List.map_ofFn, List.prod_ofFn] at h
  simp only [Function.comp_def] at h
  rw [h]
  apply moment_eq_of_equiv M hM (List.ofFn a).get a (finCongr (List.length_ofFn (f := a)))
  intro i
  simp [List.get_ofFn, finCongr, Fin.cast]

include hM in
@[simp] theorem functional_one : functional M 1 = M 0 (fun i => Fin.elim0 i) := by
  simpa using functional_tuple_prod M hM (fun i : Fin 0 => Fin.elim0 i)

end SYK.SymmetricMomentFunctional
