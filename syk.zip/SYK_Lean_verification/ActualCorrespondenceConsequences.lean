import ActualWickWard
import ActualFourthResponse

noncomputable section
open scoped NNReal
namespace SYK.ActualCorrespondenceConsequences
open ThermalWick WickVertexIntegrals ContinuumWickSeries

/-- The four repeated bilocals are a literal specialization of the full
inserted operator/Wick correspondence, with no distinctness restriction. -/
theorem fourth_of_list_correspondence (d : ℕ) {β : ℝ} (hβ : 0<β) (lam : ℝ≥0)
    (hMoment : ∀ ps : List (Time β×Time β), normalizedMoment d β hβ ps (lam:ℝ) =
      Interacting.collectiveMoment d β lam (fun i=>((ps.get i).1.val,(ps.get i).2.val)))
    (p : ℝ×ℝ) :
    normalizedMoment d β hβ (quarticPairs β hβ p) (lam:ℝ) =
      Interacting.collectiveMoment d β lam (fun _ : Fin 4=>
        ((timeRepresentative β hβ p.1).val,(timeRepresentative β hβ p.2).val)) := by
  have h := hMoment (quarticPairs β hβ p)
  simpa only [quarticPairs,List.get_eq_getElem,List.getElem_replicate] using h

/-- The single actual list correspondence closes the microscopic derivative
input used by the pressure-limit argument. -/
theorem pressure_response_of_list_correspondence (d : ℕ) (hd : 0<d) {β : ℝ} (hβ : 0<β)
    (lam : ℝ) (hlam : 0<lam)
    (hMoment : ∀ ps : List (Time β×Time β), normalizedMoment d β hβ ps (lam.toNNReal:ℝ) =
      Interacting.collectiveMoment d β lam.toNNReal (fun i=>((ps.get i).1.val,(ps.get i).2.val))) :
    HasDerivAt (fun l=>Microscopic.annealedPressure d β l.toNNReal)
      (FourthMomentIntegral.fourthIntegral d β lam.toNNReal) lam := by
  apply ActualFourthResponse.hasDerivAt_annealedPressure d hd hβ lam hlam
  intro p
  have h := fourth_of_list_correspondence d hβ lam.toNNReal hMoment p
  simpa only [Real.coe_toNNReal _ hlam.le] using h

end SYK.ActualCorrespondenceConsequences
