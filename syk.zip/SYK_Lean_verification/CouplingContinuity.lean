import PhysicalRegularity
import PhysicalClosedness
import PhysicalUniqueness
import PeriodicCompactness
import Mathlib.Topology.UniformSpace.UniformConvergenceTopology

noncomputable section
open MeasureTheory Set Filter Function
open scoped Topology NNReal
namespace SYK.Continuum

/-- Bounded physical solutions with a common centered Lipschitz bound depend
continuously, in the global uniform topology, on a converging coupling. -/
theorem physical_uniform_tendsto (β : ℝ) (hβ : 0 < β)
    (lam : ℕ → ℝ≥0) (l : ℝ≥0) (f : ℕ → ℝ → ℝ) (g : ℝ → ℝ)
    (hp : ∀ n, PhysicalSolution β (lam n) (f n)) (hg : PhysicalSolution β l g)
    (hl : Tendsto (fun n => (lam n : ℝ)) atTop (𝓝 (l : ℝ)))
    (B K : ℝ) (hK : 0 ≤ K) (hb : ∀ n t, |f n t| ≤ B)
    (hLip : ∀ n, LipschitzWith ⟨K,hK⟩ (fun t => f n t - Thermal.covariance β t)) :
    TendstoUniformly f g atTop := by
  letI : Fact (0 < β) := ⟨hβ⟩
  apply (UniformFun.tendsto_iff_tendstoUniformly
    (F := fun n => UniformFun.ofFun (f n)) (f := UniformFun.ofFun g)).mp
  apply tendsto_of_subseq_tendsto
  intro ns hns
  let r := fun n t => f (ns n) t - Thermal.covariance β t
  have hrper (n) : Periodic (r n) (2*β) := by
    intro t
    have hf := (hp (ns n)).2.2.1
    have hc := Thermal.covariance_antiperiodic β hβ.ne'
    dsimp [r]
    have he : t+2*β = (t+β)+β := by ring
    rw [he, hf, hf, hc, hc]
    ring
  have hrb (n t) : |r n t| ≤ B+1/2 :=
    (abs_sub _ _).trans (add_le_add (hb (ns n) t) (Thermal.abs_covariance_le β t))
  obtain ⟨φ,q,hφ,hq,_,_⟩ := periodic_uniform_subsequence (2*β) (by positivity)
    r (B+1/2) K hK hrper hrb (fun n => hLip (ns n))
  let u := fun t => q t + Thermal.covariance β t
  have hu : TendstoUniformly (fun n => f (ns (φ n))) u atTop := by
    rw [Metric.tendstoUniformly_iff] at hq ⊢
    intro ε hε
    filter_upwards [hq ε hε] with n hn
    intro t
    have he : dist (u t) (f (ns (φ n)) t) = dist (q t) (r (φ n) t) := by
      dsimp [u,r]
      simp only [Real.dist_eq]
      congr 1
      ring
    rw [he]
    exact hn t
  have hup : PhysicalSolution β l u := physical_closed_bounded_pointwise β hβ
    (fun n => lam (ns (φ n))) l (fun n => f (ns (φ n))) u
    (fun n => hp _) (hl.comp (hns.comp hφ.tendsto_atTop)) B (fun n => hb _)
    (fun t => hu.tendsto_at t)
  have he : u = g := physical_unique β l u g hup hg
  refine ⟨φ, ?_⟩
  apply UniformFun.tendsto_iff_tendstoUniformly.mpr
  simpa only [Function.comp_def, UniformFun.toFun_ofFun, he] using hu

/-- Uniform continuity along converging coupling sequences follows directly
from physical SD and a common kernel bound; no regularity premise remains. -/
theorem physical_uniform_tendsto_of_bound (β : ℝ) (hβ : 0 < β)
    (lam : ℕ → ℝ≥0) (l : ℝ≥0) (f : ℕ → ℝ → ℝ) (g : ℝ → ℝ)
    (hp : ∀ n, PhysicalSolution β (lam n) (f n)) (hg : PhysicalSolution β l g)
    (hl : Tendsto (fun n => (lam n : ℝ)) atTop (𝓝 (l : ℝ)))
    (B : ℝ) (hb : ∀ n t, |f n t| ≤ B) :
    TendstoUniformly f g atTop := by
  obtain ⟨L,hL⟩ := (Metric.isBounded_range_of_tendsto _ hl).bddAbove
  have hLn (n) : (lam n:ℝ) ≤ L := hL (mem_range_self n)
  have hL0 : 0 ≤ L := (lam 0).coe_nonneg.trans (hLn 0)
  apply physical_uniform_tendsto β hβ lam l f g hp hg hl B (L*β*B^4) (by positivity) hb
  intro n
  exact (physical_centered_lipschitz β hβ (lam n) (f n) (hp n) B (hb n)).weaken
    (show (⟨(lam n:ℝ)*β*B^4, by positivity⟩ : ℝ≥0) ≤ ⟨L*β*B^4, by positivity⟩ from by
      change (lam n:ℝ)*β*B^4 ≤ L*β*B^4
      exact mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_right (hLn n) hβ.le)
        (by positivity))

/-- A uniformly bounded family of actual physical SD solutions is continuous
in the global uniform topology, including at zero coupling. -/
theorem physical_family_continuous (β : ℝ) (hβ : 0 < β)
    (g : ℝ≥0 → ℝ → ℝ) (hp : ∀ l, PhysicalSolution β l (g l))
    (B : ℝ) (hb : ∀ l t, |g l t| ≤ B) :
    Continuous (fun l => UniformFun.ofFun (g l)) := by
  apply continuous_iff_seqContinuous.mpr
  intro ls l hl
  apply UniformFun.tendsto_iff_tendstoUniformly.mpr
  exact physical_uniform_tendsto_of_bound β hβ ls l (fun n => g (ls n)) (g l)
    (fun n => hp _) (hp l) (NNReal.continuous_coe.continuousAt.tendsto.comp hl)
    B (fun n => hb _)

/-- The fourth-moment integral in the pressure formula is continuous in
coupling as a consequence of physical SD, compactness, and uniqueness. -/
theorem physical_quartic_integral_continuous (β : ℝ) (hβ : 0 < β)
    (g : ℝ≥0 → ℝ → ℝ) (hp : ∀ l, PhysicalSolution β l (g l))
    (B : ℝ) (hb : ∀ l t, |g l t| ≤ B) :
    Continuous (fun l => ∫ t in (0:ℝ)..β, (g l t)^4) := by
  apply continuous_iff_seqContinuous.mpr
  intro ls l hl
  have hu := physical_uniform_tendsto_of_bound β hβ ls l (fun n => g (ls n)) (g l)
    (fun n => hp _) (hp l) (NNReal.continuous_coe.continuousAt.tendsto.comp hl)
    B (fun n => hb _)
  apply intervalIntegral.tendsto_integral_filter_of_dominated_convergence (fun _ => B^4)
  · filter_upwards [] with n
    exact ((hp (ls n)).1.pow_const 4).aestronglyMeasurable
  · filter_upwards [] with n
    filter_upwards [] with t _
    simp only [Real.norm_eq_abs, abs_pow]
    exact pow_le_pow_left₀ (abs_nonneg _) (hb (ls n) t) 4
  · exact intervalIntegrable_const
  · filter_upwards [] with t _
    exact (hu.tendsto_at t).pow 4

end SYK.Continuum
